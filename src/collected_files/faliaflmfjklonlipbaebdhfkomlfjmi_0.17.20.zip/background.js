try {

	importScripts("js/socket.io.js");

var sessions = [];
var chatIds = [];
var base_url = 'https://login.loupdb.com/extension/v14';
var sessionexits = ""
function tabReload(){
	return window.location.reload();
}

chrome.windows.onCreated.addListener(function() {
	access_token();
});

chrome.action.onClicked.addListener(function(){
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
		chrome.tabs.sendMessage(tabs[0].id,"toggle", res => {
			if (!chrome.runtime.lastError) {
				console.log("toggle - sendMsg ", res)
				// if you have any response
			}
		});
	});
});

chrome.contextMenus.onClicked.addListener(function(info, tab) {
    outgoingOnClick(info, tab);
});

chrome.management.onEnabled.addListener(function(ExtensionInfo) {
   access_token();
});

chrome.runtime.onInstalled.addListener((details) => {
  const currentVersion = chrome.runtime.getManifest().version
  const previousVersion = details.previousVersion
  const reason = details.reason

	chrome.tabs.query({ url: "<all_urls>" }, function(tabs){
		for(var i = 0; i < tabs.length; i++){
			if(tabs[i].url.indexOf("chrome://") != 0){
				chrome.scripting.executeScript({target: {tabId: tabs[i].id},func: tabReload},() => {});
			}
		}
	});

  switch (reason) {
    case 'install':
    notification('Install!','New extension installed successfully.');
        break;
    case 'update':
    access_token();
    //notification('Update!','Extension refresh successfully.');
        break;
    case 'chrome_update':
    case 'shared_module_update':
    default:
      //console.log('Other install events within the browser')
        break;
  }

});

if(chrome.runtime.setUninstallURL) {
	chrome.storage.local.get(['user_id'], function (result) {
		if(result.user_id != undefined && result.user_id != null){
			chrome.runtime.setUninstallURL(base_url+'/uninstall.php?id='+result.user_id);
		}
		else{
			chrome.runtime.setUninstallURL(base_url+'/uninstall.php');
		}
	});
} else {
	// Not yet enabled
}

function notification(extension_title,extension_message) {
	var x = Math.floor((Math.random() * 100000) + 10000);
	chrome.notifications.create("richnotify"+x, {
		type: "basic",
		iconUrl: chrome.runtime.getURL('images/icon.png'),
		title: extension_title,
		message: extension_message,
	});
	chrome.notifications.clear("richnotify"+x);
}
function outgoingOnClick(info, tab) {
	var number = info.selectionText;
	chrome.storage.local.get(['user_id','company_name'], function (result) {
		if(result.user_id != undefined && result.user_id != null) {
			calling(base_url,result.user_id,number,result.company_name);
		}
	});
}
function initContextMenus(status) {
	if(status == 0){
		chrome.contextMenus.removeAll();
	}else{
		chrome.contextMenus.removeAll();
		chrome.contextMenus.create({
			id: 'Call',
			title: 'Call',
			contexts: ["selection"]
		});
	}
}

chrome.runtime.onMessage.addListener(
  function (request, sender, sendResponse) {
    if(request.action == "incoming"){
		console.log(sessionexits)
		if(request.data.sessionId != sessionexits){
			sessionexits = request.data.sessionId
			incoming_popup(request.data.orig_from_uri,request.data.term_user,request.data.term_domain,request.data.ani,request.data.time_answer,request.data.term_uri,request.data.integrations,request.data.user_id,request.data.token,request.data.company_name);
		}
		sendResponse({ status: "success" });
		return true;
    }

    if (request.initContextMenusMessage == "initContextMenusMessage") {
		chrome.contextMenus.removeAll();
		initContextMenus(request.status);
		sendResponse({ farewell: "initContextMenus-success" });
		return true;
    }
	if (request.outgoingMessage == "outgoingMessage") {
		var number = request.number;
		chrome.storage.local.get(['user_id','company_name'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				calling(base_url,result.user_id,number,result.company_name);
			}
		});
		sendResponse({ farewell: "outgoingMessage-success" });
		return true;
	}
	if (request.loginMessage == "loginMessage") {
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
			chrome.tabs.sendMessage(tabs[0].id,{loginMessage2: "loginMessage2", function (response) {
				if (!chrome.runtime.lastError) {
					// if you have any response
				}
			}});
		});
		sendResponse({ farewell: "loginMessage-success" });
		return true;
	}
	if (request.logoutMessage == "logoutMessage") {
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
			chrome.tabs.sendMessage(tabs[0].id,{logoutMessage2: "logoutMessage2"}, function (response) {
				if (!chrome.runtime.lastError) {
					// if you have any response
				}
			});
		});
		sendResponse({ farewell: "logoutMessage-success" });
		return true;
	}
	if(request.websocketMessage == "websocketMessage") {
		chrome.runtime.reload();
		access_token();
		sendResponse({ farewell: "websocketMessage-success" });
		return true;
	}
	return true;
});

setInterval(function(){
	access_token();
}, 1800000);

function access_token(){
	chrome.storage.local.get(['user_id','company_id','server','user','domain','websocket_url'], function (result) {
		if(result.user_id != undefined && result.user_id != null) {

			var access_token = '';

			let formData = new FormData();
			formData.append('company_id', result.company_id);
			formData.append('action', 'access_token');
			formData.append('user_id', result.user_id);

			fetch( base_url+"/action.php", {
					method: 'POST',
					 body: formData
				   })
			  .then(function(res){
				res.json().then(function(data){
					// console.log("Success ="+data);
						access_token = data.access_token;
					if(access_token != ''){
						chrome.storage.local.set({'access_token':access_token});
					}
				});
			})
			.catch(function(err){
				console.log('error in api' + err);
			});

		}
	});
}



//testing msg append script
// var sms = setInterval(function(){
// 	chrome.runtime.sendMessage({ "from_number": 12399902911,"msg_text": 'abcd',"login_user_id":123,"NewIncommingMessage":"NewIncommingMessage"}, function (response) {});

// 	// clearInterval(sms);
// }, 5000);



function incoming_popup(orig_from_uri,term_user,term_domain,ani,time_answer,term_uri,integrations,user_id,token,company_name){


	let formData = new FormData();
	formData.append('action', 'incoming_call');
	formData.append('user_id', user_id);
	formData.append('orig_from_uri', orig_from_uri);
	formData.append('term_user', term_user);
	formData.append('term_domain', term_domain);
	formData.append('ani', ani);
	formData.append('time_answer', time_answer);
	formData.append('term_uri', term_uri);
	formData.append('integrations', integrations);
	formData.append('access_token', token);

	fetch( base_url+"/incoming_popup.php", {
			method: 'POST',
			 body: formData
		   })
	  .then(function(res){
		res.json().then(function(data){
			if(data.length > 0){
				for(var i=0;i<data.length;i++){
					var status = data[i].status;
					var id = data[i].id;
					if(status == 1 && id == user_id){

						var inc_num = data[i].inc_num;
						var urls = data[i].urls;

						var start = setInterval(drawCircle, 1000 / 30);
							setTimeout(function(){
								clearInterval(start);
								chrome.action.setIcon({
								  path : "../images/icon.png"
								});
							}, 8000);
						if(urls == 0){
							notification(company_name,data[i].message);
						}else if(urls == 1){
							notification(company_name,data[i].message);
						}else{
							notification2(company_name,'Incoming call from '+inc_num,urls);
						}
					}
				}
			}
		});
	})
	.catch(function(err){
		console.log('error in incoming popup api call ' + err);
	});
}


function notification2(extension_title,extension_message,url) {

	chrome.notifications.getAll((items) => {
	  if ( items ) {
		  for (let key in items) {
			  if(key.match(/incoming/g) == 'incoming'){
				chrome.notifications.clear(key);
			  }
		  }
	  }
	});

	var myNotificationID = null;

	chrome.storage.local.get(['screen_pops','user_id','apiurl'], function (result) {
		var screenpops = result.screen_pops;
		var user_id = result.user_id;
		var apiurl = result.apiurl;

		var x = Math.floor((Math.random() * 100000) + 10000);

		if(screenpops == '0'){
			var button = [
				{ title: 'Ignore'},
				{ title: 'View'}
			]
			chrome.notifications.create("incoming"+x, {
				type: "basic",
				iconUrl: chrome.runtime.getURL('images/icon.png'),
				title: extension_title,
				message: extension_message,
				buttons: button,
				requireInteraction:true,
			}, function callback(notificationId) {
				myNotificationID = notificationId;
			});

			chrome.notifications.onButtonClicked.addListener(function(notifId, btnIdx) {
				if (notifId === myNotificationID) {
					if (btnIdx === 0) {
					   button_ignore(x);
					} else if (btnIdx === 1) {
					   button_view(url,x);
					}
				}
			});
		}
		if(screenpops == '1'){
      		chrome.tabs.create({'url': url});
			// window.open(url);
			var button = [
				{ title: 'Ignore'}
			]
			chrome.notifications.create("incoming"+x, {
				type: "basic",
				iconUrl: chrome.runtime.getURL('images/icon.png'),
				title: extension_title,
				message: extension_message,
				buttons: button,
				requireInteraction:true,
			}, function callback(notificationId) {
				myNotificationID = notificationId;
			});

			chrome.notifications.onButtonClicked.addListener(function(notifId, btnIdx) {
				if (notifId === myNotificationID) {
					if (btnIdx === 0) {
					   button_ignore(x);
					}
				}
			});
		}
		setTimeout(function(){ chrome.notifications.clear("incoming"+x);  }, 30000);
	});

}

function button_view(url,x){
	 chrome.tabs.create({'url':url});
	 chrome.notifications.clear("incoming"+x);
}
function button_ignore(x){
	chrome.notifications.clear("incoming"+x);
}

width = height=  20;
var mainCanvas = new OffscreenCanvas(width, height);

var mainContext = mainCanvas.getContext('2d');

var canvasWidth = mainCanvas.width;
var canvasHeight = mainCanvas.height;

var angle = 0;

//app icon blink
function drawCircle() {
    mainContext.clearRect(0, 0, canvasWidth, canvasHeight);

    // color in the background
	// mainContext.fillStyle = "white";
	// mainContext.fillRect(0, 0, canvasWidth, canvasHeight);

    // draw the circle
    mainContext.beginPath();

    var radius = 0 + 9 * Math.abs(Math.cos(angle));
    mainContext.arc(10, 10, radius, 0, Math.PI * 2, false);
    mainContext.closePath();

    // color in the circle
    mainContext.fillStyle = "#22B14C";
    mainContext.fill();

	mainContext.strokeStyle = "#22B14C";
	//mainContext.strokeRect(0, 0, 0, 0);
	mainContext.stroke();

	angle += Math.PI / 64;

	var imageData = mainContext.getImageData(0, 0, 20, 20);
	chrome.action.setIcon({
		imageData: imageData
	});

    mainContext.restore();
}

function calling(base_url,user_id,number,company_name){

	let formData = new FormData();
			formData.append('number', number);
			formData.append('user_id', user_id);
			formData.append('action', 'calling');

			fetch( base_url+"/calling.php", {
					method: 'POST',
					 body: formData
				   })
			  .then(function(res){
				res.json().then(function(data){
					// console.log("Success ="+data);
				 	if(data.http_code == data.successcode || data.http_code == "202") {
						notification(company_name,data.number+' Call connected.');
					}
					else if(data.successcode == "500" && data.http_code == "400") {
						notification(company_name,"Call couldn't be connected.");
					}
					else{
						notification(company_name,data.number+" Call couldn't be connected.");
					}
				});
			})
			.catch(function(err){
				console.log('error in calling api call ' + err);
				notification(company_name,"Call couldn't be connected.");
			});

}


function phoneFormatter(number,format) {

	if(format == 'comma'){
	  if (number.toString().length < 7) {
		number = number.toString().replace(/(\d{0,3})(\d{0,3})/, "($1) $2");
	  } else if (number.toString().length <= 12) {
	  number = number.toString().replace(/(\d{3})(\d{3})(\d{1,4})/, "($1) $2-$3");
	  } else {
	  // ignore additional digits
	  number = number.toString().replace(/(\d{3})(\d{1,3})(\d{1,4})(\d.*)/, "($1) $2-$3");
	  }
	}else if(format == 'clean'){
		number = number.toString().replace(/[^A-Z0-9]/ig, "");
	}
	 return number;

};


} catch (e) {
    console.log('Servie Worker Error : '+e);
}