$(function(){
	var base_url = 'https://login.loupdb.com/extension/v14';
	
	$('[data-toggle="tooltip"]').tooltip();
	
	$('#login').validator().on('submit', function (e) {
	  if (e.isDefaultPrevented()) {

	  } else {
		e.preventDefault();
		$('.loader').show();
		var user_name = $('#user_name').val();
		var password = $('#password').val();
		var company_name = '223';
		$.ajax({
			url: base_url+'/login.php',
			dataType: 'json',
			type: 'post',
			data: {'user_name':user_name,'password':password,'company_name':company_name},
			success: function( data, textStatus, jQxhr ){
				$('.loader').hide();
				$('#message').empty();

				if(data.status == 1){
					chrome.storage.local.set({'company_name':data.company_name,'first_name':data.first_name,'last_name':data.last_name,'apiurl':data.apiurl,'company_id':data.company_id,'click_to_dail':data.click_to_dail,'screen_pops':data.screen_pops,'logo_click_to_call':data.logo_click_to_call,'auto_answer':data.auto_answer,'tel_link':data.tel_link,'user_id':data.user_id,'integrations':data.integrations,'salesforce':data.salesforce,'server':data.server,'user':data.user,'domain':data.domain,'access_token':data.access_token,'redtail':data.redtail,'zoho':data.zoho,'websocket_url':data.websocket_url,'pipedrive':data.pipedrive,'hubspot':data.hubspot});
					
					chrome.runtime.sendMessage({"websocketMessage":"websocketMessage"}, function (response) {});
					
					window.location.href = 'dashboard.html';
				}else{
					$('#message').append('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error!</strong> '+data.message+' </div>');
				}
			},
			error: function( jqXhr, textStatus, errorThrown ){
				$('.loader').hide();
				$('#message').empty();
				$('#message').append('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error!</strong> Server Error, please try again later. </div>');	
				console.log( jqXhr);
			}
		});
	  }
	})
	
	/* chrome.storage.local.get(['user_id'], function (result) {
		if (result.user_id != undefined && result.user_id != null) { 
			window.location.href = 'dashboard.html';
		}
	});  */
	
	
	chrome.runtime.onMessage.addListener(
	  function (request, sender, sendResponse) {
		if (request.loginMessage2 == "loginMessage2") {
			window.location.href = 'dashboard.html';
			sendResponse({ farewell: "loginMessage2-success" });
			return true;
		}
		return true;
		/* if (request.logoutMessage2 == "logoutMessage2") {
			window.location.href = 'login.html';
			return sendResponse({ farewell: "logoutMessage2-success" });
		}  */
	});
	
});