$( document ).ready(function() {

	chrome.runtime.onMessage.addListener(function(msg, sender,sendResponse){
		if(msg == "toggle"){
			toggle();
			sendResponse({ status: "success" });
			return true;
		}
		return true;
	});

	var iframe = document.createElement('iframe'); 
	iframe.style.background = "white";
	iframe.setAttribute('id', 'loup_iframe_id'); 
	//iframe.style.height = "98vh";
	//iframe.style.width = "400px";
	//iframe.style.position = "fixed";
	//iframe.style.top = "0px";
	iframe.style.right = "-405px";
	iframe.style.zIndex = "9999999999";
	//iframe.style.border = "1px solid rgba(13, 33, 48, 0.1)";  
	iframe.src = chrome.runtime.getURL("../html/login.html");
	
	chrome.storage.local.get(['user_id'], function (result) {
		if (result.user_id != undefined && result.user_id != null) { 
			iframe.src = chrome.runtime.getURL("../html/dashboard.html");
		}else{
			iframe.src = chrome.runtime.getURL("../html/login.html");
		}
	});
	
	if(document.getElementsByTagName("BODY")[0] == undefined){
		document.head.after(iframe);
	}else{
		document.body.appendChild(iframe);
	}
	
	function toggle(){
		if(iframe.style.right == "-405px"){
			iframe.style.right = "5px";
			chrome.runtime.sendMessage({"InboundMessage":"InboundMessage"}, function (response) {});
			chrome.runtime.sendMessage({"ToggleMessage":"1"}, function (response) {});
		}
		else{
			iframe.style.right = "-405px";
			chrome.runtime.sendMessage({"ToggleMessage":"0"}, function (response) {});
		}  
		
		chrome.storage.local.get(['logo_click_to_call','user_id','tel_link','click_to_dail'], function (result) {

			if((result.logo_click_to_call != undefined && result.logo_click_to_call != null) || (result.tel_link != undefined && result.tel_link != null)) {
				appendicon(result.logo_click_to_call,result.tel_link,result.click_to_dail);
				IconSetting(result.logo_click_to_call,result.tel_link,result.click_to_dail);
			}
			if (result.user_id != undefined && result.user_id != null) {
				chrome.runtime.sendMessage({ "loginMessage":"loginMessage"}, function (response) {});
			}else{
				chrome.runtime.sendMessage({ "logoutMessage":"logoutMessage"}, function (response) {});
			}
		});	
	}

	$(document).on('mouseover','.Link-Click-To-Call-Trigger', function(event){
		let el = event.currentTarget
		el.previousElementSibling.style.top = `${el.getBoundingClientRect().top - el.getBoundingClientRect().height}px`
		el.previousElementSibling.style.left = `${el.getBoundingClientRect().left + (el.getBoundingClientRect().width / 2 )}px`
	}); 
	
	$(document).on('click','.loup-number',function(){
		var loupnumber = $(this).data('loupnumber');
		chrome.storage.local.get(['logo_click_to_call','tel_link','click_to_dail'], function (result) {
			if(result.logo_click_to_call == 1 || result.tel_link == 1 || result.click_to_dail == 1){
				chrome.runtime.sendMessage({ "number": loupnumber,"outgoingMessage":"outgoingMessage"}, function (response) {});
			} 
		}); 
	});	
});

var pattern = /(\d\d\d.\d\d\d.\d\d\d\d)|[\D]{1}[\(]?\d{3}[\)]?[\s\-]?\d{3}[\s\-]?\d{4}[\D]{1}/gm;
//var pattern =  /[0-9]/gm ;
			 
var nodes=[];
var nodeIndexes=[];

function appendicon(logo_click_to_call,tel_link,click_to_dail) {

	//Search for 10 digit mobile numbers
	findTextnodes(document.body);
	//console.log(nodes);
	for(var i=0; i<nodes.length; i++ )
	{
		//Append each number with a image icon 
		if(nodes[i].nodeValue)
		{
			var val=' '+nodes[i].nodeValue+' ';
			var arr=val.match(pattern);

			for(var h=0;h<1;h++)
			{
				arr[h]=arr[h].replace(/^\D{1}/,'').replace(/\D{1}$/,''); 
				//var mob = arr[h].replace(/[^0-9\.]/g, '');
				var mobile = arr[h].match(/[0-9]/gm).join('');
				
				var pattern1=new RegExp("(?!\=)"+arr[0].replace('(','\\(').replace(')','\\)').replace('-','\\-').replace('.','\\.')+"(?![\&(\"\>)(\'\>)])(?=.?)",'g');
				
				if(nodes[i].nextSibling && nodes[i].nextSibling.tagName=="IMG" && nodes[i].nextSibling.numshow!="undefined")
				{
					
				}
				else
				{
					
					var linktocall = nodes[i].parentNode;

					if(tel_link == 1 || logo_click_to_call == 1 || click_to_dail == 1){
					
						var clicktodail = '<span class="hoverBox" style="z-index:9999"><div class="dFlex"><a href="javascript:void(0)" class="call-icon loup-number" data-loupnumber="'+mobile+'"><img style="width:16px" src="'+chrome.runtime.getURL('images/call-icon.png')+'" /></a></div></span>';
						
						var icon = '<img style="width:16px" class="Logo-Click-To-Call-Trigger" data-loupnumber="'+mobile+'"  title="'+arr[h]+'" width="19" height="19" style="width:19px;height:19px;cursor:pointer;margin-left: 4px;" src="'+chrome.runtime.getURL('images/icon.png')+'"/>';
						
						var setting = '<span class="Icon-Setting"><span class="Click-To-Call-Trigger Click-To-Call">'+clicktodail+'<a href="loup://'+mobile+'" class="sw-phone Link-Click-To-Call-Trigger" data-loupnumber="'+mobile+'">'+arr[h]+icon+'</a></span></span>'; 
						
						if(linktocall.classList.contains('Icon-Setting') == true){ }else{
							linktocall.innerHTML=nodes[i].parentNode.innerHTML.replace(pattern1,setting);
						}
					}
					findTextnodes(document.body);  
				} 
			}          
		}        
	}  
}

function IconSetting(logo_click_to_call,tel_link,click_to_dail){
	if(logo_click_to_call == 1 && tel_link == 1){
		$('.Logo-Click-To-Call-Trigger').removeClass('loup-number');
		$('.Link-Click-To-Call-Trigger').addClass('loup-number');
		$('.Logo-Click-To-Call-Trigger').show();
		$('.Link-Click-To-Call-Trigger').addClass('Link-Click-To-Call').attr('title','Click To Call');
	}
	if(logo_click_to_call == 0 && tel_link == 0){
		$('.Logo-Click-To-Call-Trigger, .Link-Click-To-Call-Trigger').removeClass('loup-number');
		$('.Logo-Click-To-Call-Trigger').hide();
		$('.Link-Click-To-Call-Trigger').removeClass('Link-Click-To-Call').removeAttr('title');
	}
	if(logo_click_to_call == 0 && tel_link == 1){
		$('.Logo-Click-To-Call-Trigger').removeClass('loup-number');
		$('.Link-Click-To-Call-Trigger').addClass('loup-number');
		$('.Logo-Click-To-Call-Trigger').hide();
		$('.Link-Click-To-Call-Trigger').addClass('Link-Click-To-Call').attr('title','Click To Call');
	}
	if(logo_click_to_call == 1 && tel_link == 0){
		$('.Logo-Click-To-Call-Trigger').addClass('loup-number');
		$('.Link-Click-To-Call-Trigger').removeClass('loup-number');
		$('.Logo-Click-To-Call-Trigger').show();
		$('.Link-Click-To-Call-Trigger').removeClass('Link-Click-To-Call').removeAttr('title');
	}
	if(click_to_dail == 1){
		$('.hoverBox').removeClass('Click-To-Call_Hide');
	}
	if(click_to_dail == 0){
		$('.hoverBox').addClass('Click-To-Call_Hide');
	}
	if(logo_click_to_call == 0 && tel_link == 0 && click_to_dail == 0){
		$('.Logo-Click-To-Call-Trigger, .Link-Click-To-Call-Trigger').removeClass('loup-number');
		$('.Logo-Click-To-Call-Trigger').hide();
		$('.Link-Click-To-Call-Trigger').removeClass('Link-Click-To-Call').removeAttr('title');
	}
}
			
function findTextnodes(node,index)
{
	if(node.nodeName=="BODY")
	{
		nodes=[];nodeIndexes=[];
	} 
	if(node.nodeType===3)  // Element Node or textnode
	{ 
		if(!/^\s*$/.test(node.nodeValue)) // Must not be all spaces
		{
			var val=' '+node.nodeValue+' ';
			if(pattern.test(val)!=false || pattern.test(val)!=0)
			{                      
				nodes.push(node);
				nodeIndexes.push(index);                    
			}
		}
	}   
	else
	{
		for(var k=0;k<node.childNodes.length;++k)
		{
			if(node.childNodes[k].nodeName!="SCRIPT" && node.childNodes[k].nodeName!="STYLE" && node.childNodes[k].nodeName!="TEXTAREA")
			{
				findTextnodes(node.childNodes[k],k); 							
			}
		}
	}
}

chrome.runtime.onMessage.addListener(function(msg, sender,sendResponse){	
	if(msg.logoclicktocallMessage == "logoclicktocallMessage" || msg.CalltellinkMessage == "CalltellinkMessage" || msg.ClicktodailMessage == "ClicktodailMessage"){
		chrome.storage.local.get(['logo_click_to_call','tel_link','click_to_dail'], function (result) {
			if((result.logo_click_to_call != undefined && result.logo_click_to_call != null) || (result.tel_link != undefined && result.tel_link != null) || (result.click_to_dail != undefined && result.click_to_dail != null)) {
			
				appendicon(result.logo_click_to_call,result.tel_link,result.click_to_dail);
				IconSetting(result.logo_click_to_call,result.tel_link,result.click_to_dail);	

			}else{
				IconSetting(0,0,0);		
				//appendicon(0,0,0);
			}
		});
		return ;
	}

});

$(document).ready(function() {
	setTimeout(function(){
		chrome.storage.local.get(['logo_click_to_call','tel_link','click_to_dail'], function (result) {
			if((result.logo_click_to_call != undefined && result.logo_click_to_call != null) || (result.tel_link != undefined && result.tel_link != null) || (result.click_to_dail != undefined && result.click_to_dail != null)) {
				$('.Logo-Click-To-Call').remove();
				appendicon(result.logo_click_to_call,result.tel_link,result.click_to_dail);
				IconSetting(result.logo_click_to_call,result.tel_link,result.click_to_dail);
			}else{
				$('.Logo-Click-To-Call').remove();
			}
		});
	}, 3000);

 /*$(document).ready(function() {
	/* setInterval(function(){
		chrome.storage.local.get(['logo_click_to_call','tel_link'], function (result) {
			if((result.logo_click_to_call != undefined && result.logo_click_to_call != null) || (result.tel_link != undefined && result.tel_link != null)) {
				$('.Logo-Click-To-Call').remove();
				appendicon(result.logo_click_to_call,result.tel_link);
			}else{
				$('.Logo-Click-To-Call').remove();
			}
		});
	}, 3000);  */
	
}); 