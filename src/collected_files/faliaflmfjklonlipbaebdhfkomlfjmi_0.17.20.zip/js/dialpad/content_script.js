
var DIALPAD_DOMAIN = 'https://dialpad.com';

var isGmail = false;
var isSalesforce = false;
var domLock = false;
var autoCall = false;
var defaultAppType = (/\bCrOS\b/.test(navigator.userAgent)) ? 'chrome': 'native';
var appType = defaultAppType;

var WEBSITE_EXCEPTIONS = ['uberconference.com'];

var formattedNumberRegex = new RegExp(/(((\d{2,3}[-\. ]){1,2}\d{3,4}[-\. ]\d{4})|((\+?\d{1,3} )?\(\d{2,3}\) ?\d{3,4}[ \-]\d{4})|(\+\d{0,3} ?[- \d\.]{8,13}))/i);
var unformattedNumberRegex = new RegExp(/(((\d{3}[-\. ]?){1,2}\d{3,4}[-\. ]?\d{4})|((\+?\d{1,3} ?)?\(\d{2,3}\) ?\d{3,4}[ \-]?\d{4})|(\+?\d{0,3} ?(?:\d[- \.]*){10,13}))/i);

var _className = 'sw-phone';
//var _classReg = new RegExp('(?:^|\\b)' + _className + '(?:$|\\b)');

var _unacceptableNodes = {
  'SCRIPT': 1,
  'STYLE': 1,
  'TEXTAREA': 1,
  'INPUT': 1,
  'META': 1
};

function log() {
  var args = ['DIALPAD:'].concat(Array.prototype.slice.call(arguments));
  console.log.apply(console, args);
}

function DialpadExtension() {
  chrome.runtime.sendMessage({tabUrl: 1}, $.proxy(function(response) {
    log(response.tabUrl);
    var currentSite = response.tabUrl;

    isGmail = response.tabUrl.indexOf('mail.google.com') != -1;
    isSalesforce = response.tabUrl.indexOf('salesforce.com') != -1;

    chrome.storage.local.get({
      appType: defaultAppType
    }, $.proxy(function(localItems) {
      chrome.storage.sync.get({
        exceptions: '',
        allNumbers: '',
        confirmPhone: true
      }, $.proxy(function(items) {
        if (!this.isPageBlocked(currentSite, items.exceptions)) {
          this.initialize(currentSite, items, localItems);
        } else {
          log('Page blocked');
        }

        if (isGmail) {
          this.initUser();
        }
      }, this));
    }, this));


  }, this));
}

DialpadExtension.prototype.initialize = function(currentSite, items, localItems) {
  autoCall = !items.confirmPhone;
  appType = localItems.appType;
  this.unformatted = this.isUnformattedPage(currentSite, items.allNumbers);
  this.findPhoneNumbers();
  this.listenToDom();
};

DialpadExtension.prototype.listenToDom = function() {
  if (this.observer) {
    this.observer.disconnect();

  }
  this.observer = new MutationObserver(this._onBodyMutation.bind(this));
  this.observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: false,
    characterData: false,
  });
  this.listenToClick();
};

DialpadExtension.prototype._onBodyMutation = function(mutations) {
  mutations.forEach(function (mutation) {
    var nodes = Array.prototype.slice.call(mutation.addedNodes);
    nodes.forEach(this._onNodeAddedToBody.bind(this));
  }.bind(this));
};

DialpadExtension.prototype._onNodeAddedToBody = function(node) {
  if (domLock) {
    return;
  }
  this.findPhoneNumbers(node);
  // Add Call buttons to contact hover card.
  if (isGmail && window.top) {
    this.onGmailDomChanged();
  }
};

DialpadExtension.prototype.listenToClick = function() {
  var $body = $(document.body);
  var selector = '.' + _className;
  if (this.clickListener) {
    $body.off('click', selector, this.clickListener);
  }
  //this.clickListener = this._onClick.bind(this);
 // $body.on('click', selector, this.clickListener);
};

DialpadExtension.prototype._onClick = function(e) {
  e.stopPropagation();
  if (appType == 'web') {
    e.preventDefault();
    chrome.runtime.sendMessage({callPhone: e.target.phoneNumber || e.target.innerText, useWebApp: true, autoCall: autoCall});
    return;
  }
  // Let the background know we clicked a number so it can clean up the tab.
  chrome.runtime.sendMessage({phone: e.target.innerText});
};

DialpadExtension.prototype.findPhoneNumbers = function(opt_target) {
  var target = opt_target || document.body;
  if (!this.isTestableNode(target)) {
    return;
  }
  target.nodeType === 3 ? this.testNode(target) : this.testElement(target);
};

DialpadExtension.prototype.isTestableNode = function(node) {
  if (node.nodeType === 3) {
    // Then it's a text node. It's fine, but we really want to be testing the parentElement;
    node = node.parentElement;
  }
  if (!node || node.nodeType !== 1 || _unacceptableNodes[node.nodeName]) {
    return false;
  }
  var notReplaced = !node.className.match || node.className !== _className;
  var notEditable = !node.closest('[contenteditable]');
  return notReplaced && notEditable;
};

DialpadExtension.prototype.testNode = function(node) {
  if (node.nodeType === 3) {  // Text node.
    this.maybeReplaceNode(node);
  } else if ((appType == 'web' || appType == 'chrome') && 
      node.nodeType === Node.ELEMENT_NODE && 
      node.tagName === 'A' && 
      node.href && node.href.toLowerCase().startsWith('tel:')) {
    this.maybeReplaceLink(node);
  } else {
    this.findPhoneNumbers(node);
  }
};

DialpadExtension.prototype.testElement = function(el) {
  var node;
  var ct = 0;
  while (node = (el.childNodes || [])[ct]) {
    this.testNode(node);
    ct++;
  }
};

DialpadExtension.prototype.maybeReplaceLink = function(node) {
  // replace tel links with dialpad links so that they work with web and/or chrome.
  var phoneNumber = node.href.replace(/tel:(\/)*/, '');
  console.log('Found tel for ', phoneNumber);
  if (appType === 'web') {
    node.className = node.className + ' ' + _className;
    node.phoneNumber = phoneNumber;
  } else if (appType === 'chrome') {
    // Replace tel link href with chrome friendly version. 
    node.href = this.getC2cUrl(phoneNumber);
    node.className = node.className + ' ' + _className;
    node.target = '_blank';
  }
};

DialpadExtension.prototype.maybeReplaceNode = function(node) {
  var regex = unformattedNumberRegex;
  if (!this.unformatted && !isSalesforce) {
    regex = formattedNumberRegex;
  }
  var replace = false;
  var originalText = node.textContent;
  var parentTag = node.parentElement.tagName;

  // Hack to fix Google search, and also good to never try to replace any text with meta in it.
  // Also, do not replace text that is an already existing hyperlink unless it's a call
  // with Hangouts link.
  if (originalText.indexOf('<meta') != -1 ||
      (parentTag === 'A' && node.parentElement.dataset.pstnOutCallUrl === undefined)) {
    return false;
  }

  // https://jsperf.com/htmlencoderegex/25
  // re-encode any tags contained in the text content.
  originalText = document.createElement('div').appendChild(
      document.createTextNode(originalText)).parentNode.innerHTML;

  var text = originalText.replace(regex, function(match) {
    replace = true;
    return this.createLink(match);
  }.bind(this));

  if (replace) {
    domLock = true;
    $(node).replaceWith(text);
  }
  domLock = false;
};

DialpadExtension.prototype.getC2cUrl = function(number) {
  return (appType == 'chrome' ? 'https://dialpad.com/launch/?phone=' : 'loup://') +
    encodeURIComponent(number) + (autoCall ? '|1' : '') ;
};

DialpadExtension.prototype.createLink = function(number) {
	
 /* return '<a class="' + _className + ' Link-Click-to-Call" data-loupnumber="'+number.match(/[0-9]/gm).join('')+'" title="Click to Call" ' +
      (appType == 'chrome' ? 'target="_blank" ' : '') +
      'href="' + this.getC2cUrl(number)  + '">' + number + '</a>';	 */
	  
	  var number2 = number.match(/[0-9]/gm).join('');
	  number2 = number2.substr(-10);

  return '<a class="Link-Click-to-Call" data-loupnumber="'+number2+'" title="Click to Call" ' +
      (appType == 'chrome' ? 'target="_blank" ' : '') +
      'href="' + this.getC2cUrl(number)  + '">' + number + '</a>';
};

DialpadExtension.prototype.isPageBlocked = function(currentSite, pageExceptions) {
  var blockPage = false;

  var exceptions = pageExceptions.split('\n');
  exceptions = _.union(exceptions, WEBSITE_EXCEPTIONS);

  _.each(exceptions, function(url) {
    if (url && currentSite.indexOf(url) != -1) {
      blockPage = true;
      return;
    }
  });

  return blockPage;
};

DialpadExtension.prototype.isUnformattedPage = function(currentSite, pages) {
  var unformatted = false;

  var allNumberSites = pages.split('\n');
  _.each(allNumberSites, function(url) {
    if (url && currentSite.indexOf(url) != -1) {
      unformatted = true;
      return;
    }
  });

  return unformatted;
};

DialpadExtension.prototype.initUser = function() {
  chrome.storage.local.get('user', $.proxy(function(result) {
    this.user = result.user;
    if (this.user) {
      $.ajaxSetup({headers: {'Authorization': 'Bearer ' + this.user.auth.access_token}});
    } else if (window.top == window.self) {
      this.checkLogin();
    }
  }, this));
};

/**
 * Add call button to Gmail's contact hover card.
 */
DialpadExtension.prototype.onGmailDomChanged = function() {
  var contactCard = $('div.o-ms-fk');
  if (contactCard.length) {
    log('Card Changed');
    var email = contactCard.find('div.vta').text();

    if (email != this.email) {
      log('Get Contact');
      this.email = email;
      log(this.email);

      // Make request for contact.
      this.getContact(email);
      return;
    }

    log('Same email, re-add button');
    this.addCallLink();
  }
};

DialpadExtension.prototype.checkLogin = function(opt_force) {
  if (opt_force || !this.user) {
    chrome.storage.local.set({'lastLoginAttempt': new Date().getTime()});

    chrome.storage.local.get('client_id', function(result) {
      var client_id = result.client_id;
      if (!client_id) {
        client_id = Math.random().toString(36).substring(2, 17);
        chrome.storage.local.set({'client_id': client_id});
      }

      var params = {
        'type': 'proxy',
        'client_id': client_id
      };

      var login = $.ajax(DIALPAD_DOMAIN + '/api/login', {
        data: JSON.stringify(params),
        contentType: 'application/json',
        type: 'POST'
      });

      login.done(function(data) {
        log(data);
        chrome.storage.local.set({'user': data});
      });
    });
  }
};

/**
 * Look up the user in Dialpad by email.
 * Save the info in local storage so we don't have to hit the server every time.
 * @param email
 */
DialpadExtension.prototype.getContact = function(email) {
  this.contact = null;

  // Check if it's in cache first and return if it is.
  chrome.storage.local.get(email, $.proxy(function(result) {
    log('Get Cache result:', result);

    // No local cache, go get data from server.
    if (!(email in result)) {
      log('requestContact from server');
      this._requestContact(email);
      return;
    }

    // Local cache with no matches in Dialpad. Do nothing.
    if (result[email] == 'no_match') {
      log('cached, but no match');
      return;
    }

    this.contact = result[email];
    log('Cached contact, add link');
    this.addCallLink();

    // NOTE(brian): For now always update in background. Maybe do a date timeout later.
    this._requestContact(email);
  }, this));
};

DialpadExtension.prototype.addCallLink = function() {
  if (!this.contact || $('.X6.qPa').has('.dp-call').length) {
    return;
  }

  log('Add button');

  var url = this.getC2cUrl(this.contact['primary_phone']);

  var $ctc = $('<div>', {class: 'dp-call', title: 'Call with Dialpad'}).append($('<img>', {
    src: 'https://storage.googleapis.com/switch_static/extension/dplogo.svg'
  }));

  $ctc.on('click', $.proxy(function(e) {
    // If we're in web app mode, send
    if (appType == 'web') {
      chrome.runtime.sendMessage({callPhone: this.contact['primary_phone'], useWebApp: true, autoCall: autoCall});
      return;
    }

    // This opens a tab since it's in a content script.
    var win = window.open(url);

    // Let the background know we clicked a number so it can clean up the tab.
    chrome.runtime.sendMessage({phone: this.contact['primary_phone']});
  }, this));

  $('.X6.qPa').prepend($ctc);
};

DialpadExtension.prototype._requestContact = function(email) {
  // Not in cache so search the server and then set result to cache.
  var params = {
    'search': email,
    'filter': 'all',
    'phones_only': 'true'
  };

  var xhr = $.ajax(DIALPAD_DOMAIN + '/api/contact', {
    data: params,
    contentType: 'application/json',
    type: 'GET',
    statusCode: {
      403: $.proxy(function() {
        // If hasn't logged in ever or last login attempt was over a day ago.
        chrome.storage.local.get('lastLoginAttempt', $.proxy(function(result) {
          var lastLoginAttempt;
          if (result.lastLoginAttempt) {
            lastLoginAttempt = new Date(result.lastLoginAttempt);
          }

          if (!lastLoginAttempt || (((new Date()) - lastLoginAttempt) > 86400000)) {
            this.checkLogin(true);
          }
        }, this));
      }, this)
    }
  });

  xhr.done($.proxy(function(data) {
    log(data);
    log(data.length);

    this.contact = data.length ? data[0] : 'no_match';

    var cache = {};
    cache[email] = this.contact;

    if (data.length && this.email == email) {
      this.addCallLink();
    }

    log('Set cache:', cache);
    chrome.storage.local.set(cache);
  }, this));
};


// Start Extension.
new DialpadExtension();


$(document).ready(function() {
	$(document).on('click','.sw-phone',function(){
		var loupnumber = $(this).data('loupnumber');
		chrome.storage.local.get(['tel_link'], function (result) {
			if(result.tel_link == 1){
				chrome.runtime.sendMessage({ "number": loupnumber,"outgoingMessage":"outgoingMessage"}, function (response) {});
			} 
		});
	}); 	
}); 
