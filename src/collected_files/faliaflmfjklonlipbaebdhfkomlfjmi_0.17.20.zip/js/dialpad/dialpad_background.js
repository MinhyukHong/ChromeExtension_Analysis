/* eslint-env es6 */
/* var SWITCH_URL = 'https://dialpad.com';
var SWITCH_LAUNCH_URL = SWITCH_URL + '/launch';
var SWITCH_APP_URL = SWITCH_URL + '/app';

var launchedBefore = false; */


/* function init() {
  createRightClickMenu();
}

init(); */



/* function restoreOptions(url, callback) {
  chrome.storage.sync.get({
    exceptions: '',
    allNumbers: ''
  }, function(items) {
    console.log(items.exceptions);
    callback(url, items);
  });
} */


/* function createRightClickMenu() {
  chrome.contextMenus.create({
    "id": "website_exception",
    "title" : "Ignore phone numbers for this site",
    "type" : "checkbox",
    "contexts" : ["page"],
    "onclick" : getClickHandler()
  });

  chrome.contextMenus.create({
    "id": "unformatted",
    "title" : "Link unformatted numbers for this site",
    "type" : "checkbox",
    "contexts" : ["page"],
    "onclick" : getClickHandler()
  });
} */


/* function isPageInSettingList(currentSite, pageList) {
  var blockPage = false;

  var urls = pageList.split('\n');

  _.each(urls, function(url) {
    if (url && currentSite.indexOf(url) != -1) {
      blockPage = true;
      return;
    }
  });

  return blockPage;
} */


/* function updateRightClickMenu(url, items) {
  chrome.contextMenus.update(
    "website_exception",
    {
      "checked": isPageInSettingList(url, items.exceptions)
    }
  );

  chrome.contextMenus.update(
    "unformatted",
    {
      "checked": isPageInSettingList(url, items.allNumbers)
    }
  );
} */


/* function addPage(url, setting) {
  restoreOptions(url, function(url, items) {
    var currentVal = items[setting].trim();

    var data = {};
    data[setting] = (currentVal + '\n' + url).trim();

    chrome.storage.sync.set(data, function() {});
  });
}


function removePage(url, setting) {
  restoreOptions(url, function(url, items) {
    var currentList = items[setting].split('\n');
    var newList = _.without(currentList, url);

    var data = {};
    data[setting] = newList.join('\n');

    chrome.storage.sync.set(data, function() {});
  });
} */


/**
 * Returns a handler which will open a new window when activated.
 */
/* function getClickHandler() {
  return function(info, tab) {
    console.log(info);
    var url = getHostname(info.pageUrl);

    if (info.checked) {
      addPage(url, getMenuSetting(info.menuItemId));
    } else {
      removePage(url, getMenuSetting(info.menuItemId));
    }
  };
}


function getMenuSetting(menuItemId) {
  switch (menuItemId) {
    case 'unformatted':
      return 'allNumbers';
    case 'website_exception':
      return 'exceptions';
  }
}


function getHostname(url) {
  var hostname;

  if (url.indexOf("://") > -1) {
    hostname = url.split('/')[2];
  }
  else {
    hostname = url.split('/')[0];
  }

  //find & remove port number
  hostname = hostname.split(':')[0];
  //find & remove "?"
  hostname = hostname.split('?')[0];

  return hostname;
} */


/* function launchCloseDelay() {
  if (launchedBefore) {
    return 3000;
  }

  // This gives Window's users enough time to accept the prompt before we close the tab.
  launchedBefore = true;
  return 30000;
} */


/* function closeLaunchTab() {
  // Wait a while to let the app launch before closing the tab.
  _.delay(function() {
    chrome.tabs.query({url: SWITCH_LAUNCH_URL + '*'}, function(tabs) {
      _.each(tabs, function(tab) {
        chrome.tabs.remove(tab['id']);
      });
    });
  }, launchCloseDelay());
}  */


function callPhoneWithWebApp(phoneNumber, autoCall, opt_isRetry) {
  // Find a tab with dialpad.com/app
  // If no dialpad.com/app, launch dialpad.com/app?call=phoneNumber
  chrome.tabs.query({url: "<all_urls>"}, function(tabs) {
   /*  if (!tabs.length) {
      // If we've already tried to open the window, give up.
      if (opt_isRetry) {
        return;
      }
      chrome.tabs.create({url: SWITCH_APP_URL}, function() {
        // Try to call it again in 3 seconds.
        _.delay(function() {
          callPhoneWithWebApp(phoneNumber, autoCall, true);
        }, 3000);
      });
      return;
    } */
    // Just use the first tab.
    var tab = tabs[0];
    chrome.tabs.executeScript(tab['id'], {'code': `
      {
        let el = document.getElementById('call-phone');
        let customEvent = new CustomEvent('call', {detail: {phone: '${phoneNumber}', autoCall: ${autoCall}}});
        el.dispatchEvent(customEvent);
      }
    `});
    chrome.tabs.highlight({tabs: tab['index'], windowId: tab['windowId']});
  });
}


/**
 * Attempt the launch the Switch app when the user clicks the extension icon.
 * Uses the packaged app url_handlers to achieve this.
 * https://developer.chrome.com/apps/manifest/url_handlers
 */
/* chrome.browserAction.onClicked.addListener(function (tab) {

  chrome.tabs.create({'url': SWITCH_LAUNCH_URL, 'active': false}, function (tab) {
    var newTabId = tab['id'];

    // We need to delay the tab removal to make sure the App intercept has time to happen.
    _.delay(function() {
      chrome.tabs.get(newTabId, function(tab) {
        if (tab['url'].indexOf(SWITCH_LAUNCH_URL) != -1) {
          chrome.tabs.remove(tab['id']);
        }
      });
    }, launchCloseDelay());
  });

  chrome.runtime.requestUpdateCheck(function(status) {
    if (status == "update_available") {
      console.log("update pending...");
    } else if (status == "no_update") {
      console.log("no update found");
    } else if (status == "throttled") {
      console.log("Oops, I'm asking too frequently - I need to back off.");
    }
  });
}); */


/* chrome.runtime.onUpdateAvailable.addListener(function(details) {
  console.log("updating to version " + details.version);
  chrome.runtime.reload();
}); */


chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  console.log(request);
  if (request.tabUrl) {
    sendResponse({tabUrl: sender.tab.url});
    return;
  }

  if (request.callPhone) {
    // Maybe send an api request in the future?
    if (request.useWebApp) {
      callPhoneWithWebApp(request.callPhone, request.autoCall);
      return;
    }
  }
  // If the /launch tab is still open, close it.
  // closeLaunchTab();
});

/* chrome.runtime.onInstalled.addListener(function(details) {
  if (chrome.runtime.OnInstalledReason.UPDATE == details.reason) {
    // If the user has the old useWebApp setting, set the local setting to 'web'
    // and clear out useWebApp
    chrome.storage.sync.get(['useWebApp'], function(result) {
      if (result.useWebApp) {
        chrome.storage.local.set({'appType': 'web'});
        chrome.storage.sync.set({'useWebApp': null});
      }
    });
  }
}); */


/* chrome.tabs.onActivated.addListener(function(activeInfo) {
  chrome.tabs.get(activeInfo.tabId, function(tab) {
    // Update the context menu state for this tab.
    restoreOptions(tab.url, updateRightClickMenu);
  });
}); */
