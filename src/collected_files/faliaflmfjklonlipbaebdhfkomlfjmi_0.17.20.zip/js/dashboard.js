$(function(){
	
	var salesforce_pop = zoho_pop = hubspot_pop = null;
	var socket;
	var request_call_data;
  	var sessions = [];
	
	var maxHeight = $( window ).height(); //window.screen.availHeight;
	$('.contact-table-scroll tbody').css('height',maxHeight - 422);
	$('.table-scroll tbody').css('height',maxHeight - 436);
	$('.table-scroll-directory tbody').css('height',maxHeight - 355);
	
	$(window).resize(function(){
		var maxHeight = $( window ).height();
		$('.contact-table-scroll tbody').css('height',maxHeight - 422);
		$('.table-scroll tbody').css('height',maxHeight - 436);
		$('.table-scroll-directory tbody').css('height',maxHeight - 355);
	});
	
	$('select').select2({
		minimumResultsForSearch: -1
	});

	const getItemFromStorage = (key) => {
		return new Promise((resolve, reject) => {
			chrome.storage.local.get(key, (result) => {
				if (chrome.runtime.lastError) {
					reject(chrome.runtime.lastError);
				} else {
					resolve(result[key]);
				}
			});
		});
	};


	var base_url = 'https://login.loupdb.com/extension/v14';

	chrome.storage.local.get(['company_name','first_name','last_name','apiurl','company_id','click_to_dail','screen_pops','logo_click_to_call','auto_answer','tel_link','integrations','user_id','salesforce','redtail','zoho','pipedrive','hubspot','user', 'domain', 'access_token','websocket_url'], function (result) {
		
		//call socket
		request_call_data = {
			domain: result.domain,
			filter: result.user,
			type: 'call',
			'bearer': result.access_token
		};
	
		socket = io.connect(result.websocket_url, {
			secure: true,
			jsonp: false,
		});
	
		//initiate socket
		socket.on('connect', function() {
			
		//   smsNotification('Socket','Socket Connected');
			console.log("status", 'Socket Connected');
			
			socket.emit('subscribe', request_call_data);
		});
	
		socket.on('connect_error', function(err) {
			console.log("status", 'connect_error');
			console.log("status", err);
		});
	
		socket.on('error', function(err) {
			console.log("status", 'error');
			console.log("status", err);
		});
	
	
		//event fire when new incoming call connection
		socket.on('call', function(data) {
			
			//console.log(data);
			if (typeof data == "object"){
			
			var sessionId = data.sessionId;
			var orig_from_uri = data.orig_from_uri;
			var term_user = data.term_user;
			var term_domain = data.term_domain;
			var time_answer = data.time_answer;
			var ani = data.ani;
			var term_uri = data.term_uri;
			
			var term_sub = data.term_sub;
			
			var Call_To_Talk = 'Call_To_Talk_'+sessionId;
			var Call_Queue = 'Call_Queue_'+sessionId;

			(async () => {
				var userId = await getItemFromStorage('user');

				if(orig_from_uri != 'Call-To-Talk' && Number.isInteger(Number(ani)) == true && time_answer == '0000-00-00 00:00:00' && term_sub != '' && data.orig_user != userId ){
				

				if(sessions.indexOf(Call_To_Talk) === -1) {
					
					sessions.push(Call_To_Talk);
					
					chrome.storage.local.get(['user_id','integrations','company_name','sessionId'], function (result) {
						if(result.user_id != undefined && result.user_id != null) {
							
							if(result.sessionId == sessionId) {
									
							}else{
								chrome.storage.local.set({'sessionId': sessionId}, function(results) {
									chrome.runtime.sendMessage({action: 'incoming', data: {orig_from_uri: orig_from_uri,term_user: term_user,term_domain: term_domain,ani: ani,time_answer: time_answer,term_uri: term_uri,integrations: result.integrations, user_id: result.user_id, token: result.access_token, company_name: result.company_name, sessionId: sessionId}},function (response) {
										if (!chrome.runtime.lastError) {
											// if you have any response
										}
									})
								});
							}
						}
					});
				}
			}
	
				
			if(term_uri == 'Call-Queue' && Number.isInteger(Number(ani)) == true && term_domain != ''){
				if(sessions.indexOf(Call_Queue) === -1) {
					sessions.push(Call_Queue);
					
					chrome.storage.local.get(['user_id','integrations','company_name','sessionId2'], function (result) {
						if(result.user_id != undefined && result.user_id != null) {
							
							if(result.sessionId2 == sessionId) {
									
							}else{
								chrome.storage.local.set({'sessionId': sessionId}, function(results) {
									chrome.runtime.sendMessage({action: 'incoming', data: {orig_from_uri: orig_from_uri,term_user: term_user,term_domain: term_domain,ani: ani,time_answer: time_answer,term_uri: term_uri,integrations: result.integrations, user_id: result.user_id, token: result.access_token, company_name: result.company_name, sessionId: sessionId}},function (response) {
										if (!chrome.runtime.lastError) {
											// if you have any response
										}
									})
								});
							}
						}
					});
					
				}
			}
			})();
			}
		});
  		call_history(base_url,result.user_id,'Inbound',1);

		if(result.company_name != undefined && result.company_name != null) {
			$('#company-name').html(result.company_name);
		}
		if(result.first_name != undefined && result.first_name != null) {
			$('#extension-full-name').html(result.first_name+' '+result.last_name);
		}
		if(result.apiurl != undefined && result.apiurl != null) {
			//$('#portal-home').attr('href',result.apiurl+'/portal/home');
			$('#portal-home-footer').attr('href',result.apiurl+'/portal/home');
			//$('#view-call-history').attr('href',result.apiurl+'/portal/callhistory');
			//$('#view-contacts').attr('href',result.apiurl+'/portal/contacts');
			$('#call-history').attr('href',result.apiurl+'/portal/callhistory');
		}
		if(result.click_to_dail != undefined && result.click_to_dail != null) {
			if(result.click_to_dail == '0'){
				$('#click_to_dail').removeAttr('checked');
			}else{
				$('#click_to_dail').attr('checked');
			}
			$('#click_to_dail').val(result.click_to_dail);
			chrome.runtime.sendMessage({ initContextMenusMessage: "initContextMenusMessage","status":result.click_to_dail}, function (response) {
				if (!chrome.runtime.lastError) {
					console.log("result.click_to_dail",result.click_to_dail);
				}
			});

			chrome.tabs.query({ url: "<all_urls>" }, function (tabs) {
				for (var i = 0; i < tabs.length; i++) {
					chrome.tabs.sendMessage(tabs[i].id, { "ClicktodailMessage": "ClicktodailMessage", "status": result.click_to_dail },(res) => {
						if (!chrome.runtime.lastError) {
							// if you have any response
						}
					});
				}
			});
		}
		if(result.screen_pops != undefined && result.screen_pops != null) {
			if(result.screen_pops == '0'){
				$('#screen_pops').removeAttr('checked');
			}else{
				$('#screen_pops').attr('checked');
			}
			$('#screen_pops').val(result.screen_pops);
		}
		if(result.tel_link != undefined && result.tel_link != null) {
			if(result.tel_link == '0'){
				$('#tel_link').removeAttr('checked');
			}else{
				$('#tel_link').attr('checked');
			}
			$('#tel_link').val(result.tel_link);
			
			
			chrome.tabs.query({ url: "<all_urls>" }, function(tabs)
			{
				for(var i = 0; i < tabs.length; i++)
				{
					chrome.tabs.sendMessage(tabs[i].id, {"status":result.tel_link,"CalltellinkMessage":"CalltellinkMessage"}, function (response) {
						if (!chrome.runtime.lastError) {
							// if you have any response
						}
					});
				} 
			});
		}
		if(result.logo_click_to_call != undefined && result.logo_click_to_call != null) {

			if(result.logo_click_to_call == '0'){
				$('#logo_click_to_call').removeAttr('checked');
			}else{
				$('#logo_click_to_call').attr('checked');
			}
			$('#logo_click_to_call').val(result.logo_click_to_call);
			

			chrome.tabs.query({ url: "<all_urls>" }, function(tabs)
			{
				for(var i = 0; i < tabs.length; i++)
				{
					chrome.tabs.sendMessage(tabs[i].id, {"logoclicktocallMessage":"logoclicktocallMessage","status":result.logo_click_to_call}, function (response) {
						if (!chrome.runtime.lastError) {
							// if you have any response
						}
					});
				} 
			});
			
			
		}
		
		if(result.salesforce != undefined && result.salesforce != null) {
			
			if(result.salesforce == '0'){
				$('#salesforce').removeAttr('checked');
				}else{
				$('#salesforce').attr('checked');
			}
			$('#salesforce').val(result.salesforce);
		}
		if(result.redtail != undefined && result.redtail != null) {
			
			if(result.redtail == '0'){
				$('#redtail').removeAttr('checked');
			}else{
				$('#redtail').attr('checked');
			}
			$('#redtail').val(result.redtail);
		}
		if(result.zoho != undefined && result.zoho != null) {
			
			if(result.zoho == '0'){
				$('#zoho').removeAttr('checked');
			}else{
				$('#zoho').attr('checked');
			}
			$('#zoho').val(result.zoho);
		}
		if(result.pipedrive != undefined && result.pipedrive != null) {
			
			if(result.pipedrive == '0'){
				$('#pipedrive').removeAttr('checked');
			}else{
				$('#pipedrive').attr('checked');
			}
			$('#pipedrive').val(result.pipedrive);
		}
		if(result.hubspot != undefined && result.hubspot != null) {
			
			if(result.hubspot == '0'){
				$('#hubspot').removeAttr('checked');
			}else{
				$('#hubspot').attr('checked');
			}
			$('#hubspot').val(result.hubspot);
		}
		if(result.auto_answer != undefined && result.auto_answer != null) {
			if(result.auto_answer == '0'){
				$('#auto_answer').removeAttr('checked');
			}else{
				$('#auto_answer').attr('checked');
			}
			$('#auto_answer').val(result.auto_answer);
		}
		
		if(result.company_id != undefined && result.company_id != null) {
			$.ajax({ url: base_url+"/integrations.php",
				data: {"company_id":result.company_id},
				dataType:'JSON',
				method: 'POST',
				beforeSend: function() {
					
				},
				success: function(obj, textStatus, jqXHR) {
					var integrations = $("#integrations");
					integrations.empty(); 
					integrations.append("<option value=''>Select App</option>");
					for(var i = 0; i < obj.length; i++) {
						var url_popup1=obj[i].url_popup;
						var url_name1=obj[i].url_name;
						var url1=obj[i].url;
						integrations.append("<option value='"+url_popup1+"' data-name='"+url_name1.toLowerCase()+"' data-url='"+url1+"'>"+url_name1+"</option>");	
					}
					$('#integrations').val(result.integrations);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					//if fails      
				}			
			});
		}
	});
	
	$('[data-toggle="tooltip"]').tooltip();

	$(document).on("input", ".only-number", function() {
		this.value = this.value.replace(/\D/g,'');
	});
	$(document).on('click','.btn-history, .btn-contacts, .btn-settings',function(){
		chrome.storage.local.get(['user_id'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				
			}else{
				logout();
			}
		});
		
		$('.loader').show();
		$('.btn-history, .btn-contacts, .btn-settings').removeClass('btn-info').removeClass('disabled');
		$(this).addClass('btn-info').addClass('disabled');

		switch($(this).html()) {
		  case 'History':
			var type = $('#tab-history .nav-tabs').find('li.active').find('a').html();
			chrome.storage.local.get(['user_id'], function (result) {
				call_history(base_url,result.user_id,type,1);
			});
			$('#tab-history').show();
			$('#tab-contacts').hide();
			$('#tab-settings').hide();
			break;
		  case 'Contacts':
			$('#tab-history').hide();
			$('#tab-contacts').show();
			$('#tab-settings').hide();
			
			/* if($('.contacts-tabs-li').hasClass('active') == false){
				$('.contacts-tabs-li-first').addClass('active');
			} */

			var type = $('#tab-contacts .nav-tabs').find('li.active').find('a').html();
			chrome.storage.local.get(['user_id'], function (result) {
				$('#get-contact-table').empty();
				if(type == 'Directory'){
					presence(base_url,result.user_id,1); 
					websoket_presence();
				}
				if(type == 'Speed Dials'){
					contact_table_scroll(base_url,result.user_id,'',0);
				}
			});			
			break;
		  case 'Settings':
			$('#tab-history').hide();
			$('#tab-contacts').hide();
			$('#tab-settings').show();
			break;
		  default:
			$('#tab-history').show();
			$('#tab-contacts').hide();
			$('#tab-settings').hide();
			break;
	   } 
	   setTimeout(function(){ $('.loader').hide(); }, 1000);
	});
	$(document).on('click','.btn-logout',function(){
		chrome.storage.local.clear(function() {
			logout();
		 var error = chrome.runtime.lastError;
			if (error) {
				console.error(error);
			}
		});
	});
	$(document).on('submit','#quick-call-form',function(event){
		event.preventDefault();
		var quick_call = $('#quick_call').val();
		if(quick_call == ""){
			$('#quick_call').focus();
		}else{
			chrome.storage.local.get(['user_id','company_name'], function (result) {
				if(result.user_id != undefined && result.user_id != null) {
					
					$.ajax({ url: base_url+"/calling.php",
						data: {"user_id":result.user_id,"action":"calling",'number':quick_call},
						dataType:'JSON',
						method: 'POST',
						beforeSend: function() {
							$('#quick_call').addClass('calling-loader');
						},
						success:function(data, textStatus, jqXHR) {
							$('#quick_call').removeClass('calling-loader');
							if(data.http_code == data.successcode || data.http_code == "202") {
								notification(result.company_name,data.number+' Call connected.');
							}else{
								notification(result.company_name,data.number+" Call couldn't be connected.");
							}
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('#quick_call').removeClass('calling-loader');
							notification(result.company_name,"Call couldn't be connected.");  
						}			
					});
					
				}else{
					logout();
				}
			});
		}
	});
	$('#pipedrive-form-next').validator().on('submit', function (e) {

		if (e.isDefaultPrevented()) {

		} else {
			e.preventDefault();
			var pipedrive_token = $('#pipedrive-token').val();
			var pipedrive_domain = $('#pipedrive-domain').val();
			$('#pipedrive-user').empty('');
			var pipedrive_user = '';
			if(pipedrive_token != '' && pipedrive_domain != ''){
				chrome.storage.local.get(['user_id','company_name'], function (result) {
					if(result.user_id != undefined && result.user_id != null) {
						$.ajax({ url: base_url+"/pipedrive.php",
							data: {"user_id":result.user_id,"action":"pipedrive_login","pipedrive_token":pipedrive_token,"pipedrive_domain":pipedrive_domain,"pipedrive_user":pipedrive_user},
							dataType:'JSON',
							method: 'POST',
							beforeSend: function() {
								$('.loader').show();
								$('.btn-pipedrive').prop('disabled',true);
							},
							success: function(obj, textStatus, jqXHR) {
							
								$('.loader').hide();
								$('.btn-pipedrive').prop('disabled',false);
							
								if(obj.status == 1){
								
									$('#pipedrive-form-next').hide();
									$('#pipedrive-form-finish').show();

									$('#pipedrive-user').empty('');
									$('#pipedrive-user').append('<option value="">Select</option>');
									
									for(var i=0; i< obj.users.length; i++){
										$('#pipedrive-user').append('<option value="'+obj.users[i].id+'">'+obj.users[i].name+'</option>');
									} 
								}else{
									$('#pipedrive-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong>'+obj.message+'</div>');
								} 
								
							},
							error: function(jqXHR, textStatus, errorThrown) {
								$('.btn-pipedrive').prop('disabled',false);
								$('#pipedrive-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong> Server Error, please try again later. </div>');
								$('.loader').hide(); 
							}			
						});
					}else{
						logout();
					}
				});
			}else{
				$('#pipedrive-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong> Username and Password Required. </div>');
			}
		}
	});
	
	
	$(document).on('click','.btn-pipedrive-back', function (e) {
		$('#pipedrive-form-next').show();
		$('#pipedrive-form-finish').hide();
	});
	
	$('#pipedrive-form-finish').validator().on('submit', function (e) {
		
		if (e.isDefaultPrevented()) {

		} else {
			e.preventDefault();
			var pipedrive_token = $('#pipedrive-token').val();
			var pipedrive_domain = $('#pipedrive-domain').val();
			var pipedrive_user = $('#pipedrive-user').val();
			if(pipedrive_token != '' && pipedrive_domain != ''){
				chrome.storage.local.get(['user_id','company_name'], function (result) {
					if(result.user_id != undefined && result.user_id != null) {
						$.ajax({ url: base_url+"/pipedrive.php",
							data: {"user_id":result.user_id,"action":"pipedrive_login","pipedrive_token":pipedrive_token,"pipedrive_domain":pipedrive_domain,"pipedrive_user":pipedrive_user},
							dataType:'JSON',
							method: 'POST',
							beforeSend: function() {
								$('.loader').show();
								$('.btn-pipedrive-finish').prop('disabled',true);
							},
							success: function(obj, textStatus, jqXHR) {
							
								$('.loader').hide();
								$('.btn-pipedrive-finish').prop('disabled',false);
							
								if(obj.status == 1){
								
									$('#pipedrive-form-next').show();
									$('#pipedrive-form-finish').hide();
								
									$('#pipedrive-token').val('');
									$('#pipedrive-domain').val('');
									$('#pipedrive-user').val('');
									swal("Pipedrive Account", "Connected successfully", "success");
									chrome.storage.local.set({'pipedrive':1});
									$('#pipedrive').val(1);
									$('#pipedrive').prop("checked",true);
									$('#pipedriveModal').modal('hide');
									
									$('#pipedrive-user option').each(function() {
										$(this).remove();
									});
									
								}else{
									$('#pipedrive-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong>'+obj.message+'</div>');
								} 
								
							},
							error: function(jqXHR, textStatus, errorThrown) {
								$('.btn-pipedrive-finish').prop('disabled',false);
								$('#pipedrive-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong> Server Error, please try again later. </div>');
								$('.loader').hide(); 
							}			
						});
					}else{
						logout();
					}
				});
			}else{
				$('#pipedrive-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong> Username and Password Required. </div>');
			}
		}
	});
	
	$('#redtail-form').validator().on('submit', function (e) {

		if (e.isDefaultPrevented()) {

		} else {
			e.preventDefault();
			var username = $('#redtail-username').val();
			var password = $('#redtail-password').val();
			if(username != '' && password != ''){
				chrome.storage.local.get(['user_id','company_name'], function (result) {
					if(result.user_id != undefined && result.user_id != null) {
						$.ajax({ url: base_url+"/action.php",
							data: {"user_id":result.user_id,"action":"redtail_login","username":username,"password":password},
							dataType:'JSON',
							method: 'POST',
							beforeSend: function() {
								//$('.loader').show();
								$('.btn-redtail').prop('disabled',true);
							},
							success: function(obj, textStatus, jqXHR) {
								if(obj.status == 1){
									$('#redtail-username').val('');
									$('#redtail-password').val('');
									swal("Redtail Account", "Connected successfully", "success");
									chrome.storage.local.set({'redtail':1});
									$('#redtail').val(1);
									$('#redtail').prop("checked",true);
									$('#redtailModal').modal('hide');
								}else{
									$('#redtail-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong>'+obj.message+'</div>');
								} 
								//$('.loader').hide();
								$('.btn-redtail').prop('disabled',false);
							},
							error: function(jqXHR, textStatus, errorThrown) {
								$('.btn-redtail').prop('disabled',false);
								$('#redtail-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong> Server Error, please try again later. </div>');
								//$('.loader').hide(); 
							}			
						});
					}else{
						logout();
					}
				});
			}else{
				$('#redtail-message').html('<div class="alert alert-danger fade in alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a><strong>Error! </strong> Username and Password Required. </div>');
			}
		}
	});
	$('#add-contact-form').validator().on('submit', function (e) {
		if (e.isDefaultPrevented()) {

		} else {
			e.preventDefault();
			var full_name = $('#full_name').val();
			var number = $('#number').val();
			chrome.storage.local.get(['user_id','company_name'], function (result) {
				if(result.user_id != undefined && result.user_id != null) {
					$.ajax({ url: base_url+"/action.php",
						data: {"user_id":result.user_id,"action":"add_contact","full_name":full_name,"number":number},
						dataType:'JSON',
						method: 'POST',
						beforeSend: function() {
							$('.loader').show();
						},
						success: function(obj, textStatus, jqXHR) {
							if(obj == 1){
								$('#full_name').val('');
								$('#number').val('');
								notification(result.company_name,'Contact created successfully.');
								$('#get-contact-table').empty();
								contact_table_scroll(base_url,result.user_id,'',0);
							}else{
								notification(result.company_name,'Contact not created.');
							}
							$('.loader').hide();
						},
						error: function(jqXHR, textStatus, errorThrown) {
							$('.loader').hide();
							notification(result.company_name,'Contact not created.');
						}			
					});
				}else{
					logout();
				}
			});
		}
	});
	$(document).on('change','#integrations',function(){
		
		var integrations = $('#integrations').val();
		
		chrome.storage.local.get(['user_id','company_name'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				
				integrations_fun(base_url,result.user_id,integrations,result.company_name);
					
			}else{
				logout();
			}
			
		});
	});
	$(document).on('click','#screen_pops, #click_to_dail, #logo_click_to_call, #auto_answer, #tel_link',function(){
		
		var id = $(this).attr('id');
		
		chrome.storage.local.get(['company_name','user_id','integrations'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				$.ajax({ url: base_url+"/action.php",
					data: {"user_id":result.user_id,"action":"settings","name":id},
					dataType:'JSON',
					method: 'POST',
					beforeSend: function() {
						$('#'+id).prop('disabled',true);
					},
					success: function(obj, textStatus, jqXHR) {
						
						var switchs = '';
						
						$('#'+id).val(obj);
						$('#'+id).prop('disabled',false);
						
						if(obj == '0'){
							switchs = 'off';
							$('#'+id).prop('checked',false);
						}else{
							switchs = 'on';
							$('#'+id).prop('checked',true);
						}
						
						if(id == 'screen_pops'){
							notification(result.company_name,'Screen pops '+switchs+' successfully.');
							chrome.storage.local.set({'screen_pops':obj});
						}
						if(id == 'click_to_dail'){
							notification(result.company_name,'Click to call '+switchs+' successfully.');
							chrome.storage.local.set({'click_to_dail':obj});

							chrome.runtime.sendMessage({ initContextMenusMessage: "initContextMenusMessage","status":obj}, function (response) {
								if (!chrome.runtime.lastError) {
									// if you have any response
								}
							});
						}
						if(id == 'logo_click_to_call'){
							notification(result.company_name,'Logo click to call '+switchs+' successfully.');
							chrome.storage.local.set({'logo_click_to_call':obj});

							chrome.tabs.query({ url: "<all_urls>" }, function(tabs)
							{
								for(var i = 0; i < tabs.length; i++)
								{
									chrome.tabs.sendMessage(tabs[i].id, {"logoclicktocallMessage":"logoclicktocallMessage","status":obj}, function (response) {
										if (!chrome.runtime.lastError) {
											// if you have any response
										}
									});
								} 
							});
							
						}
						if(id == 'auto_answer'){
							notification(result.company_name,'Click to call auto answer '+switchs+' successfully.');
							chrome.storage.local.set({'auto_answer':obj});
						}
						if(id == 'tel_link'){
							notification(result.company_name,'Click to call link '+switchs+' successfully.');
							chrome.storage.local.set({'tel_link':obj});
							
							
							chrome.tabs.query({ url: "<all_urls>" }, function(tabs)
							{
								for(var i = 0; i < tabs.length; i++)
								{
									chrome.tabs.sendMessage(tabs[i].id, {"status":obj,"CalltellinkMessage":"CalltellinkMessage"}, function (response) {
										if (!chrome.runtime.lastError) {
											// if you have any response
										}
									});
								} 
							}); 
							
							
						}
					},
					error: function(jqXHR, textStatus, errorThrown) {
						$('#'+id).prop('disabled',false);  
					}			
				}); 
			}else{
				logout();
			}
		});		
	}); 
	$('#get-contact-table').scroll(function() {
		if($(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight) {
			chrome.storage.local.get(['user_id'], function (result) {
				if(result.user_id != undefined && result.user_id != null) {
					var offset = $(".contact-table-scroll tr").last().attr('id');
					contact_table_scroll(base_url,result.user_id,offset,'',0);
				}else{
					logout();
				}
			});
		}
	});
	$(document).on('click','.calling',function(){
		var number = $(this).data('original-title');
		chrome.storage.local.get(['user_id','company_name'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				chrome.runtime.sendMessage({ "number": number,"outgoingMessage":"outgoingMessage"}, function (response) {
					if (!chrome.runtime.lastError) {
						// if you have any response
					}
				});
			}else{
				logout();
			}
		});
	});
	$(document).on('click','.call-history-tabs, .contacts-tabs-li',function(){
		var tabs = '';
		var type = $(this).find('a').html();
		if($(this).hasClass('call-history-tabs') == true){
			tabs = 1;
		}
		if($(this).hasClass('contacts-tabs-li') == true){
			tabs = 2;
		}
		chrome.storage.local.get(['user_id'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				
				if(tabs == 1){
					call_history(base_url,result.user_id,type,1);
				}
				if(tabs == 2){
					if(type == 'Directory'){
						presence(base_url,result.user_id,1); 
						websoket_presence();
					}
					if(type == 'Speed Dials'){
						contact_table_scroll(base_url,result.user_id,'',1);
					}
				}
			}else{
				logout();
			}
		}); 
	});
	$(document).on('click','.manual-screen-pop',function(){
		var url_id = $('#integrations').val();
		var number = $(this).parents('tr').find('td').eq(0).html();
		
		chrome.storage.local.get(['company_name','user_id'], function (result) {
			if((result.company_name != undefined && result.company_name != null) && (result.user_id != undefined && result.user_id != null)){
				
				if(url_id != ''){
					$.ajax({ url: base_url+"/action.php",
						data: {"url_id":url_id,"action":"manual_screen_pop","number":number,"user_id":result.user_id},
						dataType:'JSON',
						method: 'POST',
						beforeSend: function() {

						},
						success: function(obj, textStatus, jqXHR) {

							if(obj.auth == 0 || obj.auth == 1 || obj.auth == 2){
								if(obj.auth == 0){
									notification(result.company_name,obj.message);
								}
								if(obj.auth == 2){
									notification(result.company_name,obj.message);
								}
								if(obj.auth == 1){
									if(obj.url != ''){
										window.open(obj.url);
									}
								}
							}else{
								if(obj.url != ''){
									window.open(obj.url);
								}else{
								
								}
							}
						},
						error: function(jqXHR, textStatus, errorThrown) {
							
						}			
					});
				}else{
					notification(result.company_name,'Please select app.');
				} 
				
			}else{
				logout();
			}
		});
	});
	$(document).on('click','.del-contact',function(){
		var contact_id = $(this).data('id');
		chrome.storage.local.get(['user_id','company_name'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				
				swal({
					title: "Are you sure?",
					text: "Do you want to delete contact?",
					type: "warning",
					showCancelButton: true,
					confirmButtonColor: "#DD6B55",
					confirmButtonText: "Yes",
					cancelButtonText: "No",
					closeOnConfirm: true,
					closeOnCancel: true
				},
				function(isConfirm){
					if (isConfirm) {
						$.ajax({ url: base_url+"/action.php",
							data: {"user_id":result.user_id,"action":"del_contact","contact_id":contact_id},
							dataType:'JSON',
							method: 'POST',
							beforeSend: function() {
								$('.loader').show();
							},
							success: function(obj, textStatus, jqXHR) {
								if(obj == 1){
									
									$('.contact-'+contact_id).remove();
									var offset = $(".contact-table-scroll tr").last().attr('id');
									contact_table_scroll(base_url,result.user_id,offset,'',0);

									notification(result.company_name,"Contact deleted successfully.");
								}else{
									notification(result.company_name,"Contact not deleted.");
								}
								$('.loader').hide();
							},
							error: function(jqXHR, textStatus, errorThrown) {
								$('.loader').hide();
								notification(result.company_name,"Contact not deleted.");
							}			
						});	   
					} else {
						//swal("Cancelled", "Your imaginary file is safe :)", "error");
					}
				});  
			}else{
				logout();
			}
		});
	});
	
	$(document).on('click','#arrow-right',function(){
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
			chrome.tabs.sendMessage(tabs[0].id,"toggle", function (response) {
				if (!chrome.runtime.lastError) {
					// if you have any response
				}
			});
		}); 
	});
	$(document).on('click','#redtail',function(){
		
		$('#redtail-username').val('');
		$('#redtail-password').val('');
		
		var redtail = $('#redtail').val();
		if(redtail == 0){
			if($('#redtail').prop("checked") == true){
				$('#redtail').prop("checked",false);
			}
			$('#redtail-message').empty();
			$('#redtailModal').modal({backdrop: 'static', keyboard: false});
		}
		if(redtail == 1){
			chrome.storage.local.get(['user_id','company_name'], function (result) {
				if(result.user_id != undefined && result.user_id != null) {
					
					if($('#redtail').prop("checked") == false){
						$('#redtail').prop("checked",true);
					}
					swal({
					  title: "Are you sure?",
					  text: "You want to disconnect Redtail Account?",
					  type: "warning",
					  showCancelButton: true,
					  confirmButtonColor: "#DD6B55",
					  confirmButtonText: "Disconnect",
					  cancelButtonText: "Cancel",
					  closeOnConfirm: true,
					  closeOnCancel: true
					},
					function(isConfirm){
					  if(isConfirm) {
							$.ajax({ url: base_url+"/action.php",
								data: {"user_id":result.user_id,"action":"redtail_status"},
								dataType:'JSON',
								method: 'POST',
								beforeSend: function() {
									$('#redtail').prop('disabled',true);
								},
								success: function(obj) { 
									if(obj == 1){
										$('#redtail').prop("checked",true);
										chrome.storage.local.set({'redtail':0});
										$('#redtail').val(0);
										$('#redtail').prop("checked",false);
										notification(result.company_name,"Redtail account disconnected successfully."); 
									}
									$('#redtail').prop('disabled',false);
								},
								error: function(jqXHR, textStatus, errorThrown) {
									$('#redtail').prop('disabled',false);
								}
							});
						} else {

					  }
					});
				}
			});
		}
		
	});
	$(document).on('click','#pipedrive',function(){
		
		$('#pipedrive-token').val('');
		$('#pipedrive-domain').val('');
		
		var pipedrive = $('#pipedrive').val();
		if(pipedrive == 0){
			if($('#pipedrive').prop("checked") == true){
				$('#pipedrive').prop("checked",false);
			}
			$('#pipedrive-message').empty();
			
			$('#pipedrive-token').val();
			$('#pipedrive-domain').val();
			$('#pipedrive-user').empty('');
			$('#pipedrive-form-next').show();
			$('#pipedrive-form-finish').hide();

			$('#pipedriveModal').modal({backdrop: 'static', keyboard: false});
			
			
		}
		if(pipedrive == 1){
			chrome.storage.local.get(['user_id','company_name'], function (result) {
				if(result.user_id != undefined && result.user_id != null) {
					
					if($('#pipedrive').prop("checked") == false){
						$('#pipedrive').prop("checked",true);
					}
					swal({
					  title: "Are you sure?",
					  text: "You want to disconnect Pipedrive Account?",
					  type: "warning",
					  showCancelButton: true,
					  confirmButtonColor: "#DD6B55",
					  confirmButtonText: "Disconnect",
					  cancelButtonText: "Cancel",
					  closeOnConfirm: true,
					  closeOnCancel: true
					},
					function(isConfirm){
					  if(isConfirm) {
							$.ajax({ url: base_url+"/pipedrive.php",
								data: {"user_id":result.user_id,"action":"pipedrive_cancel"},
								dataType:'JSON',
								method: 'POST',
								beforeSend: function() {
									$('#pipedrive').prop('disabled',true);
								},
								success: function(obj) { 
									if(obj == 1){
										$('#pipedrive').prop("checked",true);
										chrome.storage.local.set({'pipedrive':0});
										$('#pipedrive').val(0);
										$('#pipedrive').prop("checked",false);
										notification(result.company_name,"Pipedrive account disconnected successfully."); 
									}
									$('#pipedrive').prop('disabled',false);
								},
								error: function(jqXHR, textStatus, errorThrown) {
									$('#pipedrive').prop('disabled',false);
								}
							}); 
						} else {

					  }
					});
				}
			});
		}
		
	});
	$(document).on('click','#salesforce',function(){

		chrome.storage.local.get(['user_id','company_name'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				var salesforce = $('#salesforce').val();
				if(salesforce == 0){
				
					salesforce_pop = window.open(base_url+'/salesforce_auth.php?user_id='+result.user_id,'name','height=500,width=500,status=yes');
					
					if($('#salesforce').prop("checked") == true){
						$('#salesforce').prop("checked",false);
					}
					
					salesforce_auth = setInterval(function() {
						if (!salesforce_pop || !salesforce_pop.closed) return;
						clearInterval(salesforce_auth);
						
						$.ajax({ url: base_url+"/action.php",
							data: {"user_id":result.user_id,"action":"auth"},
							dataType:'JSON',
							method: 'POST',
							success: function(obj) {
							
								clearInterval(salesforce_auth);
							
								if(obj == 1){
									$('#salesforce').prop("checked",true);
									chrome.storage.local.set({'salesforce':obj});
									$('#salesforce').val(obj);
									swal("Salesforce CRM", "Connected successfully", "success");

									$("#integrations option").each(function(){
										var name = $(this).data('name');
										var id = $(this).val();
										if(name != ''){
											if(name == 'salesforce'){
												integrations_fun(base_url,result.user_id,id,result.company_name);
											}
										}
									});
									
								}
							},
							error: function(jqXHR, textStatus, errorThrown) {
								clearInterval(salesforce_auth);
							}
						});
						
						
					},100);
					

				}else{
					
					if($('#salesforce').prop("checked") == false){
						$('#salesforce').prop("checked",true);
					}
					
					swal({
					  title: "Are you sure?",
					  text: "You want to disconnect Salesforce CRM?",
					  type: "warning",
					  showCancelButton: true,
					  confirmButtonColor: "#DD6B55",
					  confirmButtonText: "Disconnect",
					  cancelButtonText: "Cancel",
					  closeOnConfirm: true,
					  closeOnCancel: true
					},
					function(isConfirm){
					  if(isConfirm) {
							$.ajax({ url: base_url+"/action.php",
								data: {"user_id":result.user_id,"action":"auth_cancel"},
								dataType:'JSON',
								method: 'POST',
								beforeSend: function() {
									$('#salesforce').prop('disabled',true);
								},
								success: function(obj) {
									$('#salesforce').prop("checked",false);	
									$('#salesforce').prop('disabled',false);
									if(obj == 1){
										chrome.storage.local.set({'salesforce':0});
										$('#salesforce').val(0);
										notification(result.company_name,"Salesforce CRM call log disconnected successfully."); 
									}
								},
								error: function(jqXHR, textStatus, errorThrown) {
									$('#salesforce').prop('disabled',false);
								}
							});
						} else {

					  }
					}); 
										 
				}
			}else{
				logout();
			}
		}); 

	});

	$(document).on('click','#hubspot',function(){
		chrome.storage.local.get(['user_id','company_name'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				var hubspot = $('#hubspot').val();
				if(hubspot == 0){
					
					hubspot_pop = window.open(base_url+'/hubspot/hubspot_auth.php?user_id='+result.user_id,'name','height=500,width=500,status=yes');
					
					if($('#hubspot').prop("checked") == true){
						$('#hubspot').prop("checked",false);
					}

					hubspot_auth = setInterval(function() {
						if (!hubspot_pop || !hubspot_pop.closed) return;
						clearInterval(hubspot_auth);
						
						$.ajax({ url: base_url+"/hubspot/hubspot.php",
							data: {"user_id":result.user_id,"action":"hubspot_auth"},
							dataType:'JSON',
							method: 'POST',
							success: function(obj) { 
								
								clearInterval(hubspot_auth);
							
								if(obj == 1){
									$('#hubspot').prop("checked",true);
									chrome.storage.local.set({'hubspot':obj});
									$('#hubspot').val(obj);
									swal("HubSpot CRM", "Connected successfully", "success");
								}
							},
							error: function(jqXHR, textStatus, errorThrown) {
								clearInterval(hubspot_auth);
							}
						});
						
						
					},100);
						
				}else{
					
					if($('#hubspot').prop("checked") == false){
						$('#hubspot').prop("checked",true);
					}
					
					swal({
					  title: "Are you sure?",
					  text: "You want to disconnect HubSpot CRM?",
					  type: "warning",
					  showCancelButton: true,
					  confirmButtonColor: "#DD6B55",
					  confirmButtonText: "Disconnect",
					  cancelButtonText: "Cancel",
					  closeOnConfirm: true,
					  closeOnCancel: true
					},
					function(isConfirm){
					  if(isConfirm) {
							$.ajax({ url: base_url+"/hubspot/hubspot.php",
								data: {"user_id":result.user_id,"action":"hubspot_auth_cancel"},
								dataType:'JSON',
								method: 'POST',
								beforeSend: function() {
									$('#hubspot').prop('disabled',true);
								},
								success: function(obj) { 
									$('#hubspot').prop('disabled',false);
									if(obj == 1){
										$('#hubspot').prop("checked",false);
										chrome.storage.local.set({'hubspot':0});
										$('#hubspot').val(0);
										notification(result.company_name,"HubSpot CRM call log disconnected successfully."); 
									}
								},
								error: function(jqXHR, textStatus, errorThrown) {
									$('#hubspot').prop('disabled',false);
								}
							});
						} else {

					  }
					});  
				}
			}else{
				logout();
			}
		});
	});
	
	$(document).on('click','#zoho',function(){

		chrome.storage.local.get(['user_id','company_name'], function (result) {
			if(result.user_id != undefined && result.user_id != null) {
				var zoho = $('#zoho').val();
				if(zoho == 0){

					zoho_pop = window.open(base_url+'/zoho_oauth.php?user_id='+result.user_id,'name','height=500,width=500,status=yes');
					
					if($('#zoho').prop("checked") == true){
						$('#zoho').prop("checked",false);
					}
					
					
					zoho_auth = setInterval(function() {
						if (!zoho_pop || !zoho_pop.closed) return;
						clearInterval(zoho_auth);
						
						$.ajax({ url: base_url+"/action.php",
							data: {"user_id":result.user_id,"action":"zoho_auth"},
							dataType:'JSON',
							method: 'POST',
							success: function(obj) { 
								clearInterval(zoho_auth);
								if(obj == 1){
									$('#zoho').prop("checked",true);
									chrome.storage.local.set({'zoho':obj});
									$('#zoho').val(obj);
									swal("Zoho CRM", "Connected successfully", "success");
								}
							},
							error: function(jqXHR, textStatus, errorThrown) {
								clearInterval(zoho_auth);
							}
						});
						
					},100);
 
				}else{
					
					if($('#zoho').prop("checked") == false){
						$('#zoho').prop("checked",true);
					}
					
					swal({
					  title: "Are you sure?",
					  text: "You want to disconnect Zoho CRM?",
					  type: "warning",
					  showCancelButton: true,
					  confirmButtonColor: "#DD6B55",
					  confirmButtonText: "Disconnect",
					  cancelButtonText: "Cancel",
					  closeOnConfirm: true,
					  closeOnCancel: true
					},
					function(isConfirm){
					  if(isConfirm) {
							$.ajax({ url: base_url+"/action.php",
								data: {"user_id":result.user_id,"action":"zoho_auth_cancel"},
								dataType:'JSON',
								method: 'POST',
								beforeSend: function() {
									$('#zoho').prop('disabled',true);
								},
								success: function(obj) { 
									$('#zoho').prop('disabled',false);
									if(obj == 1){
										$('#zoho').prop("checked",false);
										chrome.storage.local.set({'zoho':0});
										$('#zoho').val(0);
										notification(result.company_name,"Zoho CRM call log disconnected successfully."); 
									}
								},
								error: function(jqXHR, textStatus, errorThrown) {
									$('#zoho').prop('disabled',false);
								}
							});
						} else {

					  }
					});  
				}
			}else{
				logout();
			}
		}); 

	});
	
	chrome.runtime.onMessage.addListener(
	  function (request, sender, sendResponse) {
		if (request.logoutMessage2 == "logoutMessage2") {
			logout();
			sendResponse({ farewell: "logoutMessage2-success" });
			return;
		}
		if(request.InboundMessage == 'InboundMessage'){
			var type = $('#tab-history .nav-tabs').find('li.active').find('a').html();
			chrome.storage.local.get(['user_id'], function (result) {
				call_history(base_url,result.user_id,type,1);
			}); 
			sendResponse({ farewell: "InboundMessage-success" });
			return;
		}
		if(request.ToggleMessage == '1'){
			$('body').eq(0).addClass('toggle-on');
			sendResponse({ farewell: "ToggleMessage-success" });
			return;
		}
		if(request.ToggleMessage == '0'){
			$('body').eq(0).removeClass('toggle-on');
			sendResponse({ farewell: "ToggleMessage-success" });
			return;
		}
		return;
	});

	
/* 	setInterval(function(){ 
		var toggle = $('body').eq(0).hasClass('toggle-on');
		if(toggle == true){}
		
		var contacts_history = $('#tab-history').is(':visible');
		if(contacts_history == true){
			var type = $('#tab-history .nav-tabs').find('li.active').find('a').html();
			chrome.storage.local.get(['user_id'], function (result) {
				if(result.user_id != undefined && result.user_id != null){
					call_history(base_url,result.user_id,type,0);
				}
			});
		}

	}, 30000); */ 
	
	/* setInterval(function(){
		var contacts_visible = $('#tab-contacts').is(':visible');
		if(contacts_visible == true){
			var contacts_active = $('.contacts-tabs-li-first').hasClass('active');
			if(contacts_active == true){
				chrome.storage.local.get(['user_id'], function (result) {
					if(result.user_id != undefined && result.user_id != null){
						presence(base_url,result.user_id,0);
					}
				});
			}
		}
	}, 5000); */
});

function notification(extension_title,extension_message) {
	var x = Math.floor((Math.random() * 100000) + 10000);
	chrome.notifications.create("richnotify"+x, {
		type: "basic",
		iconUrl: chrome.runtime.getURL('images/icon.png'),
		title: extension_title,
		message: extension_message
	});
	chrome.notifications.clear("richnotify"+x);
}

function contact_table_scroll(base_url,user_id,offset,loader){
	$.ajax({ url: base_url+"/action.php",
		data: {"user_id":user_id,"action":"get_contact","offset":offset},
		dataType:'JSON',
		method: 'POST',
		beforeSend: function() {
			if(loader == 1){
				$('.loader').show();
			}
		},
		success: function(obj, textStatus, jqXHR) {
			var contact_table = $('#get-contact-table');
			if(obj.length > 0){
				for(var i=0; i<obj.length; i++){
					var contact = $(".contact-"+obj[i].id).hasClass("contact-"+obj[i].id);
					if(contact == false){
						contact_table.append('<tr class="contact-'+obj[i].id+'" id="'+obj[i].id+'"><td><i class="fa fa-user-o fa-2x" aria-hidden="true"></i> '+obj[i].name+'</td><td class="text-right"><a href="#"><i class="fa fa-minus fa-2x text-danger del-contact" data-id="'+obj[i].id+'" aria-hidden="true" data-toggle="tooltip" title="Delete"></i></a>&nbsp;&nbsp;<a href="#"><i class="fa fa-phone fa-2x text-success calling" aria-hidden="true" data-toggle="tooltip" title="'+obj[i].phone+'"></i></a></td></tr>');
					}
				}
			}else{
				var offset = $(".contact-table-scroll tr").last().attr('id');
				if(offset != undefined && offset != null){
					$('.not-contact-list').remove();
					//contact_table.append('<tr><td colspan="2" class="text-center not-contact-list">No More List</td></tr>');
				}else{
					$('.not-contact-list').remove();
					contact_table.append('<tr><td colspan="2" class="text-center not-contact-list">No Contacts</td></tr>');
				}
			}
			$('[data-toggle="tooltip"]').tooltip();
			$('.loader').hide();
		},
		error: function(jqXHR, textStatus, errorThrown) {
			$('.loader').hide();
		}			
	});
}

function call_history(base_url,user_id,type,loader){
	if(type == 'Inbound'){
		var get_call_history = $('#inbound-call-history');
	}if(type == 'Outbound'){
		var get_call_history = $('#outbound-call-history');
	}if(type == 'Missed'){
		var get_call_history = $('#missed-call-history');
	}
	$.ajax({ url: base_url+"/action.php",
		data: {"user_id":user_id,"action":"call_history","type":type},
		dataType:'JSON',
		method: 'POST',
		beforeSend: function() {
			if(loader == 1){
				$('.loader').show();
			}
		},
		success:function(data, textStatus, jqXHR) {
			if(data.length > 0){
				get_call_history.empty();
				for(var i=0;i<data.length;i++){
					get_call_history.append('<tr><td>'+data[i].number+'</td><td>'+data[i].date+'</td><td class="text-right"><a href="#"><i class="fa fa-phone fa-2x text-success calling" data-toggle="tooltip" title="'+data[i].number+'" aria-hidden="true"></i></a>&nbsp;<a href="#" class="manual-screen-pop" data-toggle="tooltip" title="Screen pop"><i class="fa fa-search fa-2x text-info" aria-hidden="true"></i></a></td></tr>');
				}
				$('[data-toggle="tooltip"]').tooltip();
			}else{
				get_call_history.empty();
				get_call_history.append('<tr><td colspan="3" class="text-center">Not '+type+' Call </tr></td>');
			}
			$('.loader').hide();
		},
		error: function(jqXHR, textStatus, errorThrown) {
			$('.loader').hide(); 
		}			
	});
}

function logout(){
	
	chrome.runtime.sendMessage({ initContextMenusMessage: "initContextMenusMessage","status":0}, function (response) {
		if (!chrome.runtime.lastError) {
			// if you have any response
		}
	});
			
	chrome.tabs.query({ url: "<all_urls>" }, function(tabs)
	{
		for(var i = 0; i < tabs.length; i++)
		{
			chrome.tabs.sendMessage(tabs[i].id, {"logoclicktocallMessage":"logoclicktocallMessage","status":0}, function (response) {
				if (!chrome.runtime.lastError) {
					// if you have any response
				}
			});
			chrome.tabs.sendMessage(tabs[i].id, {"status":0,"CalltellinkMessage":"CalltellinkMessage"}, function (response) {
				if (!chrome.runtime.lastError) {
					// if you have any response
				}
			});
		} 
	});
	
	window.location.href = 'login.html';
}


function integrations_fun(base_url,user_id,integrations,company_name){
	$.ajax({ url: base_url+"/action.php",
		data: {"user_id":user_id,"action":"set_integrations","integrations":integrations},
		dataType:'JSON',
		method: 'POST',
		beforeSend: function() {

		},
		success: function(obj, textStatus, jqXHR) {
			$('#integrations').val(integrations);
			$('select').select2({
				minimumResultsForSearch: -1
			});
			chrome.storage.local.set({'integrations':integrations});
			notification(company_name,'App updated successfully.');
		},
		error: function(jqXHR, textStatus, errorThrown) {
			notification(company_name,'App not updated.');
		}			
	});
}

function websoket_presence(){
	
	chrome.storage.local.get(['user_id','server','user','domain','access_token','websocket_url'], function (result) {
		if(result.user_id != undefined && result.user_id != null) {
			
			var request_presence_data = {
			  domain: result.domain,
			  type: 'presence',
			  'bearer': result.access_token
			};

			var socket = io.connect(result.websocket_url, {
			  secure: true
			});

			socket.on('connect', function() {
			  console.log("status", 'socket connected');
			  socket.emit('subscribe', request_presence_data);
			});

			socket.on('connect_error', function(err) {
			  console.log("status", 'connect_error');
			  console.log("status", err);
			});

			socket.on('error', function(err) {
			  console.log("status", 'error');
			  console.log("status", err);
			});

			socket.on('presence', function(data) {
				
			  //console.log(data);
			  
			  if (typeof data == "object"){
				  
					//var domain = data.domain;
					//var firstname = data.firstname;
					//var lastname = data.lastname;
					//var portal_status = data.portal_status;
					var presence = data.presence;
					var user = data.user;
					
					if(presence == 'alerting' || presence == 'held-private'  || presence == 'progressing' ||  presence == 'inuse'){
						$('#signal_'+user).css('color','RED');
					}
					if(presence == 'inactive'){
						$('#signal_'+user).css('color','GRAY');
					}
					if(presence == 'open'){
						$('#signal_'+user).css('color','GREEN');
					}
			  }
			  
			});
		}
	});
}
function presence(base_url,user_id,loader){
	var presence = $('#presence');
	$.ajax({ url: base_url+"/action.php",
		data: {"user_id":user_id,"action":"presence"},
		dataType:'JSON',
		method: 'POST',
		beforeSend: function() {
			if(loader == 1){
				$('.loader').show();
			}
		},
		success:function(data, textStatus, jqXHR) {
			if(data.length > 0){
				presence.empty();
				for(var i=0;i<data.length;i++){
					presence.append('<tr><td>'+data[i].presence+'&nbsp;'+data[i].first_name+'&nbsp;'+data[i].last_name+'</td><td class="text-right"><a href="#"><i class="fa fa-phone fa-2x text-success calling" data-toggle="tooltip" title="" aria-hidden="true" data-original-title="'+data[i].user+'"></i></a></td></tr>');
				}
				$('[data-toggle="tooltip"]').tooltip();
			}else{
				presence.empty();
				presence.append('<tr><td colspan="2" class="text-center">No Directory</tr></td>');
			}
			$('.loader').hide();
		},
		error: function(jqXHR, textStatus, errorThrown) {
			$('.loader').hide(); 
		}			
	});
} 