# Theme Inverter Chrome Extension

## Overview

The **Theme Inverter** is a Chrome extension designed to enhance the readability of web content by inverting the colors of web pages. This extension allows users to toggle between light and dark themes, making it easier to read text and view content in various lighting conditions.

## Features

- **Toggle Inversion**: Easily switch between inverted and normal color themes with a simple toggle switch in the popup.
- **Hue Adjustment**: Adjust the hue of the inverted colors using a range slider, allowing for a more personalized viewing experience.
- **Domain-Specific Settings**: The extension remembers the inversion state and hue settings for each domain, ensuring a consistent experience across visits.
- **Media Inversion**: Media files such as images, videos, etc., are not quite perfect, but they are mostly preserved.

## Installation

1. Download or clone the repository to your local machine.
2. Open Chrome and navigate to `chrome://extensions/`.
3. Enable "Developer mode" by toggling the switch in the top right corner.
4. Click on "Load unpacked" and select the directory where the extension files are located.
5. The Theme Inverter extension should now be installed and visible in your extensions list.

## Usage

1. Click on the Theme Inverter icon in the Chrome toolbar to open the popup.
2. Use the toggle switch to enable or disable the color inversion.
3. Adjust the hue using the range slider to customize the appearance of the inverted colors.
4. The extension will remember your settings for each domain, so you can enjoy a consistent experience across different websites.

## Contributing

Contributions are welcome! If you have suggestions for improvements or new features, please open an issue or submit a pull request.