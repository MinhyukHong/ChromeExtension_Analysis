let isInverted = false;
let lastHueRotate = 158; // Default value, approximately 88%

function updateUI(isInverted, hueRotate) {
	const toggleElement = document.getElementById('toggle');
	const sliderElement = document.getElementById('slider');

	toggleElement.checked = isInverted;

	if (isInverted) {
		sliderElement.value = hueRotate;
		sliderElement.disabled = false;
		lastHueRotate = hueRotate;
	} else {
		sliderElement.value = 0;
		sliderElement.disabled = true;
	}

	updatePercentage(isInverted ? hueRotate : 0);
}

function updatePercentage(hueRotate) {
	const percentage = (hueRotate / 180 * 100).toFixed(2);
	document.getElementById('percentage').textContent = `${percentage}%`;
}

function saveState(tabId, state) {
	chrome.storage.local.set({ [tabId]: state });
}

document.addEventListener('DOMContentLoaded', () => {
	chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
		if (tabs.length > 0) {
			chrome.runtime.sendMessage({ action: 'getDomainState', url: tabs[0].url }, (response) => {
				console.log('Received domain state:', response); // Debugging log
				isInverted = response.isInverted;
				lastHueRotate = response.hueRotate;
				updateUI(isInverted, lastHueRotate);
			});
		}
	});
});

document.getElementById('toggle').addEventListener('change', (event) => {
	isInverted = event.target.checked;
	const hueRotate = isInverted ? lastHueRotate : 0;
	updateInversion(isInverted, hueRotate);
});

document.getElementById('slider').addEventListener('input', (event) => {
	const hueRotate = parseInt(event.target.value);
	lastHueRotate = hueRotate;
	updatePercentage(hueRotate);
	if (isInverted) {
		updateInversion(isInverted, hueRotate);
	}
});

function updateInversion(isInverted, hueRotate) {
	chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
		if (tabs.length > 0) {
			try {
				const domain = new URL(tabs[0].url).hostname;
				chrome.runtime.sendMessage({
					action: 'updateInvertedDomains',
					url: tabs[0].url,
					isInverted,
					hueRotate
				}, (response) => {
					if (response && response.success) {
						updateUI(isInverted, hueRotate);
					} else {
						console.error('Failed to update inversion:', response.error);
					}
				});
			} catch (e) {
				console.error('Invalid URL:', tabs[0].url);
			}
		}
	});
}

console.log('Popup script loaded');