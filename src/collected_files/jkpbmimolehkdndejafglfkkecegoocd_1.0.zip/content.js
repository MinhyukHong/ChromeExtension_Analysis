function applyInvert(isInverted, hueRotate) {
	const invertPercentage = isInverted ? (hueRotate / 180) * 100 : 0;
	const styles = `
    html {
      filter: invert(${invertPercentage}%) hue-rotate(${hueRotate}deg);
      background-color: ${isInverted ? '#fff' : ''} !important;
    }
    img, video, [style*="url("], image, iframe {
      filter: invert(${invertPercentage}%) hue-rotate(-${hueRotate}deg) !important;
    }
  `;

	let styleElement = document.getElementById('invert-styles');
	if (!styleElement) {
		styleElement = document.createElement('style');
		styleElement.id = 'invert-styles';
		document.head.appendChild(styleElement);
	}
	styleElement.textContent = isInverted ? styles : '';
}

function removeInvert() {
	const styleElement = document.getElementById('invert-styles');
	if (styleElement) {
		styleElement.textContent = '';
	}
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	if (request.action === 'updateInvert') {
		if (request.isInverted) {
			applyInvert(request.isInverted, request.hueRotate);
		} else {
			removeInvert();
		}
		sendResponse({ status: 'Inversion updated' });
	}
	return true; // Indicates that the response will be sent asynchronously
});

// Check initial state when the page loads
chrome.runtime.sendMessage({
	action: 'getDomainState',
	url: window.location.href
}, (response) => {
	if (response && response.isInverted) {
		applyInvert(response.isInverted, response.hueRotate);
	}
});
