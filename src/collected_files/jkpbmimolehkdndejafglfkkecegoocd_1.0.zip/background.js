// Store inverted domains
let invertedDomains = {};

// Load inverted domains from storage
chrome.storage.local.get('invertedDomains', (result) => {
    if (result.invertedDomains) {
        invertedDomains = result.invertedDomains;
    }
});

// Listen for tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        const domain = new URL(tab.url).hostname;
        if (invertedDomains[domain]) {
            chrome.tabs.sendMessage(tabId, {
                action: 'updateInvert',
                isInverted: true,
                hueRotate: invertedDomains[domain].hueRotate
            });
        }
    }
});

// Listen for messages from popup or content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'updateInvertedDomains') {
        const domain = getDomainFromUrl(request.url);
        if (!domain) {
            sendResponse({ success: false, error: 'Invalid URL' });
            return true;
        }
        const { isInverted, hueRotate } = request;
        if (isInverted) {
            invertedDomains[domain] = { isInverted, hueRotate };
        } else {
            delete invertedDomains[domain];
        }
        chrome.storage.local.set({ invertedDomains });
        updateAllTabsForDomain(domain, isInverted, hueRotate);
        sendResponse({ success: true });
    } else if (request.action === 'getDomainState') {
        const domain = getDomainFromUrl(request.url);
        if (!domain) {
            sendResponse({ isInverted: false, hueRotate: 158 });
            return true;
        }
        const state = invertedDomains[domain] || { isInverted: false, hueRotate: 158 };
        sendResponse(state);
    }
    return true; // Indicates that the response will be sent asynchronously
});

function getDomainFromUrl(url) {
    try {
        return new URL(url).hostname;
    } catch (e) {
        console.log('Invalid URL:', url);
        return null;
    }
}

function updateAllTabsForDomain(domain, isInverted, hueRotate) {
    if (!domain) return;
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
            const tabDomain = getDomainFromUrl(tab.url);
            if (tabDomain === domain) {
                chrome.tabs.sendMessage(tab.id, {
                    action: 'updateInvert',
                    isInverted,
                    hueRotate
                }).catch(err => console.log('Error sending message to tab:', err));
            }
        });
    });
}

chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        const domain = getDomainFromUrl(tab.url);
        if (domain && invertedDomains[domain]) {
            chrome.tabs.sendMessage(tab.id, {
                action: 'updateInvert',
                isInverted: true,
                hueRotate: invertedDomains[domain].hueRotate
            }).catch(err => console.log('Error sending message to tab:', err));
        }
    });
});