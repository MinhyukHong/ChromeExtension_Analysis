importScripts('./js/common.js', './js/jszip.js', 'js/filesave.js', 'js/xlsx.js');








chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    switch (message.cmd) {
        case 'get_asin':
            var marketplace_id = message.params.marketplace_id;
            var tab_id = message.params.tab_id;
            var asin_list = message.params.asin_list;
            var http = message.params.http;
            get_all_asin(tab_id, asin_list, marketplace_id, http);

        default:
            break
    }
})


async function get_all_asin(tab_id, asin_list, marketplace_id, http) {
    send_content_message(tab_id, { 'msg': '开始获取asin_list中asin的数据', 'msg_type': 'success' }, 'show_msg');
    var all_asin = await get_all_asin_data(tab_id, asin_list, marketplace_id);
    all_asin = [...new Set(all_asin)];
    send_content_message(tab_id, { 'asin_list': all_asin, 'http': http, 'marketplace_id': marketplace_id, 'tab_id': tab_id }, 'search_title_l_d');


}

async function get_all_asin_data(tab_id, asin_list, marketplace_id) {

    var all_asin = [];
    var http_asin = get_marketplace_id(marketplace_id);

    var data_leng = asin_list.length;
    for (let i = 0; i < data_leng; i++) {
        send_content_message(tab_id, { 'msg': '开始获取' + asin_list[i] + '--->' + data_leng + '->' + (i + 1) + '的数据', 'msg_type': 'success' }, 'show_msg');
        var url = http_asin + asin_list[i];
        var temp_data = await getAsinList(url);
        if (temp_data == -1) {
            send_content_message(tab_id, { 'msg': '获取失败' + asin_list[i] + '--->' + data_leng + '->' + (i + 1) + '的数据', 'msg_type': 'error' }, 'show_msg');
        } else {
            all_asin = all_asin.concat(temp_data);
            send_content_message(tab_id, { 'msg': '获取成功' + asin_list[i] + '--->' + data_leng + '->' + (i + 1) + '的数据', 'msg_type': 'success' }, 'show_msg');
        }


    }

    return all_asin;



}











