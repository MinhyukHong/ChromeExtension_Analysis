// console.log("this is content.js");
// console.log(document);
// console.log(location);



chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
	// console.log('监听content.js', message)

	switch (message.cmd) {
		case 'voice':
			var seller_id = message.params.seller_id;
			var marketplace_id = message.params.marketplace_id;
			var http = message.params.http;
			var tab_id = message.params.tab_id;
			var start_date = message.params.start_date;
			var end_date = message.params.end_date;
			var date_list = getMonthRange(start_date, end_date);
			console.log(date_list);
			download_voice(seller_id, marketplace_id, date_list, http, tab_id, start_date, end_date);
			break;
		case 'show_msg':
			var msg = message.params.msg;
			var msg_type = message.params.msg_type;
			// console.log(msg, msg_type)
			show_msg(msg_type, msg);
			break;
		case 'search_title':
			var http = message.params.http;
			var asin_list = message.params.asin;
			var down_type = message.params.down_type;
			var marketplace_id = message.params.marketplace_id;
			var tab_id = message.params.tab_id;
			download_search_title(http, asin_list, down_type, marketplace_id, tab_id);
			break
		case 'search_title_l_d':
			var http = message.params.http;
			var asin_list = message.params.asin_list;
			var marketplace_id = message.params.marketplace_id;
			var tab_id = message.params.tab_id;
			var down_type = 'search_title'

			download_search_title(http, asin_list, down_type, marketplace_id, tab_id);
			console.log(message.cmd)
			console.log(asin_list);
			console.log(http);
			break

	}
})


//买家之声
function download_voice(seller_id, marketplace_id, date_list, http, tab_id, start_date, end_date) {
	download_voice_data(seller_id, marketplace_id, date_list, http, tab_id, start_date, end_date);
}

//子标题搜索
function download_search_title(http, asin_list, down_type, marketplace_id, tab_id) {
	if (down_type === 'search_title') {
		download_search_title_data(http, asin_list);
	}
	else {
		console.log(111111,tab_id);
		send_background_message({ 'tab_id': tab_id, 'asin_list': asin_list, 'marketplace_id': marketplace_id, 'http': http }, 'get_asin')

	}

}































