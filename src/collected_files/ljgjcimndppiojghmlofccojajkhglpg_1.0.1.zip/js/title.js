async function download_search_title_data(http, asin_list) {


	var result = [];
	var data_leng = asin_list.length;
	for (let i = 0; i < data_leng; i++) {

		var temp_data = await download_search_title_data_detail(http, asin_list[i], data_leng, i);
		console.log(temp_data);
		result = result.concat(temp_data);

	}


	var file_name = "标题数据-" + new Date().getTime() + '.xlsx';
	var download_data = { 'file_name': file_name, 'data': result }
	download_xlsx(download_data);

	console.log(result);




}



async function download_search_title_data_detail(http, asin, data_leng, i) {
	show_msg('success', '开始' + data_leng + '->' + i + '   ' + asin + '---->的数据');
	let return_data = [];
	let page_url = "/abis/ajax/reconciledDetailsV2?asin=" + asin;

	let home_p = new Promise((resolve, reject) => {
		$.ajax({
			type: 'GET',
			url: page_url,
			followRedirects: true,
			success: function (resp_data) {
				try {

					// resp_data = JSON.parse(resp_data);
					resp = resp_data['detailPageListingResponse'];
					var newObject = {"asin": asin,'code':'成功'};

					for (const key in resp) {
						const item = resp[key];
						// const displayLabel = item.displayLabel.length > 0 ? item.displayLabel : key;
						if (item.hasOwnProperty("value") && item.value !== "") {
							newObject[key] = item.value;
						}
						// newObject[key] = item.value;
					}
					resolve([newObject]);
				} catch (e) {
					show_msg('error', "解析数据" + asin + "--->数据失败");

					resolve([
						{ 'asin': asin, 'code': "解析错误" }
					])
				}
			},
			error: function (err) {
				console.log('发生了错误，错误的原因为', err)


				show_msg('error', "获取数据" + asin + "--->数据失败");
				resolve([
					{ 'asin': asin, 'code': "发送请求错误" }
				]);
			}
		}).fail(function () {
			show_msg('error', "发送请求" + asin + "--->数据失败");
			resolve([])
		})

	}).then(res => {
		return_data = res;
	})




	await home_p;






	return return_data;




}




async function download_search_title_data_detail_old(http, asin, data_leng, i) {
	show_msg('success', '开始' + data_leng + '->' + i + '   ' + asin + '---->的数据');
	let return_data = [];
	let page_url = "/abis/ajax/reconciledDetailsV2?asin=" + asin;

	let home_p = new Promise((resolve, reject) => {
		$.ajax({
			type: 'GET',
			url: page_url,
			followRedirects: true,
			success: function (resp_data) {
				try {

					// resp_data = JSON.parse(resp_data);
					resp = resp_data['detailPageListingResponse'];
					// var brand = resp['brand#1.value'] ? resp['brand#1.value']['value'] : '';
					// var item_name = resp['item_name#1.value'] ? resp['item_name#1.value']['value'] : '';
					var occasion_type = resp['occasion_type#1.value'] ? resp['occasion_type#1.value']['value'] : '';
					var material_type = resp['material#1.value'] ? resp['material#1.value']['value'] : '';


					var subject_character = resp['subject_character#1.value'] ? resp['subject_character#1.value']['value'] : '';
					// var shirt_height_type = resp['shirt_size#1.height_type'] ? resp['shirt_size#1.height_type']['value'] : '';
					// var shirt_body_type = resp['shirt_body_type'] ? resp['shirt_body_type']['value'] : '';


					var package_length = resp['item_package_dimensions#1.length.value'] ? resp['item_package_dimensions#1.length.value']['value'] : '';
					var package_length_unit_of_measure = resp['item_package_dimensions#1.length.unit'] ? resp['item_package_dimensions#1.length.unit']['value'] : '';
					package_length = package_length + "  " + package_length_unit_of_measure;
					package_length = package_length.trim();
					if (package_length.length <= 0) {
						package_length = resp['package_length'] ? resp['package_length']['value'] : '';
						package_length_unit_of_measure = resp['package_length_unit_of_measure'] ? resp['package_length_unit_of_measure']['value'] : '';
						package_length = package_length + "  " + package_length_unit_of_measure;
						package_length = package_length.trim();

					}

					var package_width = resp['item_package_dimensions#1.width.value'] ? resp['item_package_dimensions#1.width.value']['value'] : '';
					var package_width_unit_of_measure = resp['item_package_dimensions#1.width.unit'] ? resp['item_package_dimensions#1.width.unit']['value'] : '';
					package_width = package_width + "  " + package_width_unit_of_measure;
					package_width = package_width.trim();
					if (package_width.length <= 0) {
						package_width = resp['package_width'] ? resp['package_width']['value'] : '';
						package_width_unit_of_measure = resp['package_width_unit_of_measure'] ? resp['package_width_unit_of_measure']['value'] : '';
						package_width = package_width + "  " + package_width_unit_of_measure;
						package_width = package_width.trim();

					}

					var package_height = resp['item_package_dimensions#1.height.value'] ? resp['item_package_dimensions#1.height.value']['value'] : '';
					var package_height_unit_of_measure = resp['item_package_dimensions#1.height.unit'] ? resp['item_package_dimensions#1.height.unit']['value'] : '';
					package_height = package_height + "  " + package_height_unit_of_measure;
					package_height = package_height.trim();
					if (package_height.length <= 0) {
						package_height = resp['package_height'] ? resp['package_height']['value'] : '';
						package_height_unit_of_measure = resp['package_height_unit_of_measure'] ? resp['package_height_unit_of_measure']['value'] : '';
						package_height = package_height + "  " + package_height_unit_of_measure;
						package_height = package_height.trim();

					}


					var package_weight = resp['item_package_weight#1.value'] ? resp['item_package_weight#1.value']['value'] : '';
					var package_weight_unit_of_measure = resp['item_package_weight#1.unit'] ? resp['item_package_weight#1.unit']['value'] : '';
					package_weight = package_weight + "  " + package_weight_unit_of_measure;
					package_weight = package_weight.trim();
					if (package_weight.length <= 0) {
						package_weight = resp['package_weight'] ? resp['package_weight']['value'] : '';
						package_weight_unit_of_measure = resp['package_weight_unit_of_measure'] ? resp['package_weight_unit_of_measure']['value'] : '';
						package_weight = package_weight + "  " + package_weight_unit_of_measure;
						package_weight = package_weight.trim();

					}





					var import_designation = resp['import_designation#1.value'] ? resp['import_designation#1.value']['value'] : '';
					var model_name = resp['model_name#1.value'] ? resp['model_name#1.value']['value'] : '';
					var special_features = resp['special_feature#1.value'] ? resp['special_feature#1.value']['value'] : '';
					var closure_type = resp['closure#1.type#1.value'] ? resp['closure#1.type#1.value']['value'] : '';
					var back_style = resp['back#1.style#1.value'] ? resp['back#1.style#1.value']['value'] : '';
					var pocket_description = resp['pocket_description#1.value'] ? resp['pocket_description#1.value']['value'] : '';
					var specific_uses_for_product = resp['specific_uses_for_product#1.value'] ? resp['specific_uses_for_product#1.value']['value'] : '';
					var theme = resp['theme#1.value'] ? resp['theme#1.value']['value'] : '';
					var sport_type = resp['sport_type#1.value'] ? resp['sport_type#1.value']['value'] : '';
					var top_style = resp['top_style#1.value'] ? resp['top_style#1.value']['value'] : '';
					var pattern = resp['pattern#1.value'] ? resp['pattern#1.value']['value'] : '';
					var neck_style = resp['neck#1.neck_style#1.value'] ? resp['neck#1.neck_style#1.value']['value'] : '';
					var style_name = resp['style#1.value'] ? resp['style#1.value']['value'] : '';
					var sleeve_type = resp['sleeve#1.type#1.value'] ? resp['sleeve#1.type#1.value']['value'] : '';
					var fit_type = resp['fit_type#1.value'] ? resp['fit_type#1.value']['value'] : '';
					var collar_style = resp['collar_style#1.value'] ? resp['collar_style#1.value']['value'] : '';

					var item_type = resp['item_type_keyword#1.value'] ? resp['item_type_keyword#1.value']['value'] : '';
					var lifestyle = resp['lifestyle#1.value'] ? resp['lifestyle#1.value']['value'] : '';
					var color_name = resp['color#1.value'] ? resp['color#1.value']['value'] : '';
					// var size_name = resp['shirt_size#1.size'] ? resp['shirt_size#1.size']['value'] : '';

					var result = { 'asin': asin, 'code': 1 };

					result['color_name'] = color_name;


					// 先找size_name
					for (const key in resp) {
						if (key.endsWith(".size")) {
							const displayLabel = resp[key].displayLabel;
							const value = resp[key].value;
							result["size_name"] = value;
						}
					}
					
					//其他后面，保证size_name-color_name需要在其他的后面
					for (const key in resp) {
						if (key.endsWith(".body_type")) {
							const displayLabel = resp[key].displayLabel;
							const value = resp[key].value;
							result["body_type"] = value;
						}

						if (key.endsWith(".height_type")) {
							const displayLabel = resp[key].displayLabel;
							const value = resp[key].value;
							result["height_type"] = value;
						}

						if (key.startsWith("brand")) {
							const displayLabel = resp[key].displayLabel;
							const value = resp[key].value;
							result["brand_name"] = value;
						}

						if (key.startsWith("item_name")) {
							const displayLabel = resp[key].displayLabel;
							const value = resp[key].value;
							result["item_name"] = value;
						}
					}
					// result['size_name'] = size_name;
					// result['brand'] = brand;
					// result['item_name'] = item_name;
					result['occasion_type'] = occasion_type;
					result['material_type'] = material_type;
					result['subject_character'] = subject_character;
					// result['shirt_height_type'] = shirt_height_type;
					// result['shirt_body_type'] = shirt_body_type;
					result['package_length'] = package_length;
					result['package_width'] = package_width;
					result['package_height'] = package_height;
					result['package_weight'] = package_weight;
					result['import_designation'] = import_designation;
					result['model_name'] = model_name;
					result['special_features'] = special_features;
					result['closure_type'] = closure_type;
					result['back_style'] = back_style;
					result['pocket_description'] = pocket_description;
					result['specific_uses_for_product'] = specific_uses_for_product;
					result['theme'] = theme;
					result['sport_type'] = sport_type;
					result['top_style'] = top_style;
					result['pattern'] = pattern;
					result['neck_style'] = neck_style;
					result['style_name'] = style_name;
					result['sleeve_type'] = sleeve_type;
					result['fit_type'] = fit_type;
					result['collar_style'] = collar_style;
					result['item_type'] = item_type;
					result['lifestyle'] = lifestyle;

					var result_1 = [];
					result_1.push(result);









					// var result = [
					// 	{
					// 		"asin": asin,
					// 		"color_name": color_name,
					// 		"size_name": size_name,
					// 		"brand": brand,
					// 		"item_name": item_name,
					// 		"ossasion_type": occasion_type,
					// 		"material_type": material_type,
					// 		"subject_character": subject_character,
					// 		"shirt_height_type": shirt_height_type,
					// 		"shirt_body_type": shirt_body_type,
					// 		"package_length": package_length,
					// 		"package_width": package_width,
					// 		"package_height": package_height,
					// 		"package_weight": package_width,
					// 		"import_designation": import_designation,
					// 		"model_name": model_name,
					// 		"special_features": special_features,
					// 		"closure_type": closure_type,
					// 		"back_style": back_style,
					// 		"pocket_description": pocket_description,
					// 		"specific_use_for_product": specific_uses_for_product,
					// 		"theme": theme,
					// 		"sport_type": sport_type,
					// 		"top_style": top_style,
					// 		"pattern": pattern,
					// 		"neck_style": neck_style,
					// 		"style_name": style_name,
					// 		"sleeve_type": sleeve_type,
					// 		"fit_type": fit_type,
					// 		"collar_style": collar_style,
					// 		"item_type": item_type,
					// 		"lifestyle": lifestyle
					// 	}
					// ]




					resolve(result_1);
				} catch (e) {
					show_msg('error', "解析数据" + asin + "--->数据失败");

					resolve([])
				}
			},
			error: function (err) {
				console.log('发生了错误，错误的原因为', err)


				show_msg('error', "获取数据" + asin + "--->数据失败");
				resolve([]);
			}
		}).fail(function () {
			show_msg('error', "发送请求" + asin + "--->数据失败");
			resolve([])
		})

	}).then(res => {
		return_data = res;
	})




	await home_p;




	if (return_data.length <= 0) {
		return_data = [
			// {
			// 	"asin": asin,
			// 	"color_name": -1,
			// 	"size_name": -1,
			// 	"brand": -1,
			// 	"item_name": -1,
			// 	"ossasion_type": -1,
			// 	"material_type": -1,
			// 	"subject_character": -1,
			// 	"shirt_height_type": -1,
			// 	"shirt_body_type": -1,
			// 	"package_length": -1,
			// 	"package_width": -1,
			// 	"package_height": -1,
			// 	"package_weight": -1,
			// 	"import_designation": -1,
			// 	"model_name": -1,
			// 	"special_features": -1,
			// 	"closure_type": -1,
			// 	"back_style": -1,
			// 	"pocket_description": -1,
			// 	"specific_use_for_product": -1,
			// 	"theme": -1,
			// 	"sport_type": -1,
			// 	"top_style": -1,
			// 	"pattern": -1,
			// 	"neck_style": -1,
			// 	"style_name": -1,
			// 	"sleeve_type": -1,
			// 	"fit_type": -1,
			// 	"collar_style": -1,
			// 	"item_type": -1,
			// 	"lifestyle": -1
			// }
			{ 'asin': asin, 'code': -1 }
		];

	}

	return return_data;




}
