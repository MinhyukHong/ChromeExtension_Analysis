async function download_voice_data(seller_id, marketplace_id, date_list, http, tab_id, start_date, end_date) {

	let total_page = await get_voice_data();
	total_page = total_page['totalListingsCount'];
	total_page = Math.ceil(total_page / 25);



	show_msg('success', '总共找到了' + total_page + '页');

	var total_data = [];
	var total_result = [];

	for (let i = 0; i < total_page; i++) {


		show_msg('success', '开始找第' + total_page + '---->' + (i + 1) + '页数据');

		var temp_data = await get_voice_data(i);
		temp_data = temp_data['pcrListings']; i
		if (temp_data.length <= 0) {
			console
		}
		total_data = total_data.concat(temp_data);

		await sleep(Math.floor(Math.random() * (1001 - 800)) + 800);


	}





	var data_leng = total_data.length;

	for (let i = 0; i < total_data.length; i++) {

		for (let j = 0; j < date_list.length; j++) {
			var firstDay = date_list[j]['firstDay'];
			var lastDay = date_list[j]['lastDay'];
			var temp_data_ = await get_voice_data_detail(total_data[i], firstDay, lastDay, seller_id, marketplace_id, data_leng, i);


			total_result = total_result.concat(temp_data_);
			await sleep(Math.floor(Math.random() * (1001 - 800)) + 800);

		}


	}
	var file_name = seller_id + '-' + marketplace_id + '--' + start_date + "~" + end_date + '.xlsx';
	var download_data = { 'file_name': file_name, 'sheet1_data': total_data, 'sheet2_data': total_result }

	download_two_sheet_xlsx(download_data)



}





async function get_voice_data(page = 0) {

	let return_data = { "totalListingsCount": 0, "pcrListings": [] }
	var page_url = "/pcrHealth/pcrListingSummary?searchText=&pageSize=25&pageOffset=" + 25 * page + "&sortColumn=ORDERS_COUNT&sortDirection=DESCENDING&insufficientFeedback=false"
	let home_p = new Promise((resolve, reject) => {
		$.ajax({
			type: 'GET',
			url: page_url,
			followRedirects: true,
			success: function (resp_data) {
				try {

					resolve(resp_data);
				} catch (e) {
					show_msg('error', '解析首页数据第' + (page + 1) + '页失败');

					resolve({ "totalListingsCount": 0, "pcrListings": [] })
				}
			},
			error: function (err) {
				console.log('发生了错误，错误的原因为', err)


				show_msg('error', '获取首页数据第' + (page + 1) + '页失败');
				resolve({ "totalListingsCount": 0, "pcrListings": [] })
			}
		})

	}).then(res => {
		return_data = res;
	})

	await home_p;

	return return_data
}




async function get_voice_data_detail(item, start_date, end_date, seller_id, marketplace_id, data_leng, i) {

	var asin = item['asin'];
	var fnsku = item['fnsku'];
	var sku = item['mskus'];


	show_msg('success', '开始' + data_leng + '->' + i + '   ' + fnsku  + '-' + asin + '---->' + start_date + "~" + end_date + '的数据');




	let return_data = [];
	var page_url = "/feedback/getAsinFeedbackV2?value=" + fnsku + "&type=FNSKU&asin=" + asin + "&fromDate=" + start_date + "&toDate=" + end_date;
	let home_p = new Promise((resolve, reject) => {
		$.ajax({
			type: 'GET',
			url: page_url,
			followRedirects: true,
			success: function (resp_data) {
				try {
					resolve(resp_data);
				} catch (e) {
					show_msg('error', "解析数据" + fnsku + "--->" + asin + "--->" + start_date + "~" + end_date + "失败");

					resolve({ "returnComments": [], "customerComplaintSummaries": [] })
				}
			},
			error: function (err) {
				console.log('发生了错误，错误的原因为', err)


				show_msg('error', "获取数据" + fnsku + "--->" + asin + "--->" + start_date + "~" + end_date + "失败");
				resolve({ "returnComments": [], "customerComplaintSummaries": [] });
			}
		}).fail(function () {
			show_msg('error', "获取数据发送请求" + fnsku + "--->" + asin + "--->" + start_date + "~" + end_date + "失败");
			resolve({ "returnComments": [], "customerComplaintSummaries": [] })
		})

	}).then(res => {
		return_data = res;
	})

	await home_p;

	var return_result = [];
	var customer = return_data['customerComplaintSummaries'];
	var r_comments = return_data['returnComments']

	if (customer.length > 0) {
		for (let i = 0; i < customer.length; i++) {
			var item = customer[i]
			var order_id = item['orderId'];
			var desc = item['customerComplaintSummary'];
			var time_ = item['orderDay'];

			return_result.push(
				{
					"seller_id": seller_id,
					"marketplace_id": marketplace_id,
					"sku": sku,
					"asin": "",
					"类别": "其他",
					"order_id": order_id,
					"desc": desc,
					'ymd': time_.substring(0, 10),
					"date": time_,

				}
			)

		}
	}

	if (r_comments.length > 0) {
		for (let i = 0; i < r_comments.length; i++) {
			var item = r_comments[i]
			var order_id = item['orderId'];
			var desc = item['comment'];
			var time_ = item['timestamp'];
			var asin = item['asin'];

			return_result.push(
				{
					"seller_id": seller_id,
					"marketplace_id": marketplace_id,
					"sku": sku,
					"asin": asin,
					"类别": "买家",
					"order_id": order_id,
					"desc": desc,
					'ymd': time_.substring(0, 10),
					"date": time_,

				}
			)

		}
	}

	return return_result;
}




















