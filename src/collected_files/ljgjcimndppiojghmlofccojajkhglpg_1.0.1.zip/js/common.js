function show_msg(type, msg) {
  switch (type) {
    case 'success':
      Message.run(msg);
      break;
    case 'error':
      Message.run(msg, "error", 10000);
    case 'process':
      Message.run(msg, "success", 1000);

    default:
      break

  }

}


function send_background_message(data, type) {
  chrome.runtime.sendMessage({
    recipient: 'background',
    cmd: type,
    params: data
  })
}

function send_content_message(tab_id, data, type) {
  chrome.tabs.sendMessage(tab_id, {
    recipient: 'content',
    cmd: type,
    params: data
  })
}






// 发送post数据
function post(url, data, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("post", url, true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4) {
      // defensive check
      if (typeof callback === "function") {
        // apply() sets the meaning of "this" in the callback
        callback.apply(xhr);
      }
    }
  };
  xhr.send(new URLSearchParams(data));
}





// 发送get数据
function get(url, data, callback) {
  var xhr = new XMLHttpRequest();
  xhr.open("get", url, true);
  xhr.onreadystatechange = function () {
    if (xhr.readyState == 4) {
      // defensive checkconsole.log(xhr.readySate)
      if (typeof callback === "function") {
        // apply() sets the meaning of "this" in the callback
        xhr.params_data = data;
        callback.apply(xhr);
      }
    }
  };
  xhr.send();
}








function get_now_time() {
  let date = new Date(),
    obj = {
      year: date.getFullYear(), //获取完整的年份(4位)
      month: date.getMonth() + 1, //获取当前月份(0-11,0代表1月)
      strDate: date.getDate(), // 获取当前日(1-31)
      hour: date.getHours(), //获取当前小时(0 ~ 23)
      minute: date.getMinutes(), //获取当前分钟(0 ~ 59)
      second: date.getSeconds() //获取当前秒数(0 ~ 59)
    };

  Object.keys(obj).forEach(key => {
    if (obj[key] < 10) obj[key] = `0${obj[key]}`
    // console.log(obj[key])
  });

  return `${obj.year}-${obj.month}-${obj.strDate}  ${obj.hour}~${obj.minute}~${obj.second}`

}


function getDaysDifference(startDate, endDate) {
  // 将日期字符串转换为 Date 对象
  var start = new Date(startDate);
  var end = new Date(endDate);

  // 计算时间差（以毫秒为单位）
  var timeDiff = Math.abs(end - start);

  // 将时间差转换为天数
  var daysDiff = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

  return daysDiff;
}


// function getMonthRange(startDate, endDate) {
//     var start = new Date(startDate);
//     var end = new Date(endDate);
//     var result = [];

//     while (start <= end) {
//       var firstDay = new Date(start.getFullYear(), start.getMonth(), 1);
//       var lastDay = new Date(start.getFullYear(), start.getMonth() + 1, 0);

//       var monthRange = {
//         firstDay: formatDate(firstDay),
//         lastDay: formatDate(lastDay)
//       };

//       result.push(monthRange);

//       start.setMonth(start.getMonth() + 1);
//     }

//     return result;
//   }


function getMonthRange(startDate, endDate) {
  var dateList = [];

  var start = new Date(startDate);
  var end = new Date(endDate);

  var numDays = Math.floor((end - start) / (1000 * 60 * 60 * 24)); // 计算日期之间的天数

  if (numDays > 90) {
    var currentDate = new Date(start.getTime());

    while (currentDate <= end) {
      var nextDate = new Date(currentDate.getTime() + (90 * 24 * 60 * 60 * 1000)); // 加上90天
      var segmentEndDate = new Date(nextDate.getTime() - (24 * 60 * 60 * 1000)); // 减去1天作为段的结束日期

      // 如果段的结束日期超过了 end_date，则将结束日期设置为 end_date
      if (segmentEndDate >= end) {
        segmentEndDate = new Date(end.getTime());
      }

      // 格式化日期并添加到数组中
      var monthRange = {
        firstDay: formatDate(currentDate),
        lastDay: formatDate(segmentEndDate)
      };

      dateList.push(monthRange);

      // 更新当前日期为下一个段的起始日期
      currentDate = new Date(nextDate.getTime());
    }
  } else {
    // 少于90天，返回单个日期范围
    var singleRange = {
      firstDay: formatDate(start),
      lastDay: formatDate(end)
    };

    dateList.push(singleRange);
  }

  return dateList;
}



function sleep(time) {
  return new Promise(res => {
    setTimeout(res, time)
  })
}





function getPreviousDate(days) {
  var currentDate = new Date();
  currentDate.setDate(currentDate.getDate() - days);
  var previousDateString = formatDate(currentDate);
  return previousDateString;
}

function formatDate(date) {
  var year = date.getFullYear();
  var month = (date.getMonth() + 1).toString().padStart(2, '0');
  var day = date.getDate().toString().padStart(2, '0');
  return year + '-' + month + '-' + day;
}





function getLastDayOfPreviousMonth() {
  var currentDate = new Date();
  var currentMonth = currentDate.getMonth();
  var currentYear = currentDate.getFullYear();

  // 设置日期为当前月的第一天
  var firstDayOfCurrentMonth = new Date(currentYear, currentMonth, 1);

  // 减去一天，得到上个月的最后一天
  var lastDayOfPreviousMonth = new Date(firstDayOfCurrentMonth.getTime() - 1);

  var lastDayFormatted = formatDate(lastDayOfPreviousMonth);
  return lastDayFormatted;
}



function download_xlsx(args) {
  let file_name = args.file_name;
  let data = args.data;

  const book = XLSX.utils.book_new();
  const sheet = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(book, sheet);
  XLSX.writeFile(book, file_name);

}


function download_two_sheet_xlsx(args) {
  let file_name = args.file_name;
  let data_1 = args.sheet1_data;

  let data_2 = args.sheet2_data;

  const book = XLSX.utils.book_new();
  let sheet1 = XLSX.utils.json_to_sheet(data_1);

  let sheet2 = XLSX.utils.json_to_sheet(data_2);

  XLSX.utils.book_append_sheet(book, sheet1, '数据表');
  XLSX.utils.book_append_sheet(book, sheet2, '数据详情表');
  XLSX.writeFile(book, file_name);

}


function get_marketplace_id(marketplace_id) {
  var http = "";
  switch (marketplace_id) {
    case 'US':
      http = "https://www.amazon.com/dp/";
      break;
    case 'DE':
      http = "https://www.amazon.de/dp/";
      break;
    case 'CA':
      http = "https://www.amazon.ca/dp/";
      break;
    case 'ES':
      http = "https://www.amazon.es/dp/";
      break;
    case 'UK':
      http = "https://www.amazon.uk/dp/";
      break;
    case 'FR':
      http = "https://www.amazon.fr/dp/"


  }
  return http;
}



async function getAsinList(url) {

  let asin_list = await fetch(url).then(resp => resp.text()).then(resp => {
    var resp_text = resp;

    var all_asin_regex = /dimensionToAsinMap.*/;
    try {
      var all_asin_text = resp_text.match(all_asin_regex)[0];
    } catch {
      var all_asin_text = url;
    }
    all_asin_text = all_asin_text + url;
    var regex_token = new RegExp(/(B0[A-Z0-9]{8})/g);
    var asin_result = all_asin_text.match(regex_token);
    asin_result = [...new Set(asin_result)]
    return asin_result;



  }).catch(err => {
    console.log('获取asin_list失败，原因为', err);
    return -1
  })

  return asin_list;

}