//监听消息
console.log('popup.js')
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
	switch (message.cmd) {
		case 'download_finsh':
			break

		default:
			break;
	}
})











// 买家之声
var isShow = false; // 默认div不显示
$('#voice').click(function (e) {
	var box = document.getElementById('box');
	var body = document.getElementById('body_id');

	var end_date = getPreviousDate(2);
	var start_date = getPreviousDate(88);

  // 设置input标签的初始值
  document.getElementById("start_date").value = start_date;
  document.getElementById("end_date").value = end_date;




	if (isShow) {
		box.className = 'hidden'; // 控制div的显示，改变class属性值 class在js中是关键字，不可以作为变量或者属性的名字 用className代替
		body.className = 'first_body'
		isShow = false;
	} else {
		box.className = 'show';
		body.className = 'change_body'
		isShow = true;
	}
})



$("#box").keydown(function (e) {
	var e = e || event;
	if (e.keyCode == 13) {//keyCode=13是回车键

		e.preventDefault ? e.preventDefault() : (e.returnValue = false);
		voice_download('voice');
	}
});



//标题搜索

var isShow_ = false; // 默认div不显示
$('#search_title_div').click(function (e) {
	var box = document.getElementById('search_title');
	var body = document.getElementById('body_id')
	if (isShow_) {
		box.className = 'hidden_'; // 控制div的显示，改变class属性值 class在js中是关键字，不可以作为变量或者属性的名字 用className代替
		body.className = 'first_body'
		isShow_ = false;
	} else {
		box.className = 'show';
		body.className = 'change_body'
		isShow_ = true;
	}
})



$("#search_title").keydown(function (e) {
	var e = e || event;
	if (e.keyCode == 13) {//keyCode=13是回车键
		var asin_data = $("#search_title").val()
		e.preventDefault ? e.preventDefault() : (e.returnValue = false);
		// asin_download('yy_ratings', 'asin', asin_data);
		search_title_download('search_title',asin_data);
	}
});




//标题搜索listing
var isShow_l = false; // 默认div不显示
$('#search_title_l_div').click(function (e) {
	var box = document.getElementById('search_title_l');
	var body = document.getElementById('body_id')
	if (isShow_l) {
		box.className = 'hidden_'; // 控制div的显示，改变class属性值 class在js中是关键字，不可以作为变量或者属性的名字 用className代替
		body.className = 'first_body'
		isShow_ = false;
	} else {
		box.className = 'show';
		body.className = 'change_body'
		isShow_l = true;
	}
})



$("#search_title_l").keydown(function (e) {
	var e = e || event;
	if (e.keyCode == 13) {//keyCode=13是回车键
		var asin_data = $("#search_title_l").val()
		e.preventDefault ? e.preventDefault() : (e.returnValue = false);
		// asin_download('yy_ratings', 'asin', asin_data);
		search_title_download('search_title_l',asin_data);
	}
});







function search_title_download(downType, asin_data)
{

	chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
		let tab = tabs[0]
		let tab_id = tab.id;
		let tab_url = tab.url;

		if (tab_url.match(/amazon.de/)) {
			marketplace_id = 'DE';
			asin_http = "sellercentral.amazon.de";
		} else if (tab_url.match(/amazon.co.uk/)) {
			marketplace_id = 'UK';
			asin_http = "sellercentral.amazon.co.uk";
		} else if (tab_url.match(/amazon.com/)) {
			marketplace_id = "US";
			asin_http = "sellercentral.amazon.com";
		} else if (tab_url.match(/amazon.ca/)) {
			marketplace_id = "CA";
			asin_http = "sellercentral.amazon.ca";
		} else if (tab_url.match(/amazon.fr/)) {
			marketplace_id = "FR";
			asin_http = "sellercentral.amazon.fr";
		} else if (tab_url.match(/amazon.es/)) {
			marketplace_id = "ES";
			asin_http = "sellercentral.amazon.es";
		} else {
			asin_http = "";
			marketplace_id = "";
		}


		var regex_token = new RegExp(/(B0[A-Z0-9]{8})/gm)
		asin_data = asin_data.replace('\n', '');
		asin_data = asin_data.replace(' ', '');
		var t_result = asin_data.match(regex_token);
		t_result = [...new Set(t_result)];

		if (t_result.length<=0)
		{
			alert('未找到asin集合数据');
			return;
		}




		if(asin_http.length <=0){
			alert("未找到sellercentral.amazon.xxxx");
			return;
		}




		alert('开始标题的数据的数据');


		send_content_message(tab_id, {

			'http': asin_http,
			'tab_id': tab_id,
			'down_type': downType,
			"asin":t_result,
			"marketplace_id": marketplace_id
		}, 'search_title')



	});

}


function voice_download(downType) {
	let seller_id = $("#seller_id").val()
	let marketplace_id = ""
	let start_date = $("#start_date").val()
	let end_date = $("#end_date").val()




	chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
		let tab = tabs[0]
		let tab_id = tab.id;
		let tab_url = tab.url;

		if (tab_url.match(/amazon.de/)) {
			marketplace_id = 'DE';
			asin_http = "sellercentral.amazon.com";
		} else if (tab_url.match(/amazon.co.uk/)) {
			marketplace_id = 'UK';
			asin_http = "sellercentral.amazon.com";
		} else if (tab_url.match(/amazon.com/)) {
			marketplace_id = "US";
			asin_http = "sellercentral.amazon.com";
		} else if (tab_url.match(/amazon.ca/)) {
			marketplace_id = "CA";
			asin_http = "sellercentral.amazon.com";
		} else if (tab_url.match(/amazon.fr/)) {
			marketplace_id = "FR";
			asin_http = "sellercentral.amazon.com";
		} else if (tab_url.match(/amazon.es/)) {
			marketplace_id = "ES";
			asin_http = "sellercentral.amazon.com";
		} else {
			marketplace_id = "";
		}

		if (seller_id.length <= 0) {
			alert('没有填写帐号');
			return;
		}

		if (marketplace_id.length <= 0) {
			alert('网址中没有找到amazon.国家');
			return;
		}

		if (start_date.length <= 0) {
			alert('没有填写开始时间');
			return;
		}

		if (start_date.length <= 0) {
			alert('没有填写结束时间时间');
			return;
		}


		alert('开始下载买家之声的数据');


		send_content_message(tab_id, {
			'seller_id': seller_id,
			'marketplace_id': marketplace_id,
			'http': asin_http,
			'table_id': tab_id,
			'down_type': downType,
			'start_date': start_date,
			'end_date': end_date,
		}, downType)



	});



}











