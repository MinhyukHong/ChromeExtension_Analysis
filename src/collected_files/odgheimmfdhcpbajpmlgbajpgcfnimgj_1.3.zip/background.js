chrome.runtime.onInstalled.addListener(function() {
    chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
        chrome.declarativeContent.onPageChanged.addRules([{
            conditions: [
                new chrome.declarativeContent.PageStateMatcher({
                    pageUrl: {
                        hostEquals: 'imgur.com'
                    }
                }),
				new chrome.declarativeContent.PageStateMatcher({
                    pageUrl: {
                        hostEquals: 'i.imgur.com'
                    }
                }),
				new chrome.declarativeContent.PageStateMatcher({
                    pageUrl: {
                        hostEquals: 'stack.imgur.com'
                    }
                })
            ],
            actions: [
				new chrome.declarativeContent.ShowPageAction()
				]
        }]);
    });
});

chrome.pageAction.onClicked.addListener(function(info, tab) {
		chrome.tabs.query({'active': true, 'windowId': chrome.windows.WINDOW_ID_CURRENT},
		   function(tabs){
				SecureURL(tabs);
		   }
		);
    });
	
function SecureURL(tabs)
{
	var currentUrl = tabs[0].url;
	currentUrl = currentUrl.replace("http", "https") + ".jpg";
	chrome.tabs.update(null, {url: currentUrl});
}