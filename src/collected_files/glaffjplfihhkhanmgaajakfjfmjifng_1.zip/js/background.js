// Start Detection Loop
check(); setInterval(function () {check(); }, 10000);

async function check() {

    let storage = await getStorageData();

    const streamData = await getStreamData();
    if (streamData && streamData.type === 'live') {
        chrome.browserAction.setIcon({path: config.images.icon_on_64});
        if (storage.notifications && !await streamIsOpen()) {
            if (storage.notified || (new Date()) - storage.notified > 60 * 60 * 1000) {
                if (config.notification.message === '') config.notification.message = streamData.title;
                chrome.notifications.create(config.notification);
                chrome.storage.local.set({notified: new Date()});
            }
        }
    } else {
        chrome.browserAction.setIcon({path: config.images.icon_off_64});
        chrome.storage.local.set({sent: null});
    }
}
