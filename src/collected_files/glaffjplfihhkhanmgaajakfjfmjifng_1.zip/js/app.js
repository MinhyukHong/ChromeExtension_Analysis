$(async function () {

    const user = await getUserInfos();
    const data = await getStreamData();
    const storage = await getStorageData();
    const viewsCount = user && user.view_count
        ? user.view_count.toLocaleString('fr')
        : '0';

    // Init HTML Content
    $('body').on('click', 'a', function () {
        chrome.tabs.create({url: $(this).attr('href')});
    });
    $('.channel').attr('href', 'https://twitch.tv/' + config.channel_name);
    if (storage.notifications) $('.tgl.tgl-skewed').attr('checked', 'checked');
    for (let [key, value] of Object.entries(config.social)) {
        if (value) $('.social').append(`<a href="${value}"><img alt="${key}" src="img/assets/${key}.png"></a>`);
    }
    $(".tgl.tgl-skewed").on("change", function() {
        this.checked
            ? chrome.storage.local.set({notifications: true})
            : chrome.storage.local.set({notifications: false, sent: false});
    });
    $('#views').html(viewsCount + ' vues');

    // If Stream is Online
    if (user && data && data.type === 'live') {

        // Switch to Online View
        $('.offline').addClass('disabled');
        $('.online').removeClass('disabled');
        $('body').addClass('stream-off')
        $('body').addClass('stream-on')

        // Get Informations
        const gameName = await getGameName(data.game_id);
        const viewersCount = data.viewer_count ? data.viewer_count.toLocaleString('fr') : 0;
        const thumnailUrl = data.thumbnail_url.replace('-{width}x{height}', '') || 'img/assets/placeholder.png';

        // Change Informations
        $('.channel .online img').attr('src', thumnailUrl);
        $('.channel h1').html(data.title);
        $('#viewers').html(viewersCount + ' spectateurs');
        $('#game').html(gameName);


    // if Streeam is Offline
    } else if (user) {

        // Switch to Offline View
        $('.online').addClass('disabled');
        $('.offline').removeClass('disabled');
        $('body').addClass('stream-off')
        $('body').removeClass('stream-on')
        // Change Informations
        $('.channel .offline .profile-img img').attr('src', user.profile_image_url);
        $('.channel h1').html(user.display_name);
        $('#game').html('Stream soon !');


    // If Twitch Error
    } else {

        $('.loading').addClass('disabled');
        $('.error').removeClass('disabled');
        return;
    }

    // Show App View
    $('.loading').addClass('disabled');
    $('.app').removeClass('disabled');
});
