let config = {
    "channel_name": "vivec_tv",
    "client_id": "5eibdu8ztkirqquyd5hn6tidrdzmm2",
    "notification": {
        "title": "Vivec est désormais en live !",
        "message": "Bouges ton fessier et rejoins nous !",
        "type": "basic",
        "iconUrl": "img/icon-notification.png"
    },
    "social": {
        "youtube": "https://www.youtube.com/channel/UCDVf0scMd4ZIGO6ymPIxQzw",
        "twitter": "https://twitter.com/VivecPro",
        "facebook": "",
        "instagram": "",
        "discord": "https://discordapp.com/invite/3HRGat4",
        "shop": ""
    },
    "installation": {
        "type": "basic",
        "title": "Extension installée !",
        "message": "Merci d'avoir installé l'extension vivec TV.",
        "iconUrl": "img/icon-notification.png"
    },
    "images": {
        "icon_off_64": "img/icon-off-64.png",
        "icon_on_64": "img/icon-on-64.png",
    },
};
