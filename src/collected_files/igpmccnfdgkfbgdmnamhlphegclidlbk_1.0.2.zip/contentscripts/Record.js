/******/ (() => { // webpackBootstrap
var mediaRecorder = null;
var mediaStreamTemp = null;
/* global chrome */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 2. A page requested user data, respond with a copy of `user`
  /*if(message === "test"){
    chrome.runtime.sendMessage(sender.tab.id);
  }*/
  if (message.type === 'tab' || message.type === 'desktop') {
    navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: "desktop",
          chromeMediaSourceId: message.streamData
        }
      },
      video: {
        mandatory: {
          chromeMediaSource: "desktop",
          chromeMediaSourceId: message.streamData
        }
      }
    }).then(stream => {
      //console.log(stream);
      mediaStreamTemp = stream;
      chrome.runtime.sendMessage({
        mName: "storeRecordingState",
        mData: {
          isRecording: true,
          recordingType: message.type
        }
      });
      //stream.addTrack(stream.getAudioTracks()[0]);
      createRecorder(stream, "video/webm");
      //this does not work currently
      stream.onended = () => {
        // Click on browser UI stop sharing button
        //console.log("on ended arrow function stream ended");
        chrome.runtime.sendMessage({
          mName: "storeRecordingState",
          mData: {
            isRecording: false,
            recordingType: "tab"
          }
        });
        mediaRecorder.stop();
        mediaStreamTemp.getTracks() // get all tracks from the MediaStream
        .forEach(track => track.stop());
      };
      stream.getVideoTracks()[0].onended = function () {
        //console.log("get video tracks 0 stream ended");
        chrome.runtime.sendMessage({
          mName: "storeRecordingState",
          mData: {
            isRecording: false,
            recordingType: "tab"
          }
        });
        mediaRecorder.stop();
        mediaStreamTemp.getTracks() // get all tracks from the MediaStream
        .forEach(track => track.stop());
      };
      stream.oninactive = () => {
        //console.log("on inactive stream ended");
        chrome.runtime.sendMessage({
          mName: "storeRecordingState",
          mData: {
            isRecording: false,
            recordingType: "tab"
          }
        });
        mediaRecorder.stop();
        mediaStreamTemp.getTracks() // get all tracks from the MediaStream
        .forEach(track => track.stop());
      };
    });
  }
  if (message.type === "stopRecording") {
    mediaRecorder.stop();
    mediaStreamTemp.getTracks() // get all tracks from the MediaStream
    .forEach(track => track.stop());
  }
});
function createRecorder(stream, mimeType) {
  // the stream data is stored in this array
  let recordedChunks = [];
  mediaRecorder = new MediaRecorder(stream);
  mediaRecorder.ondataavailable = function (e) {
    if (e.data.size > 0) {
      recordedChunks.push(e.data);
    }
  };
  mediaRecorder.onstop = function () {
    saveFile(recordedChunks);
    recordedChunks = [];
  };
  mediaRecorder.start(200); // For every 200ms the stream data will be stored in a separate chunk.
  return mediaRecorder;
}
function blobToDataURL(blob, callback) {
  var a = new FileReader();
  a.onload = function (e) {
    callback(e.target.result);
  };
  a.readAsDataURL(blob);
}
function saveFile(recordedChunks) {
  const blob = new Blob(recordedChunks, {
    type: 'video/webm'
  });
  //let filename = window.prompt('Enter file name'),
  //downloadLink = document.createElement('a');
  //console.log(blob);
  let url = URL.createObjectURL(blob);
  //downloadLink.href = url;
  //downloadLink.download = `${filename}.webm`;
  blobToDataURL(blob, function (dataUrl) {
    chrome.runtime.sendMessage({
      mName: "tempStreamStorage",
      mData: {
        streamBlob: dataUrl
      }
    });
  });
  chrome.runtime.sendMessage({
    mName: "openSaveFileTab",
    mData: {
      fileUrl: url
    }
  });

  /*document.body.appendChild(downloadLink);
  downloadLink.click();
  URL.revokeObjectURL(blob); // clear from memory
  document.body.removeChild(downloadLink);*/
}
/******/ })()
;