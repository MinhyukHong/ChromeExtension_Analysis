/******/ (() => { // webpackBootstrap
let installSuccessURL = 'welcome/welcome.html';
var AzioneBackground = {
  streamData: null
};
/*chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({url: installSuccessURL});
});*/

chrome.runtime.onStartup.addListener(() => {
  /*chrome.storage.sync.get(['isSnipDOMEnabled'], function(result) {
    console.log('Value currently is ' + result.isSnipDOMEnabled);
  });*/
  //console.log('azione started');
});
async function getCurrentTab() {
  let queryOptions = {
    active: true,
    currentWindow: true
  };
  let [tab] = await chrome.tabs.query(queryOptions);
  return tab;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.mName === "tab" || message.mName === "desktop") {
    chrome.tabs.get(message.mData, async tab => {
      //tab = tab.id;
      //let tab = currentTab;
      let mediaType = message.mName;
      if (mediaType === "desktop") {
        mediaType = "screen";
      }
      chrome.desktopCapture.chooseDesktopMedia([mediaType, "audio"], tab, streamId => {
        //check whether the user canceled the request or not
        if (streamId && streamId.length) {
          //sendResponse(streamId);
          chrome.storage.local.set({
            recordingStartedTabId: tab.id
          }, function () {
            //console.log('Value is set to ' + tab.id);
          });
          chrome.tabs.sendMessage(tab.id, {
            streamData: streamId,
            type: message.mName
          });
        }
      });
    });
  }
  if (message.mName === "storeRecordingState") {
    chrome.storage.local.set({
      isRecording: message.mData.isRecording,
      recordingType: message.mData.recordingType
    }, function () {
      //console.log('Value is set to ' + message.mData);
    });
  }
  if (message.mName === "retrievePopupUiStates") {
    chrome.storage.local.get(['isRecording', "recordingType"], function (result) {
      //console.log('Value currently is ' + result.isRecording);
      if (result.isRecording !== undefined && result.isRecording !== null) {
        sendResponse({
          isRecording: result.isRecording,
          recordingType: result.recordingType
        });
      }
    });
  }
  if (message.mName === "openSaveFileTab") {
    chrome.tabs.create({
      url: 'views/savefile/index.html?fileUrl=' + message.mData.fileUrl
    });
  }
  if (message.mName === "downloadVideoFile") {
    chrome.downloads.download({
      url: message.mData.fileUrl,
      filename: message.mData.fileName
    });
  }
  if (message.mName === "closeTab") {
    chrome.tabs.remove(message.mData);
  }
  if (message.mName === "tempStreamStorage") {
    AzioneBackground.streamData = message.mData.streamBlob;
    //console.log(AzioneBackground.streamData, message.mData.streamBlob);
  }
  if (message.mName === "saveRecordingToStorage") {
    chrome.storage.local.get(['savedRecordingArray'], function (result) {
      //console.log('Value currently is ' + result.savedRecordingArray);
      if (result.savedRecordingArray !== undefined && result.savedRecordingArray !== null) {
        result.savedRecordingArray.push(AzioneBackground.streamData);
        chrome.storage.local.set({
          savedRecordingArray: result.savedRecordingArray
        }, function () {
          //console.log('Value is set to ' + tab.id);
        });
      } else {
        let savedRecordingArray = new Array();
        savedRecordingArray.push(AzioneBackground.streamData);
        chrome.storage.local.set({
          savedRecordingArray: savedRecordingArray
        }, function () {
          //console.log('Value is set to ' + tab.id);
        });
      }
    });
  }
  if (message.mName === "openSaveRecording") {
    chrome.storage.local.get(['savedRecordingArray'], function (result) {
      //console.log('Value currently is ' + result.savedRecordingArray);
      if (result.savedRecordingArray !== undefined && result.savedRecordingArray !== null) {
        sendResponse(result.savedRecordingArray[2]);
      }
    });
  }
  if (message.mName === "stopRecording") {
    chrome.tabs.sendMessage(message.mData, {
      type: "stopRecording"
    });
  }
  return true;
});
chrome.storage.onChanged.addListener(function (changes, namespace) {
  for (let [key, {
    oldValue,
    newValue
  }] of Object.entries(changes)) {
    /*console.log(
      `Storage key "${key}" in namespace "${namespace}" changed.`,
      `Old value was "${oldValue}", new value is "${newValue}".`
    );*/
    if (key === "isRecording" && newValue === false) {
      chrome.storage.local.get(['recordingStartedTabId'], function (result) {
        //console.log('Value currently is ' + result.recordingStartedTabId);
        if (result.recordingStartedTabId !== undefined && result.recordingStartedTabId !== null) {
          chrome.tabs.sendMessage(result.recordingStartedTabId, {
            streamData: streamId,
            type: message.mName
          });
        }
      });
    }
  }
});

/*chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  console.log(tabId, changeInfo, tab);
  var url = new URL(tab.url);

});*/
/******/ })()
;