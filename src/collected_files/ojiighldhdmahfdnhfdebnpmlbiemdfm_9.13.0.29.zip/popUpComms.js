(function () {
  const browserAPI = (typeof browser === 'undefined' ? chrome : browser);

  browserAPI.runtime.onMessage.addListener((msg) => {
    if (msg.destination === 'ast') {
            window.postMessage(msg, (!!window.origin && window.origin!== 'null') ? window.origin : '*');
    }
  });
  
  window.addEventListener('message', function (event) {
    try {
      if (event.data.command && event.data.command.source !== 'mainstation') {
        browserAPI.runtime.sendMessage(event.data);
      }
    } catch (e) {
      // ignore other events
    }
  }, false);
})();