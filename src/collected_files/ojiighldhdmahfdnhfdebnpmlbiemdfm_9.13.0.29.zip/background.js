import appState from './background/AppState.js';
import browserAPI from './background/browserAPI.js';
import {
	getPopupWindow,
	getWindowDimensions,
	injectContentScripts,
	requestPermission,
	tabCheck
} from './background/helpers.js';
import {initializeFreezeThaw} from './background/freezeThaw.js';
import MessageHandlers from './background/MessageHandlers.js';

const initializeAssistant = async (tab) => {
	const popupWindow = await getPopupWindow();
	if (popupWindow) {
		// window is already open
		browserAPI.windows.update(popupWindow.id, {
			focused: true
		});
		return;
	}
	
	const {windowSize, windowPosition} = await getWindowDimensions();
	await appState.set('initialActiveTabId', tab.id);
	
	await injectContentScripts(tab);
	
	browserAPI.windows.create({
		          width : windowSize.width,
		          height: windowSize.height,
		          top   : windowPosition.y,
		          left  : windowPosition.x,
		          type  : 'popup',
		          url   : 'popup.html'
	          })
	          .then(async (popupWindow) => {
		          await appState.set('popupWindowId', popupWindow.id);
		          await appState.set('popupTabId', popupWindow.tabs[0].id);
		          setTimeout(() => {
			          browserAPI.tabs.reload(popupWindow.tabs[0].id);
		          }, 250);
	          });
};

const handlePotentialTabChange = async (tabId, hidePermissions = true) => {
	const popup = await getPopupWindow();
	if (!(popup)) {
		// don't do anything if the AST extension window isn't open
		return;
	}

	browserAPI.tabs.get(tabId, (tab) => {
		if (!tab || tab.id <= 0) {
			// ignore invalid tabs
			return;
		}
		
		const windowId = tab.windowId;
		if (windowId <= 0) {
			// ignore tabs with invalid window IDs
			return;
		}
		
		if (!tab.url) {
			// ignore blank tabs
			return;
		}

		if (tab.windowId === popup.id) {
			// ignore tabs from the AST window
			return;
		}
		
		const urlObj = new URL(tab.url);
		if (['http:', 'https:', 'file:'].indexOf(urlObj.protocol) === -1) {
			// ignore N/A protocols for tab content
			return;
		}
		
		browserAPI.windows.get(windowId, async (win) => {
			if (!win || win.id !== windowId) {
				// ignore invalid windows
				return;
			}
			
			// inject content scripts into page, requesting permission if necessary
			const permissions = {
				origins: [urlObj.protocol + '//' + urlObj.hostname + '/*']
			};
			browserAPI.permissions.contains(permissions, (hasPermission) => {
				if (hasPermission) {
					injectContentScripts(tab, hidePermissions);
				} else {
					requestPermission('page', { permissions });
				}
			});
			
			await appState.set('activeWindowId', win.id);
			await appState.set('activeTabId', tab.id);
			
			tabCheck(tab);
		});
	});
};

/* ******************************************************************************** */
// Listeners
/* ******************************************************************************** */
browserAPI.action.onClicked.addListener(async (tab) => {
	await appState.set('activeTabId', tab.id);
	await appState.set('activeWindowId', tab.windowId);
	
	initializeAssistant(tab);
});

// handle user changing from one active tab to another
browserAPI.tabs.onActivated.addListener((activeInfo) => {
	handlePotentialTabChange(activeInfo.tabId);
});

// handle the current page changing in some way, e.g. navigating to a new page within a tab
browserAPI.tabs.onUpdated.addListener((tabId, changeInfo) => {
	if (!changeInfo.status || changeInfo.status !== 'complete') {
		// ignore incomplete updates
		return;
	}
	
	handlePotentialTabChange(tabId);
});

// handle user changing from one active window to another
browserAPI.windows.onFocusChanged.addListener(async (windowId) => {
	if (windowId !== browserAPI.windows.WINDOW_ID_NONE) {
		const activeTabId = await appState.get('activeTabId');
		const [newActiveTab] = await browserAPI.tabs.query({ active: true, windowId });
		if (newActiveTab && newActiveTab.id !== activeTabId) {
			handlePotentialTabChange(newActiveTab.id);
		}
	}
});

// handle changes to current document, eg. new iframes
browserAPI.webNavigation.onCompleted.addListener((changeInfo) => {
	handlePotentialTabChange(changeInfo.tabId, changeInfo.frameType !== 'sub_frame');
});

// Reset state when popup window is closed
browserAPI.windows.onRemoved.addListener(async (windowId) => {
	const popupWindowId = await appState.get('popupWindowId');
	if (windowId === popupWindowId) {
		await appState.set('popupWindowId', null);
		await appState.set('popupTabId', null);
		await appState.set('initialActiveTabId', null);
	}
});

if (browserAPI?.windows?.onBoundsChanged) {
	// Only compatible with Chrome and Edge
	browserAPI.windows.onBoundsChanged.addListener(async (window) => {
		const popupWindow = await getPopupWindow();
		if (popupWindow && window.id === popupWindow.id) {
			const {top, left, width, height} = window;
			
			browserAPI.storage.local.set({
				'windowPosition': JSON.stringify({x: left, y: top}),
				'windowSize'    : JSON.stringify({height, width})
			});
		}
	});
}

/* ******************************************************************************** */
// Messaging
/* ******************************************************************************** */
MessageHandlers.initialize();

/* ******************************************************************************** */
// Freeze/Thaw Functionality
/* ******************************************************************************** */
initializeFreezeThaw();