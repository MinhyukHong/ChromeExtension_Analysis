import browserAPI from './browserAPI.js';

const STORAGE_KEY = 'app-state';

class AppState {
	initialized = false;
	data        = {
		popupWindowId     : null,
		popupTabId        : null,
		initialActiveTabId: null,
		activeTabId       : null,
		activeWindowId    : null,
		frozen            : false
	};
	
	async init() {
		if (!this.initialized) {
			this.data        = await browserAPI.storage.local.get([STORAGE_KEY])
			                               .then(values => values[STORAGE_KEY])
			                               .then(state => (
				                               !!state ? JSON.parse(state) : this.data
			                               ));
			this.initialized = true;
		}
	}
	
	async get(key) {
		await this.init();
		
		return this.data[key];
	}
	
	async set(key, value) {
		await this.init();
		
		this.data[key] = value;
		await browserAPI.storage.local.set({ [STORAGE_KEY]: JSON.stringify(this.data) });
	}
}

const appState = new AppState();

export default appState;