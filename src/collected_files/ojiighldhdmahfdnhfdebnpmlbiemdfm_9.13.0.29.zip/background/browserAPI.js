const browserAPI = (typeof browser === 'undefined' ? chrome : browser);
export default browserAPI;
