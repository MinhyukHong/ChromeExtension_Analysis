import appState from './AppState.js';
import browserAPI from './browserAPI.js';
import {
	injectContentScripts,
	reactivateAST,
	checkRuntimeErrors,
	requestPermission,
	sendMessageToPopup,
	sendMessageToTab
} from './helpers.js';

export default class MessageHandlers {
	static initialize() {
		browserAPI.runtime.onMessage.addListener(MessageHandlers.handleMessage);
		browserAPI.runtime.onMessageExternal.addListener(MessageHandlers.handleExternalMessage);
	}

	// Handle messages within extension
	static async handleMessage(payload) {
		if (!payload.destination) {
			return;
		}

		if (payload.destination === 'background') {
			switch (payload.command?.type) {
				case 'PERMISSION_CHECK':
					MessageHandlers.permissionCheck(payload);
					break;
				
				case 'TO_EXTERNAL':
					MessageHandlers.toExternal(payload);
					break;
				
				case 'ACTIVATE_AST':
					reactivateAST();
					break;
				
				case 'CONNECT':
					MessageHandlers.connect(payload);
					break;
				
				case 'SEND_REQUEST':
					MessageHandlers.sendRequest(payload);
					break;
				
				case 'CAPTURE_THUMBNAIL':
					MessageHandlers.captureThumbnail();
					break;
				
				case 'CHECK_SESSION':
					MessageHandlers.checkSession(payload);
					break;
				
				case 'PERMISSION_GRANTED':
					MessageHandlers.permissionGranted(payload);
					break;
				
				default:
					// unknown command
					return;
			}
		} else {
			const activeWindowId = await appState.get('activeWindowId');
			if (activeWindowId) {
				browserAPI.tabs.query({
					active  : true,
					windowId: activeWindowId,
					url     : '<all_urls>'
				}, function (tabs) {
					if (tabs.length === 1) {
						switch (payload.destination) {
							case 'page':
								const tabId = tabs[0].id;
								sendMessageToTab(tabId, payload);
								browserAPI.tabs.update(tabId, {
									active: true
								});
								break;

							case 'ast':
								sendMessageToPopup(payload)
								break;
						
							default:
								break;
						}
					}
				})
			}
		}
	}

	// Handle external messages
	static handleExternalMessage(payload, sender) {
		switch (payload.from) {
			case 'FROM_EXTERNAL':
				MessageHandlers.fromExternal(payload, sender)
				break;

			default:
				break;
		}
	}
	
	// 'PERMISSION_CHECK'
	static async permissionCheck(payload) {
		const activeTabId = await appState.get('activeTabId');

		if (activeTabId && payload.command.permissions.origins.length > 0) {
			browserAPI.permissions.contains(payload.command.permissions, (hasPermission) => {
				if (hasPermission) {
					MessageHandlers.permissionGranted(payload);
				} else {
					requestPermission('iframes', payload.command);
				}
			});
		}
	}
	
	// 'PERMISSION_GRANTED'
	static async permissionGranted(payload) {
		const activeTabId = await appState.get('activeTabId');

		if (activeTabId) {
			browserAPI.tabs.get(activeTabId, async (tab) => {
				await injectContentScripts(tab);
				sendMessageToTab(activeTabId, {
					source: 'background',
					destination: 'page',
					frameId: payload.frameId,
					result: {
						...payload.command,
						type: 'PERMISSION_CHECK_RESPONSE'
					}
				});
				checkRuntimeErrors();
			});
		}
	}
	
	// 'TO_EXTERNAL'
	static toExternal(payload) {
		if (payload.command.extension) {
			try {
				console.debug('[AST] [toExternal]', payload);
				browserAPI.runtime.sendMessage(payload.command.extension, {
						from   : 'AST',
						payload: {
							action: payload.command.action,
							data  : payload.command.data
						}
					}
				);
			} catch (e) {
				console.info('no external', e);
			}
		}
	}
	
	// 'FROM_EXTERNAL'
	static fromExternal(payload, sender) {
		const responsePayload = {
			source     : 'background',
			destination: 'ast',
			result     : {
				type       : 'FROM_EXTERNAL',
				payload    : Object.assign({}, payload.payload),
				extensionId: sender.id
			}
		};
		
		sendMessageToPopup(responsePayload);
	}
	
	// 'CONNECT':
	static async connect(payload) {
		const {url}          = payload.command || {};
		const activeWindowId = await appState.get('activeWindowId');
		browserAPI.tabs.query({
			active  : true,
			windowId: activeWindowId
		})
		.then((tabs) => {
			if (tabs[0].url === url) {
				return; // Tab is already active
			}

			// See if any other open tabs match
			browserAPI.tabs.query(
				{
					windowId: activeWindowId,
					url     : url
				}
			)
			.then((tabs) => {
				if (tabs.length > 0) {
					browserAPI.tabs.update(tabs[0].id, {active: true})
						.then(injectContentScripts)
						.then(reactivateAST);
				} else {
					// No tabs match, open one.
					browserAPI.tabs.create({windowId: activeWindowId, url})
						.then(reactivateAST);
				}
			});
		});
	}
	
	// 'SEND_REQUEST'
	static sendRequest(payload) {
		const handler = (method, url, data) => {
			fetch(url, {
				method,
				headers: {
					'Content-Type'            : 'application/json;charset=UTF-8',
					'Level-Access-AST-Version': '9.13.0.29'
				},
				body   : JSON.stringify(data)
			})
				.then(async (response) => {
					return {
						status      : response.status,
						responseText: await response.text()
					};
				})
				.then(({status, responseText}) => {
						// fetch doesn't hit catch even if 4xx or 5xx responses
						if (status === 200) {
							if (responseText && responseText.length > 0) {
								try {
									sendMessageToPopup({
										...(JSON.parse(responseText)),
										destination: 'ast',
										COMID      : payload.COMID
									});
								} catch (error) {
									sendMessageToPopup({
										error      : true,
										code       : status,
										source     : 'background',
										destination: 'ast',
										COMID      : payload.COMID
									});
								}
							}
						} else {
							sendMessageToPopup({
								error      : true,
								code       : status,
								source     : 'background',
								destination: 'ast',
								COMID      : payload.COMID
							});
						}
					}
				);
		};
		
		const {method, url, data} = payload.command;
		switch (method) {
			case 'POST':
			case 'PUT':
				handler(method, url, data);
				break;
			
			case 'DELETE':
			case 'GET':
				handler(method, `${url}?token=${data.token}`);
				break;
			
			default:
				sendMessageToPopup({COMID: payload.COMID, error: true, code: 404});
				return;
		}
	}
	
	// 'CAPTURE_THUMBNAIL'
	static async captureThumbnail() {
		// The screenshot taken by browserAPI.tabs.captureVisibleTab() may be of higher resolution thus it needs to be scaled to the window size using canvas
		const callback = function (dataUrl) {
			// Check if the call failed because of lack of activeTab permission
			const e = browserAPI.runtime.lastError;
			if (!(e === undefined || e === null)) { // undefined in chrome, null in firefox
				sendMessageToPopup({
					result     : {
						type   : 'CAPTURE_THUMBNAIL_RESPONSE',
						success: false
					},
					source     : 'background',
					destination: 'ast'
				});
			}
			
			sendMessageToPopup({
				result     : {
					type            : 'CAPTURE_THUMBNAIL_RESPONSE',
					success         : true,
					dataUrl         : dataUrl
				},
				source     : 'background',
				destination: 'ast'
			});
		};
		
		const activeWindowId = await appState.get('activeWindowId');
		if (activeWindowId) {
			browserAPI.tabs.captureVisibleTab(activeWindowId, {}).then(callback);
		}
	}
	
	// 'CHECK_SESSION'
	static checkSession(payload) {
		fetch(`https://${payload.command.host}/api/assistant/user/hasSession`, {method: 'POST'})
			.then(async response => await response.text())
			.then((response) => {
				sendMessageToPopup({
					source     : 'background',
					destination: 'ast',
					result     : {
						type: 'CHECK_SESSION_RESPONSE',
						response
					}
				});
			})
			.catch(reason => {
				sendMessageToPopup({
					source     : 'background',
					destination: 'ast',
					result     : {
						error: true,
						COMID: payload.COMID,
						type : 'CHECK_SESSION_RESPONSE',
						reason
					}
				});
			});
	}
}