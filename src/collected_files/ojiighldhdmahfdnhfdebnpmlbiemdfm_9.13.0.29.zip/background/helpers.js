/* global chrome, browser */
import browserAPI from './browserAPI.js';
import appState from './AppState.js';

const AST_TITLE = 'Access Assistant';

export async function getPopupWindow() {
	let popupWindow;
	try {
		const popupWindowId = await appState.get('popupWindowId');
		if (popupWindowId) {
			popupWindow = await browserAPI.windows.get(popupWindowId, { windowTypes: ['popup'] });
		}
	} catch (err) {
		await appState.set('popupWindowId', null);
	}

	return popupWindow;
}

export async function sendMessageToPopup(payload, responseCallback) {
	if (await getPopupWindow()) {
		console.debug('[AST] [sendMessageToPopup]', payload);
		browserAPI.runtime.sendMessage(payload, responseCallback);
	}
}

export function sendMessageToTab(tabId, payload, responseCallback) {
	console.debug('[AST] [sendMessageToTab]', tabId, payload);
	const frameId = payload.hasOwnProperty('frameId') ? payload.frameId : 0;
	browserAPI.tabs.sendMessage(tabId, payload, { frameId }, responseCallback);
}

export const requestPermission = (source, request) => {
	const responsePayload = {
		source     : 'background',
		destination: 'ast',
		result     : {
			...request,
			type  : 'PERMISSIONS',
			source: source
		}
	};
	
	try {
		sendMessageToPopup(responsePayload);
	} catch (e) {
		console.log(e);
	}
};

export const checkRuntimeErrors = () => {
	const e = browserAPI.runtime.lastError;
	if (!(e === undefined || e === null)) {
		console.log('Encountered', e);
	}
};

export async function tabCheck() {
	const callback = async () => {
		let override = false;
		const e      = browserAPI.runtime.lastError;
		if (!(e === undefined || e === null)) {
			override = true;
		}

		sendMessageToPopup({
			source     : 'background',
			destination: 'ast',
			result     : {
				type        : 'ACTIVE_TAB_CHANGE',
				initialTabId: await appState.get('initialActiveTabId'),
				activeTabId : await appState.get('activeTabId'),
				override    : override
			}
		});
	};
	
	// See if AST has screenshot permission
	browserAPI.tabs.captureVisibleTab(await appState.get('activeWindowId'), {}, callback);
}

let injectScriptsPromise;
export async function injectContentScripts(tab, hidePermissions = true) {
	if (injectScriptsPromise) {
		// Wait for any pending injection and then try again, to avoid racing
		await injectScriptsPromise;
		return injectContentScripts(tab);
	}

	injectScriptsPromise = new Promise(async (resolve, reject) => {
		try {
			const frames = await browserAPI.webNavigation.getAllFrames({ tabId: tab.id });

			// Determine which frames don't have the content scripts yet
			const outcomes = await Promise.allSettled(
				frames.map((frame) =>
					browserAPI.scripting
						.executeScript({
							target: { tabId: tab.id, frameIds: [frame.frameId] },
							injectImmediately: true,
							func: function () {
								return !!window.LevelAccess;
							}
						})
			));

			const frameIds = outcomes.filter( (outcome) => outcome.status === 'fulfilled' && Array.isArray( outcome.value ) && outcome.value[0].result !== null && !outcome.value[0].result )
						.map( (outcome) => outcome.value[0].frameId );

			if (frameIds && frameIds.length > 0) {
				await Promise.all([
					browserAPI.scripting
						.executeScript({
							target: { tabId: tab.id, frameIds },
							injectImmediately: true,
							files: [
								'MainStation.js',
								'AccessEngine.professional.js',
								'LevelAccess-AST.js',
							]
						}),
						browserAPI.scripting.insertCSS({
						target: { tabId: tab.id, frameIds },
						files: ['LevelAccess-AST.css']
					})
				]);

				const framesMap = frames.reduce((map, frame) => map.set(frame.frameId, frame), new Map());

				// Determine the `frameId` for the page scripts.
				// Note that this is based on the frame's url, which is different from the frameId used by the browser extension APIs.
				function getPageFrameId(targetFrame) {
					if (!targetFrame) return '';

					if (targetFrame.parentFrameId > -1 && framesMap.get(targetFrame.parentFrameId)) {
						const parentId = getPageFrameId(framesMap.get(targetFrame.parentFrameId));

						// Use full location to identify unique iframes
						if (parentId) {
							return parentId.indexOf('[') === 0
								? parentId + '[' + targetFrame.url + ']'
								: '[' + parentId + '][' + targetFrame.url + ']';
						}
					}

					return targetFrame.url;
				}

				// Set the `frameId` for the page scripts.
				await Promise.allSettled(
					frames.map((frame) =>
						browserAPI.scripting.executeScript({
							args: [getPageFrameId(frame)],
							target: { tabId: tab.id, frameIds: [frame.frameId] },
							func: function (frameId) {
								if (typeof LevelAccess !== 'undefined') {
									LevelAccess.frameId = frameId;
								}
							}
						})
					)
				);
			}

			injectScriptsPromise = undefined;

			if (hidePermissions) {
				sendMessageToPopup({
					source     : 'background',
					destination: 'ast',
					result     : {
						type: 'HIDE_PERMISSIONS'
					}
				});
			}
		
			checkRuntimeErrors();

			resolve();
		} catch (error) {
			reject(error);
		}
	});

	return injectScriptsPromise;
}

export const getWindowDimensions = () => {
	return new Promise((resolve) => {
		const defaults = {
			windowSize    : {width: 800, height: 640},
			windowPosition: {x: 0, y: 0}
		};
		browserAPI.storage.local.get(['windowSize', 'windowPosition'])
			.then((response) => {
				const {windowSize = defaults.windowSize, windowPosition = defaults.windowPosition} = response;
				resolve({
					windowSize    : typeof windowSize === 'string' ? JSON.parse(windowSize) : windowSize,
					windowPosition: typeof windowPosition === 'string' ? JSON.parse(windowPosition) : windowPosition
				});
			})
			.catch(() => resolve(defaults));
	});
};

export const reactivateAST = function () {
	browserAPI.tabs.query(
		{
			title: AST_TITLE + ' *'
		},
		(tabs) => {
			if (tabs.length > 0) {
				browserAPI.windows.update(tabs[0].windowId, {'focused': true});
			}
		}
	);
};
