import appState from './AppState.js';
import browserAPI from './browserAPI.js';
import {checkRuntimeErrors} from './helpers.js';

const thawPage = async (tab) => {
	if (typeof tab === 'object') {
		tab = tab.tabId;
	}
	
	if (await appState.get('frozen')) {
		browserAPI.tabs.sendMessage(
			tab,
			{
				data: {
					type: 'THAW'
				}
			}
		);
	}
	
	await appState.set('frozen', false);
};

export function initializeFreezeThaw() {
	browserAPI.commands.onCommand.addListener(async function (command) {
		if (command === 'freeze-thaw') {
			const frozen = !(await appState.get('frozen'));
			await appState.set('frozen', frozen);
			browserAPI.tabs.query({active: true, currentWindow: true}, function (tabs) {
					const freezeThaw = (type) => {
						// use of `window` is ok here because this function is executed in page context
						window.postMessage({destination: 'page', command: {type}}, (!!window.origin && window.origin!== 'null') ? window.origin : '*');
					};
					browserAPI.scripting.executeScript({
						          target: {tabId: tabs[0].id},
						          func  : freezeThaw,
						          args  : [
							          frozen ? 'freeze' : 'thaw'
						          ]
					          })
					          .then(checkRuntimeErrors);
				}
			);
		}
	});
	
	browserAPI.tabs.onActivated.addListener(thawPage);
	browserAPI.tabs.onUpdated.addListener(thawPage);
}