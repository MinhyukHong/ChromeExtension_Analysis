(function () {
	const browserAPI = (typeof browser === 'undefined' ? chrome : browser);

	// Receives messages from background and sends them to SubStation - SubStation is either in the page or iframes
	browserAPI.runtime.onMessage.addListener((msg) => {
		const origin = !!window.origin && window.origin!== 'null' ? window.origin : '*';
		if (msg.command) {
			msg.command.source = 'mainstation';
			window.postMessage(msg, origin);
		} else if (msg.result && msg.destination === 'page') {
			window.postMessage(msg, origin);
		}
	});
	
	// Receives messages from SubStation and sends them to background
	window.addEventListener('message', function (event) {
		if (event.data.destination === 'ast' || event.data.destination === 'background') {
			browserAPI.runtime.sendMessage(event.data);
		}
	}, false);
})();