chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.action === "getCookie") {

      // Get the current tab's URL
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
          const currentDomain = new URL(tabs[0].url).hostname; // Extract hostname
          chrome.cookies.getAll({}, (cookies) => {

              const ctCookies = cookies.filter(cookie => 
                  cookie.name.startsWith("_ct_") && 
                  (currentDomain.includes(cookie.domain) || currentDomain.includes(cookie.domain.replace('.', ''))) // Match exact domain or subdomain
              );

              if (ctCookies.length > 0) {
                  const cookie = ctCookies[0];
                  const values = cookie.value.split('|');
                  sendResponse({ success: true, values });
              } else {
                  sendResponse({ success: false, message: "No information found on the current domain" });
              }
          });
      });
      return true; // Keep the messaging channel open for sendResponse
  }

  if (request.action === "deleteCookie") {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const currentDomain = new URL(tabs[0].url).hostname; // Extract hostname
        chrome.cookies.getAll({}, (cookies) => {

            const ctCookies = cookies.filter(cookie => 
                cookie.name.startsWith("_ct_") && 
                (currentDomain.includes(cookie.domain) || currentDomain.includes(cookie.domain.replace('.', ''))) // Match exact domain or subdomain
            );

            if (ctCookies.length > 0) {
                // remove the cookie
                chrome.cookies.remove({ url: `https://${currentDomain}/`, name: ctCookies[0].name }, (details) => {
                    sendResponse({ success: true, message: "Tracker Reset" });
                });
            } else {
                sendResponse({ success: false, message: "No tracker found on the current domain" });
            }
        });
    });
    
    return true; // Keep the messaging channel open for sendResponse
}



});
