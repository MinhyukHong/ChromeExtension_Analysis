document.addEventListener('DOMContentLoaded', function() {

  const messageDiv = document.getElementById('message');
  const cookieDataDiv = document.getElementById('cookie-data');
  const resetButton = document.getElementById('reset-tracker');

  chrome.runtime.sendMessage({ action: "getCookie" }, (response) => {

    if (response.success) {
      const values = response.values;
      const labels = [
        "Last Pageview Timestamp",
        "Session Count",
        "First Touch Pathname",
        "First Touch Timestamp",
        "First Touch Referrer",
        "First Touch Query String",
        "Last Touch Pathname",
        "Last Touch Timestamp",
        "Last Touch Referrer",
        "Last Touch Query String",
        "Placeholder",
        "Pageviews",
        "Last Viewed Blog Page",
        "Last Viewed Email",
        "Last Viewed Campaign"
      ];

      values.forEach((value, index) => {
        const p = document.createElement('p');
        if(labels[index] == 'Last Pageview Timestamp'){
          if(value != ''){
          value = new Date(value * 1000).toLocaleString();
          }
        }
        if(labels[index] == 'First Touch Timestamp'){
          if(value != ''){
          value = new Date(value * 1000).toLocaleString();
          }
        }
        if(labels[index] == 'Last Touch Timestamp'){
          if(value != ''){
          value = new Date(value * 1000).toLocaleString();
          }
        }

        p.textContent = `${labels[index]}: ${value}`;
        cookieDataDiv.appendChild(p);
      });
    } else {
      messageDiv.textContent = response.message;
    }
  });

  resetButton.addEventListener('click', () => {
    
    chrome.runtime.sendMessage({ action: "deleteCookie" }, (response) => {
      
      if (response.success) {
        messageDiv.textContent = response.message;
        cookieDataDiv.innerHTML = "";
      } else {
        messageDiv.textContent = response.message;
      }
    });
  });

});


