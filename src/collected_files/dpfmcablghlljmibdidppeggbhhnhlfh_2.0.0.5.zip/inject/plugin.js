

var SiacPlugin = {
    config:{
        URL_API:'https://siac.sudam.gov.br/api/',
        URL_LOGIN_SIAC: localStorage.getItem('URL_LOGIN_SIAC'),
        CONSULTA_COMPLETA: localStorage.getItem('CONSULTA_COMPLETA'),
        MANTER_MOVIMENTACAO: localStorage.getItem('MANTER_MOVIMENTACAO')
    },
    conveniosCarregar:function(callback){
        
        /**
         * Busca os convênios a serem atualizados e armazena no localStorage
         */
        //limpa o local storage
        localStorage.clear();
        $.get(SiacPlugin.config.URL_API+'plugin-convenios.php', function(data){ 
            if (localStorage && !localStorage.getItem('size')) {
                try {
                    for(var i in data.data.convenios){
                        localStorage.setItem(i, JSON.stringify(data.data.convenios[i]));
                    }
                    
                    SiacPlugin.config = data.data.config;
                    localStorage.setItem('URL_LOGIN_SIAC',      SiacPlugin.config.URL_LOGIN_SIAC);
                    localStorage.setItem('CONSULTA_COMPLETA',   SiacPlugin.config.CONSULTA_COMPLETA);
                    localStorage.setItem('MANTER_MOVIMENTACAO', SiacPlugin.config.MANTER_MOVIMENTACAO);
                    
                    if(callback){
                        callback(data.data);
                    }
                } catch (e) {
                    console.error('Erro de local storage');        
                }
            }

        }, 'json');
    },
    convenioAtual:function(){
        
        /**
         * Retorna o convênio que esta sento consultado
         */
        
        var indexConvenio = localStorage.getItem('indexConvenio');
        if(!indexConvenio){
            indexConvenio = 0;
            localStorage.setItem('indexConvenio', indexConvenio);
        }
        var convenio = localStorage.getItem(indexConvenio);
        if(convenio){
            return JSON.parse(convenio);
        }else{
            return null;
        }
    },
    proximoConvenioConsultar:function(){
        
        /**
         * Retorna o próximo convênio a ser consultado
         */
        
        var indexConvenio = localStorage.getItem('indexConvenio');
        if(!indexConvenio){
            indexConvenio = 0;
        }else{
            indexConvenio  = parseInt(indexConvenio);
            indexConvenio += 1;
        }
        localStorage.setItem('indexConvenio', indexConvenio);
        
        var convenio = localStorage.getItem(indexConvenio);
        
        if(convenio){
            convenio = JSON.parse(convenio);
        }else{
            alert('Convênios atualizados, você será redirecionado par ao SIAC');
            window.location.href = SiacPlugin.config.URL_LOGIN_SIAC;
            return false;
        }
        
        //atualiza a data do convenio no localStorage
        convenio.VL_DATA_ATUALIZACAO = SiacPlugin.dataAtual();
        localStorage.setItem(indexConvenio, JSON.stringify(convenio));
        
        //coloca a data de atualização do convenio como a data atual
        SiacPlugin.conveioDataAtualizarPlugin(convenio.NR_CONVENIO, function(){
            //faz o post para verificar o convênio
            $.post(SiacPlugin.config.CONSULTA_COMPLETA, {numeroConvenio:convenio.NR_CONVENIO}, function(resource){ 
                //verifica se existe convênio
                if($(resource).find('.numeroConvenio a').length){
                    //redireciona para a tela do convênio
                    window.location.href = 'https://www.convenios.gov.br'+$(resource).find('.numeroConvenio a').attr('href');
                }else{
                    //se não existir, consuta o próximo convênio
                    SiacPlugin.proximoConvenioConsultar();
                }
            });
        });
    },
    clausulaSuspensiva:function(){
        
        /**
         * Método que verifica se existe clausula suspensiva e envia para a base de dados
         */
        
        //pega os dados da cláusula suspensiva
        var dataPrevista   = document.getElementById('tr-voltarDataParaRetirada');
        var motivoClausula = document.getElementById('tr-voltarMotivo');
        
        if(dataPrevista || motivoClausula){
            
            if(dataPrevista){
                dataPrevista = dataPrevista.lastElementChild.innerHTML.replace( /\s/g, '');
            }else{
                dataPrevista = null;
            }
            
            if(motivoClausula){
                motivoClausula = motivoClausula.lastElementChild.innerHTML.replace( /\s/g, '');
            }else{
                motivoClausula = null;
            }
             
            //recupera o convenio que esta sendo atualizado
            var convenio = SiacPlugin.convenioAtual();
            
            var conveioPlugin = {
                NR_CONVENIO:convenio.NR_CONVENIO, 
                VL_DATA_RESOLUCAO_CLAUSULA_SUSPENSIVA: dataPrevista, 
                VL_MOTIVO_CLAUSULA_SUSPENSIVA: motivoClausula
            };
            
            SiacPlugin.cadastraConveioPlugin(conveioPlugin, function(resource){
                //se não existir enviar para a tela das movimentações
                window.location.href = SiacPlugin.config.MANTER_MOVIMENTACAO;
            });
            
        }else{
            //NOTA - Colocar o redirecionamento para a tela do próximo dado
        }
    },
    movimentacaoFinanceira:function(){
        
        /**
         * Método que verifica se existe movimentação financeira e envia para a base de dados
         */
        
        $.get(SiacPlugin.config.MANTER_MOVIMENTACAO, function(resource){ 
            
            //recupera o convenio que esta sendo atualizado
            var convenio = SiacPlugin.convenioAtual();
            
            var movimentacoes = [];
            $('#formConsultaMovimentacaoFinanceira\\:dtTableBeans').find('.dr-table-firstrow').each(function(a, b){ 
                movimentacoes.push({
                    NR_CONVENIO:convenio.NR_CONVENIO, 
                    NUMERO: $($(b).find('td')[0]).find('span').html(), 
                    DATA: $($(b).find('td')[1]).find('span').html(), 
                    VALOR_LIQUIDO: $($(b).find('td')[4]).find('span').html(),
                    TIPO: $($(b).find('td')[6]).find('span').html()
                });
            });
            
            SiacPlugin.cadastraMovimentacaoPlugin(movimentacoes, function(resource){
                //consideramos essa a última etapa, então redirecionamentos para o próximo convênio
                SiacPlugin.proximoConvenioConsultar();
            });
        });
    },
    conveiosStatusTela:function(){
        
        /**
         * Método de montagem de tela para o usuário ver o status do convênio
         */
        
        //recupera os convenios do local storage
        var convenios = [];
        for (var i = 0; i < localStorage.length - 4; i++) {
            var key = localStorage.key(i);
            var value = localStorage.getItem(key);
            convenios.push(JSON.parse(value));
        }
        
        //ordena pela data
        convenios.sort(function(a,b){
            return new Date(b.VL_DATA_ATUALIZACAO) - new Date(a.VL_DATA_ATUALIZACAO);
        });
        
        var convenio = SiacPlugin.convenioAtual();

        var linhas          = '';
        var quantidade      = 0;
        var nrConvenio      = convenio.NR_CONVENIO;
        var atualizadoClass = null;
        var atualizadoLabel = null
        
        for (var i in convenios) {
            if (SiacPlugin.convenioAtualizadoVerificar(convenios[i].VL_DATA_ATUALIZACAO)) {
                atualizadoClass = 'atualizado';
                atualizadoLabel = 'Atualizado';
                quantidade++;
            } else {
                atualizadoClass = 'pendente';
                atualizadoLabel = 'Pendente';
                //pega id do primeiro convênio pendente
                if (parseInt(nrConvenio) === parseInt(convenios[i].NR_CONVENIO)) {
                    //coloca o status como atualizando
                     atualizadoLabel = 'Atualizando...';
                }
            }
            linhas += `<li>Convênio ${convenios[i].NR_CONVENIO} <label class="${atualizadoClass}">${atualizadoLabel}</label> ${SiacPlugin.timestampTodata(convenios[i].VL_DATA_ATUALIZACAO)}</li>`;
        }

        $('body').after(`
            <div class="siac-box">
                <img src="https://upload.wikimedia.org/wikipedia/pt/thumb/4/43/SUDAM_Logo.png/250px-SUDAM_Logo.png"/>
                <h4>Atualizando o convênio ${nrConvenio} aguarde... ${quantidade} de ${convenios.length}</h4>
                <p>Você será redirecionado para o SIAC quando finalizado</p>
                <div class="siac-box-status">
                    <div class="scroll-box">
                        <ul>
                            ${linhas}
                        <ul>
                    </div>
                </div>
            </div>
        `);
        
        //espera X segundos para que o usuário consiva visualizar a tela de status antes da página ser redirecionada
        setTimeout(function(){

            //verifica se existe uma cláusula suspensiva
            if ($('input[name=editarDadosPropostaDetalharPropostaDetalharClausulaSuspensivaForm]').length > 0) {
                //redireciona para a clausula suspensiva
                $('input[name=editarDadosPropostaDetalharPropostaDetalharClausulaSuspensivaForm]').trigger("click");
            }else{
                //se não existir enviar para a tela das movimentações
                window.location.href = SiacPlugin.config.MANTER_MOVIMENTACAO;
            }

        }, 3000);;
    },
    cadastraMovimentacaoPlugin: function(dados, callback){
        /**
         * Método para cadastrar as movimentações financeiras
         */
        $.post(SiacPlugin.config.URL_API+'plugin-convenios.php?acao=cadastraMovimentacaoPlugin', {movimentacoes: dados}, function(resource){ 
            if(callback){
                callback(dados);
            }
        }, 'json');
    },
    cadastraConveioPlugin: function(dados, callback){
        /**
         * Método cadastrar os dados da cláusula suspensiva
         */
        $.post(SiacPlugin.config.URL_API+'plugin-convenios.php?acao=cadastraConveioPlugin', dados, function(resource){ 
            if(callback){
                callback(dados);
            }
        }, 'json');   
    },
    conveioDataAtualizarPlugin: function(nrConvenio, callback){
        /**
         * Método para informar que o convenio esta sendo atualizado 
         */
        $.post(SiacPlugin.config.URL_API+'plugin-convenios.php?acao=conveioDataAtualizarPlugin', {NR_CONVENIO:nrConvenio}, function(resource){ 
            if(callback){
                callback();
            }
        }, 'json');  
    },
    //### ---- Funções auxiliares ----###//
    
    dataAtual: function(){
        
        var dataAtual = new Date();
        var dia = dataAtual.getDate();
        var mes = dataAtual.getMonth() + 1;
        var ano = dataAtual.getYear();
        var hora = dataAtual.getHours();
        var minuto = dataAtual.getMinutes();
        var segundo = dataAtual.getSeconds();

        if (dia < 10) {
            dia = '0' + dia;
        }
        if (mes < 10) {
            mes = '0' + mes;
        }
        if (ano < 1000) {
            ano += 1900;
        }
        
        return ano + '-' + mes + '-' + dia;
    },
    convenioAtualizadoVerificar:function(data) {
        var dataAtual = new Date();
        var dia = dataAtual.getDate();
        var mes = dataAtual.getMonth() + 1;
        var ano = dataAtual.getYear();
        var hora = dataAtual.getHours();
        var minuto = dataAtual.getMinutes();
        var segundo = dataAtual.getSeconds();

        if (dia < 10) {
            dia = '0' + dia;
        }
        if (mes < 10) {
            mes = '0' + mes;
        }
        if (ano < 1000) {
            ano += 1900;
        }

        if (data && data.indexOf(ano + '-' + mes + '-' + dia) > -1) {
            return true
        } else {
            return false;
        }
    },
    timestampTodata: function(data) {
        if(data){
            
            return data.substring(8, 10)+'/'+data.substring(5, 7)+'/'+data.substring(0, 4);
            
//            var mydate = new Date(data + "T20:17:53.730Z");
//
//            var dia = mydate.getDate();
//            var mes = mydate.getMonth() + 1;
//            var ano = mydate.getYear();
//
//            if (mes < 10) {
//                mes = '0' + mes;
//            }
//            if (ano < 1000) {
//                ano += 1900
//            }
//
//            return `${dia}/${mes}/${ano}`;
        }else{
            return '';
        }
    }
};