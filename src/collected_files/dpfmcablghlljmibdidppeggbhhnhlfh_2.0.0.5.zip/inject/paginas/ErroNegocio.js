$(document).ready(function () {
   //inicia o processo de consulta
    SiacPlugin.proximoConvenioConsultar();
});