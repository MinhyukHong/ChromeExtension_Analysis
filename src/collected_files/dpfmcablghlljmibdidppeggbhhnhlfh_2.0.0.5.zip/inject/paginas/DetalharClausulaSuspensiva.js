$(document).ready(function(){
    //pega os dados da cláusula suspensiva
    SiacPlugin.clausulaSuspensiva();
});