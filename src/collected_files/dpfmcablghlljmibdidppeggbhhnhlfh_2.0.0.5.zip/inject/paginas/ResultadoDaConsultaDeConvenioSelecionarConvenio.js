$(document).ready(function () {
    //mostra a tela de status de atualização dos convênios
    SiacPlugin.conveiosStatusTela();
});


