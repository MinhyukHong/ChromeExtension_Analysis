$(document).ready(function(){
    //pega os dados da movimentação financeira
    SiacPlugin.movimentacaoFinanceira();
});