$(document).ready(function() {
    console.log('---'); 
    
    SiacPlugin.conveniosCarregar(function(convenios){
        //inicia o processo de consulta
        SiacPlugin.proximoConvenioConsultar();
    });
    
    console.log('+++'); 
});
