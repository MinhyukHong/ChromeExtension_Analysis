alert('Por favor, realize o login novamente.');
window.location.href = 'https://idp.convenios.gov.br/idp/';