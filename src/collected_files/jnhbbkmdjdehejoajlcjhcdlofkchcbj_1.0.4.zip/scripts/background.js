let isActive = true;
let whitelist = [];
let blacklist = [];
const domainMap = new Map();
const minersTabs = new Map();
const WHITE_LIST_KEY = 'whitelist';
const BLACKLIST_URL = 'https://en.insider.pro/media/files/blacklist.txt';
const FETCH_PERIOD = 30;
function getWhitelist() {
    return new Promise(resolve => {
        chrome.storage.sync.get({ [WHITE_LIST_KEY]: [] }, resolve);
    }).then(({ whitelist }) => whitelist);
}
function checkStatus(response) {
    if (response.status >= 200 && response.status < 300) {
        return response;
    }
    else {
        return new Error(response.statusText);
    }
}
function parseText(response) {
    if (response instanceof Error) {
        // throw??
        return Promise.resolve([]);
    }
    return response.text().then(text => text.split('\n').filter(text => text));
}
function fetchBlacklist(url) {
    return fetch(url)
        .then(checkStatus)
        .then(parseText);
}
function getBlacklist(url) {
    return fetchBlacklist(url)
        .catch(() => {
        console.warn(`Can't fetch blacklist from address ${url}. Using fallback.`);
        return fetch(chrome.runtime.getURL('blacklist.txt'))
            .then(parseText);
    });
}
function updateBlacklist(url) {
    return fetchBlacklist(url)
        .then(bl => blacklist = bl)
        .catch(() => {
        console.warn(`Can't update blacklist from address ${url}`);
    });
}
function saveWhitelist(list) {
    return new Promise(resolve => {
        chrome.storage.sync.set({ [WHITE_LIST_KEY]: list }, resolve);
    });
}
function isDomainWhitelisted(domain) {
    return domain ? whitelist.includes(domain) : false;
}
function addDomainToDomainMap(tabId, domain) {
    if (domain) {
        domainMap.set(tabId, domain);
    }
    return domainMap;
}
function getDomain(url) {
    let domain;
    try {
        domain = new URL(url).hostname;
    }
    catch (e) {
        domain = '';
    }
    return domain;
}
chrome.tabs.onUpdated.addListener((tabId, { status }, tab) => {
    if (tab.url) {
        addDomainToDomainMap(tabId, getDomain(tab.url));
    }
    if (status === 'loading') {
        minersTabs.set(tabId, false);
        if (isActive) {
            chrome.browserAction.setIcon({
                path: 'img/icon-128x128-green.png',
                tabId,
            });
        }
    }
});
chrome.tabs.onRemoved.addListener(tabId => {
    domainMap.delete(tabId);
    minersTabs.delete(tabId);
});
chrome.runtime.onMessage.addListener(({ tabId, type, url, add }, sender, sendResponse) => {
    const domain = url ? getDomain(url) : undefined;
    switch (type) {
        case 'TOGGLE_POWER':
            isActive = !isActive;
            break;
        case 'TOGGLE_WHITELIST': {
            if (add && domain) {
                if (!whitelist.includes(domain)) {
                    whitelist.push(domain);
                    saveWhitelist(whitelist);
                }
            }
            else {
                whitelist = whitelist.filter(url => url !== domain);
                saveWhitelist(whitelist);
            }
            break;
        }
        default: break;
    }
    sendResponse({
        isInWhitelist: isDomainWhitelisted(domain),
        isActive,
        minerDetected: minersTabs.get(tabId) || false,
    });
});
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    if (message === 'MINE_CONTROL_IS_INSTALLED') {
        sendResponse(true);
    }
});
chrome.runtime.onStartup.addListener(() => {
    getWhitelist().then(wl => whitelist = wl);
});
chrome.alarms.create({ periodInMinutes: FETCH_PERIOD, delayInMinutes: FETCH_PERIOD });
chrome.alarms.onAlarm.addListener(() => {
    updateBlacklist(BLACKLIST_URL);
});
Promise.all([
    getBlacklist(BLACKLIST_URL),
    getWhitelist(),
]).then(([bl, wl]) => {
    blacklist = bl;
    whitelist = wl;
    chrome.webRequest.onBeforeRequest.addListener(({ tabId }) => {
        minersTabs.set(tabId, true);
        if (!isActive) {
            chrome.browserAction.setIcon({
                path: 'img/icon-128x128-gray.png',
                tabId: tabId,
            });
            return { cancel: false };
        }
        if (isDomainWhitelisted(domainMap.get(tabId))) {
            chrome.browserAction.setIcon({
                path: 'img/icon-128x128-green-red.png',
                tabId: tabId,
            });
            return { cancel: false };
        }
        chrome.browserAction.setIcon({
            path: 'img/icon-128x128-red.png',
            tabId: tabId,
        });
        return { cancel: true };
    }, {
        urls: blacklist,
    }, ['blocking']);
});
