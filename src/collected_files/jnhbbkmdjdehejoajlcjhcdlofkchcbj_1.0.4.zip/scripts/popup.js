function getCurrentTab() {
    return new Promise(resolve => {
        chrome.tabs.query({ currentWindow: true, active: true }, tabs => resolve(tabs[0]));
    });
}
function sendMessage(message) {
    return new Promise(resolve => {
        chrome.runtime.sendMessage(message, resolve);
    });
}
function powerTitle(isOn) {
    return isOn ? chrome.i18n.getMessage('power_title_on') : chrome.i18n.getMessage('power_title_off');
}
function powerLabel(isOn) {
    return isOn ? chrome.i18n.getMessage('power_label_on') : chrome.i18n.getMessage('power_label_off');
}
function whitelistTitle(isOn) {
    return isOn ? chrome.i18n.getMessage('whitelist_title_on') : chrome.i18n.getMessage('whitelist_title_off');
}
function whitelistLabel(isOn) {
    return isOn ? chrome.i18n.getMessage('whitelist_label_on') : chrome.i18n.getMessage('whitelist_label_off');
}
function powerToggleTemplate(isOn) {
    return `
    <p class="power-title">${powerTitle(isOn)}</p>
    <input type="checkbox" class="switch" id="power" ${isOn ? 'checked' : ''}/>
    <label for="power" class="power-label">${powerLabel(isOn)}</label>`;
}
function whitelistToggleTemplate(isOn) {
    return `
    <p class="whitelist-title">${whitelistTitle(isOn)}</p>
    <input type="checkbox" class="switch" id="wlist" ${isOn ? 'checked' : ''}/>
    <label for="wlist" class="whitelist-label">${whitelistLabel(isOn)}</label>`;
}
function togglePowerText(isOn) {
    document.querySelector('.power-title').textContent = powerTitle(isOn);
    document.querySelector('.power-label').textContent = powerLabel(isOn);
}
function toggleWhitelistText(isOn) {
    document.querySelector('.whitelist-title').textContent = whitelistTitle(isOn);
    document.querySelector('.whitelist-label').textContent = whitelistLabel(isOn);
}
getCurrentTab().then(({ url, id }) => {
    sendMessage({
        type: 'INIT',
        tabId: id,
        url,
    }).then(({ isActive, isInWhitelist, minerDetected }) => {
        document.querySelector('.power').innerHTML = powerToggleTemplate(isActive);
        document.getElementById('power').addEventListener('change', ({ target: { checked } }) => {
            togglePowerText(checked);
            sendMessage({
                type: 'TOGGLE_POWER',
                isActive: checked,
            }).then(() => chrome.tabs.reload(id));
        });
        if (minerDetected) {
            document.querySelector('.wlist').innerHTML = whitelistToggleTemplate(isInWhitelist);
            document.getElementById('wlist').addEventListener('change', ({ target: { checked } }) => {
                toggleWhitelistText(checked);
                sendMessage({
                    type: 'TOGGLE_WHITELIST',
                    add: checked,
                    tabId: id,
                    url,
                }).then(() => chrome.tabs.reload(id));
            });
        }
    });
});
