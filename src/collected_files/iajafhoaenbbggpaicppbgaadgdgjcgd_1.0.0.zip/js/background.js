let control = {}
let modular = {}
let deploy  = {
    identity: { email: null, id: null },
    default: { background: '' },
    local: null
}

chrome.identity.getProfileUserInfo(null, function(userInfo) {
    if (userInfo.email && userInfo.id) {
        deploy.identity = userInfo
    }
})
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    // 阻止插件以外的调用
    if (chrome.runtime.id !== sender.id) { return }

    let message = { identity: deploy.identity, result: null }

    switch (request.command) {
        // modular deploy 全局配置（可以同步到google）
        case 'global': {
            chrome.storage.sync.get(['modular','deploy'], function(res) {
                modular = Object.assign({}, modular, res?.modular || {})
                deploy.local = Object.assign({}, deploy.default, res?.deploy || {})
                message.result = { deploy: deploy.local, modular }
                sendResponse(message)
            })
            break
        }
        case 'modular': {
            chrome.storage.sync.get('modular', function(res) {
                modular = Object.assign({}, modular, res || {})
                message.result = modular
                sendResponse(message)
            })
            break
        }
        case 'change modular': {
            modular = request.value || {}
            chrome.storage.sync.set({ modular }, function() {
                message.result = modular
                sendResponse(message)
            })
            break
        }
        case 'deploy': {
            chrome.storage.sync.get('deploy', function(res) {
                deploy.local = Object.assign({}, deploy.default, res || {})
                message.result = deploy.local
                sendResponse(message)
            })
            break
        }
        case 'change deploy': {
            deploy.local = Object.assign({}, deploy.default, request.value || {})
            chrome.storage.sync.set({deploy: deploy.local}, function() {
                message.result = deploy.local
                sendResponse(message)
            })
            break
        }
        case 'control': {
            chrome.storage.local.get('control', function(res) {
                control = Object.assign({...control}, res?.control || {})
                message.result = control
                sendResponse(message)
            })
            break
        }
        case 'change control': {
            control = request.value || {}
            chrome.storage.local.set({ control }, function() {
                message.result = control
                sendResponse(message)
            })
            break
        }
        default: { sendResponse(message) }
    }
    return true
})