;define("6c363ac", function (e, t, n) {
    "use strict";
    function i(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var r = e("6cfeef6"), a = i(r), u = e("3eddb2a"), o = i(u), f = e("c75ffe0"), s = i(f), c = e("621bc70"), d = e("6bafc50"), l = i(d), p = e("8724bbb"), h = i(p);
    t.default = {
        store: l.default, data: function () {
            return {is: "app", type: ""}
        }, computed: s.default({}, c.mapState({
            weixinConfigDone: function (e) {
                return e.weixin.weixinConfigDone
            }
        })), watch: {
            $route: function () {
                var e = this.$router.isBack, t = "slide-left";
                e && (t = "slide-right"), this.type = t, this.$router.isBack = !1, this.weixinConfigDone && h.default(this.$route.path)
            }
        }, mounted: function () {
            var e = this;
            return o.default(a.default.mark(function t() {
                return a.default.wrap(function (t) {
                    for (; ;)switch (t.prev = t.next) {
                        case 0:
                            if (e.weixinConfigDone) {
                                t.next = 4;
                                break
                            }
                            return t.next = 3, e.$store.dispatch("weixinConfig");
                        case 3:
                            h.default(e.$route.path);
                        case 4:
                        case"end":
                            return t.stop()
                    }
                }, t, e)
            }))()
        }
    };
    var w = '<div class="app">\n    <transition :name="type">\n        <router-view class="router-view"></router-view>\n    </transition>\n</div>';
    n && n.exports && (n.exports.template = w), t && t.default && (t.default.template = w), n.exports = t["default"]
});
;define("29921ff", function (e, t, u) {
    "use strict";
    function f(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var d = e("6c363ac"), a = f(d);
    t.default = a.default, u.exports = t["default"]
});
;define("aed8871", function (t, e, i) {
    "use strict";
    function s(t) {
        return t && t.__esModule ? t : {"default": t}
    }

    Object.defineProperty(e, "__esModule", {value: !0});
    var n = t("c75ffe0"), a = s(n), o = t("cece673"), c = t("621bc70"), l = t("b7e47cd"), p = (s(l), t("6bafc50")), r = s(p), u = t("c3e5ef7"), d = t("8a67f20"), h = s(d);
    e.default = {
        store: r.default, data: function () {
            return {
                petId: "",
                channel: "",
                captcha: "",
                popupVisible: !1,
                isDisabled: !1,
                isSmsCodeDisable: !0,
                inputSmsVal: "",
                isAndiord: !/iphone/i.test(navigator.userAgent)
            }
        }, watch: {
            inputSmsVal: function (t) {
                return this.captcha = t, /[\da-zA-Z]{4}/i.test(t) ? void(this.isSmsCodeDisable = !1) : void(this.isSmsCodeDisable = !0)
            }, "smsInfo.img": function () {
                this.popupVisible = !0
            }
        }, computed: a.default({}, c.mapState({
            petInfo: function (t) {
                return t.detail.petInfo
            }, smsInfo: function (t) {
                return t.detail.smsInfo
            }
        }), {
            hasPetInfo: function () {
                return Object.keys(this.petInfo).length >= 10
            }, saleVisible: function () {
                return "center" === this.channel
            }, unsaleVisible: function () {
                return "center" === this.channel
            }, buyVisible: function () {
                return "market" === this.channel
            }, noRefer: function () {
                return history.length <= 2
            }
        }), methods: {
            throttle: function (t, e) {
                var i = this;
                return function () {
                    clearTimeout(i.timer), i.timer = setTimeout(function () {
                        t.apply(i)
                    }, e)
                }
            }, showBuyPetPop: function () {
                this.isSmsCodeDisable = !0, this.isDisabled || this.throttle(this.refreshCode.bind(this), 400)()
            }, refreshCode: function () {
                this.$store.dispatch("detailSmsInfo")
            }, showSalePetPop: function () {
                var t = this;
                this.isDisabled || o.MessageBox.prompt(" ", "设置卖出价格", {
                    inputErrorMessage: "",
                    confirmButtonClass: "detail-sale-sure",
                    cancelButtonClass: "detail-sale-cancel",
                    inputPlaceholder: "0.00微",
                    inputValidator: function (t) {
                        return +t ? /^\d{1,9}$|^\d{1,9}\.\d{0,2}$/g.test(t) ? void 0 : "格式有误，请重新输入" : "请输入卖出价格"
                    }
                }).then(function (e) {
                    if (e.value) {
                        var i = e.value;
                        u.api.sale({petId: t.petId, amount: i}).then(function (e) {
                            var i = t;
                            0 === +e.errorNo && (t.isDisabled = !0, o.Toast({
                                message: "发布成功",
                                position: "center",
                                duration: 2e3,
                                className: "app-toast",
                                iconClass: "icon-right icon-font"
                            }), setTimeout(function () {
                                i.$router.push({
                                    path: "/chain/personal",
                                    query: {t: +new Date, appId: i.$route.query.appId, tpl: i.$route.query.tpl}
                                })
                            }, 1e3))
                        })
                    }
                })
            }, close: function () {
                this.popupVisible = !1
            }, buyPet: function () {
                var t = this;
                u.api.buy({
                    petId: this.petId,
                    amount: this.petInfo.amount,
                    seed: this.smsInfo.seed,
                    captcha: this.inputSmsVal,
                    validCode: this.$route.query.validCode
                }).then(function (e) {
                    var i = t;
                    t.popupVisible = !1, t.inputSmsVal = "", t.$store.commit("DETAIL_SMS_INFO_CLEAR"), 0 === +e.errorNo ? (t.isDisabled = !0, o.Toast({
                        message: "订单已提交",
                        position: "center",
                        duration: 2e3,
                        className: "app-toast",
                        iconClass: "icon-right icon-font"
                    }), setTimeout(function () {
                        i.$router.push({
                            path: "/chain/personal?type=order",
                            query: {t: +new Date, appId: i.$route.query.appId, tpl: i.$route.query.tpl}
                        })
                    }, 1500)) : t.isSmsCodeDisable = !0
                }).catch(function (e) {
                    e.data && 10012 === +e.data.errorNo && (t.isDisabled = !0), t.popupVisible = !1, t.inputSmsVal = "", t.isSmsCodeDisable = !0
                })
            }, unsalePet: function () {
                var t = this;
                this.isDisabled || o.MessageBox.confirm(" ", "提示", {
                    message: "确定撤销卖出吗？",
                    confirmButtonClass: "app-sure",
                    cancelButtonClass: "app-cancel",
                    inputPlaceholder: "0.000微"
                }).then(function () {
                    u.api.cancelSale({petId: t.petId}).then(function (e) {
                        var i = t;
                        0 === +e.errorNo && (t.isDisabled = !0, o.Toast({
                            message: "撤销成功",
                            position: "center",
                            duration: 2e3,
                            className: "app-toast",
                            iconClass: "icon-right icon-font"
                        }), setTimeout(function () {
                            i.$router.push({
                                path: "/chain/personal",
                                query: {t: +new Date, appId: i.$route.query.appId, tpl: i.$route.query.tpl}
                            })
                        }, 1500))
                    })
                })
            }, toast: function (t) {
                o.Toast({message: t, position: "center", duration: 2e3, className: "app-toast"})
            }, checkSimple: function () {

                var t = this;
                // alert(this.isSmsCodeDisable);
                t.buyPet();
                // this.isSmsCodeDisable || (/SearchCraft/gi.test(navigator.userAgent) ? this.throttle(this.buyPet.bind(this), 400)() : this.throttle(function () {
                //     u.api.shouldJump2JianDan().then(function (e) {
                //         !/SearchCraft/gi.test(navigator.userAgent) && e.data && (location.href = "https://jr.baidu.com/~2dQzmG"), t.buyPet()
                //     })
                // }, 400)())
            }, "goto": function (t) {
                switch (t) {
                    case"back":
                        this.$router.go(-1);
                        break;
                    case"home":
                        this.$router.push({
                            path: "/chain/dogMarket",
                            query: {t: +new Date, appId: this.$route.query.appId, tpl: this.$route.query.tpl}
                        })
                }
            }
        }, mounted: function () {
            h.default(this, {
                petId: this.$route.query.petId,
                channel: this.$route.query.channel
            }), "center" === this.channel ? this.$store.dispatch("detailPetInfoWithAuth", {petId: this.petId}) : this.$store.dispatch("detailPetInfo", {petId: this.petId})
        }, destroyed: function () {
            this.$store.commit("DETAIL_CLEAR")
        }
    };
    var f = '<section class="detail">\n    <div class="dog-img" v-bind:class="{\'onchain\': saleVisible&amp;&amp;!petInfo.isOnChain}" v-bind:style="{backgroundColor: petInfo.bgColor}">\n        <div v-if="noRefer" class="option home" @click="goto(\'home\')">\n            <i class="home"></i>\n        </div>\n        <div v-if="!noRefer&amp;&amp;isAndiord" class="option back" @click="goto(\'back\')">\n            <i class="black icon-font icon-back"></i>\n        </div>\n        <div class="img-box">\n            <img v-if="petInfo.isOnChain &amp;&amp; petInfo.petUrl" :src="petInfo.petUrl" onerror="this.src=\'http://blockchain-pet-online.bj.bcebos.com/vip_185089739579405926420180202112326\'" alt="">\n        </div>\n    </div>\n    <div class="info-main" v-if="hasPetInfo">\n        <div class="tag-info">\n            <i class="rareDegree tag b0">{{petInfo.rareDegree}}</i>\n            <i class="generation tag b1">第{{petInfo.generation}}代</i>\n        </div>\n        <h1 class="name f24">{{petInfo.name}} {{petInfo.id | petId}}</h1>\n        <p class="price" v-if="buyVisible&amp;&amp;+petInfo.amount">{{petInfo.amount}}微</p>\n    </div>\n    <div class="usr" v-if="hasPetInfo">\n        <div class="info">\n            <p class="f16">{{petInfo.userName}}</p>\n            <p class="f14 c2">所有者</p>\n        </div>\n        <div class="icon">\n            <img class="head-icon" :src="petInfo.headIcon" alt="">\n        </div>\n    </div>\n    <div class="attr" v-if="hasPetInfo">\n        <h2 class="f18">属性</h2>\n        <ul class="list">\n            <li v-for="item in petInfo.attributes">\n                {{item.name}}：{{item.value}}<font v-show="item.rareDegree">{{item.rareDegree}}</font>\n            </li>\n        </ul>\n    </div>\n    <div v-if="hasPetInfo">\n        <div id="showBugPop" v-if="buyVisible&amp;&amp;+petInfo.selfStatus" class="button" v-bind:class="{disable: isDisabled}" @click="showBuyPetPop">确认购买</div>\n        <div v-if="saleVisible&amp;&amp;!+petInfo.selfStatus&amp;&amp;petInfo.isOnChain" v-bind:class="{disable: isDisabled}" class="button" @click="showSalePetPop()">卖出</div>\n        <div v-if="saleVisible&amp;&amp;!petInfo.isOnChain" class="button disable">区块链写入中，请稍候再试</div>\n        <div v-if="unsaleVisible&amp;&amp;+petInfo.selfStatus" class="button handling" v-bind:class="{disable: isDisabled}" @click="unsalePet">取消卖出</div>\n    </div>\n    <mt-popup v-model="popupVisible" position="bottom">\n        <i class="close icon-close icon-font" @click="close"></i>\n        <div class="contain">\n            <p class="c0 f32"><font class="cut1">{{petInfo.amount}}</font>微</p>\n            <p class="c2 f14">额外收取5微左右的手续费</p>\n            <div class="sms-verify">\n                <div class="sms-input">\n                    <input v-model="inputSmsVal" placeholder="请输入验证码" maxlength="4" type="text">\n                </div>\n                <div class="sms-img" @click="refreshCode">\n                    <img :src="\'data:image/jpeg;base64,\' + smsInfo.img" width="100%" height="100%" alt="">\n                    <i class="icon-font icon-shuaxin"></i>\n                </div>\n            </div>\n            <div class="button" v-bind:class="{disable: isSmsCodeDisable}" @click="checkSimple">立即购买</div>\n        </div>\n    </mt-popup>\n</section>';

    i && i.exports && (i.exports.template = f), e && e.default && (e.default.template = f), i.exports = e["default"];
});
;define("96f1c13", function (e, t, u) {
    "use strict";
    function d(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var f = e("aed8871"), a = d(f);
    t.default = a.default, u.exports = t["default"]
});
;define("a5ae409", function (t, e, r) {
    "use strict";
    function a(t) {
        return t && t.__esModule ? t : {"default": t}
    }

    Object.defineProperty(e, "__esModule", {value: !0});
    var n, o = t("6cfeef6"), f = a(o), u = t("3eddb2a"), d = a(u), i = t("d918814"), c = a(i), s = t("c3e5ef7");
    e.default = {
        state: {petInfo: {isOnChain: !0, petUrl: ""}, smsInfo: {}},
        mutations: (n = {}, c.default(n, "DETAIL_PET_INFO", function (t, e) {
            t.petInfo = e
        }), c.default(n, "DETAIL_CLEAR", function (t) {
            t.petInfo = {isOnChain: !0, petUrl: ""}
        }), c.default(n, "DETAIL_SMS_INFO", function (t, e) {
            t.smsInfo = e
        }), c.default(n, "DETAIL_SMS_INFO_CLEAR", function (t) {
            t.smsInfo = {}
        }), n),
        actions: {
            detailPetInfo: function (t, e) {
                var r = this;
                return d.default(f.default.mark(function a() {
                    var n;
                    return f.default.wrap(function (r) {
                        for (; ;)switch (r.prev = r.next) {
                            case 0:
                                return r.next = 2, s.api.getPetInfo(e);
                            case 2:
                                n = r.sent, 0 === +n.errorNo || n.data && 0 === +n.data.errorNo ? t.commit("DETAIL_PET_INFO", n.data) : n.data && 1 === +n.data.errorNo && (location.href = "/error");
                            case 4:
                            case"end":
                                return r.stop()
                        }
                    }, a, r)
                }))()
            }, detailPetInfoWithAuth: function (t, e) {
                var r = this;
                return d.default(f.default.mark(function a() {
                    var n;
                    return f.default.wrap(function (r) {
                        for (; ;)switch (r.prev = r.next) {
                            case 0:
                                return r.next = 2, s.api.getPetInfoWithAuth(e);
                            case 2:
                                n = r.sent, 0 === +n.errorNo || n.data && 0 === +n.data.errorNo ? t.commit("DETAIL_PET_INFO", n.data) : n.data && 1 === +n.data.errorNo && (location.href = "/error");
                            case 4:
                            case"end":
                                return r.stop()
                        }
                    }, a, r)
                }))()
            }, detailSmsInfo: function (t, e) {
                var r = this;
                return d.default(f.default.mark(function a() {
                    var n;
                    return f.default.wrap(function (r) {
                        for (; ;)switch (r.prev = r.next) {
                            case 0:
                                return r.next = 2, s.api.getCode(e);
                            case 2:
                                n = r.sent, 0 === +n.errorNo || n.data && 0 === +n.data.errorNo ? t.commit("DETAIL_SMS_INFO", n.data) : n.data && 1 === +n.data.errorNo && (location.href = "/error");
                            case 4:
                            case"end":
                                return r.stop()
                        }
                    }, a, r)
                }))()
            }
        }
    }, r.exports = e["default"]
});
;define("868f976", function (t, e, n) {
    "use strict";
    function o(t) {
        return t && t.__esModule ? t : {"default": t}
    }

    Object.defineProperty(e, "__esModule", {value: !0});
    var a = t("6cfeef6"), s = o(a), r = t("3eddb2a"), i = o(r), d = t("c75ffe0"), l = o(d), c = t("e3a0dda"), u = o(c), p = t("621bc70"), f = t("7b6a2c2"), m = o(f), g = t("cece673"), h = t("9368b99"), v = o(h), b = t("6bafc50"), k = o(b);
    e.default = {
        store: k.default,
        data: function () {
            return {allLoaded: !1, loaded: !1}
        },
        components: {ListDog: v.default, Spinner: g.Spinner, loadmore: m.default},
        computed: l.default({}, p.mapState({
            pets: function (t) {
                return t.dogMarket.pets
            }, sort: function (t) {
                return t.dogMarket.sort
            }, noData: function (t) {
                return t.dogMarket.noData
            }
        }), {
            getSplashLink: function () {
                return "/chain/splash?appId=" + (this.$route.query.appId || "") + "&tpl=" + (this.$route.query.tpl || "")
            }, module: function () {
                return this.$store.state.dogMarket
            }
        }),
        methods: {
            refresh: function () {
                var t = "AMOUNT";
                var e = this, n = this.module.sort;
                n[t] && (n[t] = "ASC", this.$store.commit("DOG_MARKET_CLEAR"), this.$nextTick(function () {
                    e.$store.commit("QUERY_SORT_SOURCE_TYPE", n), e.$store.commit("QUERY_SORT_TYPE", t + "_" + n[t])
                }), this.loadMore(function () {
                    return e.scrollTo()
                }))
            },
            sortBy: function (t) {
                var e = this, n = this.module.sort;
                n[t] && (n[t] = "ASC" === n[t] ? "DESC" : "ASC", this.$store.commit("DOG_MARKET_CLEAR"), this.$nextTick(function () {
                    e.$store.commit("QUERY_SORT_SOURCE_TYPE", n), e.$store.commit("QUERY_SORT_TYPE", t + "_" + n[t])
                }), this.loadMore(function () {
                    return e.scrollTo()
                }))
            }, loadMore: function (t) {
                var e = this;
                this.$nextTick(i.default(s.default.mark(function n() {
                    var o, a;
                    return s.default.wrap(function (n) {
                        for (; ;)switch (n.prev = n.next) {
                            case 0:
                                return o = e.$store.state.dogMarket, a = o.pageNo, a++, n.next = 5, e.$store.dispatch("dogMarKetList", {pageNo: a});
                            case 5:
                                if (1 === a && 0 === e.pets.petsOnSale.length && e.$store.commit("DOG_MARKET_NO_DATA", !0), e.$refs.loadmore && e.$refs.loadmore.onBottomLoaded(t || 0), e.$store.commit("PAGE_NO", a), o.pets.hasData) {
                                    n.next = 12;
                                    break
                                }
                                if (!(a > 1)) {
                                    n.next = 11;
                                    break
                                }
                                return n.abrupt("return", g.Toast({message: "没有更多数据了", duration: 2e3}));
                            case 11:
                                return n.abrupt("return", e.loaded = !0);
                            case 12:
                                e.allLoaded = !0, "function" == typeof t && t();
                            case 14:
                            case"end":
                                return n.stop()
                        }
                    }, n, e)
                })))
            }, jumpTo: function (t, e) {
                e.preventDefault(), this.$router.push({
                    path: "/chain/" + t,
                    query: {t: +new Date, appId: this.$route.query.appId, tpl: this.$route.query.tpl}
                })
            }, scrollTo: function () {
                var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
                setTimeout(function () {
                    window.scrollTo(e, n)
                }, 10), this.$nextTick(function () {
                    t.loaded = !0
                })
            }
        },
        beforeCreate: function () {
        },
        mounted: function () {
            var t = this;
            this.pets.petsOnSale.length ? this.loaded = !0 : this.loadMore(function () {
                return t.scrollTo()
            }), window.addEventListener("scroll", u.default.debounce(function () {
                var e = t.$refs["header-inner"];
                if (e && e.getBoundingClientRect()) {
                    var n = e.getBoundingClientRect();
                    e.style.position = window.pageYOffset - n.top > 0 ? "fixed" : ""
                }
            }, 10))
        }
    };
    var T = '<section class="dog-market">\n    <div id="slogan">\n        <router-link :to="getSplashLink">\n            <img src="/static/pkg/image/page/DogMarket/img/adi_d3c93dc.png" width="100%">\n        </router-link>\n    </div>\n    <header>\n        <div class="header-inner" ref="header-inner">\n            <h2 @click="refresh()">刷新</h2>\n            <div class="sort">\n                <span @click="sortBy(\'RAREDEGREE\')">稀有度<b :class="sort.RAREDEGREE" class="filter"></b></span>\n                <span @click="sortBy(\'AMOUNT\')">价格<b :class="sort.AMOUNT" class="filter"></b></span></div>\n        </div>\n    </header>\n    <div class="spinner-loading" v-show="!loaded">\n        <spinner color="#666" class="loading" type="fading-circle"></spinner>\n        <p>数据加载中,请稍后...</p>\n    </div>\n    <div class="no-data" v-if="noData">\n        <img src="/static/pkg/image/static/img/empty_b3e0548.png" width="105">\n        <div class="info">\n            <p>狗狗都回家了</p>\n            <p>迟点再来看看吧</p>\n        </div>\n    </div>\n    <div class="pull-list scroller" v-else="">\n        <mt-loadmore :bottom-method="loadMore" :auto-fill="false" :bottom-distance="20" ref="loadmore">\n            <list-dog :list="pets.petsOnSale" :bottom-all-loaded="allLoaded" channel="market">\n            </list-dog>\n        </mt-loadmore>\n    </div>\n    <div class="toolbar-wrapper">\n        <div class="toolbar">\n            <div class="toolbar-inner">\n                <div @click.stop="jumpTo(\'dogMarket\', $event)">\n                    <span class="icon icon-font icon-market_p current"></span><b class="current-b">狗狗集市</b>\n                </div>\n                <div @click.stop="jumpTo(\'personal\', $event)">\n                    <span class="icon icon-font icon-personage"></span><b>我的狗窝</b>\n                </div>\n            </div>\n        </div>\n    </div>\n</section>';
    n && n.exports && (n.exports.template = T), e && e.default && (e.default.template = T), n.exports = e["default"]
});
;define("990a4d5", function (e, t, u) {
    "use strict";
    function d(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var f = e("868f976"), a = d(f);
    t.default = a.default, u.exports = t["default"]
});
;define("8c09f0f", function (e, t, a) {
    "use strict";
    function n(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var u, r = e("6cfeef6"), s = n(r), o = e("c75ffe0"), f = n(o), l = e("3eddb2a"), p = n(l), c = e("d918814"), i = n(c), d = e("c3e5ef7");
    t.default = {
        state: {
            pageNo: 0,
            pageSize: 20,
            sort: {AMOUNT: "DESC", RAREDEGREE: "DESC"},
            querySortType: "RAREDEGREE_DESC",
            pets: {petsOnSale: []},
            noData: !1
        }, mutations: (u = {}, i.default(u, "DOG_MARKET_CLEAR", function (e) {
            e.pageNo = 0, e.pets = {hasData: !0, petsOnSale: []}
        }), i.default(u, "DOG_MARKET_PETS", function (e, t) {
            var a = t.petsOnSale, n = void 0 === a ? [] : a;
            t.petsOnSale = e.pets.petsOnSale.concat(n), e.pets = t
        }), i.default(u, "QUERY_SORT_TYPE", function (e, t) {
            e.querySortType = t
        }), i.default(u, "QUERY_SORT_SOURCE_TYPE", function (e, t) {
            e.sort = t
        }), i.default(u, "PAGE_NO", function (e, t) {
            e.pageNo = t
        }), i.default(u, "DOG_MARKET_NO_DATA", function (e, t) {
            e.noData = t
        }), u), actions: {
            dogMarKetList: function (e) {

                var t = this, a = e.commit, n = e.state, u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return p.default(s.default.mark(function r() {
                    var e, o, l, p, c, i, E, S, O, _, R;
                    return s.default.wrap(function (t) {
                        for (; ;)switch (t.prev = t.next) {
                            case 0:
                                return e = n.pageNo, o = n.pageSize, l = n.querySortType, p = {}, c = "", i = "", n.pets.petsOnSale && (E = n.pets.petsOnSale, S = E[E.length - 1] || [], E.slice(-(2 * o)).forEach(function (e) {
                                    var t = e.petId;
                                    p[t] = ""
                                }), c = S.amount || null, i = S.rareDegree || null), u = f.default({}, {
                                    pageNo: e,
                                    pageSize: o,
                                    querySortType: l,
                                    petIds: Object.keys(p),
                                    lastAmount: c,
                                    lastRareDegree: i
                                }, u), t.next = 8, d.api.queryPetsOnSale(u);
                            case 8:
                                O = t.sent, _ = O.data, R = void 0 === _ ? {} : _, a("DOG_MARKET_PETS", R);
                            case 12:
                            case"end":
                                return t.stop()
                        }
                    }, r, t)
                }))()
            }
        }
    }, a.exports = t["default"]
});
;define("bc67c61", function (e, t, p) {
    "use strict";
    function r(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var u = e("2c3701f"), n = r(u);
    t.default = {
        data: function () {
            return {is: "Error"}
        }, components: {Empty: n.default}
    };
    var a = '<div>\n    <empty type="500" msg="<p>狗狗找不到回家的路了</p><p>请稍后再试～</p>"></empty>\n</div>';
    p && p.exports && (p.exports.template = a), t && t.default && (t.default.template = a), p.exports = t["default"]
});
;define("366fa26", function (e, t, u) {
    "use strict";
    function f(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var d = e("bc67c61"), a = f(d);
    t.default = a.default, u.exports = t["default"]
});
;define("f93105a", function (t, e, l) {
    "use strict";
    function i(t) {
        return t && t.__esModule ? t : {"default": t}
    }

    Object.defineProperty(e, "__esModule", {value: !0});
    var s = t("c75ffe0"), n = i(s), o = t("621bc70"), a = t("cece673"), u = t("6bafc50"), c = i(u);
    e.default = {
        store: c.default, computed: n.default({}, o.mapState({
            list: function (t) {
                return t.helloWorld.list
            }
        })), methods: {
            listItem: function (t) {
                a.Toast({message: "This is " + this.list[t], position: "center", duration: 1e3})
            }, removeCell: function () {
                var t = Math.random() * (this.list.length + 1);
                this.list.splice(t, 1)
            }
        }, mounted: function () {
            this.$store.dispatch("list", {a: 1})
        }
    };
    var d = '<div>\n    <div v-for="(val, key) in list" :key="key" @click="listItem(key)">\n        <mt-cell>{{ val }}</mt-cell>\n    </div>\n    <mt-button @click="removeCell">删除列表项</mt-button>\n</div>';
    l && l.exports && (l.exports.template = d), e && e.default && (e.default.template = d), l.exports = e["default"]
});
;define("c449fe2", function (e, t, u) {
    "use strict";
    function f(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var d = e("f93105a"), a = f(d);
    t.default = a.default, u.exports = t["default"]
});
;define("e12a4c7", function (e, t, a) {
    "use strict";
    function n(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var u = e("6cfeef6"), r = n(u), i = e("3eddb2a"), s = n(i), f = e("d918814"), c = n(f), d = e("c3e5ef7");
    t.default = {
        state: {list: []}, mutations: c.default({}, "LIST", function (e, t) {
            e.list = t
        }), actions: {
            list: function (e, t) {
                var a = this, n = e.commit;
                return s.default(r.default.mark(function u() {
                    var e, i, s;
                    return r.default.wrap(function (a) {
                        for (; ;)switch (a.prev = a.next) {
                            case 0:
                                return a.next = 2, d.api.getList(t);
                            case 2:
                                e = a.sent, i = e.data, s = void 0 === i ? {} : i, n("LIST", s);
                            case 6:
                            case"end":
                                return a.stop()
                        }
                    }, u, a)
                }))()
            }
        }
    }, a.exports = t["default"]
});
;define("a61a906", function (e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {value: !0});
    e("c3e5ef7");
    t.default = {state: {}, mutations: {}, actions: {}}, a.exports = t["default"]
});
;define("c874910", function (n, s, e) {
    "use strict";
    function a(n) {
        return n && n.__esModule ? n : {"default": n}
    }

    Object.defineProperty(s, "__esModule", {value: !0});
    {
        var t = n("c75ffe0"), i = a(t), c = n("621bc70"), p = n("a61a906"), d = a(p);
        n("cece673")
    }
    s.default = {
        store: d.default, data: function () {
            return {is: "introduce"}
        }, computed: i.default({}, c.mapState([])), methods: {
            goPersonal: function () {
                this.$router.go(-1)
            }
        }, created: function () {
        }, mounted: function () {
        }
    };
    var o = '<div>\n    <section class="introduce">\n        <div class="introduce-bg">\n            <span class="back" @click="goPersonal()"><i class="icon icon-font icon-back"></i></span>\n            <span class="dog-image"></span>\n        </div>\n        <h2 class="title">我是谁?</h2>\n        <div class="info">\n            <p>汪汪汪~</p>\n            <p>我是区块链赋能的莱茨狗。</p>\n            <p>我的小伙伴们，每只都有独一无二的基因。</p>\n            <p>一旦你拥有了我，我们的关系将被永远记录在区块链上，任何人都不能改变。</p>\n            <p>我有8个外貌特征，每个特征有两种不同的属性：稀有属性和普通属性。这些属性组合起来，将会决定我最终的稀有等级（普通、稀有、卓越、史诗、神话、传说）。</p>\n        </div>\n        <h2 class="title">你要怎么玩儿？</h2>\n        <div class="info">\n            <p>你可以在市场中，通过数字积分—微积分，购买你心仪的莱茨狗。</p>\n            <p>你也能在个人中心，查看并出售你所拥有的莱茨狗。</p>\n        </div>\n        <h2 class="title">开发团队</h2>\n        <div class="info">\n            <p>百度金融区块链实验室，拥有完整的企业级区块链解决方案，以及面向用户的应用级区块链解决方案。该实验室深入底层技术、平台化、区块链应用以及前瞻性领域研究，目前的技术已应用于多条核心业务线，支撑了超500亿元资产的真实性问题。同时，该实验室也是Hyperledger的核心董事会成员，致力于提升区块链行业的技术发展，推动全球区块链技术规范和标准的建立。</p>\n        </div>\n        <div class="tips">\n            <h3>特别提示:</h3>\n            <div class="col">\n                <span>01.</span>\n                <p>点击免费领取后，系统将通过区块链，把属于你的狗狗和微积分发放到你的账户中。当领取人数较多时，写入区块链时间可能较长，请耐心等待。</p>\n                </div>\n            <div class="col">\n                <span>02.</span>\n                <p>当你提交购买订单后，由于订单需要写入区块链，将要一段交易确认时间。待交易确认后，才能在“我的狗窝”看到你所购买的莱茨狗。</p>\n            </div>\n            <div class="col">\n                <span>03.</span>\n                <p>当你在购买莱茨狗时，需扣除5微积分左右的手续费，用于支付写入区块链所需算力资源的消耗。因此，你的微积分余额必须大于【狗狗出售价格与手续费之和】，才能成功发起购买。实际收取的费用将由具体消耗的算力决定，待交易成功后，可在我的订单中查看。</p>\n            </div>\n        </div>\n    </section>\n</div>';
    e && e.exports && (e.exports.template = o), s && s.default && (s.default.template = o), e.exports = s["default"]
});
;define("1c0139f", function (e, t, u) {
    "use strict";
    function f(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var d = e("c874910"), l = f(d);
    t.default = l.default, u.exports = t["default"]
});
;define("926ded0", function (e, t, d) {
    "use strict";
    function u(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var n = e("2c3701f"), o = u(n);
    t.default = {
        data: function () {
            return {is: "NotFound"}
        }, methods: {}, components: {Empty: o.default}
    };
    var a = '<div>\n    <empty type="404" msg="<p>哎哟，该页面好像不存在哟～</p>"></empty>\n</div>';
    d && d.exports && (d.exports.template = a), t && t.default && (t.default.template = a), d.exports = t["default"]
});
;define("8536207", function (e, t, u) {
    "use strict";
    function d(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var f = e("926ded0"), l = d(f);
    t.default = l.default, u.exports = t["default"]
});
;define("3b4659a", function (e, t, n) {
    "use strict";
    function o(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var a = e("6cfeef6"), s = o(a), r = e("3eddb2a"), i = o(r), d = e("c75ffe0"), c = o(d), l = e("e3a0dda"), u = (o(l), e("621bc70")), p = e("6bafc50"), f = o(p), g = e("7b6a2c2"), m = o(g), h = e("1d94572"), v = o(h), b = e("9368b99"), y = o(b), L = e("2c3701f"), k = o(L), x = e("95cd1e2"), T = e("cece673"), I = e("c3e5ef7"), M = e("eba5767");
    t.default = {
        store: f.default,
        components: {
            Order: v.default,
            ListDog: y.default,
            MessageBox: T.MessageBox,
            Empty: k.default,
            Spinner: T.Spinner,
            loadmore: m.default
        },
        data: function () {
            return {
                status: {1: "已卖出", 2: "已买入"},
                activeTab: "my-dog",
                messageBox: !1,
                hasNext: !0,
                isLogin: !1,
                userInfo: {},
                allLoadedPets: !1,
                allLoadedOrders: !1,
                loaded: !1,
                emptyPets: !1,
                emptyOrders: !1,
                initLoading: !0
            }
        },
        computed: c.default({}, u.mapState({
            pets: function (e) {
                return e.personal.pets
            }, orders: function (e) {
                return e.personal.orders
            }
        }), {
            module: function () {
                return this.$store.state.personal
            }, isMyPets: function () {
                return "my-dog" == this.activeTab
            }, isMyOrders: function () {
                return "order" == this.activeTab
            }, getUserInfo: function () {
                return this.isLogin ? this.userInfo.userName : "未登录"
            }, getUserHeadIcon: function () {
                if (this.isLogin) {
                    var e = [];
                    return e.push('<div class="headIcon">'), e.push("<i v-bind:style=\"{backgroundImage: 'url("), e.push(this.userInfo.headIcon || ""), e.push(")', backgroundSize: '105%', backgroundPosition: 'center'}\"></i>"), e.push("</div>"), e.join("")
                }
                return '<span class="default-img"></span>'
            }, getAmount: function () {
                return this.isLogin ? this.userInfo.amount + " 微积分" : "登录后领养莱茨狗"
            }
        }),
        methods: {
            tabClick: function (e) {
                var t = this, n = function () {
                    t.initLoading = !1, t.loaded = !0, setTimeout(function () {
                        return t.fixedHeader()
                    }, 100), t.scrollTo()
                };
                "my-dog" == e ? (this.activeTab = "my-dog", this.isLogin && 0 == this.pets.page.pageNo && (this.initLoading = !0, this.loadMorePets(1, n))) : "order" == e && (this.activeTab = "order", this.isLogin && 0 == this.orders.page.pageNo && (this.initLoading = !0, this.loadMoreOrders(1, n)))
            }, logout: function () {
                /baiduhi/g.test(navigator.userAgent) || T.MessageBox.confirm("您确定退出吗?").then(function () {
                    location.href = "https://passport.baidu.com/?logout&u=http%3A%2F%2Fpet-chain.baidu.com%2Fchain%2FdogMarket"
                })
            }, editName: function () {
                var e = this, t = this;
                this.messageBox = !0, T.MessageBox.prompt("", "", {
                    title: "编辑昵称",
                    message: "最多输入8位汉字、英文或数字",
                    inputErrorMessage: "昵称不能为空",
                    confirmButtonClass: "sure",
                    cancelButtonClass: "cancle",
                    editorErrorMessage: null,
                    inputPlaceholder: "TODO显示默认的用户名",
                    inputValidator: function (e) {
                        return t.checkLength(e) ? t.checkLength(e) > 8 ? "昵称最大长度为8位" : t.checkLegal(e) ? "含有非法字符" : void 0 : "昵称不能为空"
                    }
                }).then(function (t) {
                    var n = t.value;
                    e.$store.dispatch("editName", {value: n})
                })
            }, checkLength: function (e) {
                return e.replace(/[^\x00-\xff]/g, "a").length
            }, checkLegal: function (e) {
                var t = /[^\w\u4e00-\u9fa5]/g;
                return t.test(e) ? "含有非法字符" : void 0
            }, goIntroduce: function () {
                this.$router.push({
                    path: "/chain/introduce",
                    query: {t: +new Date, appId: this.$route.query.appId, tpl: this.$route.query.tpl}
                })
            }, jumpTo: function (e, t) {
                t.preventDefault(), "dogMarket" == e && this.$refs.toolbarBox.setAttribute("style", "visibility: hidden"), this.$router.push({
                    path: "/chain/" + e,
                    query: {t: +new Date, appId: this.$route.query.appId, tpl: this.$route.query.tpl}
                })
            }, scrollTo: function () {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
                setTimeout(function () {
                    window.scrollTo(t, n)
                }, 10), this.$nextTick(function () {
                    e.initLoading = !1, e.loaded = !0
                })
            }, loadMorePets: function (e, t) {
                var n = this;
                this.$nextTick(i.default(s.default.mark(function o() {
                    var a, r, i;
                    return s.default.wrap(function (o) {
                        for (; ;)switch (o.prev = o.next) {
                            case 0:
                                if (a = n.pets, r = a.page, i = a.hasData, e ? r.pageNo = e : r.pageNo++, i && !(-1 != r.pageTotal && r.pageNo > r.pageTotal)) {
                                    o.next = 9;
                                    break
                                }
                                if (n.$refs.loadmorePets.onBottomLoaded(r.pageNo || 0), !(r.pageNo > 1)) {
                                    o.next = 6;
                                    break
                                }
                                return o.abrupt("return", T.Toast({message: "没有更多数据了", duration: 2e3}));
                            case 6:
                                return n.allLoadedPets = !0, t && "function" == typeof t && t(), o.abrupt("return");
                            case 9:
                                return o.next = 11, n.$store.dispatch("myPets", r);
                            case 11:
                                n.$refs.loadmorePets.onBottomLoaded(r.pageNo || 0), n.emptyPets = !n.pets.myPets.length, t && "function" == typeof t && t();
                            case 14:
                            case"end":
                                return o.stop()
                        }
                    }, o, n)
                })))
            }, loadMoreOrders: function (e, t) {
                var n = this;
                this.$nextTick(i.default(s.default.mark(function o() {
                    var a, r, i;
                    return s.default.wrap(function (o) {
                        for (; ;)switch (o.prev = o.next) {
                            case 0:
                                if (a = n.orders, r = a.page, i = a.hasData, e > 0 ? r.pageNo = e : r.pageNo++, i && !(-1 != r.pageTotal && r.pageNo > r.pageTotal)) {
                                    o.next = 9;
                                    break
                                }
                                if (n.$refs.loadmoreOrders.onBottomLoaded(r.pageNo || 0), !(r.pageNo > 1)) {
                                    o.next = 6;
                                    break
                                }
                                return o.abrupt("return", T.Toast({message: "没有更多数据了", duration: 2e3}));
                            case 6:
                                return n.allLoadedOrders = !0, t && "function" == typeof t && t(), o.abrupt("return");
                            case 9:
                                return o.next = 11, n.$store.dispatch("orderList", r);
                            case 11:
                                n.$refs.loadmoreOrders.onBottomLoaded(r.pageNo || 0), n.emptyOrders = !n.orders.orderList.length, t && "function" == typeof t && t();
                            case 14:
                            case"end":
                                return o.stop()
                        }
                    }, o, n)
                })))
            }, goLogin: function () {
                location.href = M.LOGIN_URL + "&u=" + encodeURIComponent(location.href)
            }, fixedHeader: function () {
                var e = this.$refs["header-inner"], t = e.offsetTop;
                document.onscroll = function () {
                    var n = document.body.scrollTop || document.documentElement.scrollTop;
                    e.setAttribute("data-fixed", n >= t ? "fixed" : "")
                }
            }
        },
        created: function () {
        },
        beforeCreate: function () {
            this.$store.commit("MY_PET_CLEAR"), this.$store.commit("MY_ORDER_CLEAR")
        },
        mounted: function () {
            var e = this;
            return i.default(s.default.mark(function t() {
                var n, o, a;
                return s.default.wrap(function (t) {
                    for (; ;)switch (t.prev = t.next) {
                        case 0:
                            return n = e, e.initLoading = !0, e.loaded = !1, e.$route.query.type && (e.activeTab = "order"), t.next = 6, I.api.getUserInfo({}, {
                                handler: {
                                    payload: x.handler.payload,
                                    success: function (e) {
                                        "00" == e.data.errorNo ? (n.isLogin = !0, n.userInfo = e.data.data) : "05" == e.data.errorNo && (n.isLogin = !1), n.loaded = !0
                                    }
                                }
                            });
                        case 6:
                            o = t.sent, a = function () {
                                n.scrollTo(), setTimeout(function () {
                                    n.fixedHeader()
                                }, 100)
                            }, e.isLogin ? e.isMyPets && 0 == e.pets.page.pageNo ? e.loadMorePets(1, a) : e.isMyOrders && 0 == e.orders.page.pageNo ? e.loadMoreOrders(1, a) : a() : a();
                        case 9:
                        case"end":
                            return t.stop()
                    }
                }, t, e)
            }))()
        }
    };
    var P = '<div class="personal">\n    <!-- 已登陆 -->\n   <!-- 已登陆 -->\n    <div class="personal-info" v-if="isLogin &amp;&amp; loaded" @click="logout()">\n        <div class="info">\n            <h3 class="name">{{userInfo ? userInfo.userName : \'\'}}</h3>\n            <p class="price">{{userInfo ? userInfo.amount : \'\'}}&nbsp;微积分</p>\n        </div>\n        <div class="img">\n            <div class="headIcon">\n                <!-- <i v-bind:style="{backgroundImage: \'url(\' + userInfo.headIcon || \'\' + \')\', backgroundSize: \'105%\', backgroundPosition: \'center\'}"></i> -->\n                <img class="head-icon" :src="userInfo.headIcon" alt="">\n            </div>\n        </div>\n    </div>\n    <!-- 未登录 -->\n    <div class="personal-info" v-if="!isLogin">\n        <div v-if="loaded">\n            <div class="info">\n                <h3 class="name">未登录</h3>\n                <p class="price">登录后领养莱茨狗</p>\n            </div>\n            <div class="img">\n                <span class="default-img"></span>\n            </div>\n        </div>\n    </div>\n    <header v-if="loaded">\n        <div class="header-inner" ref="header-inner">\n            <h2>\n                <span class="nav" v-bind:class="( isMyPets ? \'on\' : \'\' )" @click="tabClick(\'my-dog\')">我的狗狗</span>\n                <span class="nav" v-bind:class="( isMyOrders ? \'on\' : \'\' )" @click="tabClick(\'order\')">我的订单</span>\n            </h2>\n            <div class="introduce-link">\n                <span @click="goIntroduce()">莱茨狗介绍<i class="icon icon-font icon-back"></i></span>\n            </div>\n        </div>\n    </header>\n    <!-- 已登陆 -->\n    <div class="spinner-loading" v-if="initLoading &amp;&amp; isLogin">\n        <spinner color="#666" class="loading" type="fading-circle"></spinner>\n        <p>数据加载中,请稍后...</p>\n    </div>\n    <div v-if="isLogin &amp;&amp; isMyPets" class="pull-list scroller">\n        <mt-loadmore :bottom-method="loadMorePets" :bottom-all-loaded="allLoadedPets" :auto-fill="false" :bottom-distance="20" ref="loadmorePets">\n            <list-dog :list="pets.myPets">\n                <empty v-if="emptyPets &amp;&amp; loaded" type="default" msg="<p>我的狗窝空空如也</p><p>去狗狗集市看看吧</p>"></empty>\n            </list-dog>\n        </mt-loadmore>\n    </div>\n    <div v-if="isLogin &amp;&amp; isMyOrders" class="pull-list scroller pull-list-order">\n        <mt-loadmore :bottom-method="loadMoreOrders" :bottom-all-loaded="allLoadedOrders" :auto-fill="false" :bottom-distance="20" ref="loadmoreOrders">\n            <order :list="orders.orderList" v-if="loaded">\n                <empty v-if="emptyOrders &amp;&amp; loaded" type="default" msg="<p>啊哦～啊哦～</p><p>好像还没有狗狗的订单</p>"></empty>\n            </order>\n        </mt-loadmore>\n    </div>\n    <!-- 未登录 -->\n    <div class="empty" v-if="!isLogin &amp;&amp; loaded">\n        <span class="empty-image"></span>\n        <p>您还未登录狗窝哦</p>\n        <p class="go-login" @click="goLogin()">立即登录</p>\n    </div>\n    <div class="toolbar-wrapper" ref="toolbarBox">\n        <div class="toolbar">\n            <div class="toolbar-inner">\n                <div @click.stop="jumpTo(\'dogMarket\', $event)">\n                    <span class="icon icon-font icon-market"></span>狗狗集市\n                </div>\n                <div @click.stop="jumpTo(\'personal\', $event)" class="current">\n                    <span class="icon icon-font icon-personage_p"></span>我的狗窝\n                </div>\n            </div>\n        </div>\n    </div>\n</div>';
    n && n.exports && (n.exports.template = P), t && t.default && (t.default.template = P), n.exports = t["default"]
});
;define("020d343", function (e, t, u) {
    "use strict";
    function d(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var f = e("3b4659a"), a = d(f);
    t.default = a.default, u.exports = t["default"]
});
;define("7434137", function (e, t, a) {
    "use strict";
    function r(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var n, s = e("6cfeef6"), o = r(s), u = e("3eddb2a"), i = r(u), p = e("d918814"), d = r(p), c = e("c3e5ef7");
    t.default = {
        state: {
            userInfo: {},
            userName: "",
            pets: {myPets: [], page: {pageNo: 0, pageSize: 10, pageTotal: -1}, hasData: !0},
            orders: {orderList: [], page: {pageNo: 0, pageSize: 10, pageTotal: -1}, hasData: !0}
        }, mutations: (n = {}, d.default(n, "USER_INFO", function (e, t) {
            t.headIcon = t.headIcon || "./img/default.png", e.userInfo = t
        }), d.default(n, "MY_PET_CLEAR", function (e) {
            e.pets = {myPets: [], page: {pageNo: 0, pageSize: 10, pageTotal: -1}, hasData: !0}
        }), d.default(n, "MY_ORDER_CLEAR", function (e) {
            e.orders = {orderList: [], page: {pageNo: 0, pageSize: 10, pageTotal: -1}, hasData: !0}
        }), d.default(n, "MY_PET_LIST", function (e, t) {
            var a = t.dataList, r = void 0 === a ? [] : a, n = t.pageSize, s = t.pageNo, o = t.totalCount, u = e.pets.page.pageTotal;
            if (-1 === u) {
                var i = 0;
                i = 0 === o ? s : o % n === 0 ? o / n : parseInt(o / n, 10) + 1, e.pets.page.pageTotal = u = i
            }
            s >= u && (e.pets.hasData = !1);
            for (var p = 0, d = r.length; d > p; p++)0 === r[p].chainStatus ? r[p].petStatus = 1 : 1 === r[p].chainStatus && 1 === r[p].shelfStatus && (r[p].petStatus = 2);
            e.pets.myPets = 1 === s ? r || [] : e.pets.myPets.concat(r), e.pets.page.pageNo = s
        }), d.default(n, "ORDER_LIST", function (e, t) {
            var a = t.dataList, r = void 0 === a ? [] : a, n = t.pageSize, s = t.pageNo, o = t.totalCount, u = e.orders.page.pageTotal;
            if (-1 === u) {
                var i = 0;
                i = 0 === o ? s : o % n === 0 ? o / n : parseInt(o / n, 10) + 1, e.orders.page.pageTotal = u = i
            }
            s >= u && (e.orders.hasData = !1), e.orders.orderList = 1 === s ? [].concat(r) : e.orders.orderList.concat(r), e.orders.page.pageNo = s
        }), d.default(n, "EDIT_NAME", function (e, t) {
            e.userName = t
        }), n), actions: {
            userInfo: function (e) {
                var t = this;
                return i.default(o.default.mark(function a() {
                    var r, n, s;
                    return o.default.wrap(function (t) {
                        for (; ;)switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, c.api.getUserInfo();
                            case 2:
                                r = t.sent, n = r.data, s = void 0 === n ? {} : n, e.commit("USER_INFO", s);
                            case 6:
                            case"end":
                                return t.stop()
                        }
                    }, a, t)
                }))()
            }, myPets: function (e, t) {
                var a = this;
                return i.default(o.default.mark(function r() {
                    var n, s, u;
                    return o.default.wrap(function (a) {
                        for (; ;)switch (a.prev = a.next) {
                            case 0:
                                return a.next = 2, c.api.getMyPets(t);
                            case 2:
                                n = a.sent, s = n.data, u = void 0 === s ? {} : s, e.commit("MY_PET_LIST", u);
                            case 6:
                            case"end":
                                return a.stop()
                        }
                    }, r, a)
                }))()
            }, orderList: function (e, t) {
                var a = this;
                return i.default(o.default.mark(function r() {
                    var n, s, u;
                    return o.default.wrap(function (a) {
                        for (; ;)switch (a.prev = a.next) {
                            case 0:
                                return a.next = 2, c.api.getOrderList(t);
                            case 2:
                                n = a.sent, s = n.data, u = void 0 === s ? [] : s, e.commit("ORDER_LIST", u);
                            case 6:
                            case"end":
                                return a.stop()
                        }
                    }, r, a)
                }))()
            }, editName: function (e) {
                var t = this;
                return i.default(o.default.mark(function a() {
                    var r, n, s;
                    return o.default.wrap(function (t) {
                        for (; ;)switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, c.api.postName();
                            case 2:
                                r = t.sent, n = r.data, s = void 0 === n ? {} : n, e.commit("EDIT_NAME", s);
                            case 6:
                            case"end":
                                return t.stop()
                        }
                    }, a, t)
                }))()
            }
        }
    }, a.exports = t["default"]
});
;define("94af8f7", function (t, e, s) {
    "use strict";
    function n(t) {
        return t && t.__esModule ? t : {"default": t}
    }

    Object.defineProperty(e, "__esModule", {value: !0});
    var a = t("6cfeef6"), i = n(a), o = t("3eddb2a"), l = n(o), r = t("c75ffe0"), c = n(r), p = t("621bc70"), d = t("c3e5ef7"), u = t("cece673"), h = t("6bafc50"), f = n(h), m = "//app.baifubao.com/index.html?channel=1021157k&from=yc&bdwallet_type=1&bdwallet_url_ios=https%3A%2F%2Fjr.baidu.com%2F~2pCWWK", v = "//wappass.baidu.com/wp/bindwidget-bindmobile?u=";
    e.default = {
        store: f.default, data: function () {
            return {captcha: "", inputSmsVal: "", isSmsCodeDisable: !0, smsDialogShow: !1, splashMaskShow: !1}
        }, watch: {
            inputSmsVal: function (t) {
                return this.captcha = t, /[\da-zA-Z]{4}/i.test(t) ? void(this.isSmsCodeDisable = !1) : void(this.isSmsCodeDisable = !0)
            }, "smsInfo.img": function () {
                this.splashMaskShow = !0, this.smsDialogShow = !0
            }
        }, computed: c.default({}, p.mapState({
            adopted: function (t) {
                return t.splash.adopted
            }, isBDWallet: function (t) {
                return t.splash.isBDWallet
            }, getPet: function (t) {
                return t.splash.getPet
            }, smsInfo: function (t) {
                return t.splash.smsInfo
            }
        }), {
            toMarketLink: function () {
                return "/chain/dogMarket?appId=" + (this.$route.query.appId || "") + "&tpl=" + (this.$route.query.tpl || "")
            }
        }), methods: {
            flash: function () {
                var t = 80, e = document.getElementById("splash-flash-wrapper"), s = document.getElementById("splash-flash-content1"), n = document.getElementById("splash-flash-content2");
                n.innerHTML = s.innerHTML;
                setInterval(function () {
                    n.offsetWidth - e.scrollLeft <= 0 ? e.scrollLeft -= s.offsetWidth : e.scrollLeft++
                }, t)
            }, refreshCode: function () {
                this.$store.dispatch("splashSmsInfo")
            }, smsClose: function () {
                this.splashMaskShow = !1, this.smsDialogShow = !1
            }, check: function () {
                var t = this;
                return l.default(i.default.mark(function e() {
                    var s, n;
                    return i.default.wrap(function (e) {
                        for (; ;)switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, d.api.hasMobile();
                            case 2:
                                if (s = e.sent, n = s.data, !n) {
                                    e.next = 6;
                                    break
                                }
                                return e.abrupt("return", t.$store.dispatch("splashSmsInfo"));
                            case 6:
                                u.MessageBox.confirm("绑定手机号才能领取哦", "提示", {
                                    confirmButtonText: "绑定手机",
                                    cancelButtonText: "看看狗市",
                                    confirmButtonClass: "btn-confirm"
                                }).then(function () {
                                    location.href = v
                                }).catch(function () {
                                    t.$router.push({
                                        path: "/",
                                        query: {t: +new Date, appId: t.$route.query.appId, tpl: t.$route.query.tpl}
                                    })
                                });
                            case 7:
                            case"end":
                                return e.stop()
                        }
                    }, e, t)
                }))()
            }, adopt: function () {
                var t = this;
                return l.default(i.default.mark(function e() {
                    var s, n, a, o, l;
                    return i.default.wrap(function (e) {
                        for (; ;)switch (e.prev = e.next) {
                            case 0:
                                return s = t.$route.query.appId, n = void 0 === s ? 1 : s, e.next = 3, t.$store.dispatch("splashGiftInfo", {
                                    appId: n,
                                    seed: t.smsInfo.seed,
                                    captcha: t.inputSmsVal
                                });
                            case 3:
                                return e.next = 5, t.$store.commit("SPLASH_SMS_INFO_CLEAR");
                            case 5:
                                if (t.splashMaskShow = !1, t.smsDialogShow = !1, a = t.$store.state.splash, a.isBDWallet) {
                                    e.next = 12;
                                    break
                                }
                                return o = t.$store.state.splash, o.adopted && (l = "您已经领取过了哦<br>", !t.isBDWallet, u.MessageBox.alert(l, "提示", {
                                    confirmButtonText: "看看狗窝",
                                    confirmButtonClass: "btn-confirm"
                                }).then(function () {
                                    t.$router.push({
                                        path: "/chain/personal",
                                        query: {t: +new Date, appId: t.$route.query.appId, tpl: t.$route.query.tpl}
                                    })
                                })), e.abrupt("return");
                            case 12:
                                a.adopted && (u.Toast({message: "你已经领过了噢～", duration: 2e3}), setTimeout(function () {
                                    t.$router.push({
                                        path: "/chain/dogMarket",
                                        query: {t: +new Date, appId: t.$route.query.appId, tpl: t.$route.query.tpl}
                                    })
                                }, 3e3));
                            case 13:
                            case"end":
                                return e.stop()
                        }
                    }, e, t)
                }))()
            }, jump: function () {
                var t = this;
                return l.default(i.default.mark(function e() {
                    var s;
                    return i.default.wrap(function (e) {
                        for (; ;)switch (e.prev = e.next) {
                            case 0:
                                return s = d.api.hasMobile(), e.next = 3, t.$store.commit("SPLASH_GET_PET", !1);
                            case 3:
                                t.$router.push({
                                    path: "/chain/personal",
                                    query: {t: +new Date, appId: t.$route.query.appId, tpl: t.$route.query.tpl}
                                });
                            case 4:
                            case"end":
                                return e.stop()
                        }
                    }, e, t)
                }))()
            }, downloadWallet: function () {
                location.href = m, this.$store.commit("SPLASH_GET_PET", !1)
            }
        }, mounted: function () {
            this.flash()
        }
    };
    var g = '<div class="splash">\n    <div class="splash-container">\n        <div class="splash-content">\n            <div class="splash-flash">\n                <div id="splash-flash-wrapper">\n                    <div id="splash-flash-box">\n                        <div id="splash-flash-content1">\n                            <img src="/static/pkg/image/page/Splash/img/bg_39c0ea7.png" border="0">\n                        </div>\n                        <div id="splash-flash-content2"></div>\n                    </div>\n                </div>\n            </div>\n            <div class="splash-title">\n                <h1>可爱</h1>\n                <h1>唯一</h1>\n                <h1>值得收藏</h1>\n            </div>\n            <div class="splash-abstract">\n                <p>世界上总有属于你的唯一</p>\n                <p>我在云端，等待你的陪伴</p>\n            </div>\n            <div class="jump-to-market">\n                <router-link :to="toMarketLink">\n                    <span>逛逛狗市</span><b class="icon icon-font icon-back"></b>\n                </router-link>\n            </div>\n        </div>\n        <div @click="check">\n            <button class="button-confirm" size="large" type="danger">免费领养</button>\n        </div>\n        <div class="splash-tips">百度区块链技术赋能的数字狗，无法被修改和销毁</div>\n\n        <mt-popup class="popup" v-model="getPet" :close-on-click-modal="false" close-delay="500" position="center">\n            <img @click="jump" src="/static/pkg/image/page/Splash/img/adopt_b91c8a7.png" width="290" height="220">\n            <div class="other-app" v-if="!isBDWallet">\n                <div @click="jump">\n                    <img src="/static/pkg/image/page/Splash/img/button_1_223e009.png" width="90" height="48">\n                </div>\n                <!--div @click="downloadWallet">\n                    <img src="./img/button.png" width="90" height="48">\n                </div-->\n            </div>\n        </mt-popup>\n\n        <div class="detail-dialog-mask" v-show="splashMaskShow"></div>\n        <div class="detail-dialog-sms-verify" v-show="smsDialogShow">\n            <div class="title">\n                请输入验证码\n            </div>\n            <div class="sms-verify">\n                <div class="sms-input">\n                    <input v-model="inputSmsVal" placeholder="请输入验证码" maxlength="4" type="text">\n                </div>\n                <div class="sms-img" @click="refreshCode">\n                    <img :src="\'data:image/jpeg;base64,\' + smsInfo.img" width="100%" height="100%" alt="">\n                    <i class="icon-font icon-shuaxin"></i>\n                </div>\n            </div>\n            <div class="option">\n                <div class="button" @click="smsClose">取消</div>\n                <div class="button" v-bind:class="{disable: isSmsCodeDisable}" @click="adopt">确定</div>\n            </div>\n        </div>\n    </div>\n</div>';
    s && s.exports && (s.exports.template = g), e && e.default && (e.default.template = g), s.exports = e["default"]
});
;define("e3e7fb6", function (e, t, f) {
    "use strict";
    function u(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var d = e("94af8f7"), a = u(d);
    t.default = a.default, f.exports = t["default"]
});
;define("da9e113", function (t, e, a) {
    "use strict";
    function n(t) {
        return t && t.__esModule ? t : {"default": t}
    }

    Object.defineProperty(e, "__esModule", {value: !0});
    var r, o = t("6cfeef6"), f = n(o), u = t("3eddb2a"), s = n(u), d = t("d918814"), i = n(d), c = t("c3e5ef7");
    e.default = {
        state: {
            adopted: !0,
            isBDWallet: /BaiduWallet/.test(navigator.userAgent) === !0,
            getPet: !1,
            smsInfo: {}
        }, mutations: (r = {}, i.default(r, "SPLASH_GIFT_INFO", function (t, e) {
            t.adopted = e, t.getPet = !e
        }), i.default(r, "SPLASH_GET_PET", function (t) {
            t.getPet = !1
        }), i.default(r, "SPLASH_SMS_INFO", function (t, e) {
            t.smsInfo = e
        }), i.default(r, "SPLASH_SMS_INFO_CLEAR", function (t) {
            t.smsInfo = {}
        }), r), actions: {
            splashGiftInfo: function (t, e) {
                var a = this, n = t.commit;
                return s.default(f.default.mark(function r() {
                    var t, o, u;
                    return f.default.wrap(function (a) {
                        for (; ;)switch (a.prev = a.next) {
                            case 0:
                                return a.next = 2, c.api.getGiftInfo(e);
                            case 2:
                                t = a.sent, o = t.data, u = void 0 === o ? {} : o, n("SPLASH_GIFT_INFO", u);
                            case 6:
                            case"end":
                                return a.stop()
                        }
                    }, r, a)
                }))()
            }, splashSmsInfo: function (t, e) {
                var a = this;
                return s.default(f.default.mark(function n() {
                    var r;
                    return f.default.wrap(function (a) {
                        for (; ;)switch (a.prev = a.next) {
                            case 0:
                                return a.next = 2, c.api.getCode(e);
                            case 2:
                                r = a.sent, 0 === +r.errorNo || r.data && 0 === +r.data.errorNo ? t.commit("SPLASH_SMS_INFO", r.data) : r.data && 1 === +r.data.errorNo && (location.href = "/error");
                            case 4:
                            case"end":
                                return a.stop()
                        }
                    }, n, a)
                }))()
            }
        }
    }, a.exports = e["default"]
});