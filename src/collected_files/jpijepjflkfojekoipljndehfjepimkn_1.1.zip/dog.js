// var slogan = document.getElementById('slogan');
// slogan.parentNode.removeChild(slogan);

// ;define("868f976", function (t, e, n) {
//     "use strict";
//     function o(t) {
//         return t && t.__esModule ? t : {"default": t}
//     }
//
//     Object.defineProperty(e, "__esModule", {value: !0});
//     var a = t("6cfeef6"), s = o(a), r = t("3eddb2a"), i = o(r), d = t("c75ffe0"), l = o(d), c = t("e3a0dda"), u = o(c), p = t("621bc70"), f = t("7b6a2c2"), m = o(f), g = t("cece673"), h = t("9368b99"), v = o(h), b = t("6bafc50"), k = o(b);
//     e.default = {
//         store: k.default,
//         data: function () {
//             return {allLoaded: !1, loaded: !1}
//         },
//         components: {ListDog: v.default, Spinner: g.Spinner, loadmore: m.default},
//         computed: l.default({}, p.mapState({
//             pets: function (t) {
//                 return t.dogMarket.pets
//             }, sort: function (t) {
//                 return t.dogMarket.sort
//             }, noData: function (t) {
//                 return t.dogMarket.noData
//             }
//         }), {
//             getSplashLink: function () {
//                 return "/chain/splash?appId=" + (this.$route.query.appId || "") + "&tpl=" + (this.$route.query.tpl || "")
//             }, module: function () {
//                 return this.$store.state.dogMarket
//             }
//         }),
//         methods: {
//             sortBy: function (t) {
//                 var e = this, n = this.module.sort;
//                 n[t] && (n[t] = "ASC" === n[t] ? "DESC" : "ASC", this.$store.commit("DOG_MARKET_CLEAR"), this.$nextTick(function () {
//                     e.$store.commit("QUERY_SORT_SOURCE_TYPE", n), e.$store.commit("QUERY_SORT_TYPE", t + "_" + n[t])
//                 }), this.loadMore(function () {
//                     return e.scrollTo()
//                 }))
//             }, loadMore: function (t) {
//                 var e = this;
//                 this.$nextTick(i.default(s.default.mark(function n() {
//                     var o, a;
//                     return s.default.wrap(function (n) {
//                         for (; ;)switch (n.prev = n.next) {
//                             case 0:
//                                 return o = e.$store.state.dogMarket, a = o.pageNo, a++, n.next = 5, e.$store.dispatch("dogMarKetList", {pageNo: a});
//                             case 5:
//                                 if (1 === a && 0 === e.pets.petsOnSale.length && e.$store.commit("DOG_MARKET_NO_DATA", !0), e.$refs.loadmore && e.$refs.loadmore.onBottomLoaded(t || 0), e.$store.commit("PAGE_NO", a), o.pets.hasData) {
//                                     n.next = 12;
//                                     break
//                                 }
//                                 if (!(a > 1)) {
//                                     n.next = 11;
//                                     break
//                                 }
//                                 return n.abrupt("return", g.Toast({message: "没有更多数据了", duration: 2e3}));
//                             case 11:
//                                 return n.abrupt("return", e.loaded = !0);
//                             case 12:
//                                 e.allLoaded = !0, "function" == typeof t && t();
//                             case 14:
//                             case"end":
//                                 return n.stop()
//                         }
//                     }, n, e)
//                 })))
//             }, jumpTo: function (t, e) {
//                 e.preventDefault(), this.$router.push({
//                     path: "/chain/" + t,
//                     query: {t: +new Date, appId: this.$route.query.appId, tpl: this.$route.query.tpl}
//                 })
//             }, scrollTo: function () {
//                 var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : -1;
//                 setTimeout(function () {
//                     window.scrollTo(e, n)
//                 }, 10), this.$nextTick(function () {
//                     t.loaded = !0
//                 })
//             }
//         },
//         beforeCreate: function () {
//         },
//         mounted: function () {
//             var t = this;
//             this.pets.petsOnSale.length ? this.loaded = !0 : this.loadMore(function () {
//                 return t.scrollTo()
//             }), window.addEventListener("scroll", u.default.debounce(function () {
//                 var e = t.$refs["header-inner"];
//                 if (e && e.getBoundingClientRect()) {
//                     var n = e.getBoundingClientRect();
//                     e.style.position = window.pageYOffset - n.top > 0 ? "fixed" : ""
//                 }
//             }, 10))
//         }
//     };
//     var T = '<section class="dog-market">\n    <div id="slogan">\n        <router-link :to="getSplashLink">\n            <img src="/static/pkg/image/page/DogMarket/img/adi_d3c93dc.png" width="100%">\n        </router-link>\n    </div>\n    <header>\n        <div class="header-inner" ref="header-inner">\n            <h2>排xx</h2>\n            <div class="sort">\n                <span @click="sortBy(\'RAREDEGREE\')">稀有度<b :class="sort.RAREDEGREE" class="filter"></b></span>\n                <span @click="sortBy(\'AMOUNT\')">价格<b :class="sort.AMOUNT" class="filter"></b></span></div>\n        </div>\n    </header>\n    <div class="spinner-loading" v-show="!loaded">\n        <spinner color="#666" class="loading" type="fading-circle"></spinner>\n        <p>数据加载中,请稍后...</p>\n    </div>\n    <div class="no-data" v-if="noData">\n        <img src="/static/pkg/image/static/img/empty_b3e0548.png" width="105">\n        <div class="info">\n            <p>狗狗都回家了</p>\n            <p>迟点再来看看吧</p>\n        </div>\n    </div>\n    <div class="pull-list scroller" v-else="">\n        <mt-loadmore :bottom-method="loadMore" :auto-fill="false" :bottom-distance="20" ref="loadmore">\n            <list-dog :list="pets.petsOnSale" :bottom-all-loaded="allLoaded" channel="market">\n            </list-dog>\n        </mt-loadmore>\n    </div>\n    <div class="toolbar-wrapper">\n        <div class="toolbar">\n            <div class="toolbar-inner">\n                <div @click.stop="jumpTo(\'dogMarket\', $event)">\n                    <span class="icon icon-font icon-market_p current"></span><b class="current-b">狗狗集市</b>\n                </div>\n                <div @click.stop="jumpTo(\'personal\', $event)">\n                    <span class="icon icon-font icon-personage"></span><b>我的狗窝</b>\n                </div>\n            </div>\n        </div>\n    </div>\n</section>';
//     n && n.exports && (n.exports.template = T), e && e.default && (e.default.template = T), n.exports = e["default"]
// });


// var sortByAmount= "this.module.sort['AMOUNT']='ASC';";
//
// var sort = document.getElementsByClassName('sort')[0];
// sort.innerHTML = sort.innerHTML+'<span onclick="'+sortByAmount+'">刷新</span>';