/**
 * Created by macuser on 2018/2/7.
 */


setTimeout(function () {
    var button = document.getElementById('showBugPop');
    if(button){
        button.click()
    }
},100);
