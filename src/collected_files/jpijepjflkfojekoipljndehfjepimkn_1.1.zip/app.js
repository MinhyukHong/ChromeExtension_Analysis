;define("802dbc3", function (e, t) {
    "use strict";
    Object.defineProperty(t, "__esModule", {value: !0});
    t.POST = {
        getOrderList: "/data/user/order/list",
        getMyPets: "/data/user/pet/list",
        getUserInfo: "/data/user/get",
        getGiftInfo: "/data/user/gift",
        getPetInfo: "/data/pet/queryPetById",
        getPetInfoWithAuth: "/data/pet/queryPetByIdWithAuth",
        buy: "/data/txn/create",
        sale: "/data/market/salePet",
        cancelSale: "/data/market/unsalePet",
        shouldJump2JianDan: "/data/market/shouldJump2JianDan",
        hasMobile: "/data/user/hasMobile",
        queryPetsOnSale: "/data/market/queryPetsOnSale",
        getCode: "/data/captcha/gen"
    }, t.GET = {getWeixinConfig: "/api/digitpet/getwechatsign"}
});
;define("eba5767", function (e, a) {
    "use strict";
    Object.defineProperty(a, "__esModule", {value: !0});
    {
        var s = 3, t = "wappass.baidu.com/passport/login?adapter=";
        a.LOGIN_URL = "//" + t + s
    }
});
;define("95cd1e2", function (e, r, o) {
    "use strict";
    function t(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    function a(e) {
        e && d.Toast({message: e, className: "app-toast", iconClass: "icon icon-fail", duration: 2e3})
    }

    Object.defineProperty(r, "__esModule", {value: !0});
    var n = e("c75ffe0"), i = t(n), c = e("b7e47cd"), s = t(c), d = e("cece673"), u = e("eba5767");
    r.default = {
        timeout: 15e3, credentials: "include", hook: {
            timeout: function () {
                a("网络超时，请重试！")
            }
        }, handler: {
            success: function (e, r) {
                var o = e.data, t = void 0 === o ? {} : o, n = t.errorNo || JSON.stringify(t.code);
                if (0 === +n || "00" === n)return t;
                if ("05" === t.errorNo)location.href = u.LOGIN_URL + "&u=" + encodeURIComponent(r.u || location.href); else {
                    if ("01" === t.errorNo)return e;
                    r["x-silent"] || a(t.errorMsg)
                }
                return Promise.reject(e)
            }, payload: function f(e, r) {
                if ("POST" === r["x-method"]) {
                    var f = JSON.parse(e.body), o = location.href.slice(location.href.indexOf("?")), t = s.default.parse(location.search || o), a = t.appId, n = void 0 === a ? 1 : a, c = t.tpl, d = void 0 === c ? "" : c;
                    return f = i.default({}, f, {
                        requestId: +new Date,
                        appId: +n,
                        tpl: d
                    }), e.body = JSON.stringify(f), e
                }
            }, error: function (e, r) {
                var o = e.data;
                return /^50.?$/.test(o.status) && !r["x-noblocking"] ? location.href = "/error" : o.data && o.data.errorMsg && !r["x-silent"] && a(o.data.errorMsg), o
            }
        }
    }, o.exports = r["default"]
});
;define("ac45f2b", function (e, t, f) {
    "use strict";
    function u(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var a = e("c75ffe0"), d = u(a);
    e("89c93f8");
    var r = e("7fbe820"), c = e("802dbc3"), l = e("95cd1e2"), s = u(l);
    t.default = d.default({}, r.apify(r.request.post, c.POST, s.default), r.apify(r.request.get, c.GET, s.default)), f.exports = t["default"]
});
;define("c3e5ef7", function (t, e) {
    "use strict";
    function i(t) {
        return t && t.__esModule ? t : {"default": t}
    }

    Object.defineProperty(e, "__esModule", {value: !0}), e.http = e.api = void 0;
    {
        var n = t("ac45f2b"), u = i(n), f = e.api = u.default;
        e.http = {
            install: function (t) {
                t.prototype.$http = f
            }
        }
    }
});
;define("524d2fc", function (t, e, i) {
    "use strict";
    Object.defineProperty(e, "__esModule", {value: !0}), e.default = {
        props: {
            type: {
                type: String,
                "default": function () {
                    return "default"
                }
            }, msg: {
                type: String, "default": function () {
                    return "<p>空空如也</p>"
                }
            }
        }, data: function () {
            return {}
        }, computed: {}, methods: {}, mounted: function () {
        }
    };
    var a = '<div class="no-data">\n    <img v-if="type == \'default\'" src="/static/pkg/image/static/img/empty_b3e0548.png" width="105">\n    <img v-if="type == \'order\'" src="/static/pkg/image/static/img/empty_b3e0548.png" width="105">\n    <img v-if="type == \'500\'" src="/static/pkg/image/static/img/500_e323ca5.png" width="105">\n    <img v-if="type == \'404\'" src="/static/pkg/image/static/img/404_6eba4c5.png" width="105">\n    <div class="info" v-html="msg"></div>\n</div>';
    i && i.exports && (i.exports.template = a), e && e.default && (e.default.template = a), i.exports = e["default"]
});
;define("2c3701f", function (e, t, u) {
    "use strict";
    function f(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var d = e("524d2fc"), l = f(d);
    t.default = l.default, u.exports = t["default"]
});
;define("e6f9e34", function (e, t, n) {
    "use strict";
    function i(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var a = e("7c6ec45"), s = i(a), o = e("e3a0dda"), r = i(o), d = e("cece673");
    t.default = {
        data: function () {
            return {}
        }, props: {
            list: {
                type: Array, "default": function () {
                    return []
                }
            }, channel: {type: String, "default": "center"}
        }, methods: {
            jumpTo: function (e, t) {
                return "center" == e && "1" == t.petStatus ? void d.Toast({
                    message: "区块链写入中,请稍后再试",
                    position: "center",
                    duration: 2e3
                }) : void this.$router.push({
                    path: "/chain/detail",
                    query: {
                        channel: e,
                        petId: t.petId,
                        appId: this.$route.query.appId,
                        tpl: this.$route.query.tpl,
                        validCode: t.validCode
                    }
                })
            }
        }, mounted: function () {
            window.addEventListener("scroll", r.default.debounce(function () {
                [].concat(s.default(document.querySelectorAll(".dog-preview"))).forEach(function (e) {
                    var t = e.getBoundingClientRect(), n = t.top, i = t.bottom, a = "block", s = window.innerHeight;
                    (0 > i && 0 > n || i > s && n > s) && (a = "none"), e.style.display = a
                })
            }, 50))
        }
    };
    var l = '<section class="dog-wrapper">\n    <div class="dog" v-for="item in list">\n        <dl @click="jumpTo(channel, item)">\n            <dt v-bind:style="{backgroundColor: item.bgColor}">\n                <img :src="item.petUrl" :data-src="item.petUrl" border="0" alt="" class="dog-preview" onerror="this.src=\'http://blockchain-pet-online.bj.bcebos.com/vip_185089739579405926420180202112326\'">\n            </dt>\n            <dd>\n                <p class="tag">\n                    <span :class="(item.rareDegree == 0 ? \'rare rare_0\' : (item.rareDegree == 1 ? \'rare rare_1\' : (item.rareDegree == 2 ? \'rare rare_2\' :(item.rareDegree == 3 ? \'rare rare_3\' :(item.rareDegree == 4 ? \'rare rare_4\' :(item.rareDegree == 5 ? \'rare rare_5\' : \'rare\'))))))">{{ item.rareDegree | rare }}</span><span class="generation">第{{ item.generation }}代</span>\n                </p>\n                <h3>\n                    <span v-if="item.petName">{{ item.petName }}</span>\n                    <span v-if="item.desc">{{ item.desc }}</span>\n                    <span v-if="item.id">{{ item.id | petId }}</span>\n                </h3>\n                <div class="price">\n                    <span v-if="channel == \'market\'" v-html="$options.filters.currency(item.amount)">\n                    </span>\n                    <span v-else-if="item.petStatus == 1" class="coin">\n                        <div class="ing" v-if="item.petStatus == 1">区块链写入中<i></i></div>\n                    </span>\n                    <span v-else-if="item.petStatus == 2"><font v-html="$options.filters.currency(item.amount)"></font> 出售中</span>\n                </div>\n            </dd>\n        </dl>\n    </div>\n    <slot></slot>\n</section>';
    n && n.exports && (n.exports.template = l), t && t.default && (t.default.template = l), n.exports = t["default"]
});
;define("9368b99", function (e, t, u) {
    "use strict";
    function f(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var d = e("e6f9e34"), l = f(d);
    t.default = l.default, u.exports = t["default"]
});
;define("ce4930b", function (t, e, s) {
    "use strict";
    Object.defineProperty(e, "__esModule", {value: !0}), e.default = {
        props: {
            list: {
                type: Array,
                "default": function () {
                    return []
                }
            }
        }, data: function () {
            return {
                is: "order",
                status: {1: "已卖出", 2: "已买入"},
                txnStatus: {0: "上链中", 1: "上链中", 2: "成功", 3: "失败", 4: "失败"}
            }
        }, computed: {}, methods: {}, mounted: function () {
        }
    };
    var a = '<div class="order-wrapper">\n    <div class="order-list" v-for="item in list">\n        <dl>\n            <dt class="dog-img" v-bind:style="{backgroundColor: item.bgColor}">\n                <img :src="item.petUrl" onerror="this.onerror=null; this.style.height=0;" alt="">\n            </dt>\n            <dd class="dog-info">\n                <span v-if="item.txnStatus == 2" class="tag">{{status[item.status]}}</span>\n                <span v-if="item.txnStatus == 3 || item.txnStatus == 4" class="tag">交易失败</span>\n                <h3 class="dog-name">{{item.petName}} {{item.id | petId }}</h3>\n                <div class="date">{{item.transDate}}</div>\n            </dd>\n            <dd class="txn-status" v-if="item.txnStatus !=2">\n                <p class="txn">{{txnStatus[item.txnStatus]}}</p>\n                <p class="fee" v-if="item.status == \'2\' &amp;&amp; item.fee >= 0.01">含手续费: {{item.fee}}</p>\n            </dd>\n            <dd class="price" v-if="item.txnStatus == 2">\n                <p :class="(item.status == \'1\' ? \'buy\' : \'sale\')">\n                    {{item.status == 1 ? \'+\' : \'-\'}}{{item.amount}}微\n                </p>\n                <p v-if="item.status == \'2\' &amp;&amp; item.fee >= 0.01" class="fee">含手续费{{item.fee}}微</p>\n            </dd>\n        </dl>\n    </div>\n    <slot></slot>\n</div>';
    s && s.exports && (s.exports.template = a), e && e.default && (e.default.template = a), s.exports = e["default"]
});
;define("1d94572", function (e, t, u) {
    "use strict";
    function d(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var f = e("ce4930b"), l = d(f);
    t.default = l.default, u.exports = t["default"]
});
;define("8f6d643", function (e, n, t) {
    "use strict";
    function u(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(n, "__esModule", {value: !0});
    var r = e("13f1565"), f = u(r), c = function (e) {
        return '<span class="chain-currency">' + (e || 0) + "</span>微"
    };
    f.default.filter("currency", c), n.default = c, t.exports = n["default"]
});
;define("1b9f8fb", function (e, t, f) {
    "use strict";
    function u(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var r = e("13f1565"), n = u(r), d = function (e) {
        return {0: "普通", 1: "稀有", 2: "卓越", 3: "史诗", 4: "神话", 5: "传说"}[e]
    };
    n.default.filter("rare", d), t.default = d, f.exports = t["default"]
});
;define("5354aee", function (e, t, u) {
    "use strict";
    function n(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(t, "__esModule", {value: !0});
    var r = e("13f1565"), a = n(r), f = function () {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = e.length, u = "00000000";
        return "" + u.slice(0, 8 - t) + e
    };
    a.default.filter("petId", f), t.default = f, u.exports = t["default"]
});
;define("21866d6", function (e) {
    "use strict";
    e("8f6d643"), e("1b9f8fb"), e("5354aee")
});
;define("e11ddd2", function (e, a) {
    "use strict";
    Object.defineProperty(a, "__esModule", {value: !0});
    {
        var t = 3, d = "wappass.qatest.baidu.com/passport/login?adapter=";
        a.LOGIN_URL = "//" + d + t
    }
});
;define("dc6d8fa", function () {
    "use strict"
});
;define("c4d9e68", function (t, e, a) {
    "use strict";
    function n(t) {
        return t && t.__esModule ? t : {"default": t}
    }

    Object.defineProperty(e, "__esModule", {value: !0});
    var o = t("990a4d5"), l = n(o), c = t("020d343"), d = n(c), i = t("96f1c13"), p = n(i), f = t("1c0139f"), u = n(f), m = t("e3e7fb6"), h = n(m), r = t("8536207"), s = n(r), _ = t("366fa26"), M = n(_);
    e.default = [{path: "*", component: s.default, meta: {title: "404"}}, {
        path: "/error",
        component: M.default,
        meta: {title: "500"}
    }, {path: "/", component: l.default, meta: {title: "莱茨狗"}}, {
        path: "/chain/dogMarket",
        component: l.default,
        meta: {title: "莱茨狗"}
    }, {path: "/chain/detail", component: p.default, meta: {title: "莱茨狗"}}, {
        path: "/chain/personal",
        component: d.default,
        meta: {title: "莱茨狗"}
    }, {path: "/chain/introduce", component: u.default, meta: {title: "莱茨狗"}}, {
        path: "/chain/splash",
        component: h.default,
        meta: {title: "莱茨狗"}
    }], a.exports = e["default"]
});
;define("112cd80", function (e) {
    "use strict";
    function u(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    var t = e("13f1565"), f = u(t), c = e("cece673"), d = u(c);
    f.default.use(d.default)
});
;define("02f76d8", function (e) {
    "use strict";
    function t(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    e("112cd80"), e("21866d6");
    var u = e("b7e47cd"), f = (t(u), e("13f1565")), d = t(f), a = e("3665f4a"), n = t(a), r = e("9a06a56"), l = t(r), o = e("c4d9e68"), c = t(o), i = e("c3e5ef7"), s = e("29921ff"), m = t(s);
    d.default.use(n.default), d.default.use(l.default, {name: "v-touch"}), d.default.use(i.http);
    var h = new n.default({mode: "history", routes: c.default});
    h.beforeEach(function (e, t, u) {
        document.title = e.meta.title, u()
    }), new d.default({
        render: function (e) {
            return e(m.default)
        }, router: h
    }).$mount("#app")
});
;define("8b19be1", function (e, n, t) {
    "use strict";
    function i(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(n, "__esModule", {value: !0});
    var a = e("6cfeef6"), o = i(a), r = e("3eddb2a"), u = i(r), f = e("d918814"), c = i(f), d = e("c3e5ef7");
    n.default = {
        state: {weixinconfig: {}, weixinConfigDone: !1},
        mutations: c.default({}, "WEIXIN_CONFIG", function (e, n) {
            0 === n.code && (window.wx.config({
                debug: !1,
                appId: n.data.appId,
                timestamp: n.data.timestamp,
                nonceStr: n.data.nonceStr,
                signature: n.data.signature,
                jsApiList: ["onMenuShareTimeline", "onMenuShareAppMessage"]
            }), e.weixinconfig = n, e.weixinConfigDone = !0)
        }),
        actions: {
            weixinConfig: function (e) {
                var n = this;
                return u.default(o.default.mark(function t() {
                    var i;
                    return o.default.wrap(function (n) {
                        for (; ;)switch (n.prev = n.next) {
                            case 0:
                                return n.next = 2, d.api.getWeixinConfig({target_url: location.href}, {
                                    method: "GET",
                                    "x-silent": !0,
                                    "x-noblocking": !0
                                });
                            case 2:
                                i = n.sent, e.commit("WEIXIN_CONFIG", i);
                            case 4:
                            case"end":
                                return n.stop()
                        }
                    }, t, n)
                }))()
            }
        }
    }, t.exports = n["default"]
});
;define("6bafc50", function (e, a, t) {
    "use strict";
    function u(e) {
        return e && e.__esModule ? e : {"default": e}
    }

    Object.defineProperty(a, "__esModule", {value: !0});
    var d = e("13f1565"), f = u(d), l = e("621bc70"), n = u(l), o = e("8c09f0f"), r = u(o), s = e("7434137"), i = u(s), c = e("a5ae409"), b = u(c), p = e("a61a906"), _ = u(p), M = e("da9e113"), v = u(M), w = e("8b19be1"), x = u(w);
    f.default.use(n.default), a.default = new n.default.Store({
        modules: {
            dogMarket: r.default,
            personal: i.default,
            detail: b.default,
            introduce: _.default,
            splash: v.default,
            weixin: x.default
        }
    }), t.exports = a["default"]
});
;define("8724bbb", function (n, c, e) {
    "use strict";
    function t(n, c) {
        return p[parseInt(Math.random() * (n - c + 1) + c, 10)]
    }

    function o(n) {
        switch (n) {
            case"/chain/detail":
                return p[0];
            default:
                return t(13, 1)
        }
    }

    function i(n) {
        switch (n) {
            case"/chain/detail":
                return location.href.replace("channel=center", "channel=market");
            default:
                return location.protocol + "//" + location.host + "/chain/dogMarket?tpl=wechat"
        }
    }

    function b(n) {
        var c = {
            title: "", desc: "", link: i(n), imgUrl: o(n), success: function () {
            }, cancel: function () {
            }
        };
        switch (n) {
            case"/chain/detail":
                return c.title = "我的区块链数字狗，独一无二，好酷！", c.desc = "等你来看", c;
            default:
                return c.title = "区块链初代狗，限时免费领取！", c.desc = "手慢无！可爱、唯一、值得收藏的区块链数字狗，等你来领取！", c
        }
    }

    var p = ["https://blockchain-pet-online.bj.bcebos.com/vip_185106259741613260820180202124335", "https://blockchain-pet-online.bj.bcebos.com/vip_185194887250759680220180202195330", "https://blockchain-pet-online.bj.bcebos.com/vip_185194887250759680120180202195330", "https://blockchain-pet-online.bj.bcebos.com/vip_185198261377067417620180202200950", "https://blockchain-pet-online.bj.bcebos.com/vip_185198261377067417720180202200952", "https://blockchain-pet-online.bj.bcebos.com/vip_185198261377067417820180202200952", "https://blockchain-pet-online.bj.bcebos.com/vip_185102081597427712020180202122320", "https://blockchain-pet-online.bj.bcebos.com/vip_185194887250759680020180202195329", "https://blockchain-pet-online.bj.bcebos.com/vip_185102081597427712120180202122321", "https://blockchain-pet-online.bj.bcebos.com/vip_184868985132339200420180201173243.png", "https://blockchain-pet-online.bj.bcebos.com/vip_184868985132339200320180201173242.png", "https://blockchain-pet-online.bj.bcebos.com/vip_184868985132339200220180201173242.png", "https://blockchain-pet-online.bj.bcebos.com/vip_184868985132339200120180201173242.png", "https://blockchain-pet-online.bj.bcebos.com/vip_184868985132339200020180201173241.png"];
    e.exports = function (n) {
        setTimeout(function () {
            window.wx.ready(function () {
                window.wx.onMenuShareTimeline(b(n)), window.wx.onMenuShareAppMessage(b(n))
            })
        }, 300)
    }
});