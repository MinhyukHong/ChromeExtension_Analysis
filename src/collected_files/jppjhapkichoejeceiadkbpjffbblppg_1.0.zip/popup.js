const toggleButton = document.getElementById('toggleButton');

// Initialize the button's text based on the current state
chrome.storage.sync.get('isEnabled', (data) => {
    const isEnabled = data.isEnabled !== false;  // Default to true if not set
    toggleButton.textContent = isEnabled ? 'Disable' : 'Enable';
    toggleCSS(isEnabled);  // Apply the CSS based on the initial state
});

// Toggle the CSS when the button is clicked
toggleButton.addEventListener('click', () => {
    chrome.storage.sync.get('isEnabled', (data) => {
        const isEnabled = data.isEnabled !== false;
        const newState = !isEnabled;

        // Update the button text and storage
        toggleButton.textContent = newState ? 'Disable' : 'Enable';
        chrome.storage.sync.set({ isEnabled: newState }, () => {
            toggleCSS(newState);
        });
    });
});

// Function to inject or remove CSS based on the isEnabled state
function toggleCSS(enable) {
    chrome.tabs.query({ url: "*://*.x.com/*" }, (tabs) => {
        tabs.forEach((tab) => {
            if (enable) {
                // Inject the CSS if enabling
                chrome.scripting.insertCSS({
                    target: { tabId: tab.id },
                    files: ["styles.css"]
                }).catch((error) => console.log("Error inserting CSS:", error));
            } else {
                // Remove the CSS if disabling
                chrome.scripting.removeCSS({
                    target: { tabId: tab.id },
                    files: ["styles.css"]
                }).catch((error) => console.log("Error removing CSS:", error));
            }
        });
    });
}

// Add this after your existing code
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url?.includes('x.com')) {
    chrome.storage.sync.get('isEnabled', (data) => {
      const isEnabled = data.isEnabled !== false;
      if (isEnabled) {
        chrome.scripting.insertCSS({
          target: { tabId },
          files: ["styles.css"]
        }).catch((error) => console.log("Error inserting CSS:", error));
      }
    });
  }
});
