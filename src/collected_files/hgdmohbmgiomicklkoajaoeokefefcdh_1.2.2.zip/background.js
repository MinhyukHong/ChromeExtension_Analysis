chrome.runtime.onMessage.addListener(function (msg, sender) {
    var editorExtensionId = chrome.runtime.id;
    if ((msg.from === 'content') && (msg.subject === 'showPageAction')) {
        // highlight the corion extension
        chrome.pageAction.show(sender.tab.id)
        chrome.pageAction.setTitle({
            tabId: sender.tab.id,
            title: "Corion Key Hider (Click to show key)"
        });
        // chrome.tabs.create({
        //     url: "popup.html"
        // });
    }
});
chrome.webRequest.onCompleted.addListener(function (sender) {
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, function (tabs) {
        if (tabs.length == 0)
            return;
        // if not the opened tab then don't execute parsing
        if (sender.tabId != tabs[0].id)
            return;
        chrome.tabs.sendMessage(tabs[0].id, {
            from: 'content',
            subject: 'ParseCorionKeys'
        }, function (response) {});
    });
}, {
    urls: ["<all_urls>"],
    types: ["xmlhttprequest"]
});