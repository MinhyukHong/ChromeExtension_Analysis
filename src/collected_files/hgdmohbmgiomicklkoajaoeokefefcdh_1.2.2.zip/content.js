console.log("Corion Key Hider extension loaded");

// variables
var iconUrl = chrome.extension.getURL("images/icon.png");
var extensionId = chrome.runtime.id;
var corionKeyStyle = {
    fontFamily: "Helvetica, sans-serif",
    border: "1px solid #293795",
    borderRadius: "5px",
    //element.style.backgroundColor : "rgb(230,231,235)";
    backgroundColor: "rgb(246,246,246)",
    backgroundImage: "url('" + iconUrl + "')",
    backgroundPosition: "3px center",
    backgroundRepeat: "no-repeat",
    backgroundSize: "16px",
    padding: "4px",
    paddingLeft: "20px",
    color: "#0d47a1",
    lineHeight: "14px",
    margin: "0px",
    transition: "200ms",
    cursor: "pointer"
};
var PopupCode = null;




function ParseCorionKeys() {
    // old plain replace. Notwirkong with DOM elements
    //document.body.innerHTML = document.body.innerHTML.replace(re, "<button corion='corion'>$&</button>");
    // new TextNode search version
    findCorionKeys(document.body);

    // set the design element on the keys
    var elements = document.querySelectorAll('[corion="init"]');
    //console.log(elements.length);
    // start only if find corion data
    if (elements.length > 0) {


        for (var i = 0; i < elements.length; i++) {
            var element = elements[i];
            element.setAttribute("corion", "drawing");
            // get code from the element
            var plainCode = element.innerHTML;
            // clean inside
            element.innerHTML = "";
            element.innerHTML = "CORION hides this content";

            for (var key in this.corionKeyStyle) {
                element.style[key] = this.corionKeyStyle[key];
            }

            (function (code) {
                element.addEventListener("mouseover", function (elm) {
                    this.style.boxShadow = "0px 0px 5px #293795";
                });
                element.addEventListener("mouseout", function (elm) {
                    this.style.boxShadow = "none";
                });
                element.addEventListener("click", function (elm) {
                    PopupCode = code;
                    chrome.runtime.sendMessage({
                        from: 'content',
                        subject: 'showPageAction'
                    });
                })
            }(plainCode))
            element.setAttribute("corion", "completed");
        }

        chrome.runtime.onMessage.addListener(function (msg, sender, response) {
            if ((msg.from === 'popup') && (msg.subject === 'SendCorionCode')) {
                response(PopupCode);
            }
        });
    }
}

function findCorionKeys(parentNode) {
    // search for corion keys on the site
    var pattern = "(0x[0-9a-fA-F]{64}|[0-9a-fA-F]{64})";
    var re = new RegExp(pattern, "g");

    for (var i = parentNode.childNodes.length - 1; i >= 0; i--) {
        var node = parentNode.childNodes[i];

        //  Make sure this is a text node
        if (node.nodeType == Element.TEXT_NODE) {
            if (node.textContent.match(re)) {
                var btn = document.createElement("button");
                btn.setAttribute("corion", "init");
                btn.innerText = node.textContent;
                node.parentNode.replaceChild(btn, node);
            }
        } else if (node.nodeType == Element.ELEMENT_NODE) {
            if (node.tagName.toLowerCase() == "input") {
                if (node.value.match(re)) {
                    var btn = document.createElement("button");
                    btn.setAttribute("corion", "init");
                    btn.innerText = node.value;
                    node.parentNode.replaceChild(btn, node);
                }
            }
            findCorionKeys(node);
        }
    }
};

// enable messaging to asyc callbacks
chrome.runtime.onMessage.addListener(function (msg, sender, response) {
    if ((msg.from === 'content') && (msg.subject === 'ParseCorionKeys')) {
        ParseCorionKeys();
        response(true);
    }
});

// parse the main site
ParseCorionKeys();

// change fetch logic
var fetchDiff = 300;
var lastFetch = null;
var fetchTimer = null;

function StartFetching() {
    var now = new Date();
    if (lastFetch != null && (now.getTime() - lastFetch.getTime()) < fetchDiff) {
        clearTimeout(fetchTimer);
    }
    lastFetch = now;
    fetchTimer = setTimeout(ParseCorionKeys, fetchDiff);
}

document.addEventListener("DOMSubtreeModified", function () {
    StartFetching();
})