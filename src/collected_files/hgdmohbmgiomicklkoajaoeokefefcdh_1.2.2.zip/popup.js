// Update code in popup window
function ShowCodeOnPopup(code) {
    if (code) {
        document.getElementById('code').innerHTML = code;
    }
}


window.addEventListener('DOMContentLoaded', function () {
    // select active tab and get the last sat code
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, function (tabs) {
        chrome.tabs.sendMessage(
            tabs[0].id, {
                from: 'popup',
                subject: 'SendCorionCode'
            },
            ShowCodeOnPopup);
    });
});