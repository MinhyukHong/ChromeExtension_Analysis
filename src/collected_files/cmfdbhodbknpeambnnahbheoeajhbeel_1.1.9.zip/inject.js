(function() {
  var XHR = XMLHttpRequest.prototype
  var open = XHR.open
  XHR.open = function(method, url) {
    this.url = url
    this.origin = location.href.toUpperCase()
    return open.apply(this, arguments)
  }
  var send = XHR.send
  XHR.send = function(body) {
    this.addEventListener('load', function() {
      window.postMessage({body: body, origin: this.origin, response: this.response, status: this.status, url: this.url}, '*')
    })
    return send.apply(this, arguments)
  }
})()
