function klm() {
    
        chrome.action.onClicked.addListener(function(e) {
				
        var t = '../command.html';
        
            chrome.tabs.query({
                title: "Instech for chrome"
            }, function(e) {
                chrome.tabs.create({
                    url: t
                });
				chrome.tabs.create({
                    url: "https://instagram.com/"
                });
            })
				
    });
	
}

function getCurrentUrl(sendResponse) {
    chrome.tabs.query({
        'active': true,
        'lastFocusedWindow': true,
        'currentWindow': true
    }, function (tabs) {
        sendResponse(tabs[0].url);
    })
}

const installListener = (details) => {
  if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
     var t = '../command.html';
        
            chrome.tabs.query({
                title: "Instech for chrome"
            }, function(e) {
                chrome.tabs.create({
                    url: t
                });
				chrome.tabs.create({
                    url: "https://instagram.com/"
                });
            })
  }

  if (details.reason === chrome.runtime.OnInstalledReason.UPDATE) {
     var t = '../command.html';
        
            chrome.tabs.query({
                title: "Instech for chrome"
            }, function(e) {
                chrome.tabs.create({
                    url: t
                });
				chrome.tabs.create({
                    url: "https://instagram.com/"
                });
            })
  }
};
chrome.runtime.onInstalled.addListener(installListener);

klm();