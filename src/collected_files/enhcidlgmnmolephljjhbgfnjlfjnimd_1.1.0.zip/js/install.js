/* globals i18nHydrate */

window.addEventListener('DOMContentLoaded', () => {
  i18nHydrate();
});