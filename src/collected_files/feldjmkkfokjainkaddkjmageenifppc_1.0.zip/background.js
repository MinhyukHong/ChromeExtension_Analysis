'use strict';

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    const url = new URL(details.url);
    if (url.searchParams.has('hl')) {
      url.searchParams.delete('hl');
      return {redirectUrl: url.toString()}
    }
    return {}
  },
  {urls: ['https://cloud.google.com/*']},
  ['blocking'])
