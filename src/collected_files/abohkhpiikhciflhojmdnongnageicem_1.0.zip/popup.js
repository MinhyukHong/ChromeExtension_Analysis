document.addEventListener('DOMContentLoaded', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      let url = tabs[0].url;
      let qrUrl = `https://quickchart.io/qr?text=${encodeURIComponent(url)}&ecLevel=H&margin=10&size=150`;
      document.getElementById('qr-code').src = qrUrl;
    //   document.getElementById('download').href = qrUrl;
    })});

document.getElementById('share').addEventListener('click', function() {
    let qr = document.getElementById('qr-code').src;
    navigator.clipboard.writeText(qr)
        .then(() => {
            console.log('QR code URL copied to clipboard');
        })
        .catch((error) => {
            console.error('Failed to copy QR code URL to clipboard:', error);
        });
  });

document.getElementById('download').addEventListener('click', function() {
    chrome.downloads.download({
        url: "https://quickchart.io/qr?text=https%3A%2F%2Fchromewebstore.google.com%2Fcategory%2Fextensions%2Fproductivity%2Ftools&ecLevel=H&margin=10&size=150",
        filename: "qr.png"
      });
  });