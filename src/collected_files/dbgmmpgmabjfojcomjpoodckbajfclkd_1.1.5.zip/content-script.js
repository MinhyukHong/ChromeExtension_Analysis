(() => {
  const EventHub = new (class {
    emit(eventName, data) {
      const event = new CustomEvent(eventName, { detail: data });
      window.document.body.dispatchEvent(event);
    }

    on(eventName, listener, options) {
      window.document.body.addEventListener(eventName, listener, options);
    }

    off(eventName, listener, options) {
      window.document.body.removeEventListener(eventName, listener, options);
    }
  })();

  const Extension = new (class {
    init() {
      chrome.runtime.onMessage.addListener(this._onMessage.bind(this));
    }

    sendMessage(action, payload) {
      chrome.runtime.sendMessage({ action, payload });
    }

    _onMessage(request) {
      if (typeof request !== "object" || request === null) {
        console.error("invalid request:", request);
        return;
      }

      const { action, payload } = request;

      switch (action) {
        case "activate":
          this._activate(payload).catch(console.error);
          break;
        case "deactivate":
          this._deactivate().catch(console.error);
          break;
        case "screenshot-captured":
          this._screenshotCaptured(payload).catch(console.error);
          break;
        case "element-captured":
          this._elementCaptured(payload).catch(console.error);
          break;
        case "widget-slot-captured":
          this._widgetSlotCaptured(payload).catch(console.error);
          break;
      }
    }

    async _activate(payload) {
      EventHub.emit("plotline/ext/activate", payload);
    }

    async _deactivate() {
      EventHub.emit("plotline/ext/deactivate");
    }

    async _screenshotCaptured(payload) {
      EventHub.emit("plotline/ext/screenshot-captured", payload);
    }

    async _elementCaptured(payload) {
      EventHub.emit("plotline/ext/element-captured", payload);
    }

    async _widgetSlotCaptured(payload) {
      EventHub.emit("plotline/ext/widget-slot-captured", payload);
    }
  })();

  const ScriptInjector = new (class {
    init() {
      const files = ["sdk-bridge.js", "webpage-script.js"];
      for (const file of files) {
        const url = chrome.runtime.getURL(file);
        this._inject(url);
      }
    }

    _inject(src) {
      const script = document.createElement("script");
      script.type = "text/javascript";
      script.src = src;
      script.defer = true;
      script.async = true;
      document.body.appendChild(script);
    }
  })();

  Extension.init();
  ScriptInjector.init();

  EventHub.on("plotline/tab/capture-screenshot", () => {
    Extension.sendMessage("capture-screenshot");
  });

  EventHub.on("plotline/tab/deactivate", () => {
    Extension.sendMessage("deactivate");
  });

  EventHub.on("plotline/tab/open-url", (event) => {
    const url = event.detail;
    Extension.sendMessage("open-url", url);
  });

  EventHub.on("plotline/tab/open-url-for-widget", (event) => {
    const url = event.detail;
    Extension.sendMessage("open-url-for-widget", url);
  });

  EventHub.on("plotline/tab/mode-changed", (event) => {
    const mode = event.detail;
    Extension.sendMessage("mode-changed", mode);
  });

  EventHub.on("plotline/tab/element-captured", (event) => {
    const data = event.detail;
    Extension.sendMessage("element-captured", data);
  });

  EventHub.on("plotline/tab/widget-slot-captured", (event) => {
    const data = event.detail;
    Extension.sendMessage("widget-slot-captured", data);
  });

  EventHub.on("plotline/ext/get-resources", () => {
    const resources = {
      plotline_logo: chrome.runtime.getURL("assets/icon.png"),
      webpage_stylesheet: chrome.runtime.getURL("webpage-stylesheet.css"),
    };
    EventHub.emit("plotline/tab/resources", resources);
  });
})();
