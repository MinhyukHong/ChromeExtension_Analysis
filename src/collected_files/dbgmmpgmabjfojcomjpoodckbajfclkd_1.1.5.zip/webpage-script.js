(() => {
  const EventHub = new (class {
    emit(eventName, data) {
      const event = new CustomEvent(eventName, { detail: data });
      window.document.body.dispatchEvent(event);
    }

    on(eventName, listener, options) {
      window.document.body.addEventListener(eventName, listener, options);
    }

    off(eventName, listener, options) {
      window.document.body.removeEventListener(eventName, listener, options);
    }
  })();

  const DOMBuilder = new (class {
    build(node) {
      if (typeof node === "string" || typeof node === "number") {
        return document.createTextNode(`${node}`);
      } else {
        return this._createNode(node);
      }
    }

    _createNode({ type, id, classes, style, children, attributes, ref }) {
      const element = document.createElement(type);
      if (id) element.setAttribute("id", id);
      if (classes) element.classList.add(...classes);
      if (style) {
        const entries = Object.entries(style);
        for (const [key, value] of entries) {
          element.style[key] = value;
        }
      }
      if (children) {
        for (const child of children) {
          const childNode = this.build(child);
          element.appendChild(childNode);
        }
      }
      if (attributes) {
        for (const [name, value] of Object.entries(attributes)) {
          element.dataset[name] = value;
        }
      }
      if (ref) ref(element);
      return element;
    }
  })();

  const Selector = new (class {
    generate(node) {
      const text = node.textContent;
      const path = this._getPath(node);
      const parts = path.map((node) => this._getQuery(node));

      // Loop for every possible sub-pattern
      for (let startIndex = 0; startIndex < parts.length - 1; startIndex++) {
        for (let i = startIndex; i < parts.length; i++) {
          const slice = parts.slice(startIndex, i + 1).reverse();
          const query = slice.join(" > ");
          const selection = document.querySelectorAll(query);
          const filtered = [...selection].filter(
            (node) => node.textContent === text
          );
          if (filtered.length === 1) return { query, text, type: "matches" };
        }
      }

      // Nothing found in normal method, try contains
      for (let startIndex = 0; startIndex < parts.length - 1; startIndex++) {
        for (let i = startIndex; i < parts.length; i++) {
          const slice = parts.slice(startIndex, i + 1).reverse();
          const query = slice.join(" > ");
          const selection = document.querySelectorAll(query);
          const filtered = [...selection].filter((node) =>
            node.textContent.includes(text)
          );
          if (filtered.length === 1) return { query, text, type: "regex" };
        }
      }

      if (parts.length === 1) {
        return { query: parts[0], text, type: "matches" };
      }

      return null;
    }

    _getPath(node) {
      const path = [];
      while (node) {
        path.push(node);
        if (node.getAttribute("id")) break;
        node = node.parentElement;
        if (node === document.body) break;
      }
      return path;
    }

    _getQuery(node) {
      const id = node.getAttribute("id");
      if (id) return `#${id}`;

      const parts = [node.nodeName.toLowerCase()];

      const classes = [...node.classList].join(" ").substring(0, 12);
      if (classes) parts.push(`[class^="${classes.replace(/"/g, `\\"`)}"]`);

      const type = node.getAttribute("type");
      if (type) parts.push(`[type="${type}"]`);

      const alt = node.getAttribute("alt");
      if (alt) parts.push(`[alt="${alt}"]`);

      const href = node.getAttribute("href");
      if (href) parts.push(`[href="${href.replace(/"/g, `\\"`)}"]`);

      const query = parts.join("");

      const parent = node.parentElement;
      if (parent) {
        const selections = parent.querySelectorAll(query);
        if (selections.length > 1) {
          const children = [...parent.children];
          const index = children.indexOf(node);
          return `${query}:nth-child(${index + 1})`;
        }
      }

      return query;
    }
  })();

  const Root = new (class {
    constructor() {
      this._root = null;
      this._shadow = null;
      this._stylesheet = null;
    }

    get shadow() {
      return this._shadow;
    }

    show() {
      this._root.style.opacity = "1";
      this._root.style.pointerEvents = "auto";
    }

    hide() {
      this._root.style.opacity = "0";
      this._root.style.pointerEvents = "none";
    }

    initialise() {
      this._root = DOMBuilder.build({
        type: "div",
        attributes: { plotlineBypass: true },
      });
      this._shadow = this._root.attachShadow({ mode: "closed" });
      this._stylesheet = document.createElement("link");

      this._shadow.appendChild(this._stylesheet);
      document.body.appendChild(this._root);
    }

    deinitialise() {
      document.body.removeChild(this._root);
      this._root = null;
      this._shadow = null;
      this._stylesheet = null;
    }

    onResourceLoad(resources) {
      this._stylesheet.href = resources.webpage_stylesheet;
      this._stylesheet.rel = "stylesheet";
    }
  })();

  const Targeter = new (class {
    constructor() {
      this._overlay = null;
      this._highlight = null;
      this._target = null;
      this._isActive = false;
    }

    initialise() {
      this._overlay = DOMBuilder.build({
        type: "div",
        classes: ["overlay"],
      });
      this._highlight = DOMBuilder.build({
        type: "div",
        classes: ["highlight"],
      });
    }

    deinitialise() {
      if (this._isActive) this.deactivate();

      this._overlay = null;
      this._highlight = null;
      this._target = null;
      this._isActive = false;
    }

    activate() {
      Root.shadow.appendChild(this._overlay);
      Root.shadow.appendChild(this._highlight);

      window.addEventListener("mousemove", this._onMouseMove);
      window.addEventListener("click", this._onMouseClick);
      window.addEventListener("scroll", this._onScroll);

      this._isActive = true;
    }

    deactivate() {
      Root.shadow.removeChild(this._overlay);
      Root.shadow.removeChild(this._highlight);

      window.removeEventListener("mousemove", this._onMouseMove);
      window.removeEventListener("click", this._onMouseClick);
      window.removeEventListener("scroll", this._onScroll);

      this._isActive = false;
    }

    _onMouseMove = (event) => {
      const elements = document.elementsFromPoint(event.clientX, event.clientY);
      const targets = [...elements].filter(
        (element) => !element.dataset.plotlineBypass
      );
      const target = targets[0];

      if (target) {
        const bounds = target.getBoundingClientRect();
        this._highlight.style.top = `${bounds.top}px`;
        this._highlight.style.left = `${bounds.left}px`;
        this._highlight.style.width = `${bounds.width}px`;
        this._highlight.style.height = `${bounds.height}px`;
        this._highlight.style.opacity = "1";
        this._target = target;
      }
    };

    _onMouseClick = (event) => {
      event.preventDefault();

      const target = this._target;
      if (!target) return;

      Root.hide();

      EventHub.on(
        "plotline/ext/screenshot-captured",
        (event) => this._onScreenshotCaptured(event, target),
        {
          once: true,
        }
      );

      setTimeout(() => EventHub.emit("plotline/tab/capture-screenshot"), 500);
    };

    _onScroll = () => {
      this._highlight.style.opacity = "0";
      this._target = null;
    };

    _onScreenshotCaptured = (event, target) => {
      Root.show();

      const dataUrl = event.detail;
      const selector = Selector.generate(target);

      const bounds = target.getBoundingClientRect();
      const dpr = window.devicePixelRatio;
      const width = window.innerWidth;
      const height = window.innerHeight;
      const pageId = window.location.pathname;

      EventHub.emit("plotline/tab/element-captured", {
        screenshot: { dataUrl, width, height },
        selector,
        bounds,
        dpr,
        pageId,
      });
    };
  })();

  const Widgets = new (class {
    constructor() {
      this._intervalId = 0;
      this._controller = null;
      this._slots = new Set();
    }

    startFindingSlots() {
      if (this._intervalId) return;
      this._intervalId = window.setInterval(() => this._findSlots(), 1e3);
      this._controller = new AbortController();
    }

    stopFindingSlots() {
      if (!this._intervalId) return;

      window.clearInterval(this._intervalId);
      this._controller.abort();
      for (const slot of this._slots) slot.innerHTML = "";

      this._intervalId = 0;
      this._controller = null;
      this._slots = new Set();
    }

    _findSlots() {
      const matches = window.document.querySelectorAll(
        "[data-plotline-widget]"
      );

      for (const element of matches.values()) {
        if (
          !(element instanceof HTMLElement) ||
          element.dataset.slotInitialised === "true" ||
          !element.getAttribute("id")
        ) {
          continue;
        }
        this._setupSlot(element);
      }
    }

    _setupSlot(element) {
      const id = element.getAttribute("id");
      const text = DOMBuilder.build({
        type: "div",
        children: [`Plotline widget slot\n#${id}`],
        style: {
          display: "flex",
          padding: "32px 16px",
          border: "1px dashed #553097",
          borderRadius: "8px",
          backgroundColor: "#fbf8ff",
          justifyContent: "center",
          alignItems: "center",
          color: "#553097",
          fontSize: "12px",
          fontFamily: "monospace",
          textAlign: "center",
          whiteSpace: "pre",
          cursor: "pointer",
        },
      });

      element.innerHTML = "";
      element.appendChild(text);
      element.addEventListener(
        "click",
        () => {
          const pageId = window.location.pathname;
          const bounds = element.getBoundingClientRect();
          const width = window.innerWidth;
          const height = window.innerHeight;
          this.stopFindingSlots();
          EventHub.emit("plotline/tab/widget-slot-captured", {
            id,
            pageId,
            bounds,
            width,
            height,
          });
        },
        {
          signal: this._controller.signal,
        }
      );
      element.dataset.slotInitialised = "true";

      this._slots.add(element);
    }
  })();

  const BottomBar = new (class {
    constructor() {
      this._container = null;
      this._padding = null;
      this._logo = null;
      this._text = null;
      this._switchButton = null;
      this._isSelectingElement = false;
    }

    initialise() {
      let logoRef = null;
      let textRef = null;
      let switchButtonRef = null;
      let cancelButtonRef = null;

      const container = DOMBuilder.build({
        type: "div",
        classes: ["container"],
        children: [
          {
            type: "div",
            classes: ["left"],
            children: [
              {
                type: "img",
                classes: ["logo"],
                ref: (node) => (logoRef = node),
              },
              {
                type: "span",
                ref: (node) => (textRef = node),
              },
            ],
          },
          {
            type: "div",
            classes: ["right"],
            children: [
              {
                type: "button",
                classes: ["button", "button-switch"],
                ref: (node) => (switchButtonRef = node),
              },
              {
                type: "button",
                classes: ["button", "button-cancel"],
                children: ["Cancel"],
                ref: (node) => (cancelButtonRef = node),
              },
            ],
          },
        ],
      });

      const padding = DOMBuilder.build({
        type: "div",
        classes: ["padding"],
      });

      Root.shadow.appendChild(container);
      Root.shadow.appendChild(padding);

      switchButtonRef.addEventListener("click", (event) => {
        event.stopPropagation();
        this.toggleMode();
      });
      cancelButtonRef.addEventListener("click", (event) => {
        event.stopPropagation();
        this.onCancel();
      });

      this._container = container;
      this._padding = padding;
      this._logo = logoRef;
      this._text = textRef;
      this._switchButton = switchButtonRef;

      this._text.textContent = "Navigate to the target page";
      this._switchButton.textContent = "Select the target element";
    }

    deinitialise() {
      Root.shadow.removeChild(this._container);
      Root.shadow.removeChild(this._padding);

      this._container = null;
      this._padding = null;
      this._logo = null;
      this._text = null;
      this._switchButton = null;
      this._isSelectingElement = false;
    }

    onCancel() {
      EventHub.emit("plotline/tab/deactivate");
    }

    hide() {
      this._container.style.transform = "translateY(100%)";
      this._padding.style.display = "none";
    }

    toggleMode(isSelectingElement = !this._isSelectingElement) {
      if (isSelectingElement) {
        this._text.textContent = "Click an element to select it";
        this._switchButton.textContent = "Navigate to another page";
        Targeter.activate();
        EventHub.emit("plotline/tab/mode-changed", "select-element");
      } else {
        this._text.textContent = "Navigate to the target page";
        this._switchButton.textContent = "Select the target element";
        Targeter.deactivate();
        EventHub.emit("plotline/tab/mode-changed", "navigate");
      }
      this._isSelectingElement = isSelectingElement;
    }

    onResourceLoad(resources) {
      this._logo.src = resources.plotline_logo;
    }
  })();

  const Main = new (class {
    constructor() {
      this._isActivated = false;
      this._isWidgetActivated = false;
    }

    setup() {
      EventHub.on("plotline/ext/activate", this._onActivate);
      EventHub.on("plotline/ext/deactivate", this._onDeactivate);
      EventHub.on("plotline/tab/resources", this._onResources);
    }

    _onActivate = (event) => {
      if (window.plotline) {
        window.plotline("logout");
        window.plotline = () => null;
      }

      const { mode } = event.detail;
      if (mode === "widget") {
        if (!this._isWidgetActivated) {
          this._isWidgetActivated = true;
          Widgets.startFindingSlots();
        }
      } else {
        const isSelectingElement = mode === "select-element";

        if (!this._isActivated) {
          Root.initialise();
          Targeter.initialise();
          BottomBar.initialise();

          this._isActivated = true;

          EventHub.emit("plotline/ext/get-resources");
        }

        BottomBar.toggleMode(isSelectingElement);
      }
    };

    _onDeactivate = () => {
      if (this._isWidgetActivated) {
        Widgets.stopFindingSlots();
        this._isWidgetActivated = false;
      }

      if (this._isActivated) {
        BottomBar.deinitialise();
        Targeter.deinitialise();
        Root.deinitialise();

        this._isActivated = false;
      }
    };

    _onResources = (event) => {
      if (!this._isActivated) return;

      const resources = event.detail;
      Root.onResourceLoad(resources);
      BottomBar.onResourceLoad(resources);
    };
  })();

  Main.setup();

  Object.defineProperty(window, "__plotline_extension_is_active", {
    value: true,
  });
})();
