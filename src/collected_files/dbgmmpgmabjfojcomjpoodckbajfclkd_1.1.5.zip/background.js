(() => {
  class Extension {
    constructor() {
      this._activeTabs = new Map();
    }

    onMessage(request, sender) {
      if (typeof request !== "object" || request === null) {
        console.error("invalid request:", request);
        return;
      }

      const { action, payload } = request;

      switch (action) {
        case "capture-screenshot":
          this._captureScreenshot(sender).catch(console.error);
          break;
        case "open-url":
          this._openUrl(sender, payload).catch(console.error);
          break;
        case "open-url-for-widget":
          this._openUrlForWidget(sender, payload).catch(console.error);
          break;
        case "element-captured":
          this._elementCaptured(sender, payload).catch(console.error);
          break;
        case "mode-changed":
          this._modeChanged(sender, payload).catch(console.error);
          break;
        case "widget-slot-captured":
          this._widgetSlotCaptured(sender, payload).catch(console.error);
          break;
        case "deactivate":
          this._deactivate(sender).catch(console.error);
          break;
      }
    }

    async onUpdated(tabId, info) {
      if (this._activeTabs.has(tabId) && info.status === "complete") {
        await chrome.tabs.sendMessage(tabId, {
          action: "activate",
          payload: {
            mode: this._activeTabs.get(tabId),
          },
        });
      }
    }

    async onRemoved(tabId, _info) {
      if (this._activeTabs.has(tabId)) {
        this._activeTabs.delete(tabId);
      }
    }

    async _captureScreenshot(sender) {
      let dataUrl = "";
      try {
        dataUrl = await chrome.tabs.captureVisibleTab(null, {
          format: "png",
        });
      } catch (error) {
        console.error(error);
      }
      await chrome.tabs.sendMessage(sender.tab.id, {
        action: "screenshot-captured",
        payload: dataUrl,
      });
    }

    async _openUrl(sender, url) {
      const { id, index, windowId } = sender.tab;
      const tab = await chrome.tabs.create({
        active: true,
        openerTabId: id,
        index: index + 1,
        url,
        windowId,
      });
      this._activeTabs.set(tab.id, "select-element");
    }

    async _openUrlForWidget(sender, url) {
      const { id, index, windowId } = sender.tab;
      const tab = await chrome.tabs.create({
        active: true,
        openerTabId: id,
        index: index + 1,
        url,
        windowId,
      });
      this._activeTabs.set(tab.id, "widget");
    }

    async _elementCaptured(sender, data) {
      const { id, openerTabId } = sender.tab;
      if (openerTabId) {
        await chrome.tabs.update(openerTabId, { active: true });
        await chrome.tabs.sendMessage(openerTabId, {
          action: "element-captured",
          payload: data,
        });
      }

      if (this._activeTabs.has(id)) {
        this._activeTabs.delete(id);
        await chrome.tabs.sendMessage(id, {
          action: "deactivate",
        });
      }
    }

    async _modeChanged(sender, data) {
      const { id } = sender.tab;
      this._activeTabs.set(id, data);
    }

    async _widgetSlotCaptured(sender, data) {
      const { id, openerTabId } = sender.tab;
      if (openerTabId) {
        await chrome.tabs.update(openerTabId, { active: true });
        await chrome.tabs.sendMessage(openerTabId, {
          action: "widget-slot-captured",
          payload: data,
        });
      }

      if (this._activeTabs.has(id)) {
        this._activeTabs.delete(id);
        await chrome.tabs.sendMessage(id, {
          action: "deactivate",
        });
      }
    }

    async _deactivate(sender) {
      const { id } = sender.tab;
      if (this._activeTabs.has(id)) {
        this._activeTabs.delete(id);
        await chrome.tabs.sendMessage(id, {
          action: "deactivate",
        });
      }
    }
  }

  const extension = new Extension();
  chrome.runtime.onMessage.addListener((request, sender) => {
    extension.onMessage(request, sender);
  });
  chrome.tabs.onUpdated.addListener((tabId, info) => {
    extension.onUpdated(tabId, info).catch(console.error);
  });
  chrome.tabs.onRemoved.addListener((tabId, info) => {
    extension.onRemoved(tabId, info).catch(console.error);
  });
})();
