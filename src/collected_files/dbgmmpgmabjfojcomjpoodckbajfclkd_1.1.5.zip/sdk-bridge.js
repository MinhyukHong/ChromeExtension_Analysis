(() => {
  const overrideInternals = () => {
    const eventHub = window.document.body;
    const handler = async () => {
      return new Promise((resolve, reject) => {
        eventHub.addEventListener(
          "plotline/ext/screenshot-captured",
          (event) => resolve(event.detail),
          { once: true }
        );

        const event = new CustomEvent("plotline/tab/capture-screenshot");
        eventHub.dispatchEvent(event);

        setTimeout(() => reject("Plotline extension did not respond."), 5e3);
      });
    };
    window.plotline("overrideInternals", "get-screenshot", handler);
  };

  const waitForSDK = (count = 0) => {
    if (count < 60) {
      if (window.plotline) overrideInternals();
      else setTimeout(() => waitForSDK(count + 1), 1e3);
    } else {
      console.log("SDK bridge failed to override the internals.");
    }
  };

  waitForSDK();
})();
