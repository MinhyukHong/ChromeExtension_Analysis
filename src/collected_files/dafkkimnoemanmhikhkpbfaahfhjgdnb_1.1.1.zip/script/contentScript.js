try {
    let lastPath = '';
    const authUrl = isInitPage => {
        const url = window.location.href;
        const path = window.location.pathname;
        // console.log('lastPath:::', lastPath, 'current path:::', path);
        let flag = false;

        if (isInitPage && path === '/') {
            flag = true;
        } else if (lastPath === path) {
            flag = false;
        } else if (path === '/' || url.includes('openai.com/?model=text')) {
            flag = true;
        } else {
            flag = false;
        }
        setTimeout(() => {
            lastPath = path;
        }, 100);
        return flag;
        // console.log('isInitPage', isInitPage, path);
        // if (isInitPage && path === '/') {
        //     return true;
        // } else if (url === 'https://chat.openai.com/' || url.includes('openai.com/?model=text')) {
        //     return true;
        // } else {
        //     return false;
        // }
    };
    const addLoading = () => {
        const main = document.querySelector('main');
        var newElement = document.createElement('div');
        newElement.classList.add('_prompt_loadding');
        newElement.innerHTML = `<svg t="1689147650695" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4133" xmlns:xlink="http://www.w3.org/1999/xlink" width="300" height="300"><path d="M512.000427 1024c-69.12 0-136.192-13.482667-199.296-40.192a510.293333 510.293333 0 0 1-162.688-109.824A510.293333 510.293333 0 0 1 0.000427 512a35.968 35.968 0 1 1 72.021333 0 439.338667 439.338667 0 0 0 128.896 311.210667A437.717333 437.717333 0 0 0 512.000427 951.978667a439.338667 439.338667 0 0 0 311.210666-128.896A437.717333 437.717333 0 0 0 951.979093 512c0-59.392-11.562667-116.992-34.56-171.306667a440.448 440.448 0 0 0-94.293333-139.904A437.717333 437.717333 0 0 0 512.000427 71.978667 35.968 35.968 0 1 1 512.000427 0c69.12 0 136.192 13.482667 199.296 40.192a510.293333 510.293333 0 0 1 162.688 109.824 511.104 511.104 0 0 1 109.696 162.688c26.709333 63.104 40.234667 130.176 40.234666 199.296s-13.525333 136.192-40.234666 199.296a508.373333 508.373333 0 0 1-109.653334 162.688A511.104 511.104 0 0 1 512.000427 1024z" fill="#000000" opacity=".65" p-id="4134"></path></svg>`;
        // if (!document.querySelector('main').querySelector('._prompt_loadding')) {
        main.appendChild(newElement);
        // }
    };

    const removeLoading = () => {
        try {
            const main = document.querySelector('main');
            const remove_dom = main.querySelectorAll('._prompt_loadding');
            remove_dom.forEach(ele => {
                main.removeChild(ele);
            });
        } catch (e) {}
    };

    const removeNavSwitch = () => {
        try {
            const main = document.querySelectorAll('nav[aria-label="Chat history"]')[0];
            const remove_dom = main.querySelectorAll('.promptport_content_nav_switch');
            remove_dom.forEach((ele, index) => {
                if (index !== 0) {
                    main.removeChild(ele);
                }
            });
        } catch (e) {}
    };

    const addNavSwitch = () => {
        try {
            let i = 0;
            const action = () => {
                const switch_dom = document.querySelector('#promptport_content');
                if (!switch_dom) {
                    const main = document.querySelectorAll('nav[aria-label="Chat history"]')[0];
                    if (!main) {
                        i++;
                        if (i < 50) {
                            setTimeout(() => {
                                action();
                            }, 500);
                        }
                    } else {
                        const url = window.location.href;
                        chrome.storage.local.get('iframe', function (result) {
                            var newElement = document.createElement('a');
                            newElement.setAttribute('id', 'promptport_content');
                            newElement.setAttribute('class', 'promptport_content_nav_switch');
                            let innerHTML = '<div class="logo"><img src="https://promptport.ai/_next/image?url=%2Fimages%2Flogo%2Flogo.png&w=256&q=75" alt="" /></div><div class="switch" id="_promptport_switch"></div>';
                            if (result && result?.iframe === 'open') {
                                innerHTML = '<div class="logo"><img src="https://promptport.ai/_next/image?url=%2Fimages%2Flogo%2Flogo.png&w=256&q=75" alt="" /></div><div class="switch open" id="_promptport_switch"></div>';
                            }
                            newElement.innerHTML = innerHTML;
                            var firstChild = main.firstChild;
                            main.insertBefore(newElement, firstChild);
                            removeNavSwitch();
                            newElement.addEventListener('click', () => {
                                const nav = document.getElementById('_promptport_switch').classList;
                                handNavSwitch(nav.contains('open') ? 'close' : 'open');
                            });
                        });

                        document
                            .querySelectorAll('nav[aria-label="Chat history"]')[0]
                            .querySelectorAll(':scope > div.flex')[0]
                            .addEventListener('click', () => {
                                chrome.storage.local.get('iframe', function (result) {
                                    try {
                                        if (result && result?.iframe === 'open') {
                                            if (authUrl()) {
                                                setTimeout(() => {
                                                    addLoading();
                                                }, 500);
                                            }
                                            addIframe(true);
                                            document.getElementById('_promptport_switch').classList.add('open');
                                        } else {
                                            document.getElementById('_promptport_switch').classList.remove('open');
                                        }
                                    } catch (e) {}
                                });
                            });
                    }
                }
            };
            setTimeout(() => {
                action();
            }, 100);
        } catch (e) {}
    };
    addNavSwitch();

    const addIframe1 = (isInitPage = false) => {
        try {
            if (!authUrl(isInitPage)) return;
            addLoading();
            let i = 0;
            var elements = document.querySelector('main').querySelector('.text-sm.flex-col.h-full');
            const action = () => {
                if (!elements) {
                    i++;
                    if (i < 100) {
                        setTimeout(() => {
                            elements = document.querySelector('main').querySelector('.text-sm.flex-col.h-full');
                            action();
                        }, 500);
                    } else {
                        removeLoading();
                    }
                } else {
                    setTimeout(() => {
                        const dom = document.querySelector('html');
                        dom.classList.replace('dark', 'light');
                        dom.classList.add('promptport');
                        dom.style['color-scheme'] = 'light';
                        const doms = elements.querySelectorAll(':scope > .w-full');
                        doms[doms.length - 1].classList.add('_fulls');
                        doms[doms.length - 1].innerHTML = '<iframe src="https://promptport.ai" id="promptport_iframe"></iframe>';
                        // doms[doms.length - 1].innerHTML = '<iframe src="http://localhost:3000" id="promptport_iframe"></iframe>';

                        const shrinkdoms = elements.querySelectorAll(':scope > .flex-shrink-0');
                        if (shrinkdoms && shrinkdoms.length > 0) {
                            shrinkdoms[shrinkdoms.length - 1].classList.add('_none');
                        }
                    }, 2000);
                    setTimeout(() => {
                        removeLoading();
                    }, 3000);
                }
            };
            action();
        } catch (e) {}
    };

    const addIframe = (isInitPage = false) => {
        try {
            if (!authUrl(isInitPage)) return;
            addLoading();
            let i = 0;
            //
            var elements = document.querySelector('main').querySelector(':scope > div.flex');
            // console.log('addIframe:::::::::')
            const action = () => {
                if (!elements) {
                    i++;
                    if (i < 100) {
                        setTimeout(() => {
                            elements = document.querySelector('main').querySelector(':scope > div.flex');
                            action();
                        }, 500);
                    } else {
                        removeLoading();
                    }
                } else {
                    setTimeout(() => {
                        elements = document.querySelector('main').querySelector(':scope > div.flex').querySelector(':scope > .flex-1').querySelector(':scope > div').querySelector(':scope > div.flex-col');
                        const dom = document.querySelector('html');
                        dom.classList.replace('dark', 'light');
                        dom.classList.add('promptport');
                        dom.style['color-scheme'] = 'light';

                        // elements.setAttribute('style', 'padding-bottom: 8rem');

                        // const _doms = elements.querySelectorAll(':scope > div');

                        // var oldNode = _doms[1];

                        // var newNode = document.createElement('div');
                        // newNode.classList.add('_fulls');
                        // // newNode.style = 'width: 100%; height: 100vh; display: flex; justify-content:center;align-items:center; position: relative;overflow-y: hidden;';
                        // newNode.style = 'felx: 1;overflow-y: hidden;';
                        // newNode.innerHTML = `
                        //             <div id="promptport-container" style="width: 100%; display: flex;overflow-y: auto;" data-v-app="">
                        //                 <div class="h-screen w-[100%] flex flex-col bg-[#f8f8fc]" style="width: 100% !important; background-color: rgb(248, 248, 252);">
                        //                     <iframe id="app" class="w-[100%] h-[100%] flex-1" src="http://localhost:3000" style="padding-bottom: 240px;"></iframe>
                        //                 </div>
                        //             </div>
                        //         `;
                        // oldNode.replaceWith(newNode);

                        // _doms.forEach((ele, index) => {
                        //     if (index === 1) {
                        //         var oldNode = _doms[index];

                        //         var newNode = document.createElement('div');
                        //         newNode.classList.add('_fulls');
                        //         // newNode.style = 'width: 100%; height: 100vh; display: flex; justify-content:center;align-items:center; position: relative;overflow-y: hidden;';
                        //         newNode.style = 'felx: 1;overflow-y: hidden;';
                        //         newNode.innerHTML = `
                        //             <div id="promptport-container" style="width: 100%; display: flex;overflow-y: auto;" data-v-app="">
                        //                 <div class="h-screen w-[100%] flex flex-col bg-[#f8f8fc]" style="width: 100% !important; background-color: rgb(248, 248, 252);">
                        //                     <iframe id="app" class="w-[100%] h-[100%] flex-1" src="http://localhost:3000" style="padding-bottom: 240px;"></iframe>
                        //                 </div>
                        //             </div>
                        //         `;
                        //         // const newNodes = `
                        //         // <div class="" style="width: 100%; height: 100vh; display: flex; justify-content:center;align-items:center; position: relative;">
                        //         //     <div id="sp-container" style="width: 100%; display: flex;" data-v-app="">
                        //         //         <div class="h-screen w-[100%] flex flex-col bg-[#f8f8fc]" style="width: 100% !important; background-color: rgb(248, 248, 252);">
                        //         //             <iframe id="app" class="w-[100%] h-[100%] flex-1" src="https://promptport.ai" style="padding-bottom: 240px;"></iframe>
                        //         //         </div>
                        //         //     </div>
                        //         // </div>`;
                        //         // oldNode.innerHTML = '<iframe src="https://promptport.ai" id="promptport_iframe"></iframe>';
                        //         // oldNode.innerHTML = newNodes;
                        //         oldNode.replaceWith(newNode);
                        //         // parentNode.replaceChild(newNodes, oldNode);
                        //     }
                        // });

                        // const shrinkdoms = elements.querySelectorAll(':scope > div.flex-shrink-0');
                        // if (shrinkdoms && shrinkdoms.length > 0) {
                        //     shrinkdoms[shrinkdoms.length - 1].classList.add('_none');
                        // }
                        // setTimeout(() => {
                        //     elements.scrollIntoView({
                        //         block: 'start',
                        //     });
                        // },500)
                        // return;

                        // function_two
                        // console.log('set addIframe--------', elements)
                        // console.log('set addIframe--------', elements.querySelectorAll(':scope > div'))
                        // const doms = elements.querySelectorAll(':scope > div');
                        const doms = elements;

                        doms.classList.add('_fulls');
                        doms.innerHTML = '<iframe src="https://promptport.ai" id="promptport_iframe"></iframe>';
                        // var newIframe = document.createElement('iframe');

                        // newIframe.src = 'https://promptport.ai';
                        // newIframe.id = 'promptport_iframe';
                        // doms.appendChild(newIframe);
                        // doms[doms.length - 1].innerHTML = '<iframe src="http://localhost:3000" id="promptport_iframe"></iframe>';

                        const shrinkdoms = elements.querySelectorAll(':scope > div');
                        if (shrinkdoms && shrinkdoms.length > 0) {
                            shrinkdoms[shrinkdoms.length - 1].classList.add('_none');
                        }

                        // hidden footer bar
                        // const footerdoms = document.querySelector('form').querySelector(':scope > div').querySelectorAll(':scope > div');
                        // if (footerdoms.length > 1) {
                        //     for (let i = 0; i < footerdoms.length; i++) {
                        //         if (i !== 0) {
                        //             footerdoms[i].classList.add('_none');
                        //         }
                        //     }
                        // }
                    }, 2000);
                    setTimeout(() => {
                        removeLoading();
                        elements.scrollIntoView({
                            block: 'start',
                        });
                    }, 3000);
                }
            };
            action();
        } catch (e) {}
    };

    const handNavSwitch = status => {
        chrome.storage.local.set({ iframe: status });
        if (status === 'close') {
            document.getElementById('_promptport_switch').classList.remove('open');
            window.location.reload();
        } else {
            document.getElementById('_promptport_switch').classList.add('open');
            addIframe();
        }
    };

    const setIframeByRouterListener = () => {
        chrome.storage.local.get('iframe', function (result) {
            try {
                const url = window.location.href;
                if (result && result?.iframe === 'open') {
                    if (authUrl()) {
                        setTimeout(() => {
                            addLoading();
                        }, 500);
                    }
                    addIframe();
                    document.getElementById('_promptport_switch').classList.add('open');
                } else {
                    document.getElementById('_promptport_switch').classList.remove('open');
                }
            } catch (e) {}
        });
    };

    // receive plug message
    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
        const { type } = message;
        if (type === 'add_nav_switch') {
            addNavSwitch();
            setIframeByRouterListener();
        } else if (type === 'iframe') {
            handNavSwitch(message.status);
        } else if (type === 'addtoken') {
            var iframe = document.querySelector('#promptport_iframe');
            iframe.contentWindow.postMessage(
                {
                    target: 'promptport-inpage',
                    data: {
                        method: 'reload_userinfo',
                        data: {},
                    },
                },
                '*'
            );
            chrome.storage.local.set({ token: '' });
        }
    });

    chrome.storage.local.get('iframe', function (result) {
        try {
            if (result && result?.iframe === 'open') {
                addIframe(true);
                document.getElementById('_promptport_switch').classList.add('open');
            } else {
                document.getElementById('_promptport_switch').classList.remove('open');
            }
        } catch (e) {}
    });
} catch (e) {}

window.addEventListener('message', function (ev) {
    if (event.source === window && event.data && event.data.target === 'promptport-inpage') {
        const { method, data } = event.data.data;
        if (method === 'login_method') {
            // local     jnkdopgikakdmmlankkhcpfmlmgnkbkp
            // product   dafkkimnoemanmhikhkpbfaahfhjgdnb
            chrome.runtime.sendMessage('dafkkimnoemanmhikhkpbfaahfhjgdnb', { type: 'login', data: data }, function (response) {
                // console.log('plug result：', response);
            });
        }
        if (method === 'logout_method') {
            // local     jnkdopgikakdmmlankkhcpfmlmgnkbkp
            // product   dafkkimnoemanmhikhkpbfaahfhjgdnb
            chrome.runtime.sendMessage('dafkkimnoemanmhikhkpbfaahfhjgdnb', { type: 'logout', data: data }, function (response) {
                // console.log('plug result：', response);
            });
        }
    }
});
