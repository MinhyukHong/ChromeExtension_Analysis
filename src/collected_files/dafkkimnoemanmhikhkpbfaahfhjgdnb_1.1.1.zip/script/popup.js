(function (doc, win) {
    chrome.storage.local.get('iframe', function (result) {
        if (result && result?.iframe === 'open') {
            document.getElementById('switch').classList.add('open');
        } else {
            document.getElementById('switch').classList.remove('open');
        }
    });

    document.getElementById('switch').addEventListener('click', () => {
        const list = document.getElementById('switch').classList;
        let open = 'close';
        if (list.contains('open')) {
            document.getElementById('switch').classList.remove('open');
            open = 'close';
        } else {
            document.getElementById('switch').classList.add('open');
            open = 'open';
        }
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, { type: 'iframe', status: open });
        });
    });

    document.querySelector('.logo').addEventListener('click', () => {
        window.open('https://promptport.ai');
    });

    document.querySelector('.open_gpt').addEventListener('click', () => {
        window.open('https://chat.openai.com');
    });
})(document, window);
