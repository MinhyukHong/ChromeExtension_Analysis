let funFactOverlay;
let currentFunFact;
let adPlaying = false;
let factInterval;

function isVideoPlaying() {
  const video = document.querySelector("video");
  return video && !video.paused && video.currentTime > 0;
}

function createFunFactOverlay() {
  funFactOverlay = document.createElement("div");
  funFactOverlay.style.position = "fixed";
  funFactOverlay.style.top = "10%";
  funFactOverlay.style.left = "50%";
  funFactOverlay.style.transform = "translateX(-50%)";
  funFactOverlay.style.width = "80%";
  funFactOverlay.style.padding = "20px";
  funFactOverlay.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
  funFactOverlay.style.color = "white";
  funFactOverlay.style.display = "none";
  funFactOverlay.style.alignItems = "center";
  funFactOverlay.style.justifyContent = "center";
  funFactOverlay.style.fontSize = "24px";
  funFactOverlay.style.textAlign = "center";
  funFactOverlay.style.zIndex = "9999";
  funFactOverlay.style.pointerEvents = "none";
  funFactOverlay.style.borderRadius = "10px";
  document.body.appendChild(funFactOverlay);
}

function showFunFact() {
  if (!funFactOverlay) {
    createFunFactOverlay();
  }
  updateFact();
  funFactOverlay.style.display = "flex";

  if (factInterval) {
    clearInterval(factInterval);
  }

  factInterval = setInterval(updateFact, 15000);
}

function updateFact() {
  currentFunFact = getFunFact();
  funFactOverlay.style.opacity = "0";
  setTimeout(() => {
    funFactOverlay.textContent = currentFunFact;
    funFactOverlay.style.opacity = "1";
  }, 500);
}

function hideFunFact() {
  if (funFactOverlay) {
    funFactOverlay.style.display = "none";
    if (factInterval) {
      clearInterval(factInterval);
      factInterval = null;
    }
  }
}

function getFunFact() {
  const funFacts = [
    "The scientific term for brain freeze is 'sphenopalatine ganglioneuralgia.'",
    "Canadians say 'sorry' so much that a law was passed in 2009 declaring that an apology can't be used as evidence of admission to guilt.",
    "Back when dinosaurs existed, there used to be volcanoes that were erupting on the moon.",
    "The only letters that don't appear on the periodic table are 'J' and 'Q.'",
    "One habit of intelligent humans is being easily annoyed by people around them but saying nothing in order to avoid a meaningless argument.",
    "If a Polar Bear and a Grizzly Bear mate, their offspring is called a 'Pizzy Bear.'",
    "In 2006, a Coca-Cola employee offered to sell Coca-Cola secrets to Pepsi. Pepsi responded by notifying Coca-Cola.",
    "The ten highest mountain summits in the United States are all located in Alaska.",
    "Nintendo trademarked the phrase 'It's on like Donkey Kong' in 2010.",
    "The famous line in Titanic from Leonardo DiCaprio, 'I'm king of the world!' was improvised.",
    "A single strand of Spaghetti is called a 'Spaghetto.'",
    "Hershey's Kisses are named after the kissing sound the deposited chocolate makes as it falls from the machine on the conveyor belt.",
    "Princess Peach didn't move until 1988 because it was too complicated for the designers to make her a moveable character.",
    "In English, leaving a party without telling anyone is called a 'French Exit.' In French, it's called a 'partir à l'anglaise,' to leave like the English.",
    "If you cut down a saguaro cactus in Arizona, you can be charged with a class-4 felony and penalized with jail time.",
    "The Buddha commonly depicted in statues and pictures is a different person entirely. The real Buddha was actually incredibly skinny because of self-deprivation.",
    "In Colorado, USA, there is still an active volcano. It last erupted about the same time as the pyramids were being built in Egypt.",
    "The first movie ever to put out a motion-picture soundtrack was Snow White and the Seven Dwarfs.",
    "Fruit stickers are edible, though the same as any fruit; washing prior to eating is recommended. The glue used for them is regulated by the FDA.",
    "The scientific name for the Giant Anteater is Myrmecophaga Tridactyla. This means 'ant eating with three fingers.'",
    "Astronaut is a compound word derived from the two Ancient Greek words 'Astro,' meaning 'star,' and 'naut' meaning 'sailor.' So astronaut literally means 'star sailor.'",
    "The flashes of colored light you see when you rub your eyes are called 'phosphenes.'",
    "At birth, a baby panda is smaller than a mouse.",
    "Iceland does not have a railway system.",
    "The largest known prime number has 24,862,048 digits. The new prime number is 2 multiplied by itself 82,589,933 times, minus 1.",
    "Forrest Fenn, an art dealer and author, hid a treasure chest in the Rocky Mountains worth over 1 million dollars. It was found approximately a decade later, in 2020.",
    "The lead singer of The Offspring started attending school to achieve a doctorate in molecular biology while still in the band. He graduated in May 2017.",
    "The tongue is the only muscle in one's body that is attached from one end.",
    "There is a company in Japan that has schools that teach you how to be funny. The first one opened in 1982. About 1,000 students take the course each year.",
    "The Lego Group is the world's most powerful brand. There are more Lego Minifigures than there are people on Earth.",
    "The Bagheera kiplingi spider was discovered in the 1800s and is the only species of spider that has been classified as vegetarian.",
    "There is a boss in Metal Gear Solid 3 that can be defeated by not playing the game for a week or by changing the date.",
    "The Roman-Persian wars are the longest in history, lasting over 680 years. They began in 54 BC and ended in 628 AD.",
    "Elvis was originally blonde. He started coloring his hair black for an edgier look. Sometimes, he would touch it up himself using shoe polish.",
    "If you translate 'Jesus' from Hebrew to English, the correct translation is 'Joshua.' The name 'Jesus' comes from translating the name from Hebrew to Greek to Latin to English.",
    "Ed Sheeran bought a ticket to LA with no contacts. He was spotted by Jamie Foxx, who offered him the use of his recording studio and a bed in his Hollywood home for six weeks.",
    "The first service animals were established in Germany during World War I, but references to service animals date back to the mid-16th Century.",
    "An 11-year-old girl proposed the name of Pluto after the Roman god of the Underworld.",
    "The voice actors of SpongeBob and Karen, Plankton's computer wife, have been married since 1995.",
    "An Italian banker, Gilberto Baschiera, is considered a modern-day Robin Hood. Over the course of 7 years, he secretly diverted 1 million euros to poorer clients from the wealthy ones so they could qualify for loans. He made no profit and avoided jail in 2018 due to a plea bargain.",
    "Octopuses and squids have beaks. The beak is made of keratin – the same material that a bird's beak and our fingernails are made of.",
    "An estimated 50% of all gold ever mined on Earth came from a single plateau in South Africa: Witwatersrand.",
    "75% of the world's diet is produced from just 12 plants and five different animal species.",
    "The original Star Wars premiered on just 32 screens across the U.S. in 1977. This was to produce buzz as the release widened to more theaters.",
    "The British government coined the slogan 'Keep Calm and Carry on' during World War 2 to motivate citizens to stay strong. Posters with the slogan were printed but never officially issued and were only unearthed in 2000.",
    "Tirana, the capital of Albania, has a lot of things in common with other European capitals – except one. It's one of the few capitals without a Mcdonald's, along with Vatican City and Reykjavik, Iceland, and Podgorica, Montenegro.",
    "Sour Patch Kids are from the same manufacturer as Swedish Fish. The red Sour Patch Kids are the same candy as Swedish Fish but with sour sugar.",
    "The largest Japanese population outside of Japan stands at 1.6 million people who live in Brazil.",
    "IKEA is an acronym that stands for Ingvar Kamprad Elmtaryd Agunnaryd, which is the founder's name, the farm where he grew up, and his hometown.",
    "In 2009, Stephen Hawking held a reception for time travelers but didn't publicize it until after. This way, only those who could time travel would be able to attend. Nobody else attended.",
    "Violin bows are commonly made from horse hair.",
    "There are less than 30 ships in the Royal Canadian Navy which are less than most third-world countries.",
    "Larry the Cable Guy's real name is Daniel Lawrence Whitney. His notable Southern accent is fake – he was born and raised in the midwest, not the South.",
    "The youngest Pope in history was Pope Benedict IX, who was either 11 or 20 years old when he was elected in 1032. He is also the only person to have been the Pope more than once.",
    "Costa Coffee employs Gennaro Pelliccia as a coffee taster, who has had his tongue insured for £10 million since 2009.",
    "Johnny Cash took only three voice lessons before his teacher advised him to stop taking lessons and to never deviate from his natural voice.",
    "There is an island called 'Just Enough Room,' where there's just enough room for a tree and a house.",
    "People who post their fitness routine on Facebook are more likely to have psychological problems.",
    "Medieval chastity belts are a myth. A great majority of examples now existing were made in the 18th and 19th centuries as jokes.",
    "Nowadays, millionaires with just $1 million aren't considered wealthy anymore by most Americans. Now, the typical American sees at least $2.4 million as wealthy.",
    "Hanna-Barbera pitched The Flintstones to networks for 8 weeks before it was finally picked up. It became the first-ever animated show to air during primetime.",
    "There is a company that sells mirrors that make people look 10 pounds thinner. Overall, the mirrors have contributed to 54% of total sales for retailers that use them.",
    "There's no period in 'Dr. Pepper.' It was removed because the old logo font made it look like 'Di: Pepper.'",
    "Standing around burns calories. On average, a 150-pound person burns 114 calories per hour while standing and doing nothing.",
    "Although GPS is free for the world to use, it costs $2 million per day to operate. The money comes from American tax revenue.",
    "In World War II, Germany tried to collapse the British economy by dropping millions of counterfeit bills over London.",
    "The human eye is so sensitive that if the Earth were flat and it was a dark night, a candle's flame could be seen from 30 miles away.",
    "When Space Invaders was created, Tomohiro Nishikado left in the lag caused by more invaders on the screen in order to create greater difficulty in the games.",
    "The color red doesn't really make bulls angry; they are color-blind.",
    "28% of people on the autism spectrum are left-handed, and only 10% of people, in general, are left-handed.",
    "In 2007, Scotland spent £125,000 devising a new national slogan. The winning entry was: 'Welcome to Scotland.'",
    "Until 2016, the 'Happy Birthday' song was not for public use. Meaning that prior to 2016, the song was copyrighted, and you had to pay a license to use it.",
    "There is a punctuation mark used to signify irony or sarcasm that looks like a backward question mark ⸮",
    "Lettuce is a member of the sunflower family.",
    "Researchers have found that flossing your teeth can help your memory. Flossing prevents gum disease, which prevents stiff blood vessels, which cause memory issues.",
    "A cluster of bananas is called a 'hand.' Along that theme, a single banana is called a 'finger.'",
    "The Hobbit has been published in two editions. In the first edition, Gollum willingly bet on his ring in the riddle game.",
    "For nearly 60 years, Texas didn't have an official state flag between 1879 & 1933. During that time, the Lone Star flag was active, but the unofficial flag.",
    "A wildlife technician, Richard Thomas, took the famous tongue-twister 'How much wood would a woodchuck chuck if a woodchuck could chuck wood' and calculated a rough estimate of what the answer would actually be. It came out to be around 700 pounds.",
    "Red Solo cups are a common souvenir to bring back from the United States. The novelty comes from the cups being used in many party scenes in movies.",
    "Swedish meatballs originated from a recipe King Charles XII brought back from Turkey in the early 1800s.",
    "Those cute furry bits inside a cat's ear are called 'ear furnishings.' They ensure that dirt doesn't go inside and also helps them to hear well.",
    "Scientists discovered sharks living in an active underwater volcano. Divers cannot investigate because they would get burns from the acidity and heat.",
    "There are times when Pluto is closer to the Sun than Neptune – one of these timelines was from 1979 to 1999.",
    "There is a town in Nebraska called Monowi with a population of one. The only resident is a woman who is the Mayor, Bartender, and Librarian.",
    "The Ethiopian calendar is 7.5 years behind the Gregorian calendar due to the fact that it has 13 months.",
    "In 1994, the company that had a patent on GIFs tried to charge a fee for using GIFS. The PNG was invented as an alternative, and the company backed down.",
    "China is spending $3 billion dollars to build panda-shaped solar farms in order to get more young people interested in renewable energy.",
    "Mercury and Venus are the only two planets in our solar system that do not have any moons.",
    "The average American child is given $3.70 per tooth that falls out.",
    "To properly write adjectives in order, you would list them by amount, value, size, temperature, age, shape, color, origin, and material.",
  ];
  return funFacts[Math.floor(Math.random() * funFacts.length)];
}

function checkForAd() {
  if (!isVideoPlaying()) return;
  const player = document.getElementById("movie_player");
  if (!player) return;
  const adOverlay = player.querySelector(".ytp-ad-player-overlay");
  const hasAdShowingClass = player.classList.contains("ad-showing");
  const skipAdContainer = player.querySelector(".videoAdUiPreSkipContainer");
  const adText = player.querySelector(".ytp-ad-text");

  if (
    (adOverlay || hasAdShowingClass || skipAdContainer || adText) &&
    !adPlaying
  ) {
    console.log("Ad detected");
    adPlaying = true;
    chrome.runtime.sendMessage({ action: "adDetected" });
    showFunFact();
  } else if (
    !(adOverlay || hasAdShowingClass || skipAdContainer || adText) &&
    adPlaying
  ) {
    console.log("Ad ended");
    adPlaying = false;
    chrome.runtime.sendMessage({ action: "adEnded" });
    hideFunFact();
  }
}

const observer = new MutationObserver(() => {
  if (isVideoPlaying()) {
    checkForAd();
  }
});

const config = { childList: true, subtree: true };
observer.observe(document.body, config);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "showFunFact") {
    showFunFact();
  } else if (message.action === "hideFunFact") {
    hideFunFact();
  }
});

// Initial check
checkForAd();
