let youtubeTabId = null;
let isAdPlaying = false;

function findYoutubeTab() {
  chrome.tabs.query({ url: "*://*.youtube.com/*" }, (tabs) => {
    if (tabs.length > 0) {
      youtubeTabId = tabs[0].id;
      console.log("YouTube tab found:", youtubeTabId);
    } else {
      console.log("YouTube tab not found");
      youtubeTabId = null;
    }
  });
}

findYoutubeTab();

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.url && tab.url.includes("youtube.com")) {
    youtubeTabId = tabId;
    console.log("YouTube tab updated:", youtubeTabId);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "adDetected" && !isAdPlaying) {
    console.log("Ad detected in tab:", sender.tab.id);
    isAdPlaying = true;
    if (youtubeTabId) {
      chrome.tabs.update(youtubeTabId, { muted: true });
      chrome.tabs.sendMessage(youtubeTabId, { action: "showFunFact" });
    }
  } else if (message.action === "adEnded" && isAdPlaying) {
    console.log("Ad ended in tab:", sender.tab.id);
    isAdPlaying = false;
    if (youtubeTabId) {
      chrome.tabs.update(youtubeTabId, { muted: false });
      chrome.tabs.sendMessage(youtubeTabId, { action: "hideFunFact" });
    }
  }
});
