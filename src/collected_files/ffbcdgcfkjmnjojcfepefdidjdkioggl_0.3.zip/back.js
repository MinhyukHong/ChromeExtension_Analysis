var perstore = new Array;
var heading = new Array;//heading
var headingperm = new Array;//perment storage for heading
var res;
var goo = new Array;
var cpygoo;
var indomap = new Array;
var idofname
var notcpygoo = new Array;
var Avilable;
  var refresh;
  localStorage["Avilable"] = 30000;
  localStorage["refresh"] = 3000;
var b=0;
 // continus run
function doSomething() {

            window.setTimeout(doSomething, refresh);
       //code to be run
       getinggoo();
    }
    doSomething();
function getinggoo(){
Avilable = localStorage["Avilable"];
refresh = localStorage["refresh"];

 /* if(Avilable == ""){Avilable = 30000};
  if(refresh == "") 
  {
  refresh = 3000;
  }*/
  
b=0
var xdoc = new XMLHttpRequest();
xdoc.open("GET","http://www.bseindia.com/corporates/ann.aspx?expandable=0");
function proc()
{
res = xdoc.responseText;
goo=res.match(/4'>.+?<\/t/g); 
heading=res.match(/<tr><td class='TTHeadergrey' style='font-weight:bold;' valign='middle'>.+?<\/td|<a class='tablebluelink' href.+?<\/a>/g);
compare(heading,headingperm);
notcompare(goo,perstore);
headingperm = heading;
perstore = goo;
}
xdoc.onload = proc;
xdoc.send();
}
 function compare(now,before)
{
	newupdata = $(now).not(before).get(); //$(notnow).not(notbefore).get()
	if(newupdata.length>0&&newupdata.length<10){  
	  Avilable = localStorage["Avilable"];
	  remov(newupdata)
		 }
	 else{
	 console.log("no new update");
	 }
	 };
	 function remov(unwanted)
	 {
	 cpygoo = new Array
	 var uncopy = new Array
	 uncopy = unwanted
	 for(i in uncopy)
{
 uncopy[i]=uncopy[i].replace(/4'>|<\/t|<.+?>|&nbsp;/g,"")
  if(uncopy[i].length>20)
 {
 cpygoo[b] = uncopy[i]
 b++
 }
}
	 indomap = cpygoo.toString().match(/[0-9][0-9][0-9][0-9][0-9][0-9]/g)
	 dofname(cpygoo)
	 }  
var inshowa,inshowe,inshowi=new Array
function show(gaa,gee,gii) {
     inshowa = gaa ;
   inshowe = gee;
   inshowi=gii;
   for(i in inshowa){
  inshow(inshowa[i],inshowe[i],inshowi[i]);
  }
  function inshow(a,b,c){
   var aa,bb,cc;  
   aa = a
   bb = b
   cc = c
  notification = window.webkitNotifications.createNotification(
 	   '48.png',
	   aa,                 
       cc                                 
          );
  notification.addEventListener('click', function() {
  var value,num;
var xdoc = new XMLHttpRequest()
xdoc.open("GET","https://finance.google.com/finance/info?client=ig&q=BOM:"+bb);
 chrome.tabs.create({ url: "https://www.google.com/finance?q=BOM%3A"+bb })
function proc()
{
var rupes
rupes = JSON.stringify(xdoc.responseText).match(/Rs.[0-9]*.[0-9]*|Rs.[0-9]*,[0-9]*.[0-9]*/g); 
value = rupes.toString().replace(/Rs.|,/g,"");
console.log(value);
value = Number(value);
num = Avilable/value;
num = Math.round(num);
var add_per = value+value*1/100;
var exnum = Avilable/add_per;
exnum = Math.round(exnum);
var textt = (aa+"| cv:Rs."+value+"\n avilable Rs: "+Avilable+"-get: "+num+" shres").toString();
var body2 = ("cv+1%: "+ add_per +"\navilable Rs: "+Avilable+"-get: "+exnum+ " shares").toString();
notificat = window.webkitNotifications.createNotification(
       '48.png',
	   textt,
	   body2               
   
		   );                                       
  notificat.show()                                  	
}
xdoc.onload = proc;
xdoc.send();
});
  notification.show();
  }
  }
 function dofname(jous)
{
 idofname = new Array
 idofname = jous
for(i in idofname)
{
idofname[i] = idofname[i].replace(/-.+/g,"")
}
}
   function notcompare(notnow,notbefore)
{

	notnewupdata = $(notnow).not(notbefore).get();
	if(notnewupdata.length>0&&notnewupdata.length<10){  
	   notremov(notnewupdata);
	 }
	 else{
	 console.log(" notice no new update");
	 }
	 };
	  function notremov(notunwanted)
	 {
	 var bb = 0
	 var notuncopy = new Array()
	 notcpygoo = new Array()
	 notuncopy = notunwanted
 for(i in notuncopy)
{
 notuncopy[i]=notuncopy[i].replace(/4'>|<\/t|<.+?>|&nbsp;/g,"")
  }
  for(i in notuncopy)
 {
 if(notuncopy[i].length>20)
 {
 notcpygoo.push(notuncopy[i])
 bb++
 }
 }
 show(idofname,indomap,notcpygoo)
 }
