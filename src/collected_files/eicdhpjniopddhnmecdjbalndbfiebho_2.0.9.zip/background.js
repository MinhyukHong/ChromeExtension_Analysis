// importScripts("./js/jquery.js");

chrome.runtime.onInstalled.addListener(() => {
  console.log("Chrome extension successfully installed!");
  // console.log({ chromeStorage: chrome.storage });
  return;
});

//region -- LocalStorage --
var LocalStorage = {
  set: function (key, value) {
    chrome.storage.local.set(key, JSON.stringify(value));
  },
  get: function (key) {
    var saved = chrome.storage.local.get(key);
    // saved = JSON.parse(saved);
    return saved;
  },
  remove: function (key) {
    if (key) {
      chrome.storage.local.remove(key);
    }
  },
};
//endregion

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  switch (request.action) {
    case "afterGetNewExchangeRate":
      afterGetNewExchangeRate(request, sender, sendResponse);
    case "getExchangeRate":
    case "addToCart":
    case "addToFavorite":
    case "getCategory":
    case "translate":
      getUrls(request, sender, sendResponse);
      break;
    case "addToCartNHSG":
      getUrlsNHSG(request, sender, sendResponse);
      break;
    case "setTranslateValue":
      setTranslateValue(request, sender, sendResponse);
      break;
    case "getTranslateValue":
      getTranslateValue(request, sender, sendResponse);
      break;
    case "reloadExchangeRate":
      reloadExchangeRate(request, sender, sendResponse);
      break;
    default:
      //todo
      break;
  }
});

function afterGetNewExchangeRate(request, sender, sendResponse) {
  fetch("https://nhaphangb2b.com/api/menu/config?id=1", {
    method: "GET",
    headers: {
      accept: "text/plain",
      "Content-Type": "application/json-patch+json",
    },
  })
    .then((response) => response.text())
    .then((result) => {
      chrome.tabs.sendMessage(
        sender.tab.id,
        {
          action: request.callback,
          response: { msg: "success", data: JSON.parse(result).Data },
        },
        function () {}
      );
    })
    .catch((error) => {
      chrome.tabs.sendMessage(
        sender.tab.id,
        { action: request.callback, response: { msg: "err-not-define" } },
        function () {}
      );
    });
}

function setTranslateValue(request, sender, sendResponse) {
  var value = request.value;
  LocalStorage.set("translate", value);

  chrome.tabs.sendMessage(
    sender.tab.id,
    { action: request.callback },
    function (response) {}
  );
}

function getTranslateValue(request, sender, sendResponse) {
  var value =
    LocalStorage.get("translate") == undefined
      ? 0
      : LocalStorage.get("translate");

  // value.then((item) => {
  //   console.log({ value: item });
  // });

  // console.log("get translateValue", value);
  chrome.tabs.sendMessage(
    sender.tab.id,
    { action: request.callback, value: value },
    function (response) {}
  );
  // LocalStorage.get("translate").then((data)=>{

  // })
}

function getUrls(request, sender, sendResponse) {
  fetch(request.url, {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  })
    .then((data) => {
      return data.json();
    })
    .then((data) => {
      chrome.tabs.sendMessage(sender.tab.id, {
        action: request.callback,
        response: data,
      });
    })
    .catch((err) => {
      chrome.tabs.sendMessage(
        sender.tab.id,
        { action: request.callback },
        function () {}
      );
    });
}

function reloadExchangeRate(request, sender, sendResponse) {
  fetch("https://nhaphangb2b.com/api/menu/config?id=1", {
    method: "GET",
    headers: {
      accept: "text/plain",
      "Content-Type": "application/json-patch+json",
    },
  })
    .then((response) => response.text())
    .then((result) => {
      chrome.tabs.sendMessage(
        sender.tab.id,
        {
          action: request.callback,
          response: { msg: "success", data: JSON.parse(result).Data },
        },
        function () {}
      );
    })
    .catch((error) => {
      chrome.tabs.sendMessage(
        sender.tab.id,
        { action: request.callback, response: { msg: "err-not-define" } },
        function () {}
      );
    });
}

function getUrlsNHSG(request, sender, sendResponse) {
  chrome.cookies.get(
    { url: "https://nhaphangb2b.com/", name: "tokenNHTQ-nhaphangb2b" },
    function (cookie) {
      if (!cookie) {
        console.log("Chưa đăng nhập!", cookie);
        var login = "login|login";
        chrome.tabs.sendMessage(
          sender.tab.id,
          { action: request.callback, response: login },
          function () {}
        );
        return;
      }

      chrome.storage.local.get(["miniumQuantity"]).then((result) => {
        const mini = result ? result.miniumQuantity : 1;
        const send_data = { ...request.data, minimumQuantity: mini };

        if (!send_data.property || !send_data.property_translated) {
          chrome.tabs.sendMessage(
            sender.tab.id,
            { action: request.callback, response: "property|property" },
            function () {}
          );
          return;
        }

        var tk = "Bearer " + cookie.value;
        fetch("https://nhaphangb2b.com/api/order-shop-temp", {
          //body: request.data == undefined ? "{}" : formData,
          method: request.method == undefined ? "GET" : request.method,
          headers: {
            accept: "text/plain",
            "Content-Type": "application/json-patch+json",
            Authorization: tk,
          },
          body: JSON.stringify(send_data),
        })
          .then((data1) => {
            console.log("==== success 1");
            console.log("data_send: ", JSON.stringify(send_data));
            console.log("data1: ", data1);
            return data1.text();
          })
          .then((data2) => {
            console.log("==== success 2");
            var checklogin1 = strip_tag(data2);
            var pricemuspay =
              parseFloat(
                request.data.price_promotion == 0
                  ? request.data.price_origin
                  : request.data.price_promotion
              ) * parseFloat(request.data.quantity);
            var checklogin = checklogin1 + "|" + pricemuspay;
            var trackerTimes = {
              times: request.times || 0,
              maxTimes: request.data.maxTimes || 0,
            };
            console.log(checklogin, trackerTimes);
            chrome.tabs.sendMessage(
              sender.tab.id,
              {
                action: request.callback,
                response: checklogin,
                ...trackerTimes,
              },
              function (response) {}
            );
          })
          .catch((error) => {
            console.log("error: ", error);
            var loi = "loi|loi";
            chrome.tabs.sendMessage(
              sender.tab.id,
              { action: request.callback, response: loi },
              function () {}
            );
          });
      });
    }
  );
}

function strip_tag(str) {
  var regex = /(&nbsp;|<([^>]+)>)/gi,
    body = str,
    result = body.replace(regex, "");
  return result;
}

var Common = {
  request: function (params) {
    return $.ajax({
      url: params.url,
      type: params.type == undefined ? "GET" : params.type,
      data: params.data == undefined ? {} : params.data,
    });
  },

  getIconWebservice: function (service) {
    var iconUrl = "images/add_on/addon-icon-nhst.png";
    return iconUrl;
  },

  getCurrentDateTime: function () {
    var now = new Date();
    var year = now.getFullYear();
    var month = now.getMonth() + 1;
    var day = now.getDate();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    if (month.toString().length == 1) {
      month = "0" + month;
    }
    if (day.toString().length == 1) {
      day = "0" + day;
    }
    if (hour.toString().length == 1) {
      hour = "0" + hour;
    }
    if (minute.toString().length == 1) {
      minute = "0" + minute;
    }
    if (second.toString().length == 1) {
      second = "0" + second;
    }
    var dateTime =
      year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
    return dateTime;
  },

  convertingHTMLToPlainText: function (string) {
    var s = "";
    if (string) {
      string = string.replace(/<br>/gi, "\n");
      string = string.replace(/<p.*>/gi, "\n");
      string = string.replace(
        /<a.*href="(.*?)".*>(.*?)<\/a>/gi,
        " $2 (Link->$1) "
      );
      string = string.replace(/<(?:.|\s)*?>/g, "");
      s = string;
    }
    return s;
  },
};
