try {
	if (window.location.href.match(/1688.com|alibaba/))
		if (iDetailData?.sku) {
			setInterval(function () {
				/* Example: Send data from the page to your Chrome extension */
				document.dispatchEvent(
					new CustomEvent('Send_data_to_extension', {
						detail: {
							skuMap: iDetailData.sku.skuMap,
							sku: iDetailData.sku,
						},
					})
				);
			}, 100);
		} else {
		}
	else {
	}
} catch (ex) {
	console.log('error from getGlobalData');
	// alert(`error from getGlobalData ${ex.message}`);
	// alert('khong idetail');
	// trường hợp trang 1688 không lấy đc  iDetailData
	// 'trường hợp trang 1688 không lấy đc  iDetailData');
	setInterval(function () {
		/* Example: Send data from the page to your Chrome extension */
		try {
			let sku = {};
			sku.canBookCount = Object.values(__INIT_DATA.globalData.skuModel.skuInfoMap).reduce((s, x) => s + x.canBookCount, 0);
			sku.skuPriceType = __INIT_DATA.globalData.orderParamModel.orderParam.skuParam.skuPriceType;
			sku.priceRange = __INIT_DATA.globalData.orderParamModel.orderParam.skuParam.skuRangePrices?.map((x) => [
				Number(x.beginAmount) || 0,
				Number(x.price) || 0,
			]);
			sku.sellerId =
				__INIT_DATA.globalData?.tempModel?.sellerUserId ||
				__GLOBAL_DATA.offerBaseInfo?.sellerUserId ||
				JSON.parse(__GLOBAL_DATA.offerDomain)?.sellerModel?.userId;
			sku.companyName =
				__INIT_DATA.globalData?.tempModel?.companyName || JSON.parse(__GLOBAL_DATA.offerDomain)?.sellerModel?.companyName;
			sku.price = __INIT_DATA.globalData.skuModel.skuPriceScale;
			sku.image = __INIT_DATA.globalData.images?.[0].fullPathImageURI;
			sku.skuProps = __INIT_DATA.globalData.skuModel.skuProps;
			const cloneskuMap = JSON.parse(JSON.stringify(__INIT_DATA.globalData.skuModel.skuInfoMap));
			Object.values(cloneskuMap).forEach((x) => {
				x.price = __INIT_DATA.globalData.skuModel.skuPriceScale;
			});
			sku.skuMap = cloneskuMap;
			document.dispatchEvent(
				new CustomEvent('Send_data_to_extension', {
					detail: {
						skuMap: sku.skuMap,
						sku: sku,
					},
				})
			);
		} catch (ex) {
			document.dispatchEvent(
				new CustomEvent('Send_data_to_extension', {
					detail: {
						msg: 'loi',
					},
				})
			);
		}
	}, 100);
}
