var service_host,
  add_to_cart_url,
  cart_url,
  catalog_scalar_url,
  isTranslate,
  link_detail_cart,
  add_to_favorite_url,
  button_add_to_cart_url;

var site_using_https = false;

chrome.storage.sync.get(
  {
    domain: "https://nhaphangb2b.com/",
    is_translate: true,
  },
  function (items) {
    console.log({ items });
    var value = items.domain;
    chrome.storage.sync.set(
      {
        domain: value,
      },
      function () {}
    );

    service_host = value;

    //============================================================

    isTranslate = items.is_translate;
    //add_to_cart_url = service_host+'cart/add_cart_v2';
    add_to_cart_url = service_host + "ReceiveRequest.aspx";
    cart_url = service_host + "checkout.html";
    link_detail_cart = service_host + "gio-hang";
    add_to_favorite_url = service_host + "i/favoriteLink/saveLink";
    button_add_to_cart_url =
      service_host + "assets/images/add_on/icon-bkv1-small.png";

    var css_url = "";
    switch (items.domain) {
      default:
        css_url = "css/main.css";
        catalog_scalar_url = "https://nhaphangb2b.com/api/catalog/scalar";
        break;
    }

    if (css_url) {
      var NewStyles = document.createElement("link");
      NewStyles.rel = "stylesheet";
      NewStyles.type = "text/css";
      NewStyles.href = chrome.runtime.getURL(css_url);
      document.head.appendChild(NewStyles);
    }
  }
);

var translate_url = "https://nhaphangb2b.com/i/goodies_util/translate";
var isUsingSetting = false;
var translate_keyword_url = "";
var version_tool = "1.7";
var exchange_rate;
var nhst_exchange_rate = "0";
var link_store_review_guidelines = "https://nhaphangb2b.com/";
var web_service_url = "https://nhaphangb2b.com/";
var exchange_rate_url = "https://nhaphangb2b.com/";
