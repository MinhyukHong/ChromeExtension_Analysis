var version_tool = "1.7";
var last_updated_time = "2018-09-04 12:00:00";