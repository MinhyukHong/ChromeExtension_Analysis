chrome.runtime.onInstalled.addListener(() => {

  chrome.storage.sync.get(null).then((result) => {
    const options = result.options || {
      'tabs': true,
      'urls': false,
      'new-tab': true,
    };

    chrome.storage.sync.set({ options }).then(() => chrome.tabs.create({ url: chrome.runtime.getURL('sessionBookmarks.html') }));
  });
});

chrome.tabs.onCreated.addListener((tab) => {
  chrome.storage.sync.get(['options']).then((result) => {
    if (result.options['new-tab'] && tab.pendingUrl === 'chrome://newtab/') {
      chrome.tabs.update(tab.id, { url: chrome.runtime.getURL('sessionBookmarks.html') });
    }
  });
});