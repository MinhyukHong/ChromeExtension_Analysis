'use strict';

const bookmarks = document.getElementById('bookmarks');

const showMessage = (message) => {
  const messages = document.getElementById('messages');
  const messageParagraph = document.createElement('p');
  messageParagraph.innerText = message;
  messages.appendChild(messageParagraph);

  setTimeout(() => {
    messages.removeChild(messageParagraph);
  }, 3000);
}

const ACTIONS = {
  openInNewWindow: (urls) => {
    chrome.windows.create({ url: urls });
  },

  openInIncognito: (urls) => {
    chrome.windows.create({ url: urls, incognito: true });
  },

  openInCurrentWindow: (urls) => {
    urls.forEach((url) => {
      chrome.tabs.create({ url });
    })
  },

  showUrls: (key) => document.getElementById(key).classList.toggle('bookmark--urls'),

  showRenameForm: (key) => {
    const form = document.getElementById(`rename-${key}`);

    form.style.display = 'inline-block';
    form.nextElementSibling.style.display = 'none';
    form.querySelector('input').focus();
  },

  hideRenameForm: (key) => {
    const form = document.getElementById(`rename-${key}`);

    form.style.display = 'none';
    form.nextElementSibling.style.display = 'inline-block';
    form.querySelector('input').blur();
  },

  rename: (key) => chrome.storage.sync.get(null).then((result) => {
    const data = result;
    const form = document.getElementById(`rename-${key}`);

    data[key].name = form.querySelector('input').value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');

    chrome.storage.sync.set(data).then(() => {
      form.style.display = 'none';
      form.nextElementSibling.style.display = 'inline-block';

      chrome.tabs.reload();
    });
  }),

  delete: (key) => chrome.storage.sync.remove(key).then(() => {
    const error = chrome.runtime.lastError;

    if (error) {
      console.error(error);
      return;
    }

    chrome.tabs.reload();
  }),

  remove: (key, index) => chrome.storage.sync.get(null).then((result) => {
    const data = result;

    data[key].urls.splice(index, 1);

    chrome.storage.sync.set(data).then(() => {
      chrome.tabs.reload();
    });
  }),

  copy: (key, index) => chrome.storage.sync.get(null).then((result) => {
    navigator.clipboard.writeText(result[key].urls[index].url).then(() => {
      showMessage('Copied to clipboard');
    });
  }),
}

chrome.storage.sync.get(null).then((items) => {
  const {options} = items;
  if (Object.keys(items).length === 0 || Object.keys(items).length === 1 && items.options) {
    
    bookmarks.innerHTML += `
      <div class="bookmark__empty">
        <h1>You don't have any sessions bookmarked yet.</h1>
        <p>Start by clicking on the Session Bookmark extension icon.</p>
      </div>
    `
  }

  Object.keys(items).reverse().forEach((key) => {

    if (key === 'options') {
      return;
    }

    const renderLinks = () => {
      let links = '';

      items[key].urls.forEach((item, index) => {
        links += `
          <div class="bookmark__item">
            <div class="bookmark__item-actions">
              <button type="button" class="js-url" data-key="${key}" data-index="${index}" data-action="copy">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                <span class="hidden">Copy to clipboard</span>
              </button>
              <button type="button" class="js-url" data-key="${key}" data-index="${index}" data-action="remove">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
                <span class="hidden">Remove link</span>
              </button>
            </div>
            <img src="${item.favicon}" alt=""/>
            <span>
              <a href="${item.url}" class="bookmark__item-title">${item.title}</a>
              <a href="${item.url}" class="bookmark__item-link">${item.url}</a>
            </span>
          </div>`;
      });

      return links;
    }
    
    bookmarks.innerHTML += `
      <div class="bookmark${options.urls ? ' bookmark--urls' : ''}" id="${key}">
        <div class="bookmark__header">
          <div>
            <div class="dropdown">
              <button type="button" class="dropdown__trigger js-dropdown">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 3.75V3.7575V3.75ZM9 9V9.0075V9ZM9 14.25V14.2575V14.25ZM9 4.5C8.80109 4.5 8.61032 4.42098 8.46967 4.28033C8.32902 4.13968 8.25 3.94891 8.25 3.75C8.25 3.55109 8.32902 3.36032 8.46967 3.21967C8.61032 3.07902 8.80109 3 9 3C9.19891 3 9.38968 3.07902 9.53033 3.21967C9.67098 3.36032 9.75 3.55109 9.75 3.75C9.75 3.94891 9.67098 4.13968 9.53033 4.28033C9.38968 4.42098 9.19891 4.5 9 4.5ZM9 9.75C8.80109 9.75 8.61032 9.67098 8.46967 9.53033C8.32902 9.38968 8.25 9.19891 8.25 9C8.25 8.80109 8.32902 8.61032 8.46967 8.46967C8.61032 8.32902 8.80109 8.25 9 8.25C9.19891 8.25 9.38968 8.32902 9.53033 8.46967C9.67098 8.61032 9.75 8.80109 9.75 9C9.75 9.19891 9.67098 9.38968 9.53033 9.53033C9.38968 9.67098 9.19891 9.75 9 9.75ZM9 15C8.80109 15 8.61032 14.921 8.46967 14.7803C8.32902 14.6397 8.25 14.4489 8.25 14.25C8.25 14.0511 8.32902 13.8603 8.46967 13.7197C8.61032 13.579 8.80109 13.5 9 13.5C9.19891 13.5 9.38968 13.579 9.53033 13.7197C9.67098 13.8603 9.75 14.0511 9.75 14.25C9.75 14.4489 9.67098 14.6397 9.53033 14.7803C9.38968 14.921 9.19891 15 9 15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <span class="hidden">Options</span>
              </button>
              <div class="dropdown__options">
                <ul>
                  <li><button class="dropdown__button js-open" data-action="openInNewWindow">Open in new window</button></li>
                  <li><button class="dropdown__button js-open" data-action="openInIncognito">Open in incognito</button></li>
                  <li><button class="dropdown__button js-open" data-action="openInCurrentWindow">Open in current window</button></li>
                </ul>
                <ul>
                  <li><button class="dropdown__button dropdown__button--toggle js-change" data-key="${key}" data-action="showUrls">
                    <span>Show URLs</span><span>Hide URLs</span></button>
                  </li>
                </ul>
                <ul>
                  <li><button class="dropdown__button js-change" data-key="${key}" data-action="showRenameForm">Rename</button></li>
                  <li><button class="dropdown__button dropdown__button--delete js-change" data-key="${key}" data-action="delete">Delete</button></li>
                </ul>
              </div>
            </div>
            <div class="bookmark__title">
              <form class="bookmark__form" id="rename-${key}" style="display: none">
                <input type="text" value="${items[key].name !== '' ? items[key].name : ''}" />
                <div>
                  <button type="button" class="js-change" data-key="${key}" data-action="hideRenameForm">Cancel</button>
                  <button type="button" class="js-change" data-key="${key}" data-action="rename">Save</button>
                </div>
              </form>
              <span>${items[key].name !== '' ? items[key].name : '[No name]'}</span>
              <button type="button" class="bookmark__toggle ${options.tabs ? 'bookmark__toggle--show' : ''}" data-toggle="links-${key}">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M6 9L12 15L18 9" stroke="#a5a5a5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </button>
            </div>
          </div>
          <div class="bookmark__details">
            <span>${items[key].urls.length} Tabs</span> &middot; <span>${new Date(items[key].date).toLocaleString('en-US')}</span>
          </div>
        </div>
        <div class="bookmark__links" id="links-${key}" ${options.tabs ? '' : 'style="display: none;"'}>
          ${renderLinks()}
        </div>
      </div>
    `;

    bookmarks.querySelectorAll('.js-open').forEach((button) => {
      button.addEventListener('click', () => ACTIONS[button.dataset.action](items[key].urls.map(item => item.url)));
    });

    bookmarks.querySelectorAll('.js-change').forEach((button) => {
      button.addEventListener('click', () => ACTIONS[button.dataset.action](button.dataset.key));
    });

    bookmarks.querySelectorAll('.js-dropdown').forEach((button) => {
      button.addEventListener('click', () => button.nextElementSibling.classList.toggle('dropdown__options--show'));
    });

    bookmarks.querySelectorAll('.js-url').forEach((button) => {
      button.addEventListener('click', () => ACTIONS[button.dataset.action](button.dataset.key, button.dataset.index));
    });

    bookmarks.querySelectorAll('[data-toggle]').forEach((button) => {
      button.addEventListener('click', () => {
        const toggleElement = document.getElementById(button.dataset.toggle);

        if (toggleElement.style.display === 'none') {
          toggleElement.style.display = 'block';
          button.classList.add('bookmark__toggle--show');
        } else {
          toggleElement.style.display = 'none';
          button.classList.remove('bookmark__toggle--show');
        }
      })
    })

    document.addEventListener('click', (event) => {
      const dropdowns = document.querySelectorAll('.js-dropdown');

      dropdowns.forEach(dropdown => {
        if (!dropdown.contains(event.target)) {
          dropdown.nextElementSibling.classList.remove('dropdown__options--show');
        }
      });
    });
  })
});