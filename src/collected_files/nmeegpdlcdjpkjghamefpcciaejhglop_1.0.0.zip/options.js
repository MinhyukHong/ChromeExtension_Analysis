'use strict';

const showMessage = (message) => {
  const messages = document.getElementById('messages');
  const messageParagraph = document.createElement('p');
  messageParagraph.innerText = message;
  messages.appendChild(messageParagraph);

  setTimeout(() => {
    messages.removeChild(messageParagraph);
  }, 3000);
}

const clearSessionStorage = () => {
  chrome.storage.sync.get(null).then((result) => {
    const options = result.options;

    chrome.storage.sync.clear(() => {
      showMessage('Session storage has been cleared!');

      chrome.storage.sync.set({options}, () => {
        const error = chrome.runtime.lastError;

        if (error) {
          console.error(error);
        }
      })
    });
  });
}

const exportJSON = () => {
  const link = document.createElement('a');

  chrome.storage.sync.get(null).then((result) => {
    const fileToSave = new Blob([JSON.stringify(result, null, 2)], {
      type: 'application/json'
    });

    link.download = `session_bookmark-${Date.now()}.json`;
    link.href = window.URL.createObjectURL(fileToSave);
    link.click();
  });
}

const saveOptions = (e) => {
  chrome.storage.sync.get(null).then((result) => {
    const options = result.options || {};
    options[e.target.id] = e.target.checked;

    chrome.storage.sync.set({ options }).then(() => {
      showMessage('Option saved');
    });
  });
}

chrome.storage.sync.get(null).then((result) => {
  const {options} = result;

  if (!options) {
    return;
  }

  Object.keys(options).forEach((option) => document.getElementById(option).checked = options[option])
});

document.getElementById('clear').addEventListener('click', clearSessionStorage);
document.getElementById('export').addEventListener('click', exportJSON);
document.querySelectorAll('.switch').forEach((element) => element.addEventListener('change', (e) => saveOptions(e)));