'use strict';

function logSave() {
  const messageContainer = document.getElementById('messages');
  const name = document.getElementById('session-name');
  const id = Date.now() + Math.random().toString(36).slice(2);
  const session = {};
  const data = {
    name: '',
    urls: [],
    date: Date.now(),
  };

  data.name = name.value;

  chrome.tabs.query({currentWindow: true}).then((tabs) => {
    const extensionTabs = [];
    tabs.forEach(function (tab) {
      if (!tab.incognito) {
        data.urls.push({
          title: tab.title,
          url: tab.url,
          favicon: tab.favIconUrl
        });
      }

      if (tab.url === chrome.runtime.getURL('sessionBookmarks.html')) {
        extensionTabs.push(tab);
      }
    });
    
    session[id] = data;

    chrome.storage.sync.set(session).then(() => {
      const error = chrome.runtime.lastError;
      if (error) {
        console.error(error);
        messageContainer.innerHTML = `
          <div class="popup__message-container">
            <p class="popup__message popup__message--error">Error!</p>
          </div>
        `;
      } else {
        messageContainer.innerHTML = `
          <div class="popup__message-container">
            <p class="popup__message popup__message--success">Session saved!</p>
            <a href="sessionBookmarks.html" class="popup__sessions" target="_blank">Go to saved sessions</a>
          </div>`;

        extensionTabs.forEach((tab) => chrome.tabs.reload(tab.id));
      }
    });
  });
}

chrome.storage.sync.get(['options']).then((result) => {
  if (!result.options['new-tab']) {
    document.getElementById('popup').classList.add('popup--extension-page');
  }
});

document.getElementById('save-session').addEventListener('click', logSave);