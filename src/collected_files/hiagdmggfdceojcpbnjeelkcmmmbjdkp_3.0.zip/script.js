document.getElementById('searchForm').addEventListener('submit', function(event) {
    event.preventDefault();

    var searchWord = document.getElementById('searchWord').value;
    var notSearchWord = document.getElementById('notSearchWord').value.replace(/[\s　]/g, '+');
    var sites = [];
    var checkboxes = document.querySelectorAll('input[name="site"]:checked');
    checkboxes.forEach(function(checkbox) {
        sites.push(checkbox.value);
    });

    var siteFilter = sites.join('+OR+');
    var searchAfter = document.getElementById('searchAfter').value;
    var afterFilter = searchAfter ? `+after:${searchAfter}` : '';

    var searchEngine = document.getElementById('searchEngine').value;
    var searchQuery = `${encodeURIComponent(searchWord)}%E3%80%80-(${encodeURIComponent(notSearchWord)})%E3%80%80(${siteFilter})${afterFilter}`;

    // ()と-()だけのクエリを削除
    searchQuery = searchQuery.replace(/\(\)/g, '').replace(/-\(\)/g, '');

    var searchUrl;
    if (searchEngine === 'google') {
        searchUrl = `https://www.google.com/search?q=${searchQuery}`;
    } else if (searchEngine === 'bing') {
        searchUrl = `https://www.bing.com/search?q=${searchQuery}`;
    } else {
        searchUrl = `https://duckduckgo.com/?q=${searchQuery}`;
    }

    chrome.tabs.create({ url: searchUrl });
});

document.getElementById('addCurrentSiteButton').addEventListener('click', function() {
    var selectedCategories = document.querySelectorAll('input[name="category"]:checked');
    if (selectedCategories.length === 1) {
        var selectedCategoryIndex = selectedCategories[0].dataset.index;

        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            var currentTab = tabs[0];
            var url = new URL(currentTab.url);
            var site = `site:${url.hostname}`;
            var displayName = url.hostname;

            chrome.storage.local.get('customCategories', function(result) {
                var customCategories = result.customCategories || [];
                var selectedCategory = customCategories[selectedCategoryIndex];

                selectedCategory.subCategories.push({ name: displayName, url: site });
                chrome.storage.local.set({ customCategories: customCategories }, function() {
                    renderCategories(customCategories);
                });
            });
        });
    } else {
        alert('一つの上位カテゴリを選択してください。');
    }
});

document.getElementById('addCategoryButton').addEventListener('click', function() {
    var newCategoryName = prompt('新しいカテゴリーの名前を入力してください:');
    if (newCategoryName) {
        chrome.storage.local.get('customCategories', function(result) {
            var customCategories = result.customCategories || [];
            customCategories.push({ name: newCategoryName, subCategories: [] });
            chrome.storage.local.set({ customCategories: customCategories }, function() {
                renderCategories(customCategories);
            });
        });
    }
});

function createEditButton(checkbox, itemObject, isCategory = false) {
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'edit-button';
    button.textContent = '編集';

    button.addEventListener('click', function() {
        var label = checkbox.parentElement;
        
        var inputName = document.createElement('input');
        inputName.type = 'text';
        inputName.value = itemObject.name;

        if (isCategory) {
            label.insertBefore(inputName, checkbox.nextSibling);
        } else {
            var inputUrl = document.createElement('input');
            inputUrl.type = 'text';
            inputUrl.value = itemObject.url;
            label.insertBefore(inputUrl, checkbox);
            label.insertBefore(inputName, checkbox.nextSibling);
        }

        label.removeChild(checkbox);
        button.textContent = '保存';

        button.addEventListener('click', function() {
            var newSiteName = inputName.value;

            if (isCategory) {
                itemObject.name = newSiteName;
            } else {
                var newSiteUrl = inputUrl.value;
                itemObject.url = newSiteUrl;
            }

            chrome.storage.local.get('customCategories', function(result) {
                var customCategories = result.customCategories || [];
                var categoryIndex = customCategories.findIndex(item => item.name === itemObject.name);
                if (isCategory && categoryIndex !== -1) {
                    customCategories[categoryIndex].name = newSiteName;
                } else if (!isCategory) {
                    customCategories.forEach(category => {
                        var subCategoryIndex = category.subCategories.findIndex(sub => sub.name === itemObject.name);
                        if (subCategoryIndex !== -1) {
                            category.subCategories[subCategoryIndex] = itemObject;
                        }
                    });
                }
                chrome.storage.local.set({ customCategories: customCategories });
            });

            label.insertBefore(checkbox, inputName);
            if (!isCategory) {
                label.removeChild(inputUrl);
            }
            label.removeChild(inputName);
            button.textContent = '編集';
            label.childNodes[1].textContent = ` ${newSiteName}`;
        }, { once: true });
    });

    return button;
}

function createDeleteButton(checkbox, itemObject, isCategory = false) {
    var deleteButton = document.createElement('button');
    deleteButton.type = 'button';
    deleteButton.className = 'delete-button';
    deleteButton.textContent = '削除';

    deleteButton.addEventListener('click', function() {
        var label = checkbox.parentElement;
        label.remove();

        chrome.storage.local.get('customCategories', function(result) {
            var customCategories = result.customCategories || [];
            if (isCategory) {
                customCategories = customCategories.filter(item => item.name !== itemObject.name);
            } else {
                customCategories.forEach(category => {
                    category.subCategories = category.subCategories.filter(sub => sub.name !== itemObject.name);
                });
            }
            chrome.storage.local.set({ customCategories: customCategories });
        });
    });

    return deleteButton;
}

document.getElementById('exportButton').addEventListener('click', function() {
    chrome.storage.local.get('customCategories', function(result) {
        var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(result.customCategories));
        var downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "customCategories.json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    });
});

document.getElementById('importButton').addEventListener('change', function(event) {
    var file = event.target.files[0];
    var reader = new FileReader();
    reader.onload = function(e) {
        var importedCategories = JSON.parse(e.target.result);
        chrome.storage.local.set({ customCategories: importedCategories }, function() {
            renderCategories(importedCategories);
        });
    };
    reader.readAsText(file);
});

document.getElementById('clearStorageButton').addEventListener('click', function() {
    chrome.storage.local.clear(function() {
        location.reload();
    });
});

document.addEventListener('DOMContentLoaded', function() {
    chrome.storage.local.get('customCategories', function(result) {
        var customCategories = result.customCategories || [];
        renderCategories(customCategories);
    });
});

function renderCategories(categories) {
    var categoryGroup = document.getElementById('categoryGroup');
    categoryGroup.innerHTML = '';

    categories.forEach(function(category, index) {
        var label = document.createElement('label');
        var checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.name = 'category';
        checkbox.dataset.index = index;
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(` ${category.name}`));

        var editButton = createEditButton(checkbox, category, true);
        var deleteButton = createDeleteButton(checkbox, category, true);
        label.appendChild(editButton);
        label.appendChild(deleteButton);

        var subCategoryGroup = document.createElement('div');
        subCategoryGroup.className = 'sub-category-group';
        subCategoryGroup.style.display = 'none';
        subCategoryGroup.style.maxHeight = '200px'; // スクロールを設定
        subCategoryGroup.style.overflowY = 'auto';

        category.subCategories.forEach(function(subCategory, subIndex) {
            var subLabel = document.createElement('label');
            var subCheckbox = document.createElement('input');
            subCheckbox.type = 'checkbox';
            subCheckbox.name = 'site';
            subCheckbox.value = subCategory.url;
            subCheckbox.dataset.index = subIndex;
            subLabel.appendChild(subCheckbox);
            subLabel.appendChild(document.createTextNode(` ${subCategory.name}`));

            var subEditButton = createEditButton(subCheckbox, subCategory);
            var subDeleteButton = createDeleteButton(subCheckbox, subCategory);
            subLabel.appendChild(subEditButton);
            subLabel.appendChild(subDeleteButton);

            subCategoryGroup.appendChild(subLabel);
        });

        var addSiteButton = document.createElement('button');
        addSiteButton.type = 'button';
        addSiteButton.textContent = 'サイトを追加';
        addSiteButton.addEventListener('click', function() {
            var newSiteName = prompt('新しいサイトの名前を入力してください:');
            var newSiteUrl = prompt('新しいサイトのURLを入力してください:');

            if (newSiteName && newSiteUrl) {
                var newSiteObject = { name: newSiteName, url: newSiteUrl };
                category.subCategories.push(newSiteObject);
                chrome.storage.local.set({ customCategories: categories }, function() {
                    renderCategories(categories);
                });
            }
        });

        label.appendChild(addSiteButton);

        checkbox.addEventListener('change', function() {
            subCategoryGroup.style.display = checkbox.checked ? 'block' : 'none';
        });

        label.appendChild(subCategoryGroup);
        categoryGroup.appendChild(label);
    });
}