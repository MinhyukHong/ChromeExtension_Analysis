// Give the service worker access to Firebase Messaging.
// Note that you can only use Firebase Messaging here. Other Firebase libraries
// are not available in the service worker.
importScripts('https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.10.0/firebase-messaging.js');

const firebaseConfig = {
  apiKey: 'AIzaSyAibmfNIU_fVvJtB-ibThQOTCGxmWYjD6Y',
  authDomain: 'yh-mobile-wallet.firebaseapp.com',
  projectId: 'yh-mobile-wallet',
  storageBucket: 'yh-mobile-wallet.appspot.com',
  messagingSenderId: '1061474616018',
  appId: '1:1061474616018:web:b23bf818efd0662844630b',
  measurementId: 'G-1Q59NSJE47'
};

// Initialize the Firebase app in the service worker by passing in
// your app's Firebase config object.
// https://firebase.google.com/docs/web/setup#config-object
firebase.initializeApp(firebaseConfig);

// Retrieve an instance of Firebase Messaging so that it can handle background
// messages.
const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  // console.log('[firebase-messaging-sw.js] Received background message ', payload);
  // Customize notification here
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.title,
    icon: 'img/YH_ICON128x128.png'
  };

  self.registration.showNotification(notificationTitle,
    notificationOptions);
});
