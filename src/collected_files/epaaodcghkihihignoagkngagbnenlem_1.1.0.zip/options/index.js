const isValidJson = (str) => {
  try {
    JSON.parse(str);
    return true;
  } catch {
    return false;
  }
};

const saveAccounts = (value, onSuccess, onError) => {
  chrome.storage.sync
    .set({ accounts: JSON.parse(value) })
    .then(() => onSuccess())
    .catch((e) => {
      const text = (() => {
        if (e.message === "QUOTA_BYTES_PER_ITEM quota exceeded") {
          return "JSON is too large.";
        } else {
          console.log(e);
          return "Something went wrong. Please try again later.";
        }
      })();
      onError(text);
    });
};

const getElements = () => ({
  textarea: document.querySelector("textarea"),
  messagearea: document.querySelector(".message"),
  button: document.querySelector("button"),
});

const initTextarea = (textarea, accounts) => {
  const exampleAccounts = [
    {
      accountId: "012345678912",
      accountName: "This is example",
    },
  ];

  textarea.value = accounts
    ? JSON.stringify(accounts, null, 2)
    : JSON.stringify(exampleAccounts, null, 2);
  textarea.placeholder = JSON.stringify(exampleAccounts, null, 2);
};

document.addEventListener("DOMContentLoaded", async () => {
  const { accounts } = await chrome.storage.sync.get("accounts");
  const { textarea, messagearea, button } = getElements();
  const updateFeedBack = (type, message) => {
    messagearea.classList.remove("success", "error");
    messagearea.classList.add(type);
    messagearea.textContent = message;

    textarea.classList.remove("success", "error");
    textarea.classList.add(type);
  };
  const successFeedBack = () => updateFeedBack("success", "Saved successfully.");
  const errorFeedBack = (text) => updateFeedBack("error", `Error: ${text}`);

  initTextarea(textarea, accounts);
  button.addEventListener("click", (event) => {
    event.preventDefault();
    const accounts = textarea.value;

    if (!isValidJson(accounts)) {
      errorFeedBack("JSON is invalid.");
      return;
    }

    saveAccounts(accounts, successFeedBack, errorFeedBack);
  });
});
