document.getElementById("show-button").addEventListener("click", function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { action: "show" });
  });
});

document.getElementById("hide-button").addEventListener("click", function () {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { action: "hide" });
  });
});

document.getElementById("setting-link").addEventListener("click", function () {
  chrome.runtime.openOptionsPage();
});
