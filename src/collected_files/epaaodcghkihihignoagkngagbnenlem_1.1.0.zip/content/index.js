class AwsAccountLabel {
  constructor(accounts) {
    this.timer = null;
    this.accounts = accounts;
  }

  start() {
    this.timer = setInterval(() => {
      const element = this.#getAccountIdElement();

      if (element == null) {
        return;
      }

      const accountId = this.#extractAccountId(element.textContent);
      const accountName = this.#findAccountName(accountId);
      this.#appendElement(accountName);

      this.#stop();
    }, 1000);
  }

  #stop() {
    clearInterval(this.timer);
  }

  #findAccountName(accountId) {
    if (!this.accounts) {
      return "Unknown";
    }
    const account = this.accounts.find((account) => account.accountId === accountId);

    return account ? account.accountName : "Unknown";
  }

  #extractAccountId(textContent) {
    return textContent.match(/\d{4}-\d{4}-\d{4}/)[0].replace(/-/g, "");
  }

  #getAccountIdElement() {
    return document.querySelector("[data-testid=account-detail-menu]");
  }

  #appendElement(accountName) {
    const div = document.createElement("div");

    div.textContent = accountName;
    div.id = "awsAccountLabel";

    Object.assign(div.style, {
      position: "fixed",
      top: "80px",
      right: "10px",
      background: "#ff9900",
      padding: "12px 24px",
      borderRadius: "4px",
      fontWeight: "bold",
      zIndex: "99999",
      boxShadow: "0px 10px 10px -6px rgba(0, 0, 0, 0.3)",
    });

    document.body.appendChild(div);
  }
}

(async () => {
  const { accounts } = await chrome.storage.sync.get("accounts");

  new AwsAccountLabel(accounts).start();
})();

chrome.runtime.onMessage.addListener((message, _sender, _sendResponse) => {
  const getLabelElement = () => document.getElementById("awsAccountLabel");

  const label = getLabelElement();

  if (message.action === "show") {
    label.style.display = "block";
    return;
  }

  if (message.action === "hide") {
    label.style.display = "none";
    return;
  }
});
