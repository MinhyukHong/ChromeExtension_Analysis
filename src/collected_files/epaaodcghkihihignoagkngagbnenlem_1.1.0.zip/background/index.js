chrome.runtime.onInstalled.addListener(() => {
  chrome.runtime.openOptionsPage();
});

const pattern = /https:\/\/.*.console.aws.amazon.com/;

chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (pattern.test(tab.url)) {
      chrome.action.setPopup({ tabId: activeInfo.tabId, popup: "popup/index.html" });
    } else {
      chrome.action.setPopup({ tabId: activeInfo.tabId, popup: "" });
    }
  });
});
