var base_uri = new URL(window.location.origin).origin;
if (base_uri.includes('whatsapp')) {
  localStorage.setItem('exId', chrome.runtime.id);
  loadScripts(['/app/jquery.js', '/app/bootstrap.bundle.min.js', '/app/whats.js?cache=' + Date.now(), '/app/wppconnect-wa.js', '/app/xlsx.full.min.js']);
}

function loadScripts(scripts_arr) {
  for (i of scripts_arr) {
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = 'chrome-extension://' + chrome.runtime.id + i;
    var firstScriptTag = document.getElementsByTagName('link')[0];
    firstScriptTag ? firstScriptTag.parentNode.appendChild(script, firstScriptTag) : document.body.appendChild(script);
  }
}
