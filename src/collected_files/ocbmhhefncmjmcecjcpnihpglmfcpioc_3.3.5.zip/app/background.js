importScripts("xlsx.full.min.js"); // <-- required for V3


chrome.runtime.onMessageExternal.addListener(function (request, sender, sendResponse) {
  console.log(request);
  fetch(request.url, {
    mode: 'no-cors',
  })
    .then(async (response) => await response.json())
    .then(async (json) => {
      await sendResponse(json);
      console.log(json);
    });
});

chrome.action.onClicked.addListener((tab) => {
  chrome.browsingData.remove({}, { serviceWorkers: true }, () => null);
  console.log(tab.id);

  //showWhatsappTab(false);

  chrome.tabs.query({ url: 'https://web.whatsapp.com/' }, function (tabs) {
    if (tabs.length > 0) {
      chrome.tabs.update(tabs[0].id, { active: true });
    } else {
      chrome.tabs.create({ url: 'https://web.whatsapp.com/' });
    }
  });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ['app/ext.js'],
  });
  console.log(tab);
});

async function showWhatsappTab(reload = true) {
  chrome.tabs.query({ active: false, currentWindow: false }, function (tabs) {
    console.log(tabs);
    const whatsappTab = tabs.find((tab) => tab.url !== 'https://web.whatsapp.com' || tab.url !== 'https://web.whatsapp.com/');
    console.log(whatsappTab);
    if (whatsappTab) {
      chrome.tabs.update(
        whatsappTab.id,
        {
          active: true,
        },
        function (tab) {
          console.log('Error');
        }
      );
      if (reload) {
        setTimeout(function () {
          chrome.tabs.reload(whatsappTab.id);
        }, 500);
      }
    } else {
      const newURL = 'https://web.whatsapp.com';
      chrome.tabs.create({
        url: newURL,
      });
    }
  });
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.type == 'click_event') {
    console.log('click event captured in current webpage');
    // Call the callback passed to chrome.action.onClicked
  }
});
