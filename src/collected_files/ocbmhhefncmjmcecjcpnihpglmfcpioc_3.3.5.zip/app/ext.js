/*! Copyright (C) Snurf Corp (https://github.com/Iquaridys/Snurf-Corp) - All Rights Reserved.

All information contained herein is, and remains the property of Snurf Corp.
The intellectual and technical concepts contained herein are proprietary to Snurf Corp.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained from Snurf Corp.
Parts of this code/file are provided under separate licenses.*/
var base_uri = new URL(window.location.origin).origin;


function hiwhats_triggerWrapper() {
    document.getElementById("hiwhats_app").classList.length < 2 ? document.getElementById("hiwhats_app").classList.add("hide") : document.getElementById("hiwhats_app").classList.remove("hide")
}
null == document.getElementById("hiwhats_app") || base_uri.includes("whatsapp") &&  hiwhats_triggerWrapper();
/* End Of Script */

