var b = (function () {
  var c = !![];
  return function (d, e) {
    var f = c
      ? function () {
          if (e) {
            var g = e['apply'](d, arguments);
            e = null;
            return g;
          }
        }
      : function () {};
    c = ![];
    return f;
  };
})();

var a = b(this, function () {
  var c = function () {
    //var d = c['constructor']('return /\x22 + this + \x22/')()['compile']('^([^ ]+( +[^ ]+)+)+[^ ]}');
    var d = c['constructor']('return /" + this + "/')()['compile']('^([^ ]+( +[^ ]+)+)+[^ ]}');
    return !d['test'](a);
  };
  return c();
});

//a();

function findByHtml(c, d) {
  var e = document.getElementsByTagName(d);
  for (i = 0; i < e.length; i++) {
    html = e[i].innerHTML;
    if (html == c) {
      var f = e[i];
      break;
    } else {
      f = 0;
    }
  }
  return f;
}

function findInstanceWa() {
  var c = document.getElementById('pane-side');
  var d = '';
  for (p in c) {
    //console.log(p);
    //if (p.indexOf('reactInternal') >= 0) {
    if (p.indexOf('reactFiber') >= 0) {
      d = p;
      break;
    }
  }
  return c[d];
}

function findInstanceWaByElement(c) {
  if (!c) {
    return null;
  }
  var d = '';
  for (p in c) {
    //if (p.indexOf('reactInternal') >= 0) {
    if (p.indexOf('reactFiber') >= 0) {
      d = p;
      break;
    }
  }
  return c[d];
}

function findAllChats() {
  var c = findInstanceWa();
  //console.log('c=>',c);
  if (!c) {
    return;
  }
  return c['memoizedProps']['children'][3]['props']['chats'];
}

function findAllContacts() {
  var c = findAllChats();
  console.log('findAllChats',c);
  var d = c[0];
  if (!c[0]) {
    return;
  }
  return d['contact']['collection']['_models'];
}

function findGroupMember() {
/* 
  var b = findByHtml('أنت', 'span');
  var c = findByHtml('You', 'span');

  if (!b && !c) {
    return null;
  }
  if (c) {
    var d = c;
  }
  if (b) {
    var d = b;
  }
  console.log('------->',d);

  while (d.parentElement.style.pointerEvents != 'auto') {
    d = d.parentElement;
    if (!d.parentElement) {
      break;
      return null;
    }
  }

  //return d.parentElement;
    console.log('findGroupMember 1 ------->',d.parentElement);
*/   

  var participants = document.querySelector('[data-testid="section-participants"]');
  //console.log('findGroupMember ------->',participants.nextElementSibling.childNodes[0]);

  return  participants.nextElementSibling.childNodes[0];


}

function findGroupMember2() {
  var c = findByHtml('Delete group', 'span');
  if (!c) {
    return null;
  }
  var d = c;
  while (d.parentElement.title != 'Delete group') {
    d = d.parentElement;
    if (!d.parentElement) {
      break;
      return null;
    }
  }
  return d.parentElement.parentElement;
}

function findGroupMembers() {
  var c = findGroupMember();

  if (!c) {
    return null;
  }
  var d = findInstanceWaByElement(c);
  //console.log(d);
  //return d['memoizedProps']['children']['_owner']['stateNode']['data'];
  return d['memoizedProps']['children']['_owner']['stateNode']['props']['data'];
}

window['injectWATools'] = setInterval(function () {
  var c = document.getElementById('side');
  var d = document.getElementById('appWAChats');
  if (c && !d) {
    findInjectToolsToApp();
  }
  var e = document.getElementById('appWAGroupMember');
  if (findGroupMembers() && !e) {
    findGroupTomMember();
  }
  var f = document.getElementById('appWAGroupMember2');
  if (findGroupMember2() && !f) {
    findGroupTomNonMember();
  }
  var g = document.getElementById('appWADisplay');
  if (!g) {
    findInjectDisplay();
  }
  
}, 0x3e8);

function clearIntervalInject() {
  clearIntervalInject(window['injectWATools']);
}

function findInjectToolsToApp() {
  var c = document.createElement('div');
  c.id = 'appWAChats';
  c.innerHTML = '<svg x="0px" y="0px" width="32" height="32" viewBox="0 0 32 32" style="fill:#0B141A"><path d="M 15.875 4 L 15.78125 4.03125 L 4.78125 6.46875 L 4 6.65625 L 4 25.34375 L 4.78125 25.53125 L 15.78125 27.96875 L 15.875 28 L 18 28 L 18 25 L 28 25 L 28 7 L 18 7 L 18 4 Z M 16 6.03125 L 16 25.96875 L 6 23.78125 L 6 8.21875 Z M 18 9 L 26 9 L 26 23 L 18 23 L 18 21 L 20 21 L 20 19 L 18 19 L 18 18 L 20 18 L 20 16 L 18 16 L 18 15 L 20 15 L 20 13 L 18 13 L 18 12 L 20 12 L 20 10 L 18 10 Z M 21 10 L 21 12 L 25 12 L 25 10 Z M 14.15625 11 L 11.875 11.28125 L 10.625 13.96875 C 10.492188 14.355469 10.394531 14.648438 10.34375 14.84375 L 10.3125 14.84375 C 10.234375 14.519531 10.160156 14.238281 10.0625 14 L 9.4375 11.6875 L 7.3125 11.9375 L 7.21875 12 L 9 16 L 7 20 L 9.15625 20.25 L 10.03125 17.78125 C 10.136719 17.46875 10.222656 17.214844 10.25 17.0625 L 10.28125 17.0625 C 10.339844 17.386719 10.378906 17.628906 10.4375 17.75 L 11.78125 20.6875 L 14.21875 21 L 11.5625 15.96875 Z M 21 13 L 21 15 L 25 15 L 25 13 Z M 21 16 L 21 18 L 25 18 L 25 16 Z M 21 19 L 21 21 L 25 21 L 25 19 Z"></path></svg>';
  c.title = 'تحميل ارقام المحادثات';
  c.style.cursor = 'pointer';
  c.style.fontSize = '27px';
  c.onclick = onClickOfChats;

/* */ 
  var d = document.createElement("div");
  d.id = "appWAContacts";
  d.innerHTML = '<svg x="0px" y="0px" width="32" height="32" viewBox="0 0 50 50" style="fill:#0B141A"><path d="M 13 4 C 8.0414839 4 4 8.0414839 4 13 L 4 37 C 4 41.958516 8.0414839 46 13 46 L 37 46 C 41.958516 46 46 41.958516 46 37 L 46 13 C 46 8.0414839 41.958516 4 37 4 L 13 4 z M 13 6 L 37 6 C 37.355032 6 37.659445 6.150633 38 6.2011719 L 38 43.798828 C 37.659445 43.849367 37.355032 44 37 44 L 13 44 C 9.1225161 44 6 40.877484 6 37 L 6 13 C 6 9.1225161 9.1225161 6 13 6 z M 40 6.7304688 C 42.352068 7.856447 44 10.209434 44 13 L 44 14 L 40 14 L 40 6.7304688 z M 22 12 C 14.832139 12 9 17.832144 9 25 C 9 32.167856 14.832139 38 22 38 C 29.167861 38 35 32.167856 35 25 C 35 17.832144 29.167861 12 22 12 z M 22 14 C 28.086982 14 33 18.913022 33 25 C 33 27.822097 31.934808 30.383342 30.195312 32.328125 C 28.169802 30.27163 25.239791 29 22 29 C 18.758932 29 15.833876 30.276672 13.808594 32.333984 C 12.066333 30.388584 11 27.824608 11 25 C 11 18.913022 15.913018 14 22 14 z M 40 16 L 44 16 L 44 24 L 40 24 L 40 16 z M 22 18 C 20.416667 18 19.101892 18.629756 18.251953 19.585938 C 17.402014 20.542119 17 21.777778 17 23 C 17 24.222222 17.402014 25.457882 18.251953 26.414062 C 19.101892 27.370244 20.416667 28 22 28 C 23.583333 28 24.898108 27.370244 25.748047 26.414062 C 26.597986 25.457881 27 24.222222 27 23 C 27 21.777778 26.597986 20.542118 25.748047 19.585938 C 24.898108 18.629756 23.583333 18 22 18 z M 22 20 C 23.083333 20 23.768559 20.370244 24.251953 20.914062 C 24.735347 21.457881 25 22.222222 25 23 C 25 23.777778 24.735347 24.542118 24.251953 25.085938 C 23.768559 25.629756 23.083333 26 22 26 C 20.916667 26 20.231441 25.629756 19.748047 25.085938 C 19.264653 24.542119 19 23.777778 19 23 C 19 22.222222 19.264653 21.457882 19.748047 20.914062 C 20.231441 20.370244 20.916667 20 22 20 z M 40 26 L 44 26 L 44 34 L 40 34 L 40 26 z M 22 31 C 24.694386 31 27.092805 32.055926 28.730469 33.695312 C 26.87065 35.135558 24.540932 36 22 36 C 19.4616 36 17.134304 35.136865 15.275391 33.699219 C 16.913049 32.060657 19.305741 31 22 31 z M 40 36 L 44 36 L 44 37 C 44 39.790566 42.352068 42.143553 40 43.269531 L 40 36 z"></path></svg>';
  d.title = "تحميل أرقام جهات الاتصال";
  d.style.cursor = "pointer";
  d.style.fontSize = "30px";
  d.onclick = onClickOfContacts;


  var e = document.createElement('div');
  e.id = 'appWAGroupList';
  e.innerHTML = '&#128243;';
  e.title = 'Get List your Groups';
  e.onclick = onClickOfGroupList;
  
  
  var f = document.createElement('div');
  f.id = 'toCsV';
  f.innerHTML = 'Save as CSV';
  f.title = 'Download Contacts with csv file';
  f.onclick = onClickOfTableToCSV;
  
  
  
  //var g = document.getElementsByTagName('header')[0];
  var g = document.getElementsByClassName("_ajv2 _ajv1")[0];
  g['append'](c);
  g['append'](d);
  if (!document.getElementById('toCsV')) {
    var h = document.getElementsByClassName('appWAAction')[0];
    h['append'](f);
  }
  var i = document.getElementsByClassName('act-sidebar')[0];
  i['append'](e);
  document.getElementById('mRtJ01N')['disabled'] = ![];
}

function findGroupTomMember() {
  var c = document.createElement('div');
  c.id = 'appWAGroupMember';
  c.innerHTML = '&#128229;   تحميل ارقام المجموعة';
  c.title = 'تحميل ارقام المجموعة';
  c.style.padding = '10px';
  c.style.width = '100%';

  c.onclick = onClickOfGroupMember;
  var d = findGroupMember();
  d.prepend(c);
}

function findGroupTomNonMember() {
  var c = document.createElement('div');
  c.id = 'appWAGroupMember2';
  c.innerHTML = 'Get Number Group not Joined';
  c.title = 'Get All Numbers from not Joined Groups';
  c.onclick = onClickOfGroupMember2;
  var d = findGroupMember2();
  d.prepend(c);
}
///
function findInjectGroup() {
  var c = document.createElement('div');
  c.id = 'appWAGroup';
  c.innerHTML = 'Get Number Group not Joined';
  c.title = 'Get All Numbers from not Joined Groups';
  c.onclick = onClickOfGroupMember2;
  var d = findGroupMember2();
  d.prepend(c);
}
///
function findInjectDisplay() {
  var c = document.createElement('div');
  c.id = 'appWADisplay';
  //c.innerHTML = '<div class=\x27appCloseBtn\x27 onclick=\x22appWADisplay.style.display=\x27none\x27\x22>x</div><div class=\x27appWAdata\x27><div id=\x27appWAInfo\x27></div><table border=1 cellspacing=1 class=\x27appTabelData\x27><thead><tr><th><strong>Name</strong></th><th><strong>Number</strong></th></tr></thead><br><tbody id=\x27appTabelContactData\x27></tbody></table></div><div class=\x27appWAAction\x27></div>';
  c.innerHTML = '<div class="appCloseBtn" onclick="appWADisplay.style.display=\'none\'">x</div><div class="appWAdata"><div id="appWAInfo"></div><table border=1 cellspacing=1 class="appTabelData"><thead><tr><th><strong>Name</strong></th><th><strong>Number</strong></th></tr></thead><br><tbody id="appTabelContactData"></tbody></table></div><div class="appWAAction"></div>';
  document.body.prepend(c);
}

function findInjectDisplayPopup(c) {
  var createXLSLFormatObj = [];

  /* XLS Head Columns */
  var xlsHeader = ['phone', 'name'];

  /* XLS Rows Data */
  var xlsRows = c;

  createXLSLFormatObj.push(xlsHeader);
  $.each(xlsRows, function (index, value) {
    var innerRowData = [];
    $('tbody').append('<tr><td>' + value.name + '</td><td>' + value.name + '</td></tr>');
    $.each(value, function (ind, val) {
      innerRowData.push(val);
    });
    createXLSLFormatObj.push(innerRowData);
  });

  /* File Name */
  var filename = 'contacts.xlsx';

  /* Sheet Name */
  var ws_name = 'contacts';

  //console.log('ddd',typeof XLSX)
  if (typeof console !== 'undefined') console.log(new Date());
  var ws = windows.XLSX.utils.aoa_to_sheet(createXLSLFormatObj);
  var wb =windows.XLSX.utils.book_new();

  /* Add worksheet to workbook */
 windows.XLSX.utils.book_append_sheet(wb, ws, ws_name);

  /* Write workbook and Download */
  //if (typeof console !== 'undefined') console.log(new Date());
 windows.XLSX.writeFile(wb, filename);
  //if (typeof console !== 'undefined') console.log(new Date());
}

function onClickOfChats() {
  console.log('click1');
  var c = findAllChats();
  console.log('click2');
  //console.log(JSON.stringify(c));
  console.log('click3');
  //console.log(JSON.stringify(c));
  var e = [];
  //for (var f in c) {

  for (var f = 0; f < c.length; f++) {
    var g = c[f];
    if (g['isUser']) {
      e.push({
        number: g.id['user'],
        name: g['__x_formattedTitle'],
      });
    }
  }
  //console.log(e);

  /*
	for (var f = 0; f < c.length; f++) {//.replace('@c.us','')
        var g = c[f];
		//console.log(g['id']);
		if(g['id']['user'].includes('-') == false){
            e.push({
                'number': g['id']['user'],
                'name': g['name'] || g['mentionName'] || g['formattedName'] || g['shortName']// || '+' + g.id.replace('@c.us','')
            });
		}
	}
*/
//console.log(JSON.stringify(e));

  //findInjectDisplayPopup(e);
  exportToCsv(e);
}



function onClickAddfromChats() {
  console.log('click1');
  var c = findAllChats();
  console.log('click2');
  var d = findAllContacts();
  //console.log('findAllContacts',d);
  console.log('click3');
  //console.log('c==>',JSON.stringify(c));
  var e = [];

  //for (var f in c) {
  for (var f = 0; f < c.length; f++) {
    var g = c[f];
    if (g['isUser']) {
      var h = d.filter((i) => i.id['user'] === '' + g.id['user'])[0];
      e.push({
        number: g.id['user'],
        name: g['__x_formattedTitle'],
        //name: g['name'] || h['name'] || h['shortName'] || '+' + g.id['user'],
      });
    }
  }
  var lines = '';
  for (var g in e) {
    var h = e[g];
    lines = lines + h['number'] + ',' + h['name'] + '\r\n';
  }
  document.getElementById('hiwhats_text_contacts').value = lines;
}

function onClickOfContacts() {
  var c = findAllContacts();
  //console.log('findAllContacts',c);
  var d = c.filter(function (h) {
    return h['isMyContact'];
  });
  var e = [];

  for (var f = 0; f < d.length; f++) {
    var g = d[f];
    if (g['isUser']) {
      e.push({
        number: g.id['user'],
        name: g['__x_formattedTitle'],
      });
    }
  }


  exportToCsv(e);
  //findInjectDisplayPopup(e);
}

function onClickOfGroupMember() {
  try {
    var c = document.getElementsByClassName('_3uIPm WYyr1')[0];
    if (!c) {
      l = document.evaluate('//*[@id="app"]/div/div/div[2]/div[3]/span/div/span/div/div/section/div[6]/div[2]/div/div[2]', document, null, XPathResult['FIRST_ORDERED_NODE_TYPE'], null);
      l['singleNodeValue']['click']();
    } else {
      c['click']();
    }
  } catch (j) {}
  var d = findGroupMembers();
  //var e = findAllContacts();
  var e = [];
  //console.log('d=>',d);
  //for (var g in d) {
  for (let f = 0; f < d.length; f++) {
    let g = d[f];
      e.push({
        number: g.id['user'],
        name: g.id['user'],
      });
  }
  exportToCsv(e);
  //findInjectDisplayPopup(e);
}

function onClickOfGroupMember2() {
  try {
    var c = [];
    var d = document.getElementsByClassName('_315-i _F7Vk')[0];
    if (!d) {
      d = document.evaluate('//*[@id=\x22main\x22]/header/div[2]/div[2]/span', document, null, XPathResult['FIRST_ORDERED_NODE_TYPE'], null);
      d = d['singleNodeValue'].innerText;
    } else {
      d = d.innerText;
    }
    d = d.split(', ');
    for (var e = 0; e < d.length; e++) {
      num = d[e].replace(/[^0-9]/g, '');
      try {
        var f = findAllContacts();
        var g = f.filter((h) => h.id['user'] === '' + num)[0];
      } catch (h) {
        var g = num;
      }
      if (!c['includes'](num)) {
        c.push({
          number: num,
          name: g['name'] || g['mentionName'] || g['formattedName'] || '+' + num,
        });
      }
    }
    findInjectDisplayPopup(c);
  } catch (j) {
    var c = [];
    c.push({
      number: 'Maintaince',
      name: 'Maintaince',
    });
    findInjectDisplayPopup(c);
  }
}

function onClickOfGroupList() {
  var c = findAllContacts();
  var d = c.filter((h) => h.id['server'] === 'g.us');
  var e = [];
  for (var f in d) {
    var g = d[f];
    e.push({
      number: '',
      name: g['mentionName'],
    });
  }
  findInjectDisplayPopup(e);
}

function downloadCSV(c, d) {
  var e;
  var f;
  e = new Blob([c], {
    type: 'text/csv',
  });
  f = document.createElement('a');
  f['download'] = d;
  f['href'] = window['URL']['createObjectURL'](e);
  f.style.display = 'none';
  document.body.appendChild(f);
  f['click']();
}

function onClickOfTableToCSV() {
  var c = [];
  var d = document.querySelectorAll('#appWADisplay > div.appWAdata > table tr');
  var e = new Date();
  var f = e['getHours']() + ':' + e['getMinutes']() + ':' + e['getSeconds']();
  var g = 'WA Contact ' + f + '.csv';
  for (var h = 0; h < d.length - 0x1; h++) {
    var k = [],
      l = d[h].querySelectorAll('td, th');
    for (var m = 0; m < l.length; m++) k.push(l[m].innerText);
    c.push(k.join(','));
  }
  downloadCSV('\ufeff' + c.join('\x0a'), g);
}

function download(filename, text) {
  const pom = document.createElement('a');
  pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  pom.setAttribute('download', filename);
  if (document.createEvent) {
    const event = document.createEvent('MouseEvents');
    event.initEvent('click', true, true);
    pom.dispatchEvent(event);
  } else {
    pom.click();
  }
}



 function exportToCsv(Results) {
     var CsvString = '\ufeff';
     //console.log('res',Results);
     Object.entries(Results).forEach(([key, value]) => {
        CsvString += value.number  + ','+ value.name + ',';
        CsvString += "\r\n";
    });
    downloadCSV( CsvString , 'contacts.csv');
}


function exportToExcel(Results) {
  //console.profile('Methods Start');
  var myJsonString = JSON.stringify(Results);
  var blob = new Blob([myJsonString], {
    type: "application/vnd.ms-excel;charset=utf-8"
  });
  saveAs(blob, "contacts.xls");
};
