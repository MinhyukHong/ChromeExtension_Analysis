var base_uri = new URL(window.location.origin).origin;



function hiwhats_getBaseUrl() {
    return window.location.href.match(/^.*\//)[0]
}

function hiwhats_createElm(e) {
    return document.createElement(e)
}

function createDocFragment(e) {
    var t = document.createDocumentFragment(),
        a = hiwhats_createElm("div");
    for (a.innerHTML = e; a.firstChild;) t.appendChild(a.firstChild);
    return t
}



//##############################################################################//


var hiwhats_imgFile = hiwhats_getBaseUrl();
if (hiwhats_imgFile.includes("whatsapp")){

//var meta = document.createElement('meta');
//meta.httpEquiv = "Access-Control-Allow-Origin";
//meta.content = "*";
//document.getElementsByTagName('head')[0].appendChild(meta);


var iWA_container = createDocFragment(`

<!-- Report Modal -->
<div class="modal fade" id="hiwhats_reportModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content" dir="rtl">
            <div class="modal-header">
                <h5 class="modal-title"> نتيجة الارسال</h5>
            </div>
            <div class="modal-body">

                <div class="hiwhats_areabox_">
                    <table id="hiwhats_myTable_Wa" class="table table-Warning">
                    </table>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="bbtn bbtn-secondary" data-dismiss="modal">اغلاق</button>
            </div>
        </div>
    </div>
</div>
<!-- Report Modal -->


<!-- Modal hiwhats_myGroupModal -->
<div class="modal fade" id="hiwhats_myGroupModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content" dir="rtl">
            <div class="modal-header">
                <h4 class="modal-title">قم باختيار مجموعة!</h4>
            </div>
            <div class="modal-body" id="hiwhats_savedGroup">


                <table class="table table-hover" id="hiwhats_groupsTableModal">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>اسم المجموعة</th>
                            <th>عدد الأرقام</th>
                        </tr>
                    </thead>
                    <tbody id="hiwhats_groupsTableBodyModal">

                    </tbody>
                </table>


            </div>
            <div class="modal-footer">
                <button type="button" class="bbtn bbtn-default" data-dismiss="modal">اغلاق</button>
                <button type="button" class="bbtn bbtn-primary" id="hiwhats_groupsTableAddBtn">ادراج</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal hiwhats_myGroupModal -->




<div class="hiwhats_container hide" id="hiwhats_app" style="direction:rtl">


    <div class="container-fluid">
        <div class="row" style="border-bottom:solid 2px #2A2A2A;">
            <div class="col-md-4 p-3" style="text-align:right;">
                <img src="https://hiwhats.com/logov2.png" style="height:45px">
            </div>
            <div class="col-md-4">
            </div>
            <div class="col-md-4" style="text-align:left;">
                <p>
                    <select id="hiwhats_dir" class="custom-select custom-select-sm">
                        <option value="right">محاذاة يمين</option>
                        <option value="left">محاذاة يسار</option>
                    </select>
                </p>
                <a href="https://hiwhats.com/Packages" class="bbtn bbtn-success bbtn-sm mt-2" target="_blank">شراء باقة</a>
            </div>
        </div>
    </div>


    <div class="container-fluid app-container">
        <div class="row" id="hiwhats_user_auth">
            <div class="col-md-3 pt-3 pr-0 pl-0 sideNavbar">
                <ul class="nav flex-column nav-tabs" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                    <li class="nav-item">
                        <a class="nav-link pt-3 pb-3 lang active" id="hiwhats_signinUser-tab" data-toggle="tab" href="#hiwhats_signinUser" role="tab" aria-controls="hiwhats_signinUser-tab" aria-selected="true" key="login"><i class="fa fa-sign-in"></i> تسجيل دخول</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link pt-3 pb-3 lang" id="hiwhats_signupUser-tab" data-toggle="tab" href="#hiwhats_signupUser" role="tab" aria-controls="hiwhats_signupUser-tab" aria-selected="false"><i class="fa fa fa-user-plus"></i> مستخدم جديد </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link pt-3 pb-3 lang" id="activateUser-tab" data-toggle="tab" href="#activateUser" role="tab" aria-controls="activateUser-tab" aria-selected="false"><i class="fa fa fa-user-plus"></i> تفعيل حساب </a>
                    </li>
                </ul>
            </div>
            <div class="col-md-9 p-0">
                <div class="tab-content p-3" id="hiwhats_hiwhats_myTabContent1">

                    <!-- hiwhats_signinUser -->
                    <div class="tab-pane show active" id="hiwhats_signinUser" role="tabpanel" aria-labelledby="hiwhats_signinUser-tab">

                        <div class="col-xs-12">
                            <br>
                            <div class="alert alert-danger" role="alert" id="hiwhats_loginFailedMsg">بيانات الدخول غير صحيحة</div>
                            <div class="alert alert-success" role="alert" id="hiwhats_loginSuccessMsg">تم تسجيل الدخول بنجاح</div>
                            <div id="hiwhats_signinPhoneNumberDiv">
                                <div class="form-group">
                                    <span class="title">اسم المستخدم</span>
                                    <label class="text-danger" for="hiwhats_signinUsernameInput"></label>
                                    <input type="tel" class="form-control" placeholder="رقم الموبايل, مثال: 96656751982" id="hiwhats_signinUsernameInput" dir="ltr">
                                </div>
                                <div class="form-group">
                                    <label class="title">كلمة المرور:</label>
                                    <label class="text-danger" for="hiwhats_signinPasswordInput"></label>
                                    <input type="password" class="form-control" id="hiwhats_signinPasswordInput">
                                </div>

                                <div class="form-group pt-3">
                                    <button class="bbtn bbtn-primary bbtn-sm get-started" id="hiwhats_signinBtn">دخول</button>
                                    <a class="bbtn bbtn-primary bbtn-sm lang" target="_blank" href="https://hiwhats.com/usercp/pwreset">نسيت كلمة المرور</a>
                                </div>


                                <br><br>
                            </div>

                        </div>

                    </div>
                    <!-- hiwhats_signinUser -->


                    <!-- hiwhats_signupUser -->
                    <div class="tab-pane" id="hiwhats_signupUser" role="tabpanel" aria-labelledby="hiwhats_signupUser-tab">

                        <div class="col-xs-12 text-center">
                            <br>
                            <div class="alert alert-danger" role="alert" id="hiwhats_signupFailedMsg"></div>
                            <div class="alert alert-success" role="alert" id="hiwhats_signupSuccessMsg">
                                تم التسجيل بنجاح و ارسال رابط تفعيل الحساب الى واتساب الخاص بك
                            </div>
                            <div id="hiwhats_signupPhoneNumberDiv">


                                <div class="row">
                                    <div class="col-md-12 form-group">
                                        <input type="text" name="hiwhats_signupNameInput" id="hiwhats_signupNameInput" class="form-control" placeholder="الاسم">
                                    </div>
                                    <div class="col-md-12 form-group">
                                        <input type="email" name="hiwhats_signupEmailInput" id="hiwhats_signupEmailInput" class="form-control" placeholder="البريد الالكتروني">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 mb-3" dir="ltr">
                                        <div class="input-group select-group">

                                            <select name="hiwhats_signupCountryCodeInput" id="hiwhats_signupCountryCodeInput" class="form-control input-group-addon" dir="ltr">
                                                <option data-countryCode="DZ" value="213">Algeria (+213)</option>
                                                <option data-countryCode="AD" value="376">Andorra (+376)</option>
                                                <option data-countryCode="AO" value="244">Angola (+244)</option>
                                                <option data-countryCode="AI" value="1264">Anguilla (+1264)</option>
                                                <option data-countryCode="AG" value="1268">Antigua &amp; Barbuda (+1268)</option>
                                                <option data-countryCode="AR" value="54">Argentina (+54)</option>
                                                <option data-countryCode="AM" value="374">Armenia (+374)</option>
                                                <option data-countryCode="AW" value="297">Aruba (+297)</option>
                                                <option data-countryCode="AU" value="61">Australia (+61)</option>
                                                <option data-countryCode="AT" value="43">Austria (+43)</option>
                                                <option data-countryCode="AZ" value="994">Azerbaijan (+994)</option>
                                                <option data-countryCode="BS" value="1242">Bahamas (+1242)</option>
                                                <option data-countryCode="BH" value="973">Bahrain (+973)</option>
                                                <option data-countryCode="BD" value="880">Bangladesh (+880)</option>
                                                <option data-countryCode="BB" value="1246">Barbados (+1246)</option>
                                                <option data-countryCode="BY" value="375">Belarus (+375)</option>
                                                <option data-countryCode="BE" value="32">Belgium (+32)</option>
                                                <option data-countryCode="BZ" value="501">Belize (+501)</option>
                                                <option data-countryCode="BJ" value="229">Benin (+229)</option>
                                                <option data-countryCode="BM" value="1441">Bermuda (+1441)</option>
                                                <option data-countryCode="BT" value="975">Bhutan (+975)</option>
                                                <option data-countryCode="BO" value="591">Bolivia (+591)</option>
                                                <option data-countryCode="BA" value="387">Bosnia Herzegovina (+387)</option>
                                                <option data-countryCode="BW" value="267">Botswana (+267)</option>
                                                <option data-countryCode="BR" value="55">Brazil (+55)</option>
                                                <option data-countryCode="BN" value="673">Brunei (+673)</option>
                                                <option data-countryCode="BG" value="359">Bulgaria (+359)</option>
                                                <option data-countryCode="BF" value="226">Burkina Faso (+226)</option>
                                                <option data-countryCode="BI" value="257">Burundi (+257)</option>
                                                <option data-countryCode="KH" value="855">Cambodia (+855)</option>
                                                <option data-countryCode="CM" value="237">Cameroon (+237)</option>
                                                <option data-countryCode="CV" value="238">Cape Verde Islands (+238)</option>
                                                <option data-countryCode="KY" value="1345">Cayman Islands (+1345)</option>
                                                <option data-countryCode="CF" value="236">Central African Republic (+236)</option>
                                                <option data-countryCode="CL" value="56">Chile (+56)</option>
                                                <option data-countryCode="CN" value="86">China (+86)</option>
                                                <option data-countryCode="CO" value="57">Colombia (+57)</option>
                                                <option data-countryCode="KM" value="269">Comoros (+269)</option>
                                                <option data-countryCode="CG" value="242">Congo (+242)</option>
                                                <option data-countryCode="CK" value="682">Cook Islands (+682)</option>
                                                <option data-countryCode="CR" value="506">Costa Rica (+506)</option>
                                                <option data-countryCode="HR" value="385">Croatia (+385)</option>
                                                <option data-countryCode="CU" value="53">Cuba (+53)</option>
                                                <option data-countryCode="CY" value="90392">Cyprus North (+90392)</option>
                                                <option data-countryCode="CY" value="357">Cyprus South (+357)</option>
                                                <option data-countryCode="CZ" value="42">Czech Republic (+42)</option>
                                                <option data-countryCode="DK" value="45">Denmark (+45)</option>
                                                <option data-countryCode="DJ" value="253">Djibouti (+253)</option>
                                                <option data-countryCode="DM" value="1809">Dominica (+1809)</option>
                                                <option data-countryCode="DO" value="1809">Dominican Republic (+1809)</option>
                                                <option data-countryCode="EC" value="593">Ecuador (+593)</option>
                                                <option data-countryCode="EG" value="20">Egypt (+20)</option>
                                                <option data-countryCode="SV" value="503">El Salvador (+503)</option>
                                                <option data-countryCode="GQ" value="240">Equatorial Guinea (+240)</option>
                                                <option data-countryCode="ER" value="291">Eritrea (+291)</option>
                                                <option data-countryCode="EE" value="372">Estonia (+372)</option>
                                                <option data-countryCode="ET" value="251">Ethiopia (+251)</option>
                                                <option data-countryCode="FK" value="500">Falkland Islands (+500)</option>
                                                <option data-countryCode="FO" value="298">Faroe Islands (+298)</option>
                                                <option data-countryCode="FJ" value="679">Fiji (+679)</option>
                                                <option data-countryCode="FI" value="358">Finland (+358)</option>
                                                <option data-countryCode="FR" value="33">France (+33)</option>
                                                <option data-countryCode="GF" value="594">French Guiana (+594)</option>
                                                <option data-countryCode="PF" value="689">French Polynesia (+689)</option>
                                                <option data-countryCode="GA" value="241">Gabon (+241)</option>
                                                <option data-countryCode="GM" value="220">Gambia (+220)</option>
                                                <option data-countryCode="GE" value="7880">Georgia (+7880)</option>
                                                <option data-countryCode="DE" value="49">Germany (+49)</option>
                                                <option data-countryCode="GH" value="233">Ghana (+233)</option>
                                                <option data-countryCode="GI" value="350">Gibraltar (+350)</option>
                                                <option data-countryCode="GR" value="30">Greece (+30)</option>
                                                <option data-countryCode="GL" value="299">Greenland (+299)</option>
                                                <option data-countryCode="GD" value="1473">Grenada (+1473)</option>
                                                <option data-countryCode="GP" value="590">Guadeloupe (+590)</option>
                                                <option data-countryCode="GU" value="671">Guam (+671)</option>
                                                <option data-countryCode="GT" value="502">Guatemala (+502)</option>
                                                <option data-countryCode="GN" value="224">Guinea (+224)</option>
                                                <option data-countryCode="GW" value="245">Guinea - Bissau (+245)</option>
                                                <option data-countryCode="GY" value="592">Guyana (+592)</option>
                                                <option data-countryCode="HT" value="509">Haiti (+509)</option>
                                                <option data-countryCode="HN" value="504">Honduras (+504)</option>
                                                <option data-countryCode="HK" value="852">Hong Kong (+852)</option>
                                                <option data-countryCode="HU" value="36">Hungary (+36)</option>
                                                <option data-countryCode="IS" value="354">Iceland (+354)</option>
                                                <option data-countryCode="IN" value="91">India (+91)</option>
                                                <option data-countryCode="ID" value="62">Indonesia (+62)</option>
                                                <option data-countryCode="IR" value="98">Iran (+98)</option>
                                                <option data-countryCode="IQ" value="964">Iraq (+964)</option>
                                                <option data-countryCode="IE" value="353">Ireland (+353)</option>
                                                <option data-countryCode="IL" value="972">Israel (+972)</option>
                                                <option data-countryCode="IT" value="39">Italy (+39)</option>
                                                <option data-countryCode="JM" value="1876">Jamaica (+1876)</option>
                                                <option data-countryCode="JP" value="81">Japan (+81)</option>
                                                <option data-countryCode="JO" value="962">Jordan (+962)</option>
                                                <option data-countryCode="KZ" value="7">Kazakhstan (+7)</option>
                                                <option data-countryCode="KE" value="254">Kenya (+254)</option>
                                                <option data-countryCode="KI" value="686">Kiribati (+686)</option>
                                                <option data-countryCode="KP" value="850">Korea North (+850)</option>
                                                <option data-countryCode="KR" value="82">Korea South (+82)</option>
                                                <option data-countryCode="KW" value="965">Kuwait (+965)</option>
                                                <option data-countryCode="KG" value="996">Kyrgyzstan (+996)</option>
                                                <option data-countryCode="LA" value="856">Laos (+856)</option>
                                                <option data-countryCode="LV" value="371">Latvia (+371)</option>
                                                <option data-countryCode="LB" value="961">Lebanon (+961)</option>
                                                <option data-countryCode="LS" value="266">Lesotho (+266)</option>
                                                <option data-countryCode="LR" value="231">Liberia (+231)</option>
                                                <option data-countryCode="LY" value="218">Libya (+218)</option>
                                                <option data-countryCode="LI" value="417">Liechtenstein (+417)</option>
                                                <option data-countryCode="LT" value="370">Lithuania (+370)</option>
                                                <option data-countryCode="LU" value="352">Luxembourg (+352)</option>
                                                <option data-countryCode="MO" value="853">Macao (+853)</option>
                                                <option data-countryCode="MK" value="389">Macedonia (+389)</option>
                                                <option data-countryCode="MG" value="261">Madagascar (+261)</option>
                                                <option data-countryCode="MW" value="265">Malawi (+265)</option>
                                                <option data-countryCode="MY" value="60">Malaysia (+60)</option>
                                                <option data-countryCode="MV" value="960">Maldives (+960)</option>
                                                <option data-countryCode="ML" value="223">Mali (+223)</option>
                                                <option data-countryCode="MT" value="356">Malta (+356)</option>
                                                <option data-countryCode="MH" value="692">Marshall Islands (+692)</option>
                                                <option data-countryCode="MQ" value="596">Martinique (+596)</option>
                                                <option data-countryCode="MR" value="222">Mauritania (+222)</option>
                                                <option data-countryCode="YT" value="269">Mayotte (+269)</option>
                                                <option data-countryCode="MX" value="52">Mexico (+52)</option>
                                                <option data-countryCode="FM" value="691">Micronesia (+691)</option>
                                                <option data-countryCode="MD" value="373">Moldova (+373)</option>
                                                <option data-countryCode="MC" value="377">Monaco (+377)</option>
                                                <option data-countryCode="MN" value="976">Mongolia (+976)</option>
                                                <option data-countryCode="MS" value="1664">Montserrat (+1664)</option>
                                                <option data-countryCode="MA" value="212">Morocco (+212)</option>
                                                <option data-countryCode="MZ" value="258">Mozambique (+258)</option>
                                                <option data-countryCode="MN" value="95">Myanmar (+95)</option>
                                                <option data-countryCode="NA" value="264">Namibia (+264)</option>
                                                <option data-countryCode="NR" value="674">Nauru (+674)</option>
                                                <option data-countryCode="NP" value="977">Nepal (+977)</option>
                                                <option data-countryCode="NL" value="31">Netherlands (+31)</option>
                                                <option data-countryCode="NC" value="687">New Caledonia (+687)</option>
                                                <option data-countryCode="NZ" value="64">New Zealand (+64)</option>
                                                <option data-countryCode="NI" value="505">Nicaragua (+505)</option>
                                                <option data-countryCode="NE" value="227">Niger (+227)</option>
                                                <option data-countryCode="NG" value="234">Nigeria (+234)</option>
                                                <option data-countryCode="NU" value="683">Niue (+683)</option>
                                                <option data-countryCode="NF" value="672">Norfolk Islands (+672)</option>
                                                <option data-countryCode="NP" value="670">Northern Marianas (+670)</option>
                                                <option data-countryCode="NO" value="47">Norway (+47)</option>
                                                <option data-countryCode="OM" value="968">Oman (+968)</option>
                                                <option data-countryCode="PK" value="92">Pakistan (+92)</option>
                                                <option data-countryCode="PW" value="680">Palau (+680)</option>
                                                <option data-countryCode="PS" value="970">Palestinian Territory, Occupied (+970)</option>
                                                <option data-countryCode="PA" value="507">Panama (+507)</option>
                                                <option data-countryCode="PG" value="675">Papua New Guinea (+675)</option>
                                                <option data-countryCode="PY" value="595">Paraguay (+595)</option>
                                                <option data-countryCode="PE" value="51">Peru (+51)</option>
                                                <option data-countryCode="PH" value="63">Philippines (+63)</option>
                                                <option data-countryCode="PL" value="48">Poland (+48)</option>
                                                <option data-countryCode="PT" value="351">Portugal (+351)</option>
                                                <option data-countryCode="PR" value="1787">Puerto Rico (+1787)</option>
                                                <option data-countryCode="QA" value="974">Qatar (+974)</option>
                                                <option data-countryCode="RE" value="262">Reunion (+262)</option>
                                                <option data-countryCode="RO" value="40">Romania (+40)</option>
                                                <option data-countryCode="RU" value="7">Russia (+7)</option>
                                                <option data-countryCode="RW" value="250">Rwanda (+250)</option>
                                                <option data-countryCode="SM" value="378">San Marino (+378)</option>
                                                <option data-countryCode="ST" value="239">Sao Tome &amp; Principe (+239)</option>
                                                <option data-countryCode="SA" value="966" selected>Saudi Arabia (+966)</option>
                                                <option data-countryCode="SN" value="221">Senegal (+221)</option>
                                                <option data-countryCode="CS" value="381">Serbia (+381)</option>
                                                <option data-countryCode="SC" value="248">Seychelles (+248)</option>
                                                <option data-countryCode="SL" value="232">Sierra Leone (+232)</option>
                                                <option data-countryCode="SG" value="65">Singapore (+65)</option>
                                                <option data-countryCode="SK" value="421">Slovak Republic (+421)</option>
                                                <option data-countryCode="SI" value="386">Slovenia (+386)</option>
                                                <option data-countryCode="SB" value="677">Solomon Islands (+677)</option>
                                                <option data-countryCode="SO" value="252">Somalia (+252)</option>
                                                <option data-countryCode="ZA" value="27">South Africa (+27)</option>
                                                <option data-countryCode="ES" value="34">Spain (+34)</option>
                                                <option data-countryCode="LK" value="94">Sri Lanka (+94)</option>
                                                <option data-countryCode="SH" value="290">St. Helena (+290)</option>
                                                <option data-countryCode="KN" value="1869">St. Kitts (+1869)</option>
                                                <option data-countryCode="SC" value="1758">St. Lucia (+1758)</option>
                                                <option data-countryCode="SD" value="249">Sudan (+249)</option>
                                                <option data-countryCode="SR" value="597">Suriname (+597)</option>
                                                <option data-countryCode="SZ" value="268">Swaziland (+268)</option>
                                                <option data-countryCode="SE" value="46">Sweden (+46)</option>
                                                <option data-countryCode="CH" value="41">Switzerland (+41)</option>
                                                <option data-countryCode="SI" value="963">Syria (+963)</option>
                                                <option data-countryCode="TW" value="886">Taiwan (+886)</option>
                                                <option data-countryCode="TJ" value="7">Tajikstan (+7)</option>
                                                <option data-countryCode="TH" value="66">Thailand (+66)</option>
                                                <option data-countryCode="TG" value="228">Togo (+228)</option>
                                                <option data-countryCode="TO" value="676">Tonga (+676)</option>
                                                <option data-countryCode="TT" value="1868">Trinidad &amp; Tobago (+1868)</option>
                                                <option data-countryCode="TN" value="216">Tunisia (+216)</option>
                                                <option data-countryCode="TR" value="90">Turkey (+90)</option>
                                                <option data-countryCode="TM" value="7">Turkmenistan (+7)</option>
                                                <option data-countryCode="TM" value="993">Turkmenistan (+993)</option>
                                                <option data-countryCode="TC" value="1649">Turks &amp; Caicos Islands (+1649)</option>
                                                <option data-countryCode="TV" value="688">Tuvalu (+688)</option>
                                                <option data-countryCode="UG" value="256">Uganda (+256)</option>
                                                <option data-countryCode="GB" value="44">UK (+44)</option>
                                                <option data-countryCode="UA" value="380">Ukraine (+380)</option>
                                                <option data-countryCode="AE" value="971">United Arab Emirates (+971)</option>
                                                <option data-countryCode="UY" value="598">Uruguay (+598)</option>
                                                <option data-countryCode="US" value="1">USA & Canada(+1)</option>
                                                <option data-countryCode="UZ" value="7">Uzbekistan (+7)</option>
                                                <option data-countryCode="VU" value="678">Vanuatu (+678)</option>
                                                <option data-countryCode="VA" value="379">Vatican City (+379)</option>
                                                <option data-countryCode="VE" value="58">Venezuela (+58)</option>
                                                <option data-countryCode="VN" value="84">Vietnam (+84)</option>
                                                <option data-countryCode="VG" value="84">Virgin Islands - British (+1284)</option>
                                                <option data-countryCode="VI" value="84">Virgin Islands - US (+1340)</option>
                                                <option data-countryCode="WF" value="681">Wallis &amp; Futuna (+681)</option>
                                                <option data-countryCode="YE" value="969">Yemen (North)(+969)</option>
                                                <option data-countryCode="YE" value="967">Yemen (South)(+967)</option>
                                                <option data-countryCode="ZM" value="260">Zambia (+260)</option>
                                                <option data-countryCode="ZW" value="263">Zimbabwe (+263)</option>

                                            </select>
                                            <input type="text" name="hiwhats_signupMobileInput" id="hiwhats_signupMobileInput" class="form-control" placeholder="رقم الموبايل,مثال: 56751982" dir="ltr">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="password" name="hiwhats_signupPasswordInput" id="hiwhats_signupPasswordInput" class="form-control" placeholder="كلمة المرور, تسعة محارف على الاقل">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="password" name="hiwhats_signupConfirmPasswordInput" id="hiwhats_signupConfirmPasswordInput" class="form-control" placeholder="تأكيد كلمة المرور">
                                        </div>
                                    </div>
                                </div>

                                <label class="col-md-12" style="font-size:12px;color:red">
                                    بتسجيلك بالموقع فأنك توافق على <a target="_blank" href="https://hiwhats.com/page/PrivacyPolicy">اتفاقية الاستخدام</a>
                                </label>
                                <div class="form-group pt-3">
                                    <button class="bbtn bbtn-primary bbtn-sm bbtn-block" id="hiwhats_signupBtn">سجلني بالموقع</button>
                                </div>

                                <div class="row pt-3">
                                    <div class="col-md-12">
                                        <div class="form-group" style="text-align:right;font-size:11px;">
                                            *جميع الحقول مطلوبة
                                        </div>
                                    </div>
                                </div>

                                <br><br>


                            </div>

                        </div>

                    </div>
                    <!-- hiwhats_signupUser -->


                    <!-- activateUser -->
                    <div class="tab-pane" id="activateUser" role="tabpanel" aria-labelledby="activateUser-tab">

                        <div class="col-xs-12">
                            <br>
                            <div class="alert alert-success" role="alert" id="hiwhats_activateSuccessMsg" style="display:none;">تم تفعيل حسابكم بنجاح</div>
                            <div class="alert alert-danger" role="alert" id="hiwhats_activateFailedMsg" style="display:none;">حسابك مفعل مسبقاً أو ان كود التفعيل غير صحيح</div>
                            <div id="hiwhats_signinPhoneNumberDiv">
                                <div class="form-group">
                                    <span class="title">كود التفعيل:</span>
                                    <input type="text" class="form-control" id="hiwhats_activateCodeInput" dir="ltr">
                                </div>

                                <div class="form-group pt-3">
                                    <button class="bbtn bbtn-primary bbtn-sm get-started" id="hiwhats_activateBtn">تفعيل</button>
                                </div>


                                <br><br>
                            </div>

                        </div>

                    </div>
                    <!-- activateUser -->

                </div>
            </div>
        </div>


        <div class="row" id="hiwhats_usercp" style="display:none;">
            <div class="col-md-3 pt-3 pr-0 pl-0 sideNavbar">
                <ul class="nav flex-column nav-tabs" id="v-pills-tab1" role="tablist" aria-orientation="vertical">
                    <li class="nav-item">
                        <a class="nav-link pt-3 pb-3 active" id="hiwhats_home-tab" data-toggle="tab" href="#hiwhats_home" role="tab" aria-controls="home" aria-selected="true">
                            الارسال</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link pt-3 pb-3" id="hiwhats_groups-tab" data-toggle="tab" href="#hiwhats_groups" role="tab" aria-controls="groups" aria-selected="false">
                            المجموعات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link pt-3 pb-3" id="hiwhats_blocks-tab" data-toggle="tab" href="#hiwhats_blocks" role="tab" aria-controls="blocks" aria-selected="false">
                            قائمة التجاهل</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="hiwhats_tools-tab" data-toggle="tab" href="#hiwhats_tools" role="tab" aria-controls="hiwhats_tools" aria-selected="false">أدوات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link pt-3 pb-3" id="hiwhats_contact-tab" data-toggle="tab" href="#hiwhats_contact" role="tab" aria-controls="contact" aria-selected="false">
                            تواصل معنا</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link pt-3 pb-3" id="hiwhats_logOutBtn" style="cursor: pointer; ">خروج</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-9 p-0">
                <div class="tab-content p-3" id="hiwhats_myTabContent">
                    <div class="tab-pane show active" id="hiwhats_home" role="tabpanel" aria-labelledby="hiwhats_home-tab">

                        <h4>مرحباً بك: <span id="hiwhats_ucp_fullname">محمد</span></h4>
                        <ul class="breadcrumb" style="margin-top:8px">
                            <li class="breadcrumb-item" style="padding:0px">نوع الاشتراك: <span id="hiwhats_ucp_kind">0</span></li>
                            <li class="breadcrumb-item" style="padding:0px">تاريخ الانتهاء: <span id="hiwhats_ucp_exp">0</span></li>
                        </ul>

                        <span class="title">نص الرسالة:</span>
                        <div class="dropdown pull-left" style="text-align:left;">
                            <button class="bbtn bbtn-secondary bbtn-sm dropdown-toggle fs-11" type="button" id="hiwhats_dropdownVarButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                ادراج المتغيرات
                            </button>
                            <div class="dropdown-menu" aria-labelledby="hiwhats_dropdownVarButton">
                                <a class="dropdown-item text-right hiwhats_msgVars" href="#" data-id="A">[A]</a>
                                <a class="dropdown-item text-right hiwhats_msgVars" href="#" data-id="B">[B]</a>
                                <a class="dropdown-item text-right hiwhats_msgVars" href="#" data-id="C">[C]</a>
                                <a class="dropdown-item text-right hiwhats_msgVars" href="#" data-id="D">[D]</a>
                                <a class="dropdown-item text-right hiwhats_msgVars" href="#" data-id="E">[E]</a>
                                <a class="dropdown-item text-right hiwhats_msgVars" href="#" data-id="time">[time]</a>
                                <a class="dropdown-item text-right hiwhats_msgVars" href="#" data-id="date">[date]</a>
                            </div>
                        </div>
                        <textarea class="hiwhats_textarea copyable-text selectable-text" id="hiwhats_text_message" title="use [A] to put A" placeholder="Hi [A],
        This is your invoice number [B].
        [time]-[date]" rows="4"></textarea>
                        <span id="hiwhats_appx11" style="display:none">rn</span>


                        <span class="title">خيارات الارسال:</span>


                        <div class="card">

                            <div class="card-body p-2">


                                <div class="dropdown pull-left" style="text-align:left;">
                                    <button class="bbtn bbtn-secondary bbtn-sm dropdown-toggle fs-11" type="button" id="hiwhats_dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        ادراج ارقام
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="hiwhats_dropdownMenuButton">
                                        <a class="dropdown-item text-right" href="#" id="hiwhats_uploadCSV">من ملف csv</a>
                                        <a class="dropdown-item text-right" href="#" id="hiwhats_uploadXLS">من ملف اكسل</a>
                                        <a class="dropdown-item text-right" href="#" id="hiwhats_groupBtn" data-toggle="modal" data-target="#hiwhats_myGroupModal">من مجموعة</a>
                                        <a class="dropdown-item text-right" href="#" id="contactsBtn">من جهات الاتصال</a>
                                    </div>
                                </div>

                                <input style="display: none;" type="file" id="hiwhats_csvFileInput" accept=".csv">
                                <input style="display: none;" type="file" id="hiwhats_xlsFileInput" accept=".xlsx">

                                <textarea class="hiwhats_textarea copyable-text selectable-text" dir="ltr" id="hiwhats_text_contacts" title="no need [] in var ex: 966554433221,Alex" placeholder="966554433221,A,B,C,D,E" rows="4"></textarea>

                                <div class="form-group" style="display:none;">
                                    <p class="hiwhats_num_count">اجمالي الأرقام: <span id="hiwhats_num_count">0</span></p>
                                </div>



                                <div class="row">
                                    <div class="col-sm-12">


                                        <span class="title"><input type="checkbox" style="" id="hiwhats_s_img" class="" name="hiwhats_s_img" value="getImg" capt-id="capt" title="send with image and caption"> ارفاق ملف:
                                            <span class="pull-left">
                                                <input type="file" accept="image/*,video/*,audio/*,.pdf,.zip,.xlsx,.docx,.txt," id="hiwhats_getImgs" name="images" multiple="multiple" style="display: none; width:220px;cursor:pointer;">
                                                <a class="bbtn bbtn-secondary bbtn-sm fs-11" style="padding:1px" id="hiwhats_uploadFile">ادرج ملف</a>
                                            </span>
                                        </span>
                                        <div class="card  pb-1">
                                            <div class="card-body p-0">

                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-10">
                                                        <div id="i_img">
                                                            <div id="hiwhats_del" data-icon="close" class="img icon icon-del" data-value="hiwhats_getImgs" title="Delete Image" style="float:right;cursor:pointer;display:none">
                                                                <svg width="20" height="20" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg">
                                                                    <path opacity=".4" d="M1490 1322q0 40-28 68l-136 136q-28 28-68 28t-68-28l-294-294-294 294q-28 28-68 28t-68-28l-136-136q-28-28-28-68t28-68l294-294-294-294q-28-28-28-68t28-68l136-136q28-28 68-28t68 28l294 294 294-294q28-28 68-28t68 28l136 136q28 28 28 68t-28 68l-294 294 294 294q28 28 28 68z">
                                                                    </path>
                                                                </svg>
                                                            </div>
                                                            <div class="c_imgs">
                                                                <img id="hiwhats_PreviewImg" style="" class="img-fluid" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <textarea style="display:none;" id="capt" class="caption hiwhats_textarea copyable-text selectable-text" rows="6" placeholder="caption..."></textarea>
                                                    </div>

                                                </div>


                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-12">

                                        <div class="card p-1 mt-2">
                                            <div class="row" dir="rtl">
                                                <div class="col-md-12">
                                                <span class="title_ fw-bold">الزمن بين الرسائل:</span>
                                                    <span>من :
                                                        <input type="text" id="hiwhats_dly_wa" placeholder="2" title="interval in second" minlength="1" maxlength="3" size="1">
                                                    </span>
                                                    <span class="pt-1">الى :
                                                        <input type="text" id="hiwhats_dly_wa2" placeholder="5" title="interval in second" minlength="1" maxlength="3" size="1">
                                                    </span>
                                                </div>
                                                <!-- -->
                                                <div class="col-md-12 columnOpt_" style="">
                                                    <input type="checkbox" id="hiwhats_s_tdy" class="" name="hiwhats_s_tdy" capt-id="capt" title="تجاهل الرسائل المرسلة هذا اليوم">
                                                    تجاهل اليوم
                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                </div>


                                <div class="row rowOpt_">
                                    <div class="col-md-12">
                                        <hr>
                                        <span id="hiwhats_app" style="display:none">6203</span>
                                        <span id="hiwhats_wa_count" style="">0</span>
                                        <button id="hiwhats_insert_wa" class="bbtn bbtn-success bbtn-sm bbtn-success-colored" style="display:none" title="تجهيز قائمة الارسال">تجهيز</button>
                                        <button id="hiwhats_BtnSend" class="bbtn bbtn-success bbtn-sm bbtn-success-colored" title="ارسل مع الفواصل الزمنية">ارسال</button>
                                        <button id="hiwhats_BtnStop" class="bbtn bbtn-success bbtn-sm bbtn-danger" title="ايقاف" disabled>ايقاف</button>

                                        <button type="button" class="bbtn bbtn-primary bbtn-sm" data-toggle="modal" data-target="#hiwhats_reportModal"> تقارير الارسال</button>
                                    </div>
                                </div>


                            </div>
                        </div>










                    </div><!-- END tab-pane home-->




                    <div class="tab-pane" id="hiwhats_groups" role="tabpanel" aria-labelledby="hiwhats_groups-tab">

                        <div class="container-fluid mt-3">
                            <p class="p-2">الرجاء الاختيار:</p>
                            <div class="alert alert-danger" role="alert" id="hiwhats_groupsFailedMsg"></div>
                            <div class="alert alert-success" role="alert" id="hiwhats_groupsSuccessMsg">تمت العملية بنجاح</div>




                            <div id="hiwhats_groupsAccordion">

                                <div class="card">
                                    <div class="card-header p-0" id="hiwhats_headingOne">
                                        <a class="bbtn bbtn-link bbtn-sm " data-toggle="collapse" data-target="#hiwhats_collapseOne" aria-expanded="true" aria-controls="hiwhats_collapseOne">
                                            اضافة مجموعة جديدة
                                        </a>
                                    </div>
                                    <div id="hiwhats_collapseOne" class="collapse show" aria-labelledby="hiwhats_headingOne" data-parent="#hiwhats_groupsAccordion">
                                        <div class="card-body p-1">
                                            <div class="row" id="hiwhats_groupAddDiv">
                                                <div class="col-md-12">
                                                    <p class="p-2">اسم المجموعة:</p>
                                                    <input type="text" id="hiwhats_groupAddInput" class="form-control" placeholder="">
                                                </div>
                                                <div class="col-md-12">
                                                    <label>&nbsp;</label>
                                                    <button class="bbtn bbtn-success bbtn-sm bbtn-block" id="hiwhats_groupAddBtn">اضافة</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="card">
                                    <div class="card-header p-0" id="hiwhats_headingTwo">
                                        <a class="bbtn bbtn-link bbtn-sm collapsed" data-toggle="collapse" data-target="#hiwhats_collapseTwo" aria-expanded="false" aria-controls="hiwhats_collapseTwo">
                                            حذف مجموعة
                                        </a>
                                    </div>
                                    <div id="hiwhats_collapseTwo" class="collapse" aria-labelledby="hiwhats_headingTwo" data-parent="#hiwhats_groupsAccordion">
                                        <div class="card-body p-1">
                                            <div class="row" id="hiwhats_groupDeleteDiv">
                                                <div class="col-md-12">
                                                    <p class="p-2">اسم المجموعة:</p>
                                                    <select type="text" id="hiwhats_groupDeleteList" class="form-control input-field-name">
                                                    </select>
                                                </div>
                                                <div class="col-md-12">
                                                    <label>&nbsp;</label>
                                                    <button class="bbtn bbtn-danger bbtn-sm bbtn-block" id="hiwhats_groupDeleteBtn">حذف</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="card">
                                    <div class="card-header p-0" id="hiwhats_headingThree">
                                        <a class="bbtn bbtn-link bbtn-sm collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            اضافة ارقام لمجموعة
                                        </a>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="hiwhats_headingThree" data-parent="#hiwhats_groupsAccordion">
                                        <div class="card-body p-1">
                                            <div class="row" id="hiwhats_groupAddNumberDiv">
                                                <div class="col-md-12">
                                                    <p class="p-2">اسم المجموعة:</p>
                                                    <select type="text" id="hiwhats_groupAddNumberList" class="form-control">
                                                    </select>
                                                    <p class="p-2">الأرقام:</p>
                                                    <textarea id="hiwhats_groupAddNumberInput" style="width:100%;" class="form-control" rows="3" placeholder="Please paste the numbers like this 
  966532594583
  966532594583"></textarea>

                                                </div>
                                                <div class="col-md-12">
                                                    <label>&nbsp;</label>
                                                    <button class="bbtn bbtn-success bbtn-sm bbtn-block" id="hiwhats_groupAddNumberBtn">اضافة الارقام</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <!--/panel-group-->



                        </div>

                    </div><!-- END tab-pane groups-->





                    <div class="tab-pane" id="hiwhats_blocks" role="tabpanel" aria-labelledby="hiwhats_blocks-tab">

                        <div class="container-fluid mt-3" style="overflow:scroll; height:390px;">

                            <h2>قائمة الأرقام المحظورة من الارسال</h2>
                            <br>

                            <div class="row">
                                <div class="col-md-12">
                                    <p class="p-2">الأرقام:</p>

                                    <div class="alert alert-success" role="alert" id="hiwhats_blocksSuccessMsg">تمت العملية بنجاح</div>


                                    <textarea id="hiwhats_BlocksNumbersInput" style="width:100%;" class="form-control" rows="8" placeholder="Please paste the numbers like this 
  966532594583
  966532594583"></textarea>

                                </div>
                                <div class="col-md-12">
                                    <label>&nbsp;</label>
                                    <button class="bbtn bbtn-success bbtn-sm bbtn-block" id="hiwhats_AddBlockesNumbersBtn">اضافة الارقام</button>
                                </div>
                            </div>

                        </div>

                    </div><!-- END tab-pane blocks-->



                    <div class="tab-pane" id="hiwhats_tools" role="tabpanel" aria-labelledby="hiwhats_tools-tab">
                        <div class="container-fluid text-center mt-3">
                            
                            <div class="row">
                                <div class="col-md-12 pb-2">
                                    <div class="card">
                                        <div class="card-body p-2">
                                        <p class="p-2">تصدير أرقام المحادثات:</p>
                                                    <button class="bbtn bbtn-success bbtn-sm bbtn-block" id="hiwhats_ExportChatNumbersBtn">تصدير </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 pb-2">
                                    <div class="card">
                                        <div class="card-body p-2">
                                        <p class="p-2">تصدير  جهات الاتصال:</p>
                                        <button class="bbtn bbtn-success bbtn-sm bbtn-block" id="hiwhats_ExportContactNumbersBtn">تصدير </button>
                                        </div>
                                    </div>              
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12 pb-2">
                                    <div class="card">
                                        <div class="card-body p-2">
                                        <p class="p-2">تصدير أرقام مجموعة:</p>
                                        <select class="form-control mb-2" id="hiwhats_ExportGroupNumbersList"></select>
                                        <button class="bbtn bbtn-success bbtn-sm bbtn-block" id="hiwhats_ExportGroupNumbersBtn">تصدير </button>
                                        </div>
                                    </div>              
                                </div>
                            </div>

                        </div>
                    </div>
                    <!-- END tab-pane tools-->




                    <div class="tab-pane" id="hiwhats_contact" role="tabpanel" aria-labelledby="hiwhats_contact-tab">

                        <div class="container-fluid text-center mt-3">

                            <h3>مؤسسة أفكار جديدة للاتصالات وتقنية المعلومات</h3>
                            <h5></h5>

                            <img src="https://hiwhats.com/afkar.png">


                            <h4><b>عن الشركة </b></h4>
                            <p>
                                تأسست مؤسسة أفكار جديدة للاتصالات وتقنية المعلومات ومقرها المملكة العربية السعودية، الرياض، عام 1990 علي يد مجموعة من المهندسين استجابة للنمو التجاري المتزايد والذي بدوره يتطلب الخدمات البرمجية الفعالة ذات التكلفة المناسبة والجديرة بالثقة. فقد تعهدوا بتقديم المنتجات التي من شأنها مساعدة الشركات في تحسين أعمالها التجارية في الشرق الأوسط. يرأس الشركة واحدا من الاستشاريين البارزين في مجال المعلوماتية يحظى بخبرة تزيد على 35 عاما في مجال تقنية المعلومات، ويدعمه مجموعة من المدراء المؤهلين في التطبيقات والأعمال التجارية. ومن ورائهم قسم التطبيقات البرمجية والأعمال التجارية ذوي الخبرة الفنية في المجالات المختصة
                            </p>

                            <h4><b>رؤية الشركة</b></h4>
                            <p>
                                تقديم الحلول الالكترونية إلى عملائنا والتي من شأنها إضافة القيم الفعالة إلى أعمالهم وخلق بيئة عمل متكاملة لتسهيل اجراءات العمل. كما تضع الشركة نصب أعينها خطوة تحويل كافة أنظمتها سواء كانت في مجال الرعاية الصحية أو في المجالات المختلفة الأخرى الي البيئة السحابية Clouding هادفين إلى توفير أعلي معايير الكفاءة في العمل.
                            </p>

                            <h4><b>مهمة الشركة</b></h4>
                            <p>
                                “مهمتنا هي أن نصبح شركة عالمية رائدة في تقديم الحلول المعلوماتية”. تسعي مؤسسة أفكار جديدة للاتصالات وتقنية المعلومات إلى تقديم الخدمات الفعالة في كافة حلولها البرمجية”. التزمنا بأن نقدم رؤيتنا وحلولنا ومقترحاتنا بالإضافة إلى تطوير وتكامل الحلول البرمجية النهائية لعملائنا، باستخدام خبراتنا المكتسبة اعتمادا على التجربة والدراية في تنفيذ وتطبيق برامج الحاسوب المختلفة
                            </p>

                            <p style="padding:20px;margin:20px 20px 20px 30px;">
                                <a href="" class="pull-left" style="direction:ltr;">Telephone<br> 966(50)9994854</a>
                                <a href="" class="pull-right" style="direction:ltr;">E-mail<br> sales@hiwhats.com</a>
                            </p>



                        </div>

                    </div><!-- END tab-pane contact-->



                </div><!-- END hiwhats_myTabContent -->

            </div>
        </div>

    </div><!-- END hiwhats_container -->

    <div class="container-fluid footer">
        <div class="row" style="text-align:center;border-top:solid 2px #2A2A2A;padding:4px 0 4px 0;">
            <ul id="horizontal-list">
                <li class="p-3"><a target="_blank" href="https://hiwhats.com/blog/articles/2" alt="مساعدة" title="مساعدة"><svg class="svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                            <path d="M256 0C114.6 0 0 114.6 0 256s114.6 256 256 256s256-114.6 256-256S397.4 0 256 0zM256 400c-18 0-32-14-32-32s13.1-32 32-32c17.1 0 32 14 32 32S273.1 400 256 400zM325.1 258L280 286V288c0 13-11 24-24 24S232 301 232 288V272c0-8 4-16 12-21l57-34C308 213 312 206 312 198C312 186 301.1 176 289.1 176h-51.1C225.1 176 216 186 216 198c0 13-11 24-24 24s-24-11-24-24C168 159 199 128 237.1 128h51.1C329 128 360 159 360 198C360 222 347 245 325.1 258z" />
                        </svg></a></li>
                <li class="p-3"><a target="_blank" href="https://hiwhats.com/" alt="الموقع الالكتروني" title="الموقع الالكتروني"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                            <path
                                d="M512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256C0 114.6 114.6 0 256 0C397.4 0 512 114.6 512 256zM177.8 63.19L187.8 80.62C190.5 85.46 192 90.93 192 96.5V137.9C192 141.8 193.6 145.6 196.3 148.3C202.6 154.6 212.8 153.1 218.3 147.1L231.9 130.1C236.6 124.2 244.8 122.4 251.6 125.8L266.8 133.4C270.2 135.1 273.1 136 277.8 136C284.3 136 290.6 133.4 295.2 128.8L299.1 124.9C302 121.1 306.5 121.2 310.1 123.1L339.4 137.7C347.1 141.6 352 149.5 352 158.1C352 168.6 344.9 177.8 334.7 180.3L299.3 189.2C291.9 191 284.2 190.7 276.1 188.3L244.1 177.7C241.7 176.6 238.2 176 234.8 176C227.8 176 220.1 178.3 215.4 182.5L176 212C165.9 219.6 160 231.4 160 244V272C160 298.5 181.5 320 208 320H240C248.8 320 256 327.2 256 336V384C256 401.7 270.3 416 288 416C298.1 416 307.6 411.3 313.6 403.2L339.2 369.1C347.5 357.1 352 344.5 352 330.7V318.6C352 314.7 354.6 311.3 358.4 310.4L363.7 309.1C375.6 306.1 384 295.4 384 283.1C384 275.1 381.2 269.2 376.2 264.2L342.7 230.7C338.1 226.1 338.1 221 342.7 217.3C348.4 211.6 356.8 209.6 364.5 212.2L378.6 216.9C390.9 220.1 404.3 215.4 410.1 203.8C413.6 196.8 421.3 193.1 428.1 194.6L456.4 200.1C431.1 112.4 351.5 48 256 48C228.3 48 201.1 53.4 177.8 63.19L177.8 63.19z" />
                        </svg></a></li>
                <li class="p-3"><a target="_blank" href="https://hiwhats.com/Packages" alt="الاسعار" title="الاسعار"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                            <path d="M472.8 168.4C525.1 221.4 525.1 306.6 472.8 359.6L360.8 472.9C351.5 482.3 336.3 482.4 326.9 473.1C317.4 463.8 317.4 448.6 326.7 439.1L438.6 325.9C472.5 291.6 472.5 236.4 438.6 202.1L310.9 72.87C301.5 63.44 301.6 48.25 311.1 38.93C320.5 29.61 335.7 29.7 344.1 39.13L472.8 168.4zM.0003 229.5V80C.0003 53.49 21.49 32 48 32H197.5C214.5 32 230.7 38.74 242.7 50.75L410.7 218.7C435.7 243.7 435.7 284.3 410.7 309.3L277.3 442.7C252.3 467.7 211.7 467.7 186.7 442.7L18.75 274.7C6.743 262.7 0 246.5 0 229.5L.0003 229.5zM112 112C94.33 112 80 126.3 80 144C80 161.7 94.33 176 112 176C129.7 176 144 161.7 144 144C144 126.3 129.7 112 112 112z" />
                        </svg></a></li>
                <li class="p-3"><a target="_blank" href="https://www.youtube.com/channel/UCJvGte1wqjkQ8hZbDyOmr4w" alt="دروس تعليمية" title="دروس تعليمية"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
                            <path
                                d="M386.539 111.485l15.096 248.955-10.979-.275c-36.232-.824-71.64 8.783-102.657 27.997-31.016-19.214-66.424-27.997-102.657-27.997-45.564 0-82.07 10.705-123.516 27.723L93.117 129.6c28.546-11.803 61.484-18.115 92.226-18.115 41.173 0 73.836 13.175 102.657 42.544 27.723-28.271 59.013-41.721 98.539-42.544zM569.07 448c-25.526 0-47.485-5.215-70.542-15.645-34.31-15.645-69.993-24.978-107.871-24.978-38.977 0-74.934 12.901-102.657 40.623-27.723-27.723-63.68-40.623-102.657-40.623-37.878 0-73.561 9.333-107.871 24.978C55.239 442.236 32.731 448 8.303 448H6.93L49.475 98.859C88.726 76.626 136.486 64 181.775 64 218.83 64 256.984 71.685 288 93.095 319.016 71.685 357.17 64 394.225 64c45.289 0 93.049 12.626 132.3 34.859L569.07 448zm-43.368-44.741l-34.036-280.246c-30.742-13.999-67.248-21.41-101.009-21.41-38.428 0-74.385 12.077-102.657 38.702-28.272-26.625-64.228-38.702-102.657-38.702-33.761 0-70.267 7.411-101.009 21.41L50.298 403.259c47.211-19.487 82.894-33.486 135.045-33.486 37.604 0 70.817 9.606 102.657 29.644 31.84-20.038 65.052-29.644 102.657-29.644 52.151 0 87.834 13.999 135.045 33.486z" />
                        </svg></a></li>
            </ul>
        </div>
        <div class="col text-center">
            <p class="pb-3" style="font-size:12px;color:red">Version: 3.3.5</p>
        </div>

    </div>


</div>







`);


}


document.body.insertBefore(iWA_container, document.body.childNodes[0]);
//document.body.insertBefore(iWA_container, document.getElementsByClassName("ldL67 _3sh5K")[4]);
/* End Of Script */



// Example POST method implementation:
function postData(url = '', data = {}) {
  // Default options are marked with *
  const response = fetch(url, {
    method: 'POST', // *GET, POST, PUT, DELETE, etc.
    mode: "no-cors", // no-cors, *cors, same-origin
    //cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
    credentials: 'same-origin', // include, *same-origin, omit
    headers: {
      'Content-Type': 'application/json'
      //'Content-Type': 'application/x-www-form-urlencoded',
    },
    redirect: 'follow', // manual, *follow, error
    referrerPolicy: 'no-referrer', // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
    //body: JSON.stringify(data) // body data type must match "Content-Type" header
    body: data // body data type must match "Content-Type" header
  });
  console.log("sasfafa" + JSON.stringify(data));
  //console.log(response.json());
  //return response.json(); // parses JSON response into native JavaScript objects
  return response; // parses JSON response into native JavaScript objects
}







//languages Objects
let arrLang = {
     en: {
  'login' : 'login',
  'new_user' : 'new_user',
  'forget_password' : 'forget_password'
     },

     ar: {
	  'login' : 'دخول',
	  'new_user' : 'new_user',
	  'forget_password' : 'forget_password',
	  'username':'اسم المستخدم',
	  'password':'كلمة المرور',
	  'signin':'تسجيل دخول',
	  'new_user':'مستخدم جديد ',
	  'activate_user':'تفعيل حساب ',
	  'forgot_password':'نسيت كلمة المرور',
	  'buy_package':'شراء باقة',
	  'hello':'مرحباً بك: ',
	  'message':'نص الرسالة:',
	  'insert_variables':'ادراج المتغيرات',
	  'sending_options':'خيارات الارسال:',
	  'insert_numbers':'ادراج ارقام',
	  'from_csv':'من ملف csv',
	  'from_excel':'من ملف اكسل',
	  'from_group':'من مجموعة',
	  'from_contacts':'من جهات الاتصال',
	  'add_file':'ارفاق ملف:',
	  'insert_file':'ادرج ملف',
	  'sending_interval':'الزمن بين الرسائل:',
	  'from':'من :',
	  'to':'الى :',
	  'send':'ارسال',
	  'send_with_interval':'ارسل مع الفواصل الزمنية',
	  'stop':'ايقاف',
	  'report':'تقارير الارسال',
	  'sending':'الارسال',
	  'groups':'المجموعات',
	  'ignore_list':'قائمة التجاهل',
	  'contact_us':'تواصل معنا',
	  'logout':'خروج',
	  'align_right':'محاذاة يمين',
	  'align_left':'محاذاة يسار',
	  'please_choose':'الرجاء الاختيار:',
	  'add_new_group':'اضافة مجموعة جديدة',
	  'group_name':'اسم المجموعة:',
	  'add':'اضافة',
	  'delete_group':'حذف مجموعة',
	  'delete':'حذف',
	  'add_numbers_to group':'اضافة ارقام لمجموعة',
	  'numbers':'الأرقام:',
	  'add_numbers':'اضافة الارقام',
	  'ignorance_list':'قائمة الأرقام المحظورة من الارسال',
	  'sending_result':'نتيجة الارسال',
	  'close':'اغلاق',
	  'name':'الاسم',
	  'email':'البريد الالكتروني',
	  'mobile_placeholder':'رقم الموبايل,مثال: 56751982',
	  'password_at_least_nine_chars':'كلمة المرور, تسعة محارف على الاقل',
	  'password_confirm':'تأكيد كلمة المرور',
	  'you_agree':'بتسجيلك بالموقع فأنك توافق على',
	  'terms':'اتفاقية الاستخدام',
	  'register_me':'سجلني بالموقع',
	  'all_fields_are_required':'*جميع الحقول مطلوبة',
	  'activation_code':'كود التفعيل:',
	  'activate':'تفعيل',
     }
 }


 let lang =localStorage.getItem('language');
 changeLanguage(lang);

$('.translate').click(function(){
	lang = $(this).attr('id');
	localStorage.setItem('language', lang);
	changeLanguage(lang);
	//alert(lang);
});

function changeLanguage(lang){
	$('.lang').each(function(index,element){
		//$(this).text(arrLang[lang][$(this).attr('key')]);
	}); 
}


