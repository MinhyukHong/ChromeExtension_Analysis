
//==========================================================================
// Copyright (c) Fabasoft R&D GmbH, A-4020 Linz, 1988-2023.
//
// Alle Rechte vorbehalten. Alle verwendeten Hard- und Softwarenamen sind
// Handelsnamen und/oder Marken der jeweiligen Hersteller.
//
// Der Nutzer des Computerprogramms anerkennt, dass der oben stehende
// Copyright-Vermerk im Sinn des Welturheberrechtsabkommens an der vom
// Urheber festgelegten Stelle in der Funktion des Computerprogramms
// angebracht bleibt, um den Vorbehalt des Urheberrechtes genuegend zum
// Ausdruck zu bringen. Dieser Urheberrechtsvermerk darf weder vom Kunden,
// Nutzer und/oder von Dritten entfernt, veraendert oder disloziert werden.
//==========================================================================

// console.log("register script execution start");

(function() {
  var script = document.currentScript;
  var dataset = script.dataset;
  var typesuffix = dataset.typesuffix;
  var url = dataset.url;
  // --
  var id = "nmext@fabasoft.com";
  var value = window[id];
  var disabled = true;
  if (!value) {
    value = window[id] = {};
  }
  if (!value["nmext" + typesuffix + "@fabasoft.com"] || value["nmext" + typesuffix + "@fabasoft.com"] === url) {
    value["nmext" + typesuffix + "@fabasoft.com"] = url;
    disabled = false;
  }
  // --
  dataset.result = disabled ? "disabled": "enabled";
})();

// console.log("register script execution done");