//==========================================================================
// Copyright (c) Fabasoft R&D GmbH, A-4020 Linz, 1988-2023.
//
// Alle Rechte vorbehalten. Alle verwendeten Hard- und Softwarenamen sind
// Handelsnamen und/oder Marken der jeweiligen Hersteller.
//
// Der Nutzer des Computerprogramms anerkennt, dass der oben stehende
// Copyright-Vermerk im Sinn des Welturheberrechtsabkommens an der vom
// Urheber festgelegten Stelle in der Funktion des Computerprogramms
// angebracht bleibt, um den Vorbehalt des Urheberrechtes genuegend zum
// Ausdruck zu bringen. Dieser Urheberrechtsvermerk darf weder vom Kunden,
// Nutzer und/oder von Dritten entfernt, veraendert oder disloziert werden.
//==========================================================================

// console.log("com.fabasoft.nm/pm21/nmext: nmext.js loading");
var ERRORCODE = {
  MSGSEND_EXTENSION_FORWARD_TO_EXT_BACK_FAILED: 2022
};
var connected = false;
var disabledchecked = false;
var portPromise;
var port;
var windoworigin;
var disabled = {};
var conflicts = {};
var typesuffixlist;
var typesuffix;
var connectionid = "nmext" + Math.floor(Math.random()*10000000000000000);
var connectionnumber = 0;
if ("pm21" === "pu") {
  typesuffixlist = ["pu"];
}
else {
  typesuffixlist = ["pu", "pm", "pm21"];
}
if (!window.cloneInto) {
  window.cloneInto = function(obj) {
    return obj;
  }
}
//
// connect to background page
//
function connect(errorondisconnectfun, typesuffix)
{
  var cn = ++connectionnumber;
  return new Promise((resolve, reject) => {
    port = null;
    try {
      // console.log("com.fabasoft.nm/pm21/nmext: Connecting to background page");
      port = chrome.runtime.connect({name: connectionid});
      connected = true;
      //
      // messages received from background page: forward to web site
      //
      if (port) {
        port.onMessage.addListener((data, sender) => {
          // console.log("com.fabasoft.nm/pm21/nmext: Extension received message from background page");
          // console.log(data);
          if (data && data.type === "com.fabasoft.nm.back.connect") {
            resolve();
          }
          else {
            try {
              if (windoworigin) {
                window.postMessage(data, windoworigin);
              }
              else {
                // console.log("com.fabasoft.nm/pm21/nmext: Extension content script: invalid window origin");
              }
              // --
              if (errorondisconnectfun) {
                // console.log("com.fabasoft.nm/pm21/nmext: clear error on disconnect as reply was given");
                port.onDisconnect.removeListener(errorondisconnectfun);
                errorondisconnectfun = null;
              }
            } catch (e) {
              // console.log("com.fabasoft.nm/pm21/nmext: Failed to forward received message to browser");
              // console.log(e);
            }
          }
        });
        port.onDisconnect.addListener(() => {
          if (connectionnumber === cn) {
            // console.log("com.fabasoft.nm/pm21/nmext: Currenct connection disconnected from background page");
            connected = false;
            reject();
          }
          else {
            // console.log("com.fabasoft.nm/pm21/nmext: Old connection disconnected from background page (ignore)");
          }
        });
        if (errorondisconnectfun) {
          port.onDisconnect.addListener(errorondisconnectfun);
        }
        try {
          port.postMessage({
            type: "com.fabasoft.nm.back.connect",
            typesuffix: typesuffix
          });
        } catch (e) {
          // console.log("com.fabasoft.nm/pm21/nmext: Failed to send connect message to browser extension background page");
          // console.log(e);
          connected = false;
          if (errorondisconnectfun) {
            errorondisconnectfun();
          }
          reject();
        }
      }
      else {
        // console.log("com.fabasoft.nm/pm21/nmext: Connecting to background page failed (chrome.runtime.connect returned null)");
        connected = false;
        if (errorondisconnectfun) {
          errorondisconnectfun();
        }
        reject();
      }
    } catch (e) {
      // console.log("com.fabasoft.nm/pm21/nmext: Connecting to background page failed");
      // console.log(e);
      connected = false;
      if (errorondisconnectfun) {
        errorondisconnectfun();
      }
      reject();
    }
  });
}
//
// register extension on web page
//
async function registertype(typesuffix, nonfabasoftonly)
{
  // console.log("com.fabasoft.nm/pm21/nmext: Register extension for " + typesuffix);
  try {
    var disabled = true;
    if (window.wrappedJSObject) {
      (function() {
        if (nonfabasoftonly && /.*\.fabasoft\.com/.test(new URL(this.location.href).hostname)) {
          // console.log("com.fabasoft.nm/pm21/nmext: Skip registering " + typesuffix + " on *.fabasoft.com domain");
          return;
        }
        var id="nmext@fabasoft.com";
        if (!this[id]) {
          this[id]=cloneInto({}, this);
        }
        var url = cloneInto(chrome.runtime.getURL("installed.js"), this);
        if (!this[id]["nmext" + typesuffix + "@fabasoft.com"] || this[id]["nmext" + typesuffix + "@fabasoft.com"] === url) {
          this[id]["nmext" + typesuffix + "@fabasoft.com"] = url;
          disabled = false;
        }
      }).call(window.wrappedJSObject);
      // console.log("com.fabasoft.nm/pm21/nmext: Extension is enabled for " + typesuffix + ": " + !disabled);
      return disabled;
    }
    else {
      if (nonfabasoftonly && /.*\.fabasoft\.com/.test(new URL(window.location.href).hostname)) {
        // console.log("com.fabasoft.nm/pm21/nmext: Skip registering " + typesuffix + " on *.fabasoft.com domain");
        return true;
      }
      return new Promise((resolve, reject) => {
        var id = "nmext@fabasoft.com";
        var script = document.createElement("SCRIPT");
        script.dataset.typesuffix = typesuffix;
        script.dataset.url = chrome.runtime.getURL("installed.js");
        script.src = chrome.runtime.getURL("register.js");
        script.onload = () => {
          // console.log("com.fabasoft.nm/pm21/nmext: Extension is enabled for " + typesuffix + ": " + (script.dataset.result === "enabled"));
          resolve(script.dataset.result !== "enabled");
          script.parentNode.removeChild(script);
        };
        script.onerror = (e) => {
          reject(e);
        }
        document.documentElement.appendChild(script);
      });
    }
  } catch (e) {
    // console.log("com.fabasoft.nm/pm21/nmext: Failed to register extension for " + typesuffix  + " in window");
    // console.log(e);
    return true;
  }
}
//
// messages received from web site: forward to background page
//
async function checkdisabled(typesuffix)
{
  var typesuffixcheck = typesuffix;
  var disable = false;
  if (typesuffix.substr(0, 2) === "pm" && !typesuffixlist.includes(typesuffix)) {
    typesuffixcheck = "pm";
  }
  if (!typesuffixlist.includes(typesuffixcheck)) {
    // console.log("com.fabasoft.nm/pm21/nmext: Message with type " + typesuffix + ": Extension not active for this type, remove event listener");
    return true;
  }
  if (disabled[typesuffixcheck]) {
    // console.log("com.fabasoft.nm/pm21/nmext: Message with type " + typesuffix + ": Extension is disabled for this type, remove event listener");
    return true;
  }
  if (["pm16", "pm17", "pm18", "pm19", "pm20"].includes(typesuffix)) {
    if (typeof conflicts[typesuffix] === "undefined") {
      conflicts[typesuffix] = await registertype(typesuffix);
      // console.log("com.fabasoft.nm/pm21/nmext: First message with type " + typesuffix + ": Conflict with other extension: " + conflicts[typesuffix]);
    }
    if (conflicts[typesuffix]) {
      // console.log("com.fabasoft.nm/pm21/nmext: Message with type " + typesuffix + ": Conflict with other extension, remove event listener");
      return true;
    }
  }
  return false;
}
//
// main entry point
//
async function run() {
  for (var ts of typesuffixlist) {
    disabled[ts] = await registertype(ts, "pm21" !== "pu" && ts === "pu");
  }
  if ("pm21" !== "pu" || !disabled["pu"]) {
    var el;
    window.addEventListener("message", el = async (event) => {
      if (event.source !== window) {
        return;
      }
      if (windoworigin && event.origin !== windoworigin) {
        return;
      }
      var data = event.data;
      var typeprefix = "com.fabasoft.nm.send";
      if (data.type && data.type.startsWith(typeprefix)) {
        if (true) {
          if (data.method === "Init" || data.performance) {
            if (!data.performance) {
              data.performance = cloneInto([], data);
            }
            data.performance.push(cloneInto({contentscript_enter: new Date()}, data));
          }
        }
        typesuffix = data.type.substr(typeprefix.length);
        if (!disabledchecked) {
          if (await checkdisabled(typesuffix)) {
            window.removeEventListener("message", el);
            return;
          }
          disabledchecked = true;
        }
      }
      else {
        return;
      }
      // --
      // console.log("com.fabasoft.nm/pm21/nmext: Extension content script: process message");
      // console.log(data);
      if (!windoworigin) {
        windoworigin = event.source.origin || event.source.location.origin;
        // console.log("com.fabasoft.nm/pm21/nmext: Extension content script initialize window origin: " + windoworigin);
      }
      try {
        if (!connected) {
          var errorondisconnectfun = () => {
            // console.log("com.fabasoft.nm/pm21/nmext: Disconnect from reconnected port: reply error");
            var response = {
              method: data.method,
              callid: data.callid,
              type: "com.fabasoft.nm.abort",
              outdata: null,
              faildata: {
                code: ERRORCODE.MSGSEND_EXTENSION_FORWARD_TO_EXT_BACK_FAILED,
                cause: "onDisconnect",
                request: data
              }
            };
            if (windoworigin) {
              window.postMessage(response, windoworigin);
            }
            else {
              // console.log("com.fabasoft.nm/pm21/nmext: Extension content script: invalid window origin");
            }
          };
          portPromise = connect(errorondisconnectfun, typesuffix);
        }
      } catch(e) {
        // console.log("com.fabasoft.nm/pm21/nmext: Extension content script exception");
        // console.log(e);
      }
      // --
      try {
        data.srcurl = event.source.location.href;
        data.typesuffix = typesuffix;
        await portPromise;
        if (true) {
          if (data.method === "Init" || data.performance) {
            data.performance.push(cloneInto({contentscript_leave: new Date()}, data));
          }
        }
        port.postMessage(data);
      } catch (e) {
        // console.log("com.fabasoft.nm/pm21/nmext: Failed to send message to browser extension background page");
        // console.log(e);
        connected = false;
        var response = {
          method: data.method,
          callid: data.callid,
          type: "com.fabasoft.nm.abort",
          outdata: null,
          faildata: {
            code: ERRORCODE.MSGSEND_EXTENSION_FORWARD_TO_EXT_BACK_FAILED,
            cause: e ? (e.stack ? e.stack.toString() : e.toString()) : null,
            request: data
          }
        };
        if (windoworigin) {
          window.postMessage(response, windoworigin);
        }
        else {
          // console.log("com.fabasoft.nm/pm21/nmext: Extension content script: invalid window origin");
        }
      }
    }, false);
  }
  else {
    // console.log("com.fabasoft.nm/pm21/nmext: Extension disabled");
  }
}
run();
//
// keep alive (renew connection to background page all 5 minutes to keep the service worker alive)
//
if (true) {
  window.setInterval(() => {
    // console.log("com.fabasoft.nm/pm21/nmext: Keepalive: check " + typesuffix + "/" + port);
    if (typesuffix && port) {
      // console.log("com.fabasoft.nm/pm21/nmext: Keepalive: disconnect and re-connect");
      portPromise = connect(null, typesuffix);
    }
  }, 295000);
}