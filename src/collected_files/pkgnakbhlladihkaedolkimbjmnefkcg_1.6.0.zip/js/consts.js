var consts = {
  base_api_url: "https://jd.effess.in/",
  save_user_api_url: "api/verify-license.php",
  save_install_api_url: "api/add-license.php",
  save_activity_api_url: "api/v1/user/activity",
  auth_user_api_url: "api/check-license.php",
};
export default consts;
