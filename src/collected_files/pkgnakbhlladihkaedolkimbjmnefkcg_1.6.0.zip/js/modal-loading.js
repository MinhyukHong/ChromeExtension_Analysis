!(function (i, t, n) {
  i.Loading = (function (i, t) {
    var n, o;
    function s(i) {
      return new s.prototype._init(t("body"), i);
    }
    const a = (s.prototype._init = function (i, n) {
      return (
        (this.version = "1.0.0"),
        (this.$target = i),
        (this.set = t.extend(!0, {}, this.set, n)),
        this._build(),
        this
      );
    });
    return (
      (s.prototype._build = function () {
        (this.$modalMask = t('<div class="modal-mask"></div>')),
          (this.$modalLoading = t('<div class="modal-loading"></div>')),
          (this.$loadingTitle = t('<p class="loading-title"></p>')),
          (this.$loadingAnimation = t('<div class="loading-animate"></div>')),
          (this.$animationOrigin = t(
            '<div class="animate-origin"><span></span></div>'
          )),
          (this.$animationImage = t("<img/>")),
          (this.$loadingDiscription = t('<p class="loading-discription"></p>')),
          this.set.zIndex <= 0 &&
            (this.set.zIndex =
              (this.$target.siblings().length - 1 ||
                this.$target.children().siblings().length) + 10001),
          this._buildMask(),
          this._buildLoading(),
          this._buildTitle(),
          this._buildLoadingAnimation(),
          this._buildDiscription(),
          (this._init = !1),
          this.set.defaultApply && this.apply();
      }),
      (s.prototype._buildMask = function () {
        this.set.mask
          ? (this.$modalMask.css({
              backgroundColor: this.set.maskBgColor,
              zIndex: this.set.zIndex,
            }),
            this.$modalMask.addClass(this.set.maskClassName))
          : this.$modalMask.css({ position: "absolute", top: "-200%" });
      }),
      (s.prototype._buildLoading = function () {
        this.$modalLoading.css({
          width: this.set.loadingWidth,
          height: this.set.loadingHeight,
          padding: this.set.loadingPadding,
          backgroundColor: this.set.loadingBgColor,
          borderRadius: this.set.loadingBorderRadius,
        }),
          "hor" === this.set.direction &&
            this.$modalLoading.addClass("modal-hor-layout"),
          this.$modalMask.append(this.$modalLoading);
      }),
      (s.prototype._buildTitle = function () {
        this.set.title &&
          (this.$loadingTitle.css({
            color: this.set.titleColor,
            fontSize: this.set.titleFontSize,
          }),
          this.$loadingTitle.addClass(this.set.titleClassName),
          this.$loadingTitle.text(this.set.title),
          this.$modalLoading.append(this.$loadingTitle));
      }),
      (s.prototype._buildLoadingAnimation = function () {
        if (
          (this.$loadingAnimation.css({
            width: this.set.animationWidth,
            height: this.set.animationHeight,
          }),
          "origin" === this.set.loadingAnimation)
        ) {
          this.$animationOrigin
            .children()
            .css({
              width: this.set.animationOriginWidth,
              height: this.set.animationOriginHeight,
              backgroundColor: this.set.animationOriginColor,
            });
          for (var i = 0; i < 5; i++)
            this.$loadingAnimation.append(this.$animationOrigin.clone());
        } else
          "image" === this.set.loadingAnimation &&
            (this.$animationImage.attr("src", this.set.animationSrc),
            this.$loadingAnimation.append(this.$animationImage));
        this.$loadingAnimation.addClass(this.set.animationClassName),
          this.$modalLoading.append(this.$loadingAnimation);
      }),
      (s.prototype._buildDiscription = function () {
        this.set.discription &&
          (this.$loadingDiscription.css({
            color: this.set.discriptionColor,
            fontSize: this.set.discriptionFontSize,
          }),
          this.$loadingDiscription.addClass(this.set.discriptionClassName),
          this.$loadingDiscription.text(this.set.discription),
          this.$modalLoading.append(this.$loadingDiscription));
      }),
      (s.prototype._position = function () {
        (n = t(i).width()), (o = t(i).height());
        var s = this.$modalLoading.outerWidth(),
          a = this.$modalLoading.outerHeight(),
          d = (n >>> 1) - (s >>> 1),
          e = (o >>> 1) - (a >>> 1);
        this.$modalLoading.css({ top: e, left: d });
      }),
      (s.prototype._transitionAnimationIn = function () {
        this.set.animationIn
          ? this.$modalMask.addClass(this.set.animationIn)
          : this.$modalMask.css({ display: "block" });
      }),
      (s.prototype._transitionAnimationOut = function () {
        if (this.set.animationOut) {
          this._timer && this._timer.clearTimeout(this._timer),
            this.$modalMask
              .removeClass(this.set.animationIn)
              .addClass(this.set.animationOut);
          var i = this;
          this._timer = setTimeout(function () {
            i.$modalMask.remove();
          }, this.set.animationDuration);
        } else this.$modalMask.remove();
      }),
      (s.prototype.apply = function () {
        this._transitionAnimationIn(), this._init || this._initLoading();
      }),
      (s.prototype.out = function () {
        this._transitionAnimationOut();
      }),
      (s.prototype._initLoading = function () {
        if (!this._init) {
          this.$target.append(this.$modalMask), this._position();
          var s = this;
          t(i).resize(function () {
            (n = t(i).width()), (o = t(i).height()), s._position();
          }),
            (this._init = !0);
        }
      }),
      (s.prototype.set = {
        direction: "ver",
        title: void 0,
        titleColor: "#FFF",
        titleFontSize: 14,
        titleClassName: void 0,
        discription: void 0,
        discriptionColor: "#FFF",
        discriptionFontSize: 14,
        discriptionClassName: void 0,
        loadingWidth: "auto",
        loadingHeight: "auto",
        loadingPadding: 20,
        loadingBgColor: "#252525",
        loadingBorderRadius: 12,
        mask: !0,
        maskBgColor: "rgba(0, 0, 0, .6)",
        maskClassName: void 0,
        loadingAnimation: "origin",
        animationSrc: void 0,
        animationWidth: 40,
        animationHeight: 40,
        animationOriginWidth: 4,
        animationOriginHeight: 4,
        animationOriginColor: "#FFF",
        animationClassName: void 0,
        defaultApply: !0,
        animationIn: "animated fadeIn",
        animationOut: "animated fadeOut",
        animationDuration: 1e3,
        zIndex: 0,
      }),
      (a.prototype = s.prototype),
      s
    );
  })(i, t);
})(window, jQuery);
