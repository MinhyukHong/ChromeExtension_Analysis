let imageUrl;

document.addEventListener("mouseover", (event) => {
  if (event.target.nodeName.toLowerCase() === "img") {
    imageUrl = event.target.src;
  } else {
    imageUrl = undefined
  }
});

document.addEventListener("keydown", (event) => {
  if (
    (event.ctrlKey && event.key === "c") ||
    (event.metaKey && event.key === "c")
  ) {
    if (imageUrl) {
      copyToClipboard(imageUrl);
    }
  }
});

function copyToClipboard(url) {
  const textArea = document.createElement("textarea");
  textArea.value = url;

  document.body.appendChild(textArea);
  textArea.select();

  try {
    document.execCommand("copy");
  } catch (err) {
    console.warn("Error copying image URL:", err);
  }

  document.body.removeChild(textArea);
}