document.addEventListener("DOMContentLoaded", function () {
  // Ici, tu peux ajouter du JavaScript pour rendre la page dynamique
  // Par exemple, récupérer le nom du meeting depuis le stockage de l'extension ou une autre source
})
