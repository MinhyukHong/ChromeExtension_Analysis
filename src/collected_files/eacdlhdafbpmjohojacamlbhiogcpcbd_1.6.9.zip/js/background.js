let tabsData = {}
let tabsIdsWithActiveDivSet = new Set()
let userPermission = null
let apiV2Url = ""
let user_region = ""
let audioSegmentsByUUID = {}
let lastAudioSegmentsByUUID = {}
let isSending = false
let offscreenDocumentCreated = false
let waitingForMicPermission = false
let processQueuePromise = null


const allowedDomains = [
  "meet.google.com",
  "meet.ringover.io",
  "meet-v2.ringover.net",
  "teams.live.com",
  "teams.microsoft.com",
  "*.zoom.us",
]

const MEETING_TYPE = {
  GOOGLE_MEET: "google meet",
  RINGOVER_MEET: "ringover meet",
  RINGOVER_MEET_V2: "ringover meet v2",
  TEAMS_PERSONAL: "teams(personal)",
  TEAMS_BUSINESS: "teams(business)",
  ZOOM: "zoom",
}

function getRegex(text) {
  const regexPattern = text.replace(/\./g, "\\.").replace(/\*/g, ".*")
  return new RegExp(`^${regexPattern}$`)
}

const allowedDomainsPattern = allowedDomains.map((domain) => {
  const regexPattern = getRegex(domain)
  return regexPattern
})

const zoomRegex = getRegex("*.zoom.us")

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// chrome.action.onClicked.addListener((tab) => {
//     const url = new URL(tab.url);
//     if (!allowedDomains.includes(url.hostname)) {
//         console.error('Invalid domain for recording');
//         return;
//     }

//     chrome.scripting.executeScript({
//         target: { tabId: tab.id },
//         files: ['js/content.js']
//     }, () => {
//         setTimeout(() => {
//             chrome.tabs.sendMessage(tab.id, { action: 'showDiv' });
//         }, 500);
//     });
// });

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const timestamp = new Date().toISOString()
  const hostname = sender.tab ? new URL(sender.tab.url).hostname : ""
  if (
    sender.tab &&
    !(
      allowedDomainsPattern.some((pattern) => pattern.test(hostname)) ||
      hostname === new URL(chrome.runtime.getURL("")).hostname
    )
  ) {
    sendResponse({ success: false, message: "Invalid domain" })
    return
  }

  switch (request.action || request.type) {
    case "pageLoaded" : 
      ;(async () => {
        console.log('page loaded', sender.tab.id)
        tabsIdsWithActiveDivSet.delete(sender.tab.id)
        for (const [key, value] of Object.entries(tabsData)) {
          if (value.tabId === sender.tab.id) {
            if(value.isRecording){
              const existingContexts = await chrome.runtime.getContexts({})
    
              const offscreenDocument = existingContexts.find(
                (c) => c.contextType === "OFFSCREEN_DOCUMENT"
              )
              
              if(offscreenDocument){
                chrome.runtime.sendMessage({
                  type: "stop-recording",
                  target: "offscreen",
                })
              }
            }
            delete tabsData[key];
          }
        }
        
        
      })()

      return false
    
    case "divCreated" :
      tabsIdsWithActiveDivSet.add(sender.tab.id)
      return false
    case "startOAuth":
      ;(async () => {
        try {
          await oauth_auth()
          sendResponse({ success: true, message: "authok" })
        } catch (e) {
          console.error(e)
          sendResponse({ success: false, message: "authko" })
        }
      })()
      return true

    case "userNotLoggedIn":
      ;(async () => {
        try {
          await oauth_auth()
          sendResponse({ success: true, message: "authok" })
        } catch (e) {
          console.error(e)
          sendResponse({ success: false, message: "authko" })
        }
      })()
      return true

    case "refreshTokenAuth":
      ;(async () => {
        try {
          const newAccessToken = await refresh_oauth_tokens()
          const responseTimestamp = new Date().toISOString()
          sendResponse({ success: true, accessToken: newAccessToken })
        } catch (e) {
          console.error(e)
          sendResponse({ success: false })
        }
      })()
      return true

    case "stopTabCapture":
      chrome.runtime.sendMessage({
        action: "stopRecording",
        meetingUUID: request.meetingUUID,
        duration: request.duration,
      })
      break

    case "uploadSegment":
      if(request?.isLast){
        addToLastSendQueue(request.base64, request.name, request.meetingUUID)
      } else {
        addToSendQueue(request.base64, request.name, request.meetingUUID)
      }
      if(tabsData[request.meetingUUID]){
        chrome.tabs.sendMessage(tabsData[request.meetingUUID].tabId, {
          action: "retrieve_participants",
        })
      }
      break

    case "endOfRecording":
      ;(async () => {
        try {
          await finalizeRecording(
            request.meetingUUID,
            request.duration,
            request.participantNames
          )
          sendResponse({ success: true })
        } catch (e) {
          console.error("error server.", e)
          sendResponse({ success: false })
        }
      })()
      return true

    case "startRecording":
      if (request.meetingType && request.tabId) {
        chrome.scripting.executeScript(
          {
            target: { tabId: request.tabId },
            files: ["js/content.js"],
          },
          () => {
            setTimeout(() => {
              chrome.tabs.sendMessage(request.tabId, {
                action: "showDiv",
                meetingType: request.meetingType,
              })
            }, 200)
          }
        )
        sendResponse({ success: true, message: "Recording div visible" })
      } else {
        console.error("Invalid domain for recording")
        sendResponse({ success: false, message: "Invalid domain" })
      }
      return false

    case "start-recording-from-content":
      startRecordingOffscreen(
        "check_permission_and_start_recording",
        request.meetingUUID
      )
      return false

    case "stop-recording-from-content":
      ;(async () => {
        try {
          chrome.runtime.sendMessage({
            type: "stop-recording",
            target: "offscreen",
            meetingUUID: request.meetingUUID,
          })
          delete tabsData[request.meetingUUID]
          sendResponse({ success: true, message: "Stopped recording" })
        } catch (error) {
          console.error("Error stopping recording:", error)
          sendResponse({ success: false, message: "Error stopping recording" })
        }
      })()
      return true

    case "openEmpowerSite":
      const empowerSite = "https://www.ringover.com/signup-empower"
      chrome.tabs.create({ url: encodeURI(empowerSite) })
      break

    case "check_permission_and_start_recording":
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        tabsData[request.meetingUUID] = {tabId: tabs[0].id, isRecording: false, waitingForMicPermission: false}
        startRecordingOffscreen(
          "check_permission_and_start_recording",
          request.meetingUUID
        )
      })
      return false

    case "no_mic_permission":
      tabsData[request.meetingUUID].waitingForMicPermission = true
      ;(async () => {
        const window = await chrome.windows.getCurrent()
        width = Math.round(0.75 * window.width)
        height = Math.round(0.75 * window.height)
        left = Math.round(0.5 * (window.width - width) + window.left)
        top = Math.round(0.5 * (window.height - height) + window.top)

        chrome.windows.create({
          top: top,
          left: left,
          width: width,
          height: height,
          focused: true,
          type: "popup",
          url: `${chrome.runtime.getURL("html/mic.html")}?meetingUUID=${request.meetingUUID}`,
        })
      })()
      return false

    case "got_mic_permission":
      if (tabsData[request.meetingUUID].waitingForMicPermission) {
        setTimeout(() => {
          startRecordingOffscreen("check_permission_and_start_recording", request.meetingUUID)
        }, 100)

        tabsData[request.meetingUUID].waitingForMicPermission = false
      }
      return false

    case "recording_started":
      tabsData[request.meetingUUID].isRecording = true
      chrome.tabs.sendMessage(tabsData[request.meetingUUID].tabId, {
        action: "recording_started",
      })
      return false

    case "mic_state":
      if(sender.tab.id === tabsData?.[request.meetingUUID]?.tabId){
        chrome.runtime.sendMessage({
          type: "mic_state",
          target: "offscreen",
          isMuted: request.isMuted,
          meetingUUID: request.meetingUUID
        })
      }
      return false

    case "logout":
      logout()
      return false

    case "check_recording_status":
      checkRecordingStatus(sendResponse)
      return true

    default:
      sendResponse({ success: false, message: "Unknown message type" })
      break
  }
  return true
})

function handleStopRecording() {
  chrome.runtime.sendMessage({
    type: "stop-recording",
    target: "offscreen",
  })
}

async function getStreamID(tabId) {
  return new Promise( async(resolve, reject) => {
        chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, (streamId) => {
          if (chrome.runtime.lastError || !streamId) {
            reject(chrome.runtime.lastError || new Error("No stream ID"))
          } else {
            resolve(streamId)
          }
        })
  })
}


async function startRecordingOffscreen(type, meetingUUID, sendResponse) {
  const isSendRequest = typeof sendResponse === "function"
  const tabId = tabsData[meetingUUID].tabId

  try {
    for (const id of tabsIdsWithActiveDivSet.values()) {
      if(tabId !== id){
        chrome.tabs.sendMessage(id, {
          action: "removeDiv",
        })
        tabsIdsWithActiveDivSet.delete(id);
      }
    }
  } catch (error) {
    console.log('error removing div', error)
  }

  try {
    const existingContexts = await chrome.runtime.getContexts({})
    let recording = false

    const offscreenDocument = existingContexts.find(
      (c) => c.contextType === "OFFSCREEN_DOCUMENT"
    )

    if (!offscreenDocument) {
      await chrome.offscreen.createDocument({
        url: "html/offscreen.html",
        reasons: ["USER_MEDIA"],
        justification: "Recording from chrome.tabCapture API",
      })
    } else {
      recording = offscreenDocument.documentUrl.endsWith("#recording")
      chrome.runtime.sendMessage({
        type: "stop-recording",
        target: "offscreen",
      })
      await delay(200);
    }

    if (recording) {
      isSendRequest &&
        sendResponse({
          success: true,
          message: "Stopped existing recording",
        })
      return
    }
    const streamId = await getStreamID(tabId)
    if (streamId) {
      chrome.runtime.sendMessage({
        type: type,
        target: "offscreen",
        data: streamId,
        meetingUUID: meetingUUID,
      })
      isSendRequest &&
        sendResponse({ success: true, message: "Started recording" })
    } else {
      console.error("Failed to get stream ID")
      isSendRequest &&
        sendResponse({ success: false, message: "Failed to get stream ID" })
    }
  } catch (error) {
    console.error("Error getting media stream ID:", error)
    isSendRequest &&
      sendResponse({
        success: false,
        message: "Error getting media stream ID",
      })
  }
}

function checkRecordingStatus(sendResponse) {
  const activeTab = Object.entries(tabsData).filter(([key, value]) => value.isRecording === true)?.[0]
  if(activeTab) {
    const [key, value] = activeTab
    chrome.tabs.get(value.tabId, async () => {
      if (chrome.runtime.lastError) {
        sendResponse({ success: true, isRecording: false })
        console.log(chrome.runtime.lastError.message) 
        const existingContexts = await chrome.runtime.getContexts({})
    
        const offscreenDocument = existingContexts.find(
          (c) => c.contextType === "OFFSCREEN_DOCUMENT"
        )
        
        if(offscreenDocument){
          chrome.runtime.sendMessage({
            type: "stop-recording",
            target: "offscreen",
          })
        }
        delete tabsData[key]
        tabsIdsWithActiveDivSet.delete(value.tabId)
      } else {
        sendResponse({ success: true, isRecording: true })
      }
    })
  } else {
    sendResponse({ success: true, isRecording: false })
  }
}

// * not in use
async function requestPermissionsAndStartRecording(meetingUUID) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    const hostname = new URL(tab.url).hostname

    if (!allowedDomainsPattern.some((pattern) => pattern.test(hostname))) {
      console.error("Invalid domain for recording")
      return
    }

    const granted = await new Promise((resolve) => {
      chrome.permissions.request(
        {
          permissions: [
            "tabCapture",
            "activeTab",
            "tabs",
            "storage",
            "identity",
            "desktopCapture",
            "scripting",
            "offscreen",
          ],
          origins: ["<all_urls>"],
        },
        (granted) => resolve(granted)
      )
    })

    if (!granted) {
      console.error("Permissions not granted")
      return
    }

    const existingContexts = await chrome.runtime.getContexts({})
    const offscreenDocument = existingContexts.find(
      (c) => c.contextType === "OFFSCREEN_DOCUMENT"
    )

    if (!offscreenDocument && !offscreenDocumentCreated) {
      await chrome.offscreen.createDocument({
        url: "offscreen.html",
        reasons: ["USER_MEDIA"],
        justification: "Recording from chrome.tabCapture API",
      })
      offscreenDocumentCreated = true
    }

    const streamId = await chrome.tabCapture.getMediaStreamId({
      targetTabId: tab.id,
    })

    chrome.runtime.sendMessage({
      type: "start-recording",
      target: "offscreen",
      data: streamId,
      meetingUUID: meetingUUID,
    })
  } catch (error) {
    console.error("Error in requestPermissionsAndStartRecording: ", error)
  }
}

// * not in use
async function startTabCapture(meetingUUID) {
  try {
    const existingContexts = await chrome.runtime.getContexts({})
    const offscreenDocument = existingContexts.find(
      (c) => c.contextType === "OFFSCREEN_DOCUMENT"
    )

    if (!offscreenDocument) {
      await chrome.offscreen.createDocument({
        url: "html/offscreen.html",
        reasons: ["USER_MEDIA"],
        justification: "Recording from chrome.tabCapture API",
      })
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    const streamId = await chrome.tabCapture.getMediaStreamId({
      targetTabId: tab.id,
    })

    chrome.runtime.sendMessage({
      type: "start-recording",
      target: "offscreen",
      data: streamId,
      meetingUUID: meetingUUID,
    })
  } catch (error) {
    console.error("Error in startTabCapture: ", error)
  }
}

//* not in use
function ensureOffscreenDocument(callback) {
  chrome.offscreen.hasDocument().then((hasDocument) => {
    if (hasDocument) {
      callback()
    } else {
      chrome.offscreen
        .createDocument({
          url: "html/offscreen.html",
          reasons: ["AUDIO_PLAYBACK"],
          justification: "Required for background audio recording",
        })
        .then(callback)
    }
  })
}
//* not in use
function generateUUID() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    var r = (Math.random() * 16) | 0,
      v = c === "x" ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}
//* not in use
function stopTabCapture(meetingUUID) {
  chrome.tabCapture.getCapturedTabs((tabs) => {
    for (let tab of tabs) {
      if (tab.tabId === tabsData[meetingUUID].tabId) {
        tab.stream.getTracks().forEach((track) => track.stop())
        break
      }
    }
  })
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const hostname = new URL(tab.url).hostname
  if (!allowedDomainsPattern.some((pattern) => pattern.test(hostname))) {
    return
  }
  // if (!allowedDomainsPattern.some((pattern) => pattern.test(hostname))) {
  //   chrome.action.setPopup({ popup: "", tabId : tabId})
  //   chrome.action.setTitle({ title: "Not supported", tabId : tabId})
  //   chrome.action.setIcon({
  //     path: "../assets/extension-icons/logo-32-disabled.png", tabId : tabId
  //   })
  //   return
  // }

  // chrome.action.setPopup({ popup: "../html/popup.html", tabId : tabId})
  // chrome.action.setTitle({ title: "Start Recording", tabId : tabId})
  // updateIcon()

  const urlParts = tab.url.split("/")
  if (
    tab.url.startsWith("https://meet.google.com/") &&
    urlParts.length > 3 &&
    urlParts[3] !== ""
  ) {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabId },
        files: ["js/content.js"],
      },
      () => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, { action: "onGoogleMeet" })
        }, 500)
      }
    )
  } else if (
    tab.url.startsWith("https://meet.ringover.io/") &&
    urlParts.length > 3 &&
    urlParts[3] !== ""
  ) {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabId },
        files: ["js/content.js"],
      },
      () => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, { action: "onRingoverMeet" })
        }, 500)
      }
    )
  } else if (
    tab.url.startsWith("https://meet-v2.ringover.net/") &&
    urlParts.length > 3 &&
    urlParts[3] !== ""
  ) {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabId },
        files: ["js/content.js"],
      },
      () => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, { action: "onRingoverMeetv2" })
        }, 500)
      }
    )
  } else if (tab.url.startsWith("https://teams.live.com/")) {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabId },
        files: ["js/content.js"],
      },
      () => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, { action: "onTeamsPersonal" })
        }, 500)
      }
    )
  } else if (tab.url.startsWith("https://teams.microsoft.com/")) {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabId },
        files: ["js/content.js"],
      },
      () => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, { action: "onTeamsBusiness" })
        }, 500)
      }
    )
  } else if (
    zoomRegex.test(hostname) &&
    urlParts.length > 4 &&
    urlParts[4] !== ""
  ) {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabId },
        files: ["js/content.js"],
      },
      () => {
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, { action: "onZoom" })
        }, 500)
      }
    )
  }
})

async function oauth_auth() {
  try {
    const sequence_verifier = new Uint8Array(32)
    for (let i = 0; i < 32; i++) {
      sequence_verifier[i] = Math.floor(Math.random() * 255)
    }
    let binary_verifier = ""
    for (let unit8 of sequence_verifier) {
      binary_verifier += String.fromCharCode(unit8)
    }
    const code_verifier = btoa(binary_verifier)
      .replace(/=/g, "")
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
    const code_challenge = await generate_code_challenge(code_verifier)

    await chrome.storage.local.set({ PCKE: code_verifier })

    const params = {
      client_id: "record_meet_app",
      scope: "API_V2_ALL",
      response_type: "code",
      redirect_uri: chrome.identity.getRedirectURL(),
      code_challenge_method: "S256",
      code_challenge: code_challenge,
    }
    let url = "https://auth.ringover.com/oauth2/authorize" + "?"
    for (let param in params) {
      url += param + "=" + params[param] + "&"
    }

    chrome.tabs.create({ url: encodeURI(url) })
    return Promise.resolve()
  } catch (e) {
    console.error(e)
    return Promise.reject(e)
  }
}

async function refresh_oauth_tokens() {
  try {
    const tokens = await get_tokens_as_promise()

    if (
      !tokens ||
      !tokens.access_token ||
      !tokens.refresh_token ||
      !tokens.id_token
    ) {
      throw new Error("Token data is missing")
    }
    let params = {
      grant_type: "refresh_token",
      redirect_uri: chrome.identity.getRedirectURL(),
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      id_token: tokens.id_token,
    }

    let res = await call_oauth2_API(params)

    if (res.error) {
      throw new Error(res.error)
    } else {
      await save_tokens(res)
      return res.access_token
    }
  } catch (error) {
    console.error(`Error in refresh_oauth_tokens: ${error}`)
    remove_token()
    throw error
  }
}

async function finalizeRecording(meetingUUID, duration, participantNames) {
  try {
    const data = await chrome.storage.local.get(["id_token_ext"])
    const token = data.id_token_ext

    if (!token) {
      console.error("Token non trouvé.")
      return
    }
    
    await delay(1200)

    if(processQueuePromise instanceof Promise){
      await processQueuePromise
    }
    await processLastSendQueue()

    await delay(1200)

    const response = await fetch(
      `https://record-meet.ringover.net/end-of-recording/${meetingUUID}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          duration,
          participantNames,
          callDate:
            new Date()
              .toLocaleString("en-CA", {
                timeZone: "Europe/Paris",
                hour12: false,
              })
              .replace(", ", "T") + "Z",
        }),
      }
    )

    if (!response.ok && response.status === 401) {
      const refreshResult = await refresh_oauth_tokens()
      if (refreshResult) {
        finalizeRecording(meetingUUID, duration, participantNames)
      } else {
        console.error("refresh token ko.")
      }
    } else if (!response.ok) {
      throw new Error("record server ko")
    }
  } catch (error) {
    throw new Error(error)
  }
}

function addToLastSendQueue(base64, name, meetingUUID) {
  if (!lastAudioSegmentsByUUID[meetingUUID]) {
    lastAudioSegmentsByUUID[meetingUUID] = []
  }
  lastAudioSegmentsByUUID[meetingUUID].push({ base64, name })
}


async function processLastSendQueue() {

  for (const [meetingUUID, segments] of Object.entries(lastAudioSegmentsByUUID)) {
    while (segments.length > 0) {
      const segment = segments.shift()
      try {
        await sendSegment(segment)
      } catch (error) {
        console.error(
          `Erreur lors de l'envoi du segment ${segment.name}:`,
          error
        )
      }
    }
    delete lastAudioSegmentsByUUID[meetingUUID]
  }
}

function addToSendQueue(base64, name, meetingUUID) {
  if (!audioSegmentsByUUID[meetingUUID]) {
    audioSegmentsByUUID[meetingUUID] = []
  }
  audioSegmentsByUUID[meetingUUID].push({ base64, name })
  processQueuePromise = processSendQueue()
}

async function processSendQueue() {
  if (isSending) {
    return
  }
  isSending = true

  for (const [meetingUUID, segments] of Object.entries(audioSegmentsByUUID)) {
    while (segments.length > 0) {
      const segment = segments.shift()
      try {
        await sendSegment(segment)
      } catch (error) {
        console.error(
          `Erreur lors de l'envoi du segment ${segment.name}:`,
          error
        )
      }
    }
    delete audioSegmentsByUUID[meetingUUID]
  }
  isSending = false
}

async function sendSegment(segment) {
  try {
    const data = await chrome.storage.local.get(["id_token_ext"])
    if (!data.id_token_ext) {
      throw new Error("Token non trouvé")
    }

    if (
      !segment.base64 ||
      typeof segment.base64 !== "string" ||
      segment.base64.length < 30
    ) {
      throw new Error(`Donnée base64 invalide pour le segment ${segment.name}`)
    }

    let formData = new FormData()
    formData.append("files", base64ToBlob(segment.base64), segment.name)

    let response = await fetch(
      "https://record-meet.ringover.net/upload-audio",
      {
        method: "POST",
        body: formData,
        headers: { Authorization: `Bearer ${data.id_token_ext}` },
      }
    )

    if (response.status === 401) {
      const refreshResult = await refresh_oauth_tokens()
      if (refreshResult) {
        const newData = await chrome.storage.local.get(["id_token_ext"])
        response = await fetch(
          "https://record-meet.ringover.net/upload-audio",
          {
            method: "POST",
            body: formData,
            headers: { Authorization: `Bearer ${newData.id_token_ext}` },
          }
        )
      } else {
        throw new Error("Échec du rafraîchissement du token.")
      }
    }

    if (!response.ok) {
      throw new Error(
        `Échec de l'envoi du segment ${segment.name}. Statut HTTP : ${response.status}`
      )
    }
  } catch (error) {
    console.error(`Erreur lors de l'envoi du segment ${segment.name}:`, error)
    throw error
  }
}

function base64ToBlob(base64, mimeType = "audio/webm") {
  if (!base64 || typeof base64 !== "string" || base64.length < 30) {
    throw new Error("Invalid base64 data")
  }

  const byteCharacters = atob(base64.split(",")[1])
  const byteArrays = []

  for (let offset = 0; offset < byteCharacters.length; offset += 512) {
    const slice = byteCharacters.slice(offset, offset + 512)
    const byteNumbers = new Array(slice.length)
    for (let i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i)
    }
    const byteArray = new Uint8Array(byteNumbers)
    byteArrays.push(byteArray)
  }

  return new Blob(byteArrays, { type: mimeType })
}

async function get_oauth2_tokens(code) {
  try {
    const data = await getStorageData("PCKE")
    const verifier_code = data.PCKE

    const params = {
      grant_type: "authorization_code",
      redirect_uri: chrome.identity.getRedirectURL(),
      code: code,
      code_verifier: verifier_code,
    }

    const res = await call_oauth2_API(params)

    if (res.error) {
      throw res.error
    } else {
      await removeStorageData("PCKE")
      await save_tokens(res)
      return res
    }
  } catch (error) {
    console.error(error)
    throw error
  }
}

async function call_oauth2_API(params) {
  let defaultParams = {
    client_id: "record_meet_app",
    scope: "API_V2_ALL",
  }

  params = Object.assign(defaultParams, params)

  let formData = new FormData()
  for (let key in params) {
    formData.append(key, params[key])
  }
  const res = await fetch("https://auth.ringover.com/oauth2/access_token", {
    method: "post",
    body: formData,
  })
  if (res.ok) {
    return res.json()
  } else {
    return res.json()
  }
}

function save_tokens(res) {
  return new Promise((resolve, reject) => {
    chrome.action.setIcon({ path: "../assets/extension-icons/logo-32.png" })

    let formData = new FormData()
    formData.append("token", res.id_token)

    fetch("https://auth.ringover.com/oauth2/introspect", {
      method: "post",
      body: formData,
    })
      .then((response) => response.json())
      .then((responseJson) => {
        user_region = responseJson.region.toLowerCase()
        apiV2Url = "https://api-" + user_region + ".ringover.com/v2/get/user"

        let expirationTimestamp = Date.now() + res.expires_in * 1000

        chrome.storage.local.set(
          {
            access_token_ext: res.access_token,
            refresh_token_ext: res.refresh_token,
            id_token_ext: res.id_token,
            region_ext: user_region,
            token_expiry: expirationTimestamp,
          },
          () => {
            if (chrome.runtime.lastError) {
              console.error(
                "Erreur de sauvegarde des tokens:",
                chrome.runtime.lastError
              )
              reject(chrome.runtime.lastError)
            } else {
              initUser(apiV2Url, res.id_token).then(resolve).catch(reject)
            }
          }
        )
      })
      .catch((error) => {
        console.error(error)
        reject(error)
      })
  })
}

async function logout() {
  try {

    const params = {
      post_logout_redirect_uri: `${chrome.identity.getRedirectURL()}?logout=true`,
    }

    let url = "https://auth.ringover.com/oauth2/logout" + "?"
    for (let param in params) {
      url += param + "=" + params[param] + "&"
    }

    chrome.tabs.create({ url: encodeURI(url) })
    return true
  } catch (e) {
    console.error(e)
    throw new Error(e)
  }
}

function remove_token(cb) {
  chrome.storage.local.remove(
    [
      "id_token_ext",
      "refresh_token_ext",
      "access_token_ext",
      "user_id_ext",
      "user_name_ext",
      "user_avatar_ext",
      "is_auth",
    ],
    function () {
      if(typeof cb === 'function'){
        cb()
      }
      chrome.runtime.sendMessage({ action: "userLoggedOut" })
      for (const id of tabsIdsWithActiveDivSet.values()) {
          chrome.tabs.sendMessage(id, {
            action: "removeDiv",
          })
      }
      tabsIdsWithActiveDivSet.clear()
      tabsData = {}
    }
  )
}

async function initUser(apiUrlPath, id_token) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set({ userPermissionData: true })
    let userData

    fetch(apiUrlPath, {
      method: "get",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + id_token,
      },
    })
      .then((response) => response.json())
      .then((responseJson) => {
        userData = responseJson

        chrome.storage.local.set({
          user_id_ext: userData.id,
          user_name_ext: userData.lastname + " " + userData.firstname,
          user_avatar_ext: userData.photopath,
          is_auth: 1,
        })

        if (!userData.permissions.is_empower) {
          userPermission = userData.permissions.is_empower
          chrome.storage.local.set({ userPermissionData: false })
          remove_token()
          reject("User does not have empower permissions")
        }

        chrome.runtime.sendMessage({
          type: "setUserData",
          avatar: userData.photopath,
          userName: userData.lastname + " " + userData.firstname,
        })
        resolve(userData)
      })
      .catch((error) => {
        console.error(error)
        reject(error)
      })
  })
}

function generate_code_challenge(code_verifier) {
  return crypto.subtle
    .digest("SHA-256", new TextEncoder().encode(code_verifier))
    .then((buffer) => {
      return btoa(String.fromCharCode.apply(null, new Uint8Array(buffer)))
        .replace(/\+/g, "-")
        .replace(/\//g, "_")
        .replace(/=+$/, "")
    })
}

function get_tokens_as_promise() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(
      ["access_token_ext", "refresh_token_ext", "id_token_ext"],
      (data) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError))
        } else {
          resolve({
            access_token: data.access_token_ext,
            refresh_token: data.refresh_token_ext,
            id_token: data.id_token_ext,
          })
        }
      }
    )
  })
}

function getStorageData(key) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(key, (data) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError))
      } else {
        resolve(data)
      }
    })
  })
}

function removeStorageData(key) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.remove(key, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError))
      } else {
        resolve()
      }
    })
  })
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // if (!allowedDomains.includes(new URL(tab.url).hostname)) {
  //     return;
  // }

  if (
    changeInfo.url &&
    changeInfo.url.startsWith(chrome.identity.getRedirectURL())
  ) {
    const url = new URL(changeInfo.url)
    const authorizationCode = url.searchParams.get("code")
    const isLogout = url.searchParams.get("logout")

    if (authorizationCode) {
      chrome.tabs.remove(tabId)
      chrome.tabs.create(
        { url: chrome.runtime.getURL("html/redirect.html") },
        function (newTab) {
          get_oauth2_tokens(authorizationCode)
            .then(() => {
              chrome.storage.local.remove("PCKE", function () {
                setTimeout(() => {
                  chrome.tabs.remove(newTab.id)
                }, 2000)
              })
            })
            .catch((err) => {
              console.error(err)
              chrome.tabs.remove(newTab.id)
              chrome.tabs.create(
                { url: `${chrome.runtime.getURL("html/redirect.html")}?error=${err}` },
                function (errorTab) {
                  setTimeout(() => {
                    chrome.tabs.remove(errorTab.id)
                    logout()
                  }, 2000)
                }
              )
            })
        }
      )
    } else if(isLogout) {
      chrome.tabs.remove(tabId)
      chrome.tabs.create(
        { url: chrome.runtime.getURL("html/redirect.html") },
        function (newTab) {
          remove_token(() => {chrome.tabs.remove(newTab.id)}) 
        })
    } else {
      chrome.tabs.remove(tabId)
    }
  }
})

function updateIcon() {
  chrome.storage.local.get("id_token_ext", function (data) {
    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError)
      return
    }

    let id_token = data.id_token_ext

    if (id_token && id_token !== "null") {
      chrome.action.setIcon({ path: "../assets/extension-icons/logo-32.png" })
    } else {
      chrome.action.setIcon({
        path: "../assets/extension-icons/logo-32-rec.png",
      })
    }
  })
}

updateIcon()

chrome.storage.onChanged.addListener(function (changes, areaName) {
  if (areaName === "local" && changes.id_token_ext) {
    updateIcon()
  }
})

chrome.tabs.onRemoved.addListener(async function(tabid) {
  tabsIdsWithActiveDivSet.delete(tabid)
  const activeTab = Object.entries(tabsData).filter(([key, value]) => value.tabId === tabid)?.[0]
  if(activeTab) {
    console.log("tab closed", tabid)
  
    const [key, value] = activeTab
    if(value.isRecording){
      const existingContexts = await chrome.runtime.getContexts({})
  
      const offscreenDocument = existingContexts.find(
        (c) => c.contextType === "OFFSCREEN_DOCUMENT"
      )
      
      if(offscreenDocument){
        chrome.runtime.sendMessage({
          type: "stop-recording",
          target: "offscreen",
        })
      }
    }
    delete tabsData[key]
  }
})
