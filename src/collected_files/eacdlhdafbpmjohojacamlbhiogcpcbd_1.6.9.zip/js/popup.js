document.addEventListener("DOMContentLoaded", function () {
  verifierConnexion()
  setUserData()

  let isRecording = false
  let isSupported = false
  let meetingType = ""
  let tabId = 0

  
  const allowedDomains = [
    "meet.google.com",
    "meet.ringover.io",
    "meet-v2.ringover.net",
    "teams.live.com",
    "teams.microsoft.com",
    "*.zoom.us",
  ]
  
  const MEETING_TYPE = {
    GOOGLE_MEET: "google meet",
    RINGOVER_MEET: "ringover meet",
    RINGOVER_MEET_V2: "ringover meet v2",
    TEAMS_PERSONAL: "teams(personal)",
    TEAMS_BUSINESS: "teams(business)",
    ZOOM: "zoom",
  }

  function getRegex(text) {
    const regexPattern = text.replace(/\./g, "\\.").replace(/\*/g, ".*")
    return new RegExp(`^${regexPattern}$`)
  }

  const allowedDomainsPattern = allowedDomains.map((domain) => {
    const regexPattern = getRegex(domain)
    return regexPattern
  })
  
  const zoomRegex = getRegex("*.zoom.us")

  const btnLogin = document.getElementById("login_btn")
  if (btnLogin) {
    btnLogin.addEventListener("click", function () {
      chrome.runtime.sendMessage({ action: "startOAuth" })
    })
  } else {
    console.error("login_btn does not exist in the DOM")
  }

  const openLogout = document.getElementById("open_logout")
  const logoutMenu = document.getElementById("logout_menu")
  
  const recordEmpowerBtn = document.getElementById("record_empower_btn")
  const inProgressText = document.getElementById("in_progress")
  const notInMeetingText = document.getElementById("not_in_meeting")
  const notSupportedText = document.getElementById("not_supported")

  if(openLogout && logoutMenu){
    openLogout.addEventListener("click", function () {
      logoutMenu.style.display =
        logoutMenu.style.display === "none" ? "flex" : "none"
    })
  } 

  const logoutBtn = document.getElementById("user_logout")
  if(logoutBtn){
    logoutBtn.addEventListener("click", function () {
      chrome.runtime.sendMessage({
        action: "logout",
      })
    })
  }

  chrome.runtime.sendMessage(
    {
      action: "check_recording_status",
    },
    function (response) {
      if (chrome.runtime.lastError) {
        console.error("Error checking status: ", chrome.runtime.lastError)
      } else {
        if (response && response.success) {
          if (response.isRecording) {
            updateState("recording_ongoing")
          } else {
            updateState("recording_done")
          }
        }
      }
    }
  )

  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const url = new URL(tabs[0].url)
    
    if (!allowedDomainsPattern.some((pattern) => pattern.test(url.hostname))) {
      isSupported = false
      updateState("not_supported")
      return
    }

    isSupported = true

    tabId = tabs[0].id

    if (url.hostname === "meet.google.com") {
      meetingType = MEETING_TYPE.GOOGLE_MEET
    } else if (url.hostname === "meet.ringover.io") {
      meetingType = MEETING_TYPE.RINGOVER_MEET
    } else if (url.hostname === "meet-v2.ringover.net") {
      meetingType = MEETING_TYPE.RINGOVER_MEET_V2
    } else if (url.hostname === "teams.live.com") {
      meetingType = MEETING_TYPE.TEAMS_PERSONAL
    } else if (url.hostname === "teams.microsoft.com") {
      meetingType = MEETING_TYPE.TEAMS_BUSINESS
    } else if (zoomRegex.test(url.hostname)) {
      meetingType = MEETING_TYPE.ZOOM
    }

    if(meetingType){
      chrome.tabs.sendMessage(tabs[0].id, {
          action: "check_if_in_meeting",
          meetingType: meetingType
        },
        function (response) {
          if (chrome.runtime.lastError) {
            console.error("Error checking in_meeting status: ", chrome.runtime.lastError)
          } else if (response) {
            if(response.success && response.isInMeeting){
              updateState("in_meeting")
            } else {
              updateState("not_in_meeting")
            }
          }
        }
      )

    }
    
  })

  const subscribeEmpower = document.getElementById("subscribe_empower")
  if (subscribeEmpower) {
    subscribeEmpower.addEventListener("click", function () {
      chrome.runtime.sendMessage({
        action: "openEmpowerSite",
      })
    })
  }

  let loadingTimeoutId

  if(recordEmpowerBtn){
    recordEmpowerBtn.addEventListener("click", function () {
      recordEmpowerBtn.classList.add("loading")
      chrome.runtime.sendMessage({ action: "startRecording", tabId: tabId, meetingType: meetingType })
      loadingTimeoutId = setTimeout(() => {
        recordEmpowerBtn.classList.remove("loading")
      }, 5000)
    })
  }

  function updateState(type) {
    switch (type) {
      case "recording_ongoing":
        isRecording = true
        if(logoutBtn) logoutBtn.classList.add("disabled")
        if(recordEmpowerBtn) recordEmpowerBtn.classList.add("disabled")
        if(notInMeetingText) notInMeetingText.style.display = "none"
        if(isSupported && inProgressText) inProgressText.style.display = "block"
        break;
      case "recording_done":
        isRecording = false
        if(logoutBtn) logoutBtn.classList.remove("disabled")
        if(recordEmpowerBtn && isSupported) recordEmpowerBtn.classList.remove("disabled")
        if(inProgressText) inProgressText.style.display = "none"
        break;
      case "not_in_meeting":
        if(recordEmpowerBtn) recordEmpowerBtn.classList.add("disabled")
        if(notInMeetingText && isSupported && !isRecording) notInMeetingText.style.display = "block"
        break;
      case "in_meeting":
        if(recordEmpowerBtn && isSupported && !isRecording) recordEmpowerBtn.classList.remove("disabled")
        if(notInMeetingText) notInMeetingText.style.display = "none"
        break;
      case "not_supported":
        if(recordEmpowerBtn) recordEmpowerBtn.classList.add("disabled")
        if(inProgressText) inProgressText.style.display = "none"
        if(notInMeetingText) notInMeetingText.style.display = "none"
        if(notSupportedText) notSupportedText.style.display = "block"
        break;
    }
  }

  function get_tokens(callback) {
    chrome.storage.local.get(
      ["access_token_ext", "refresh_token_ext", "id_token_ext"],
      function (data) {
        var tokens = {
          access_token: data.access_token_ext,
          refresh_token: data.refresh_token_ext,
          id_token: data.id_token_ext,
        }
        callback(tokens)
      }
    )
  }

  function updateUI(state, is_empower = true) {
    document.getElementById("body_auth").style.display = "none"
    document.getElementById("body_nauth").style.display = "none"
    // document.getElementById('body_nempower').style.display = 'none';

    if (!is_empower) {
      document.getElementById("login_btn").display = "none"
      document.getElementById("text_dark").innerText =
        "Please subscribe to Empower to use this extension"
    }
    document.getElementById(state).style.display = "flex"
  }

  function verifierConnexion() {
    get_tokens(function (tokens) {
      if (tokens && tokens.refresh_token && tokens.id_token) {
        chrome.storage.local.get("PCKE", function (data) {
          if (!data.PCKE) {
            chrome.action.setIcon({
              path: "../assets/extension-icons/logo-32.png",
            })
            updateUI("body_auth")
            chrome.runtime.sendMessage(
              { action: "refreshTokenAuth" },
              function (response) {
                if (chrome.runtime.lastError) {
                  console.error(
                    "Error sending refreshTokenAuth message: ",
                    chrome.runtime.lastError
                  )
                } else {
                  if (response && response.success) {
                    updateUI("body_auth")
                  } else {
                    console.error(
                      "Token refresh failed, attempting re-authentication"
                    )
                    chrome.runtime.sendMessage({ action: "startOAuth" })
                  }
                }
              }
            )
          }
        })
      } else {
        chrome.storage.local.get("userPermissionData", function (data) {
          if (data.userPermissionData === false) {
            updateUI("body_nauth", true)
          } else {
            updateUI("body_nauth")
          }
          chrome.action.setIcon({
            path: "../assets/extension-icons/logo-32-rec.png",
          })
        })
      }
    })
  }

  function setUserData() {
    chrome.storage.local.get(
      ["user_name_ext", "user_avatar_ext"],
      function (data) {
        const userAvatarElem = document.getElementById("user_avatar")
        if (userAvatarElem && data.user_avatar_ext) {
          userAvatarElem.src = data.user_avatar_ext
          userAvatarElem.onerror = function () {
            this.onerror = null
            this.src = chrome.runtime.getURL("assets/figma/avatar.svg")
          }
        }
        const userNameHtml = document.getElementById("user_name")
        if (userNameHtml) {
          userNameHtml.innerText = data.user_name_ext
        }
      }
    )

   
  }

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "authStatus") {
      updateUI("body_auth")
    }

    if (request.type === "divCreated") {
      loadingTimeoutId = null
      if(recordEmpowerBtn) recordEmpowerBtn.classList.remove("loading")
    }

    if (request.action === "userLoggedOut") {
      //logged out
      updateUI("body_nauth")
    }

    if (request.type === "recording_started") {
      updateState("recording_ongoing")
    } else if (request.type === "stop-recording-from-content") {
      updateState("recording_done")
    }

    if (request.type === "setUserData") {
      const userAvatarElem = document.getElementById("user_avatar")
      if (userAvatarElem && request.avatar) {
        userAvatarElem.src = request.avatar
        userAvatarElem.onerror = function () {
          this.onerror = null
          this.src = chrome.runtime.getURL("assets/figma/avatar.svg")
        }
      }
      const userNameHtml = document.getElementById("user_name")
      if (userNameHtml) {
        userNameHtml.innerText = request.userName
      }
    } else if (request.type === "userPermissionData") {
      if (!request.userPermission) {
        // handle permission denied
      }
    }
  })
})
