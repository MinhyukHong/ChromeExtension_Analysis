chrome.runtime.onMessage.addListener(async (message) => {
  if (message.target === "offscreen") {
    switch (message.type) {
      case "start-recording":
        await startRecording(message.data, message.meetingUUID)
        break
      case "stop-recording":
        stopRecording(message.meetingUUID)
        break
      case "check_permission_and_start_recording":
        await checkPermissionNstart(message.data, message.meetingUUID)
        break
      case "mic_state":
        await toggleMicState(message.isMuted)
        break
      default:
        throw new Error("Unrecognized message:", message.type)
    }
  }
})

let recorder
let recordedChunks = []
let recordingInterval
let isRecording = false
let segment = 30000

let tabAudioStream = null
let micAudioStream = null
let gainNodeForMicSource = null
let audioContext = null

async function toggleMicState(isMuted = false) {
  console.log("isMuted", isMuted)
  if (recorder && gainNodeForMicSource && audioContext) {
    await gainNodeForMicSource.gain.setValueAtTime(
      isMuted ? 0 : 1,
      audioContext.currentTime
    )
  }
}

async function startRecording(streamId, meetingUUID) {
  try {
    if (tabAudioStream) {
      tabAudioStream.getTracks().forEach((track) => track.stop())
      tabAudioStream = null
    }
    if (micAudioStream) {
      micAudioStream.getTracks().forEach((track) => track.stop())
      micAudioStream = null
    }

    tabAudioStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId,
        },
      },
      video: false,
    })

    micAudioStream = await navigator.mediaDevices.getUserMedia({ audio: true })

    audioContext = new AudioContext()
    gainNodeForMicSource = audioContext.createGain()
    const destination = audioContext.createMediaStreamDestination()

    const tabSource = audioContext.createMediaStreamSource(tabAudioStream)
    const micSource = audioContext.createMediaStreamSource(micAudioStream)

    micSource.connect(gainNodeForMicSource)

    tabSource.connect(audioContext.destination) // Re-enable tab sound
    tabSource.connect(destination)
    gainNodeForMicSource.connect(destination)

    const combinedStream = destination.stream

    recorder = new MediaRecorder(combinedStream, { mimeType: "audio/webm" })
    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        recordedChunks.push(event.data)
      }
    }

    recorder.onstop = async () => {
      try {
        if (recordedChunks.length > 0) {
          const blob = new Blob(recordedChunks, { type: "audio/webm" })
          recordedChunks = []

          // const url = URL.createObjectURL(blob)
          // const a = document.createElement("a")
          // a.href = url
          // a.download = `${meetingUUID}_${Date.now()}.webm`
          // document.body.appendChild(a)
          // a.click()
          // document.body.removeChild(a)
          // URL.revokeObjectURL(url)

          const base64data = await blobToBase64(blob)
          chrome.runtime.sendMessage({
            action: "uploadSegment",
            base64: base64data,
            name: `${meetingUUID}_${Date.now()}.webm`,
            meetingUUID: meetingUUID,
            isLast: false
          })
        }
      } catch (error) {
        console.error("Error during onstop: ", error)
      }
    }

    recorder.start(segment)
    recordingInterval = setInterval(() => {
      if (recorder && recorder.state === "recording") {
        recorder.stop()
        recorder.start(segment)
      }
    }, segment)

    await chrome.runtime.sendMessage({
      type: "recording_started",
      data: streamId,
      meetingUUID: meetingUUID,
    })

    isRecording = true
  } catch (error) {
    console.error("Error starting recording:", error)
  }
}

function stopRecording(meetingUUID) {
  clearInterval(recordingInterval)
  recordingInterval = null
  if (recorder && recorder.state === "recording") {
    recorder.onstop = async () => {
      try {
        if (recordedChunks.length > 0) {
          const blob = new Blob(recordedChunks, { type: "audio/webm" })
          recordedChunks = []

          // const url = URL.createObjectURL(blob)
          // const a = document.createElement("a")
          // a.href = url
          // a.download = `${meetingUUID}_${Date.now()}.webm`
          // document.body.appendChild(a)
          // a.click()
          // document.body.removeChild(a)
          // URL.revokeObjectURL(url)
          if(meetingUUID){
            const base64data = await blobToBase64(blob)
            chrome.runtime.sendMessage({
              action: "uploadSegment",
              base64: base64data,
              name: `${meetingUUID}_${Date.now()}.webm`,
              meetingUUID: meetingUUID,
              isLast: true
            })
          }
        }
      } catch (error) {
        console.error("Error during onstop: ", error)
      } finally {
        resetRecordingState()
      }
    }
    recorder.stop()
  } else {
    resetRecordingState()
  }
}

async function isMicAllowed() {
  let check = false
  try {
    if (!navigator.mediaDevices.getUserMedia)
      throw new Error("can't record mic")
    else {
      const micAudioStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      })

      if (micAudioStream) check = true
    }
  } catch (err) {
    console.error(err)
    check = false
  }
  return check
}

async function checkPermissionNstart(streamId, meetingUUID) {
  if (await isMicAllowed()) {
    await startRecording(streamId, meetingUUID)
  } else {
    await chrome.runtime.sendMessage({
      type: "no_mic_permission",
      data: streamId,
      meetingUUID: meetingUUID,
    })
  }
}

function resetRecordingState() {
  recorder = null
  recordedChunks = []
  isRecording = false
  if (tabAudioStream) {
    tabAudioStream.getTracks().forEach((track) => track.stop())
    tabAudioStream = null
  }
  if (micAudioStream) {
    micAudioStream.getTracks().forEach((track) => track.stop())
    micAudioStream = null
  }
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onloadend = () => {
      if (reader.result) {
        resolve(reader.result)
      } else {
        reject(new Error("Erreur de conversion du Blob en Base64"))
      }
    }
    reader.onerror = reject
    reader.readAsDataURL(blob)
  })
}
