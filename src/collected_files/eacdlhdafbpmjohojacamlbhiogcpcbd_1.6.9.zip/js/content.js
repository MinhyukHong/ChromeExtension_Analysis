document.addEventListener("DOMContentLoaded", function () {
  const allowedDomains = [
    "meet.google.com",
    "meet.ringover.io",
    "meet-v2.ringover.net",
    "teams.live.com",
    "teams.microsoft.com",
    "*.zoom.us",
  ]

  const MEETING_TYPE = {
    GOOGLE_MEET: "google meet",
    RINGOVER_MEET: "ringover meet",
    RINGOVER_MEET_V2: "ringover meet v2",
    TEAMS_PERSONAL: "teams(personal)",
    TEAMS_BUSINESS: "teams(business)",
    ZOOM: "zoom",
  }

  function getRegex(text) {
    const regexPattern = text.replace(/\./g, "\\.").replace(/\*/g, ".*")
    return new RegExp(`^${regexPattern}$`)
  }

  const allowedDomainsPattern = allowedDomains.map((domain) => {
    const regexPattern = getRegex(domain)
    return regexPattern
  })

  const currentDomain = window.location.hostname
  if (!allowedDomainsPattern.some((pattern) => pattern.test(currentDomain))) {
    return
  }

  chrome.runtime.sendMessage({
    action: "pageLoaded",
  })

  let micRecorder
  let micAudioChunks = []
  let meetRecorders = []
  let participantNameSet = new Set()
  let isRecording = false
  let div
  let isTimerVisible = true
  let audioBlobs = []
  let timerInterval
  let secondsElapsed = 0
  let isInGoogleMeet = false
  let meetingType = MEETING_TYPE.GOOGLE_MEET
  const segmentDuration = 60000
  let meetingUUID = ""
  let isManualStop = false

  let isUserLoggedIn = false

  let micBtnObserver = null

  function initializeDraggable() {
    const divElement = document.getElementById("my-custom-div")
    const dragHandle = document.getElementById("myimgdrog")

    if (divElement && dragHandle) {
      makeDivDraggable(divElement, dragHandle)
    }
  }

  function makeDivDraggable(divElement, dragHandle) {
    let pos1 = 0,
      pos2 = 0,
      pos3 = 0,
      pos4 = 0
    const pageWidth = window.innerWidth
    const pageHeight = window.innerHeight

    dragHandle.onmousedown = dragMouseDown

    function dragMouseDown(e) {
      e = e || window.event
      e.preventDefault()
      pos3 = e.clientX
      pos4 = e.clientY
      document.onmouseup = closeDragElement
      document.onmousemove = elementDrag
    }

    function elementDrag(e) {
      e = e || window.event
      e.preventDefault()
      pos1 = pos3 - e.clientX
      pos2 = pos4 - e.clientY
      pos3 = e.clientX
      pos4 = e.clientY

      let newTop = divElement.offsetTop - pos2
      let newLeft = divElement.offsetLeft - pos1

      if (newTop < 0) newTop = 0
      if (newLeft < 0) newLeft = 0
      if (newTop > pageHeight - divElement.offsetHeight)
        newTop = pageHeight - divElement.offsetHeight
      if (newLeft > pageWidth - divElement.offsetWidth)
        newLeft = pageWidth - divElement.offsetWidth

      divElement.style.top = newTop + "px"
      divElement.style.left = newLeft + "px"
    }

    function closeDragElement() {
      document.onmouseup = null
      document.onmousemove = null
    }
  }

  function rePosition() {
    const divElement = document.getElementById("my-custom-div")
    if (divElement) {
      const offset =
        divElement.getAttribute("data-state") === "recording" ? 170 : 90
      const offsetRight =
        window.innerWidth - (divElement.offsetLeft + divElement.offsetWidth)
      if (offsetRight < 0) {
        const newLeft = window.innerWidth - divElement.offsetWidth - offset
        divElement.style.left = newLeft + "px"
      }
    }
  }

  function get_tokens(callback) {
    chrome.storage.local.get(
      ["access_token_ext", "refresh_token_ext", "id_token_ext"],
      function (data) {
        var tokens = {
          access_token: data.access_token_ext,
          refresh_token: data.refresh_token_ext,
          id_token: data.id_token_ext,
        }
        callback(tokens)
      }
    )
  }

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "showDiv") {
      meetingType = request.meetingType
      get_tokens(function (tokens) {
        if (tokens.id_token) {
          isUserLoggedIn = true
          chrome.runtime.sendMessage(
            { action: "refreshTokenAuth" },
            function (response) {
              const requestTimestamp = new Date().toISOString()

              if (chrome.runtime.lastError) {
                console.error("Runtime error:", chrome.runtime.lastError)
                createDivWithNoToken()
                return
              }

              const responseTimestamp = new Date().toISOString()
              if (response && response.success) {
                isUserLoggedIn = true
                createDiv()
              } else {
                createDivWithNoToken()
              }

              chrome.runtime.sendMessage({ type: "divCreated" })
            }
          )
        } else {
          createDivWithNoToken()
          chrome.runtime.sendMessage({ type: "divCreated" })
        }
      })
    }
    if (request.action === "removeDiv") {
      removeDiv()
    }
    if (request.action === "startRecording" && !isRecording) {
      get_tokens(function (tokens) {
        if (tokens.id_token) {
          createDiv()
          startAllRecordings()
        } else {
          createDivWithNoToken()
        }
      })
    }

    if (request.action === "authSuccess" && isInGoogleMeet) {
      isUserLoggedIn = true
      updateDivContent()
    }

    if (request.action === "userLoggedOut") {
      handleUserLogout()
    }

    if (request.action === "recording_started") {
      recordingStarted()
      handleMicState()
    }

    if (request.action === "retrieve_participants") {
      if(isRecording) {
        let currentParticipantNames = retrieveParticipantNames()
        currentParticipantNames.forEach(name => participantNameSet.add(name));
      }
    }

    if(request.action === "check_if_in_meeting"){
      const isInMeeting = checkIfInMeeting(request.meetingType)
      sendResponse({ success: true, isInMeeting: isInMeeting, message: "in meeting" })
      return true
    }
  })

  function handleUserLogout() {
    isUserLoggedIn = false
    createDivWithNoToken()
  }

  function createDivWithNoToken() {
    injectFonts()
    if (!div) {
      div = document.createElement("div")
      div.id = "nologuser"
      div.style.position = "fixed"
      div.style.left = "1px"
      div.style.top = "40px"
      div.style.zIndex = "99999995"
      div.setAttribute("data-state", "nologuser")
      div.innerHTML = getSignInDivContent()

      document.body.appendChild(div)

      document
        .getElementById("sign-in-button")
        .addEventListener("click", handleNoLogUserClick)
      div.addEventListener("click", handleDivClickSwitchNoLog)

      initializeDraggable()
    } else {
      div.setAttribute("data-state", "nologuser")
      div.innerHTML = getSignInDivContent()
      attachEventHandlers()
    }
  }

  function handleDivClickSwitchNoLog(event) {
    event.stopPropagation()
    toggleDivContent()
  }

  function toggleDivContent() {
    const currentState = div.getAttribute("data-state")
    if (currentState === "nologuser") {
      div.setAttribute("data-state", "div-no-log")
    } else if (currentState === "div-no-log") {
      div.setAttribute("data-state", "nologuser")
    }
    updateDivContent()
  }

  function attachEventHandlers() {
    const divContent = div.querySelector(".detail")
    if (divContent) {
      divContent.onclick = divClickHandler
    }

    const stopButton = div.querySelector("#stop-button")
    if (stopButton) {
      stopButton.onclick = function () {
        stopButtonHandler()
      }
    }

    const recordButton = div.querySelector("#record-button")
    if (recordButton) {
      recordButton.onclick = async function () {
        checkPermissionNstart()
      }
    }

    const myimgdrog = div.querySelector("#myimgdrog")
    if (myimgdrog) {
      myimgdrog.onclick = function () {}
    }

    initializeDraggable()
  }

  function injectFonts() {
    const existingLink1 = document.querySelector(
      'link[href="https://fonts.googleapis.com"]'
    )
    const existingLink2 = document.querySelector(
      'link[href="https://fonts.gstatic.com"]'
    )
    const existingLink3 = document.querySelector(
      'link[href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap"]'
    )

    if (!existingLink1) {
      const link1 = document.createElement("link")
      link1.rel = "preconnect"
      link1.href = "https://fonts.googleapis.com"
      document.head.appendChild(link1)
    }

    if (!existingLink2) {
      const link2 = document.createElement("link")
      link2.rel = "preconnect"
      link2.href = "https://fonts.gstatic.com"
      link2.crossOrigin = "anonymous"
      document.head.appendChild(link2)
    }

    if (!existingLink3) {
      const link3 = document.createElement("link")
      link3.rel = "stylesheet"
      link3.href =
        "https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap"
      document.head.appendChild(link3)
    }
  }

  function updateDivContent() {
    const state = div ? div.getAttribute("data-state") : "ready-to-record"

    if (!div) {
      div = document.createElement("div")
      div.id = isUserLoggedIn ? "my-custom-div" : "nologuser"
      div.style.position = "fixed"
      div.style.left = "0"
      div.style.bottom = "0"
      div.style.zIndex = "99999995"
      document.body.appendChild(div)
    }

    if (state === "ready-to-record") {
      div.innerHTML = getReadyToRecordContent()
    } else if (state === "recording") {
      div.innerHTML = getRecordingDivContent()
    } else if (state === "meet") {
      div.innerHTML = getMeetDivContent()
    } else if (state === "nologuser") {
      div.innerHTML = getSignInDivContent()
    } else if (state === "div-no-log") {
      div.innerHTML = getNoLoginDivSwitch()
    }

    setTimeout(() => {
      attachEventHandlers()
      initializeDraggable()
    }, 100)
  }

  function getNoLoginDivSwitch() {
    return `
            <div class='tool pause' id='div-no-log'>
                <img id="myimgdrog" src="${chrome.runtime.getURL(
                  "assets/figma/six-dot.svg"
                )}" alt="menu" />
                <div class="detail">
                    <div class="detail-left">
                        <img src="${chrome.runtime.getURL(
                          "assets/figma/nolog.svg"
                        )}" alt="icon" />
                    </div>
                </div>
            </div>
        `
  }

  function getSignInDivContent() {
    return `
            <div class='tool sign-in is-hover'>
                <img id="myimgdrog" src="${chrome.runtime.getURL(
                  "assets/figma/six-dot.svg"
                )}" alt="menu" />
                <div class="detail">
                    <div class="detail-left">
                        <div class="ro-icon ro-u-text-danger" data-size="3xl">
                            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M6.9 4.80078C4.1938 4.80078 2 6.99458 2 9.70078V22.3008C2 25.007 4.1938 27.2008 6.9 27.2008H18.1C20.8062 27.2008 23 25.007 23 22.3008V22.0334L26.9608 24.0138C28.3571 24.712 30 23.6966 30 22.1355V9.86602C30 8.30492 28.3571 7.28959 26.9608 7.98773L23 9.96815V9.70078C23 6.99458 20.8062 4.80078 18.1 4.80078H6.9ZM7.81519 11.2607C6.92304 11.2607 6.1998 11.984 6.1998 12.8761V18.6915C6.1998 19.5837 6.92304 20.3069 7.81519 20.3069C8.70734 20.3069 9.43057 19.5837 9.43057 18.6915V12.8761C9.43057 11.984 8.70734 11.2607 7.81519 11.2607ZM11.3691 10.2921C11.3691 9.39999 12.0924 8.67676 12.9845 8.67676C13.8767 8.67676 14.5999 9.39999 14.5999 10.2921V21.2767C14.5999 22.1689 13.8767 22.8921 12.9845 22.8921C12.0924 22.8921 11.3691 22.1689 11.3691 21.2767V10.2921ZM18.1538 12.5537C17.2616 12.5537 16.5384 13.2769 16.5384 14.1691V17.3999C16.5384 18.292 17.2616 19.0152 18.1538 19.0152C19.0459 19.0152 19.7691 18.292 19.7691 17.3999V14.1691C19.7691 13.2769 19.0459 12.5537 18.1538 12.5537Z" fill="#8193A8"/>
                            </svg>
                        </div>
                    </div>
                    <div class="detail-center">
                          <p class="normal"><span class="semi-dark-ro-ext">Sign in</span> to use the Empower</p>
                          <p class="normal">Recorder extension</p>
                    </div>
                    <button id="sign-in-button" class="ro-btn detail-right ro-u-text-gradient-primary" data-variant="neumorphism" data-shape="rounded" data-size="lg">
                        <img src="${chrome.runtime.getURL(
                          "assets/figma/icon-login.svg"
                        )}" alt="icon login" class="ro-icon" data-size="lg" />
                        <span class="btn-text-product">Sign in</span>
                    </button>
                </div>
            </div>
        `
  }

  function handleNoLogUserClick(event) {
    event.stopPropagation()
    chrome.runtime.sendMessage(
      { action: "userNotLoggedIn" },
      function (response) {
        if (response.success) {
          isUserLoggedIn = true
          div.removeEventListener("click", handleNoLogUserClick)
          updateDivContent()
        } else {
          get_tokens(function (tokens) {})
          console.error("auth ok", response.message)
        }
      }
    )
  }

  function createDiv() {
    injectFonts()

    if (!div) {
      div = document.createElement("div")
      div.id = "my-custom-div"
      div.style.position = "fixed"
      div.style.left = "1px"
      div.style.top = "40px"
      div.style.zIndex = "99999995"
      div.setAttribute("data-state", "ready-to-record")
      document.body.appendChild(div)
      updateDivContent()
    } else {
      div.setAttribute("data-state", "ready-to-record")
      updateDivContent()
    }
  }

  function removeDiv() {
    if (div) {
      document.body.removeChild(div)
      div = null
    }
  }

  async function requestPermissionsAndStartRecording() {
    const meetingUUID = generateUUID()

    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        audio: true,
        video: true,
      })

      const audioTracks = stream.getAudioTracks()
      if (audioTracks.length === 0) {
        console.error("No audio tracks available in the stream")
        return
      }

      const audioStream = new MediaStream(audioTracks)
      const mimeType = "audio/webm"

      if (!MediaRecorder.isTypeSupported(mimeType)) {
        console.error(`MIME type ${mimeType} is not supported.`)
        return
      }

      const mediaRecorder = new MediaRecorder(audioStream, { mimeType })
      let recordedChunks = []

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunks.push(event.data)
        }
      }

      mediaRecorder.onstop = async () => {
        const blob = new Blob(recordedChunks, { type: mimeType })
        const base64data = await blobToBase64(blob)
        chrome.runtime.sendMessage({
          action: "uploadSegment",
          base64: base64data,
          name: `${meetingUUID}_${Date.now()}.webm`,
          meetingUUID: meetingUUID,
        })
        recordedChunks = []
        if (isRecording) {
          mediaRecorder.start(segmentDuration)
          setTimeout(() => {
            mediaRecorder.stop()
          }, segmentDuration)
        }
      }

      mediaRecorder.start(segmentDuration)
      setTimeout(() => {
        mediaRecorder.stop()
      }, segmentDuration)

      secondsElapsed = 0
      updateTimerDisplay()
      timerInterval = setInterval(() => {
        secondsElapsed++
        updateTimerDisplay()
      }, 1000)
    } catch (error) {
      console.error("Error starting audio capture: ", error)
    }
  }

  function redirectToProcessingPage() {
    const processingPageUrl = chrome.runtime.getURL("html/processing.html")
    window.open(processingPageUrl)
  }

  function divClickHandler(event) {
    if (event.target.closest("#recording-div")) {
      setTimeout(() => {
        div.innerHTML = getStopDivContent()
      }, 0)
      setTimeout(() => {
        attachEventHandlers()
      }, 100)
    }

    if (
      event.target.id !== "stop-button" &&
      event.target.id !== "myimgdrog" &&
      event.target.id !== "record-button"
    ) {
      toggleDivContent()
    }
    if (event.target.id !== "stop-button" && isRecording) {
      isTimerVisible = !isTimerVisible
      updateDivContent()
    }
    setTimeout(() => {
      rePosition()
    }, 50)
  }

  function getRecordingDivContent() {
    return `
            <div class='tool pause' id='recording-div'>
                <img id="myimgdrog" src="${chrome.runtime.getURL(
                  "assets/figma/six-dot.svg"
                )}" alt="menu" />
                <div class="detail">
                    <div class="detail-left">
                        <img src="${chrome.runtime.getURL(
                          "assets/figma/ringover-stop-icon.svg"
                        )}" alt="icon" />
                        <span style="color:#000000" id="timer-display">00:00</span>
                    </div>
                </div>
            </div>
        `
  }

  function toggleDivContent() {
    if (div.innerHTML.includes("Click the red button")) {
      div.innerHTML = getMeetDivContent()
      initializeDraggable()
    } else {
      div.innerHTML = getReadyToRecordContent()
    }
    setTimeout(() => {
      attachEventHandlers()
      initializeDraggable()
    }, 100)
  }

  function getMeetDivContent() {
    return `
            <div class='tool non-started'>
                <img id="myimgdrog" src="${chrome.runtime.getURL(
                  "assets/figma/six-dot.svg"
                )}" alt="menu" />
                <div class="detail">
                    <div class="detail-left">
                        <img src="${chrome.runtime.getURL(
                          "assets/figma/ringover-icon.svg"
                        )}" alt="icon" />
                    </div>
                </div>
            </div>
        `
  }

  function getReadyToRecordContent() {
    return `
            <div class='tool non-started is-hover'>
                <img id="myimgdrog" src="${chrome.runtime.getURL(
                  "assets/figma/six-dot.svg"
                )}" alt="menu" />
                <div class="detail">
                    <div class="detail-left">
                        <img src="${chrome.runtime.getURL(
                          "assets/figma/ringover-icon.svg"
                        )}" alt="icon" />
                    </div>
                    <div class="detail-center">
                        <p class="normal"><span class="dark-ro-ext">Click the red button</span> to</p>
                        <p class="normal">start recording</p>
                    </div>
                    <div class="detail-right">
                      <div class="circle1" id="record-button">
                        <div class="circle2">
                          <img src="${chrome.runtime.getURL(
                            "assets/figma/record.svg"
                          )}" alt="record" />
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        `
  }

  function getStopDivContent() {
    const currentUrl = window.location.href

    return `
            <div class='tool stop is-hover'>
                <img id="myimgdrog" src="${chrome.runtime.getURL(
                  "assets/figma/six-dot.svg"
                )}" alt="menu" />
                <div class="detail">
                    <div class="detail-left">
                        <img src="${chrome.runtime.getURL(
                          "assets/figma/ringover-stop-icon.svg"
                        )}" alt="icon" />
                        <span style="color:#000000" id="timer-display">00:00</span>
                    </div>
                    <div class="detail-center">
                        <span class="normal">Recording...</span>
                        <span id="meet_path_id" class="light">${currentUrl}</span>
                    </div>
                    <div class="detail-right">
                      <div class="circle1" id="stop-button">
                        <div class="circle2">
                          <img src="${chrome.runtime.getURL(
                            "assets/figma/stop.svg"
                          )}" alt="stop" />
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        `
  }

  function stopButtonHandler() {
    createAndShowStopConfirmationPopup()
  }

  function createAndShowStopConfirmationPopup() {
    const popup = document.createElement("div")
    popup.id = "stop-confirm-popup"
    popup.className = "container stop-recording"
    popup.style.position = "fixed"
    popup.style.top = "10px"
    popup.style.right = "10px"
    popup.style.zIndex = "99999999"
    popup.style.display = "block"
    popup.style.marginTop = "2rem"
    popup.style.background = "#FFF"
    popup.style.width = "352px"
    popup.style.display = "flex"
    popup.style.flexDirection = "column"
    popup.style.alignItems = "center"
    popup.style.padding = "20px"
    popup.style.gap = "28px"
    popup.style.boxShadow = "1px 6px 20px rgba(34, 34, 38, 0.05)"
    popup.style.borderRadius = "18px"

    popup.innerHTML = `
            <div class='container-header'>
                <div class="header">
                  <img src="${chrome.runtime.getURL(
                    "assets/figma/icon.svg"
                  )}" alt="icon" />
                  <h5>Empower Recorder</h5>
                </div>
                <div></div>
            </div>
            <div class="container-body">
                <span class="normal">Are you sure you want to stop recording?</span>
                <span class="light">Your recording will be saved in Empower.</span>
                <span class="error">An error occurred while processing the recording!</span>
            </div>
            <div class="container-footer">
                <div class="btn-extension-empower" id="confirm-stop">
                    <span>Stop recording</span>
                </div>
                <div class="btn-extension-empower light" id="cancel-stop">
                    <span>Cancel</span>
                </div>
            </div>
        `


    const confirmBtn = popup.querySelector("#confirm-stop")
    const cancelBtn = popup.querySelector("#cancel-stop")

    confirmBtn.onclick = async function (event) {
      event.stopPropagation()
      confirmBtn.querySelector('span').innerHTML = 'Processing...'
      confirmBtn.classList.add("loading")
      cancelBtn.classList.add("disabled")
      await stopAllRecordings(popup)
      resetRecordingState()
      updateDivContent()
      toggleDivContent()
    }

    cancelBtn.onclick = function (event) {
      event.stopPropagation()
      document.body.removeChild(popup)
    }

    document.body.appendChild(popup)
  }

  function hideRecordingDiv() {
    const recordingDiv = document.getElementById("my-custom-div")
    if (recordingDiv) {
      recordingDiv.style.display = "none"
    }
  }

  const MIC_BTN = {
    [MEETING_TYPE.GOOGLE_MEET]: {
      selector: 'button[jsname="BOHaEe"][data-is-muted]',
      attribute: "data-is-muted",
      key: "isMuted",
      value: {
        muted: "true",
        unmuted: "false",
      },
    },
    [MEETING_TYPE.TEAMS_PERSONAL]: {
      selector: "button#microphone-button[data-state]",
      attribute: "data-state",
      key: "state",
      value: {
        muted: "mic-off",
        unmuted: "mic",
      },
    },
    [MEETING_TYPE.TEAMS_BUSINESS]: {
      selector: "button#microphone-button[data-state]",
      attribute: "data-state",
      key: "state",
      value: {
        muted: "mic-off",
        unmuted: "mic",
      },
    },
    [MEETING_TYPE.RINGOVER_MEET]: {
      selector: "div.audio-preview > div > div[aria-pressed]",
      attribute: "aria-pressed",
      key: "ariaPressed",
      value: {
        muted: "true",
        unmuted: "false",
      },
    },
    [MEETING_TYPE.RINGOVER_MEET_V2]: {
      selector: 'div.meetroom-bottom-option-panel__center > div.action-frame > div:nth-child(1) > button:nth-child(1) > div',
      attribute: "class",
      key: "className",
      value: {
        muted: 'icon-svg red',
        unmuted: 'icon-svg white',
      },
    },
    [MEETING_TYPE.ZOOM]: {
      selector: "button.join-audio-container__btn[aria-label]",
      attribute: "aria-label",
      key: "ariaLabel",
      value: {
        muted: "unmute my microphone",
        unmuted: "mute my microphone",
      },
    },
  }

  function getAttributeValue(btn, btnDetails) {
    if (btnDetails.attribute.startsWith("aria-")) {
      return btn?.[btnDetails?.key]
    } else if (btnDetails.attribute.startsWith("data-")) {
      return btn?.dataset?.[btnDetails?.key]
    } else if (btnDetails.attribute.startsWith("title")) {
      return btn?.[btnDetails?.key]
    } else if (btnDetails.attribute.startsWith("class")) {
      return btn?.[btnDetails?.key]
    }
    return undefined
  }

  async function sendMicState() {
    let isMuted = false,
      micBtn = null

    if (Object.keys(MIC_BTN).includes(meetingType)) {
      if (meetingType === MEETING_TYPE.ZOOM) {
        const iframe = document.getElementById("webclient")
        const iframeDocument =
          iframe.contentDocument || iframe.contentWindow.document
        micBtn = iframeDocument.querySelector(MIC_BTN[meetingType].selector)
      } else {
        micBtn = document.querySelector(MIC_BTN[meetingType].selector)
      }
      if (micBtn) {
        isMuted =
          getAttributeValue(micBtn, MIC_BTN[meetingType]) ===
          MIC_BTN[meetingType].value.muted
            ? true
            : false
      }
    }

    await chrome.runtime.sendMessage({
      type: "mic_state",
      isMuted: isMuted,
      meetingUUID: meetingUUID,
    })

    return { micBtn, isMuted }
  }

  async function handleMicState() {
    const { micBtn, isMuted } = await sendMicState()
    if (micBtnObserver) {
      micBtnObserver?.disconnect?.()
      micBtnObserver = null
    }

    if (Object.keys(MIC_BTN).includes(meetingType)) {
      if (micBtn) {
        micBtnObserver = new MutationObserver((e) => {
          e.forEach((e) => {
            getAttributeValue(e.target, MIC_BTN[meetingType]) !== e.oldValue &&
              sendMicState()
          })
        })
        micBtnObserver.observe(micBtn, {
          attributes: true,
          attributeOldValue: true,
          attributeFilter: [MIC_BTN[meetingType].attribute],
        })
      }
    }
  }

  function checkPermissionNstart() {
    const isInMeeting = checkIfInMeeting(meetingType)
    if(isInMeeting){
      meetingUUID = generateUUID()
      chrome.runtime.sendMessage({
        type: "check_permission_and_start_recording",
        meetingUUID: meetingUUID,
      })
    } else {
      removeDiv()
    }
  }

  function recordingStarted() {
    isRecording = true
    div.setAttribute("data-state", "recording")

    updateDivContent()

    secondsElapsed = 0
    updateTimerDisplay()
    timerInterval = setInterval(() => {
      secondsElapsed++
      updateTimerDisplay()
    }, 1000)
  }

  function startAllRecordings() {
    meetingUUID = generateUUID()
    isRecording = true

    chrome.runtime.sendMessage({
      type: "start-recording-from-content",
      meetingUUID: meetingUUID,
    })

    updateDivContent()

    secondsElapsed = 0
    updateTimerDisplay()
    timerInterval = setInterval(() => {
      secondsElapsed++
      updateTimerDisplay()
    }, 1000)
  }

  function startObservingNewAudioElements() {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeName === "AUDIO" && node.srcObject) {
            node.srcObject.getTracks().forEach((track, trackIndex) => {
              startRecordingForTrack(track, 0, trackIndex)
            })
          }
        })
      })
    })

    observer.observe(document.body, { childList: true, subtree: true })
  }

  function updateTimerDisplay() {
    const timerDisplay = document.getElementById("timer-display")
    if (timerDisplay) {
      timerDisplay.textContent = formatTime(secondsElapsed)
    }
  }

  function formatTime(seconds) {
    const date = new Date(0)
    date.setSeconds(seconds)
    return date.toISOString().substr(11, 8)
  }

  async function stopAllRecordings(popup) {
    let currentParticipantNames = retrieveParticipantNames()
    currentParticipantNames.forEach(name => participantNameSet.add(name));

    chrome.runtime.sendMessage({
      type: "stop-recording-from-content",
      meetingUUID: meetingUUID,
    })
    chrome.runtime.sendMessage({
      action: "endOfRecording",
      meetingUUID: meetingUUID,
      duration: secondsElapsed,
      participantNames: [...participantNameSet],
    }, (response) => {
      if(response?.success) document.body.removeChild(popup)
      else {
    
        const confirmBtn = popup.querySelector("#confirm-stop")
        confirmBtn.classList.remove("loading")
        confirmBtn.classList.add("disabled")
        popup.querySelector(".container-body > span.light").style.display = 'none'
        popup.querySelector(".container-body > span.error").style.display = 'block'
        setTimeout(() => {
          document.body.removeChild(popup)
        }, 2000)
      }
    })
    clearInterval(timerInterval)
    isRecording = false
  }

  function startRecording() {
    chrome.tabCapture.capture({ audio: true, video: false }, (stream) => {
      if (stream) {
        mediaRecorder = new MediaRecorder(stream, { mimeType: "audio/webm" })
        recordedChunks = []
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            recordedChunks.push(event.data)
          }
        }
        mediaRecorder.onstop = () => {
          const audioBlob = new Blob(recordedChunks, { type: "audio/webm" })
          const reader = new FileReader()
          reader.readAsDataURL(audioBlob)
          reader.onloadend = function () {
            const base64data = reader.result
            chrome.runtime.sendMessage({
              action: "uploadSegment",
              base64: base64data,
              name: `${meetingUUID}.webm`,
              meetingUUID: meetingUUID,
            })
          }
        }
        mediaRecorder.start()
        setInterval(() => {
          if (mediaRecorder.state === "recording") {
            mediaRecorder.stop()
          }
        }, 60000)
      }
    })
  }

  function startMicRecording() {
    const micStreamId = "mic"

    navigator.mediaDevices
      .getUserMedia({ audio: true })
      .then((stream) => {
        micRecorder = new MediaRecorder(stream, { mimeType: "audio/webm" })
        micAudioChunks = []
        let audioSegmentCounter = 0

        micRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            micAudioChunks.push(event.data)
          }
        }

        micRecorder.onstop = async () => {
          if (micAudioChunks.length > 0) {
            const filename = createFileName(
              meetingUUID,
              micStreamId,
              audioSegmentCounter++
            )
            const audioBlob = new Blob(micAudioChunks, { type: "audio/webm" })
            micAudioChunks = []
            const reader = new FileReader()
            reader.readAsDataURL(audioBlob)
            reader.onloadend = function () {
              const base64data = reader.result
              chrome.runtime.sendMessage({
                action: "uploadSegment",
                base64: base64data,
                name: filename,
                meetingUUID: meetingUUID,
              })
            }
          }
          if (!isManualStop && isRecording) {
            micRecorder.start(segmentDuration)
          }
        }

        micRecorder.start(segmentDuration)
        setInterval(() => {
          if (micRecorder.state === "recording") {
            micRecorder.stop()
          }
        }, segmentDuration)
      })
      .catch((err) =>
        console.error("Erreur lors de l'accès au microphone:", err)
      )
  }

  function startRecordingForTrack(track, index, trackIndex) {
    const recordedData = []
    const stream = new MediaStream([track])
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: "audio/webm;codecs=opus",
    })

    mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        recordedData.push(event.data)
      }
    }

    mediaRecorder.onstop = async () => {
      if (recordedData.length > 0) {
        const audioBlob = new Blob(recordedData, { type: "audio/webm" })
        if (audioBlob.size > 0) {
          try {
            const filename = createFileName(meetingUUID, track.id, index)
            const base64data = await blobToBase64(audioBlob)
            chrome.runtime.sendMessage({
              action: "uploadSegment",
              base64: base64data,
              name: filename,
              meetingUUID: meetingUUID,
            })
          } catch (error) {
            console.error(
              "Erreur lors de la conversion du blob en base64",
              error
            )
          }
        }
      }
      meetRecorders = meetRecorders.filter(
        (recorder) => recorder !== mediaRecorder
      )
      if (!isManualStop && isRecording) {
        startRecordingForTrack(track, index, trackIndex)
      }
    }

    meetRecorders.push(mediaRecorder)
    mediaRecorder.start(segmentDuration)
    setTimeout(() => {
      if (mediaRecorder.state === "recording") {
        mediaRecorder.stop()
      }
    }, segmentDuration)
  }

  function startMeetRecording() {
    if (isRecording && meetRecorders.length > 0) {
      return
    }

    const audioElements = document.querySelectorAll("audio")
    audioElements.forEach((audio, index) => {
      if (audio.srcObject) {
        audio.srcObject.getTracks().forEach((track, trackIndex) => {
          startRecordingForTrack(track, index, trackIndex)
        })
      }
    })
  }

  function stopButtonHandler() {
    createAndShowStopConfirmationPopup()
  }

  function generateUUID() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (c) {
        var r = (Math.random() * 16) | 0,
          v = c === "x" ? r : (r & 0x3) | 0x8
        return v.toString(16)
      }
    )
  }

  function refreshTokenAndResendData(formData) {
    // return new Promise((resolve, reject) => {
    //     chrome.runtime.sendMessage({ action: "refreshTokenAuth" }, (responseFromBackground) => {
    //         if (responseFromBackground && responseFromBackground.success) {
    //             chrome.storage.local.get(['id_token_ext'], function (data) {
    //                 if (data.id_token_ext) {
    //                     sendData(data.id_token_ext, formData, true)
    //                         .then(resolve)
    //                         .catch(reject);
    //                 } else {
    //                     reject("token not found");
    //                 }
    //             });
    //         } else {
    //             reject("token non refresh");
    //         }
    //     });
    // });
  }

  function oauth_auth() {
    const sequence_verifier = new Uint8Array(32)
    for (let i = 0; 32 > i; i++)
      sequence_verifier[i] = Math.floor(255 * Math.random())
    const code_verifier = btoa(
      String.fromCharCode.apply(null, sequence_verifier)
    )
      .replace(/=/g, "")
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
    generate_code_challenge(code_verifier)
      .then((code_challenge) => {
        chrome.storage.local.set(
          {
            PCKE: code_verifier,
          },
          function () {
            const params = {
              client_id: "record_meet_app",
              scope: "API_V2_ALL",
              response_type: "code",
              redirect_uri: chrome.identity.getRedirectURL(),
              code_challenge_method: "S256",
              code_challenge,
            }
            let url = "https://auth.ringover.com/oauth2/authorize" + "?"
            for (let param in params) {
              url += param + "=" + params[param] + "&"
            }

            chrome.tabs.create({ url: encodeURI(url) })
          }
        )
      })
      .catch((e) => console.error(e))
  }

  function remove_token() {
    chrome.storage.local.remove([
      "id_token_ext",
      "refresh_token_ext",
      "access_token_ext",
      "user_id_ext",
      "user_name_ext",
      "is_auth",
    ])
  }

  function createSimpleObjectFromFormData(formData) {
    const object = {}
    for (const [key, value] of formData.entries()) {
      object[key] = value instanceof Blob ? value : value.toString()
    }
    return object
  }

  async function sendData(formData) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: "uploadAudio", formData: formData },
        function (response) {
          if (response && response.success) {
            resolve(response)
          } else {
            reject("Échec de l'envoi des données au background")
          }
        }
      )
    })
  }

  function formDataToObject(formData) {
    const object = {}
    for (const [key, value] of formData.entries()) {
      object[key] = value
    }
    return object
  }

  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onloadend = () => resolve(reader.result)
      reader.onerror = reject
      reader.readAsDataURL(blob)
    })
  }

  async function sendRecordingsToServer() {
    let participantNames = []
    const meetingId = generateUUID()

    let filesInfo = audioBlobs.map(({ name, blob }) => {
      return { name: `${meetingId}_${name}`, blob: blob }
    })

    let formDataObject = {
      files: filesInfo,
      participantNames: JSON.stringify(participantNames),
    }

    formDataObject.files = await Promise.all(
      formDataObject.files.map(async (file) => {
        return {
          name: file.name,
          base64: await blobToBase64(file.blob),
        }
      })
    )

    try {
      await sendData(formDataObject)
    } catch (error) {
      console.error(error)
    }
  }

  function stopMeetRecording() {
    meetRecorders.forEach((mediaRecorder, index) => {
      if (mediaRecorder.state === "recording") {
        mediaRecorder.stop()
      }
    })
    meetRecorders = []
  }

  function downloadAudio(blob, filename) {
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    a.click()
    window.URL.revokeObjectURL(url)
    a.remove()

    setTimeout(() => {
      redirectToProcessingPage()
    }, 10000)
  }

  function isValidParticipantName(name) {
    const invalidKeywords = [
      "mic_none",
      "arrow_drop_down",
      "checkDefault",
      "videocam",
      "inventory",
      "volume_up",
      "Tester",
    ]
    const maxLength = 30
    const minLength = 3
    const containsInvalidKeywords = invalidKeywords.some((keyword) =>
      name.includes(keyword)
    )
    const isLengthValid = name.length >= minLength && name.length <= maxLength

    return !containsInvalidKeywords && isLengthValid
  }

  function removeSuffix(name) {
    // Microsoft Teams
    const suffixes = [
      "Guest",
      "Unverified",
      "External",
      "Anonymous",
      "Federated",
      "Organizer",
      "Presenter",
    ]

    const regex = new RegExp(`\\s*\\((${suffixes.join("|")})\\)$`)

    return name.replace(regex, "").trim()
  }

  function retrieveParticipantNames() {
    let participantNames = []

    if (meetingType === MEETING_TYPE.GOOGLE_MEET) {
      let nameElements = document.querySelectorAll("div[jsslot] > div")
      nameElements.forEach((el) => {
        const name = el && el.innerText ? el.innerText.trim() : ""
        if (isValidParticipantName(name)) participantNames.push(name)
      })
    } else if (meetingType === MEETING_TYPE.RINGOVER_MEET) {
      const nomLocal = document.getElementById("localDisplayName")
      if (nomLocal) {
        participantNames.push(nomLocal.innerText)
      }
      const autresParticipants = document.querySelectorAll('[id*="_name"]')
      autresParticipants.forEach((participant) => {
        participantNames.push(participant.innerText)
      })
    } else if (meetingType === MEETING_TYPE.RINGOVER_MEET_V2) {
      const participantsContainer = document.querySelectorAll(
        "span.participant-display-name"
      )
      if (participantsContainer && participantsContainer.length > 0) {
        participantsContainer.forEach((participant) => {
          if (participant && participant.innerText) {
            participantNames.push(participant.innerText.trim())
          }
        })
      }
    } else if (meetingType === MEETING_TYPE.TEAMS_PERSONAL) {
      const participantsContainer = document.querySelectorAll(
        'div[data-tid="myself-video"] div[data-tid="participant-info"] > div:nth-of-type(1) > div:nth-of-type(1) > span:nth-of-type(1) span:nth-of-type(1), div[data-stream-type="Video"] div[data-tid="participant-info"] > div:nth-of-type(1) > div:nth-of-type(1) > span:nth-of-type(1) span:nth-of-type(1)'
      )

      if (participantsContainer && participantsContainer.length > 0) {
        participantsContainer.forEach((participant) => {
          if (participant && participant.innerText) {
            participantNames.push(removeSuffix(participant.innerText))
          }
        })
      } else {
        let selfName = ""

        let altText
        // for v1
        const selfImg = document.querySelector("img.user-picture")
        if (selfImg) {
          altText = selfImg.alt
        } else {
          // for v2
          const selfSpan = document.querySelector(
            'span[data-tid="me-control-avatar"]'
          )
          if (selfSpan) {
            altText = selfSpan.getAttribute("aria-label")
          }
        }

        if (altText) {
          const regex = /Profile picture of (.+)\./
          const match = altText.match(regex)

          // if not logged in -> guest
          selfName = match ? match[1] : ""
        }

        if(selfName){
          participantNames.push(selfName)
        }
      }
    } else if (meetingType === MEETING_TYPE.TEAMS_BUSINESS) {
      const participantsContainer = document.querySelectorAll(
        'div[data-tid="myself-video"] div[data-tid="participant-info"] > div:nth-of-type(1) > div:nth-of-type(1) > span:nth-of-type(1) span:nth-of-type(1), div[data-stream-type="Video"] div[data-tid="participant-info"] > div:nth-of-type(1) > div:nth-of-type(1) > span:nth-of-type(1) span:nth-of-type(1)'
      )

      if (participantsContainer && participantsContainer.length > 0) {
        participantsContainer.forEach((participant) => {
          if (participant && participant.innerText) {
            participantNames.push(removeSuffix(participant.innerText))
          }
        })
      } else {
        const selfSpan = document.querySelector(
          'span[data-tid="me-control-avatar"]'
        )
        if (selfSpan) {
          const altText = selfSpan.getAttribute("aria-label")
          if (altText) {
            const regex = /Profile picture of (.+)\./
            const match = altText.match(regex)

            const selfName = match ? match[1] : ""
            if(selfName){
              participantNames.push(selfName)
            }
          }
        }
      }
    } else if (meetingType === MEETING_TYPE.ZOOM) {
      const iframe = document.getElementById("webclient")
      const iframeDocument =
        iframe.contentDocument || iframe.contentWindow.document
      const participantsContainer = iframeDocument.querySelectorAll(
        "div.video-avatar__avatar-footer > span"
      )
      if (participantsContainer && participantsContainer.length > 0) {
        participantsContainer.forEach((participant) => {
          if (participant && participant.innerText) {
            participantNames.push(participant.innerText.trim())
          }
        })
      }
    }

    return participantNames
  }

  function resetRecordingState() {
    meetingUUID = ""
    isRecording = false
    secondsElapsed = 0
    micAudioChunks = []
    audioBlobs = []
    meetRecorders = []
    participantNameSet.clear()
    div.setAttribute("data-state", "ready-to-record")
  }

  const END_BTN = {
    [MEETING_TYPE.GOOGLE_MEET]: {
      selector: 'button[jsname="CQylAd"]'
    },
    [MEETING_TYPE.TEAMS_PERSONAL]: {
      selector: 'div#hangup-button'
    },
    [MEETING_TYPE.TEAMS_BUSINESS]: {
      selector: 'div#hangup-button'
    },
    [MEETING_TYPE.RINGOVER_MEET]: {
      selector: 'div.hangup-button'
    },
    [MEETING_TYPE.RINGOVER_MEET_V2]: {
      selector: 'button.hand-up'
    },
    [MEETING_TYPE.ZOOM]: {
      selector: "div.footer__leave-btn-container",
    },
  }

  function isEndBtnVisible (meetingType) {
    let endBtn
    if (Object.keys(END_BTN).includes(meetingType)) {
      if (meetingType === MEETING_TYPE.ZOOM) {
        const iframe = document.getElementById("webclient")
        if(iframe){
          const iframeDocument =
            iframe.contentDocument || iframe.contentWindow.document
          endBtn = iframeDocument.querySelector(END_BTN[meetingType].selector)
        }
      } else {
        endBtn = document.querySelector(END_BTN[meetingType].selector)
      }
    }

    return !!endBtn
  }
  
  function checkIfInMeeting(meetingType) {
    return isEndBtnVisible(meetingType)
  }

  window.addEventListener('beforeunload', function (e) {
    if (div && div.getAttribute("data-state") === "recording" && secondsElapsed > 0) {
      e.preventDefault();
      e.returnValue = '';
      return;
    }
  });
})
