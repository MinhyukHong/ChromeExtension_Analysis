document.addEventListener("DOMContentLoaded", function () {
  const urlParams = new URLSearchParams(window.location.search);
  const meetingUUID = urlParams.get('meetingUUID')

  function getMicrophoneSettingsUrl() {
    let userAgent = navigator.userAgent.toLowerCase()
    let url = ""

    console.log(userAgent)

    if (
      userAgent.includes("chrome") &&
      !userAgent.includes("edg") &&
      !userAgent.includes("opr") &&
      !userAgent.includes("brave") &&
      !userAgent.includes("arc")
    ) {
      url = "chrome://settings/content/microphone?search=microphone"
    } else if (userAgent.includes("firefox")) {
      url = "about:preferences#privacy"
    } else if (userAgent.includes("safari") && !userAgent.includes("chrome")) {
      url = "safari://preferences"
    } else if (userAgent.includes("edg")) {
      url = "edge://settings/content/microphone"
    } else if (userAgent.includes("opr") || userAgent.includes("opera")) {
      url = "opera://settings/content/microphone"
    } else if (userAgent.includes("brave")) {
      url = "brave://settings/content/microphone"
    } else if (userAgent.includes("arc")) {
      url = "arc://settings/content/microphone"
    } else {
      url = "Microphone settings URL not available for this browser."
    }

    return url
  }

  async function isMicAllowed() {
    let check = false
    try {
      if (!navigator.mediaDevices.getUserMedia)
        throw new Error("can't record mic")
      else {
        const micAudioStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: false,
        })

        if (micAudioStream) check = true
      }
    } catch (err) {
      console.error(err)
      check = false
    }
    return check
  }

  let requestSent = false

  async function checkAccess() {
    document.getElementById("access_request").style.display = "flex"
    document.getElementById("access_blocked").style.display = "none"
    if (await isMicAllowed()) {
      if (!requestSent) {
        requestSent = true
        await chrome.runtime.sendMessage({
          type: "got_mic_permission",
          meetingUUID: meetingUUID,
        })
      }
      window.close()
    } else {
      document.getElementById("access_request").style.display = "none"
      document.getElementById("access_blocked").style.display = "flex"
      const microphoneSettingsUrl = getMicrophoneSettingsUrl()
      const micLink = document.getElementById("microphone_link")
      micLink.innerHTML = microphoneSettingsUrl
      const copyBtn = document.getElementById("copy")
      copyBtn.onclick = function () {
        const input = document.createElement("input")

        input.setAttribute("value", microphoneSettingsUrl)
        document.body.appendChild(input)
        input.select()
        const result = document.execCommand("copy")
        document.body.removeChild(input)

        const copyText = document.getElementById("copy_text")
        copyText.innerHTML = "Copied!"
        setTimeout(() => {
          copyText.innerHTML = "Copy"
        }, 2000)

        return result
      }
    }
  }

  window.addEventListener("focus", checkAccess)

  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible") {
      checkAccess()
    }
  })

  if (document.hasFocus()) {
    checkAccess()
  }
})
