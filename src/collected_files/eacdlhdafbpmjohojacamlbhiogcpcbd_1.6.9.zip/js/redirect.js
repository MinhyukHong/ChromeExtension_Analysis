document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search)
    const error = urlParams.get('error')

    const invalidError = ['', 'undefined', 'null']

    if(error){
        const errorP = document.querySelector('p.error')
        if(errorP){
            if(!invalidError.includes(error)) errorP.innerHTML = error
            errorP.style.display = 'block'
        }
    }
})
  