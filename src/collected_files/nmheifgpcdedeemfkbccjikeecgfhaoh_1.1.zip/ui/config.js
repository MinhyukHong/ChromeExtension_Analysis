const configKey = 'IMConfig';
const Debug = false;

const services = {
    "OpenAI": "https://api.openai.com/v1/embeddings",
    "Azure": "https://<deployment_url>.openai.azure.com/openai/deployments/text-embedding-ada-002/embeddings?api-version=2023-05-15",
    "Default": "https://api.novelsec.com/v1/embeddings"
}

async function clearStorage() {
  await chrome.storage.local.clear(function() {
    console.log('Storage cleared!');
  });
}

if (Debug) {
  clearStorage();
}

async function getStorageItem(item) {
	return await chrome.storage.local.get(item);
}

async function setStorageItem(item, data) {
	await chrome.storage.local.set({[item]: data});
}

// get random api key
async function getApiKey() {
  let defaultkey = getStorageItem('DefaultKey');
  if (defaultkey['DefaultKey']) {
    return defaultkey['DefaultKey']; 
  } else {
    defaultkey = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    setStorageItem('DefaultKey', defaultkey);
    return defaultkey;
  }
}

async function getConfig() {
    let config;
    // Get from localStorage  
    const storage = await chrome.storage.local.get(configKey);
    if(storage[configKey]) {
      config = storage[configKey];
      config.fromStorage = true;
    } else {
      // Default config
      config = {
        apiUrl: services['Default'],
        //get random guid
        apiKey: await getApiKey(),
        service: 'Default',
        apiTimeout: 50,
        historyLength: 100,
        fromStorage: false
      };
    }
    return config;
}

async function saveConfig() { 
  const config = { 
      apiUrl: document.getElementById('apiUrl').value, 
      apiKey: document.getElementById('apiKey').value, 
      apiTimeout: document.getElementById('apiTimeout').value, 
      service: document.getElementById('service').value, 
      historyLength: document.getElementById('historyLength').value 
  }; 
  await chrome.storage.local.set({[configKey]: config});
  console.log('Config saved'); 
} 

function renderSelect(config) {
  const select = document.querySelector('select');
  // Clear existing options
  select.innerHTML = '';
  // Loop options and add
  for(let name in services) {
    const option = document.createElement('option');
    option.value = name;
    option.text = name;
    if(option.text == config.service) {
      option.selected = true;
    }
    select.appendChild(option);
  }
  //fill api url and key
  document.getElementById('apiUrl').value = config.apiUrl;
  document.getElementById('apiKey').value = config.apiKey;
  document.getElementById('apiTimeout').value = config.apiTimeout;
  document.getElementById('historyLength').value = config.historyLength;
}

async function onServiceChange() {
  const service = document.querySelector('#service').value;
  const urlInput = document.querySelector('#apiUrl');
  urlInput.value = services[service];
  if(service == 'Default') {
    document.querySelector('#apiKey').value = await getApiKey();
    document.querySelector('#apiKey').disabled = true;
    document.querySelector('#apiTimeout').value = 400;
    document.querySelector('#apiTimeout').disabled = true;
  }
  else {
    document.querySelector('#apiKey').value = '<api_key> or <token>';
    document.querySelector('#apiKey').disabled = false;
    document.querySelector('#apiTimeout').disabled = false;
  }
}

async function init() {
  let config = await getConfig();
  renderSelect(config);
  return config;
}

const config = init();

window.addEventListener('beforeunload', function (e) {
  e.preventDefault();
  if (config.fromStorage) {
    return;
  }
  saveConfig();
});

const saveBtn = document.getElementById('saveBtn'); 
saveBtn.addEventListener('click', saveConfig); 
document.querySelector('#service').addEventListener('change', onServiceChange);

saveBtn.addEventListener('mousedown', () => {
    saveBtn.style.background = 'darkblue';
});
  
  saveBtn.addEventListener('mouseup', () => {
    saveBtn.style.background = 'royalblue';  
});


