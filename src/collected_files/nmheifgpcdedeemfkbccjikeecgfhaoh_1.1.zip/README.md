# IntelliMark
Intelliget bookmark search using LLMs
