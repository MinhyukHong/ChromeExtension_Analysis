import { getData } from "./utils.js";


/// An Embedding class to get the config and get embedding
export class Embedding {
  constructor(apiKey, apiUrl, apiTimeout, service) {
    this.apiKey = apiKey;
    this.apiUrl = apiUrl;
    this.apiTimeout = apiTimeout;
    this.service = service;
  }

  async getEmbeddings(titles) {
    // Configure request
    let headers = {'content-Type': 'application/json'};
    let bodyo = {input: titles};
    if (this.service == 'Azure' || this.service == 'Default') {
      headers['api-key'] = this.apiKey;
    } 
    else if (this.service == 'OpenAI') {
      headers['Authorization'] = 'Bearer ' + this.apiKey;
      bodyo['model'] = 'text-embedding-ada-002';
    } 
    else {
      throw new Error('Unknown service');
    }
    const body = JSON.stringify(bodyo);
    return await getData(this.apiUrl, headers, body);
  }

  dotp(x, y) {
    function dotp_sum(a, b) {
      return a + b;
    }
    function dotp_times(a, i) {
      return x[i] * y[i];
      //return x[i] * y[i];
    }
    try {
      return x.map(dotp_times).reduce(dotp_sum, 0);
    } catch (err) {
      console.log(err);
    }
  }
  
  cosineSimilarity(A,B) {
    var similarity = this.dotp(A, B) / (Math.sqrt(this.dotp(A,A)) * Math.sqrt(this.dotp(B,B)));
    return similarity;
  }
  
  findMostSimilarIds(inputVector, vectors, topn=5) {
    const similarities = Object.entries(vectors).map(([id, item]) => {
      if (item.embedding !== undefined) {
        return {
          id,
          similarity: this.cosineSimilarity(inputVector, item.embedding)  
        };
      }
    });
    similarities.sort((a, b) => b.similarity - a.similarity);
    return similarities.slice(0,topn).map(({id}) => id);
  }
  
}

