// storage.js
export const ignoreItems = [
	'www.google.com',
	'www.bing.com',
	'www.yahoo.com',
	'www.baidu.com',
];

export async function getStorage() {
	return await chrome.storage.local.get();
}

export async function getStorageItem(item) {
	return await chrome.storage.local.get(item);
}

export async function setStorageItem(item, data) {
	await chrome.storage.local.set({[item]: data});
}

export async function setStorage(data) {
	await chrome.storage.local.set(data);
}

export async function getConfig(configKey) {
    let config = undefined;
    // Get from localStorage  
    const storage = await getStorageItem(configKey);
    if(storage[configKey]) {
      config = storage[configKey];
    }
    return config;
}

export async function getData(url, headers, body) {
	try {
	  const response = await fetch(url, {
		method: 'POST', 
		headers: headers,
		body: body
	  });
	  if(!response.ok) {
		throw new Error('Request failed');
	  }
	  const respj = await response.json();
	  return respj.data;
	} catch (err) {
	  console.error('Error:', err);
	  throw err;
	}
}

function flattenBookmarks(bmtree, allBookmarks) {
    for (let i = 0; i < bmtree.length; i++) {
        const bookmark = bmtree[i];
        if (bookmark.url) {
            allBookmarks[`b${bookmark.id}`] = {
                title: bookmark.title.toLowerCase(),
                url: bookmark.url,
				type: 'bookmark',
				//icon: bookmark.favicon
            };
            //console.log("bookmark: " + bookmark.title + " ~  " + bookmark.url + " ~  " + bookmark.parentId);
        }
        if (bookmark.children) {
            flattenBookmarks(bookmark.children, allBookmarks);
        }
    }
}

export async function getBookmarks() {
	let allBookmarks = {};
	let bmtree = await chrome.bookmarks.getTree();
	flattenBookmarks(bmtree, allBookmarks);
	return allBookmarks;
}

//added
export async function getOpenTabs() {
	let openTabs = {};
	let tabs = await chrome.tabs.query({});
	for (let i = 0; i < tabs.length; i++) {
		const tab = tabs[i];
		openTabs[`t${tab.id}`] = {
			title: tab.title.toLowerCase(),
			url: tab.url,
			type: 'tab',
			//icon: tab.favicon
		};
	}
	return openTabs;
}

export async function getHistory() {
	let allHistory = {};
	let history = await chrome.history.search({text: '', maxResults: 1000});
	for (let i = 0; i < history.length; i++) {
		const item = history[i];
		allHistory[`h${item.id}`] = {
			title: item.title.toLowerCase(),
			url: item.url,
			type: 'history',
			//icon: item.favicon
		};
	}
	return allHistory;
}

export function item2code(item) {
	// Get url short 
	let urlsh = item.url;
	urlsh = urlsh.replace('http://', '');
	urlsh = urlsh.replace('https://', '');
	urlsh = urlsh.replace('www.', '');
	// replace the domain extension in the url with a single space, check the end of it to make sure it ends with / or ?
	urlsh = urlsh.replace(/\.[a-z]{2,3}(\/|\?|$)/g, ' ');
	// replace all numberical digits and special characters with a single space
	urlsh = urlsh.replace(/[^a-zA-Z]/g, ' ');
	urlsh = urlsh.replace(/\s\s+/g, ' ');
	urlsh = urlsh.trim();
	// limit the url to first 15 words
	urlsh = urlsh.split(' ').slice(0, 15).join(' ');

	// Extract urlsh
	//urlsh = urlsh.split('/')[0];
	return item.title + ' ' + urlsh;
}

export function escapeXML(str){
	return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

