import { getStorage, getBookmarks, getOpenTabs, getHistory, setStorage, setStorageItem, item2code, escapeXML, getConfig, ignoreItems } from './utils.js';
import { TimeoutQueue } from './queue.js';
import { Embedding } from './embedding.js';

let allItems = {};
let previous_searches = new Map();
let config;
let queue = undefined;
async function getAllConfig() {
	config = await getConfig('IMConfig');
}
getAllConfig();
let embeddingo;

async function check_add_embedding(id, item, storedEmbedding, force=false) {
	if (id in allItems && allItems[id].embedding !== undefined && !force) {
		return;
	}
	if (!check_item_is_valid(item))
		return;
	// check if id is in allItems and if not, add item
	allItems[id] = item;
	if (id in storedEmbedding && item.embedding === undefined && !force ) {
		allItems[id].embedding = storedEmbedding[id];
	} else {
		if (item.embedding === undefined) {
			let code = item2code(item);
			// call the api to get the embedding with timeout
			const task = { fn: async () => { return await embeddingo.getEmbeddings([code]); } };
			const embeddings = await queue.enqueue(task);
			allItems[id].embedding = embeddings[0].embedding;
		}
		setStorageItem(id, allItems[id].embedding);
		console.log('Value set', id, ": ", allItems[id].url);
	}
}

async function init() {
	config = await getConfig('IMConfig');
	if (config === undefined || config.apiKey === undefined) {
		return;
	}

	embeddingo = new Embedding(config.apiKey, config.apiUrl, config.apiTimeout, config.service);
	queue = new TimeoutQueue(0, config.apiTimeout);
	allItems = await getBookmarks();
	const openTabs = await getOpenTabs();
	const history = await getHistory();
	allItems = {...allItems, ...openTabs, ...history};
	const storedEmbedding = await getStorage();
	
	for(let [id, item] of Object.entries(allItems)) { 
		// check if embedding already exists otherwise get the embedding
		await check_add_embedding(id, item, storedEmbedding, false);
	}
}

function openConfigPage() {
	chrome.tabs.create({url: 'ui/config.html'});
}

chrome.runtime.onInstalled.addListener(details => {
    // runs on first install/update
	if(details.reason === 'install' || details.reason === 'update') {
		openConfigPage();
		return;
	}
	init();
});

chrome.runtime.onStartup.addListener(() => {
	init();
});

chrome.omnibox.setDefaultSuggestion({
    description: 'Describe the website you are looking for!'
});

chrome.storage.onChanged.addListener((changes, namespace) => {
	for (let [key, { oldValue, newValue }] of Object.entries(changes)) {
		if (key === 'IMConfig') {
			console.log('init db!')
			init();
		}
	}
});

init();
let timer;
chrome.omnibox.onInputChanged.addListener((text, suggest) => {
	text = text.trim();
	if (text.length < 5) return;
	let suggestions = [];
	if (previous_searches.has(text)) {
		suggestions = previous_searches.get(text);
		// get the first element of suggestions and check if it is older than 1 day
		let el = suggestions.shift();
		if (new Date(el.date) > new Date(new Date().getTime() - 60 * 1000)) {
			suggest(suggestions);
			return;
		}
	}
	if (previous_searches.size > 20) {
		el = previous_searches.entries().next().value[0];
		previous_searches.delete(el);
	}
	clearTimeout(timer);
	if (config === undefined || config.apiKey === undefined) {
		return;
	}
	embeddingo = new Embedding(config.apiKey, config.apiUrl, config.apiTimeout, config.service);
	// check length of allBookmarks
	if (Object.keys(allItems).length < 2) {
		console.log('No items added yet!');
		return;
	}
	timer = setTimeout(() => {
		embeddingo.getEmbeddings([text]).then(embeddings => {
			// get the list of embeddings from allItems
			const ids = embeddingo.findMostSimilarIds(embeddings[0].embedding, allItems, 20);
			let urls = {}; //list to check for possible duplicates among tabs, history and bookmarks
			for (const i in ids) {
				const id = ids[i];
				let url = allItems[id].url;
				if (allItems[id].url.endsWith('/')) {
					url = allItems[id].url.substring(0, url.length - 1);
				}
				if (url in urls) { // if duplicate, prioritize tab over bookmakr over history
					if (allItems[id].type === 'tab') 
						urls[url].type = 'tab';
					else if (urls[url].type === 'history' && allItems[id].type === 'bookmark') 
						urls[url].type = 'bookmark';
					else
						continue;
					urls[url].id = id;
					continue;
				}
				urls[url] = {
					id: id,
					type: allItems[id].type
				}
			}
			// create a list of urls from ids
			suggestions = [];
			for (const i in ids) {
				const id = ids[i];
				let url = allItems[id].url;
				if (allItems[id].url.endsWith('/')) {
					url = allItems[id].url.substring(0, url.length - 1);
				}
				// check if duplicate, if so prioritize tab over bookmakr over history
				if (url in urls && urls[url].id !== id) {
					if ((allItems[id].type === 'history') || (allItems[id].type === 'bookmark' && urls[url].type === 'tab'))  {
						continue;
					}
				}
				let pushitem = {
					content: allItems[id].url, 
					description: allItems[id].type + ': ' + escapeXML(allItems[id].title)
				};
				if (allItems[id].type === 'tab') {
					pushitem.content = `#${id}:` + pushitem.content;
				}
				suggestions.push(pushitem);
			}
			suggest(suggestions);
			suggestions.unshift({date: new Date().toISOString()});
			previous_searches.set(text, suggestions);
		});
		
	}, 500);
});


chrome.omnibox.onInputEntered.addListener((text, disposition) => {
    if (!text.startsWith('#')) {
  		chrome.tabs.update(null, {url: text}); 
	} else {
		const id = text.split(':')[0].substring(2);
		chrome.tabs.update(parseInt(id), {active: true, highlighted: true});
	}
  init();
});

function check_item_is_valid(item) {
	if (item.url === undefined || item.title === undefined || item.url === '' || item.title === '' || item.title.toLowerCase() === 'new tab') {
		return false;
	}
	// filter if the url is not proper domain like chrome://
	if (!item.url.includes('http://') && !item.url.includes('https://')) {
		return false;
	}
	let checkurl = item.url.replace('http://', '');
	checkurl = checkurl.replace('https://', '');
	// split the url by : and take the first part
	checkurl = checkurl.split(':')[0];
	//check if checkurl is in the ignoreItems list
	if (ignoreItems.includes(checkurl.split(':')[0]) || ignoreItems.includes(checkurl.split('/')[0])) {
		return false;
	}
	return true;
}

chrome.bookmarks.onCreated.addListener(function(id, bookmark) {
	if (!check_item_is_valid(bookmark))
		return;
	const item = {
		title: bookmark.title.toLowerCase(),
		url: bookmark.url,
		type: 'bookmark',
	};
	check_add_embedding(`b${id}`, item, allItems, false);
});

chrome.bookmarks.onChanged.addListener(function(id, changeInfo) {
	if (!check_item_is_valid(changeInfo))
		return;
	const item = {
		title: changeInfo.title.toLowerCase(),
		url: changeInfo.url,
		type: 'bookmark',
	};
	check_add_embedding(`b${id}`, item, allItems, true);
});

chrome.bookmarks.onRemoved.addListener(function(id, removeInfo) {
	delete allItems[`b${id}`];
});

let effectedtab = {};//to keep track of tabs and history duplicates - less call to api

chrome.tabs.onCreated.addListener(function(tab) {
	if (!check_item_is_valid(tab)) 
		return;
	const item = {
		title: tab.title.toLowerCase(),
		url: tab.url,
		type: 'tab',
	};
	check_add_embedding(`t${tab.id}`, item, allItems);
	effectedtab = {id: tab.id, embedding: allItems[`t${tab.id}`].embedding, url: tab.url};
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
	if (!check_item_is_valid(tab))
		return;
	if (`t${tabId}` in allItems && tab.url === allItems[`t${tabId}`].url) 
		return;
	let newitem = true;
	if (`t${tabId}` in allItems && allItems[`t${tabId}`].embedding !== undefined) {
		effectedtab = {id: tabId, embedding: allItems[`t${tabId}`].embedding, url: allItems[`t${tabId}`].url };
		newitem = false;
	}
	const item = {
		title: tab.title.toLowerCase(),
		url: tab.url,
		type: 'tab',
	};
	check_add_embedding(`t${tab.id}`, item, allItems, true);
	if (newitem)
		effectedtab = {id: tab.id, embedding: allItems[`t${tab.id}`].embedding, url: tab.url};
});

chrome.tabs.onRemoved.addListener(function(tabId, removeInfo) {
	if (`t${tabId}` in allItems) {
		console.log('Tab removed t', tabId, ': ', allItems[`t${tabId}`].url);
		delete allItems[`t${tabId}`];
	}
});

chrome.history.onVisited.addListener(function(historyItem) {
	if (!check_item_is_valid(historyItem)) 
		return;
	const item = {
		title: historyItem.title.toLowerCase(),
		url: historyItem.url,
		type: 'history',
	};
	if (effectedtab!== undefined && effectedtab.url === historyItem.url) {
		item.embedding = effectedtab.embedding;
	}
	check_add_embedding(`h${historyItem.id}`, item, allItems);
});

