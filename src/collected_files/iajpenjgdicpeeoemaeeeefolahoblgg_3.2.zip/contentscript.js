$('[data-tracking-action="entretenimento"]').each(function(){
    $(this).html("<h3 class='highlight-font-title-column  homeui-tc-entretenimento'>Protegido pelo Globo Sem Besteirol</h3>");
});