//background.js
chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.open({
      tabId: tab.id
  });

  if (!tab.url.startsWith('chrome://')) {
      chrome.scripting.executeScript({
          target: { tabId: tab.id },
          function: getSelectedText,
      });
  } else {
      console.log("Cannot execute script on chrome:// page");
      // Optionally, inform the user that the action is not available on this page.
  }
});

function getSelectedText() {
  const selection = window.getSelection().toString();
  chrome.runtime.sendMessage({ message: "selectedText", text: selection });
}