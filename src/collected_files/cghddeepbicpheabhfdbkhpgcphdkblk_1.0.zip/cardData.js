const allCardData = [
    {id:1,imageUrl:'./images/eeg.png',
        text:'Master EEG interpretation from beginner to expert',
        description:'A step-by-step EEG curriculum for medical students, residents, and neurologists.covering neurophysiology, normal/abnormal patterns, epilepsy, encephalopathy, critical care, pediatric EEG, video-EEG monitoring,',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            "Introduction to EEG and Neurophysiology": [
                "What is EEG?",
                "History and Clinical Applications of EEG",
                "Basic Neurophysiology: Neuronal Activity and Synaptic Transmission",
                "Generation of Electrical Potentials in the Brain",
                "Anatomy of the Brain Relevant to EEG",
                "Thalamocortical Interactions",
                "EEG Equipment and Setup",
                "Electrodes and the 10-20 System",
                "Montages: Bipolar vs. Referential",
                "Instrumentation and Signal Processing"
            ],
            "Normal EEG Patterns and Variants": [
                "Normal Adult EEG: Alpha, Beta, Theta, and Delta Rhythms",
                "Normal Sleep Architecture: Stages 1–4 and REM Sleep",
                "Normal Variants: Mu Rhythm, Lambda Waves, and Vertex Sharp Waves",
                "Age-Related Changes in EEG: Neonates, Children, and Elderly",
                "Artifacts: Physiological and Non-Physiological",
                "Techniques to Identify and Minimize Artifacts"
            ],
            "Abnormal EEG Patterns": [
                "Epileptiform Activity: Spikes, Sharp Waves, and Spike-Wave Complexes",
                "Focal vs. Generalized Epileptiform Discharges",
                "Non-Epileptiform Abnormalities: Focal and Generalized Slowing",
                "Asymmetries and Asymmetrical Patterns",
                "Case Examples: Differentiating Normal vs. Abnormal EEG"
            ],
            "EEG in Epilepsy": [
                "Classification of Seizures: Focal vs. Generalized",
                "EEG Correlates of Different Seizure Types",
                "Interictal EEG: Identifying Epileptiform Discharges",
                "Ictal EEG: Patterns During Seizures",
                "Common Epilepsy Syndromes: Temporal Lobe Epilepsy, Lennox-Gastaut Syndrome, West Syndrome",
                "EEG in Status Epilepticus: Convulsive and Non-Convulsive",
                "Case-Based Learning: EEG Interpretation in Epilepsy"
            ],
            "EEG in Encephalopathy and Coma": [
                "EEG Patterns in Encephalopathy: Triphasic Waves, Burst-Suppression, Generalized Periodic Discharges",
                "EEG in Coma: Alpha Coma, Theta Coma, Spindle Coma",
                "Prognostic Significance of EEG in Coma",
                "Case Studies: EEG Interpretation in Encephalopathy and Coma"
            ],
            "EEG in Critical Care": [
                "Continuous EEG Monitoring in the ICU",
                "Detection of Non-Convulsive Seizures",
                "EEG in Hypoxic-Ischemic Encephalopathy: Prognostic Patterns",
                "EEG in Brain Death: Criteria for Electrocerebral Inactivity",
                "Case-Based Learning: EEG in Critical Care"
            ],
            "Pediatric EEG": [
                "Neonatal EEG: Normal and Abnormal Patterns",
                "EEG in Hypoxic-Ischemic Encephalopathy in Neonates",
                "Pediatric Epilepsy Syndromes: Benign Rolandic Epilepsy, Landau-Kleffner Syndrome",
                "Case-Based Learning: Pediatric EEG Interpretation"
            ],
            "Advanced EEG Techniques": [
                "Video-EEG Monitoring: Role in Epilepsy Diagnosis and Presurgical Evaluation",
                "Ambulatory EEG: Indications and Limitations",
                "Quantitative EEG (qEEG): Basics of Spectral Analysis",
                "Applications of qEEG in Research and Clinical Practice",
                "Case Studies: Advanced EEG Techniques"
            ],
            "EEG in Sleep Disorders": [
                "Sleep Architecture: Stages of Sleep and EEG Correlates",
                "REM and Non-REM Sleep",
                "EEG in Sleep Disorders: Narcolepsy, Sleep Apnea, Parasomnias",
                "Case-Based Learning: EEG in Sleep Disorders"
            ],
            "EEG in Research and Emerging Technologies": [
                "EEG in Cognitive Neuroscience: Event-Related Potentials (ERPs)",
                "EEG in Memory and Attention Studies",
                "Advanced EEG Analysis: Source Localization and High-Density EEG",
                "Emerging Technologies: Machine Learning and AI in EEG Analysis",
                "Wearable EEG Devices"
            ],
            "Case-Based Mastery and Final Assessment": [
                "Complex Case Studies: Review of Challenging EEG Cases",
                "Interactive Sessions for Pattern Recognition",
                "Final Assessment: Written Exam and Practical EEG Interpretation",
                "Certification: Award of Completion for the Course"
            ]
        }
    },
    {id:2,imageUrl:'./images/ecg.png',
        text:'Mastering ECG Interpretation: From Basics to Expertise',
        description:' A step-by-step course covering ECG fundamentals, arrhythmias, ischemia, chamber enlargement, electrolyte effects, pacemakers, systemic diseases, emergencies, and advanced innovations.',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            "Introduction to ECG": [
                "History and Evolution of ECG",
                "Basic Principles of ECG",
                "Anatomy and Physiology of the Heart",
                "Cardiac Conduction System",
                "Indications for ECG",
                "Limitations of ECG"
            ],
            "ECG Basics": [
                "Components of an ECG Machine",
                "Understanding ECG Leads: Limb and Precordial Leads",
                "ECG Paper: Time and Voltage Calibration",
                "Normal ECG Waveforms: P, QRS, T, U",
                "Intervals and Segments: PR, QT, ST",
                "Heart Rate Calculation Methods",
                "Normal ECG Intervals and Durations"
            ],
            "Normal ECG Interpretation": [
                "Normal Sinus Rhythm",
                "Sinus Arrhythmia",
                "Normal P Wave Morphology",
                "Normal QRS Complex Morphology",
                "Normal T Wave Morphology",
                "Normal Axis Determination",
                "Normal Variants in ECG"
            ],
            "Artifacts and Technical Errors": [
                "Muscle Tremor Artifacts",
                "Poor Electrode Contact Artifacts",
                "60 Hz Interference",
                "Baseline Wander",
                "Electrode Misplacement Errors",
                "Troubleshooting ECG Recordings"
            ],
            "Arrhythmias": [
                "Sinus Node Dysfunction: Sinus Bradycardia, Sinus Tachycardia",
                "Atrial Arrhythmias: Atrial Fibrillation, Atrial Flutter",
                "Supraventricular Tachycardia (SVT)",
                "Ventricular Arrhythmias: PVCs, VT, VF",
                "AV Blocks: First-Degree, Second-Degree (Type I and II), Third-Degree",
                "Bundle Branch Blocks: Left and Right",
                "Ectopic Beats and Escape Rhythms"
            ],
            "Ischemia, Injury, and Infarction": [
                "ST-Segment Elevation Myocardial Infarction (STEMI)",
                "ST-Segment Depression",
                "T-Wave Inversion and Hyperacute T Waves",
                "Localization of MI: Inferior, Anterior, Lateral, Posterior",
                "Non-ST Elevation Myocardial Infarction (NSTEMI)",
                "Ischemic ECG Patterns in Unstable Angina"
            ],
            "Chamber Enlargement and Hypertrophy": [
                "Left Atrial Enlargement (P Mitrale)",
                "Right Atrial Enlargement (P Pulmonale)",
                "Left Ventricular Hypertrophy (LVH)",
                "Right Ventricular Hypertrophy (RVH)",
                "Bi-Atrial and Bi-Ventricular Enlargement",
                "ECG Criteria for Chamber Enlargement"
            ],
            "Electrolyte Imbalances and Drug Effects": [
                "Hyperkalemia and Hypokalemia",
                "Hypercalcemia and Hypocalcemia",
                "Effects of Digoxin on ECG",
                "Effects of Beta-Blockers and Calcium Channel Blockers",
                "QT Prolongation and Drug-Induced Arrhythmias",
                "ECG Changes in Toxicity (e.g., Tricyclic Antidepressants)"
            ],
            "Complex Arrhythmias": [
                "Wolff-Parkinson-White (WPW) Syndrome",
                "Long QT Syndrome",
                "Brugada Syndrome",
                "Torsades de Pointes",
                "Sick Sinus Syndrome",
                "Atrial Tachycardia with Block"
            ],
            "Pacemaker ECGs": [
                "Basics of Pacemaker Function",
                "Identifying Pacemaker Spikes",
                "Pacing Modes: VVI, DDD, AAI",
                "Pacemaker Malfunction: Failure to Capture, Failure to Sense",
                "ECG Patterns in Dual-Chamber Pacing",
                "Magnet Mode and Its Effects on ECG"
            ],
            "Advanced Ischemia and Infarction Patterns": [
                "Wellens’ Syndrome",
                "De Winter’s T Waves",
                "Posterior Wall Myocardial Infarction",
                "Right Ventricular Infarction",
                "Ischemia in the Presence of Bundle Branch Blocks",
                "ECG in Acute Coronary Syndromes"
            ],
            "ECG in Special Populations": [
                "Pediatric ECG: Normal and Abnormal Patterns",
                "ECG in Athletes: Physiological Adaptations",
                "ECG in Pregnancy: Normal Changes and Pathological Findings",
                "ECG in the Elderly: Age-Related Changes",
                "ECG in Critically Ill Patients"
            ],
            "ECG in Systemic Diseases": [
                "Pericarditis and Myocarditis",
                "Pulmonary Embolism: S1Q3T3 Pattern",
                "Hypothermia: Osborne Waves",
                "Hyperthyroidism and Hypothyroidism",
                "ECG in Chronic Lung Disease",
                "ECG in Neurological Disorders (e.g., Subarachnoid Hemorrhage)"
            ],
            "Case-Based Learning": [
                "Approach to ECG Interpretation: Step-by-Step Framework",
                "Common ECG Pitfalls and Misinterpretations",
                "ECG in Acute Chest Pain",
                "ECG in Syncope and Palpitations",
                "ECG in Cardiac Arrest",
                "Integrating ECG with Clinical History and Examination"
            ],
            "ECG in Emergency Medicine": [
                "Rapid ECG Interpretation in Emergencies",
                "ECG in Acute Myocardial Infarction",
                "ECG in Pulmonary Embolism",
                "ECG in Hyperkalemia and Hypokalemia",
                "ECG in Cardiac Arrest: PEA, Asystole, VF, VT",
                "ECG in Trauma and Critical Care"
            ],
            "ECG Research and Innovations": [
                "Advanced ECG Techniques: Signal-Averaged ECG, Vectorcardiography",
                "Role of AI and Machine Learning in ECG Interpretation",
                "Wearable ECG Devices and Remote Monitoring",
                "ECG in Telemedicine",
                "Future Directions in ECG Technology"
            ],
            "Teaching ECG to Others": [
                "Developing ECG Teaching Skills",
                "Creating ECG Workshops and Simulations",
                "Teaching ECG to Medical Students and Residents",
                "Designing ECG Case Studies and Quizzes",
                "Effective Use of ECG Simulators and Online Resources"
            ]
        }
    },
    {id:3,imageUrl:'./images/xray.png',
        text:'X-Ray Imaging: A Comprehensive Curriculum ',
        description:' a step-by-step guide to mastering X-ray imaging, covering foundational physics, radiographic anatomy, advanced techniques, clinical integration, and subspecialty expertise, while emphasizing practical skills, ethics, and professional development.',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            "Foundations of Radiology and X-Ray Physics": [
                "History of Radiology and X-Rays",
                "Overview of Imaging Modalities",
                "Role of X-Rays in Clinical Practice",
                "Electromagnetic Spectrum and X-Ray Properties",
                "X-Ray Production: X-Ray Tube, Cathode, Anode, and Bremsstrahlung Radiation",
                "Interaction of X-Rays with Matter: Absorption, Scattering, and Attenuation",
                "Radiographic Density and Contrast",
                "Factors Affecting Image Quality (kVp, mAs, Distance, Grid Use)",
                "Artifacts and How to Minimize Them",
                "Biological Effects of Ionizing Radiation",
                "ALARA Principle (As Low As Reasonably Achievable)",
                "Radiation Dose Measurement and Monitoring",
                "Protective Measures for Patients and Staff",
                "Radiation Safety Protocols in Different Clinical Settings",
                "Regulatory Guidelines for Radiation Use"
            ],
            "Radiographic Anatomy and Positioning": [
                "Normal Radiographic Anatomy: Chest, Abdomen, Extremities, Spine, and Skull",
                "Anatomical Landmarks and Their Significance",
                "Standard Views: AP, PA, Lateral, Oblique, and Specialized Views",
                "Positioning for Chest X-Rays",
                "Positioning for Abdominal X-Rays",
                "Positioning for Musculoskeletal X-Rays",
                "Pediatric and Geriatric Considerations",
                "Hands-On Practice with Positioning Phantoms or Simulated Patients",
                "Critique of Positioning Errors and Corrective Measures",
                "Positioning for Trauma Patients",
                "Positioning for Obese Patients",
                "Positioning for Critically Ill Patients",
                "Positioning for Orthopedic Studies",
                "Positioning for Dental and Maxillofacial Studies"
            ],
            "Interpretation of X-Ray Images": [
                "Systematic Approach to X-Ray Interpretation: ABCDE Approach",
                "Review of Density, Lucency, and Contour Abnormalities",
                "Chest X-Ray Interpretation: Normal vs. Abnormal Findings",
                "Common Chest Pathologies: Pneumonia, Pneumothorax, Pleural Effusion, Heart Failure, Lung Cancer",
                "Pediatric Chest X-Rays: Unique Considerations",
                "Abdominal X-Ray Interpretation: Normal Bowel Gas Pattern and Abnormalities",
                "Common Abdominal Pathologies: Bowel Obstruction, Perforation, Calcifications, and Foreign Bodies",
                "Musculoskeletal X-Ray Interpretation: Fractures, Arthritis, Osteomyelitis, and Bone Tumors",
                "Pediatric Fractures and Growth Plate Injuries",
                "Skull and Facial Bone X-Rays",
                "Spine X-Rays: Cervical, Thoracic, and Lumbar",
                "Specialized Studies: Sinuses, Joints, and Soft Tissues",
                "Interpreting Post-Surgical X-Rays",
                "Interpreting X-Rays in Oncology",
                "Interpreting X-Rays in Rheumatology"
            ],
            "Advanced Topics in X-Ray Imaging": [
                "Contrast Studies: Barium Studies, Intravenous Urography (IVU), Arthrography, and Myelography",
                "Fluoroscopy: Principles and Applications",
                "Common Fluoroscopy Procedures: Barium Studies, Joint Injections, and Interventional Radiology",
                "Digital Radiography and PACS: Transition from Film to Digital Imaging",
                "Picture Archiving and Communication Systems (PACS)",
                "Advantages and Limitations of Digital Imaging",
                "Dual-Energy X-Ray Absorptiometry (DEXA)",
                "Cone-Beam CT and Its Applications",
                "AI in Radiology: Automated Image Analysis and Decision Support",
                "3D Reconstruction in X-Ray Imaging",
                "Functional Imaging with X-Rays",
                "Advanced Fluoroscopy Techniques",
                "Hybrid Imaging: Combining X-Rays with Other Modalities"
            ],
            "Clinical Integration and Case-Based Learning": [
                "Case-Based Learning: Review of Clinical Cases with X-Ray Findings",
                "Differential Diagnosis and Management Planning",
                "Multidisciplinary Approach to Patient Care",
                "Radiology-Pathology Correlation: Correlation of X-Ray Findings with Histopathology and Other Imaging Modalities",
                "Case Discussions with Pathologists and Clinicians",
                "Radiology Reporting: Structure of a Radiology Report",
                "Common Terminology and Phrases",
                "Pitfalls in Reporting and How to Avoid Them",
                "Communicating Findings to Clinicians",
                "Ethical Considerations in Radiology Reporting",
                "Handling Discrepancies in Radiology Reports",
                "Quality Assurance in Radiology"
            ],
            "Subspecialty Focus and Research": [
                "Pediatric Radiology",
                "Musculoskeletal Radiology",
                "Chest Radiology",
                "Emergency Radiology",
                "Designing and Conducting Radiology Research",
                "Critical Appraisal of Radiology Literature",
                "Presenting and Publishing Research Findings",
                "Staying Updated with Advancements in Radiology",
                "Attending Conferences, Workshops, and Online Courses",
                "Board Certification and Continuing Medical Education (CME)",
                "Subspecialty Training Pathways",
                "Interdisciplinary Collaboration in Radiology",
                "Emerging Trends in Radiology"
            ],
            "Assessment and Evaluation": [
                "Written Exams: Multiple-Choice Questions (MCQs) on Physics, Anatomy, and Pathology",
                "Image-Based Questions (IBQs) for Interpretation Skills",
                "Practical Exams: Patient Positioning and Image Acquisition",
                "Image Interpretation and Reporting",
                "Observed Structured Clinical Examinations (OSCEs)",
                "Case Presentations and Discussions",
                "Submission of a Research Paper or Case Report",
                "Peer Review of Radiology Reports",
                "Simulation-Based Assessments",
                "Feedback and Improvement Plans"
            ],
            "Practical Skills and Workshops": [
                "Hands-On X-Ray Machine Operation",
                "Positioning Techniques for Challenging Cases",
                "Radiation Safety Drills",
                "Contrast Administration Techniques",
                "Fluoroscopy Simulation Training",
                "Emergency Radiology Scenarios",
                "Pediatric Radiology Workshops",
                "Musculoskeletal Radiology Workshops",
                "Interventional Radiology Basics",
                "AI Tools for Radiology: Hands-On Training"
            ],
            "Ethics, Communication, and Professionalism": [
                "Ethical Principles in Radiology",
                "Patient Consent for Radiographic Procedures",
                "Communication with Patients and Families",
                "Breaking Bad News in Radiology",
                "Cultural Competence in Radiology",
                "Professionalism in the Radiology Department",
                "Teamwork and Collaboration in Radiology",
                "Handling Errors and Discrepancies",
                "Medicolegal Aspects of Radiology",
                "Confidentiality and Data Security in Radiology"
            ]
        }
    },
    {id:4,imageUrl:'./images/emg.png',
        text:'Mastering EMG: From Basics to Expertise ',
        description:' A comprehensive curriculum covering anatomy, instrumentation, techniques, pathophysiology, clinical applications, signal analysis, research, teaching, and complex case studies for mastering EMG diagnostics and research.',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            "Introduction to EMG": [
                "What is EMG?",
                "History and Evolution of EMG",
                "Basic Principles of Electromyography",
                "Types of EMG: Surface vs. Needle EMG",
                "Applications of EMG in Medicine"
            ],
            "Anatomy and Physiology": [
                "Muscle Anatomy: Structure and Function",
                "Nerve Anatomy: Peripheral and Central Nervous System",
                "Neuromuscular Junction: Physiology and Pathology",
                "Motor Units: Definition and Types",
                "Muscle Fiber Types: Slow-Twitch vs. Fast-Twitch"
            ],
            "Basic EMG Techniques": [
                "Surface EMG: Principles and Applications",
                "Needle EMG: Principles and Applications",
                "Electrode Types: Surface, Needle, and Fine-Wire",
                "Electrode Placement: Guidelines and Best Practices",
                "Safety and Sterilization in EMG"
            ],
            "Instrumentation and Equipment": [
                "EMG Machines: Components and Functionality",
                "Amplifiers and Filters: Signal Processing Basics",
                "Data Acquisition Systems",
                "Calibration and Maintenance of EMG Equipment"
            ],
            "EMG Signal Processing": [
                "Signal Acquisition: Sampling and Digitization",
                "Noise Reduction Techniques: Filtering and Artifact Removal",
                "Signal Analysis: Time Domain vs. Frequency Domain",
                "Amplitude, Frequency, and Duration of EMG Signals",
                "Normal vs. Abnormal EMG Patterns"
            ],
            "Clinical Applications of EMG": [
                "Diagnosing Muscle Disorders: Myopathies, Myositis, and Dystrophies",
                "Diagnosing Nerve Disorders: Neuropathies, Radiculopathies, and Plexopathies",
                "EMG in Neuromuscular Disorders: ALS, Myasthenia Gravis, and Lambert-Eaton Syndrome",
                "EMG in Rehabilitation: Muscle Activation and Recovery",
                "EMG in Sports Medicine: Performance Analysis and Injury Prevention"
            ],
            "Pathophysiology": [
                "Muscle Diseases: Inflammatory, Metabolic, and Genetic Disorders",
                "Nerve Diseases: Compression, Trauma, and Degenerative Disorders",
                "Neuromuscular Disorders: Autoimmune and Congenital Conditions",
                "EMG Findings in Specific Diseases: Case-Based Learning"
            ],
            "Interpretation of EMG Results": [
                "Normal vs. Abnormal EMG Findings",
                "Quantitative EMG: Motor Unit Analysis",
                "Interference Patterns: Recruitment and Firing Rates",
                "Artifacts and Pitfalls in EMG Interpretation",
                "Reporting EMG Findings: Clinical Documentation"
            ],
            "Advanced EMG Techniques": [
                "Single Fiber EMG: Principles and Applications",
                "Macro EMG: Principles and Applications",
                "Quantitative EMG: Advanced Signal Analysis",
                "High-Density Surface EMG: Spatial and Temporal Resolution",
                "Dynamic EMG: Gait Analysis and Movement Studies"
            ],
            "EMG in Research and Development": [
                "Latest Advances in EMG Technology",
                "EMG in Robotics and Prosthetics: Control Systems",
                "EMG in Brain-Computer Interfaces (BCI)",
                "EMG in Wearable Technology: Health Monitoring",
                "Future Trends in EMG: AI and Machine Learning Applications"
            ],
            "Interdisciplinary Applications": [
                "EMG in Orthopedics: Pre- and Post-Surgical Assessment",
                "EMG in Neurology: Diagnostic and Prognostic Tools",
                "EMG in Pediatrics: Developmental Disorders",
                "EMG in Geriatrics: Age-Related Neuromuscular Changes",
                "EMG in Pain Management: Chronic Pain and Spasticity"
            ],
            "Case Studies and Practical Applications": [
                "Complex Case Analysis: Multidisciplinary Approach",
                "Ethical Considerations in EMG Testing",
                "Legal Aspects: Documentation and Liability",
                "Interpreting Rare and Atypical EMG Findings",
                "Hands-On Workshops: Simulated and Real Patient Cases"
            ]
        }
    },
    {id:5,imageUrl:'./images/eog.png',
        text:'Electrooculography EOG From Fundamentals to Advanced Applications',
        description:'This course covering EOG principles, clinical uses, advanced techniques, and research. Includes anatomy, signal processing, data interpretation, case studies, and ethical considerations for medical professionals',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            "Introduction to EOG": [
                "What is EOG?",
                "Historical background and development",
                "Basic principles and applications in medicine",
                "Comparison with other ocular tests (ERG, VEP)"
            ],
            "Anatomy and Physiology of the Eye": [
                "Structure of the eye",
                "Eye movements and their control",
                "Retinal physiology and the role of the RPE",
                "Blood supply and innervation"
            ],
            "Basic Electronics and Signal Processing": [
                "Introduction to bioelectric signals",
                "Electrode types and placement",
                "Signal acquisition and processing",
                "Noise reduction techniques"
            ],
            "EOG Recording Techniques": [
                "Standard EOG recording protocols",
                "Calibration and normalization",
                "Artifact recognition and elimination",
                "Light-adapted vs. dark-adapted EOG"
            ],
            "Clinical Applications of EOG": [
                "Diagnosing retinal diseases (e.g., Best disease, retinitis pigmentosa)",
                "Monitoring eye movements in neurological disorders",
                "Use in sleep studies and vestibular testing",
                "Case studies in retinal dystrophies"
            ],
            "Data Interpretation": [
                "Understanding EOG waveforms",
                "Arden ratio calculation",
                "Quantitative analysis of EOG data",
                "Correlation with other diagnostic tests (ERG, VEP, OCT)"
            ],
            "Advanced EOG Techniques": [
                "Multifocal EOG",
                "High-frequency EOG",
                "Integration with imaging techniques (e.g., OCT)",
                "Wearable EOG devices"
            ],
            "Research and Development in EOG": [
                "Current research trends in EOG",
                "AI and machine learning in EOG analysis",
                "Innovations in EOG technology",
                "Future directions and potential applications"
            ],
            "Case Studies and Practical Applications": [
                "Real-world case studies using EOG",
                "Hands-on practice with EOG equipment",
                "Troubleshooting and problem-solving in EOG recordings",
                "Interdisciplinary collaboration"
            ],
            "Ethics and Patient Care": [
                "Patient preparation and informed consent",
                "Ethical considerations in EOG research",
                "Communication skills for explaining EOG results",
                "Patient comfort and safety"
            ]
        }
    },
    {id:6,imageUrl:'./images/mri.png',
        text:'Comprehensive MRI Fundamentals and Applications',
        description:'Covers MRI principles, hardware, image formation, contrast mechanisms, clinical applications, advanced techniques, safety, artifacts, and future directions. Ideal for beginners to expert doctors. Includes sub-subjects like NMR, k-space, fMRI, DTI, and AI in MRI.',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            "Introduction to MRI": [
                "What is MRI?",
                "History and Evolution of MRI",
                "Basic Principles of Magnetic Resonance Imaging",
                "Comparison with Other Imaging Modalities"
            ],
            "Physics of MRI": [
                "Nuclear Magnetic Resonance (NMR)",
                "Magnetic Fields (B0, Gradients)",
                "Radiofrequency Pulses and Signal Detection",
                "Larmor Frequency and Resonance"
            ],
            "MRI Hardware": [
                "Magnet Types (Superconducting, Permanent, Resistive)",
                "Gradient Coils and Their Functions",
                "RF Coils (Surface, Volume, Phased-Array)",
                "Computer Systems and Image Reconstruction"
            ],
            "Image Formation": [
                "Spatial Encoding (Slice Selection, Frequency, Phase)",
                "k-Space and Its Properties",
                "Pulse Sequences (Spin Echo, Gradient Echo, EPI)",
                "Fast Imaging Techniques"
            ],
            "Contrast Mechanisms": [
                "T1, T2, and Proton Density Weighting",
                "Contrast Agents (Gadolinium, Iron Oxide)",
                "Diffusion-Weighted Imaging (DWI)",
                "Perfusion and Functional MRI (fMRI)"
            ],
            "Clinical Applications": [
                "Neuroimaging (Brain, Spine)",
                "Musculoskeletal Imaging (Joints, Tendons)",
                "Cardiovascular Imaging (MRA, Cardiac MRI)",
                "Abdominal and Pelvic Imaging"
            ],
            "Advanced Techniques": [
                "MR Spectroscopy (MRS)",
                "Diffusion Tensor Imaging (DTI)",
                "Functional MRI (fMRI)",
                "Magnetic Resonance Angiography (MRA)"
            ],
            "Safety and Protocols": [
                "MRI Safety (Contraindications, Bioeffects)",
                "Patient Preparation and Positioning",
                "Protocol Optimization (TR, TE, Flip Angle)",
                "Artifact Reduction Strategies"
            ],
            "Artifacts and Troubleshooting": [
                "Common MRI Artifacts (Motion, Aliasing)",
                "Artifact Correction Techniques",
                "Quality Control and Maintenance",
                "Phantom Testing and Calibration"
            ],
            "Research and Future Directions": [
                "Emerging MRI Technologies (7T, Portable MRI)",
                "Artificial Intelligence in MRI",
                "Ethical Considerations in MRI Research",
                "Future Trends and Innovations"
            ]
        }
    },
    {id:7,imageUrl:'./images/pet.png',
        text:' Positron Emission Tomography (PET) Imaging: Principles and Applications',
        description:'This course covers the fundamentals, clinical applications, and advanced topics in Positron Emission Tomography (PET), including physics, radiopharmaceuticals, image processing, and safety protocols.  ',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            "Introduction to PET": [
                "What is PET?",
                "History and Development of PET",
                "Basic Principles of PET Imaging",
                "Overview of PET in Clinical Medicine",
                "Comparison with Other Imaging Modalities (CT, MRI, SPECT)"
            ],
            "Physics and Fundamentals": [
                "Positron Emission and Annihilation",
                "Detection of Gamma Rays",
                "Time-of-Flight (TOF) in PET",
                "PET Scanner Design and Components",
                "Image Reconstruction Algorithms",
                "Resolution and Sensitivity in PET"
            ],
            "Radiopharmaceuticals and Tracers": [
                "Basics of Radiochemistry",
                "Production of Radioisotopes for PET",
                "Common PET Tracers (FDG, FLT, etc.)",
                "Pharmacokinetics of PET Tracers",
                "Quality Control of Radiopharmaceuticals"
            ],
            "Clinical Applications of PET": [
                "PET in Oncology",
                "PET in Neurology",
                "PET in Cardiology",
                "PET in Infection and Inflammation",
                "PET in Psychiatry",
                "PET in Drug Development"
            ],
            "Image Acquisition and Processing": [
                "PET Scan Protocols",
                "Attenuation Correction Techniques",
                "Noise Reduction and Image Enhancement",
                "Fusion of PET with CT/MRI",
                "Quantitative PET Imaging"
            ],
            "Data Analysis and Interpretation": [
                "Semi-Quantitative Analysis (SUV, etc.)",
                "Parametric Imaging",
                "Kinetic Modeling in PET",
                "Interpretation of PET Images in Clinical Context",
                "Reporting and Communication of PET Findings"
            ],
            "Safety and Radiation Protection": [
                "Patient Radiation Dose in PET",
                "Radiation Safety in PET Facilities",
                "Shielding and Waste Management",
                "Staff Protection and Training"
            ],
            "Advanced Topics in PET": [
                "Emerging PET Tracers and Applications",
                "Hybrid PET/CT and PET/MRI Systems",
                "Molecular Imaging and Personalized Medicine",
                "Artificial Intelligence in PET Imaging",
                "Future Directions in PET Technology"
            ],
            "Research and Development in PET": [
                "Current Research Trends in PET",
                "Developing New PET Tracers",
                "Clinical Trials and PET",
                "Interdisciplinary Collaboration in PET Research",
                "Grant Writing and Research Funding in PET"
            ],
            "Ethical and Legal Considerations": [
                "Ethical Issues in PET Imaging",
                "Patient Consent and Privacy",
                "Regulatory Affairs in PET",
                "Quality Assurance and Accreditation"
            ]
        }
    },
    {id:8,imageUrl:'./images/mri.png',
        text:'Magnetoencephalography (MEG) Fundamentals',
        description:'understanding of Magnetoencephalography (MEG), covering the fundamental principles, technical aspects, data processing, and clinical applications. Students will gain expertise in using MEG for both research and clinical settings, from data acquisition to interpretation.',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            'Introduction to MEG': [
                'What is MEG?',
                'History and Development of MEG',
                'Basic Principles of MEG',
                'Comparison with Other Neuroimaging Techniques (EEG, fMRI, etc.)',
                'Clinical and Research Applications of MEG'
            ],
            'Elements and Structure of MEG Systems': [
                'MEG Sensors (SQUIDs)',
                'Cryogenic Systems',
                'Helmet Design and Configuration',
                'Data Acquisition Hardware',
                'Signal Conditioning and Amplification'
            ],
            'Physics of MEG': [
                'Magnetoencephalography Physics',
                'Cortical Current Sources and Magnetic Fields',
                'Forward and Inverse Problems in MEG',
                'Noise Sources and Reduction Techniques'
            ],
            'MEG Data Acquisition': [
                'Patient Preparation and Setup',
                'Recording Protocols',
                'Artifact Detection and Removal',
                'Data Quality Assessment',
                'Data Storage and Management'
            ],
            'Signal Processing in MEG': [
                'Filtering and Preprocessing',
                'Source Localization Techniques',
                'Time-Frequency Analysis',
                'Statistical Methods in MEG Data Analysis',
                'Connectivity Analysis and Network Dynamics'
            ],
            'Clinical Applications of MEG': [
                'Pre-surgical Evaluation for Epilepsy',
                'Neurological Disorders (Stroke, Dementia, etc.)',
                'Functional Brain Mapping',
                'Pediatric Applications',
                'Neurofeedback and Brain-Computer Interfaces'
            ],
            'Research Applications of MEG': [
                'Cognitive Neuroscience',
                'Developmental Studies',
                'Neuroplasticity and Learning',
                'Emotion and Social Cognition',
                'Neuroimaging in Psychiatry'
            ],
            'Challenges and Limitations of MEG': [
                'Technical Challenges in MEG',
                'Clinical Limitations and Constraints',
                'Ethical Considerations in MEG Research',
                'Future Directions and Technological Advances'
            ],
            'Practical Aspects of MEG': [
                ' hands-on MEG Data Analysis',
                'Interpretation of MEG Results',
                'Case Studies and Clinical Scenarios',
                'MEG in Multimodal Imaging Approaches',
                'Collaboration with Other Medical Specialties'
            ],
            'Future of MEG': [
                'Emerging Trends in MEG Technology',
                'Advanced Data Analysis Techniques',
                'Integration with AI and Machine Learning',
                'Potential for Translational Research',
                'Global Impact and Future Prospects'
            ]
        }
    },
    {id:9,imageUrl:'./images/ultrasounds.png',
        text:'Comprehensive Ultrasound Course',
        description:'This course covers the fundamentals of ultrasound physics, equipment, imaging techniques, and clinical applications, progressing to advanced topics and future trends in ultrasound technology.',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            'Introduction to Ultrasound': [
                'What is Ultrasound?',
                'History and Evolution of Ultrasound',
                'Basic Principles of Ultrasound',
                'Applications of Ultrasound in Medicine',
                'Safety and Regulations in Ultrasound'
            ],
            'Physics of Ultrasound': [
                'Sound Waves and Their Properties',
                'Piezoelectric Effect',
                'Ultrasound Transducers: Types and Functions',
                'Ultrasound Beam Formation and Steering',
                'Doppler Effect and Doppler Ultrasound',
                'Image Formation and Sonographic Artifacts'
            ],
            'Ultrasound Equipment and Technology': [
                'Components of an Ultrasound System',
                'Ultrasound Scanners and Probes',
                'Digital Ultrasound and Advanced Imaging Techniques',
                '3D and 4D Ultrasound',
                'Contrast-Enhanced Ultrasound',
                'Ultrasound Bioeffects and Safety Standards'
            ],
            'Ultrasound Imaging Techniques': [
                'Gray-scale Ultrasound Imaging',
                'Color Doppler Ultrasound',
                'Spectral Doppler Ultrasound',
                'Power Doppler Ultrasound',
                'Harmonic Imaging',
                'Elastography',
                'Automated Ultrasound Techniques'
            ],
            'Clinical Applications of Ultrasound': [
                'Abdominal Ultrasound: Liver, Spleen, Kidneys, Pancreas',
                'Gynecological and Obstetric Ultrasound',
                'Musculoskeletal Ultrasound',
                'Vascular Ultrasound: Arteries and Veins',
                'Cardiac Ultrasound (Echocardiography)',
                'Neurosonology: Brain and Spine',
                'Pediatric Ultrasound',
                'Interventional Ultrasound: Guided Procedures'
            ],
            'Ultrasound Interpretation and Reporting': [
                'Image Interpretation: Normal Anatomy',
                'Image Interpretation: Pathological Conditions',
                'Ultrasound Reporting Standards',
                'Communication with Referring Physicians',
                'Legal and Ethical Considerations in Ultrasound Reporting'
            ],
            'Advanced Ultrasound Techniques': [
                'Contrast-Enhanced Ultrasound (CEUS)',
                'Fusion Imaging: Ultrasound with Other Modalities',
                'Point-of-Care Ultrasound (POCUS)',
                'Ultrasound in Emergency Medicine',
                'Ultrasound in Critical Care',
                'Ultrasound in Oncology'
            ],
            'Quality Assurance and Ultrasound Education': [
                'Quality Control in Ultrasound',
                'Calibration and Maintenance of Ultrasound Equipment',
                'Continuing Education and Professional Development',
                'Teaching Ultrasound to Medical Students and Residents',
                'Ultrasound Research and Innovation'
            ],
            'Ultrasound in Specialized Fields': [
                'Ultrasound in Radiology',
                'Ultrasound in Surgery',
                'Ultrasound in Anesthesiology',
                'Ultrasound in Rheumatology',
                'Ultrasound in Urology',
                'Ultrasound in Dermatology'
            ],
            'Future Trends in Ultrasound': [
                'Artificial Intelligence in Ultrasound',
                'Miniaturization and Portable Ultrasound Devices',
                'Ultrasound in Telemedicine',
                'Ultrasound in Developing Countries',
                'Emerging Applications of Ultrasound'
            ]
        }
 
    },
    {id:10,imageUrl:'./images/icon.png',
        text:'Echocardiography Course',
        description:'This course covers the fundamentals, advanced techniques, and clinical applications of echocardiography, including physics, image acquisition, interpretation, and quality assurance, preparing learners from beginner to expert level.',
        subjects:['Medical Tests'],
        subjectDetails:
  
        {
            'Introduction to Echocardiography': [
                'What is Echocardiography?',
                'History and Evolution of Echocardiography',
                'Importance and Applications in Clinical Practice',
                'Basic Terminology and Glossary'
            ],
            'Physics and Principles of Ultrasound': [
                'Sound Wave Basics',
                'Ultrasound Physics: Frequency, Wavelength, and Propagation',
                'Doppler Effect and Its Application in Echocardiography',
                'Principles of Image Formation: Echoes, Reflection, and Attenuation',
                'Ultrasound Machine Components: Transducers, Probes, and Imaging Modalities'
            ],
            'Echocardiography Equipment and Setup': [
                'Overview of Echocardiography Machines',
                'Transducer Types and Selection',
                'Machine Controls: Gain, Depth, Focus, and Adjustments',
                'Calibration and Quality Assurance',
                'Patient Preparation and Positioning'
            ],
            'Basic Echocardiographic Views and Windows': [
                'Standard Views: Parasternal, Apical, and Subcostal Windows',
                'Acquisition of Fundamental Views: Long Axis, Short Axis, and Apical Four-Chamber View',
                'Understanding the Anatomy on Echocardiographic Images',
                'Common Artifacts and How to Avoid Them'
            ],
            'Interpretation of Echocardiographic Images': [
                'Assessment of Cardiac Chambers: Size, Shape, and Function',
                'Evaluation of Valvular Heart Disease: Stenosis and Regurgitation',
                'Assessment of Myocardial Function: Wall Motion and Contractility',
                'Identification of Pericardial Effusion and Other Abnormalities'
            ],
            'Doppler Echocardiography': [
                'Principles of Doppler Ultrasound',
                'Pulsed Wave and Continuous Wave Doppler',
                'Spectral Doppler Analysis: Velocity, Flow, and Pressure Gradients',
                'Color Doppler Imaging: Understanding Flow Patterns',
                'Assessment of Valvular Stenosis and Regurgitation Using Doppler'
            ],
            'Advanced Echocardiographic Techniques': [
                'Transesophageal Echocardiography (TEE): Indications and Techniques',
                'Stress Echocardiography: Protocol and Interpretation',
                'Three-Dimensional (3D) Echocardiography: Acquisition and Analysis',
                'Contrast Echocardiography: Uses and Limitations',
                'Tissue Doppler Imaging and Strain Rate Imaging'
            ],
            'Clinical Applications of Echocardiography': [
                'Echocardiography in Acute Cardiovascular Emergencies: Cardiac Tamponade, Aortic Dissection, and Myocardial Infarction',
                'Echocardiography in Heart Failure: Evaluation of Systolic and Diastolic Function',
                'Echocardiography in Valvular Heart Disease: Preoperative Assessment',
                'Echocardiography in Congenital Heart Disease: Diagnosis and Follow-Up',
                'Echocardiography in Pericardial Disease: Diagnosis and Management'
            ],
            'Echocardiography in Special Populations': [
                'Pediatric Echocardiography: Normal Findings and Common Pathologies',
                'Echocardiography in the Elderly: Challenges and Considerations',
                'Echocardiography in Patients with Obesity and Poor Window',
                'Echocardiography in Patients with Implanted Devices: Pacemakers and Defibrillators'
            ],
            'Quality Assurance and Reporting': [
                'Standards and Guidelines for Echocardiography',
                'Reporting Formats and Templates',
                'Interpretation and Reporting of Echocardiographic Findings',
                'Quality Control and Quality Improvement in Echocardiography Labs',
                'Legal and Ethical Considerations in Echocardiography'
            ],
            'Research and Continuous Learning in Echocardiography': [
                'Current Research Trends in Echocardiography',
                'How to Stay Updated with the Latest Advances',
                'Case Studies and Problem-Based Learning',
                'Hands-On Training and Workshops',
                'Certification and Professional Development'
            ]
        }
    },
    {id:11,imageUrl:'./images/icon.png',
        text:'Guide to Nerve Conduction Studies: From Basics to Expertise ',
        description:'This course covers the fundamentals, technical aspects, interpretation, and clinical applications of Nerve Conduction Studies (NCS), equipping learners with the skills to diagnose and manage neurological disorders using NCS.',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            'Introduction to Nerve Conduction Studies (NCS)': [
                'What is Nerve Conduction Study (NCS)?',
                'History and Development of NCS',
                'Importance of NCS in Neurology and Neuromuscular Medicine',
                'Indications and Clinical Applications of NCS',
                'Overview of Related Studies: Electromyography (EMG), Evoked Potentials'
            ],
            'Physiological Basis of NCS': [
                'Neurophysiology of Nerve Impulse Conduction',
                'Types of Nerve Fibers and Their Properties',
                'Action Potentials: Generation and Propagation',
                'Role of Ion Channels in Nerve Conduction',
                'Physiology of Sensory and Motor Nerves'
            ],
            'Technical Setup and Equipment': [
                'Overview of NCS Equipment: Stimulators, Electrodes, Amplifiers',
                'Types of Electrodes: Needle, Surface, Ring, etc.',
                'Stimulator Settings: Pulse Width, Amplitude, Frequency',
                'Amplifier Settings: Gain, Filter Settings, Sweep Speed',
                'Calibration and Quality Control of NCS Equipment',
                'Patient Preparation and Setup for NCS'
            ],
            'NCS Techniques and Procedures': [
                'Standard NCS Protocols: Motor and Sensory NCS',
                'Electrode Placement and Nerve Stimulation Techniques',
                'Recording Techniques: Compound Muscle Action Potentials (CMAP), Sensory Nerve Action Potentials (SNAP)',
                'Measuring Latency, Amplitude, and Conduction Velocity',
                'F-Wave and H-Reflex Studies',
                'Bilateral Comparisons and Normal Values'
            ],
            'Interpretation of NCS Results': [
                'Understanding Waveforms: Latency, Amplitude, Conduction Velocity',
                'Normal vs. Abnormal NCS Findings',
                'Interpreting NCS in Peripheral Neuropathies',
                'NCS in Neuromuscular Junction Disorders (e.g., Myasthenia Gravis)',
                'NCS in Nerve Compression Syndromes (e.g., Carpal Tunnel Syndrome)',
                'Correlating NCS with Clinical Findings and EMG'
            ],
            'Troubleshooting in NCS': [
                'Common Technical Errors and Artifacts in NCS',
                'Patient-Related Factors Affecting NCS Results',
                'Interpreting Abnormal Waveforms: Distinguishing Pathological from Technical Artifacts',
                'Managing Pain and Discomfort During NCS'
            ],
            'Clinical Applications and Case Studies': [
                'NCS in Diagnosis of Peripheral Nerve Injuries',
                'NCS in Evaluation of Radiculopathies and Plexopathies',
                'NCS in Monitoring of Neuromuscular Disorders',
                'Case Studies: Interpreting NCS in Various Clinical Scenarios',
                'NCS in Pre-operative Assessment and Post-operative Monitoring'
            ],
            'Advanced NCS Techniques': [
                'High-Resolution NCS (HRNCS)',
                'Supramaximal Stimulation Techniques',
                'Mapping Techniques in NCS',
                'NCS in Pediatric Patients',
                'NCS in Special Situations: Burns, Amputations, and Peripheral Nerve Grafts'
            ],
            'Ethical and Legal Considerations': [
                'Patient Consent and Privacy in NCS',
                'Safety Measures in NCS',
                'Legal Implications of NCS Results',
                'Ethical Issues in Interpretation and Reporting of NCS'
            ],
            'Resources and Further Learning': [
                'Recommended Textbooks and Journals on NCS',
                'Online Resources and Continuing Education for NCS',
                'Workshops and Conferences on NCS',
                'Professional Organizations and Certifications in NCS'
            ]
        }
     
    },
    {id:12,imageUrl:'./images/icon.png',
        text:'Visual Evoked Potentials (VEP): Comprehensive Guide',
        description:'Learn the fundamentals, recording techniques, interpretation, and clinical applications of VEP, including types, artifacts, and advanced research topics, from basic principles to expert-level',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            'Introduction to VEP': [
                'What is Visual Evoked Potential (VEP)?',
                'Historical Background of VEP',
                'Significance of VEP in Clinical Neurophysiology',
                'Overview of Visual Pathway and Its Relation to VEP',
                'Indications for VEP Testing',
                'Comparison with Other Visual Function Tests (e.g., ERG, VEP vs. Visual Field Testing)',
            ],
            'Physiology of Visual Pathway': [
                'Anatomy of the Visual Pathway',
                'Neurophysiology of Visual Signal Transmission',
                'Role of Retina, Optic Nerve, and Visual Cortex',
                'Mechanisms of VEP Generation',
            ],
            'Technical Aspects of VEP Recording': [
                'Equipment Used in VEP Recording',
                'Electrode Placement and Setup',
                'Stimulus Types and Parameters',
                'Recording Parameters and Settings',
                'Artifact Reduction Techniques',
            ],
            'Types of VEP': [
                'Pattern Visual Evoked Potential (PVEP)',
                'Flash Visual Evoked Potential (FVEP)',
                'Pattern Reversal Visual Evoked Potential (PRVEP)',
                'Pattern Onset Visual Evoked Potential (POVEP)',
                'Color Visual Evoked Potential (CVEP)',
                'Multifocal Visual Evoked Potential (mfVEP)',
            ],
            'VEP Recording Techniques': [
                'Standard VEP Recording Procedure',
                'Advanced Recording Techniques',
                'Automated VEP Systems',
                'Pediatric VEP Recording',
                'VEP in Special Populations (e.g., Patients with Ocular Pathologies)',
            ],
            'Interpretation of VEP Results': [
                'Normal VEP Waveforms and Components',
                'Abnormal VEP Patterns and Their Clinical Significance',
                'Interpretation of Latency and Amplitude Changes',
                'Differential Diagnosis Using VEP',
            ],
            'Clinical Applications of VEP': [
                'VEP in Diagnosing Optic Neuropathies',
                'VEP in Multiple Sclerosis',
                'VEP in Glaucoma',
                'VEP in Retinal Diseases',
                'VEP in Neurological Disorders (e.g., Stroke, Trauma)',
                'VEP in Pediatric Neurology',
            ],
            'VEP in Research and Advanced Applications': [
                'VEP in Functional Brain Mapping',
                'VEP in Cognitive Neuroscience',
                'VEP in Ophthalmological Research',
                'VEP in Neurorehabilitation',
            ],
            'Troubleshooting and Artifacts in VEP': [
                'Common Artifacts in VEP Recording',
                'Sources of Error in VEP Testing',
                'Troubleshooting Techniques',
                'Quality Assurance in VEP Recording',
            ],
            'VEP Case Studies and Clinical Scenarios': [
                'Case Studies in Optic Neuropathy',
                'Case Studies in Multiple Sclerosis',
                'Case Studies in Retinal Diseases',
                'Case Studies in Pediatric Neurology',
                'Case Studies in Neurological Disorders',
            ],
            'Future Directions in VEP Technology': [
                'Advancements in VEP Recording Techniques',
                'Emerging Applications of VEP',
                'Role of VEP in Future Clinical Practice',
            ],
            'Assessment and Evaluation': [
                'Practical Exams on VEP Recording',
                'Written Exams on VEP Theory and Interpretation',
                'Case-based Assessments',
                'Project Work on VEP Research or Clinical Application',
            ],
            'Resources and Further Reading': [
                'Recommended Textbooks on VEP',
                'Key Research Papers and Reviews',
                'Online Resources and Journals',
                'Professional Organizations and Conferences',
            ]
        }
     
    },
    {id:13,imageUrl:'./images/icon.png',
        text:'Computed Tomography (CT) Comprehensive Guide ',
        description:'technical aspects, clinical applications, and advanced techniques of CT imaging. Learn about CT physics, scanner hardware, image reconstruction, protocols, interpretation, and quality assurance. Dive into advanced techniques like dual-energy CT, AI in CT, and future trends in CT technology.',
        subjects:['Medical Tests'],
        subjectDetails:
        {
            'Introduction to CT Scan': [
                'What is CT Scan?',
                'History and Evolution of CT',
                'Basic Principles of CT',
                'Comparison with Other Imaging Modalities (X-ray, MRI, etc.)',
                'Clinical Applications of CT',
                'Role of CT in Modern Medicine'
            ],
            'Physics of CT': [
                'X-ray Physics',
                'Attenuation of X-rays',
                'Hounsfield Units',
                'CT Number and its Significance',
                'Radon Transform and Fourier Analysis',
                'CT Dose and Radiation Safety'
            ],
            'CT Scanner Hardware': [
                'Components of a CT Scanner',
                'Gantry and Collimation',
                'X-ray Tube: Design and Function',
                'Detectors: Types and Performance',
                'Slip Ring Technology',
                'CT Scanner Generations'
            ],
            'Image Reconstruction in CT': [
                'Filtering and Back Projection',
                'Iterative Reconstruction Techniques',
                'Algorithms for Image Formation',
                'Slice Thickness and Reconstruction Algorithms',
                'Impact of Reconstruction Parameters on Image Quality'
            ],
            'CT Protocols and Techniques': [
                'Choosing the Right Protocol',
                'Scan Parameters: kVp, mA, and mAs',
                'Contrast Media: Types, Administration, and Safety',
                'Oral Contrast: Indications and Timing',
                'Intravenous Contrast: Indications and Timing',
                'CT Angiography (CTA): Principles and Applications',
                'CT Perfusion Imaging: Techniques and Interpretation'
            ],
            'Clinical Applications of CT': [
                'Head and Neck CT: Brain, Sinuses, and Neck',
                'Chest CT: Lung Parenchyma, Vessels, and Mediastinum',
                'Abdominal and Pelvic CT: Liver, Kidneys, Pancreas, and Bowel',
                'Musculoskeletal CT: Bones, Joints, and Soft Tissues',
                'CT in Oncology: Staging, Treatment Planning, and Follow-up',
                'CT in Emergency Medicine: Trauma, Stroke, and Infection'
            ],
            'Image Interpretation in CT': [
                'Normal Anatomy on CT Images',
                'Identification of Pathological Findings',
                'Differential Diagnosis using CT',
                'CT in the Diagnosis of Acute Conditions',
                'CT in the Diagnosis of Chronic Conditions',
                'Correlation with Other Imaging Modalities'
            ],
            'Advanced CT Techniques': [
                'Dual-Energy CT: Principles and Applications',
                'Spectral CT: Material Decomposition and Virtual Non-contrast Imaging',
                'CT Perfusion and Ventilation Imaging',
                'CT Guided Interventional Procedures',
                '3D Reconstruction and Volume Rendering',
                'Artificial Intelligence in CT Image Analysis'
            ],
            'Quality Assurance in CT': [
                'CT Scanner Calibration and Quality Control',
                'Image Quality Parameters: Resolution, Noise, and Contrast',
                'Dose Management and Optimization',
                'Patient Safety in CT Imaging',
                'Regulatory Standards and Compliance'
            ],
            'Troubleshooting and Problem Solving in CT': [
                'Common Technical Issues in CT',
                'Artifact Recognition and Reduction',
                'Patient Motion and Its Impact on Images',
                'Contrast-Related Issues and Solutions',
                'Scanner Malfunctions and Emergency Protocols'
            ],
            'Legal and Ethical Considerations in CT': [
                'Informed Consent for CT Examinations',
                'Patient Privacy and Data Security',
                'Radiation Dose and Long-term Risks',
                'Ethical Use of CT in Clinical Practice',
                'Legal Liability in CT Imaging'
            ],
            'CT Research and Future Trends': [
                'Current Research in CT Technology',
                'Emerging Applications of CT',
                'Future Directions in CT Imaging',
                'Impact of CT on Patient Care and Outcomes',
                'CT in Multidisciplinary Teams and Integrated Care'
            ]
        }
     
    }




];

export default allCardData;