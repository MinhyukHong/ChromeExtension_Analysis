// sidebar.js
const selectedTextElement = document.getElementById('selectedText');
const subjectFilterElement = document.getElementById('subjectFilter');
const cardTabsElement = document.querySelector('.card-tabs');
const allCardsList = document.getElementById('all-cards');
const myCardsList = document.getElementById('my-cards');
const subjectTreeElement = document.querySelector('.subject-tree');
const subjectListElement = document.getElementById('subjectList');
const notesTabElement = document.querySelector('.notes-tab');
const addNoteButton = document.getElementById('addNoteButton');
const noteEditor = document.getElementById('noteEditor');
const noteTextarea = document.getElementById('noteText');
const saveNoteButton = document.getElementById('saveNoteButton');
const savedNotesList = document.getElementById('savedNotesList');
const noteCardSelect = document.getElementById('noteCardSelect');

const searchBox = document.querySelector('.search-box');
const myTabButton = document.querySelector('[data-tab="my"]');
const allTabButton = document.querySelector('[data-tab="all"]');
const notesTabButton = document.querySelector('[data-tab="notes"]');

import allCardData from './cardData.js';
import Analytics from './google-analytics.js';
// Fire a page view event on load
window.addEventListener('load', () => {

    const language = navigator.languages.join(", ");
    const ln="LANGUAGE_"+language;
    Analytics.fireEvent("OPEN_EXTENSIONS", { language:navigator.languages.join(", ") });
   // Analytics.firePageViewEvent("OPEN_EXTENSIONS",  document.location.href);
  });
  
let myCardData = [];
let subjectDetailsToShowOnMyTab = null;

function loadMyCards() {
    const storedMyCards = localStorage.getItem('myCards');
    myCardData = storedMyCards ? JSON.parse(storedMyCards) : [];
    updateMyTabCount();
    populateNoteCardSelectOptions();
}

function saveMyCards() {
    localStorage.setItem('myCards', JSON.stringify(myCardData));
    updateMyTabCount();
    populateNoteCardSelectOptions();
}

function updateMyTabCount() {
    myTabButton.textContent = `My (${myCardData.length})`;
}

function populateNoteCardSelectOptions() {
    noteCardSelect.innerHTML = '<option value="">All Courses Notes</option>';
    myCardData.forEach(card => {
        const option = document.createElement('option');
        option.value = card.text;
        option.textContent = card.text;
        noteCardSelect.appendChild(option);
    });
}

const uniqueSubjects = [...new Set(allCardData.flatMap(card => card.subjects))];

function populateSubjectFilter() {
    uniqueSubjects.forEach(subject => {
        const option = document.createElement('option');
        option.value = subject;
        option.textContent = subject;
        subjectFilterElement.appendChild(option);
    });
}

function createCardElement(card, isMyCard) {
    const cardElement = document.createElement('div');
    cardElement.classList.add('card');
    cardElement.innerHTML = `
        <img src="${card.imageUrl}" alt="${card.text}">
        <div class="card-text">
            <h3>${card.text}</h3>
            <p class="card-description">${card.description}</p>
        </div>
    `;

    const buttonContainer = document.createElement('div');
    buttonContainer.classList.add('card-buttons');

    const addNoteButtonToCard = document.createElement('button');
    addNoteButtonToCard.textContent = 'Add Note';
    addNoteButtonToCard.classList.add('add-note-to-card-button');
    addNoteButtonToCard.addEventListener('click', () => {
        notesTabButton.click();
        noteCardSelect.value = card.text;
        displaySavedNotes(card.text);
    });
    // buttonContainer.appendChild(addNoteButtonToCard); // Consider if this is needed on all cards

    const actionButton = document.createElement('button');
    actionButton.textContent = isMyCard ? 'Remove' : 'Enroll Now';
    actionButton.classList.add(isMyCard ? 'remove-from-my-button' : 'add-to-my-button');
    actionButton.addEventListener('click', () => {
        if (isMyCard) {
            Analytics.fireEvent('REMOVE_COURSE', { title:card.text  });
            myCardData = myCardData.filter(myCard => myCard.id !== card.id);
            saveMyCards();
            displayCards(myCardData, myCardsList);
        } else {
            Analytics.fireEvent('ENROLL_COURSE', { title:card.text  });
            if (!myCardData.some(myCard => myCard.id === card.id)) {
                myCardData.push(card);
                saveMyCards();
                subjectDetailsToShowOnMyTab = { subjectDetails: card.subjectDetails, cardTitle: card.text, cardId: card.id };
                myTabButton.click();
            }
        }
    });
    buttonContainer.appendChild(actionButton);

    cardElement.appendChild(buttonContainer);

    cardElement.addEventListener('click', (event) => {
        if (!buttonContainer.contains(event.target)) {
            console.log("Card Text when clicked:", card.text);
            showSubjectTree(card.id, card.text, card.description, card.subjectDetails);
        }
    });

    return cardElement;
}

function displayCards(cardDataToDisplay, targetElement) {
    targetElement.innerHTML = '';
    if (cardDataToDisplay.length === 0) {
        targetElement.textContent = 'No cards to display.';
        return;
    }
    cardDataToDisplay.forEach(card => {
        const isMyCard = targetElement === myCardsList;
        const cardElement = createCardElement(card, isMyCard);
        targetElement.appendChild(cardElement);
    });
}

function displaySavedNotes(filterTitle = null) {
    savedNotesList.innerHTML = '';
    let notes = JSON.parse(localStorage.getItem('myNotes') || '[]');

    // Sort notes by timestamp in descending order (newest first)
    notes.sort((a, b) => b.timestamp - a.timestamp);

    const notesToDisplay = filterTitle
        ? notes.filter(note => note.title === filterTitle)
        : notes;

    if (notesToDisplay.length === 0) {
        savedNotesList.textContent = filterTitle ? `No notes for "${filterTitle}" yet.` : 'No notes saved yet.';
        return;
    }

    notesToDisplay.forEach((note, index) => {
        const noteCard = document.createElement('div');
        noteCard.classList.add('card');
        noteCard.innerHTML = `
            <p class="note-text-content">${note.note}</p>
            <button class="delete-note-button" data-index="${index}">×</button>
        `;

        noteCard.addEventListener('click', (event) => {
            if (event.target.classList.contains('note-text-content')) {
                const noteTextElement = event.target;
                const textToCopy = noteTextElement.textContent;

                navigator.clipboard.writeText(textToCopy)
                    .then(() => {
                        const originalText = noteTextElement.textContent;
                        noteTextElement.textContent = 'Copied!';
                        setTimeout(() => {
                            noteTextElement.textContent = originalText;
                        }, 3000);
                    })
                    .catch(err => {
                        console.error('Failed to copy text: ', err);
                        noteTextElement.textContent = 'Copy Failed';
                        setTimeout(() => {
                            noteTextElement.textContent = textToCopy;
                        }, 3000);
                    });
            }
        });

        savedNotesList.appendChild(noteCard);
    });

    document.querySelectorAll('.delete-note-button').forEach(button => {
        button.addEventListener('click', () => {
            const indexToDelete = parseInt(button.dataset.index);
            deleteNote(indexToDelete);
        });
    });
}

function deleteNote(index) {
    let notes = JSON.parse(localStorage.getItem('myNotes') || '[]');
    if (index >= 0 && index < notes.length) {
        notes.splice(index, 1);
        localStorage.setItem('myNotes', JSON.stringify(notes));
        displaySavedNotes(noteCardSelect.value || null);
    }
}

function displayCardsBasedOnTab() {
    const activeTab = document.querySelector('.tab-button.active').dataset.tab;
    allCardsList.style.display = activeTab === 'all' ? 'block' : 'none';
    myCardsList.style.display = activeTab === 'my' ? 'block' : 'none';
    subjectTreeElement.style.display = 'none';
    notesTabElement.style.display = activeTab === 'notes' ? 'block' : 'none';
    searchBox.style.display = activeTab !== 'notes' ? 'block' : 'none';
    document.querySelector('.subject-filter').style.display = activeTab !== 'notes' ? 'flex' : 'none';

    if (activeTab === 'all') {
        //Analytics.firePageViewEvent("Open All Tab", document.location.href);
        displayCards(allCardData, allCardsList);
    } else if (activeTab === 'my') {
       // Analytics.firePageViewEvent("Open My Tab", document.location.href);
        displayCards(myCardData, myCardsList);
        if (subjectDetailsToShowOnMyTab) {
            const card = myCardData.find(c => c.id === subjectDetailsToShowOnMyTab.cardId);
            if (card) {
                showSubjectTree(subjectDetailsToShowOnMyTab.cardId, card.text, card.description, subjectDetailsToShowOnMyTab.subjectDetails);
                updateProgressCircle(subjectDetailsToShowOnMyTab.cardId);
            }
            subjectDetailsToShowOnMyTab = null;
        }
    } else if (activeTab === 'notes') {
        Analytics.firePageViewEvent("OPEN_NOTES_TAB", document.location.href);
        displaySavedNotes(noteCardSelect.value || null);
    }
}

function showSubjectTree(cardId, cardTitleText, cardDescriptionText, subjectDetails) {
    console.log("Card Title in showSubjectTree:", cardTitleText);
    allCardsList.style.display = 'none';
    myCardsList.style.display = 'none';
    subjectTreeElement.style.display = 'block';
    notesTabElement.style.display = 'none';
    subjectListElement.innerHTML = '';
    searchBox.style.display = 'none';
    document.querySelector('.subject-filter').style.display = 'none';
    subjectTreeElement.dataset.cardId = cardId;

    let topSection = subjectTreeElement.querySelector('.subject-tree-top');
    if (!topSection) {
        topSection = document.createElement('div');
        topSection.classList.add('subject-tree-top');
        topSection.style.display = 'flex';
        topSection.style.alignItems = 'center';
        topSection.style.justifyContent = 'space-between';
        topSection.style.marginBottom = '10px';
        subjectTreeElement.prepend(topSection);

        const backButton = document.createElement('button');
        backButton.id = 'backToCardsTop';
        backButton.innerHTML = `<div class="back-icon"></div>`;
        backButton.title = 'Go Back';
        backButton.addEventListener('click', () => {
            const activeTab = document.querySelector('.tab-button.active').dataset.tab;
            if (activeTab === 'all') {
                allTabButton.click();
            } else if (activeTab === 'my') {
                myTabButton.click();
            }
            searchBox.style.display = 'block';
            document.querySelector('.subject-filter').style.display = 'flex';
        });
        topSection.appendChild(backButton);

        const progressCircle = document.createElement('div');
        progressCircle.classList.add('progress-circle');
        topSection.appendChild(progressCircle);
    }

    const activeTab = document.querySelector('.tab-button.active').dataset.tab;
    let addNoteHereButton = topSection.querySelector('#addNoteHereButton');

    if (activeTab === 'all' && addNoteHereButton) {
        topSection.removeChild(addNoteHereButton);
    }

    if (activeTab === 'my' && !addNoteHereButton) {
        addNoteHereButton = document.createElement('button');
        addNoteHereButton.id = 'addNoteHereButton';
        addNoteHereButton.innerHTML = '<div class="notes-icon"></div>';
        addNoteHereButton.title = 'Add Note';
        addNoteHereButton.addEventListener('click', () => {
            notesTabButton.click();
            noteCardSelect.value = cardTitleText;
            displaySavedNotes(cardTitleText);
        });
        const progressCircle = topSection.querySelector('.progress-circle');
        topSection.insertBefore(addNoteHereButton, progressCircle);
    } else if (activeTab === 'my' && addNoteHereButton) {
        topSection.removeChild(addNoteHereButton);
        addNoteHereButton = document.createElement('button');
        addNoteHereButton.id = 'addNoteHereButton';
        addNoteHereButton.innerHTML = '<div class="notes-icon"></div>';
        addNoteHereButton.title = 'Add Note';
        addNoteHereButton.addEventListener('click', () => {
            notesTabButton.click();
            noteCardSelect.value = cardTitleText;
            displaySavedNotes(cardTitleText);
        });
        const progressCircle = topSection.querySelector('.progress-circle');
        topSection.insertBefore(addNoteHereButton, progressCircle);
    }

    updateProgressCircle(cardId);

    let cardInfo = subjectTreeElement.querySelector('.card-info');
    if (!cardInfo) {
        cardInfo = document.createElement('div');
        cardInfo.classList.add('card-info');
        cardInfo.style.textAlign = 'center';
        cardInfo.style.marginBottom = '20px';
        subjectTreeElement.insertBefore(cardInfo, topSection.nextSibling);

        const titleElement = document.createElement('h3');
        cardInfo.appendChild(titleElement);

        const descriptionElement = document.createElement('p');
        cardInfo.appendChild(descriptionElement);
    }
    cardInfo.querySelector('h3').textContent = cardTitleText;
    cardInfo.querySelector('p').textContent = cardDescriptionText;
    
    const storedProgressForDisplay = cardId ? JSON.parse(localStorage.getItem(`card-${cardId}-progress`) || '{}') : {};

    function updateProgress(subSubject, completed) {
        const displayedCardId = subjectTreeElement.dataset.cardId;
        if (displayedCardId) {
            const progressToUpdate = JSON.parse(localStorage.getItem(`card-${displayedCardId}-progress`) || '{}');
            progressToUpdate[subSubject] = completed;
            localStorage.setItem(`card-${displayedCardId}-progress`, JSON.stringify(progressToUpdate));
            updateProgressCircle(displayedCardId);
        }
    }

    subjectListElement.innerHTML = '';

    for (const subject in subjectDetails) {
        const subSubjects = subjectDetails[subject];
        const finishedCount = subSubjects.filter(subSubject => storedProgressForDisplay[subSubject]).length;
        const totalCount = subSubjects.length;

        const subjectHeader = document.createElement('h2');
        subjectHeader.classList.add('accordion-header');
        subjectHeader.innerHTML = `<span class="accordion-icon">+</span> ${subject} <span class="progress-count">(${finishedCount}/${totalCount})</span>`;
        subjectHeader.addEventListener('click', () => {
            const content = subjectHeader.nextElementSibling;
            const iconSpan = subjectHeader.querySelector('.accordion-icon');
            iconSpan.textContent = content.style.display === 'block' ? '+' : '-';
            content.style.display = content.style.display === 'block' ? 'none' : 'block';
        });
        subjectListElement.appendChild(subjectHeader);

        const subSubjectList = document.createElement('div');
        subSubjectList.classList.add('accordion-content');
        subSubjectList.style.display = 'none';
        subSubjects.forEach(subSubject => {
            const subSubjectItem = document.createElement('div');
            subSubjectItem.classList.add('accordion-item');

            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = storedProgressForDisplay[subSubject] || false;
            checkbox.addEventListener('change', (event) => {
                event.stopPropagation();
                updateProgress(subSubject, event.target.checked);
                subSubjectLabel.classList.toggle('sub-subject-finished', event.target.checked);
            });
            subSubjectItem.appendChild(checkbox);

            const subSubjectLabel = document.createElement('h2');
            subSubjectLabel.textContent = subSubject;
            if (storedProgressForDisplay[subSubject]) {
                subSubjectLabel.classList.add('sub-subject-finished');
            }
            subSubjectLabel.style.cursor = 'pointer';
           
            subSubjectLabel.addEventListener('click', () => {
                const prompt = 'You are an expert teacher of the  '+cardTitleText+' \n'+cardDescriptionText +' \n'+ "Provide a step-by-step explanation with examples for the topic: \n"+subject+" "+subSubject;
                const text = subSubjectLabel.textContent;
                navigator.clipboard.writeText( prompt)
                    .then(() => {
                        subSubjectLabel.textContent = 'Please Past The Copied text to your AI ChatBox ';
                        subSubjectLabel.classList.add('sub-subject-copied');
                        setTimeout(() => {
                            subSubjectLabel.classList.remove('sub-subject-copied');
                            subSubjectLabel.textContent = text;
                        }, 7000);
                    })
                    .catch(err => {
                        console.error('Failed to copy text: ', err);
                    });
            });
            subSubjectItem.appendChild(subSubjectLabel);

            subSubjectList.appendChild(subSubjectItem);
        });
        subjectListElement.appendChild(subSubjectList);
    }
}

function updateProgressCircle(cardId) {
    const progressCircle = subjectTreeElement.querySelector('.progress-circle');
    if (progressCircle && cardId) {
        let totalSubSubjects = 0;
        let completedSubSubjects = 0;
        const storedProgress = JSON.parse(localStorage.getItem(`card-${cardId}-progress`) || '{}');
        const card = allCardData.find(c => c.id === parseInt(cardId)) || myCardData.find(c => c.id === parseInt(cardId));

        if (card && card.subjectDetails) {
            for (const subject in card.subjectDetails) {
                totalSubSubjects += card.subjectDetails[subject].length;
                card.subjectDetails[subject].forEach(subSubject => {
                    if (storedProgress[subSubject]) {
                        completedSubSubjects++;
                    }
                });
            }

            const progressPercentage = totalSubSubjects > 0 ? (completedSubSubjects / totalSubSubjects) * 100 : 0;
            applyProgressCircleStyle(progressCircle, progressPercentage);
        }
    }
}

function applyProgressCircleStyle(element, percentage) {
    const roundedPercentage = Math.round(percentage);
    element.style.setProperty('--progress-percent', `${roundedPercentage}%`);
    let progressText = element.querySelector('.progress-text');
    if (!progressText) {
        progressText = document.createElement('span');
        progressText.classList.add('progress-text');
        element.appendChild(progressText);
    }
    progressText.textContent = `${roundedPercentage}%`;
}

function searchCards() {
   // Analytics.fireEvent('SEARCH_WORDS', { searched_words: searchBox.value.toLowerCase()});
    const searchTerm = searchBox.value.toLowerCase();
    const activeTab = document.querySelector('.tab-button.active').dataset.tab;
    let currentCardData = activeTab === 'all' ? allCardData : myCardData;

    const filteredCards = currentCardData.filter(card =>
        card.text.toLowerCase().includes(searchTerm) ||
        card.subjects.some(subject => subject.toLowerCase().includes(searchTerm))
    );

    const targetElement = activeTab === 'all' ? allCardsList : myCardsList;
    displayCards(filteredCards, targetElement);
}

cardTabsElement.addEventListener('click', (event) => {
    if (event.target.classList.contains('tab-button')) {
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        event.target.classList.add('active');
        displayCardsBasedOnTab();
    }
});

subjectFilterElement.addEventListener('change', () => {
    const selectedSubject = subjectFilterElement.value;
    const activeTab = document.querySelector('.tab-button.active').dataset.tab;
    let currentCardData = activeTab === 'all' ? allCardData : myCardData;
    const filteredCards = selectedSubject === ""
        ? currentCardData
        : currentCardData.filter(card => card.subjects.includes(selectedSubject));
    const targetElement = activeTab === 'all' ? allCardsList : myCardsList;
    displayCards(filteredCards, targetElement);
});

searchBox.addEventListener('keyup', searchCards);
/*searchBox.addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
          searchCards();
      
    }
  });*/
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.message === "selectedText") {
        selectedTextElement.value = request.text;
    }
});

addNoteButton.addEventListener('click', () => {
    noteEditor.style.display = 'block';
});

saveNoteButton.addEventListener('click', () => {
    const noteText = noteTextarea.value;
    const selectedCardTitle = noteCardSelect.value;

    if (noteText.trim() !== "") {
        let notes = JSON.parse(localStorage.getItem('myNotes') || '[]');
        notes.push({
            title: selectedCardTitle,
            note: noteText,
            timestamp: Date.now() // Add timestamp to the new note
        });
        localStorage.setItem('myNotes', JSON.stringify(notes));
        noteTextarea.value = '';
        noteEditor.style.display = 'none';
        displaySavedNotes(noteCardSelect.value || null);
    }
});

noteCardSelect.addEventListener('change', () => {
    displaySavedNotes(noteCardSelect.value || null);
});

loadMyCards();
populateSubjectFilter();
displayCardsBasedOnTab();