(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/main.tsx-e2f740dd.js")
    );
  })().catch(console.error);

})();
