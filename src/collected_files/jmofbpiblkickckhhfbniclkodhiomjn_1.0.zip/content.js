// This script runs on poe2skills.org pages
console.log('PoE2Skills Helper content script loaded');

// You can add functionality here to interact with the webpage if needed