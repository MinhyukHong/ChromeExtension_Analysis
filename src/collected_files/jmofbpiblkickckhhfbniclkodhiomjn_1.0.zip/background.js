chrome.runtime.onInstalled.addListener(function() {
    console.log('PoE2Skills Helper extension installed');
});