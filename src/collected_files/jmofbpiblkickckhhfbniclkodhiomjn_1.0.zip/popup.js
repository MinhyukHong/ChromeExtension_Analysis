document.addEventListener('DOMContentLoaded', function() {
    // Tab functionality
    const tabs = document.querySelectorAll('.tablinks');
    tabs.forEach(tab => {
        tab.addEventListener('click', function(event) {
            openTab(event, this.dataset.tab);
        });
    });

    // Set the first tab as active by default
    tabs[0].click();

    // Skill search functionality
    const skillSearchInput = document.getElementById('skillSearchInput');
    skillSearchInput.addEventListener('input', debounce(searchSkills, 300));


    // Save build functionality


        // 在 DOMContentLoaded 事件监听器中添加：
    document.getElementById('saveBuildBtn').addEventListener('click', saveBuild);
    loadSavedBuilds(); // 初始加载保存的构建
    // Load saved builds
    loadSavedBuilds();

    // Check if we're on a build page
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0].url.includes('poe2skills.org/planner')) {
            saveBuildBtn.disabled = false;
        }
    });

    updateSaveButtonState();

});

chrome.tabs.onActivated.addListener(updateSaveButtonState);
chrome.tabs.onUpdated.addListener(updateSaveButtonState);

function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.classList.add("active");
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

async function searchSkills() {
    const searchTerm = document.getElementById('skillSearchInput').value;
    const searchResults = document.getElementById('searchResults');
    
    if (searchTerm.length < 2) {
        searchResults.innerHTML = '<p>Please enter at least 2 characters to search.</p>';
        return;
    }

    searchResults.innerHTML = '<p>Searching...</p>';

    try {
        const [skillsResponse, supportResponse] = await Promise.all([
            fetch(`https://www.poe2skills.org/api/skills?search=${encodeURIComponent(searchTerm)}&page=1&pageSize=10`),
            fetch(`https://www.poe2skills.org/api/support?search=${encodeURIComponent(searchTerm)}&page=1&pageSize=10`)
        ]);

        const skillsData = await skillsResponse.json();
        const supportData = await supportResponse.json();

        displaySearchResults(skillsData.data, supportData.data);
    } catch (error) {
        console.error('Error fetching skills:', error);
        searchResults.innerHTML = '<p>An error occurred while searching. Please try again.</p>';
    }
}

function displaySearchResults(skills, supportSkills) {
    const searchResults = document.getElementById('searchResults');
    searchResults.innerHTML = '';

    if (skills.length === 0 && supportSkills.length === 0) {
        searchResults.innerHTML = '<p class="no-results">No results found.</p>';
        return;
    }

    const createSkillElement = (skill, isSupport) => {
        const skillElement = document.createElement('div');
        skillElement.className = 'skill-result';
        
        let effectsHtml = '';
        if (skill.Effects) {
            effectsHtml = '<h4>Effects:</h4><ul>' + 
                skill.Effects.split('|').map(effect => `<li>${effect.trim()}</li>`).join('') + 
                '</ul>';
        }

        skillElement.innerHTML = `
            <h3 class="${isSupport ? 'support-skill' : 'active-skill'}">${skill.Name}</h3>
            <div class="skill-type">${isSupport ? 'Support' : skill.Type}</div>
            <div class="skill-tags">${skill.Tags || 'N/A'}</div>
            <p class="skill-description">${skill.Description || 'No description available.'}</p>
            ${effectsHtml}
        `;
        return skillElement;
    };

    if (skills.length > 0) {
        const skillsHeader = document.createElement('h4');
        skillsHeader.textContent = 'Active Skills';
        skillsHeader.className = 'category-header';
        searchResults.appendChild(skillsHeader);
        skills.forEach(skill => searchResults.appendChild(createSkillElement(skill, false)));
    }

    if (supportSkills.length > 0) {
        const supportHeader = document.createElement('h4');
        supportHeader.textContent = 'Support Skills';
        supportHeader.className = 'category-header';
        searchResults.appendChild(supportHeader);
        supportSkills.forEach(skill => searchResults.appendChild(createSkillElement(skill, true)));
    }
}

function saveBuild() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const url = tabs[0].url;
        if (url.includes('poe2skills.org') && url.includes('/planner')) {
            // 检查 URL 是否包含构建 ID
            const buildUrl = url.includes('?build=') ? url : null;
            
            if (buildUrl) {
                const buildName = prompt("Enter a name for this build:");
                if (buildName) {
                    const buildData = {
                        name: buildName,
                        url: buildUrl,
                        date: new Date().toLocaleString()
                    };
                    chrome.storage.sync.get({builds: []}, function(data) {
                        data.builds.push(buildData);
                        chrome.storage.sync.set({builds: data.builds}, function() {
                            loadSavedBuilds();
                            alert("Build saved successfully!");
                        });
                    });
                }
            } else {
                alert("Please make changes to your build and generate a shareable link before saving.");
            }
        } else {
            alert("Please navigate to a PoE2Skills planner page to save a build.");
        }
    });
}

function updateSaveButtonState() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const url = tabs[0].url;
        const saveBuildBtn = document.getElementById('saveBuildBtn');
        if (url.includes('poe2skills.org') && url.includes('/planner')) {
            if (url.includes('?build=')) {
                saveBuildBtn.disabled = false;
                saveBuildBtn.title = "Save current build";
            } else {
                saveBuildBtn.disabled = true;
                saveBuildBtn.title = "Generate a shareable link in the planner before saving";
            }
        } else {
            saveBuildBtn.disabled = true;
            saveBuildBtn.title = "Navigate to a PoE2Skills planner page to save a build";
        }
    });
}
function loadSavedBuilds() {
    const savedBuildsElement = document.getElementById('savedBuilds');
    chrome.storage.sync.get({builds: []}, function(data) {
        savedBuildsElement.innerHTML = '';
        if (data.builds.length === 0) {
            savedBuildsElement.innerHTML = '<p class="no-builds">No saved builds yet.</p>';
        } else {
            data.builds.forEach((build, index) => {
                const buildElement = document.createElement('div');
                buildElement.className = 'saved-build';
                buildElement.innerHTML = `
                    <h3>${build.name}</h3>
                    <p>Saved on: ${build.date}</p>
                    <div class="build-actions">
                        <button class="action-button small open-build">Open</button>
                        <button class="action-button small copy-build">Copy Link</button>
                        <button class="action-button small delete delete-build">Delete</button>
                    </div>
                `;
                
                buildElement.querySelector('.open-build').addEventListener('click', () => openBuild(build.url));
                buildElement.querySelector('.copy-build').addEventListener('click', () => copyBuildLink(build.url));
                buildElement.querySelector('.delete-build').addEventListener('click', () => deleteBuild(index));
                
                savedBuildsElement.appendChild(buildElement);
            });
        }
    });
}

function openBuild(url) {
    chrome.tabs.create({ url: url }, function(tab) {
        if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError);
            alert("Error opening build: " + chrome.runtime.lastError.message);
        }
    });
}
function copyBuildLink(url) {
    navigator.clipboard.writeText(url).then(function() {
        alert('Build link copied to clipboard!');
    }, function(err) {
        console.error('Could not copy text: ', err);
        alert('Failed to copy build link: ' + err);
    });
}

function deleteBuild(index) {
    if (confirm('Are you sure you want to delete this build?')) {
        chrome.storage.sync.get({builds: []}, function(data) {
            data.builds.splice(index, 1);
            chrome.storage.sync.set({builds: data.builds}, function() {
                loadSavedBuilds();
            });
        });
    }
}



