var urlarray = [];

$(document).ready(function(){
	$("#inserturl").click(function(){
		inputurl();
	});

	$("#inputurl").keypress(function(e){
		if( e.which == 13 ){
			inputurl();
		}
	});

	$(document).on("click", ".removemark", function(){
		removeurl( $(this).attr("data-num") );
	});

	$(document).on("click", ".removeall", function(){
		removeall();
	});

	chrome.storage.sync.get('urls', function( items ){
		urlarray = JSON.parse( items.urls );

		printurl();
	});
});

function inputurl(){
	urlarray.push( { 'url': $("#inputurl").val(), 'type': $("#inputtype").val() } );
	printurl();
	$("#inputurl").val("");
	$("#inputurl").focus();
}

function printurl(){
	$("#urllist").html("");
	urlarray.forEach( function showurl(value, index){
		$("#urllist").append("<li><span class='removemark' data-num='"+index+"'>X</span> "+value.url+ "<span style='margin-left:15px;'>[ " +value.type+" ]</span></li>");
	});

	var jsonstring = JSON.stringify(urlarray);
	chrome.storage.sync.set({'urls': jsonstring}, function(){
		console.log("saved");
		chrome.runtime.sendMessage({'urls': jsonstring});
	});
}

function removeurl(index){
	urlarray.splice(index, 1);
	printurl();
}

function removeall(){
	if( confirm("Delete all urls. are you sure?") ){
		urlarray.splice(0);
		printurl();
	}
}