var urllist = [];

geturllist();

chrome.webRequest.onBeforeRequest.addListener(
	modifyUrl, { urls: ['<all_urls>']}, ['blocking']
);

chrome.extension.onMessage.addListener(function(request, sender, sendReponse) {
    geturllist();
});

function modifyUrl(details){
	var flag = false;
	urllist.forEach( function blocking(value){
		if( details.url.indexOf(value.url) != -1 && details.type == value.type){
			flag = true;
		}
	});

	if( flag == true ){
		return { cancel: true };
	}
}

function geturllist(){
	chrome.storage.sync.get('urls', function( items ){
		urllist = JSON.parse( items.urls );
	});
}