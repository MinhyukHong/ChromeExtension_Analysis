var paaperDiv = document.getElementById("paaperDiv");
if(paaperDiv){
   paaperDiv.parentNode.removeChild(paaperDiv);
}
this.paaper = null;