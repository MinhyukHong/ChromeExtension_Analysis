const t="deutsch",e={contentName:t};export{t as contentName,e as default};
