const t="english",n={contentName:t};export{t as contentName,n as default};
