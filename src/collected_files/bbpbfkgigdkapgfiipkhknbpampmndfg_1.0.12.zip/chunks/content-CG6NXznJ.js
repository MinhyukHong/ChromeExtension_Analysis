const t="中文简体",n={contentName:t};export{t as contentName,n as default};
