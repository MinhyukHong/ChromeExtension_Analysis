const t="español",e={contentName:t};export{t as contentName,e as default};
