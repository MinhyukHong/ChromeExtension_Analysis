const API_BASE = 'https://api.misbar.com/v1/';

function strippedString(str) {
  return str = str.replace(/(<([^>]+)>)/gi, "");
}

function updatePopup(data) {
  let body = document.getElementsByTagName("body")[0];

  let description = `<span class="no-description">الوصف غير متاح حاليا</span>`;
  if(data.description) {
    description = `<span dir="rtl">` + strippedString(data.description).substring(0, 240) + `..</span>`;
  }

  let desktop = `<img src="images/imageicon.svg"><div class="no-preview-available">NO PREVIEW AVAILABLE</div>`;
  if(data.desktop_screenshot) {
    desktop = `<img class="screenshot-desktop-image" src="https://assets.misbar.com/` + data.desktop_screenshot + `">`;
  }

  let mobile = `<img src="images/imageicon.svg"><div class="no-preview-available">NO PREVIEW AVAILABLE</div>`;
  if(data.mobile_screenshot) {
    mobile = `<img class="screenshot-mobile-image" src="https://assets.misbar.com/` + data.mobile_screenshot + `">`;
  }

  let credibilityClass = {
    'A': 'bg--green',
    'B': 'bg--blue',
    'C': 'bg--yellow',
    'D': 'bg--purple',
    'E': 'bg--pink'
  };

  let template = `
  <div class="main-box">
  
  <div class="source-title-box">
    <img class="title-icon" alt="` + data.name + `" src="` + data.path + `">
    <div class="source-title">
      <div class="source-title-name">` + data.name + `</div>
    </div>
  </div>
  
  <div class="source-data">
    <div class="source-data-description-box">
      <div class="source-description">` + description + `</div>
    </div>
  
    <div class="source-data-image-box">
      <div class="screenshot">
        <div class="desktop">` + desktop + `</div>
        <div class="mobile">` + mobile +`</div>
      </div>
    </div>
  </div>
  
  <div class="source-numbers">
    <div class="source-numbers-box">
      <div class="sources-item source-numbers-item">
        <div class="embed-responsive embed-responsive-1by1">
          <a class="sources-item-link embed-responsive-item rounded-circle bg--purple">
            <div class="source-numbers-item-title">مرتبة مسبار</div>
            <div class="source-numbers-item-value">` + data.rank + `</div>
          </a>
        </div>
      </div>
    </div>
    <div class="source-numbers-box">
      <div class="sources-item source-numbers-item">
        <div class="embed-responsive embed-responsive-1by1">
          <a class="sources-item-link embed-responsive-item rounded-circle bg--purple">
            <div class="source-numbers-item-title">الادعائات الزائفة</div>
            <div class="source-numbers-item-value">` + data.all_time_total + `</div>
          </a>
        </div>
      </div>
    </div>
    <div class="source-numbers-box d_flex justify_content_end">
      <div class="sources-item source-numbers-item sources-item-credibility m-0">
        <div class="embed-responsive embed-responsive-1by1">
          <a class="sources-item-link embed-responsive-item rounded-circle ` + credibilityClass[data.credibility] + `">
            <div class="source-numbers-item-title">
              <span>مستوى المصداقية</span>
            </div>
            <div class="source-numbers-item-value">` + data.credibility + `</div>
          </a>
        </div>
      </div>
    </div>
  </div>
  <div class="go-to-website">
    <a href="` + data.url_path + `" target="_blank">لتحليل الموقع الكامل <img src="images/back.png"></a>
  </div>
  
  </div>
  `;

  body.innerHTML = template;
}

function dataNotFoundPopup() {
  let body = document.getElementsByTagName("body")[0];
  
  let template = `
  <div class="data-not-found-box">
    <div class="data-not-found">لا يوجد معطيات عن هذا الموقع حاليا</div>
    <div class="go-to-website">
      <a href="https://misbar.com" target="_blank">لزيارة موقع مسبار <img src="images/back.png"></a>
    </div>
  </div>`;

  body.innerHTML = template;
}

setTimeout(async () => {
  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let websiteUrl = new URL(tab.url).hostname;
  websiteUrl = websiteUrl.replace('www.', '');

  const xhttp = new XMLHttpRequest();
  xhttp.onload = function() {
    console.log(xhttp);
    if(xhttp.status == 200) {
      updatePopup(xhttp.response);
    }
    else {
      dataNotFoundPopup();
    }
  }
  xhttp.responseType = 'json';
  xhttp.open('GET', API_BASE + 'statistics/simple/singleSourceCode/' + websiteUrl + '?language=Arabic');
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send();
}, 1);