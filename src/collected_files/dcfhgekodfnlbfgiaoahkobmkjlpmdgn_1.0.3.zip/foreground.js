const API_BASE = 'https://api.misbar.com/v1/';

let iconMouseEnter = false;
let popupMouseover = false;
let foregroundPopup = document.createElement("DIV");

foregroundPopup.classList.add('foreground-popup');
foregroundPopup.classList.add('hide');
foregroundPopup.addEventListener("mouseover", () => { popupMouseover = true; });
foregroundPopup.addEventListener("mouseleave", () => { popupMouseover = false; popupHide(); });

document.querySelector('body').appendChild(foregroundPopup);

let Icons = {
    "A": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAMqADAAQAAAABAAAAMgAAAAB1y6+rAAAGWklEQVRoBd1aXUxcRRQ+c3dZoMCCQLWlsMguFGhrQlKbtBWVf2JNCg8+GH1Q/H1BU5+saVpjG2N5MlF8aIxiH/ShT7QP7UsFHprWQkw1xkYSt1LASqoSQJDusux4zr3u5e7uzOXuvctinWSzM+fMnDnf/Jw5M+cySFNqO3O6MBqJHAK+egA4qwXGqwFYIXBeoHbB2F8AfB55PyNvHJjrmuJ2X7z8+tH5dKjAnAh56tO+8nA4dJhz6OYATah0VkryGFtBBUYYg0GPJ/vCpVffnk6pvaGyLSAEIBS6dxI4vIAAFIM821lUJAoMzmZn55ywAyglIN0DHxYtLC0c5Zy9icsk17bWpg3ZMmP8I2+e9/Rgz1tzplUNTMtAmj8+dZhBdABnoNjQfsOyqNgsB6Vn+I3jF6x0YmlZNPefegc36GCmQJDial/Yp9q3BSSmM/LiwEDO5NLUZ5zz5yzI2rAqjLGvfHkVL3/R03NP1okUiAZi8mu0SAdljTNJR8t21Zfna5WBkS4tbSb+GyBowGhASSfZ4LlEDHVdcn5ExNtk2iNVT7eGJy4OX0nUI2lpkXWijY1DkMRLbLwpZbTN6B10J1qzOGXVc2JxIejUOnlcbsj3ZAtxRvHcm1teFvKsElHpWW++N2A8Z9zGxuphl4Zz4rV9T0BXfYNRtJ5fjUbh2XNnHIGhgSZdUSj91KRvdnI7tBM7xrL371IUaK6qlTYmfmtgl5RvlUG6ks6x+joQ1XdKg9uxv9wP3hxz76UjsDvWv4N/nqvprIlQgajI0AF0IFVv2lZdr+dlGX9xKewseUjGtk5HnWOzogIJh8JduO702bEuKb4mzcT+ikA8UVLqqHE+K6QzXSOoC1V5tGddkv5SIjdV7QQ37gErifaR1bpm8vCg7Ca+Qjc7RNZkVtkqr71aPMooPynR7B304SXSYSLdCYOiXU9TvNkJOq8oLIa60m1JnCgO2eXgzSQ6EdKxvOhWShgUiEbT4hS2V4tN6s27d2Ao+JMQyL4dD0Nxbp6QlxIRMSh4vZQbfYvSyD1oC4it1ej0BHw/MwWhSCRJmoIubVsazhTCgDuTWzMzSWqsERq2V8DWPO2xZI2q5Uanb8HK6ip8NzOZyFLLHTXimRRWlhJ5AIHgk43D1C4xpbPLSxCc/V2Vfn1qQthLZVEJ1G3dLuRZJ7JCBTeLeCgtSslxZ8Hjvhph7dHpX3T6mCGvE//NdEr2V2I9aRkx4Iw4S42V1ZCTJX7OGsP9EUszi/MwNT8bK8b9N/vrIMvliqOlWsDNTi+A9lOH5Owgs/vtndtxgmnji1IeuvyP4YDYTogB3Xh8xgQosSOENnhDmU/YNBRZgSMH2uJ42wq8cWVjobNmD4zcGjeSrOc5zCEQFkQwfuut1mq2+uvR8olTbpYHmvzWLfveskoo3ZIPf/y9KBZoTg3iZgebwwDQbsHTNe9/jUsDInNx1mpJcvgoroCiXJWwTcm16I740HSmM3XYtV70sk9P+7jhV1JVSOaSpCrHWL+88AHY/eAOI2n9POpOGNwUn2jpPzmCXmT7+q20GutdZ8/euAa35/6Uinvl0UYoKygS8jvxpP/x7q9CnoiIS3KEMOBmx+2O8Qm0lpaBmF1nw6sROPfDGNC/LO3Ck/yZPXuF7CfxnvLJ9WGhbyZqQLoTXT0QKciCyKKiiiKa2XX2xm+TpiBI3jfTaCglaQtau8bKGgk3nkw6k+5EJWOhppb+9z7HWemJle+Hf5yNgaHed18iXXUXhSJFiMvZy1lG0bNlTWetUx0IhbsoUpRRXRx0RroaQ3Q6EJJJ4S5ca2LPzkGn6W5KOpKuRrlxQOgtlcJdaMZE7wXGdpuXR91IR+O7LymT5DtPXBoerzrUEkb/q3XztDXpmSnH8CU+KU6iW63EpnhIfrnZIbdEnSgEN9R74vlEOpXjlpaxAsXs0LzZ8sOMctKVJ11IJ5k8KRCK1VHMjkZB1jhTdC0YKo8fkh7SpWVUUgsR8/czHsVSjQ47Ntx7/AOjPqK8JSDU8H/xwQABoZgdhbtwrfZtrAdAn3BAH/WVGCckPWTJ8owYBVBM4r7+qMYIhvIESIutcIqvNNGDcmId03LsMydg5z3ZnvNGl8O0nYBpa0YEckD/8IwexdX3ZHqKFXx4Ro8d9E6AV2y62aXrw7N/AAcsCaC0/pLjAAAAAElFTkSuQmCC",
    "B": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAMqADAAQAAAABAAAAMgAAAAB1y6+rAAAGIklEQVRoBd1aa0wcVRQ+d2aXLYuALKhIrFHXUqOiaUmaqIkSSPtDDdQfkMZaW/CH/tGoqUkbqSLBWP1hjCaatKmFGEnsNukjlWAjTdNUaNW2abVFKlSjhGqFpbx2eezu9ZxZl51ZZtiZu7uDepPN3rn3vL65r3POHQZpKgW1O/OBBR4HiDzEOKzkwO4G4PkALDeqgk9gfYwB7+cM+gCkHuDujlHftrF0mMBSEeLZ2HQbC4WreQTWc8YrgIPTkjwGc4yz40yCg9whH/Z/3jRoiV9FLASEAMBcqBnf+mbgXFLJE68yFsHRagOn4w0RQJaA3LGl6caJQGQb55GXOEC2uNXGnGhQkDHpw1y3tPPX1qbrxpTaHtNAimobq8PA9uK892hFZOqJ+WXg9cO+lsNmNMhmiArrGrdHAHYjrdsMfZposnHUN+Tc/+hs8OKJk8lkLjoiOJWWjU2F9+AoPJ1MUGb7WXt+jvwcTrVpIz2GQAjE+FSoC9/Kw0bMdrajod15OY4qIzCGOw6NxL8FBL0wsiU6O/Rfn+4aoTWBjC/rsyxpa5nRmlkwtaK7ExxEcxf0LSmEuHKOb3994m6mMZbOCRy+Afu22Lh11mrMj4vfqz5nHGoBdNhZBeHJdYNT0rwPtUhNPYIzfWxqBmZDYU279QfuidoKaG+0zFuguB2zocu4Niyd2J07NkH5XSUxeab+J4IzcOrnQfB1X4QDp3tN8SQSoeFByHKUxtyZ+K6l+E7WQCQKN/ucm+2CtQ94YdcL1dD64lNQmGf9nFVeONoc06kAodFQHMBYq43/T6wuhS+3bwSHHH+nZtWTzcpMQgaFm81FatLmxZq1QkXnLfbAsxUPqlpMVtHzpjCCqJXFzjmvMclqiezV1k4YnZwGV5YMK9DYhsrVUHCD/hLcUrEKPu06Z0k+EVMshH8fOyiy42yygo7OdJeuC1dgaBQDw3/K/lO9cLKlAWRp4TS685aCGJmlfwroCIOkhKdWIztLquLE/VdH4Jdro/EGVU1iTBegikS/SrZjiC3h2rDNKcxzu6CkIE/XoEuDf0E4gsGCSEEMDtyPMVGQmeJ0yBi5yuDC34pbC2FHbQW4Xfph/Rff/CBsBGFwIAivsIQkjN+/93wSimh3T9/vsEdgoceEEwbctShlszQlwjns6/4RtrYdxRmeyrzguNjn8072g+k4exk++eo7mJkLpaic5S7cB1MUaYX9yfKV8PWbm6GhapUVNl1amlq00Rfq9qbY+MGRHhgPzCgLng7E6jX3oJ+njeWcsgzvPrMOegeHgdaKWOETCIRhypJnBMjeY+c0B+LurjPQ2bgJGJ4ZiaV5QyWsfastsdncM4PrFElgIGVPOXvlKlz47U9dZWW33wwup+Ix6fYv1oi55gEJ9wpMKNtTcpZloc+lP/jktniLRd0U6EMXhXXbAYMMfa3mEcMDkWy4NjYlaIrU46DUPrDJOcuZdBMqfVvrIBTmGGswWF6UD9lZ+qe6AmJ8CobHAyakJpBgRp8wSHQ/Qan9hO60PJaWFMG9y28C+l8MBCn7qOO0kE6ynTBEAyu8nxCSkiam/j9GgHY4kUJ3K8SnAKFLFlwrgq6niPo4z35MQKxr/kzsdEebFdtRnLLfUSbCU9fYhjtYfVxFZmrjgWkYmQzCmf4hOPDtT3D0fL+wIroYimVR5k8m0XSQsBUpMqLh+ukgQkY3RSnKt42dbI2NBinVOI103YUui982a4QVMX/U1rgADRDKpdJ1F3anEhzEpWemhklsXq/O+5IarSuKDYFLJ/oodY9IqjJjR2pS0Tl8fcTXgrdo2rIACHXTnV32fY+VYrVMS77UT6zd72t5Rc8KzdRSE9CdHe4Mtvhhar1GdbKFbDLqNwSCc3Ca7uxw8bcbMdvXztoXuz8kOxBo8qJcT3N42yx9commKTC5i2tiX8s7yThMASEh/4sPBggI7WbFayp3YcIDwfNybDL2yYlBsKDwoMSk9/Ny5Lqh9ubzZsWYHhG1QMWd+S9/VKMGQ3UCRHcrdC2R0mdOjB3iTumQ2uVI1JXsWWhE9ITOf3iGCWUUSvlkL05BzGImfngGA9jXp4TYafzw7G++eCM9m5nnJAAAAABJRU5ErkJggg==",
    "C": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAMqADAAQAAAABAAAAMgAAAAB1y6+rAAAGwklEQVRoBd1aa2gcVRQ+d3b2lcdOum1SbaNV0yalRRQL1hYEq/jDFJqo+MMo1Pr44+uvLcEHgpgiYvSPINRW0PxQKUnQqLQSkVLx8aPaUpLWUGs2VdN2s5vsZt9zPWc2s5ndzJ2d2U2T6IVlz5x77rnnm3vvOfeeOwwWqYSPPaIkEvF2VeU7UGUbMLaRca5wYPXUBQM+wxmLAue/4+OoJLEf/P7aoeD9n0WpvtrCqlEQGnqomWVTezjnnfi7B3W5HerLMMa+w18/l72Dze1HQw7bF8QrAkIAIJt8HVTYy4FLBW1VEAyYChJ8BLLvlUoAOQIyNdzZMBtN7VeBvQjA/VXYbdGUJSTg79Uo3p5Vu/ojFoJFVbaBTAzs3qNy9TC2DhZpuHYPYYlJ+9Z3fDlopwtb0yI00H6Ag9q/hCDI9iD1SX3bAWI5Inz4CV8oOnkIp1GXHWXXTob1NStNT7FdR5KiPoRACMREdPJbXMw7RY2Xko/O4OR6pek+ERjh1KKRWCkg6IWRLfnZYf76TIHk5+VyTyczg3mXaM0smFrknWiRcQzJZqqWm8dwi8BA6iz1ZkXGUpyIRVNjaOxSudhK30u4TvG2GOOMbNREwW4xQDCXF7zB28AduAVcXgWYWwGemYFMLAS52UuQieN/YhK74sbundDBOVvJXq0URoS2HTydPFdNxJY8AQhs2gv+tXcBSNbbLp5LQfzPLyD2Rz8Q7bywBPP4WvXtzPxip71TFdsO35pt0Lj9bfBff3dZEGQ0jVrdzQ9D485e8K2txMPjFkmzOf8KtBHRNoHp5MVKNoBM9oPSiqOw7l7nL9XQIvnPSZg63WvglCe1jabHt4FGRRsRlk52VAKCulK2PFs1CNJDo1K7YTeRtgvZTMcIaqABQX/WYbu1QdDXeCf4m7YbONWRgY2Pg0fZ5EgJnYWoAaOTXTweu4y09eosUU9TqmnHOyB5LTw1V9FDjUN2egy4mgGXfx16sy20QEq0zT/mkpdh8sQLyFDnmdZUpra2rlGm4ynKOQJBegMtj1qCSEdHIXL6XcglrxSZIdeu06ajR2kt4usPLl8jeBpaIR0Z0Vnl/t2EQVI5c+4yJBnXxS5hB6mrp+DqL68uAEENsvFLMHXqINbRJDAv3jW3m1cIuIRBwojfJqgXsr0NmzX3aSqA02n63BH05OKpoWJwpBgiKl505U4KYZAxtrY4aUSy7npxk2T4V+2tl9OZ+OsEBsKsQIwiPkUGe5GfMMj5lI1An4AteRoENQC52LiwzlhBozI7cczIqpgmDJKed3KiRXLXCMWzJYtbKLiIFYRBiyNOdarZmLCJ7L9OWHctK2QtAwiw2kknuVREKC7XbRDWFVdI6L7FU1TV+hA7DKMuwiDPpTEdAclEzxv1FNHe4FYtOqctZKgBbS4btj5X1FZ/4JkY/P3903bXOrmECLpfoIOUo5KOnMPzhXh6BTY/AxT5RUVy10M97nxFJXn5Z0v3bdJujBb7qElFGZYK8dDXQhl3/U24pX8LPKtwO1JS3IEWCN7xMrhqxGspOfljSauyj6OyxPhJlcPzZUVLBGYuHAVf006gLYdZcfmbYPW210BNT0Nm5iKQgyBZd5k1RPLJq7+ZqRTyKLMvUWofJTJCKVGFmoXoyAei2gKfTo3e1bfiqXFHWRC0UYyc6cVpJQqUBbVGIkMYJLqfoNS+scYunZ46i0HtuF3xsnLT5z+GVPhMWTmjANlOGPIHK7yfMFY6oaMjhyB24XOni3NBF4lLwxC/KN5/LWgwx6C7FSLzByu8ZNGOjSJpKz7PwczYp3DlpwOQtbk9MarLYlZl6lQPRM6+b2TboslmuiAiYe3MTkRosP1DrvJ9RFdcmIxu9UFti+/yrbFUk0uFcQQGIT7+DY5mzlJWVMkkdrh5z9CTVD8PZBHSQcYO5bobMTC2YfRWwOXBvJaazue1MKeViU/gep41ildAF6eDCkBI00T/Az24KXipAq1L3gTXxMH1nV/t1zvW1oj+QNddSIf15xX8H56ztWBiERDKpdJ1FyWKCxIrjCDbyEZj3pdMLAJCjHyWm3UTvTIL6y7NxJOdRWvEaPh4f/sn6E66jLzlp1nfDZ1Dj5nZsWBEdCHtzg6vu/Tn5f6nqzeySWSHEAjd1dGdHQ5an6jx0vFZn9X9IdkhnFpGI+eu4t5Y6lusvNNh3c0dQ28a7TGjbQGhhiv9gwHbQAjM/+ITDgKil//8RzU6EP2fAGl3K3gtUdVnThwGuMc3oF+j6fqd/DuaWlaKCx+eYUIZg28bpTHNPjzDDscoT0BH7MX88Oxfr9iP62DmBIIAAAAASUVORK5CYII=",
    "D": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAMqADAAQAAAABAAAAMgAAAAB1y6+rAAAGMklEQVRoBd1aa0wcVRQ+d3Z5FMLTB92CbVOgbWKKGoyxFXURqMFo4U8N1hhF+7Mx1j/FGHEpMaI/NNXEH2pt+UNirIaSlEZBpQnQRtvGamODwMpTESqU5y677FzPGZnNwO6dndllF/Qmm71zz7nnft/c9znDYI1SQ2lD2iJbeAI47OWM7wLO8hjwNM5YCjXBOJ/lwKYx08c46wEGFxN4UmtNe830WkBgkRh5p9yRs+jzHeCcVQLndg4QZ8YeNu4FxjoY480JFkvLsfOOETP1tbphESEC7iX5OAJ/HglIWoNh5xmTEUxjolWqDYeQKSLvVzrSZ+blGgT/MpLYFDZonYoIyIW99EFqstRwtNlxS0d1hcgwkfoyxwEfyKeQROYKC9F6YGzSAlL1G22OFiNNWIwo1e2vfY1z+RPUTTKiv0Y62OO8qjjP7unov9AZyqZuj5x6wZE4OOI7iUYOhTIUZXnTthzLS9WnHW5RO0IiColR+VscSvtElWNazlj3tmypRERGuOIoPbFRSNAbQyzLoyPo+ws6R2hO4Mb2StAa61u4RzRnAoYWrU4y9zXj8hogW18O/7aOoLjELJWrV7MVYGmfmJ6X+2O2xIb7ZnBpTkuWcrX7jFVra3mzM7xPxCXGQ8Km0KcSj9sLHpdH21RkedzLFKwANaohf48oxw6v7zczO3bRwX1gf7ZItaX7v+RZgrmpORj4ZQh6f+iH3qtOkJd8unX0hAjclRhn2akeZ/w9snx2isqxgwBZ462QnpUO99KvtADGB29Cy4lzMOb8Sw+vUEYvnDCjwoukpKxa1BtemZ/GZ38PkTBU2nr3XbC9YGsotaDy5PQkuK+sAI9VDIZvjOK0RGhmE2P3lO8q/qy9r2NG2UeQWQVaEu4pZu0b1WeSBI9UPQTV7z4HcYmh51qAXcRM1wgqV8FXBCjFsMCWmwX2Z4zNtdWwlLsQEaGbHfaGfbVCpM/jAxPQd8UJv18bBNfMQkhzDzx1P9jyNofUC1BA7MTBStdTHJ5h9GuAyRUFl1p+hJ+/u+4vy7BlwP7Dj0F+Ya6/TJthEoMnj5TDp682ApdlrUg3jzMrjjhIeI+OyaFw6s8p+Lz+S+g6c1EILGv7HbD7wXyhXCQgDvge0FEQw9TR1AUTQ38LW8wr3CGUiQTEQcJhFbyvRbUiLKdh0/WVuFdydmebboE4UI+kma4ZYYWx/nGhhZSMZKFMJCAOkup3EilFo3x6QuzKik9KwG3Z1L6MLjSWou4j0cArtJm5OV0oc8/hbTaMXV4iD6DQapQEtnyb0PLs5LxQJhIQB1p+xf0sqhlBOR0eHz64V2hh6NchoUxHcEvC4divo7CmIskiweOHSyDtTvH60nfZabpNjhys2CM9OCjLTNc2UYF6YUueDUqr7bBFZ1gN3xiB3svm3ys5xa24dHXjNn/EBC5DqvZDRUDnJ6vVArdlZwIdQfQSXbLOffS1nopYhp59K7n2F2HeS2cWsaZ5SertqUA/o6nzzCW4OSze8UV28PV4iYOkxCfQtS9SjEW586cBICJhJcROHJSrLsUncOmO6jwJBtKLTon2xgtw5fzVYGJDZYSdFBUiFGRxcfnDWN4SaWK3nGiFqTHDkYNAYhhTSbBIirdeIUKeiLqy2kacJ9WB2pGXeN0emJ9egNnJORi8PqysTKM9f0RsGOdHY4AXhSJFbq+vCskY9qR0ftEN9FuPhCRchFlt23/WUphhpEgVbPh/xKr2BmH1E6EHCnfhyXOS8hs6IUYFqwbkCiLkS6VwF3YbjrCNmQgbYdT6fQmp4qDTQv7e2dFDrnukUqIt3yh5PCG8XttWd3I1ngAipEAxO/uOR3dids/qCuv83ORoqz8aDMOKoaVVoJgdzpf1WZK0QNQ8hd4IkyAJiVCsjmJ2WK9JUDeWxU168UMCgnMndFJCcTJ/C1cAQ/qhLRrTUBYdnBNvfnP87VA1DAOr/z98MEBvg1azioLijz30GQxAIRat6bFffeNo24WhhvcwtPb0sVbHNbU81L/hHtEa+s9/VKMlQ/llQhSSoPhK2J85Yf2zeG46qz1ykH0zKaweCdaA+uEZOZTJF0tuTPIAqg5A9cMzcnaQn4Cu2Gv54dk/aBtJ/hUwt9sAAAAASUVORK5CYII=",
    "E": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAMqADAAQAAAABAAAAMgAAAAB1y6+rAAAEhklEQVRoBd1av08UQRR+b1nlEAXFYDSiDUb+Bq1M7CyE0mhhCIWJMSYUKsZIoTGiFiQWJiYaxERs0cLOxAr/Bow0gjFKgh543OFxO75vjzmW4+bc293b23ObnZ158+b75ueb95Ypomfp6VhnNr1+xqHCCSLuI6WOMXGnIrUHTUh6RdJpYv5MpGYtavnY1mm/67o0ko4CAodRsvD4QQ9n184qogHFdErA76hJH3OeFX0QENOqrfVtz9UbCzXV9wgHIgIClM3dET0XhYTl0Rc4KUAcqTxJbanRIIRqIvJzfHzv6vryiKP4qvR+W2DU1SoyZy1Wj3fZHWP7hod/VRP1lvkm8vXB3bMOOxOkqMuroG5ppiVLWYOHb9x+66cNX9Ni4dHdm4rVdGwkgFw6DG2ibT9Eqo6ImphILSzOP5dpdN6PsrrJME/1dB8Z4sHBnKkNIxGQ+Prjy3tZzCdNlePMF6Azhw8cPW0iY5xaGImkkECHAYs7Owy9V5GIOy8bPZ0qARZMpjWzbWphd8IiU0qOuAQ+zCzweKB8N9sCFufE7/zyXKy7U5DOkq15946OXu85Y3v14LALSsLa1e5VVUPaIWc1W4O8iMrW7GIlGtEVSyMCs0Pl1j4FPbEPXR4Wy7CkTuv/59vJZOj7i6f/lNsmIBYAp1qPa3Nmc7HDdqqX2bENRQQZwFq091xlLhHXCBQDMAL1cau4uIG9aLly7k+/7NOboxM3nIDtATOuEajugpettj+groZXEzIDAMG42WXSfxZlfdR2KSqjYFrshd8rtDj1okza86nk3ri+7smoMSmXs/bOnd02rqdhSVRtGkDz+aoioQplAMDBcpSTCKMwDBlwsGTn7wujJAl1wcGWge+tJ5iWPR10cOiysYnCaoYWX08ay/0UgIO94bLxIx9YhlMpY12rUDCW+S0AB0vYuH4nv5WSKAcOTXcImjpSFjuvmArjyJfeDN0MOGCxw2W5P7Q2g4LCyjL9ePnMUBpNtlwBf2FE5qJR11Atc7LYabahECJpXM3aFlszjipciURfBSVstZC9d1+FkmKWcsR/vxzOIQ/Pvg3Xfibt5Otlb1nt7dR9YdBIJPANUWsUoxEcLMQn4NrX+c32BnZwcM8RsVWmm42AxquxFy9WEmSRDMQnmuoBZgSIANolsuGJmGwqFkWwk9qLsunXkkgR5dbOBfWkfHsyHm8/iDuIUq2jutGSrQVmiBTpgqS/gVWPBrCWiOAD4S4Jvy4hnehHMLpYPSC3EIEvFeEuOIo9MolKAhswev2+ALiFCDJcLzfzLaQT+Qi2ck88cMoOVvmZf3jnlSz8xobcyqFJCO7I9dEL5dn43jYiWsiN2Um4S383+i09PgNMJhxGIojVIWYnHvYpU+XY8gVDtfghcBinlhfkRijuXtxRLHfTkTXRc+32fS+eSmlfRFAx6T8M+CYCMv/FLxwgop+m/6lGE9FvEHJjKxKWCPWbE/Mbldr5xmty6Db8vmuaWtWUln48E4eyKO0T70wvPIBwnqEeXDbw2MDZAT8BrthR/nj2Fyleze5b/JkiAAAAAElFTkSuQmCC"
}

let credibilityMeterIcons;

chrome.storage.local.get(['credibility_meter_A', 'credibility_meter_B', 'credibility_meter_C', 'credibility_meter_D', 'credibility_meter_E'], data => {
    credibilityMeterIcons = data;
});

let googleWebsiteUrl = '';
let googleLinksTags = document.querySelectorAll('a[href^="http"] h3.LC20lb');

if(googleLinksTags.length > 0) {
    for(let i = 0; i<googleLinksTags.length; i++){
        googleWebsiteUrl = new URL(googleLinksTags[i].parentElement.href).hostname;
        googleWebsiteUrl = googleWebsiteUrl.replace('www.', '');
        checkUrl(googleLinksTags[i], googleWebsiteUrl);
    }
}

let googleTopWebsiteUrl = '';
let googleTopLinksTags = document.querySelectorAll('.fhQnRd a[href^="http"] .xCURGd .g5wfEd .CEMjEf');

if(googleTopLinksTags.length > 0) {
    for(let i = 0; i<googleTopLinksTags.length; i++){
        googleTopWebsiteUrl = new URL(googleTopLinksTags[i].closest('a').href).hostname;
        googleTopWebsiteUrl = googleTopWebsiteUrl.replace('www.', '');
        checkUrl(googleTopLinksTags[i], googleTopWebsiteUrl);
    }
}

googleTopWebsiteUrl = '';
googleTopLinksTags = document.querySelectorAll('.dbsr a[href^="http"] .hI5pFf .XTjFC');
if(googleTopLinksTags.length > 0) {
    for(let i = 0; i<googleTopLinksTags.length; i++){
        googleTopWebsiteUrl = new URL(googleTopLinksTags[i].closest('a').href).hostname;
        googleTopWebsiteUrl = googleTopWebsiteUrl.replace('www.', '');
        checkUrl(googleTopLinksTags[i], googleTopWebsiteUrl);
    }
}

googleTopWebsiteUrl = '';
googleTopLinksTags = document.querySelectorAll('a[href^="http"] .iRPxbe .CEMjEf');
if(googleTopLinksTags.length > 0) {
    for(let i = 0; i<googleTopLinksTags.length; i++){
        googleTopWebsiteUrl = new URL(googleTopLinksTags[i].closest('a').href).hostname;
        googleTopWebsiteUrl = googleTopWebsiteUrl.replace('www.', '');
        checkUrl(googleTopLinksTags[i], googleTopWebsiteUrl);
    }
}

function checkUrl(el, websiteUrl) {
    const url = API_BASE + 'statistics/simple/singleSourceCode/' + websiteUrl + '?language=Arabic';
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        if(this.response && this.response.credibility) {
            let data = this.response;

            let div = document.createElement("DIV");
            div.style.display = 'inline-block';
            div.style.position = 'relative';

            let icon = document.createElement("IMG");
            icon.setAttribute("src", Icons[this.response.credibility]);
            icon.setAttribute("width", "18");
            icon.setAttribute("height", "18");
            icon.setAttribute("alt", "image");
            icon.style.marginInlineEnd = '8px';
            
            var timer;
            icon.addEventListener("mouseenter", function(event){
                iconMouseEnter = true;
                timer = setTimeout(function(){
                    foregroundPopup.style.top = (event.pageY - 30) + 'px';
                    foregroundPopup.style.left = (event.pageX + 30) + 'px';
                    foregroundPopup.innerHTML = getPopupTemplate(data);
                    foregroundPopup.classList.remove("hide");
                }, 150);
            });
            
            icon.addEventListener("mouseleave", function(event){
                clearTimeout(timer);
                iconMouseEnter = false;
                let a = setTimeout(() => { 
                    popupHide();
                }, 250);
            });

            div.append(icon);
            el.insertBefore(div, el.firstChild);
        }
    }
    xhttp.responseType = 'json';
    xhttp.open('GET', url);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send();
}

function popupHide() {
    if(!iconMouseEnter && !popupMouseover) {
        let a = setTimeout(() => { 
            foregroundPopup.classList.add("hide");
            clearTimeout(a);
        }, 250);
    }
}

function getPopupTemplate(data) {
    let description = `<span class="no-description">الوصف غير متاح حاليا</span>`;
    if(data.description) {
      description = `<span dir="rtl">` + strippedString(data.description).substring(0, 240) + `..</span>`;
    }
  
    let desktop = `<img src="images/imageicon.svg"><div class="no-preview-available">NO PREVIEW AVAILABLE</div>`;
    if(data.desktop_screenshot) {
      desktop = `<img class="screenshot-desktop-image" src="https://assets.misbar.com/` + data.desktop_screenshot + `">`;
    }
  
    let mobile = `<img src="images/imageicon.svg"><div class="no-preview-available">NO PREVIEW AVAILABLE</div>`;
    if(data.mobile_screenshot) {
      mobile = `<img class="screenshot-mobile-image" src="https://assets.misbar.com/` + data.mobile_screenshot + `">`;
    }

    let credibilityClass = {
        'A': 'bg--green',
        'B': 'bg--blue',
        'C': 'bg--yellow',
        'D': 'bg--purple',
        'E': 'bg--pink'
    };
  
    let template = `
    <div class="main-box">
    
    <div class="source-title-box">
      <img class="title-icon" alt="` + data.name + `" src="` + data.path + `">
      <div class="source-title">
        <div class="source-title-name">` + data.name + `</div>
      </div>
    </div>
    
    <div class="source-data">
      <div class="source-data-description-box">
        <div class="source-description">` + description + `</div>
      </div>
    
      <div class="source-data-image-box">
        <div class="screenshot">
          <div class="desktop">` + desktop + `</div>
          <div class="mobile">` + mobile +`</div>
        </div>
      </div>
    </div>
    
    <div class="source-numbers">
      <div class="source-numbers-box">
        <div class="sources-item source-numbers-item">
          <div class="embed-responsive embed-responsive-1by1">
            <a class="sources-item-link embed-responsive-item rounded-circle bg--purple">
              <div class="source-numbers-item-title">مرتبة مسبار</div>
              <div class="source-numbers-item-value">` + data.rank + `</div>
            </a>
          </div>
        </div>
      </div>
      <div class="source-numbers-box">
        <div class="sources-item source-numbers-item">
          <div class="embed-responsive embed-responsive-1by1">
            <a class="sources-item-link embed-responsive-item rounded-circle bg--purple">
              <div class="source-numbers-item-title">الادعائات الزائفة</div>
              <div class="source-numbers-item-value">` + data.all_time_total + `</div>
            </a>
          </div>
        </div>
      </div>
      <div class="source-numbers-box d_flex justify_content_end">
        <div class="sources-item source-numbers-item sources-item-credibility m-0">
          <div class="embed-responsive embed-responsive-1by1">
            <a class="sources-item-link embed-responsive-item rounded-circle ` + credibilityClass[data.credibility] + `">
              <div class="source-numbers-item-title">
                <span>مستوى المصداقية</span>
              </div>
              <div class="source-numbers-item-value">` + data.credibility + `</div>
            </a>
          </div>
        </div>
      </div>
    </div>
    <div class="go-to-website">
      <a href="` + data.url_path + `" target="_blank" style="color: #0f537c">لتحليل الموقع الكامل 
        <svg viewBox="0 0 20 16" id="arrow-right" xmlns="http://www.w3.org/2000/svg">
          <g fill="none" fill-rule="evenodd" stroke="#0f537c" stroke-linecap="round" stroke-width="2">
            <path stroke-linejoin="round" d="M12.5 1l6 6.75-6 6.75"></path><path d="M18 8H1"></path>
          </g>
        </svg>
    </div>
    
    </div>
    `;
  
    return template;
}

function strippedString(str) {
    return str = str.replace(/(<([^>]+)>)/gi, "");
  }

//******************************************************************************************//

function getCredibility(websiteUrl) {
    const url = API_BASE + 'statistics/credibility/singleSourceCode/' + websiteUrl + '?language=Arabic';
    
    const xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
        if((xhttp.status == 200) && (xhttp.response.credibility) && (['A', 'B', 'C', 'D', 'E'].includes(xhttp.response.credibility))) {
            updateIcon(xhttp.response.credibility);
        }
    }
    xhttp.responseType = 'json';
    xhttp.open('GET', url);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send();
}

function updateIcon(icon) {
    chrome.runtime.sendMessage({ "newIconPath" : credibilityMeterIcons['credibility_meter_' + icon] });
}

setTimeout(async () => {
    chrome.storage.local.get('activeUrl', data => {
        let websiteUrl = new URL(data.activeUrl).hostname;
        websiteUrl = websiteUrl.replace('www.', '');
        getCredibility(websiteUrl);
    });
}, 1);