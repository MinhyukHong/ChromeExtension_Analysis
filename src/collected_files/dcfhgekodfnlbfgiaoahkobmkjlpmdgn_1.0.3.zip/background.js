chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    credibility_meter_A: '/images/a.png',
    credibility_meter_B: '/images/b.png',
    credibility_meter_C: '/images/c.png',
    credibility_meter_D: '/images/d.png',
    credibility_meter_E: '/images/e.png'
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if(changeInfo.status === 'complete' && /^http/.test(tab.url)){

    chrome.storage.local.set({
      activeUrl: tab.url
    });

    chrome.scripting.insertCSS({
      target: {tabId: tabId},
      files: ["foreground.css"]
    }).then(() => {

      chrome.scripting.executeScript({
        target: {tabId: tabId},
        files: ["foreground.js"]
      }).then(() => {
      }).catch(err => console.error(err));

    }).catch(err => console.error(err));

  }
});

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    chrome.action.setIcon({
      path: request.newIconPath,
      tabId: sender.tab.id
    });
  }
);