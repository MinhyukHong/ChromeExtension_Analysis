chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
	if(tab.url){
		var regVK  = /(http|https):\/\/(vk.com)\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
		if(regVK.test(tab.url)){
			chrome.tabs.executeScript(tabId, {
				file:"jt_vk.new.js",
				allFrames:true
			});
		}
	}
});