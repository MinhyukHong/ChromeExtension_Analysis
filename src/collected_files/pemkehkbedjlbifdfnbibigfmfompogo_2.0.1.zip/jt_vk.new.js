/**
 * Created by turin on 22.08.16.
 */
(function(window, document) {
	var timeout;

	/**
	 * Return base HTMLElement for all posts
	 * @returns {HTMLElement}
	 */
	function get_wrapper() {
		return document.getElementById('feed_rows') || document.getElementById('page_wall_posts');
	}

	/**
	 * Proceed all posts
	 */
	function proceed_posts() {
		var wrapper = get_wrapper();
		if (wrapper && wrapper.children && wrapper.children.length) {
			for (var i in wrapper.children) {
				if (wrapper.children.hasOwnProperty(i)) {
					proceed_post(wrapper.children[i]);
				}
			}
		}
	}

	/**
	 * Proceed only one post
	 * @param post HTMLElement
	 */
	function proceed_post(post) {
		if (!post.dataset.jt_hider_flag) {
			post.dataset.jt_hider_flag = 1;
			var repost = post.dataset.hasOwnProperty('copy') ? post : post.querySelector('[data-copy]');
			if (repost) {
				hide(repost);
			}
		}
	}

	/**
	 * This function receive HTMLElement with data-post-id and data-copy params
	 * @param post
	 */
	function hide(post) {
		if (post.children.length === 1) {
			var post_content = post.children[0];
			post_content.style.display = 'none';
			// insert new post header
			post.insertBefore(create_show_block(post_content), post_content);
		}
	}

	/**
	 * @param post_content HTMLElement
	 * @return HTMLElement
	 */
	function create_show_block(post_content) {
		var result 			= elem('div', {'class': '_post_content'}),
			header 			= post_content.querySelector('.post_header').cloneNode(true),
			content 		= post_content.querySelector('.post_content').cloneNode(true),
			post_author 	= header.querySelector('h5.post_author'),
			repost_author 	= post_content.querySelector('h5.copy_post_author > a'),
			repost_text 	= elem('span', {}),
			post_info 		= content.querySelector('.post_info'),
			copy_quote 		= content.querySelector('.copy_quote'),
			wall_text		= content.querySelector('.wall_text'),
			wall_post_text	= content.querySelector('.wall_post_text'),
			counter;

		// start main block setup
		result.onclick = on_click;
		// add title
		result.setAttribute('title', 'Показать скрытое сообщение');
		result.style.cursor = 'pointer';
		// stylish
		// for test only:
		//result.style.background = 'linear-gradient(to left, #FFF, #d7d8db)';

		// start header block setup:
		// update post_author block
		repost_text.innerText = ' сохранил(а) сообщение от ';
		post_author.appendChild(repost_text);
		post_author.appendChild(repost_author.cloneNode(true));

		// start content block setup
		// clear all unnecessary blocks
		counter = 0;
		while ((post_info.children.length != 1) || counter > 100) {
			post_info.removeChild(post_info.children[1]); counter++;
		}
		copy_quote.parentElement.removeChild(copy_quote);
		if (wall_post_text) {
			wall_post_text.style.paddingBottom = '0';
		}
		if (wall_text) {
			wall_text.style.paddingBottom = '9px';
		}
		clear_element(content);

		// insert new header block
		result.appendChild(header);
		// insert new content block
		result.appendChild(content);

		return result;
	}

	/**
	 * Handler on click
	 */
	function on_click() {
		var post = this.parentElement,
			e = window.event;
		if (e) {
			if (is_clickable(e.target, 5)) {
				// ignore <a> tags
				return false;
			} else {
				e.preventDefault();
				e.stopPropagation();
			}
		}
		if (post.children.length === 2) {
			post.children[1].style.display = '';
			post.removeChild(post.children[0]);
		}
		return false;
	}

	/**
	 * Check: is current element is clickable
	 * @param {HTMLElement|EventTarget} el
	 * @param {int} level
	 * @return {boolean}
	 */
	function is_clickable(el, level) {
		var result = (el && el.tagName === 'A');
		return result || (level > 0 && el && is_clickable(parent(el), level - 1));
	}

	/**
	 * @param el
	 * @return {HTMLElement}
	 */
	function parent(el) {
		return el.parentElement;
	}

	/**
	 * Create new HTMLElement
	 * @param tag string
	 * @param attrs object
	 * @returns {HTMLElement}
	 */
	function elem(tag, attrs) {
		var el = document.createElement(tag);
		if (attrs) {
			for (var i in attrs) {
				if (attrs.hasOwnProperty(i)) {
					el.setAttribute(i, attrs[i]);
				}
			}
		}
		return el;
	}

	/**
	 * @param elem HTMLElement
	 */
	function clear_element(elem) {
		elem.removeAttribute('id');
		elem.onclick = null;
		for (var i in elem.children) {
			if (elem.children.hasOwnProperty(i)) {
				clear_element(elem.children[i]);
			}
		}
	}

	function run() {
		clearTimeout(timeout);
		timeout = window.setTimeout(function(){
			proceed_posts();
		}, 300);
	}

	run();
	document.addEventListener("DOMNodeInserted", run, false);
})(window, document);
