import { a as api } from '../chunks/js.cookie-6db0b043.js';

const domainRegex = /^.*leetcode\.com$/;
const currentDomain = window.location.hostname;
async function submitLeetCodeSolution(questionId, problem_url, titleSlug, code) {
  try {
    if (!api.get('csrftoken')) {
      return;
    }
    let headersList = {
      "Accept": "*/*",
      "X-Csrftoken": api.get('csrftoken'),
      "Referer": "https://leetcode.com/problems/" + titleSlug + "/description/",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
      "Content-Type": "application/json",
      "Cookie": document.cookie,
      "Origin": "https://leetcode.com"
    };
    const request = await fetch(problem_url + "submit/", {
      method: "POST",
      headers: headersList,
      body: JSON.stringify({
        "lang": "cpp",
        "question_id": questionId,
        "typed_code": code
      })
    });
    console.log(headersList);
    console.log("Request ", request);
    const test = await request.text();
    console.log(test);
    if (request.status == 200) alert("POTD solution submitted.");else {
      alert("Some error occured.");
    }
  } catch (error) {
    console.log(error);
    alert("Some error occured.");
  }
}
async function getQuestionID(titleSlug) {
  let graphQLQuery = JSON.stringify({
    query: "query questionTitle { question(titleSlug: \"" + titleSlug + "\") { questionId questionFrontendId title titleSlug isPaidOnly difficulty likes dislikes categoryTitle }}"
  });
  var headers = new Headers();
  headers.append("Content-Type", "application/json");
  headers.append("Cookie", document.cookie);
  headers.append("X-Csrftoken", api.get('csrftoken'));
  const response = await fetch('https://leetcode.com/graphql', {
    method: "POST",
    headers: headers,
    body: graphQLQuery
  });
  var data = await response.json();
  return data.data.question.questionId;
}
async function getLeetcodeSolution(leetCodeQuestionId, problem_url, titleSlug, cookie, csrf) {
  if (!domainRegex.test(currentDomain)) {
    alert("Please open POTD Page to submit.");
    return;
  }
  while (leetCodeQuestionId.length < 4) leetCodeQuestionId = "0" + leetCodeQuestionId;
  const solution_url = `https://walkccc.me/LeetCode/problems/${leetCodeQuestionId}/`;
  const response = await fetch(solution_url);
  const html = await response.text();
  const parser = new DOMParser();
  const htmlDocument = parser.parseFromString(html, 'text/html');
  const code = htmlDocument.getElementsByTagName('code')[0].innerText;
  const questionId = await getQuestionID(titleSlug);
  await submitLeetCodeSolution(questionId, problem_url, titleSlug, code);
}
chrome.runtime.onMessage.addListener(function (request) {
  if (request.action === 'autoSubmit') {
    console.log("Autosubmit working");
    console.log(request.cookie);
    getLeetcodeSolution(request.message, request.url, request.titleSlug, request.cookie, request.csrf);
  }
});
