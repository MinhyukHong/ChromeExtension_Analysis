(function () {

  const importPath = /*@__PURE__*/JSON.parse('"content/leetcode.js"');
  import(chrome.runtime.getURL(importPath));
})();
