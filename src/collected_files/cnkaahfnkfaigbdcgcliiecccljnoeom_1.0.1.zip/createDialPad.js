(function () {
  let validWebsite = false;

  function createDialPad() {
    if (!validWebsite) return;

    // for html higlight
    function html(str) {
      return str;
    }

    const templateReplace = (template, data) => {
      let result = template;
      Object.keys(data).forEach((key) => {
        result = result.replace(`{${key}}`, data[key]);
      });

      return result;
    };

    const dialPadTemplate = html`
      <pn-dialpad-wrapper
        class="pn-fixed pn-right-4 pn-bottom-4"
        visible="false"
        style="z-index: 99999999 !important;"
        iconize="false"
        visible="false"
      >
        <pn-dialpad
          style="width: 232px"
          class="pn-relative pn-block pn-bg-neutral-800 pn-pt-6"
        >
          <pn-dialpad-iconize
            class="pn-absolute pn-right-8 pn-top-1 pn-ml-auto pn-inline-flex pn-justify-center pn-items-center pn-h-6 pn-w-6 hover:pn-bg-neutral-700 pn-cursor-pointer pn-p-1 pn-text-white"
          >
            <svg
              viewbox="0 0 32 32"
              width="18"
              height="18"
              stroke="currentColor"
              fill="currentColor"
            >
              <path d="M6 16 L 26 16" stroke-width="3" />
            </svg>
          </pn-dialpad-iconize>
          <pn-dialpad-close
            class="pn-absolute pn-right-1 pn-top-1 pn-ml-auto pn-inline-flex pn-justify-center pn-items-center pn-h-6 pn-w-6 hover:pn-bg-neutral-700 pn-cursor-pointer pn-p-1 pn-text-white"
          >
            <svg
              viewbox="0 0 32 32"
              width="18"
              height="18"
              stroke="currentColor"
              fill="currentColor"
            >
              <path
                d="M24 9.4L22.6 8 16 14.6 9.4 8 8 9.4l6.6 6.6L8 22.6 9.4 24l6.6-6.6 6.6 6.6 1.4-1.4-6.6-6.6L24 9.4z"
              />
            </svg>
          </pn-dialpad-close>
          <div
            class="pn-m-1 pn-mt-2 pn-mb-0 pn-flex pn-border-b pn-border-b-blue-400 pn-bg-neutral-700"
          >
            <input
              pn-dialpad-input
              style="border: 0;"
              type="text"
              class="pn-w-full pn-bg-neutral-700 pn-px-1 pn-py-1 pn-text-center pn-text-lg pn-tracking-wide pn-text-white pn-outline-none"
            />
            <pn-dialpad-backspace
              class="hover:bg-neutral-600 pn-flex pn-w-10 pn-cursor-pointer pn-select-none pn-items-center pn-justify-center pn-bg-neutral-800/50 pn-text-white"
            >
              <svg
                viewbox="0 0 32 32"
                width="14"
                height="14"
                stroke="currentColor"
                fill="currentColor"
              >
                <path
                  d="M11.7 10.3a1 1 0 0 0 0 1.4L15.9 16l-4.2 4.3a1 1 0 0 0 1.4 1.4l4.3-4.3 4.3 4.3a1 1 0 0 0 1.4-1.4L18.8 16l4.3-4.3a1 1 0 0 0-1.4-1.4L17.4 14.6 13.1 10.3a1 1 0 0 0-1.4 0z"
                />
                <path
                  d="M27.4 2a4 4 0 0 1 4 4v20a4 4 0 0 1-4 4h-14.2a4 4 0 0 1-3-1.4L0.5 17.3a2 2 0 0 1 0-2.6L10.2 3.4A4 4 0 0 1 13.2 2h14.2z m-14.2 2a2 2 0 0 0-1.5 0.7L2 16l9.7 11.3a2 2 0 0 0 1.5 0.7h14.2a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-14.2z"
                />
              </svg>
            </pn-dialpad-backspace>
          </div>
          <div class="pn-flex pn-select-none pn-flex-wrap pn-p-2">
            <pn-dialpad-pad
              pad="1"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              1
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="2"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              2
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="3"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              3
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="4"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              4
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="5"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              5
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="6"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              6
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="7"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              7
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="8"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              8
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="9"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              9
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="star"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              *
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="0"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              0
            </pn-dialpad-pad>
            <pn-dialpad-pad
              pad="hash"
              class="pn-flex pn-h-12 pn-w-1/3 pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-md pn-text-white hover:pn-bg-neutral-700"
            >
              #
            </pn-dialpad-pad>

            <div
              class="pn-mx-auto pn-flex pn-h-12 pn-w-1/3 pn-items-center pn-justify-center pn-rounded-md pn-text-white"
            >
              <pn-dialpad-call
                class="pn-z-50 pn-m-1 pn-flex pn-h-10 pn-w-10 pn-min-w-[40px] pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-full pn-bg-green-400 hover:pn-opacity-80"
              >
                <svg
                  viewbox="0 0 32 32"
                  width="24"
                  height="24"
                  stroke="currentColor"
                  fill="currentColor"
                >
                  <path
                    d="M20.3 21.5l2.3-2.3a2.2 2.2 0 0 1 2.3-0.4l2.7 1a2.2 2.2 0 0 1 1.4 2v5A2.2 2.2 0 0 1 26.7 29C7.6 27.8 3.7 11.6 3 5.4A2.2 2.2 0 0 1 5.2 3H10a2.2 2.2 0 0 1 2 1.4l1.1 2.7a2.2 2.2 0 0 1-0.5 2.3l-2.2 2.3s1.3 8.7 9.9 9.8Z"
                  />
                </svg>
              </pn-dialpad-call>
              <pn-dialpad-end
                class="pn-z-50 pn-m-1 pn-flex pn-h-10 pn-w-10 pn-min-w-[40px] pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-full pn-bg-red-400 hover:pn-opacity-80"
              >
                <svg
                  style="rotate: 135deg"
                  viewbox="0 0 32 32"
                  width="24"
                  height="24"
                  stroke="currentColor"
                  fill="currentColor"
                >
                  <path
                    d="M20.3 21.5l2.3-2.3a2.2 2.2 0 0 1 2.3-0.4l2.7 1a2.2 2.2 0 0 1 1.4 2v5A2.2 2.2 0 0 1 26.7 29C7.6 27.8 3.7 11.6 3 5.4A2.2 2.2 0 0 1 5.2 3H10a2.2 2.2 0 0 1 2 1.4l1.1 2.7a2.2 2.2 0 0 1-0.5 2.3l-2.2 2.3s1.3 8.7 9.9 9.8Z"
                  />
                </svg>
              </pn-dialpad-end>
            </div>
          </div>
        </pn-dialpad>
        <pn-dialpad-iconize-end
          class="pn-z-50 pn-m-1 pn-flex pn-h-10 pn-w-10 pn-min-w-[40px] pn-cursor-pointer pn-items-center pn-justify-center pn-rounded-full pn-bg-red-400 hover:pn-opacity-80"
        >
          <svg
            style="rotate: 135deg"
            viewbox="0 0 32 32"
            width="28"
            height="28"
            stroke="currentColor"
            fill="currentColor"
          >
            <path
              d="M20.3 21.5l2.3-2.3a2.2 2.2 0 0 1 2.3-0.4l2.7 1a2.2 2.2 0 0 1 1.4 2v5A2.2 2.2 0 0 1 26.7 29C7.6 27.8 3.7 11.6 3 5.4A2.2 2.2 0 0 1 5.2 3H10a2.2 2.2 0 0 1 2 1.4l1.1 2.7a2.2 2.2 0 0 1-0.5 2.3l-2.2 2.3s1.3 8.7 9.9 9.8Z"
            />
          </svg>
        </pn-dialpad-iconize-end>
      </pn-dialpad-wrapper>
    `;
    const templateEl = document.createElement("pn-template");
    templateEl.innerHTML = dialPadTemplate;
    document.body.appendChild(templateEl);

    const dialPadInput = templateEl.querySelector("[pn-dialpad-input]");

    const apiFormat = {
      vozipcenter: {
        call: "https://{domain}/api/{id}/{token}/newcall.json?user_id={userId}&remoto={number}",
        end: "https://{domain}/api/{id}/{token}/hangcall.json?user_id={userId}&remoto={number}",
      },
      rm: {
        call: "https://{domain}/WSCentralita/json/RealizarLlamada/idCliente={id}&token={token}&llamado={number}&llamante={userId}",
        end: "https://{domain}/WSCentralita/json/ColgarLlamada/idCliente={id}&token={token}&llamado={number}&llamante={userId}",
      },
    };

    const pads = "123456789*0#";

    pads.split("").forEach((pad) => {
      const padAttr = pad === "*" ? "star" : pad === "#" ? "hash" : pad;
      templateEl
        .querySelector(`pn-dialpad-pad[pad="${padAttr}"]`)
        .addEventListener("click", () => {
          dialPadInput.value += pad;
        });
    });

    templateEl
      .querySelector("pn-dialpad-backspace")
      .addEventListener("click", () => {
        dialPadInput.value = dialPadInput.value.slice(0, -1);
      });

    templateEl
      .querySelector("pn-dialpad-call")
      .addEventListener("click", () => {
        const config = JSON.parse(localStorage.getItem("pnConfig") || "{}");
        const number = dialPadInput.value.replace(/\s/g, "");
        const api = templateReplace(apiFormat[config.apiFormat]?.call, {
          ...config,
          number,
        });

        fetch(api, { mode: "no-cors" })
          .then(() => { })
          .catch((err) => {
            alert(err);
          });
      });

    templateEl.querySelector("pn-dialpad-end").addEventListener("click", () => {
      const config = JSON.parse(localStorage.getItem("pnConfig") || "{}");
      const number = dialPadInput.value.replace(/\s/g, "");
      const api = templateReplace(apiFormat[config.apiFormat]?.end, {
        ...config,
        number,
      });

      fetch(api, { mode: "no-cors" })
        .then(() => { })
        .catch((err) => {
          alert(err);
        });
    });

    templateEl
      .querySelector("pn-dialpad-iconize-end")
      .addEventListener("click", () => {
        const config = JSON.parse(localStorage.getItem("pnConfig") || "{}");
        const number = dialPadInput.value.replace(/\s/g, "");
        const api = templateReplace(apiFormat[config.apiFormat]?.end, {
          ...config,
          number,
        });

        fetch(api)
          .then(() => { })
          .catch((err) => {
            alert(err);
          });
      });

    const dialPadWrapper = templateEl.querySelector("pn-dialpad-wrapper");

    templateEl
      .querySelector("pn-dialpad-close")
      .addEventListener("click", () => {
        dialPadWrapper.setAttribute("visible", "false");
        dialPadWrapper.setAttribute("iconize", "false");
      });

    templateEl
      .querySelector("pn-dialpad-iconize")
      .addEventListener("click", () => {
        dialPadWrapper.setAttribute("iconize", "true");
        dialPadWrapper.setAttribute("visible", "false");
      });

    document.querySelectorAll("pn-number-icon").forEach((el) => {
      el.addEventListener("click", (e) => {
        e.stopPropagation();
        e.preventDefault();

        const phoneNumber = el.getAttribute("phone");
        dialPadInput.value = phoneNumber;
        dialPadWrapper.setAttribute("visible", "true");
        dialPadWrapper.setAttribute("iconize", "false");
      });
    });
  }

  chrome.storage.local.get("pnConfig", function (data) {
    const config = data.pnConfig || {};
    localStorage.setItem("pnConfig", JSON.stringify(config || {}));

    validWebsite = config?.urlList
      ? config.urlList
        ?.split("\n")
        .map((url) => url.trim())
        .some((url) => window.location.href.startsWith(url))
      : true;

    if (validWebsite) {
      createDialPad();
    }
  });
})();
