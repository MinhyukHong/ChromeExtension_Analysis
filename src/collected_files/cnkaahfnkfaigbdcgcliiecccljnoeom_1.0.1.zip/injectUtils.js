// https://github.com/aykutkardas/html-vschema

window.pnGetElement = (el, options = {}) => {
  var _a;
  const tagName = el.tagName.toLowerCase();
  if ((_a = options.ignoredTags) == null ? void 0 : _a.includes(tagName))
    return null;
  const attributes = {};
  const children = [];
  for (let attr of el.attributes) {
    attributes[attr.name] = attr.value;
  }
  for (let child of el.childNodes) {
    const schema2 = window.pnGetSchema(child, options);
    if (schema2)
      children.push(schema2);
  }
  const schema = { tagName, attributes, children };
  if (options.ref)
    schema.ref = el;
  return schema;
};

window.pnGetSchema = (el, options = {}) => {
  const ELEMENT_NODE_TYPE = 1;
  const TEXT_NODE_TYPE = 3;
  if (!el)
    return null;
  if (el.nodeType === TEXT_NODE_TYPE) {
    const text = el.wholeText.replace(/\\n/g, "").trim();
    return { text, ref: el };
  }
  if (el.nodeType === ELEMENT_NODE_TYPE) {
    const element = window.pnGetElement(el, options);
    return element || null;
  }
  return null;
};
