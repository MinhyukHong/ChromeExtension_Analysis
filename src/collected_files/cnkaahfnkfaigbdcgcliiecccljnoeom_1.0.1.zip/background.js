function pnHighlightPhoneNumber() {
  // for html higlight
  const html = (str) => str;

  const svg = html`
    <pn-number-icon phone="$2">
      <svg
        class="pn-number-icon"
        viewbox="0 0 120 120"
        width="20"
        height="20"
        stroke="currentColor"
        fill="currentColor"
      >
        <path
          d="M7.5 22.5C7.5 14.2 14.2 7.5 22.5 7.5H29.4C33.7 7.5 37.4 10.4 38.4 14.6L44 36.7C44.9 40.4 43.5 44.2 40.5 46.5L34 51.3C33.4 51.8 33.2 52.6 33.4 53.1 39.1 68.6 51.4 80.9 66.9 86.6 67.4 86.8 68.2 86.6 68.7 86L73.5 79.5C75.8 76.5 79.6 75.1 83.3 76L105.4 81.6C109.6 82.6 112.5 86.3 112.5 90.6V97.5C112.5 105.8 105.8 112.5 97.5 112.5H86.3C42.8 112.5 7.5 77.2 7.5 33.8V22.5Z"
          fill-rule="evenodd"
          clip-rule="evenodd"
        />
      </svg>
    </pn-number-icon>
  `;

  const findMatchEl = (schema, match, onMatch, parentRef) => {
    if (schema.text) {
      if (match.exec(schema.text)) {
        onMatch(schema.ref, schema.text, parentRef);
      }
    } else if (schema.children) {
      for (let child of schema.children) {
        findMatchEl(child, match, onMatch, schema.ref);
      }
    }
  };

  const schema = window.pnGetSchema(document.body, {
    ref: true,
    ignoredTags: [
      "script",
      "style",
      "input",
      "textarea",
      "select",
      "option",
      "no-script",
      "pn-number",
      "img",
      "hr",
      "svg",
      "br",
      "iframe",
      "video",
      "audio",
    ],
  });

  // https://regexlearn.com/playground?id=6411860455d5d0e61faf2dac
  const regex =
    /(?<!\w)((?:(\([0-9]{3}\) |[0-9]{3}-)[0-9]{3}-[0-9]{4})|(?:(\+\d+)?[ -]*\d[ -]*(?:[0-9][ -]*){8,10}))/gim;

  const onMatch = (ref, match, parentRef) => {
    const newValue = match.replaceAll(regex, "{{{{$1}}}}");
    ref.nodeValue = newValue;
    parentRef.innerHTML = parentRef.innerHTML.replaceAll(
      /(\{\{\{\{([^}]*)\}\}\}\})/g,
      `<pn-number phone="$2">${svg} $2</pn-number>`
    );
  };

  findMatchEl(schema, regex, onMatch);

  const dialPadInput = document.querySelector("[pn-dialpad-input]");
  const dialPadWrapper = document.querySelector("pn-dialpad-wrapper");

  document.querySelectorAll("pn-number-icon").forEach((el) => {
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();

      const phoneNumber = el.getAttribute("phone");
      dialPadInput.value = phoneNumber;
      dialPadWrapper.setAttribute("visible", "true");
      dialPadWrapper.setAttribute("iconize", "false");
    });
  });
}

let validWebsite = false;
let interval = null;
chrome.storage.local.get("pnConfig", function (data) {
  const config = data.pnConfig;
  validWebsite = config?.urlList
    ? config.urlList
      ?.split("\n")
      .map((url) => url.trim())
      .some((url) => window.location.href.startsWith(url))
    : true;

  if (validWebsite) {
    pnHighlightPhoneNumber();
    clearInterval(interval);

    interval = setInterval(() => {
      pnHighlightPhoneNumber();
    }, 1500);
  }
});
