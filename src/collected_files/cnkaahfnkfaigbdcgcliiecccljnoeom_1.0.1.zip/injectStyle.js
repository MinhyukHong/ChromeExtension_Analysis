(function () {

  function injectStyle() {
    if (!validWebsite) return;

    function css(str) {
      return str;
    }

    const style = document.createElement('style');
    style.setAttribute('id', 'pn-style');
    style.innerHTML = css`
    pn-number { 
      display: inline-flex !important;
      align-items: center !important;
      white-space: nowrap !important;
      text-decoration: none !important;
    }
    
    pn-number-icon {
      cursor: pointer !important;
      background: #fff !important;
      border-radius: 6px !important;
      display: inline-flex !important;
      align-items: center !important;
      justify-content: center !important;
      padding: 3px !important;
      margin-left: 4px !important;
      margin-right: 4px !important;
      background: #85CEE2 !important;
    }
    
    pn-number-icon:hover {
      background: #85CEE2d1 !important;
    }
  
    pn-number pn-number-icon svg {
      width: 15px !important;
      height: 15px !important;
      color: #fff !important;
      margin: 0 !important;
      padding: 0 !important;
      fill: #fff !important;
    }
  
    [pn-dialpad-close] svg {
      width: 18px !important;
      height: 18px !important;
    }
  
  
    /* DialPad style - Tailwind CSS */
  
    [visible="false"] pn-dialpad,
    [iconize="true"] pn-dialpad {
      display: none !important;
    }
  
    [visible="true"] pn-dialpad-iconize-end,
    [visible="false"][iconize="false"] pn-dialpad-iconize-end,
    [iconize="false"] pn-dialpad-iconize-end {
      display: none !important;
    }
  
    
    pn-dialpad-iconize-end svg {
      width: 20px !important;
      height: 20px !important;
      stroke: none !important;
    }
  
  .pn-fixed {
    position: fixed !important;
  }
  
  .pn-absolute {
    position: absolute !important;
  }
  
  .pn-relative {
    position: relative !important;
  }
  
  .pn-bottom-4 {
    bottom: 16px !important;
  }
  
  .pn-right-1 {
    right: 4px !important;
  }
  
  .pn-right-4 {
    right: 16px !important;
  }
  
  .pn-right-8 {
    right: 32px !important;
  }
  
  .pn-top-1 {
    top: 4px !important;
  }
  
  .pn-z-50 {
    z-index: 50 !important;
  }
  
  .pn-m-1 {
    margin: 4px !important;
  }
  
  .pn-mx-auto {
    margin-left: auto !important;
    margin-right: auto !important;
  }
  
  .pn-mb-0 {
    margin-bottom: 0px !important;
  }
  
  .pn-ml-auto {
    margin-left: auto !important;
  }
  
  .pn-mt-2 {
    margin-top: 8px !important;
  }
  
  .pn-block {
    display: block !important;
  }
  
  .pn-flex {
    display: flex !important;
  }
  
  .pn-inline-flex {
    display: inline-flex !important;
  }
  
  .pn-h-10 {
    height: 2.5rem !important;
  }
  
  .pn-h-12 {
    height: 3rem !important;
  }
  
  .pn-h-6 {
    height: 24px !important;
  }
  
  .pn-w-1\\\/3 {
    width: 33.333333% !important;
  }
  
  .pn-w-10 {
    width: 2.5rem !important;
  }
  
  .pn-w-6 {
    width: 24px !important;
  }
  
  .pn-w-full {
    width: 100% !important;
  }
  
  .pn-min-w-\\[40px\\] {
    min-width: 40px !important;
  }
  
  .pn-cursor-pointer {
    cursor: pointer !important;
  }
  
  .pn-select-none {
    -webkit-user-select: none !important;
            user-select: none !important;
  }
  
  .pn-flex-wrap {
    flex-wrap: wrap !important;
  }
  
  .pn-items-center {
    align-items: center !important;
  }
  
  .pn-justify-center {
    justify-content: center !important;
  }
  
  .pn-rounded-full {
    border-radius: 9999px !important;
  }
  
  .pn-rounded-md {
    border-radius: 0.375rem !important;
  }
  
  .pn-border-b {
    border-bottom-width: 1px !important;
  }
  
  .pn-border-b-blue-400 {
    --tw-border-opacity: 1;
    border-bottom-color: rgb(96 165 250 / var(--tw-border-opacity)) !important;
  }
  
  .pn-bg-green-400 {
    --tw-bg-opacity: 1;
    background-color: rgb(74 222 128 / var(--tw-bg-opacity)) !important;
  }
  
  .pn-bg-neutral-700 {
    --tw-bg-opacity: 1;
    background-color: rgb(64 64 64 / var(--tw-bg-opacity)) !important;
  }
  
  .pn-bg-neutral-800 {
    --tw-bg-opacity: 1;
    background-color: rgb(38 38 38 / var(--tw-bg-opacity)) !important;
  }
  
  .pn-bg-neutral-800\\\/50 {
    background-color: rgb(38 38 38 / 0.5) !important;
  }
  
  .pn-bg-red-400 {
    --tw-bg-opacity: 1;
    background-color: rgb(248 113 113 / var(--tw-bg-opacity)) !important;
  }
  
  .pn-p-1 {
    padding: 4px !important;
  }
  
  .pn-p-2 {
    padding: 8px !important;
  }
  
  .pn-px-1 {
    padding-left: 4px !important;
    padding-right: 4px !important;
  }
  
  .pn-py-1 {
    padding-top: 4px !important;
    padding-bottom: 4px !important;
  }
  
  .pn-pt-6 {
    padding-top: 24px !important;
  }
  
  .pn-text-center {
    text-align: center !important;
  }
  
  .pn-text-lg {
    font-size: 18px !important;
    line-height: 28px !important;
  }
  
  .pn-tracking-wide {
    letter-spacing: 0.04px !important;
  }
  
  .pn-text-white {
    --tw-text-opacity: 1;
    color: rgb(255 255 255 / var(--tw-text-opacity)) !important;
  }
  
  .pn-outline-none {
    outline: 2px solid transparent !important;
    outline-offset: 2px !important;
  }
  
  .hover\\:pn-bg-neutral-700:hover {
    --tw-bg-opacity: 1;
    background-color: rgb(64 64 64 / var(--tw-bg-opacity)) !important;
  }
  
  .hover\\:pn-opacity-80:hover {
    opacity: 0.8 !important;
  }
  
    `;
    document.body.appendChild(style);
  }

  let validWebsite = false;

  chrome.storage.local.get("pnConfig", function (data) {
    const config = data.pnConfig || {};
    validWebsite = config?.urlList
      ? config.urlList
        ?.split("\n")
        .map((url) => url.trim())
        .some((url) => window.location.href.startsWith(url))
      : true;

    if (validWebsite) {
      injectStyle();
    }
  });

})();