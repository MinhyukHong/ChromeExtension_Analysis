try {
  importScripts("bg.js");
} catch (e) {
  console.error(e);
}
