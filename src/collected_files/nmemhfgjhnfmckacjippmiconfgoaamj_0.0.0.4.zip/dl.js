"use strict";

const NAME = "DD";
const VERSION = 2;

function db_go() {
  let openRequest = indexedDB.open(NAME, VERSION);
  
  openRequest.onupgradeneeded = function(event) {
    console.error("db_go: DB version mismatch");
  };
  
  openRequest.onerror = function() {
    console.error("db_go: error", openRequest.error);
  };
  
  openRequest.onsuccess = function(event) {
    console.log("db_go: DB OK");
    fetch(openRequest.result, dump_complete);
  };
}

// The Chrome API calls back exactly once per call.

function fetch(db, done) {
  //let db = openRequest.result;
  let logs = db.transaction("logs", "readonly").objectStore("logs");
  let request = logs.getAll();
  request.onsuccess = function(event) {
    done(event.target.result);
  };
}

function dump_complete(dump) {
  //console.log("dump_complete: %o", dump);

  let now = new Date();
  let year = String(now.getFullYear());
  let month = String(now.getMonth() + 1).padStart(2, '0');
  let day = String(now.getDate()).padStart(2, '0');
  let hours = String(now.getHours()).padStart(2, '0');
  let minutes = String(now.getMinutes()).padStart(2, '0');
  let seconds = String(now.getSeconds()).padStart(2, '0');
  let name = `downloads.${year}${month}${day}_${hours}${minutes}${seconds}.json`;

  let div = document.getElementById("div");
  let a = document.createElement("a");
  let file = new Blob([JSON.stringify(dump, null, 1)], {type: 'application/json'});
  a.href = URL.createObjectURL(file);
  a.download = name;
  a.appendChild(document.createTextNode('download'));
  div.appendChild(a);
  validate_dump(dump);
}

document.addEventListener('DOMContentLoaded', function () {
  db_go();
});

function validate_dump(dump) {
  console.log("validate_dump");
  let downloads = dump.length;
  console.log(" downloads: %d", downloads);
}
