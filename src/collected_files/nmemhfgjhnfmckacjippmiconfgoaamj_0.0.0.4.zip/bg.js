"use strict";

var NAME = "DD";
var VERSION = 2;

// The Chrome API calls back exactly once per call.

// This is a newer, simpler version. It just logs things.
// So much easier to use the event stream for testing outside the extension.

let db;
let pending = [];

function process_pending(temp_db) {
  console.log("process_pending: DB ready, processing %d pending", pending.length);
  let logs = temp_db.transaction("logs", "readwrite").objectStore("logs");
  for (let i = 0; i < pending.length; ++i) {
    logs.put(pending[i]);
  }
  pending = [];
  db = temp_db;
  console.log("process_pending: done");
}

function handle_event(type, info) {
  let bundle = {
    type: type,
    info: info,
    timestamp: Date.now(),
  };
  if (db) {
    let logs = db.transaction("logs", "readwrite").objectStore("logs");
    logs.put(bundle);
  } else {
    pending.push(bundle);
  }
}

chrome.downloads.onCreated.addListener(function(download) {
  console.log("onCreated: %o", download);
  handle_event('created', download);
});

chrome.downloads.onChanged.addListener(function(delta) {
  console.log("onChanged: %o", delta);
  handle_event('changed', delta);
});

chrome.downloads.onErased.addListener(function(id) {
  console.log("onErased: %o", id);
  handle_event('erased', id);
});

function snapshot() {
  chrome.downloads.search({ }, function(result) {
    console.log("snapshot: %o", result);
    handle_event('downloads', result);
  });
}

function init_db() {
  let request = indexedDB.open(NAME, VERSION);
  
  request.onupgradeneeded = function (event) {
    // the existing database version is less than 2 (or it doesn't exist)
    let temp_db = request.result;
    console.log("init_db: DB old version: %d", event.oldVersion);
    if (event.oldVersion == 1) {
        console.log("init_db: removing old downloads table");
        temp_db.deleteObjectStore("downloads");
    }
    if (event.oldVersion < 2) {
      console.log("init_db: creating logs table");
      let store = temp_db.createObjectStore('logs', { autoIncrement: true });
      store.transaction.oncomplete = function(event) {
        console.log("init_db: creation complete");
        snapshot();
      };
    }
  }
  
  request.onerror = function() {
    console.error("init_db: error", request.error);
  };
  
  request.onsuccess = function() {
    console.log("init_db: DB opened OK");
    process_pending(request.result);
  }
}

init_db();
