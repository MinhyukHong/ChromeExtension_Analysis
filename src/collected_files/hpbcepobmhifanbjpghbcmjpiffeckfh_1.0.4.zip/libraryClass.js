import settings from "./settingsClass.js";
class Library {
    static serialize(e) {
        const t = [];
        for (const n in e) e.hasOwnProperty(n) && t.push(`${n}=${encodeURIComponent(e[n])}`);
        return t.join("&");
    }
    static getInstalledDate() {
        const e = new Date();
        return `${e.getFullYear().toString().slice(-2)}${("0" + (e.getMonth() + 1)).slice(-2)}`;
    }
    static isNullOrUndefined(e) {
        return null == e;
    }
    static checkOS() {
        const e = { name: null, version: null };
        let t;
        return (
            /Intel Mac OS X/.test(navigator.userAgent)
                ? ((t = /Intel (Mac OS X) ([\d_]+)/.exec(navigator.userAgent)), (e.name = "macOS"))
                : /Windows NT/.test(navigator.userAgent) && ((t = /(Windows) NT ([\d\.]+);/.exec(navigator.userAgent)), (e.name = "Windows")),
            t && (e.version = t[2].replace(/_/g, ".")),
            e
        );
    }
    static checkBrowser() {
        const e = { name: null, version: null },
            t = navigator.userAgent.match(/(opera|opr|chrome|edg)\/?\s*(\.?\d+(\.\d+)*)/gi);
        if (t) {
            const n = t[t.length - 1].split("/");
            (e.name = n[0].toLowerCase().replace("edg", "edge_chrome")), (e.version = n[1]);
        } else (e.name = navigator.appName.toLowerCase()), (e.version = navigator.appVersion);
        return e;
    }
    static generateUuidv4() {
        return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (e) => (e ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (e / 4)))).toString(16));
    }
    static validateUuidv4(e) {
        return /[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}/.test(e);
    }
    static setCookies(e) {
        if (Object.keys(e).length) for (const t in e) e.hasOwnProperty(t) && this.setCookie(t, e[t]);
    }
    static setStorage(e) {
        chrome.storage.sync.set(e);
    }
    static setCookie(e, t) {
        const n = new Date().getTime() / 1e3;
        chrome.cookies.set({ url: settings.home_url, domain: "." + settings.domain, path: "/", name: e, value: encodeURIComponent(t), expirationDate: n + settings.cookies_expiration });
    }
    static getCookie(e, t) {
        chrome.cookies.get({ url: settings.home_url, name: e }, t);
    }
    static cookiesToObject(e) {
        const t = {};
        if (Object.keys(e).length) for (var n in e) t[e[n].name] = e[n].value;
        return t;
    }
}
export default Library;
