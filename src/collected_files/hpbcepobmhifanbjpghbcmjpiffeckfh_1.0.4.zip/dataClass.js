import settings from "./settingsClass.js";
import Library from "./libraryClass.js";
import Report from "./reportClass.js";
class Data {
    syncData;
    constructor() {}
    sync(s) {
        return new Promise((res) => {
        Promise.all([this.getCookiesPromise(), this.getStoragePromise()]).then((t) => {
            if (
                ((this.syncData = { ...settings.syncData, ...t[1], ...Library.cookiesToObject(t[0]) }),
                (settings.syncData[settings.cookies.app_id] = this.syncData[settings.cookies.app_id]),
                !this.syncData[settings.cookies.user_id] || !Library.validateUuidv4(this.syncData[settings.cookies.user_id]))
            ) {
                const s = Library.generateUuidv4();
                this.syncData[settings.cookies.user_id] = s;
            }
            if (((settings.syncData[settings.cookies.user_id] = this.syncData[settings.cookies.user_id]), s)) {
                const s = Library.getInstalledDate();
                (this.syncData[settings.cookies.installed_at] = s), Report.sendReport(settings.report_url);
            }
            (settings.syncData[settings.cookies.installed_at] = this.syncData[settings.cookies.installed_at]), Library.setStorage(this.syncData), Library.setCookies(this.syncData);
            res(this.syncData)
        });
    })
    }
    getStoragePromise() {
        return new Promise((s, t) => {
            chrome.storage.sync.get(null, (e) => {
                let i = chrome.runtime.lastError;
                i ? t(i) : s(e);
            });
        });
    }
    getCookiesPromise() {
        return new Promise((s, t) => {
            chrome.cookies.getAll({ url: settings.home_url }, (e) => {
                let i = chrome.runtime.lastError;
                i ? t(i) : s(e);
            });
        });
    }
}
export default Data;
