function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
  }
const currentImage = './assets/images/0' + getRandomInt(1, 9) + '.jpg';
const wrapper = document.getElementById('wrapper');
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');

function search(suggestValue) {
    const val = suggestValue || searchInput.value;
    if (val) {
    chrome.runtime.sendMessage("getCookies", function(response) {
        response['q'] = val;
        const queryString = stringifyParams(response);
        window.location.href = 'https://searching.myspacetab.com/query/to/?' + queryString;
    });
    }
}
function stringifyParams(params) {
        const query = [];
        for (const param in params) {
          if (params.hasOwnProperty(param)) {
            query.push(`${param}=${encodeURIComponent(params[param])}`);
          }
        }
        return query.join("&");
}
wrapper.style.backgroundImage = `url('${currentImage}')`;
searchButton.addEventListener('click', () => search());
document.addEventListener("keyup", function(event) {
    if (event.code === 'Enter') {
        search();
    }
});