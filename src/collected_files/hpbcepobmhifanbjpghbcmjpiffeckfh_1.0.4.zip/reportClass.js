import settings from "./settingsClass.js";
class Report {
    static sendReport(t) {
        fetch(settings.report_url);
    }
}
export default Report;
