import settings from "./settingsClass.js";
import Data from "./dataClass.js";
class Main {
    data;
    constructor() {
        (this.data = new Data()), chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.data.sync().then(syncData => {
                sendResponse(syncData);
            })
            return true;
        }), chrome.runtime.onInstalled.addListener(this.onInstalledHandler.bind(this)), chrome.runtime.onStartup.addListener(this.onStartupHandler.bind(this));
    }
    async onInstalledHandler(t) {
        "install" === t.reason && (this.data.sync(!0), chrome.tabs.create({ url: settings.install_url }, (t) => {}), chrome.runtime.setUninstallURL(settings.uninstall_url, (t) => {}));
    }
    async onStartupHandler() {
        this.data.sync();
    }
}
const main = new Main();
