import Library from "./libraryClass.js";
class Settings {
    static _instance;
    domain;
    homepage_url;
    cookies_expiration = 63072e3;
    protocol = "https";
    subdomains = { tab: "tb", home: "www", report: "reporting", suggestion: "suggesting" };
    paths = { typ: "thankyou", gbp: "goodbye" };
    cookies = { app_id: "srchnn_id", user_id: "srchnn_e", installed_at: "t" };
    syncData = { [this.cookies.app_id]: "1680432622393946", [this.cookies.user_id]: null, [this.cookies.installed_at]: null };
    options = { showAffs: { key: "showAff", type: "checkbox", default: !0 } };
    constructor() {
        return (
            Settings._instance || ((this.manifest = chrome.runtime.getManifest()), (this.homepage_url = this.manifest.homepage_url), (this.domain = this.homepage_url.replace(/www\./i, "").split("/")[2]), (Settings._instance = this)),
            Settings._instance
        );
    }
    get install_url() {
        return `${this.homepage_url}${this.paths.typ}`;
    }
    get uninstall_url() {
        return `${this.homepage_url}${this.paths.gbp}`;
    }
    get new_tab_url() {
        return `${this.protocol}://${this.subdomains.tab}.${this.domain}/`;
    }
    get report_url() {
        const t = settings.report_data;
        return `${this.protocol}://${this.subdomains.report}.${this.domain}/monetize?${Library.serialize(t)}`;
    }
    get home_url() {
        return `${this.protocol}://${this.subdomains.home}.${this.domain}/`;
    }
    get report_data() {
        return {
            a_b_4c: Library.checkBrowser().name,
            srchnn_id: this.syncData[this.cookies.app_id],
            o_t_4c: Library.checkOS().name,
            srchnn_e: this.syncData[this.cookies.user_id],
            i_h_set_s2n: !1,
            i_s_set_4c: !0,
            sn_c_s_set: !0,
            ss_iaccept: !0,
        };
    }
}
const settings = new Settings();
export default settings;
