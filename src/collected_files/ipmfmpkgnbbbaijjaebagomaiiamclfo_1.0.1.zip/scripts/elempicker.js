// console.log('This is content script!!!');

// import { $, isDOM } from './dom.js';

// 'use strict';

// dom.js

function isDOM(obj = {}) {
  return (typeof obj === 'object') && (obj.nodeType === 1) && (typeof obj.style === 'object') && (typeof obj.ownerDocument === 'object');
}

function $(selector, parent) {
  if (!parent) return document.querySelector(selector);
  if (isDOM(parent)) return parent.querySelector(selector);
  return document.querySelector(selector);
}

function addRule(selector, cssObj) {
  Object.keys(cssObj).forEach(item => {
    selector.style[item] = cssObj[item];
  });
}

function getMaxZIndex() {
  return [...document.querySelectorAll('*')].reduce((r, e) => Math.max(r, +window.getComputedStyle(e).zIndex || 0), 0);
}

function isParent(obj, parentObj) {
  while (obj !== undefined && obj !== null && obj.tagName.toUpperCase() !== 'BODY') {
    if (obj == parentObj) return true;
    obj = obj.parentNode;
  }
  return false;
}

function findIndex(el, currentTag) {
  let nth = 0;
  while (el) {
    if (el.nodeName.toLowerCase() === currentTag) nth += 1;
    el = el.previousElementSibling;
  }
  return nth;
}

function findPos(el) {
  let computedStyle = getComputedStyle(el);
  let _x = el.getBoundingClientRect().left - parseFloat(computedStyle['margin-left']);
  let _y = el.getBoundingClientRect().top - parseFloat(computedStyle['margin-top']);
  let elParent = el.parent;
  while (elParent) {
    computedStyle = getComputedStyle(elParent);
    _x += elParent.frameElement.getBoundingClientRect().left - parseFloat(computedStyle['margin-left']);
    _y += elParent.frameElement.getBoundingClientRect().top - parseFloat(computedStyle['margin-top']);
    elParent = elParent.parent;
  }
  return {
    top: _y,
    left: _x
  };
}

function getElementInfo(el) {
  const result = {};
  const requiredValue = [
    'border-top-width',
    'border-right-width',
    'border-bottom-width',
    'border-left-width',
    'margin-top',
    'margin-right',
    'margin-bottom',
    'margin-left',
    'padding-top',
    'padding-right',
    'padding-bottom',
    'padding-left',
    'z-index'
  ];

  const computedStyle = getComputedStyle(el);  // equals to `window.getComputedStyle`
  requiredValue.forEach(item => {
    result[item] = parseFloat(computedStyle[item]) || 0;
  });

  mixin(result, {
    width: el.offsetWidth - result['border-left-width'] - result['border-right-width'] - result['padding-left'] - result['padding-right'],
    height: el.offsetHeight - result['border-top-width'] - result['border-bottom-width'] - result['padding-top'] - result['padding-bottom']
  });
  mixin(result, findPos(el));
  return result;
}

// utils.js

function mixin(target, source) {
  const targetCopy = target;
  Object.keys(source).forEach(item => {
    if ({}.hasOwnProperty.call(source, item)) {
      targetCopy[item] = source[item];
    }
  });
  return targetCopy;
}

function throttle(func, wait = 100) {
  let timeout;
  let elapsed;
  let lastRunTime = Date.now(); // 上次运行时间
  return function none(...args) {
    const _this = this;

    clearTimeout(timeout);

    elapsed = Date.now() - lastRunTime;

    function later() {
      lastRunTime = Date.now();
      timeout = null;
      func.apply(_this, args);
    }

    if (elapsed > wait) {
      later();
    } else {
      timeout = setTimeout(later, wait - elapsed);
    }
  };
}

function isNull(obj) {
  return Object.prototype.toString.call(obj).replace(/\[object[\s]/, '').replace(']', '').toLowerCase() === 'null';
}


class DomInspector {
  constructor(options = {}) {
    this._doc = window.document;
    this.root = options.root ? (isDOM(options.root) ? options.root : $(options.root)) : $('body');

    if (isNull(this.root)) {
      // logger.warn('Root element')
      console.warn('Root element');
      this.root = $('body');
    }

    this.theme = options.theme || 'dom-inspector-theme-default';
    this.exclude = this._formatExcludeOption(options.exclude || []);

    this.overlay = {};
    this.overlayId = '';
    this.target = '';
    this.destroyed = false;
    this.maxZIndex = options.maxZIndex || getMaxZIndex() + 1;

    this._cachedTarget = '';
    this._throttleOnMove = throttle(this._onMove.bind(this), 100);

    this._throttleOnClick = throttle(this._onClick.bind(this), 50);

    this._throttleOnRightClick = throttle(this._onRightClick.bind(this), 50);

    this._throttleOnKeyDown = throttle(this._onKeyDown.bind(this), 50)

    this._init();
  }
  enable() {
    if (this.destroyed) {
      console.warn('Inspector instance has been destroyed! Please redeclare it.');
      return;
    }
    this.overlay.parent.style.display = 'block';
    this.root.addEventListener('mousemove', this._throttleOnMove);
    this.root.addEventListener('click', this._throttleOnClick);
    this.root.addEventListener('contextmenu', this._throttleOnRightClick);
    this.root.addEventListener('keydown', this._throttleOnKeyDown);
  }
  pause() {
    this.root.removeEventListener('mousemove', this._throttleOnMove);
    this.root.removeEventListener('click', this._throttleOnClick);
    this.root.removeEventListener('contextmenu', this._throttleOnRightClick);
    this.root.removeEventListener('keydown', this._throttleOnKeyDown);
  }
  disable() {
    this.overlay.parent.style.display = 'none';
    this.overlay.parent.style.width = 0;
    this.overlay.parent.style.height = 0;
    this.target = null;

    this.root.removeEventListener('mousemove', this._throttleOnMove);
    this.root.removeEventListener('click', this._throttleOnClick);
    this.root.removeEventListener('contextmenu', this._throttleOnRightClick);
    this.root.removeEventListener('keydown', this._throttleOnKeyDown);
  }
  destroy() {
    this.destroyed = true;
    this.disable();
    this.overlay = {};
  }
  getXPath(el) {
    if (!isDOM(el) && !this.target) {
      console.warn('Target element is not found. Warning function name:%c getXPath', 'color: #ff5151');
      return "";
    }
    if (!el) el = this.target;

    if (el.hasAttribute('id')) {
      return `//${(el.tagName).toLowerCase()}[@id="${el.id}"]`;
    }

    // if (el.hasAttribute('class')) {
    //   return `//${(el.tagName).toLowerCase()}[@class="${el.getAttribute('class')}"]`;
    // }

    let isRelativePath = false;

    let path = [];
    while (el.nodeType === Node.ELEMENT_NODE) {

      if (el.hasAttribute('id')) {
        path.push(`//*[@id="${el.id}"]`);
        isRelativePath = true;
        break;
      }

      const currentTag = el.nodeName.toLowerCase();
      const nth = findIndex(el, currentTag);
      path.push(`${(el.tagName).toLowerCase()}${(nth === 1 ? '' : `[${nth}]`)}`);
      el = el.parentNode;
    }

    if (isRelativePath) {
      return `${path.reverse().join('/')}`;
    } else {
      return `/${path.reverse().join('/')}`;
    }

  }
  // getXPath(el) {
  //   if (!isDOM(el) && !this.target) {
  //     console.warn('Target element is not found. Warning function name:%c getXPath', 'color: #ff5151');
  //     return "";
  //   }
  //   if (!el) el = this.target;

  //   if (el.hasAttribute('id')) {
  //     return `//${(el.tagName).toLowerCase()}[@id="${el.id}"]`;
  //   }

  //   // if (el.hasAttribute('class')) {
  //   //   return `//${(el.tagName).toLowerCase()}[@class="${el.getAttribute('class')}"]`;
  //   // }

  //   let path = [];
  //   while (el.nodeType === Node.ELEMENT_NODE) {
  //     const currentTag = el.nodeName.toLowerCase();
  //     const nth = findIndex(el, currentTag);
  //     path.push(`${(el.tagName).toLowerCase()}${(nth === 1 ? '' : `[${nth}]`)}`);
  //     el = el.parentNode;
  //   }

  //   return `/${path.reverse().join('/')}`;
  // }
  getSelector(el) {
    if (!isDOM(el) && !this.target) {
      // return logger.warn('Target element is not found. Warning function name:%c getCssPath', 'color: #ff5151');
      console.warn('Target element is not found. Warning function name:%c getCssPath');
      return "na";
    }
    if (!el) el = this.target;
    let path = [];
    while (el.nodeType === Node.ELEMENT_NODE) {
      let currentSelector = el.nodeName.toLowerCase();
      if (el.hasAttribute('id')) {
        currentSelector += `#${el.id}`;
      } else if (el.hasAttribute('class')) {
        currentSelector += `.${el.className.replace(/\s+/g, ' ').split(' ').join('.')}`;
      } else {
        const nth = findIndex(el, currentSelector);
        if (nth !== 1) currentSelector += `:nth-of-type(${nth})`;
      }
      path.unshift(currentSelector);
      el = el.parentNode;
    }
    return path.join('>');
  }
  getElementInfo(el) {
    if (!isDOM(el) && !this.target) {
      console.warn('Target element is not found. Warning function name:%c getElementInfo', 'color: #ff5151');
      return "";
    }
    return getElementInfo(el || this.target);
  }
  _init() {
    this.overlayId = `dom-inspector-${Date.now()}`;

    const parent = this._createElement('div', {
      id: this.overlayId,
      class: `dom-inspector ${this.theme}`,
      style: `z-index: ${this.maxZIndex}`
    });

    this.overlay = {
      parent,
      content: this._createSurroundElement(parent, 'content'),
      paddingTop: this._createSurroundElement(parent, 'padding padding-top'),
      paddingRight: this._createSurroundElement(parent, 'padding padding-right'),
      paddingBottom: this._createSurroundElement(parent, 'padding padding-bottom'),
      paddingLeft: this._createSurroundElement(parent, 'padding padding-left'),
      borderTop: this._createSurroundElement(parent, 'border border-top'),
      borderRight: this._createSurroundElement(parent, 'border border-right'),
      borderBottom: this._createSurroundElement(parent, 'border border-bottom'),
      borderLeft: this._createSurroundElement(parent, 'border border-left'),
      marginTop: this._createSurroundElement(parent, 'margin margin-top'),
      marginRight: this._createSurroundElement(parent, 'margin margin-right'),
      marginBottom: this._createSurroundElement(parent, 'margin margin-bottom'),
      marginLeft: this._createSurroundElement(parent, 'margin margin-left'),
      tips: this._createSurroundElement(parent, 'tips', '<div class="tag"></div><div class="id"></div><div class="class"></div><div class="line">&nbsp;|&nbsp;</div><div class="size"></div><div class="triangle"></div>'),
      helperOptions: this._createSurroundElement(parent, 'helper-options', '<div class="info"></div>')
    };

    this.root.appendChild(parent);
  }
  _createElement(tag, attr, content) {
    const el = this._doc.createElement(tag);
    Object.keys(attr).forEach(item => {
      el.setAttribute(item, attr[item]);
    });
    if (content) el.innerHTML = content;
    return el;
  }
  _createSurroundElement(parent, className, content) {
    const el = this._createElement('div', {
      class: className
    }, content);
    parent.appendChild(el);
    return el;
  }
  _onMove(e) {
    for (let i = 0; i < this.exclude.length; i += 1) {
      const cur = this.exclude[i];
      if (cur.isEqualNode(e.target) || isParent(e.target, cur)) return;
    }

    this.target = e.target;

    if (this.target === this._cachedTarget) return null;

    this._cachedTarget = this.target;
    const elementInfo = getElementInfo(e.target);
    const contentLevel = {
      width: elementInfo.width,
      height: elementInfo.height
    };
    const paddingLevel = {
      width: elementInfo['padding-left'] + contentLevel.width + elementInfo['padding-right'],
      height: elementInfo['padding-top'] + contentLevel.height + elementInfo['padding-bottom']
    };
    const borderLevel = {
      width: elementInfo['border-left-width'] + paddingLevel.width + elementInfo['border-right-width'],
      height: elementInfo['border-top-width'] + paddingLevel.height + elementInfo['border-bottom-width']
    };
    const marginLevel = {
      width: elementInfo['margin-left'] + borderLevel.width + elementInfo['margin-right'],
      height: elementInfo['margin-top'] + borderLevel.height + elementInfo['margin-bottom']
    };

    // crazy & magic code

    addRule(this.overlay.parent, {
      width: `${marginLevel.width}px`,
      height: `${marginLevel.height}px`,
      top: `${elementInfo.top}px`,
      left: `${elementInfo.left}px`
    });
    addRule(this.overlay.content, {
      width: `${contentLevel.width}px`,
      height: `${contentLevel.height}px`,
      top: `${elementInfo['margin-top'] + elementInfo['border-top-width'] + elementInfo['padding-top']}px`,
      left: `${elementInfo['margin-left'] + elementInfo['border-left-width'] + elementInfo['padding-left']}px`
    });
    addRule(this.overlay.paddingTop, {
      width: `${paddingLevel.width}px`,
      height: `${elementInfo['padding-top']}px`,
      top: `${elementInfo['margin-top'] + elementInfo['border-top-width']}px`,
      left: `${elementInfo['margin-left'] + elementInfo['border-left-width']}px`
    });
    addRule(this.overlay.paddingRight, {
      width: `${elementInfo['padding-right']}px`,
      height: `${paddingLevel.height - elementInfo['padding-top']}px`,
      top: `${elementInfo['padding-top'] + elementInfo['margin-top'] + elementInfo['border-top-width']}px`,
      right: `${elementInfo['margin-right'] + elementInfo['border-right-width']}px`
    });
    addRule(this.overlay.paddingBottom, {
      width: `${paddingLevel.width - elementInfo['padding-right']}px`,
      height: `${elementInfo['padding-bottom']}px`,
      bottom: `${elementInfo['margin-bottom'] + elementInfo['border-bottom-width']}px`,
      right: `${elementInfo['padding-right'] + elementInfo['margin-right'] + elementInfo['border-right-width']}px`
    });
    addRule(this.overlay.paddingLeft, {
      width: `${elementInfo['padding-left']}px`,
      height: `${paddingLevel.height - elementInfo['padding-top'] - elementInfo['padding-bottom']}px`,
      top: `${elementInfo['padding-top'] + elementInfo['margin-top'] + elementInfo['border-top-width']}px`,
      left: `${elementInfo['margin-left'] + elementInfo['border-left-width']}px`
    });
    addRule(this.overlay.borderTop, {
      width: `${borderLevel.width}px`,
      height: `${elementInfo['border-top-width']}px`,
      top: `${elementInfo['margin-top']}px`,
      left: `${elementInfo['margin-left']}px`
    });
    addRule(this.overlay.borderRight, {
      width: `${elementInfo['border-right-width']}px`,
      height: `${borderLevel.height - elementInfo['border-top-width']}px`,
      top: `${elementInfo['margin-top'] + elementInfo['border-top-width']}px`,
      right: `${elementInfo['margin-right']}px`
    });
    addRule(this.overlay.borderBottom, {
      width: `${borderLevel.width - elementInfo['border-right-width']}px`,
      height: `${elementInfo['border-bottom-width']}px`,
      bottom: `${elementInfo['margin-bottom']}px`,
      right: `${elementInfo['margin-right'] + elementInfo['border-right-width']}px`
    });
    addRule(this.overlay.borderLeft, {
      width: `${elementInfo['border-left-width']}px`,
      height: `${borderLevel.height - elementInfo['border-top-width'] - elementInfo['border-bottom-width']}px`,
      top: `${elementInfo['margin-top'] + elementInfo['border-top-width']}px`,
      left: `${elementInfo['margin-left']}px`
    });
    addRule(this.overlay.marginTop, {
      width: `${marginLevel.width}px`,
      height: `${elementInfo['margin-top']}px`,
      top: 0,
      left: 0
    });
    addRule(this.overlay.marginRight, {
      width: `${elementInfo['margin-right']}px`,
      height: `${marginLevel.height - elementInfo['margin-top']}px`,
      top: `${elementInfo['margin-top']}px`,
      right: 0
    });
    addRule(this.overlay.marginBottom, {
      width: `${marginLevel.width - elementInfo['margin-right']}px`,
      height: `${elementInfo['margin-bottom']}px`,
      bottom: 0,
      right: `${elementInfo['margin-right']}px`
    });
    addRule(this.overlay.marginLeft, {
      width: `${elementInfo['margin-left']}px`,
      height: `${marginLevel.height - elementInfo['margin-top'] - elementInfo['margin-bottom']}px`,
      top: `${elementInfo['margin-top']}px`,
      left: 0
    });

    $('.tag', this.overlay.tips).innerHTML = this.target.tagName.toLowerCase();
    $('.id', this.overlay.tips).innerHTML = this.target.id ? `#${this.target.id}` : '';
    $('.class', this.overlay.tips).innerHTML = [...this.target.classList].map(item => `.${item}`).join('');
    $('.size', this.overlay.tips).innerHTML = `${marginLevel.width}x${marginLevel.height}`;

    let tipsTop = 0;
    let helperOptionsTop = 0;
    if (elementInfo.top >= 24 + 8) {
      this.overlay.tips.classList.remove('reverse');
      tipsTop = elementInfo.top - 24 - 8;
      helperOptionsTop = tipsTop - 24;
    } else {
      this.overlay.tips.classList.add('reverse');
      tipsTop = marginLevel.height + elementInfo.top + 8;
      helperOptionsTop = tipsTop + 24;
    }
    addRule(this.overlay.tips, { top: `${tipsTop}px`, left: `${elementInfo.left}px`, display: 'block' });

    $('.info', this.overlay.helperOptions).innerHTML = "<ul><li>Select web element (ctrl + right click)</li><li>Press [ESC] to exit</li></ul>";
    addRule(this.overlay.helperOptions, { top: `${helperOptionsTop}px`, left: `${elementInfo.left}px`, display: 'block' });

  }
  _onClick(e) {
    const xpath = this.getXPath(e.target);
    const selector = this.getSelector(e.target);
    // console.log(`xpath: ${xpath}, selector: ${selector}`);
    // console.log(`xpath: ${xpath}`);
  }
  _onRightClick(e) {
    e.preventDefault();

    if (e.ctrlKey) {
      // console.log('Right clicked with control');

      const xpath = this.getXPath(e.target);
      const selector = this.getSelector(e.target);
      // console.log(`xpath: ${xpath}, selector: ${selector}`);
      // console.log('Sending xpath back to the original web page...');
      this.destroy();

      chrome.storage.local.get('options', function (items) {
        // console.log('items:', items);
        let options = items.options;
        if (options && options.isActive) {
          // console.log('Fetched xpath:', xpath);
          options.elemLocation = xpath;
          options.isActive = false

          console.log('Deactivating picker...');

          chrome.runtime.sendMessage({
            name: 'stopPicker',
            options
          })
        }
      })
    }
  }
  _onKeyDown(e) {
    e.preventDefault();

    // console.log(e.code)
    if (e.code === 'Escape') {
      // console.log('Exiting element picker...')

      this.destroy();

      chrome.storage.local.get('options', function (items) {
        // console.log('items:', items);
        let options = items.options;
        if (options && options.isActive) {
          options.elemLocation = '';
          options.isActive = false

          // console.log('Deactivating picker...');

          chrome.runtime.sendMessage({
            name: 'stopPicker',
            options
          })
        }
      })
    }
  }
  _formatExcludeOption(excludeArray = []) {
    const result = [];

    excludeArray.forEach(item => {
      if (typeof item === 'string') return result.push($(item));

      if (isDOM(item)) return result.push(item);
    });

    return result;
  }
}


// var domInspector = new DomInspector();
// domInspector.enable();