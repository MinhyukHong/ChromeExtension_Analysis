// document.body.style.backgroundColor = "orange";

// window.onerror = function (e) {
//   console.log('Caught error:', e);
// }

window.addEventListener("message", (event) => {
  // console.log('event source:', event.source);
  if (event.source !== window)
    return

  // console.log('Event data received:', event.data);
  // console.log('Event origin:', event.origin);

  const evtData = event.data;
  // console.log('event raw data:', evtData);

  if (evtData.type === 'startPicker') {
    // console.log('Sending to activate picker...');

    const newTab = evtData.tabId ? false : true;

    try {
      // console.log('from node id:', evtData.fromNodeId);
      chrome.runtime.sendMessage({
        name: evtData.type,
        options: {
          targetUrl: evtData.url,
          newTab: newTab,
          tabId: evtData.tabId,
          windowId: evtData.windowId,
          fromNodeId: evtData.fromNodeId,
          isActive: true
        }
      });
    } catch (e) {
      console.log('[YooginX]', e.message);
      // TODO: Maybe page refreshing can fix it
    }
  } else if (evtData.type === 'detectWindowTab') {
    // console.log('Fetching windows & tabs...');

    try {
      chrome.runtime.sendMessage({
        name: evtData.type,
        options: {}
      });
    } catch (e) {
      console.log('[YooginX]', e.message);
      // if (e.message.toLowerCase().indexOf("extension context invalidated") !== -1) {
      //   alert('Chrome extension is READY');
      //   location.reload();
      // }
    }
  } else if (evtData.type === 'connectWebsocketServer') {
    // console.log('Sniffering websocket server...');
    // console.log('event data:', evtData);

    try {
      chrome.runtime.sendMessage({
        name: evtData.type,
        options: { token: evtData.token }
      });
    } catch (e) {
      console.log('[YooginX]', e.message);
      if (e.message.toLowerCase().indexOf("extension context invalidated") !== -1) {
        // alert('Chrome extension is READY');
        if (window.confirm("Your chrome extension has just been reloaded and you need to REFRESH the page before it can be fully activated, do you want to refresh it immediately (but if you are designing a task bot please DO NOT refresh the page first to avoid data loss)?")) {
          location.reload();
        }
      }
    }
  }

});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // console.log('Data from bg:', request);
  if (request.type === 'CAPT_ELEM_LOC' && request.elemLocation) {
    const message = {
      type: request.type,
      value: request.elemLocation,
      targetNodeId: request.targetNodeId
    };
    window.postMessage(message);
  } else if (request.type === 'CAPT_WINDOW_TAB') {
    // console.log('Data from bg:', request);
    window.postMessage(request);
  }
});

// function errorsWrapper(fn) {
//   return function () {
//     var args = arguments;
//     return setTimeout(function () {
//       fn.apply(null, args);
//     }, 0);
//   };
// }

