// alert('Hello Chrome!');
// console.log(typeof DomInspector);
// console.log(typeof DomInspector === 'function');
if (typeof DomInspector === 'function') {
  const options = { theme: 'dom-inspector-theme-ff' };
  let domInspector = new DomInspector(options);
  domInspector.enable();
} else {
  location.reload();
}