const storage = chrome.storage.local;

const ELEMENT_PICKER_SCRIPT_ID = 'eps-1523';

const TWENTY_SECONDS_MS = 20 * 1000;

// const WS_EXT_URL = 'ws://127.0.0.1:8012/ws/extension/';

// const WS_EXT_URL = 'wss://api-beta.yooginx.com/ws/extension/';
const WS_EXT_URL = 'wss://api.yooginx.com/ws/extension/';

let webSocket = null;

chrome.runtime.onInstalled.addListener(() => {
  console.log('On installed triggered');

  // Clear data in chrome.storage.local
  // storage.clear();

  // let install = { hit: false };
  // storage.set({ install });

})

// chrome.runtime.onSuspend.addListener(() => {
//   // Clear data in chrome.storage.local
//   storage.clear();
// })

// function reddenPage() {
//   document.body.style.backgroundColor = 'red';
// }

const sleepFunc = (delay) => new Promise((resolve) => setTimeout(resolve, delay));

function doSomething() {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      resolve('first result');
    }, 1000);
  });
}

function doSomethingElse() {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      resolve('second result');
    }, 1000);
  });
}

function taskSample1() {

  const searchInput = document.querySelector('#searchInput');

  // doSomething()
  //   .then(function (result) {
  //     document.querySelector('#searchInput').focus();
  //     console.log("This is the " + result);
  //     return doSomethingElse();
  //   })
  //   .then(function (result) {
  //     document.querySelector('#searchInput').value = '后汉书';
  //     console.log("This is the " + result);
  //   });

  new Promise(function (resolve, reject) {
    setTimeout(function () {
      searchInput.focus();

      resolve('first result');
    }, 1000);
  })
    .then(function (result) {
      console.log("This is the " + result);
      return new Promise(function (resolve, reject) {
        setTimeout(function () {
          searchInput.value = '后汉书';

          resolve('second result');
        }, 1000);
      });
    })
    .then(function (result) {
      console.log("This is the " + result);

      return new Promise(function (resolve, reject) {
        setTimeout(function () {
          document.querySelector('#searchBtn').click();

          resolve('third result');
        }, 1000);
      });
    });

  // // Step 1: Focus search input
  // setTimeout(() => {
  //   searchInput.focus();
  // }, 1000);

  // // Step 2: Fill search input
  // setTimeout(() => {
  //   searchInput.value = '后汉书';
  // }, 2000);

  // // Step 3: Click search button
  // document.querySelector('#searchBtn').click();

  // alert('hello!');

  // return 'success';
}

function taskSample2() {
  new Promise(function (resolve, reject) {
    setTimeout(function () {
      document.body.style.backgroundColor = 'blue';

      resolve('DONE');
    }, 300);
  }).then(function (result) {
    console.log("task " + result);
  });
}

// function getElementByXPath(p) {
//   // '//*[@id="db-nav-book"]/div[1]/div/div[1]/a'
//   return document.evaluate(p, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
// }

function getText(xpath) {
  // const p = '//*[@id="db-nav-book"]/div[1]/div/div[1]/a';
  let elem = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  return elem !== null ? elem.textContent.trim() : "";
}

function inputText(xpath, text) {
  let inputElem = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  if (inputElem) {
    inputElem.focus();
    inputElem.value = text;
    return true;
  } else {
    return false;
  }
}

async function inputText2(xpath, text) {
  let inputElem = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  if (inputElem) {
    const processComplete = new Promise((resolve, reject) => {
      setTimeout(function () {
        inputElem.focus();

        resolve("success");
      }, 200);
    }).then(result => {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          inputElem.value = text;
        }, 300);

        resolve("success");
      });
    });

    await processComplete;

    return true;
  } else {
    return false;
  }

}

function clickElement(xpath) {
  let element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  if (element) {
    element.click();
    return true;
  } else {
    return false;
  }
}

async function openBrowser(url) {
  // mode: 0 => new browser, 1 => new page
  // const newBrowser = mode === 0 ? true : false;
  // let tabInfo = null;
  // if (newBrowser) {
  //   // chrome.windows.create({ url: url, focused: true }, (res) => {
  //   //   // console.log('after creating window:', result);
  //   //   const tab = res.tabs[0];
  //   //   tabInfo = { windowId: tab.windowId, tabId: tab.id };
  //   // })
  //   chrome.windows.create({ url: url, focused: true });
  // } else {
  //   // chrome.tabs.create({
  //   //   url: url,
  //   //   active: true
  //   // }, (res) => {
  //   //   // console.log('after creating page:', res);
  //   //   tabInfo = { windowId: res.windowId, tabId: res.id }
  //   // });
  //   chrome.tabs.create({ url: url, active: true });
  // }
  // // return tabInfo;

  let ret = await chrome.windows.create({ url: url, focused: true, type: 'normal' });
  if (ret.tabs) {
    const tab = ret.tabs[0];
    return { windowId: tab.windowId, tabId: tab.id, url: url }
  } else {
    return null;
  }
}

function navigateUrl(tab, url) {
  chrome.tabs.update(tab.id, { url: url });
  return true;
}

async function maximizeWindow() {
  const currentWindow = await chrome.windows.getCurrent();
  // console.log('Current window id:', currentWindow.id);
  chrome.windows.update(currentWindow.id, { focused: true, state: "maximized" });
  return true;
}

async function closeWindow() {
  const currentWindow = await chrome.windows.getCurrent();
  try {
    chrome.windows.remove(currentWindow.id);
    return true;
  } catch {
    return false;
  }
}


function closeTab(tab) {
  try {
    chrome.tabs.remove(tab.id);
    return true;
  } catch {
    return false;
  }
}

async function waitElementVisible(xpath, timeoutInSecs = 10) {
  let currentTime = new Date().getTime();
  let endTime = currentTime + timeoutInSecs * 1000;

  const promiseWEV = new Promise((resolve, reject) => {
    const timerId = setInterval(() => {
      const elem = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      if (elem) {
        const styles = window.getComputedStyle(elem);
        const isHidden = (styles.display === 'none' || styles.visibility === 'hidden');
        if (!isHidden) {
          clearInterval(timerId);
          resolve(true);
        }
      } else if (endTime < new Date().getTime()) {
        clearInterval(timerId);
        resolve(false);
      }
    }, 150);
  });

  const ret = await promiseWEV;

  return ret;

  // const checkComplete = new Promise((resolve, reject) => {
  //   const waitingSecs = timeoutSecs * 1000;
  //   // let currentTime = new Date();
  //   // let endTime = currentTime + waitingSecs;

  //   setTimeout(function () {
  //     let element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  //     if (element) {
  //       const styles = window.getComputedStyle(element);
  //       const isHidden = (styles.display === 'none' || styles.visibility === 'hidden');
  //       resolve(!isHidden);
  //     } else {
  //       resolve(false);
  //     }
  //   }, 300);
  // });

  // let ret = await checkComplete;

  // return ret;
}

async function waitElementContains(xpath, text, timeoutInSecs = 10) {
  let currentTime = new Date().getTime();
  let endTime = currentTime + timeoutInSecs * 1000;

  const promiseWEC = new Promise((resolve, reject) => {
    const timerId = setInterval(() => {
      const elem = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
      if (elem) {
        const innerHtml = elem.innerHTML;
        if (innerHtml.toLowerCase().indexOf(text.toLowerCase()) !== -1) {
          clearInterval(timerId);
          resolve(true);
        }
        const elemValue = elem.value;
        if (elemValue && elemValue.toLowerCase().indexOf(text.toLowerCase()) !== -1) {
          clearInterval(timerId);
          resolve(true);
        }
      } else if (endTime < new Date().getTime()) {
        clearInterval(timerId);
        resolve(false);
      }
    }, 150);
  });

  const ret = await promiseWEC;
  return ret;
}

async function waitPageContains(text, timeoutInSecs = 10) {
  let currentTime = new Date().getTime();
  let endTime = currentTime + timeoutInSecs * 1000;

  const promiseWPC = new Promise((resolve, reject) => {
    const timerId = setInterval(() => {
      if (document.body.textContent.toLowerCase().includes(text.toLowerCase())) {
        clearInterval(timerId);
        resolve(true);
      }
    }, 150);
  });

  const ret = await promiseWPC;
  return ret;
}

// function taskGetText(xpath) {
//   new Promise(function (resolve, reject) {
//     setTimeout(function () {
//       // let element = getElementByXPath(xpath);
//       // console.log('elem:', element);
//       console.log('xpath:', xpath);

//       // resolve(element.textContent);
//       resolve("DONE");
//     }, 300);
//   }).then(function (result) {
//     console.log("result text: " + result);
//   });
// }

function getTitle() { return document.title; }

async function addIframe() {
  await sleepFunc(500);
  const iframe = document.createElement("iframe");
  const loadComplete =
    new Promise(resolve => iframe.addEventListener("load", resolve));
  iframe.src = "https://example.com";
  document.body.appendChild(iframe);
  await loadComplete;
  return iframe.contentWindow.document.title;
}

async function isElementPickerScriptRegistered() {
  const scripts = await chrome.scripting.getRegisteredContentScripts();
  return scripts.some((s) => s.id === ELEMENT_PICKER_SCRIPT_ID);
}

async function checkWindowExists(windowId) {
  let windows = await chrome.windows.getAll({ populate: true });
  for (let window of windows) {
    if (window.id === windowId) return true;
  }
  return false;
}

async function checkTabExists(windowId, tabId) {
  let tabs = await chrome.tabs.query({ windowId: windowId });
  for (let tab of tabs) {
    if (tab.id === tabId) return true;
  }
  return false;
}

// chrome.action.onClicked.addListener((tab) => {
//   if (!tab.url.includes('chrome://')) {
//     chrome.scripting.executeScript({
//       target: { tabId: tab.id, allFrames: true },
//       function: addIframe
//     }).then(injectionResults => {
//       for (const frameResult of injectionResults) {
//         const { frameId, result } = frameResult;
//         console.log(`Frame ${frameId} result:`, result);
//       }
//     });
//   }
// });

chrome.action.onClicked.addListener((tab) => {
  if (webSocket) {
    disconnectAutomatorServer();
  } else {
    // connectAutomatorServer();
    // keepAlive();
  }

  // if (!tab.url.includes('chrome://')) {
  //   chrome.scripting.executeScript({
  //     target: { tabId: tab.id },
  //     function: taskSample1
  //   })
  // }

  // maximizeWindow();

  // closeTab(tab);

  // openBrowser("https://elines.coscoshipping.com/ebusiness/").then((result) => {
  //   console.log('open browser result:', result);
  // });

  // chrome.windows.getAll().then((resultWindows) => {
  //   for (let window of resultWindows) {
  //     chrome.tabs.query({ windowId: window.id }).then((tabs) => {
  //       console.log('tabs:', window.id, tabs);
  //     });
  //   }
  // });

  // console.log(waitElementContains("/html/body/div[1]/div[4]/div[1]/div[1]/div/div[1]/div[3]/div[1]/div[1]/a[1]", "期刊"))

});

// chrome.tabs.onActivated.addListener((tab) => {
//   console.log('event: OnActivated, tab id:', tab.tabId);
//   // chrome.scripting.executeScript({
//   //   target: { tabId: tab.tabId },
//   //   files: ["scripts/elempicker.js"]
//   // });
// });

function connectAutomatorServer(token) {
  webSocket = new WebSocket(WS_EXT_URL + token + '/');

  webSocket.onopen = (event) => {
    chrome.action.setIcon({ path: 'icons/socket-active.png' });
    // console.log('websocket connection connected');
  };

  webSocket.onmessage = async event => {
    // console.log('raw event data:', event.data);
    let [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    // `tab` will either be a `tabs.Tab` instance or `undefined`.
    console.log('current tab:', tab);

    const evtData = JSON.parse(event.data);
    const msgBody = evtData.message;

    if (msgBody.request_type === 'ACTION' && msgBody.name === "OPEN_BROWSER") {
      // console.log('message body:', msgBody);
      const targetUrl = msgBody.args[0];
      // const mode = msgBody.args[1];
      openBrowser(targetUrl).then((result) => {
        sendActionResult(msgBody.id, result);
      });
    } else if (tab) {
      // const evtData = JSON.parse(event.data);
      // const msgBody = evtData.message;
      console.log('message body:', msgBody);

      if (msgBody.request_type === 'ACTION') {
        // if (msgBody.name === "CHANGE_BG_COLOR") {
        //   if (!tab.url.includes('chrome://')) {
        //     // console.log('changing bg color to blue...');
        //     chrome.scripting.executeScript({
        //       target: { tabId: tab.id },
        //       function: taskSample2
        //     });
        //   }
        // }

        if (msgBody.name === "MAXIMIZE") {
          if (!tab.url.includes('chrome://')) {
            // console.log('maximizing window...');

            maximizeWindow().then((result) => {
              sendActionResult(msgBody.id, result);
            });

          }
        } else if (msgBody.name === "GET_TEXT") {
          if (!tab.url.includes('chrome://')) {
            // console.log('getting text...');
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: getText,
              args: msgBody.args
            }).then(injectionResults => {
              // console.log('Sending result back to bot agent...');
              // console.log(injectionResults);
              for (const { frameId, result } of injectionResults) {
                // console.log(`Frame ${frameId} result:`, result);
                sendActionResult(msgBody.id, result);
              }
            });
          }
        } else if (msgBody.name === "INPUT_TEXT") {
          if (!tab.url.includes('chrome://')) {
            // console.log('inputting text...');
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: inputText2,
              args: msgBody.args
            }).then(injectionResults => {
              // console.log('Sending result back to bot agent...');
              // console.log("injectionResults:", injectionResults);
              for (const { frameId, result } of injectionResults) {
                console.log(`Frame ${frameId} result:`, result);
                sendActionResult(msgBody.id, result);
              }
            });
          }
        } else if (msgBody.name === "CLICK_ELEMENT") {
          if (!tab.url.includes('chrome://')) {
            // console.log('clicking element...');
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: clickElement,
              args: msgBody.args
            }).then(injectionResults => {
              // console.log(injectionResults);
              for (const { frameId, result } of injectionResults) {
                console.log(`Frame ${frameId} result:`, result);
                sendActionResult(msgBody.id, result);
              }
            });
          }
        } else if (msgBody.name === "WAIT_ELEMENT_VISIBLE") {
          // console.log('Waiting element until visible...');
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: waitElementVisible,
            args: msgBody.args
          }).then(injectionResults => {
            // console.log(injectionResults);
            for (const { frameId, result } of injectionResults) {
              console.log(`Frame ${frameId} result:`, result);
              sendActionResult(msgBody.id, result);
            }
          });
        } else if (msgBody.name === "WAIT_ELEMENT_CONTAINS") {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: waitElementContains,
            args: msgBody.args
          }).then(injectionResults => {
            // console.log(injectionResults);
            for (const { frameId, result } of injectionResults) {
              console.log(`Frame ${frameId} result:`, result);
              sendActionResult(msgBody.id, result);
            }
          });
        } else if (msgBody.name === "WAIT_PAGE_CONTAINS") {
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: waitPageContains,
            args: msgBody.args
          }).then(injectionResults => {
            // console.log(injectionResults);
            for (const { frameId, result } of injectionResults) {
              console.log(`Frame ${frameId} result:`, result);
              sendActionResult(msgBody.id, result);
            }
          });
        } else if (msgBody.name === "NAVIGATE") {
          if (!tab.url.includes('chrome://')) {
            console.log('Navigating url...');

            const result = navigateUrl(tab, msgBody.args[0]);
            sendActionResult(msgBody.id, result);
          }
        } else if (msgBody.name === "CLOSE_TAB") {
          if (!tab.url.includes('chrome://')) {
            console.log('Closing tab...');
            const result = closeTab(tab);
            sendActionResult(msgBody.id, result);
          }
        } else if (msgBody.name === "CLOSE_WINDOW") {
          console.log('Closing current window...');
          const result = closeWindow();
          sendActionResult(msgBody.id, result);
        }
      }
    }
  };

  webSocket.onclose = (event) => {
    chrome.action.setIcon({ path: 'icons/socket-inactive.png' });
    webSocket = null;
    // console.log('websocket connection closed');
  };
}

function disconnectAutomatorServer() {
  if (webSocket) {
    webSocket.close();
  }
}

function keepAlive() {
  const keepAliveIntervalId = setInterval(
    () => {
      if (webSocket) {
        const evt_data = { 'message': { 'request_type': 'ping', 'text': 'Sending heartbeat from YooginX Web Ranger' } }
        webSocket.send(JSON.stringify(evt_data));
      } else {
        clearInterval(keepAliveIntervalId);
      }
    },
    // It's important to pick an interval that's shorter than 30s, to
    // avoid that the service worker becomes inactive.
    TWENTY_SECONDS_MS
  );
}

function sendActionResult(msgID, result) {
  if (webSocket) {
    const msgBody = {
      request_type: 'ACTION_RESULT',
      id: msgID,
      result: result
    }
    const evt_data = { 'message': msgBody };
    // console.log('Action result event:', evt_data);
    if (webSocket) {
      webSocket.send(JSON.stringify(evt_data));
    }
  }
}

chrome.webNavigation.onDOMContentLoaded.addListener(async ({ tabId, url }) => {
  // console.log(`tab id: ${tabId}, url: ${url}`);

  const { options } = await storage.get('options');
  // console.log('options:', options);

  const epsRegistered = await isElementPickerScriptRegistered();
  // console.log('eps registered:', epsRegistered);

  if (options && options.isActive && options.targetUrl) {
    const targetUrlObj = new URL(options.targetUrl);
    const reqUrlObj = new URL(url);

    console.log(targetUrlObj.hostname, reqUrlObj.hostname, epsRegistered);

    if (targetUrlObj.hostname === reqUrlObj.hostname && epsRegistered) {
      // console.log('Start inspecting...');
      chrome.scripting.executeScript({
        target: { tabId },
        files: ['scripts/inspect.js'],
        injectImmediately: true
      });
    }
  }
});

// chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
//   const { options } = await storage.get('options');
//   console.log('tab url:', tab.url);
//   console.log('target url:', options.targetUrl);
// });

chrome.runtime.onMessage.addListener(async ({ name, options }, sender, sendResponse) => {
  // console.log('options:', options);
  // console.log('event name:', name);
  // console.log('sender tab id:', sender.tab.id);
  // console.log('request method:', method);

  if (name === 'startPicker') {
    // console.log('Creating new tab...');

    options.senderTabId = sender.tab.id;
    options.senderWindowId = sender.tab.windowId;
    // console.log('options:', options);

    await storage.set({ options });

    try {
      const epsRegistered = await isElementPickerScriptRegistered();
      // console.log('eps registered:', epsRegistered);

      if (epsRegistered) {
        await chrome.scripting.unregisterContentScripts({
          ids: [ELEMENT_PICKER_SCRIPT_ID]
        });
      }

      await chrome.scripting.registerContentScripts([
        {
          id: ELEMENT_PICKER_SCRIPT_ID,
          js: ['scripts/elempicker.js'],
          persistAcrossSessions: false,
          // matches: [options.targetUrl],
          matches: ["https://*/*", 'http://*/*'],
          // matches: ["https://*.bing.com/*"],
          runAt: 'document_start',
          allFrames: true,
          world: 'ISOLATED'
        }
      ]);

      if (options.newTab) {
        await chrome.tabs.create({
          url: options.targetUrl
        });
      } else {
        const windowId = options.windowId;
        // console.log(await checkWindowExists(windowId));
        if (await checkWindowExists(windowId)) {
          await chrome.windows.update(windowId, { focused: true });
        }
        const tabId = options.tabId;
        // console.log(await checkTabExists(windowId, tabId));
        if (await checkTabExists(windowId, tabId)) {
          // await chrome.tabs.reload(tabId);
          await chrome.tabs.update(tabId, { active: true });
          // console.log('Activating dom inspector...');
          await chrome.scripting.executeScript({
            target: { tabId },
            files: ['scripts/inspect.js'],
            injectImmediately: true
          });
          // console.log('inject result:', injectResult);
        } else {
          // console.log(`Tab ${tabId} cannot be reached.`);
          if (epsRegistered) {
            await chrome.scripting.unregisterContentScripts({
              ids: [ELEMENT_PICKER_SCRIPT_ID]
            });
          }
        }
      }
    } catch (e) {
      console.log("[YooginX]", e.message);
    }
  } else if (name === 'stopPicker') {
    await storage.set({ options });

    // console.log("element location:", options.elemLocation);
    // console.log("from tab id:", options.senderTabId);

    await chrome.windows.update(options.senderWindowId, { focused: true });

    await chrome.tabs.update(options.senderTabId, { active: true });

    // Send element location
    chrome.tabs.sendMessage(
      options.senderTabId,
      { type: 'CAPT_ELEM_LOC', elemLocation: options.elemLocation, targetNodeId: options.fromNodeId }
    );

    // const evtData = { message: { request_type: 'CAPT_ELEM_LOC', value: options.elemLocation } };
    // if (webSocket) {
    //   webSocket.send(JSON.stringify(evtData));
    // }

  } else if (name === 'detectWindowTab') {
    let tabInfo = {};
    let windows = await chrome.windows.getAll({ populate: true });
    // console.log('Detected windows:', windows);
    for (let window of windows) {
      const windowId = window.id;
      if (!tabInfo.hasOwnProperty(windowId)) {
        tabInfo[windowId] = [];
      }
      let tabs = await chrome.tabs.query({ windowId: windowId });
      for (let tab of tabs) {
        tabInfo[windowId].push({ tabId: tab.id, url: tab.url, title: tab.title });
      }
    }
    // console.log('Tab info:', tabInfo);
    const message = {
      type: 'CAPT_WINDOW_TAB',
      tabInfo: tabInfo
    };
    // sendResponse(message);
    chrome.tabs.sendMessage(sender.tab.id, message);

  } else if (name === 'connectWebsocketServer') {
    if (webSocket === null) {
      connectAutomatorServer(options.token);
      keepAlive();
    }
  }

});