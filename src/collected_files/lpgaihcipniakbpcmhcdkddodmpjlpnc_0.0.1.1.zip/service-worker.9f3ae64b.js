// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"ef4b6":[function(require,module,exports) {
var global = arguments[3];
var HMR_HOST = "localhost";
var HMR_PORT = 1234;
var HMR_SECURE = false;
var HMR_ENV_HASH = "210281caf8d4160d";
module.bundle.HMR_BUNDLE_ID = "f82af28e9f3ae64b";
"use strict";
/* global HMR_HOST, HMR_PORT, HMR_ENV_HASH, HMR_SECURE, chrome, browser, __parcel__import__, __parcel__importScripts__, ServiceWorkerGlobalScope */ /*::
import type {
  HMRAsset,
  HMRMessage,
} from '@parcel/reporter-dev-server/src/HMRServer.js';
interface ParcelRequire {
  (string): mixed;
  cache: {|[string]: ParcelModule|};
  hotData: {|[string]: mixed|};
  Module: any;
  parent: ?ParcelRequire;
  isParcelRequire: true;
  modules: {|[string]: [Function, {|[string]: string|}]|};
  HMR_BUNDLE_ID: string;
  root: ParcelRequire;
}
interface ParcelModule {
  hot: {|
    data: mixed,
    accept(cb: (Function) => void): void,
    dispose(cb: (mixed) => void): void,
    // accept(deps: Array<string> | string, cb: (Function) => void): void,
    // decline(): void,
    _acceptCallbacks: Array<(Function) => void>,
    _disposeCallbacks: Array<(mixed) => void>,
  |};
}
interface ExtensionContext {
  runtime: {|
    reload(): void,
    getURL(url: string): string;
    getManifest(): {manifest_version: number, ...};
  |};
}
declare var module: {bundle: ParcelRequire, ...};
declare var HMR_HOST: string;
declare var HMR_PORT: string;
declare var HMR_ENV_HASH: string;
declare var HMR_SECURE: boolean;
declare var chrome: ExtensionContext;
declare var browser: ExtensionContext;
declare var __parcel__import__: (string) => Promise<void>;
declare var __parcel__importScripts__: (string) => Promise<void>;
declare var globalThis: typeof self;
declare var ServiceWorkerGlobalScope: Object;
*/ var OVERLAY_ID = "__parcel__error__overlay__";
var OldModule = module.bundle.Module;
function Module(moduleName) {
    OldModule.call(this, moduleName);
    this.hot = {
        data: module.bundle.hotData[moduleName],
        _acceptCallbacks: [],
        _disposeCallbacks: [],
        accept: function(fn) {
            this._acceptCallbacks.push(fn || function() {});
        },
        dispose: function(fn) {
            this._disposeCallbacks.push(fn);
        }
    };
    module.bundle.hotData[moduleName] = undefined;
}
module.bundle.Module = Module;
module.bundle.hotData = {};
var checkedAssets /*: {|[string]: boolean|} */ , assetsToDispose /*: Array<[ParcelRequire, string]> */ , assetsToAccept /*: Array<[ParcelRequire, string]> */ ;
function getHostname() {
    return HMR_HOST || (location.protocol.indexOf("http") === 0 ? location.hostname : "localhost");
}
function getPort() {
    return HMR_PORT || location.port;
}
// eslint-disable-next-line no-redeclare
var parent = module.bundle.parent;
if ((!parent || !parent.isParcelRequire) && typeof WebSocket !== "undefined") {
    var hostname = getHostname();
    var port = getPort();
    var protocol = HMR_SECURE || location.protocol == "https:" && !/localhost|127.0.0.1|0.0.0.0/.test(hostname) ? "wss" : "ws";
    var ws = new WebSocket(protocol + "://" + hostname + (port ? ":" + port : "") + "/");
    // Web extension context
    var extCtx = typeof chrome === "undefined" ? typeof browser === "undefined" ? null : browser : chrome;
    // Safari doesn't support sourceURL in error stacks.
    // eval may also be disabled via CSP, so do a quick check.
    var supportsSourceURL = false;
    try {
        (0, eval)('throw new Error("test"); //# sourceURL=test.js');
    } catch (err) {
        supportsSourceURL = err.stack.includes("test.js");
    }
    // $FlowFixMe
    ws.onmessage = async function(event /*: {data: string, ...} */ ) {
        checkedAssets = {} /*: {|[string]: boolean|} */ ;
        assetsToAccept = [];
        assetsToDispose = [];
        var data /*: HMRMessage */  = JSON.parse(event.data);
        if (data.type === "update") {
            // Remove error overlay if there is one
            if (typeof document !== "undefined") removeErrorOverlay();
            let assets = data.assets.filter((asset)=>asset.envHash === HMR_ENV_HASH);
            // Handle HMR Update
            let handled = assets.every((asset)=>{
                return asset.type === "css" || asset.type === "js" && hmrAcceptCheck(module.bundle.root, asset.id, asset.depsByBundle);
            });
            if (handled) {
                console.clear();
                // Dispatch custom event so other runtimes (e.g React Refresh) are aware.
                if (typeof window !== "undefined" && typeof CustomEvent !== "undefined") window.dispatchEvent(new CustomEvent("parcelhmraccept"));
                await hmrApplyUpdates(assets);
                // Dispose all old assets.
                let processedAssets = {} /*: {|[string]: boolean|} */ ;
                for(let i = 0; i < assetsToDispose.length; i++){
                    let id = assetsToDispose[i][1];
                    if (!processedAssets[id]) {
                        hmrDispose(assetsToDispose[i][0], id);
                        processedAssets[id] = true;
                    }
                }
                // Run accept callbacks. This will also re-execute other disposed assets in topological order.
                processedAssets = {};
                for(let i = 0; i < assetsToAccept.length; i++){
                    let id = assetsToAccept[i][1];
                    if (!processedAssets[id]) {
                        hmrAccept(assetsToAccept[i][0], id);
                        processedAssets[id] = true;
                    }
                }
            } else fullReload();
        }
        if (data.type === "error") {
            // Log parcel errors to console
            for (let ansiDiagnostic of data.diagnostics.ansi){
                let stack = ansiDiagnostic.codeframe ? ansiDiagnostic.codeframe : ansiDiagnostic.stack;
                console.error("\uD83D\uDEA8 [parcel]: " + ansiDiagnostic.message + "\n" + stack + "\n\n" + ansiDiagnostic.hints.join("\n"));
            }
            if (typeof document !== "undefined") {
                // Render the fancy html overlay
                removeErrorOverlay();
                var overlay = createErrorOverlay(data.diagnostics.html);
                // $FlowFixMe
                document.body.appendChild(overlay);
            }
        }
    };
    ws.onerror = function(e) {
        console.error(e.message);
    };
    ws.onclose = function() {
        console.warn("[parcel] \uD83D\uDEA8 Connection to the HMR server was lost");
    };
}
function removeErrorOverlay() {
    var overlay = document.getElementById(OVERLAY_ID);
    if (overlay) {
        overlay.remove();
        console.log("[parcel] ✨ Error resolved");
    }
}
function createErrorOverlay(diagnostics) {
    var overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;
    let errorHTML = '<div style="background: black; opacity: 0.85; font-size: 16px; color: white; position: fixed; height: 100%; width: 100%; top: 0px; left: 0px; padding: 30px; font-family: Menlo, Consolas, monospace; z-index: 9999;">';
    for (let diagnostic of diagnostics){
        let stack = diagnostic.frames.length ? diagnostic.frames.reduce((p, frame)=>{
            return `${p}
<a href="/__parcel_launch_editor?file=${encodeURIComponent(frame.location)}" style="text-decoration: underline; color: #888" onclick="fetch(this.href); return false">${frame.location}</a>
${frame.code}`;
        }, "") : diagnostic.stack;
        errorHTML += `
      <div>
        <div style="font-size: 18px; font-weight: bold; margin-top: 20px;">
          🚨 ${diagnostic.message}
        </div>
        <pre>${stack}</pre>
        <div>
          ${diagnostic.hints.map((hint)=>"<div>\uD83D\uDCA1 " + hint + "</div>").join("")}
        </div>
        ${diagnostic.documentation ? `<div>📝 <a style="color: violet" href="${diagnostic.documentation}" target="_blank">Learn more</a></div>` : ""}
      </div>
    `;
    }
    errorHTML += "</div>";
    overlay.innerHTML = errorHTML;
    return overlay;
}
function fullReload() {
    if ("reload" in location) location.reload();
    else if (extCtx && extCtx.runtime && extCtx.runtime.reload) extCtx.runtime.reload();
}
function getParents(bundle, id) /*: Array<[ParcelRequire, string]> */ {
    var modules = bundle.modules;
    if (!modules) return [];
    var parents = [];
    var k, d, dep;
    for(k in modules)for(d in modules[k][1]){
        dep = modules[k][1][d];
        if (dep === id || Array.isArray(dep) && dep[dep.length - 1] === id) parents.push([
            bundle,
            k
        ]);
    }
    if (bundle.parent) parents = parents.concat(getParents(bundle.parent, id));
    return parents;
}
function updateLink(link) {
    var href = link.getAttribute("href");
    if (!href) return;
    var newLink = link.cloneNode();
    newLink.onload = function() {
        if (link.parentNode !== null) // $FlowFixMe
        link.parentNode.removeChild(link);
    };
    newLink.setAttribute("href", // $FlowFixMe
    href.split("?")[0] + "?" + Date.now());
    // $FlowFixMe
    link.parentNode.insertBefore(newLink, link.nextSibling);
}
var cssTimeout = null;
function reloadCSS() {
    if (cssTimeout) return;
    cssTimeout = setTimeout(function() {
        var links = document.querySelectorAll('link[rel="stylesheet"]');
        for(var i = 0; i < links.length; i++){
            // $FlowFixMe[incompatible-type]
            var href /*: string */  = links[i].getAttribute("href");
            var hostname = getHostname();
            var servedFromHMRServer = hostname === "localhost" ? new RegExp("^(https?:\\/\\/(0.0.0.0|127.0.0.1)|localhost):" + getPort()).test(href) : href.indexOf(hostname + ":" + getPort());
            var absolute = /^https?:\/\//i.test(href) && href.indexOf(location.origin) !== 0 && !servedFromHMRServer;
            if (!absolute) updateLink(links[i]);
        }
        cssTimeout = null;
    }, 50);
}
function hmrDownload(asset) {
    if (asset.type === "js") {
        if (typeof document !== "undefined") {
            let script = document.createElement("script");
            script.src = asset.url + "?t=" + Date.now();
            if (asset.outputFormat === "esmodule") script.type = "module";
            return new Promise((resolve, reject)=>{
                var _document$head;
                script.onload = ()=>resolve(script);
                script.onerror = reject;
                (_document$head = document.head) === null || _document$head === void 0 || _document$head.appendChild(script);
            });
        } else if (typeof importScripts === "function") {
            // Worker scripts
            if (asset.outputFormat === "esmodule") return import(asset.url + "?t=" + Date.now());
            else return new Promise((resolve, reject)=>{
                try {
                    importScripts(asset.url + "?t=" + Date.now());
                    resolve();
                } catch (err) {
                    reject(err);
                }
            });
        }
    }
}
async function hmrApplyUpdates(assets) {
    global.parcelHotUpdate = Object.create(null);
    let scriptsToRemove;
    try {
        // If sourceURL comments aren't supported in eval, we need to load
        // the update from the dev server over HTTP so that stack traces
        // are correct in errors/logs. This is much slower than eval, so
        // we only do it if needed (currently just Safari).
        // https://bugs.webkit.org/show_bug.cgi?id=137297
        // This path is also taken if a CSP disallows eval.
        if (!supportsSourceURL) {
            let promises = assets.map((asset)=>{
                var _hmrDownload;
                return (_hmrDownload = hmrDownload(asset)) === null || _hmrDownload === void 0 ? void 0 : _hmrDownload.catch((err)=>{
                    // Web extension bugfix for Chromium
                    // https://bugs.chromium.org/p/chromium/issues/detail?id=1255412#c12
                    if (extCtx && extCtx.runtime && extCtx.runtime.getManifest().manifest_version == 3) {
                        if (typeof ServiceWorkerGlobalScope != "undefined" && global instanceof ServiceWorkerGlobalScope) {
                            extCtx.runtime.reload();
                            return;
                        }
                        asset.url = extCtx.runtime.getURL("/__parcel_hmr_proxy__?url=" + encodeURIComponent(asset.url + "?t=" + Date.now()));
                        return hmrDownload(asset);
                    }
                    throw err;
                });
            });
            scriptsToRemove = await Promise.all(promises);
        }
        assets.forEach(function(asset) {
            hmrApply(module.bundle.root, asset);
        });
    } finally{
        delete global.parcelHotUpdate;
        if (scriptsToRemove) scriptsToRemove.forEach((script)=>{
            if (script) {
                var _document$head2;
                (_document$head2 = document.head) === null || _document$head2 === void 0 || _document$head2.removeChild(script);
            }
        });
    }
}
function hmrApply(bundle /*: ParcelRequire */ , asset /*:  HMRAsset */ ) {
    var modules = bundle.modules;
    if (!modules) return;
    if (asset.type === "css") reloadCSS();
    else if (asset.type === "js") {
        let deps = asset.depsByBundle[bundle.HMR_BUNDLE_ID];
        if (deps) {
            if (modules[asset.id]) {
                // Remove dependencies that are removed and will become orphaned.
                // This is necessary so that if the asset is added back again, the cache is gone, and we prevent a full page reload.
                let oldDeps = modules[asset.id][1];
                for(let dep in oldDeps)if (!deps[dep] || deps[dep] !== oldDeps[dep]) {
                    let id = oldDeps[dep];
                    let parents = getParents(module.bundle.root, id);
                    if (parents.length === 1) hmrDelete(module.bundle.root, id);
                }
            }
            if (supportsSourceURL) // Global eval. We would use `new Function` here but browser
            // support for source maps is better with eval.
            (0, eval)(asset.output);
            // $FlowFixMe
            let fn = global.parcelHotUpdate[asset.id];
            modules[asset.id] = [
                fn,
                deps
            ];
        } else if (bundle.parent) hmrApply(bundle.parent, asset);
    }
}
function hmrDelete(bundle, id) {
    let modules = bundle.modules;
    if (!modules) return;
    if (modules[id]) {
        // Collect dependencies that will become orphaned when this module is deleted.
        let deps = modules[id][1];
        let orphans = [];
        for(let dep in deps){
            let parents = getParents(module.bundle.root, deps[dep]);
            if (parents.length === 1) orphans.push(deps[dep]);
        }
        // Delete the module. This must be done before deleting dependencies in case of circular dependencies.
        delete modules[id];
        delete bundle.cache[id];
        // Now delete the orphans.
        orphans.forEach((id)=>{
            hmrDelete(module.bundle.root, id);
        });
    } else if (bundle.parent) hmrDelete(bundle.parent, id);
}
function hmrAcceptCheck(bundle /*: ParcelRequire */ , id /*: string */ , depsByBundle /*: ?{ [string]: { [string]: string } }*/ ) {
    if (hmrAcceptCheckOne(bundle, id, depsByBundle)) return true;
    // Traverse parents breadth first. All possible ancestries must accept the HMR update, or we'll reload.
    let parents = getParents(module.bundle.root, id);
    let accepted = false;
    while(parents.length > 0){
        let v = parents.shift();
        let a = hmrAcceptCheckOne(v[0], v[1], null);
        if (a) // If this parent accepts, stop traversing upward, but still consider siblings.
        accepted = true;
        else {
            // Otherwise, queue the parents in the next level upward.
            let p = getParents(module.bundle.root, v[1]);
            if (p.length === 0) {
                // If there are no parents, then we've reached an entry without accepting. Reload.
                accepted = false;
                break;
            }
            parents.push(...p);
        }
    }
    return accepted;
}
function hmrAcceptCheckOne(bundle /*: ParcelRequire */ , id /*: string */ , depsByBundle /*: ?{ [string]: { [string]: string } }*/ ) {
    var modules = bundle.modules;
    if (!modules) return;
    if (depsByBundle && !depsByBundle[bundle.HMR_BUNDLE_ID]) {
        // If we reached the root bundle without finding where the asset should go,
        // there's nothing to do. Mark as "accepted" so we don't reload the page.
        if (!bundle.parent) return true;
        return hmrAcceptCheck(bundle.parent, id, depsByBundle);
    }
    if (checkedAssets[id]) return true;
    checkedAssets[id] = true;
    var cached = bundle.cache[id];
    assetsToDispose.push([
        bundle,
        id
    ]);
    if (!cached || cached.hot && cached.hot._acceptCallbacks.length) {
        assetsToAccept.push([
            bundle,
            id
        ]);
        return true;
    }
}
function hmrDispose(bundle /*: ParcelRequire */ , id /*: string */ ) {
    var cached = bundle.cache[id];
    bundle.hotData[id] = {};
    if (cached && cached.hot) cached.hot.data = bundle.hotData[id];
    if (cached && cached.hot && cached.hot._disposeCallbacks.length) cached.hot._disposeCallbacks.forEach(function(cb) {
        cb(bundle.hotData[id]);
    });
    delete bundle.cache[id];
}
function hmrAccept(bundle /*: ParcelRequire */ , id /*: string */ ) {
    // Execute the module.
    bundle(id);
    // Run the accept callbacks in the new version of the module.
    var cached = bundle.cache[id];
    if (cached && cached.hot && cached.hot._acceptCallbacks.length) cached.hot._acceptCallbacks.forEach(function(cb) {
        var assetsToAlsoAccept = cb(function() {
            return getParents(module.bundle.root, id);
        });
        if (assetsToAlsoAccept && assetsToAccept.length) {
            assetsToAlsoAccept.forEach(function(a) {
                hmrDispose(a[0], a[1]);
            });
            // $FlowFixMe[method-unbinding]
            assetsToAccept.push.apply(assetsToAccept, assetsToAlsoAccept);
        }
    });
}

},{}],"hGA5H":[function(require,module,exports) {
// Array to store the excluded URLs
let excludedUrls = [];
// The map to store unique URLs
let urlMap = new Map();
chrome.tabs.onUpdated.addListener(async (tabId, info, tab)=>{
    // Allow users to open the sidebar by clicking on the action toolbar icon
    chrome.sidePanel.setPanelBehavior({
        openPanelOnActionClick: true
    }).catch((error)=>console.error(error));
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse)=>{
    switch(request.command){
        case "startCapture":
            // Get the excluded URLs from the request
            excludedUrls = request.excludedUrls || [];
            urlMap.clear();
            // Start the webRequest listener
            chrome.webRequest.onBeforeRequest.addListener(listener, {
                urls: [
                    "<all_urls>"
                ]
            }, [
                "requestBody"
            ]);
            break;
        case "stopCapture":
            // Stop the webRequest listener
            chrome.webRequest.onBeforeRequest.removeListener(listener);
            break;
        case "getUrls":
            // Return the URL set when requested
            sendResponse(Array.from(urlMap));
            break;
    }
    return true // This is required to indicate that you will send a response asynchronously
    ;
});
function listener(details) {
    try {
        // Parse the URL and get the pathname + method
        const url = new URL(details.url);
        const pathname = url.pathname;
        const hostname = `${url.protocol}//${url.hostname}:${url.port}`;
        const { method } = details;
        // Check if the pathname matches any of the excluded patterns
        // Also check if the pattern is not an empty string
        if (!details.url.includes("$batch") && !excludedUrls.some((pattern)=>pattern && pathname.includes(pattern)) && !urlMap.has(pathname)) {
            // Add the pathname and method to the map
            urlMap.set(pathname, method);
            // Send a message to the side panel with the new URL
            sendMessage("newUrl", pathname, hostname, method);
        }
        if (details.url.includes("$batch") && details.requestBody && details.requestBody.raw) {
            // First show the Batch request
            // Send a message to the side panel with the new URL
            sendMessage("newUrl", pathname, hostname, method);
            const basePath = pathname.split("$batch")[0];
            // Fetching the request payload
            let decoder = new TextDecoder("utf-8");
            let payload = decoder.decode(details.requestBody.raw[0].bytes);
            // Splitting the payload into separate lines
            const lines = payload.split("\r\n");
            // Filter out lines that start with HTTP methods
            const requests = lines.filter((line)=>[
                    "GET",
                    "POST",
                    "PUT",
                    "DELETE"
                ].some((anyMethod)=>line.startsWith(anyMethod)));
            requests.forEach((request, index)=>{
                // Extract the method, url and other relevant parts from the request
                const [method, path] = request.trim().split(" ");
                const url = basePath + path;
                // Check if the URL is not in the excluded URLs list
                if (!excludedUrls.some((pattern)=>url.includes(pattern))) // Send a message to the side panel with the new URL
                sendMessage("newUrl", url, hostname, method, true);
            });
        }
    } catch (error) {
        console.error(error);
    }
}
function sendMessage(command, url, hostname, method, batch) {
    chrome.runtime.sendMessage({
        command,
        url,
        hostname,
        method,
        batch
    });
}

},{}]},["ef4b6","hGA5H"], "hGA5H", "parcelRequire6d0a")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJLFdBQVc7QUFBWSxJQUFJLFdBQVc7QUFBSyxJQUFJLGFBQWE7QUFBTSxJQUFJLGVBQWU7QUFBbUIsT0FBTyxPQUFPLGdCQUFnQjtBQUFtQjtBQUU3SixpSkFBaUosR0FDako7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTZDQSxHQUNBLElBQUksYUFBYTtBQUNqQixJQUFJLFlBQVksT0FBTyxPQUFPO0FBQzlCLFNBQVMsT0FBTyxVQUFVO0lBQ3hCLFVBQVUsS0FBSyxJQUFJLEVBQUU7SUFDckIsSUFBSSxDQUFDLE1BQU07UUFDVCxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUMsV0FBVztRQUN2QyxrQkFBa0IsRUFBRTtRQUNwQixtQkFBbUIsRUFBRTtRQUNyQixRQUFRLFNBQVUsRUFBRTtZQUNsQixJQUFJLENBQUMsaUJBQWlCLEtBQUssTUFBTSxZQUFhO1FBQ2hEO1FBQ0EsU0FBUyxTQUFVLEVBQUU7WUFDbkIsSUFBSSxDQUFDLGtCQUFrQixLQUFLO1FBQzlCO0lBQ0Y7SUFDQSxPQUFPLE9BQU8sT0FBTyxDQUFDLFdBQVcsR0FBRztBQUN0QztBQUNBLE9BQU8sT0FBTyxTQUFTO0FBQ3ZCLE9BQU8sT0FBTyxVQUFVLENBQUM7QUFDekIsSUFBSSxjQUFjLDBCQUEwQixLQUFJLGdCQUFnQixtQ0FBbUMsS0FBSSxlQUFlLG1DQUFtQztBQUV6SixTQUFTO0lBQ1AsT0FBTyxZQUFhLENBQUEsU0FBUyxTQUFTLFFBQVEsWUFBWSxJQUFJLFNBQVMsV0FBVyxXQUFVO0FBQzlGO0FBQ0EsU0FBUztJQUNQLE9BQU8sWUFBWSxTQUFTO0FBQzlCO0FBRUEsd0NBQXdDO0FBQ3hDLElBQUksU0FBUyxPQUFPLE9BQU87QUFDM0IsSUFBSSxBQUFDLENBQUEsQ0FBQyxVQUFVLENBQUMsT0FBTyxlQUFjLEtBQU0sT0FBTyxjQUFjLGFBQWE7SUFDNUUsSUFBSSxXQUFXO0lBQ2YsSUFBSSxPQUFPO0lBQ1gsSUFBSSxXQUFXLGNBQWMsU0FBUyxZQUFZLFlBQVksQ0FBQyw4QkFBOEIsS0FBSyxZQUFZLFFBQVE7SUFDdEgsSUFBSSxLQUFLLElBQUksVUFBVSxXQUFXLFFBQVEsV0FBWSxDQUFBLE9BQU8sTUFBTSxPQUFPLEVBQUMsSUFBSztJQUVoRix3QkFBd0I7SUFDeEIsSUFBSSxTQUFTLE9BQU8sV0FBVyxjQUFjLE9BQU8sWUFBWSxjQUFjLE9BQU8sVUFBVTtJQUUvRixvREFBb0Q7SUFDcEQsMERBQTBEO0lBQzFELElBQUksb0JBQW9CO0lBQ3hCLElBQUk7UUFDRCxDQUFBLEdBQUcsSUFBRyxFQUFHO0lBQ1osRUFBRSxPQUFPLEtBQUs7UUFDWixvQkFBb0IsSUFBSSxNQUFNLFNBQVM7SUFDekM7SUFFQSxhQUFhO0lBQ2IsR0FBRyxZQUFZLGVBQWdCLE1BQU0sd0JBQXdCLEdBQXpCO1FBQ2xDLGdCQUFnQixDQUFDLEVBQUUsMEJBQTBCO1FBQzdDLGlCQUFpQixFQUFFO1FBQ25CLGtCQUFrQixFQUFFO1FBQ3BCLElBQUksS0FBSyxlQUFlLE1BQUssS0FBSyxNQUFNLE1BQU07UUFDOUMsSUFBSSxLQUFLLFNBQVMsVUFBVTtZQUMxQix1Q0FBdUM7WUFDdkMsSUFBSSxPQUFPLGFBQWEsYUFDdEI7WUFFRixJQUFJLFNBQVMsS0FBSyxPQUFPLE9BQU8sQ0FBQSxRQUFTLE1BQU0sWUFBWTtZQUUzRCxvQkFBb0I7WUFDcEIsSUFBSSxVQUFVLE9BQU8sTUFBTSxDQUFBO2dCQUN6QixPQUFPLE1BQU0sU0FBUyxTQUFTLE1BQU0sU0FBUyxRQUFRLGVBQWUsT0FBTyxPQUFPLE1BQU0sTUFBTSxJQUFJLE1BQU07WUFDM0c7WUFDQSxJQUFJLFNBQVM7Z0JBQ1gsUUFBUTtnQkFFUix5RUFBeUU7Z0JBQ3pFLElBQUksT0FBTyxXQUFXLGVBQWUsT0FBTyxnQkFBZ0IsYUFDMUQsT0FBTyxjQUFjLElBQUksWUFBWTtnQkFFdkMsTUFBTSxnQkFBZ0I7Z0JBRXRCLDBCQUEwQjtnQkFDMUIsSUFBSSxrQkFBa0IsQ0FBQyxFQUFFLDBCQUEwQjtnQkFDbkQsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLGdCQUFnQixRQUFRLElBQUs7b0JBQy9DLElBQUksS0FBSyxlQUFlLENBQUMsRUFBRSxDQUFDLEVBQUU7b0JBQzlCLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxFQUFFO3dCQUN4QixXQUFXLGVBQWUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUNsQyxlQUFlLENBQUMsR0FBRyxHQUFHO29CQUN4QjtnQkFDRjtnQkFFQSw4RkFBOEY7Z0JBQzlGLGtCQUFrQixDQUFDO2dCQUNuQixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksZUFBZSxRQUFRLElBQUs7b0JBQzlDLElBQUksS0FBSyxjQUFjLENBQUMsRUFBRSxDQUFDLEVBQUU7b0JBQzdCLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxFQUFFO3dCQUN4QixVQUFVLGNBQWMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUNoQyxlQUFlLENBQUMsR0FBRyxHQUFHO29CQUN4QjtnQkFDRjtZQUNGLE9BQU87UUFDVDtRQUNBLElBQUksS0FBSyxTQUFTLFNBQVM7WUFDekIsK0JBQStCO1lBQy9CLEtBQUssSUFBSSxrQkFBa0IsS0FBSyxZQUFZLEtBQU07Z0JBQ2hELElBQUksUUFBUSxlQUFlLFlBQVksZUFBZSxZQUFZLGVBQWU7Z0JBQ2pGLFFBQVEsTUFBTSw0QkFBa0IsZUFBZSxVQUFVLE9BQU8sUUFBUSxTQUFTLGVBQWUsTUFBTSxLQUFLO1lBQzdHO1lBQ0EsSUFBSSxPQUFPLGFBQWEsYUFBYTtnQkFDbkMsZ0NBQWdDO2dCQUNoQztnQkFDQSxJQUFJLFVBQVUsbUJBQW1CLEtBQUssWUFBWTtnQkFDbEQsYUFBYTtnQkFDYixTQUFTLEtBQUssWUFBWTtZQUM1QjtRQUNGO0lBQ0Y7SUFDQSxHQUFHLFVBQVUsU0FBVSxDQUFDO1FBQ3RCLFFBQVEsTUFBTSxFQUFFO0lBQ2xCO0lBQ0EsR0FBRyxVQUFVO1FBQ1gsUUFBUSxLQUFLO0lBQ2Y7QUFDRjtBQUNBLFNBQVM7SUFDUCxJQUFJLFVBQVUsU0FBUyxlQUFlO0lBQ3RDLElBQUksU0FBUztRQUNYLFFBQVE7UUFDUixRQUFRLElBQUk7SUFDZDtBQUNGO0FBQ0EsU0FBUyxtQkFBbUIsV0FBVztJQUNyQyxJQUFJLFVBQVUsU0FBUyxjQUFjO0lBQ3JDLFFBQVEsS0FBSztJQUNiLElBQUksWUFBWTtJQUNoQixLQUFLLElBQUksY0FBYyxZQUFhO1FBQ2xDLElBQUksUUFBUSxXQUFXLE9BQU8sU0FBUyxXQUFXLE9BQU8sT0FBTyxDQUFDLEdBQUc7WUFDbEUsT0FBTyxDQUFDLEVBQUUsRUFBRTtzQ0FDb0IsRUFBRSxtQkFBbUIsTUFBTSxVQUFVLDJGQUEyRixFQUFFLE1BQU0sU0FBUztBQUN2TCxFQUFFLE1BQU0sS0FBSyxDQUFDO1FBQ1YsR0FBRyxNQUFNLFdBQVc7UUFDcEIsYUFBYSxDQUFDOzs7YUFHTCxFQUFFLFdBQVcsUUFBUTs7YUFFckIsRUFBRSxNQUFNOztVQUVYLEVBQUUsV0FBVyxNQUFNLElBQUksQ0FBQSxPQUFRLHVCQUFhLE9BQU8sVUFBVSxLQUFLLElBQUk7O1FBRXhFLEVBQUUsV0FBVyxnQkFBZ0IsQ0FBQyx1Q0FBdUMsRUFBRSxXQUFXLGNBQWMsc0NBQXNDLENBQUMsR0FBRyxHQUFHOztJQUVqSixDQUFDO0lBQ0g7SUFDQSxhQUFhO0lBQ2IsUUFBUSxZQUFZO0lBQ3BCLE9BQU87QUFDVDtBQUNBLFNBQVM7SUFDUCxJQUFJLFlBQVksVUFDZCxTQUFTO1NBQ0osSUFBSSxVQUFVLE9BQU8sV0FBVyxPQUFPLFFBQVEsUUFDcEQsT0FBTyxRQUFRO0FBRW5CO0FBQ0EsU0FBUyxXQUFXLE1BQU0sRUFBRSxFQUFFLEVBQUUsbUNBQW1DO0lBQ2pFLElBQUksVUFBVSxPQUFPO0lBQ3JCLElBQUksQ0FBQyxTQUNILE9BQU8sRUFBRTtJQUVYLElBQUksVUFBVSxFQUFFO0lBQ2hCLElBQUksR0FBRyxHQUFHO0lBQ1YsSUFBSyxLQUFLLFFBQ1IsSUFBSyxLQUFLLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFFO1FBQ3ZCLE1BQU0sT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRTtRQUN0QixJQUFJLFFBQVEsTUFBTSxNQUFNLFFBQVEsUUFBUSxHQUFHLENBQUMsSUFBSSxTQUFTLEVBQUUsS0FBSyxJQUM5RCxRQUFRLEtBQUs7WUFBQztZQUFRO1NBQUU7SUFFNUI7SUFFRixJQUFJLE9BQU8sUUFDVCxVQUFVLFFBQVEsT0FBTyxXQUFXLE9BQU8sUUFBUTtJQUVyRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsSUFBSTtJQUN0QixJQUFJLE9BQU8sS0FBSyxhQUFhO0lBQzdCLElBQUksQ0FBQyxNQUNIO0lBRUYsSUFBSSxVQUFVLEtBQUs7SUFDbkIsUUFBUSxTQUFTO1FBQ2YsSUFBSSxLQUFLLGVBQWUsTUFDdEIsYUFBYTtRQUNiLEtBQUssV0FBVyxZQUFZO0lBRWhDO0lBQ0EsUUFBUSxhQUFhLFFBQ3JCLGFBQWE7SUFDYixLQUFLLE1BQU0sSUFBSSxDQUFDLEVBQUUsR0FBRyxNQUFNLEtBQUs7SUFDaEMsYUFBYTtJQUNiLEtBQUssV0FBVyxhQUFhLFNBQVMsS0FBSztBQUM3QztBQUNBLElBQUksYUFBYTtBQUNqQixTQUFTO0lBQ1AsSUFBSSxZQUNGO0lBRUYsYUFBYSxXQUFXO1FBQ3RCLElBQUksUUFBUSxTQUFTLGlCQUFpQjtRQUN0QyxJQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLElBQUs7WUFDckMsZ0NBQWdDO1lBQ2hDLElBQUksS0FBSyxXQUFXLE1BQUssS0FBSyxDQUFDLEVBQUUsQ0FBQyxhQUFhO1lBQy9DLElBQUksV0FBVztZQUNmLElBQUksc0JBQXNCLGFBQWEsY0FBYyxJQUFJLE9BQU8sbURBQW1ELFdBQVcsS0FBSyxRQUFRLEtBQUssUUFBUSxXQUFXLE1BQU07WUFDekssSUFBSSxXQUFXLGdCQUFnQixLQUFLLFNBQVMsS0FBSyxRQUFRLFNBQVMsWUFBWSxLQUFLLENBQUM7WUFDckYsSUFBSSxDQUFDLFVBQ0gsV0FBVyxLQUFLLENBQUMsRUFBRTtRQUV2QjtRQUNBLGFBQWE7SUFDZixHQUFHO0FBQ0w7QUFDQSxTQUFTLFlBQVksS0FBSztJQUN4QixJQUFJLE1BQU0sU0FBUyxNQUFNO1FBQ3ZCLElBQUksT0FBTyxhQUFhLGFBQWE7WUFDbkMsSUFBSSxTQUFTLFNBQVMsY0FBYztZQUNwQyxPQUFPLE1BQU0sTUFBTSxNQUFNLFFBQVEsS0FBSztZQUN0QyxJQUFJLE1BQU0saUJBQWlCLFlBQ3pCLE9BQU8sT0FBTztZQUVoQixPQUFPLElBQUksUUFBUSxDQUFDLFNBQVM7Z0JBQzNCLElBQUk7Z0JBQ0osT0FBTyxTQUFTLElBQU0sUUFBUTtnQkFDOUIsT0FBTyxVQUFVO2dCQUNoQixDQUFBLGlCQUFpQixTQUFTLElBQUcsTUFBTyxRQUFRLG1CQUFtQixLQUFLLEtBQWEsZUFBZSxZQUFZO1lBQy9HO1FBQ0YsT0FBTyxJQUFJLE9BQU8sa0JBQWtCLFlBQVk7WUFDOUMsaUJBQWlCO1lBQ2pCLElBQUksTUFBTSxpQkFBaUIsWUFDekIsT0FBTyxPQUFtQixNQUFNLE1BQU0sUUFBUSxLQUFLO2lCQUVuRCxPQUFPLElBQUksUUFBUSxDQUFDLFNBQVM7Z0JBQzNCLElBQUk7b0JBQ0YsY0FBMEIsTUFBTSxNQUFNLFFBQVEsS0FBSztvQkFDbkQ7Z0JBQ0YsRUFBRSxPQUFPLEtBQUs7b0JBQ1osT0FBTztnQkFDVDtZQUNGO1FBRUo7SUFDRjtBQUNGO0FBQ0EsZUFBZSxnQkFBZ0IsTUFBTTtJQUNuQyxPQUFPLGtCQUFrQixPQUFPLE9BQU87SUFDdkMsSUFBSTtJQUNKLElBQUk7UUFDRixrRUFBa0U7UUFDbEUsZ0VBQWdFO1FBQ2hFLGdFQUFnRTtRQUNoRSxtREFBbUQ7UUFDbkQsaURBQWlEO1FBQ2pELG1EQUFtRDtRQUNuRCxJQUFJLENBQUMsbUJBQW1CO1lBQ3RCLElBQUksV0FBVyxPQUFPLElBQUksQ0FBQTtnQkFDeEIsSUFBSTtnQkFDSixPQUFPLEFBQUMsQ0FBQSxlQUFlLFlBQVksTUFBSyxNQUFPLFFBQVEsaUJBQWlCLEtBQUssSUFBSSxLQUFLLElBQUksYUFBYSxNQUFNLENBQUE7b0JBQzNHLG9DQUFvQztvQkFDcEMsb0VBQW9FO29CQUNwRSxJQUFJLFVBQVUsT0FBTyxXQUFXLE9BQU8sUUFBUSxjQUFjLG9CQUFvQixHQUFHO3dCQUNsRixJQUFJLE9BQU8sNEJBQTRCLGVBQWUsa0JBQWtCLDBCQUEwQjs0QkFDaEcsT0FBTyxRQUFROzRCQUNmO3dCQUNGO3dCQUNBLE1BQU0sTUFBTSxPQUFPLFFBQVEsT0FBTywrQkFBK0IsbUJBQW1CLE1BQU0sTUFBTSxRQUFRLEtBQUs7d0JBQzdHLE9BQU8sWUFBWTtvQkFDckI7b0JBQ0EsTUFBTTtnQkFDUjtZQUNGO1lBQ0Esa0JBQWtCLE1BQU0sUUFBUSxJQUFJO1FBQ3RDO1FBQ0EsT0FBTyxRQUFRLFNBQVUsS0FBSztZQUM1QixTQUFTLE9BQU8sT0FBTyxNQUFNO1FBQy9CO0lBQ0YsU0FBVTtRQUNSLE9BQU8sT0FBTztRQUNkLElBQUksaUJBQ0YsZ0JBQWdCLFFBQVEsQ0FBQTtZQUN0QixJQUFJLFFBQVE7Z0JBQ1YsSUFBSTtnQkFDSCxDQUFBLGtCQUFrQixTQUFTLElBQUcsTUFBTyxRQUFRLG9CQUFvQixLQUFLLEtBQWEsZ0JBQWdCLFlBQVk7WUFDbEg7UUFDRjtJQUVKO0FBQ0Y7QUFDQSxTQUFTLFNBQVMsT0FBTyxrQkFBa0IsR0FBbkIsRUFBdUIsTUFBTSxjQUFjLEdBQWY7SUFDbEQsSUFBSSxVQUFVLE9BQU87SUFDckIsSUFBSSxDQUFDLFNBQ0g7SUFFRixJQUFJLE1BQU0sU0FBUyxPQUNqQjtTQUNLLElBQUksTUFBTSxTQUFTLE1BQU07UUFDOUIsSUFBSSxPQUFPLE1BQU0sWUFBWSxDQUFDLE9BQU8sY0FBYztRQUNuRCxJQUFJLE1BQU07WUFDUixJQUFJLE9BQU8sQ0FBQyxNQUFNLEdBQUcsRUFBRTtnQkFDckIsaUVBQWlFO2dCQUNqRSxvSEFBb0g7Z0JBQ3BILElBQUksVUFBVSxPQUFPLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDbEMsSUFBSyxJQUFJLE9BQU8sUUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxJQUFJLEVBQUU7b0JBQzVDLElBQUksS0FBSyxPQUFPLENBQUMsSUFBSTtvQkFDckIsSUFBSSxVQUFVLFdBQVcsT0FBTyxPQUFPLE1BQU07b0JBQzdDLElBQUksUUFBUSxXQUFXLEdBQ3JCLFVBQVUsT0FBTyxPQUFPLE1BQU07Z0JBRWxDO1lBRUo7WUFDQSxJQUFJLG1CQUdGLEFBRkEsNERBQTREO1lBQzVELCtDQUErQztZQUM5QyxDQUFBLEdBQUcsSUFBRyxFQUFHLE1BQU07WUFHbEIsYUFBYTtZQUNiLElBQUksS0FBSyxPQUFPLGVBQWUsQ0FBQyxNQUFNLEdBQUc7WUFDekMsT0FBTyxDQUFDLE1BQU0sR0FBRyxHQUFHO2dCQUFDO2dCQUFJO2FBQUs7UUFDaEMsT0FBTyxJQUFJLE9BQU8sUUFDaEIsU0FBUyxPQUFPLFFBQVE7SUFFNUI7QUFDRjtBQUNBLFNBQVMsVUFBVSxNQUFNLEVBQUUsRUFBRTtJQUMzQixJQUFJLFVBQVUsT0FBTztJQUNyQixJQUFJLENBQUMsU0FDSDtJQUVGLElBQUksT0FBTyxDQUFDLEdBQUcsRUFBRTtRQUNmLDhFQUE4RTtRQUM5RSxJQUFJLE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQ3pCLElBQUksVUFBVSxFQUFFO1FBQ2hCLElBQUssSUFBSSxPQUFPLEtBQU07WUFDcEIsSUFBSSxVQUFVLFdBQVcsT0FBTyxPQUFPLE1BQU0sSUFBSSxDQUFDLElBQUk7WUFDdEQsSUFBSSxRQUFRLFdBQVcsR0FDckIsUUFBUSxLQUFLLElBQUksQ0FBQyxJQUFJO1FBRTFCO1FBRUEsc0dBQXNHO1FBQ3RHLE9BQU8sT0FBTyxDQUFDLEdBQUc7UUFDbEIsT0FBTyxPQUFPLEtBQUssQ0FBQyxHQUFHO1FBRXZCLDBCQUEwQjtRQUMxQixRQUFRLFFBQVEsQ0FBQTtZQUNkLFVBQVUsT0FBTyxPQUFPLE1BQU07UUFDaEM7SUFDRixPQUFPLElBQUksT0FBTyxRQUNoQixVQUFVLE9BQU8sUUFBUTtBQUU3QjtBQUNBLFNBQVMsZUFBZSxPQUFPLGtCQUFrQixHQUFuQixFQUF1QixHQUFHLFdBQVcsR0FBWixFQUFnQixhQUFhLHVDQUF1QyxHQUF4QztJQUNqRixJQUFJLGtCQUFrQixRQUFRLElBQUksZUFDaEMsT0FBTztJQUdULHVHQUF1RztJQUN2RyxJQUFJLFVBQVUsV0FBVyxPQUFPLE9BQU8sTUFBTTtJQUM3QyxJQUFJLFdBQVc7SUFDZixNQUFPLFFBQVEsU0FBUyxFQUFHO1FBQ3pCLElBQUksSUFBSSxRQUFRO1FBQ2hCLElBQUksSUFBSSxrQkFBa0IsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO1FBQ3RDLElBQUksR0FDRiwrRUFBK0U7UUFDL0UsV0FBVzthQUNOO1lBQ0wseURBQXlEO1lBQ3pELElBQUksSUFBSSxXQUFXLE9BQU8sT0FBTyxNQUFNLENBQUMsQ0FBQyxFQUFFO1lBQzNDLElBQUksRUFBRSxXQUFXLEdBQUc7Z0JBQ2xCLGtGQUFrRjtnQkFDbEYsV0FBVztnQkFDWDtZQUNGO1lBQ0EsUUFBUSxRQUFRO1FBQ2xCO0lBQ0Y7SUFDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixPQUFPLGtCQUFrQixHQUFuQixFQUF1QixHQUFHLFdBQVcsR0FBWixFQUFnQixhQUFhLHVDQUF1QyxHQUF4QztJQUNwRixJQUFJLFVBQVUsT0FBTztJQUNyQixJQUFJLENBQUMsU0FDSDtJQUVGLElBQUksZ0JBQWdCLENBQUMsWUFBWSxDQUFDLE9BQU8sY0FBYyxFQUFFO1FBQ3ZELDJFQUEyRTtRQUMzRSx5RUFBeUU7UUFDekUsSUFBSSxDQUFDLE9BQU8sUUFDVixPQUFPO1FBRVQsT0FBTyxlQUFlLE9BQU8sUUFBUSxJQUFJO0lBQzNDO0lBQ0EsSUFBSSxhQUFhLENBQUMsR0FBRyxFQUNuQixPQUFPO0lBRVQsYUFBYSxDQUFDLEdBQUcsR0FBRztJQUNwQixJQUFJLFNBQVMsT0FBTyxLQUFLLENBQUMsR0FBRztJQUM3QixnQkFBZ0IsS0FBSztRQUFDO1FBQVE7S0FBRztJQUNqQyxJQUFJLENBQUMsVUFBVSxPQUFPLE9BQU8sT0FBTyxJQUFJLGlCQUFpQixRQUFRO1FBQy9ELGVBQWUsS0FBSztZQUFDO1lBQVE7U0FBRztRQUNoQyxPQUFPO0lBQ1Q7QUFDRjtBQUNBLFNBQVMsV0FBVyxPQUFPLGtCQUFrQixHQUFuQixFQUF1QixHQUFHLFdBQVcsR0FBWjtJQUNqRCxJQUFJLFNBQVMsT0FBTyxLQUFLLENBQUMsR0FBRztJQUM3QixPQUFPLE9BQU8sQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUN0QixJQUFJLFVBQVUsT0FBTyxLQUNuQixPQUFPLElBQUksT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHO0lBRXRDLElBQUksVUFBVSxPQUFPLE9BQU8sT0FBTyxJQUFJLGtCQUFrQixRQUN2RCxPQUFPLElBQUksa0JBQWtCLFFBQVEsU0FBVSxFQUFFO1FBQy9DLEdBQUcsT0FBTyxPQUFPLENBQUMsR0FBRztJQUN2QjtJQUVGLE9BQU8sT0FBTyxLQUFLLENBQUMsR0FBRztBQUN6QjtBQUNBLFNBQVMsVUFBVSxPQUFPLGtCQUFrQixHQUFuQixFQUF1QixHQUFHLFdBQVcsR0FBWjtJQUNoRCxzQkFBc0I7SUFDdEIsT0FBTztJQUVQLDZEQUE2RDtJQUM3RCxJQUFJLFNBQVMsT0FBTyxLQUFLLENBQUMsR0FBRztJQUM3QixJQUFJLFVBQVUsT0FBTyxPQUFPLE9BQU8sSUFBSSxpQkFBaUIsUUFDdEQsT0FBTyxJQUFJLGlCQUFpQixRQUFRLFNBQVUsRUFBRTtRQUM5QyxJQUFJLHFCQUFxQixHQUFHO1lBQzFCLE9BQU8sV0FBVyxPQUFPLE9BQU8sTUFBTTtRQUN4QztRQUNBLElBQUksc0JBQXNCLGVBQWUsUUFBUTtZQUMvQyxtQkFBbUIsUUFBUSxTQUFVLENBQUM7Z0JBQ3BDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRTtZQUN2QjtZQUVBLCtCQUErQjtZQUMvQixlQUFlLEtBQUssTUFBTSxnQkFBZ0I7UUFDNUM7SUFDRjtBQUVKOzs7QUMzZUEsbUNBQW1DO0FBQ25DLElBQUksZUFBeUIsRUFBRTtBQUUvQiwrQkFBK0I7QUFDL0IsSUFBSSxTQUFTLElBQUk7QUFFakIsT0FBTyxLQUFLLFVBQVUsWUFBWSxPQUFPLE9BQU8sTUFBTTtJQUNwRCx5RUFBeUU7SUFDekUsT0FBTyxVQUNKLGlCQUFpQjtRQUFDLHdCQUF3QjtJQUFJLEdBQzlDLE1BQU0sQ0FBQyxRQUFVLFFBQVEsTUFBTTtBQUNwQztBQUVBLE9BQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxTQUFTLFFBQVE7SUFDckQsT0FBUSxRQUFRO1FBQ2QsS0FBSztZQUNILHlDQUF5QztZQUN6QyxlQUFlLFFBQVEsZ0JBQWdCLEVBQUU7WUFDekMsT0FBTztZQUNQLGdDQUFnQztZQUNoQyxPQUFPLFdBQVcsZ0JBQWdCLFlBQ2hDLFVBQ0E7Z0JBQUMsTUFBTTtvQkFBQztpQkFBYTtZQUFBLEdBQ3JCO2dCQUFDO2FBQWM7WUFFakI7UUFDRixLQUFLO1lBQ0gsK0JBQStCO1lBQy9CLE9BQU8sV0FBVyxnQkFBZ0IsZUFBZTtZQUNqRDtRQUNGLEtBQUs7WUFDSCxvQ0FBb0M7WUFDcEMsYUFBYSxNQUFNLEtBQUs7WUFDeEI7SUFDSjtJQUNBLE9BQU8sS0FBSyw0RUFBNEU7O0FBQzFGO0FBRUEsU0FBUyxTQUFTLE9BQWdEO0lBQ2hFLElBQUk7UUFDRiw4Q0FBOEM7UUFDOUMsTUFBTSxNQUFNLElBQUksSUFBSSxRQUFRO1FBQzVCLE1BQU0sV0FBVyxJQUFJO1FBQ3JCLE1BQU0sV0FBVyxDQUFDLEVBQUUsSUFBSSxTQUFTLEVBQUUsRUFBRSxJQUFJLFNBQVMsQ0FBQyxFQUFFLElBQUksS0FBSyxDQUFDO1FBQy9ELE1BQU0sRUFBQyxNQUFNLEVBQUMsR0FBRztRQUVqQiw2REFBNkQ7UUFDN0QsbURBQW1EO1FBQ25ELElBQ0UsQ0FBQyxRQUFRLElBQUksU0FBUyxhQUN0QixDQUFDLGFBQWEsS0FBSyxDQUFDLFVBQVksV0FBVyxTQUFTLFNBQVMsYUFDN0QsQ0FBQyxPQUFPLElBQUksV0FDWjtZQUNBLHlDQUF5QztZQUN6QyxPQUFPLElBQUksVUFBVTtZQUVyQixvREFBb0Q7WUFDcEQsWUFBWSxVQUFVLFVBQVUsVUFBVTtRQUM1QztRQUVBLElBQ0UsUUFBUSxJQUFJLFNBQVMsYUFDckIsUUFBUSxlQUNSLFFBQVEsWUFBWSxLQUNwQjtZQUNBLCtCQUErQjtZQUMvQixvREFBb0Q7WUFDcEQsWUFBWSxVQUFVLFVBQVUsVUFBVTtZQUUxQyxNQUFNLFdBQVcsU0FBUyxNQUFNLFNBQVMsQ0FBQyxFQUFFO1lBRTVDLCtCQUErQjtZQUMvQixJQUFJLFVBQVUsSUFBSSxZQUFZO1lBQzlCLElBQUksVUFBVSxRQUFRLE9BQU8sUUFBUSxZQUFZLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFFeEQsNENBQTRDO1lBQzVDLE1BQU0sUUFBUSxRQUFRLE1BQU07WUFFNUIsZ0RBQWdEO1lBQ2hELE1BQU0sV0FBVyxNQUFNLE9BQU8sQ0FBQyxPQUM3QjtvQkFBQztvQkFBTztvQkFBUTtvQkFBTztpQkFBUyxDQUFDLEtBQUssQ0FBQyxZQUNyQyxLQUFLLFdBQVc7WUFJcEIsU0FBUyxRQUFRLENBQUMsU0FBUztnQkFDekIsb0VBQW9FO2dCQUNwRSxNQUFNLENBQUMsUUFBUSxLQUFLLEdBQUcsUUFBUSxPQUFPLE1BQU07Z0JBQzVDLE1BQU0sTUFBTSxXQUFXO2dCQUV2QixvREFBb0Q7Z0JBQ3BELElBQUksQ0FBQyxhQUFhLEtBQUssQ0FBQyxVQUFZLElBQUksU0FBUyxXQUMvQyxvREFBb0Q7Z0JBQ3BELFlBQVksVUFBVSxLQUFLLFVBQVUsUUFBUTtZQUVqRDtRQUNGO0lBQ0YsRUFBRSxPQUFPLE9BQU87UUFDZCxRQUFRLE1BQU07SUFDaEI7QUFDRjtBQUVBLFNBQVMsWUFDUCxPQUFlLEVBQ2YsR0FBVyxFQUNYLFFBQWdCLEVBQ2hCLE1BQWMsRUFDZCxLQUFlO0lBRWYsT0FBTyxRQUFRLFlBQVk7UUFBQztRQUFTO1FBQUs7UUFBVTtRQUFRO0lBQUs7QUFDbkUiLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9AcGFyY2VsL3J1bnRpbWUtYnJvd3Nlci1obXIvbGliL3J1bnRpbWUtZjRkZmE5Y2IzNWZlZDRhYS5qcyIsInNyYy9zZXJ2aWNlLXdvcmtlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgSE1SX0hPU1QgPSBcImxvY2FsaG9zdFwiO3ZhciBITVJfUE9SVCA9IDEyMzQ7dmFyIEhNUl9TRUNVUkUgPSBmYWxzZTt2YXIgSE1SX0VOVl9IQVNIID0gXCIyMTAyODFjYWY4ZDQxNjBkXCI7bW9kdWxlLmJ1bmRsZS5ITVJfQlVORExFX0lEID0gXCJmODJhZjI4ZTlmM2FlNjRiXCI7XCJ1c2Ugc3RyaWN0XCI7XG5cbi8qIGdsb2JhbCBITVJfSE9TVCwgSE1SX1BPUlQsIEhNUl9FTlZfSEFTSCwgSE1SX1NFQ1VSRSwgY2hyb21lLCBicm93c2VyLCBfX3BhcmNlbF9faW1wb3J0X18sIF9fcGFyY2VsX19pbXBvcnRTY3JpcHRzX18sIFNlcnZpY2VXb3JrZXJHbG9iYWxTY29wZSAqL1xuLyo6OlxuaW1wb3J0IHR5cGUge1xuICBITVJBc3NldCxcbiAgSE1STWVzc2FnZSxcbn0gZnJvbSAnQHBhcmNlbC9yZXBvcnRlci1kZXYtc2VydmVyL3NyYy9ITVJTZXJ2ZXIuanMnO1xuaW50ZXJmYWNlIFBhcmNlbFJlcXVpcmUge1xuICAoc3RyaW5nKTogbWl4ZWQ7XG4gIGNhY2hlOiB7fFtzdHJpbmddOiBQYXJjZWxNb2R1bGV8fTtcbiAgaG90RGF0YToge3xbc3RyaW5nXTogbWl4ZWR8fTtcbiAgTW9kdWxlOiBhbnk7XG4gIHBhcmVudDogP1BhcmNlbFJlcXVpcmU7XG4gIGlzUGFyY2VsUmVxdWlyZTogdHJ1ZTtcbiAgbW9kdWxlczoge3xbc3RyaW5nXTogW0Z1bmN0aW9uLCB7fFtzdHJpbmddOiBzdHJpbmd8fV18fTtcbiAgSE1SX0JVTkRMRV9JRDogc3RyaW5nO1xuICByb290OiBQYXJjZWxSZXF1aXJlO1xufVxuaW50ZXJmYWNlIFBhcmNlbE1vZHVsZSB7XG4gIGhvdDoge3xcbiAgICBkYXRhOiBtaXhlZCxcbiAgICBhY2NlcHQoY2I6IChGdW5jdGlvbikgPT4gdm9pZCk6IHZvaWQsXG4gICAgZGlzcG9zZShjYjogKG1peGVkKSA9PiB2b2lkKTogdm9pZCxcbiAgICAvLyBhY2NlcHQoZGVwczogQXJyYXk8c3RyaW5nPiB8IHN0cmluZywgY2I6IChGdW5jdGlvbikgPT4gdm9pZCk6IHZvaWQsXG4gICAgLy8gZGVjbGluZSgpOiB2b2lkLFxuICAgIF9hY2NlcHRDYWxsYmFja3M6IEFycmF5PChGdW5jdGlvbikgPT4gdm9pZD4sXG4gICAgX2Rpc3Bvc2VDYWxsYmFja3M6IEFycmF5PChtaXhlZCkgPT4gdm9pZD4sXG4gIHx9O1xufVxuaW50ZXJmYWNlIEV4dGVuc2lvbkNvbnRleHQge1xuICBydW50aW1lOiB7fFxuICAgIHJlbG9hZCgpOiB2b2lkLFxuICAgIGdldFVSTCh1cmw6IHN0cmluZyk6IHN0cmluZztcbiAgICBnZXRNYW5pZmVzdCgpOiB7bWFuaWZlc3RfdmVyc2lvbjogbnVtYmVyLCAuLi59O1xuICB8fTtcbn1cbmRlY2xhcmUgdmFyIG1vZHVsZToge2J1bmRsZTogUGFyY2VsUmVxdWlyZSwgLi4ufTtcbmRlY2xhcmUgdmFyIEhNUl9IT1NUOiBzdHJpbmc7XG5kZWNsYXJlIHZhciBITVJfUE9SVDogc3RyaW5nO1xuZGVjbGFyZSB2YXIgSE1SX0VOVl9IQVNIOiBzdHJpbmc7XG5kZWNsYXJlIHZhciBITVJfU0VDVVJFOiBib29sZWFuO1xuZGVjbGFyZSB2YXIgY2hyb21lOiBFeHRlbnNpb25Db250ZXh0O1xuZGVjbGFyZSB2YXIgYnJvd3NlcjogRXh0ZW5zaW9uQ29udGV4dDtcbmRlY2xhcmUgdmFyIF9fcGFyY2VsX19pbXBvcnRfXzogKHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPjtcbmRlY2xhcmUgdmFyIF9fcGFyY2VsX19pbXBvcnRTY3JpcHRzX186IChzdHJpbmcpID0+IFByb21pc2U8dm9pZD47XG5kZWNsYXJlIHZhciBnbG9iYWxUaGlzOiB0eXBlb2Ygc2VsZjtcbmRlY2xhcmUgdmFyIFNlcnZpY2VXb3JrZXJHbG9iYWxTY29wZTogT2JqZWN0O1xuKi9cbnZhciBPVkVSTEFZX0lEID0gJ19fcGFyY2VsX19lcnJvcl9fb3ZlcmxheV9fJztcbnZhciBPbGRNb2R1bGUgPSBtb2R1bGUuYnVuZGxlLk1vZHVsZTtcbmZ1bmN0aW9uIE1vZHVsZShtb2R1bGVOYW1lKSB7XG4gIE9sZE1vZHVsZS5jYWxsKHRoaXMsIG1vZHVsZU5hbWUpO1xuICB0aGlzLmhvdCA9IHtcbiAgICBkYXRhOiBtb2R1bGUuYnVuZGxlLmhvdERhdGFbbW9kdWxlTmFtZV0sXG4gICAgX2FjY2VwdENhbGxiYWNrczogW10sXG4gICAgX2Rpc3Bvc2VDYWxsYmFja3M6IFtdLFxuICAgIGFjY2VwdDogZnVuY3Rpb24gKGZuKSB7XG4gICAgICB0aGlzLl9hY2NlcHRDYWxsYmFja3MucHVzaChmbiB8fCBmdW5jdGlvbiAoKSB7fSk7XG4gICAgfSxcbiAgICBkaXNwb3NlOiBmdW5jdGlvbiAoZm4pIHtcbiAgICAgIHRoaXMuX2Rpc3Bvc2VDYWxsYmFja3MucHVzaChmbik7XG4gICAgfVxuICB9O1xuICBtb2R1bGUuYnVuZGxlLmhvdERhdGFbbW9kdWxlTmFtZV0gPSB1bmRlZmluZWQ7XG59XG5tb2R1bGUuYnVuZGxlLk1vZHVsZSA9IE1vZHVsZTtcbm1vZHVsZS5idW5kbGUuaG90RGF0YSA9IHt9O1xudmFyIGNoZWNrZWRBc3NldHMgLyo6IHt8W3N0cmluZ106IGJvb2xlYW58fSAqLywgYXNzZXRzVG9EaXNwb3NlIC8qOiBBcnJheTxbUGFyY2VsUmVxdWlyZSwgc3RyaW5nXT4gKi8sIGFzc2V0c1RvQWNjZXB0IC8qOiBBcnJheTxbUGFyY2VsUmVxdWlyZSwgc3RyaW5nXT4gKi87XG5cbmZ1bmN0aW9uIGdldEhvc3RuYW1lKCkge1xuICByZXR1cm4gSE1SX0hPU1QgfHwgKGxvY2F0aW9uLnByb3RvY29sLmluZGV4T2YoJ2h0dHAnKSA9PT0gMCA/IGxvY2F0aW9uLmhvc3RuYW1lIDogJ2xvY2FsaG9zdCcpO1xufVxuZnVuY3Rpb24gZ2V0UG9ydCgpIHtcbiAgcmV0dXJuIEhNUl9QT1JUIHx8IGxvY2F0aW9uLnBvcnQ7XG59XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1yZWRlY2xhcmVcbnZhciBwYXJlbnQgPSBtb2R1bGUuYnVuZGxlLnBhcmVudDtcbmlmICgoIXBhcmVudCB8fCAhcGFyZW50LmlzUGFyY2VsUmVxdWlyZSkgJiYgdHlwZW9mIFdlYlNvY2tldCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgdmFyIGhvc3RuYW1lID0gZ2V0SG9zdG5hbWUoKTtcbiAgdmFyIHBvcnQgPSBnZXRQb3J0KCk7XG4gIHZhciBwcm90b2NvbCA9IEhNUl9TRUNVUkUgfHwgbG9jYXRpb24ucHJvdG9jb2wgPT0gJ2h0dHBzOicgJiYgIS9sb2NhbGhvc3R8MTI3LjAuMC4xfDAuMC4wLjAvLnRlc3QoaG9zdG5hbWUpID8gJ3dzcycgOiAnd3MnO1xuICB2YXIgd3MgPSBuZXcgV2ViU29ja2V0KHByb3RvY29sICsgJzovLycgKyBob3N0bmFtZSArIChwb3J0ID8gJzonICsgcG9ydCA6ICcnKSArICcvJyk7XG5cbiAgLy8gV2ViIGV4dGVuc2lvbiBjb250ZXh0XG4gIHZhciBleHRDdHggPSB0eXBlb2YgY2hyb21lID09PSAndW5kZWZpbmVkJyA/IHR5cGVvZiBicm93c2VyID09PSAndW5kZWZpbmVkJyA/IG51bGwgOiBicm93c2VyIDogY2hyb21lO1xuXG4gIC8vIFNhZmFyaSBkb2Vzbid0IHN1cHBvcnQgc291cmNlVVJMIGluIGVycm9yIHN0YWNrcy5cbiAgLy8gZXZhbCBtYXkgYWxzbyBiZSBkaXNhYmxlZCB2aWEgQ1NQLCBzbyBkbyBhIHF1aWNrIGNoZWNrLlxuICB2YXIgc3VwcG9ydHNTb3VyY2VVUkwgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICAoMCwgZXZhbCkoJ3Rocm93IG5ldyBFcnJvcihcInRlc3RcIik7IC8vIyBzb3VyY2VVUkw9dGVzdC5qcycpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBzdXBwb3J0c1NvdXJjZVVSTCA9IGVyci5zdGFjay5pbmNsdWRlcygndGVzdC5qcycpO1xuICB9XG5cbiAgLy8gJEZsb3dGaXhNZVxuICB3cy5vbm1lc3NhZ2UgPSBhc3luYyBmdW5jdGlvbiAoZXZlbnQgLyo6IHtkYXRhOiBzdHJpbmcsIC4uLn0gKi8pIHtcbiAgICBjaGVja2VkQXNzZXRzID0ge30gLyo6IHt8W3N0cmluZ106IGJvb2xlYW58fSAqLztcbiAgICBhc3NldHNUb0FjY2VwdCA9IFtdO1xuICAgIGFzc2V0c1RvRGlzcG9zZSA9IFtdO1xuICAgIHZhciBkYXRhIC8qOiBITVJNZXNzYWdlICovID0gSlNPTi5wYXJzZShldmVudC5kYXRhKTtcbiAgICBpZiAoZGF0YS50eXBlID09PSAndXBkYXRlJykge1xuICAgICAgLy8gUmVtb3ZlIGVycm9yIG92ZXJsYXkgaWYgdGhlcmUgaXMgb25lXG4gICAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICByZW1vdmVFcnJvck92ZXJsYXkoKTtcbiAgICAgIH1cbiAgICAgIGxldCBhc3NldHMgPSBkYXRhLmFzc2V0cy5maWx0ZXIoYXNzZXQgPT4gYXNzZXQuZW52SGFzaCA9PT0gSE1SX0VOVl9IQVNIKTtcblxuICAgICAgLy8gSGFuZGxlIEhNUiBVcGRhdGVcbiAgICAgIGxldCBoYW5kbGVkID0gYXNzZXRzLmV2ZXJ5KGFzc2V0ID0+IHtcbiAgICAgICAgcmV0dXJuIGFzc2V0LnR5cGUgPT09ICdjc3MnIHx8IGFzc2V0LnR5cGUgPT09ICdqcycgJiYgaG1yQWNjZXB0Q2hlY2sobW9kdWxlLmJ1bmRsZS5yb290LCBhc3NldC5pZCwgYXNzZXQuZGVwc0J5QnVuZGxlKTtcbiAgICAgIH0pO1xuICAgICAgaWYgKGhhbmRsZWQpIHtcbiAgICAgICAgY29uc29sZS5jbGVhcigpO1xuXG4gICAgICAgIC8vIERpc3BhdGNoIGN1c3RvbSBldmVudCBzbyBvdGhlciBydW50aW1lcyAoZS5nIFJlYWN0IFJlZnJlc2gpIGFyZSBhd2FyZS5cbiAgICAgICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBDdXN0b21FdmVudCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoJ3BhcmNlbGhtcmFjY2VwdCcpKTtcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCBobXJBcHBseVVwZGF0ZXMoYXNzZXRzKTtcblxuICAgICAgICAvLyBEaXNwb3NlIGFsbCBvbGQgYXNzZXRzLlxuICAgICAgICBsZXQgcHJvY2Vzc2VkQXNzZXRzID0ge30gLyo6IHt8W3N0cmluZ106IGJvb2xlYW58fSAqLztcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhc3NldHNUb0Rpc3Bvc2UubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBsZXQgaWQgPSBhc3NldHNUb0Rpc3Bvc2VbaV1bMV07XG4gICAgICAgICAgaWYgKCFwcm9jZXNzZWRBc3NldHNbaWRdKSB7XG4gICAgICAgICAgICBobXJEaXNwb3NlKGFzc2V0c1RvRGlzcG9zZVtpXVswXSwgaWQpO1xuICAgICAgICAgICAgcHJvY2Vzc2VkQXNzZXRzW2lkXSA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gUnVuIGFjY2VwdCBjYWxsYmFja3MuIFRoaXMgd2lsbCBhbHNvIHJlLWV4ZWN1dGUgb3RoZXIgZGlzcG9zZWQgYXNzZXRzIGluIHRvcG9sb2dpY2FsIG9yZGVyLlxuICAgICAgICBwcm9jZXNzZWRBc3NldHMgPSB7fTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhc3NldHNUb0FjY2VwdC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGxldCBpZCA9IGFzc2V0c1RvQWNjZXB0W2ldWzFdO1xuICAgICAgICAgIGlmICghcHJvY2Vzc2VkQXNzZXRzW2lkXSkge1xuICAgICAgICAgICAgaG1yQWNjZXB0KGFzc2V0c1RvQWNjZXB0W2ldWzBdLCBpZCk7XG4gICAgICAgICAgICBwcm9jZXNzZWRBc3NldHNbaWRdID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBmdWxsUmVsb2FkKCk7XG4gICAgfVxuICAgIGlmIChkYXRhLnR5cGUgPT09ICdlcnJvcicpIHtcbiAgICAgIC8vIExvZyBwYXJjZWwgZXJyb3JzIHRvIGNvbnNvbGVcbiAgICAgIGZvciAobGV0IGFuc2lEaWFnbm9zdGljIG9mIGRhdGEuZGlhZ25vc3RpY3MuYW5zaSkge1xuICAgICAgICBsZXQgc3RhY2sgPSBhbnNpRGlhZ25vc3RpYy5jb2RlZnJhbWUgPyBhbnNpRGlhZ25vc3RpYy5jb2RlZnJhbWUgOiBhbnNpRGlhZ25vc3RpYy5zdGFjaztcbiAgICAgICAgY29uc29sZS5lcnJvcign8J+aqCBbcGFyY2VsXTogJyArIGFuc2lEaWFnbm9zdGljLm1lc3NhZ2UgKyAnXFxuJyArIHN0YWNrICsgJ1xcblxcbicgKyBhbnNpRGlhZ25vc3RpYy5oaW50cy5qb2luKCdcXG4nKSk7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAvLyBSZW5kZXIgdGhlIGZhbmN5IGh0bWwgb3ZlcmxheVxuICAgICAgICByZW1vdmVFcnJvck92ZXJsYXkoKTtcbiAgICAgICAgdmFyIG92ZXJsYXkgPSBjcmVhdGVFcnJvck92ZXJsYXkoZGF0YS5kaWFnbm9zdGljcy5odG1sKTtcbiAgICAgICAgLy8gJEZsb3dGaXhNZVxuICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKG92ZXJsYXkpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgd3Mub25lcnJvciA9IGZ1bmN0aW9uIChlKSB7XG4gICAgY29uc29sZS5lcnJvcihlLm1lc3NhZ2UpO1xuICB9O1xuICB3cy5vbmNsb3NlID0gZnVuY3Rpb24gKCkge1xuICAgIGNvbnNvbGUud2FybignW3BhcmNlbF0g8J+aqCBDb25uZWN0aW9uIHRvIHRoZSBITVIgc2VydmVyIHdhcyBsb3N0Jyk7XG4gIH07XG59XG5mdW5jdGlvbiByZW1vdmVFcnJvck92ZXJsYXkoKSB7XG4gIHZhciBvdmVybGF5ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoT1ZFUkxBWV9JRCk7XG4gIGlmIChvdmVybGF5KSB7XG4gICAgb3ZlcmxheS5yZW1vdmUoKTtcbiAgICBjb25zb2xlLmxvZygnW3BhcmNlbF0g4pyoIEVycm9yIHJlc29sdmVkJyk7XG4gIH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZUVycm9yT3ZlcmxheShkaWFnbm9zdGljcykge1xuICB2YXIgb3ZlcmxheSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBvdmVybGF5LmlkID0gT1ZFUkxBWV9JRDtcbiAgbGV0IGVycm9ySFRNTCA9ICc8ZGl2IHN0eWxlPVwiYmFja2dyb3VuZDogYmxhY2s7IG9wYWNpdHk6IDAuODU7IGZvbnQtc2l6ZTogMTZweDsgY29sb3I6IHdoaXRlOyBwb3NpdGlvbjogZml4ZWQ7IGhlaWdodDogMTAwJTsgd2lkdGg6IDEwMCU7IHRvcDogMHB4OyBsZWZ0OiAwcHg7IHBhZGRpbmc6IDMwcHg7IGZvbnQtZmFtaWx5OiBNZW5sbywgQ29uc29sYXMsIG1vbm9zcGFjZTsgei1pbmRleDogOTk5OTtcIj4nO1xuICBmb3IgKGxldCBkaWFnbm9zdGljIG9mIGRpYWdub3N0aWNzKSB7XG4gICAgbGV0IHN0YWNrID0gZGlhZ25vc3RpYy5mcmFtZXMubGVuZ3RoID8gZGlhZ25vc3RpYy5mcmFtZXMucmVkdWNlKChwLCBmcmFtZSkgPT4ge1xuICAgICAgcmV0dXJuIGAke3B9XG48YSBocmVmPVwiL19fcGFyY2VsX2xhdW5jaF9lZGl0b3I/ZmlsZT0ke2VuY29kZVVSSUNvbXBvbmVudChmcmFtZS5sb2NhdGlvbil9XCIgc3R5bGU9XCJ0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTsgY29sb3I6ICM4ODhcIiBvbmNsaWNrPVwiZmV0Y2godGhpcy5ocmVmKTsgcmV0dXJuIGZhbHNlXCI+JHtmcmFtZS5sb2NhdGlvbn08L2E+XG4ke2ZyYW1lLmNvZGV9YDtcbiAgICB9LCAnJykgOiBkaWFnbm9zdGljLnN0YWNrO1xuICAgIGVycm9ySFRNTCArPSBgXG4gICAgICA8ZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOiAxOHB4OyBmb250LXdlaWdodDogYm9sZDsgbWFyZ2luLXRvcDogMjBweDtcIj5cbiAgICAgICAgICDwn5qoICR7ZGlhZ25vc3RpYy5tZXNzYWdlfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHByZT4ke3N0YWNrfTwvcHJlPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICR7ZGlhZ25vc3RpYy5oaW50cy5tYXAoaGludCA9PiAnPGRpdj7wn5KhICcgKyBoaW50ICsgJzwvZGl2PicpLmpvaW4oJycpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgJHtkaWFnbm9zdGljLmRvY3VtZW50YXRpb24gPyBgPGRpdj7wn5OdIDxhIHN0eWxlPVwiY29sb3I6IHZpb2xldFwiIGhyZWY9XCIke2RpYWdub3N0aWMuZG9jdW1lbnRhdGlvbn1cIiB0YXJnZXQ9XCJfYmxhbmtcIj5MZWFybiBtb3JlPC9hPjwvZGl2PmAgOiAnJ31cbiAgICAgIDwvZGl2PlxuICAgIGA7XG4gIH1cbiAgZXJyb3JIVE1MICs9ICc8L2Rpdj4nO1xuICBvdmVybGF5LmlubmVySFRNTCA9IGVycm9ySFRNTDtcbiAgcmV0dXJuIG92ZXJsYXk7XG59XG5mdW5jdGlvbiBmdWxsUmVsb2FkKCkge1xuICBpZiAoJ3JlbG9hZCcgaW4gbG9jYXRpb24pIHtcbiAgICBsb2NhdGlvbi5yZWxvYWQoKTtcbiAgfSBlbHNlIGlmIChleHRDdHggJiYgZXh0Q3R4LnJ1bnRpbWUgJiYgZXh0Q3R4LnJ1bnRpbWUucmVsb2FkKSB7XG4gICAgZXh0Q3R4LnJ1bnRpbWUucmVsb2FkKCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFBhcmVudHMoYnVuZGxlLCBpZCkgLyo6IEFycmF5PFtQYXJjZWxSZXF1aXJlLCBzdHJpbmddPiAqL3tcbiAgdmFyIG1vZHVsZXMgPSBidW5kbGUubW9kdWxlcztcbiAgaWYgKCFtb2R1bGVzKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIHZhciBwYXJlbnRzID0gW107XG4gIHZhciBrLCBkLCBkZXA7XG4gIGZvciAoayBpbiBtb2R1bGVzKSB7XG4gICAgZm9yIChkIGluIG1vZHVsZXNba11bMV0pIHtcbiAgICAgIGRlcCA9IG1vZHVsZXNba11bMV1bZF07XG4gICAgICBpZiAoZGVwID09PSBpZCB8fCBBcnJheS5pc0FycmF5KGRlcCkgJiYgZGVwW2RlcC5sZW5ndGggLSAxXSA9PT0gaWQpIHtcbiAgICAgICAgcGFyZW50cy5wdXNoKFtidW5kbGUsIGtdKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGJ1bmRsZS5wYXJlbnQpIHtcbiAgICBwYXJlbnRzID0gcGFyZW50cy5jb25jYXQoZ2V0UGFyZW50cyhidW5kbGUucGFyZW50LCBpZCkpO1xuICB9XG4gIHJldHVybiBwYXJlbnRzO1xufVxuZnVuY3Rpb24gdXBkYXRlTGluayhsaW5rKSB7XG4gIHZhciBocmVmID0gbGluay5nZXRBdHRyaWJ1dGUoJ2hyZWYnKTtcbiAgaWYgKCFocmVmKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIHZhciBuZXdMaW5rID0gbGluay5jbG9uZU5vZGUoKTtcbiAgbmV3TGluay5vbmxvYWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKGxpbmsucGFyZW50Tm9kZSAhPT0gbnVsbCkge1xuICAgICAgLy8gJEZsb3dGaXhNZVxuICAgICAgbGluay5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGxpbmspO1xuICAgIH1cbiAgfTtcbiAgbmV3TGluay5zZXRBdHRyaWJ1dGUoJ2hyZWYnLFxuICAvLyAkRmxvd0ZpeE1lXG4gIGhyZWYuc3BsaXQoJz8nKVswXSArICc/JyArIERhdGUubm93KCkpO1xuICAvLyAkRmxvd0ZpeE1lXG4gIGxpbmsucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUobmV3TGluaywgbGluay5uZXh0U2libGluZyk7XG59XG52YXIgY3NzVGltZW91dCA9IG51bGw7XG5mdW5jdGlvbiByZWxvYWRDU1MoKSB7XG4gIGlmIChjc3NUaW1lb3V0KSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNzc1RpbWVvdXQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgbGlua3MgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdsaW5rW3JlbD1cInN0eWxlc2hlZXRcIl0nKTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxpbmtzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAvLyAkRmxvd0ZpeE1lW2luY29tcGF0aWJsZS10eXBlXVxuICAgICAgdmFyIGhyZWYgLyo6IHN0cmluZyAqLyA9IGxpbmtzW2ldLmdldEF0dHJpYnV0ZSgnaHJlZicpO1xuICAgICAgdmFyIGhvc3RuYW1lID0gZ2V0SG9zdG5hbWUoKTtcbiAgICAgIHZhciBzZXJ2ZWRGcm9tSE1SU2VydmVyID0gaG9zdG5hbWUgPT09ICdsb2NhbGhvc3QnID8gbmV3IFJlZ0V4cCgnXihodHRwcz86XFxcXC9cXFxcLygwLjAuMC4wfDEyNy4wLjAuMSl8bG9jYWxob3N0KTonICsgZ2V0UG9ydCgpKS50ZXN0KGhyZWYpIDogaHJlZi5pbmRleE9mKGhvc3RuYW1lICsgJzonICsgZ2V0UG9ydCgpKTtcbiAgICAgIHZhciBhYnNvbHV0ZSA9IC9eaHR0cHM/OlxcL1xcLy9pLnRlc3QoaHJlZikgJiYgaHJlZi5pbmRleE9mKGxvY2F0aW9uLm9yaWdpbikgIT09IDAgJiYgIXNlcnZlZEZyb21ITVJTZXJ2ZXI7XG4gICAgICBpZiAoIWFic29sdXRlKSB7XG4gICAgICAgIHVwZGF0ZUxpbmsobGlua3NbaV0pO1xuICAgICAgfVxuICAgIH1cbiAgICBjc3NUaW1lb3V0ID0gbnVsbDtcbiAgfSwgNTApO1xufVxuZnVuY3Rpb24gaG1yRG93bmxvYWQoYXNzZXQpIHtcbiAgaWYgKGFzc2V0LnR5cGUgPT09ICdqcycpIHtcbiAgICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgbGV0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgICAgc2NyaXB0LnNyYyA9IGFzc2V0LnVybCArICc/dD0nICsgRGF0ZS5ub3coKTtcbiAgICAgIGlmIChhc3NldC5vdXRwdXRGb3JtYXQgPT09ICdlc21vZHVsZScpIHtcbiAgICAgICAgc2NyaXB0LnR5cGUgPSAnbW9kdWxlJztcbiAgICAgIH1cbiAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIHZhciBfZG9jdW1lbnQkaGVhZDtcbiAgICAgICAgc2NyaXB0Lm9ubG9hZCA9ICgpID0+IHJlc29sdmUoc2NyaXB0KTtcbiAgICAgICAgc2NyaXB0Lm9uZXJyb3IgPSByZWplY3Q7XG4gICAgICAgIChfZG9jdW1lbnQkaGVhZCA9IGRvY3VtZW50LmhlYWQpID09PSBudWxsIHx8IF9kb2N1bWVudCRoZWFkID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZG9jdW1lbnQkaGVhZC5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgaW1wb3J0U2NyaXB0cyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgLy8gV29ya2VyIHNjcmlwdHNcbiAgICAgIGlmIChhc3NldC5vdXRwdXRGb3JtYXQgPT09ICdlc21vZHVsZScpIHtcbiAgICAgICAgcmV0dXJuIF9fcGFyY2VsX19pbXBvcnRfXyhhc3NldC51cmwgKyAnP3Q9JyArIERhdGUubm93KCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgX19wYXJjZWxfX2ltcG9ydFNjcmlwdHNfXyhhc3NldC51cmwgKyAnP3Q9JyArIERhdGUubm93KCkpO1xuICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmFzeW5jIGZ1bmN0aW9uIGhtckFwcGx5VXBkYXRlcyhhc3NldHMpIHtcbiAgZ2xvYmFsLnBhcmNlbEhvdFVwZGF0ZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGxldCBzY3JpcHRzVG9SZW1vdmU7XG4gIHRyeSB7XG4gICAgLy8gSWYgc291cmNlVVJMIGNvbW1lbnRzIGFyZW4ndCBzdXBwb3J0ZWQgaW4gZXZhbCwgd2UgbmVlZCB0byBsb2FkXG4gICAgLy8gdGhlIHVwZGF0ZSBmcm9tIHRoZSBkZXYgc2VydmVyIG92ZXIgSFRUUCBzbyB0aGF0IHN0YWNrIHRyYWNlc1xuICAgIC8vIGFyZSBjb3JyZWN0IGluIGVycm9ycy9sb2dzLiBUaGlzIGlzIG11Y2ggc2xvd2VyIHRoYW4gZXZhbCwgc29cbiAgICAvLyB3ZSBvbmx5IGRvIGl0IGlmIG5lZWRlZCAoY3VycmVudGx5IGp1c3QgU2FmYXJpKS5cbiAgICAvLyBodHRwczovL2J1Z3Mud2Via2l0Lm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MTM3Mjk3XG4gICAgLy8gVGhpcyBwYXRoIGlzIGFsc28gdGFrZW4gaWYgYSBDU1AgZGlzYWxsb3dzIGV2YWwuXG4gICAgaWYgKCFzdXBwb3J0c1NvdXJjZVVSTCkge1xuICAgICAgbGV0IHByb21pc2VzID0gYXNzZXRzLm1hcChhc3NldCA9PiB7XG4gICAgICAgIHZhciBfaG1yRG93bmxvYWQ7XG4gICAgICAgIHJldHVybiAoX2htckRvd25sb2FkID0gaG1yRG93bmxvYWQoYXNzZXQpKSA9PT0gbnVsbCB8fCBfaG1yRG93bmxvYWQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9obXJEb3dubG9hZC5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgIC8vIFdlYiBleHRlbnNpb24gYnVnZml4IGZvciBDaHJvbWl1bVxuICAgICAgICAgIC8vIGh0dHBzOi8vYnVncy5jaHJvbWl1bS5vcmcvcC9jaHJvbWl1bS9pc3N1ZXMvZGV0YWlsP2lkPTEyNTU0MTIjYzEyXG4gICAgICAgICAgaWYgKGV4dEN0eCAmJiBleHRDdHgucnVudGltZSAmJiBleHRDdHgucnVudGltZS5nZXRNYW5pZmVzdCgpLm1hbmlmZXN0X3ZlcnNpb24gPT0gMykge1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBTZXJ2aWNlV29ya2VyR2xvYmFsU2NvcGUgIT0gJ3VuZGVmaW5lZCcgJiYgZ2xvYmFsIGluc3RhbmNlb2YgU2VydmljZVdvcmtlckdsb2JhbFNjb3BlKSB7XG4gICAgICAgICAgICAgIGV4dEN0eC5ydW50aW1lLnJlbG9hZCgpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhc3NldC51cmwgPSBleHRDdHgucnVudGltZS5nZXRVUkwoJy9fX3BhcmNlbF9obXJfcHJveHlfXz91cmw9JyArIGVuY29kZVVSSUNvbXBvbmVudChhc3NldC51cmwgKyAnP3Q9JyArIERhdGUubm93KCkpKTtcbiAgICAgICAgICAgIHJldHVybiBobXJEb3dubG9hZChhc3NldCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICAgIHNjcmlwdHNUb1JlbW92ZSA9IGF3YWl0IFByb21pc2UuYWxsKHByb21pc2VzKTtcbiAgICB9XG4gICAgYXNzZXRzLmZvckVhY2goZnVuY3Rpb24gKGFzc2V0KSB7XG4gICAgICBobXJBcHBseShtb2R1bGUuYnVuZGxlLnJvb3QsIGFzc2V0KTtcbiAgICB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBkZWxldGUgZ2xvYmFsLnBhcmNlbEhvdFVwZGF0ZTtcbiAgICBpZiAoc2NyaXB0c1RvUmVtb3ZlKSB7XG4gICAgICBzY3JpcHRzVG9SZW1vdmUuZm9yRWFjaChzY3JpcHQgPT4ge1xuICAgICAgICBpZiAoc2NyaXB0KSB7XG4gICAgICAgICAgdmFyIF9kb2N1bWVudCRoZWFkMjtcbiAgICAgICAgICAoX2RvY3VtZW50JGhlYWQyID0gZG9jdW1lbnQuaGVhZCkgPT09IG51bGwgfHwgX2RvY3VtZW50JGhlYWQyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZG9jdW1lbnQkaGVhZDIucmVtb3ZlQ2hpbGQoc2NyaXB0KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBobXJBcHBseShidW5kbGUgLyo6IFBhcmNlbFJlcXVpcmUgKi8sIGFzc2V0IC8qOiAgSE1SQXNzZXQgKi8pIHtcbiAgdmFyIG1vZHVsZXMgPSBidW5kbGUubW9kdWxlcztcbiAgaWYgKCFtb2R1bGVzKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChhc3NldC50eXBlID09PSAnY3NzJykge1xuICAgIHJlbG9hZENTUygpO1xuICB9IGVsc2UgaWYgKGFzc2V0LnR5cGUgPT09ICdqcycpIHtcbiAgICBsZXQgZGVwcyA9IGFzc2V0LmRlcHNCeUJ1bmRsZVtidW5kbGUuSE1SX0JVTkRMRV9JRF07XG4gICAgaWYgKGRlcHMpIHtcbiAgICAgIGlmIChtb2R1bGVzW2Fzc2V0LmlkXSkge1xuICAgICAgICAvLyBSZW1vdmUgZGVwZW5kZW5jaWVzIHRoYXQgYXJlIHJlbW92ZWQgYW5kIHdpbGwgYmVjb21lIG9ycGhhbmVkLlxuICAgICAgICAvLyBUaGlzIGlzIG5lY2Vzc2FyeSBzbyB0aGF0IGlmIHRoZSBhc3NldCBpcyBhZGRlZCBiYWNrIGFnYWluLCB0aGUgY2FjaGUgaXMgZ29uZSwgYW5kIHdlIHByZXZlbnQgYSBmdWxsIHBhZ2UgcmVsb2FkLlxuICAgICAgICBsZXQgb2xkRGVwcyA9IG1vZHVsZXNbYXNzZXQuaWRdWzFdO1xuICAgICAgICBmb3IgKGxldCBkZXAgaW4gb2xkRGVwcykge1xuICAgICAgICAgIGlmICghZGVwc1tkZXBdIHx8IGRlcHNbZGVwXSAhPT0gb2xkRGVwc1tkZXBdKSB7XG4gICAgICAgICAgICBsZXQgaWQgPSBvbGREZXBzW2RlcF07XG4gICAgICAgICAgICBsZXQgcGFyZW50cyA9IGdldFBhcmVudHMobW9kdWxlLmJ1bmRsZS5yb290LCBpZCk7XG4gICAgICAgICAgICBpZiAocGFyZW50cy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICAgICAgaG1yRGVsZXRlKG1vZHVsZS5idW5kbGUucm9vdCwgaWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHN1cHBvcnRzU291cmNlVVJMKSB7XG4gICAgICAgIC8vIEdsb2JhbCBldmFsLiBXZSB3b3VsZCB1c2UgYG5ldyBGdW5jdGlvbmAgaGVyZSBidXQgYnJvd3NlclxuICAgICAgICAvLyBzdXBwb3J0IGZvciBzb3VyY2UgbWFwcyBpcyBiZXR0ZXIgd2l0aCBldmFsLlxuICAgICAgICAoMCwgZXZhbCkoYXNzZXQub3V0cHV0KTtcbiAgICAgIH1cblxuICAgICAgLy8gJEZsb3dGaXhNZVxuICAgICAgbGV0IGZuID0gZ2xvYmFsLnBhcmNlbEhvdFVwZGF0ZVthc3NldC5pZF07XG4gICAgICBtb2R1bGVzW2Fzc2V0LmlkXSA9IFtmbiwgZGVwc107XG4gICAgfSBlbHNlIGlmIChidW5kbGUucGFyZW50KSB7XG4gICAgICBobXJBcHBseShidW5kbGUucGFyZW50LCBhc3NldCk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBobXJEZWxldGUoYnVuZGxlLCBpZCkge1xuICBsZXQgbW9kdWxlcyA9IGJ1bmRsZS5tb2R1bGVzO1xuICBpZiAoIW1vZHVsZXMpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKG1vZHVsZXNbaWRdKSB7XG4gICAgLy8gQ29sbGVjdCBkZXBlbmRlbmNpZXMgdGhhdCB3aWxsIGJlY29tZSBvcnBoYW5lZCB3aGVuIHRoaXMgbW9kdWxlIGlzIGRlbGV0ZWQuXG4gICAgbGV0IGRlcHMgPSBtb2R1bGVzW2lkXVsxXTtcbiAgICBsZXQgb3JwaGFucyA9IFtdO1xuICAgIGZvciAobGV0IGRlcCBpbiBkZXBzKSB7XG4gICAgICBsZXQgcGFyZW50cyA9IGdldFBhcmVudHMobW9kdWxlLmJ1bmRsZS5yb290LCBkZXBzW2RlcF0pO1xuICAgICAgaWYgKHBhcmVudHMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIG9ycGhhbnMucHVzaChkZXBzW2RlcF0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIERlbGV0ZSB0aGUgbW9kdWxlLiBUaGlzIG11c3QgYmUgZG9uZSBiZWZvcmUgZGVsZXRpbmcgZGVwZW5kZW5jaWVzIGluIGNhc2Ugb2YgY2lyY3VsYXIgZGVwZW5kZW5jaWVzLlxuICAgIGRlbGV0ZSBtb2R1bGVzW2lkXTtcbiAgICBkZWxldGUgYnVuZGxlLmNhY2hlW2lkXTtcblxuICAgIC8vIE5vdyBkZWxldGUgdGhlIG9ycGhhbnMuXG4gICAgb3JwaGFucy5mb3JFYWNoKGlkID0+IHtcbiAgICAgIGhtckRlbGV0ZShtb2R1bGUuYnVuZGxlLnJvb3QsIGlkKTtcbiAgICB9KTtcbiAgfSBlbHNlIGlmIChidW5kbGUucGFyZW50KSB7XG4gICAgaG1yRGVsZXRlKGJ1bmRsZS5wYXJlbnQsIGlkKTtcbiAgfVxufVxuZnVuY3Rpb24gaG1yQWNjZXB0Q2hlY2soYnVuZGxlIC8qOiBQYXJjZWxSZXF1aXJlICovLCBpZCAvKjogc3RyaW5nICovLCBkZXBzQnlCdW5kbGUgLyo6ID97IFtzdHJpbmddOiB7IFtzdHJpbmddOiBzdHJpbmcgfSB9Ki8pIHtcbiAgaWYgKGhtckFjY2VwdENoZWNrT25lKGJ1bmRsZSwgaWQsIGRlcHNCeUJ1bmRsZSkpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIC8vIFRyYXZlcnNlIHBhcmVudHMgYnJlYWR0aCBmaXJzdC4gQWxsIHBvc3NpYmxlIGFuY2VzdHJpZXMgbXVzdCBhY2NlcHQgdGhlIEhNUiB1cGRhdGUsIG9yIHdlJ2xsIHJlbG9hZC5cbiAgbGV0IHBhcmVudHMgPSBnZXRQYXJlbnRzKG1vZHVsZS5idW5kbGUucm9vdCwgaWQpO1xuICBsZXQgYWNjZXB0ZWQgPSBmYWxzZTtcbiAgd2hpbGUgKHBhcmVudHMubGVuZ3RoID4gMCkge1xuICAgIGxldCB2ID0gcGFyZW50cy5zaGlmdCgpO1xuICAgIGxldCBhID0gaG1yQWNjZXB0Q2hlY2tPbmUodlswXSwgdlsxXSwgbnVsbCk7XG4gICAgaWYgKGEpIHtcbiAgICAgIC8vIElmIHRoaXMgcGFyZW50IGFjY2VwdHMsIHN0b3AgdHJhdmVyc2luZyB1cHdhcmQsIGJ1dCBzdGlsbCBjb25zaWRlciBzaWJsaW5ncy5cbiAgICAgIGFjY2VwdGVkID0gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gT3RoZXJ3aXNlLCBxdWV1ZSB0aGUgcGFyZW50cyBpbiB0aGUgbmV4dCBsZXZlbCB1cHdhcmQuXG4gICAgICBsZXQgcCA9IGdldFBhcmVudHMobW9kdWxlLmJ1bmRsZS5yb290LCB2WzFdKTtcbiAgICAgIGlmIChwLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAvLyBJZiB0aGVyZSBhcmUgbm8gcGFyZW50cywgdGhlbiB3ZSd2ZSByZWFjaGVkIGFuIGVudHJ5IHdpdGhvdXQgYWNjZXB0aW5nLiBSZWxvYWQuXG4gICAgICAgIGFjY2VwdGVkID0gZmFsc2U7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgcGFyZW50cy5wdXNoKC4uLnApO1xuICAgIH1cbiAgfVxuICByZXR1cm4gYWNjZXB0ZWQ7XG59XG5mdW5jdGlvbiBobXJBY2NlcHRDaGVja09uZShidW5kbGUgLyo6IFBhcmNlbFJlcXVpcmUgKi8sIGlkIC8qOiBzdHJpbmcgKi8sIGRlcHNCeUJ1bmRsZSAvKjogP3sgW3N0cmluZ106IHsgW3N0cmluZ106IHN0cmluZyB9IH0qLykge1xuICB2YXIgbW9kdWxlcyA9IGJ1bmRsZS5tb2R1bGVzO1xuICBpZiAoIW1vZHVsZXMpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGRlcHNCeUJ1bmRsZSAmJiAhZGVwc0J5QnVuZGxlW2J1bmRsZS5ITVJfQlVORExFX0lEXSkge1xuICAgIC8vIElmIHdlIHJlYWNoZWQgdGhlIHJvb3QgYnVuZGxlIHdpdGhvdXQgZmluZGluZyB3aGVyZSB0aGUgYXNzZXQgc2hvdWxkIGdvLFxuICAgIC8vIHRoZXJlJ3Mgbm90aGluZyB0byBkby4gTWFyayBhcyBcImFjY2VwdGVkXCIgc28gd2UgZG9uJ3QgcmVsb2FkIHRoZSBwYWdlLlxuICAgIGlmICghYnVuZGxlLnBhcmVudCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBobXJBY2NlcHRDaGVjayhidW5kbGUucGFyZW50LCBpZCwgZGVwc0J5QnVuZGxlKTtcbiAgfVxuICBpZiAoY2hlY2tlZEFzc2V0c1tpZF0pIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBjaGVja2VkQXNzZXRzW2lkXSA9IHRydWU7XG4gIHZhciBjYWNoZWQgPSBidW5kbGUuY2FjaGVbaWRdO1xuICBhc3NldHNUb0Rpc3Bvc2UucHVzaChbYnVuZGxlLCBpZF0pO1xuICBpZiAoIWNhY2hlZCB8fCBjYWNoZWQuaG90ICYmIGNhY2hlZC5ob3QuX2FjY2VwdENhbGxiYWNrcy5sZW5ndGgpIHtcbiAgICBhc3NldHNUb0FjY2VwdC5wdXNoKFtidW5kbGUsIGlkXSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbn1cbmZ1bmN0aW9uIGhtckRpc3Bvc2UoYnVuZGxlIC8qOiBQYXJjZWxSZXF1aXJlICovLCBpZCAvKjogc3RyaW5nICovKSB7XG4gIHZhciBjYWNoZWQgPSBidW5kbGUuY2FjaGVbaWRdO1xuICBidW5kbGUuaG90RGF0YVtpZF0gPSB7fTtcbiAgaWYgKGNhY2hlZCAmJiBjYWNoZWQuaG90KSB7XG4gICAgY2FjaGVkLmhvdC5kYXRhID0gYnVuZGxlLmhvdERhdGFbaWRdO1xuICB9XG4gIGlmIChjYWNoZWQgJiYgY2FjaGVkLmhvdCAmJiBjYWNoZWQuaG90Ll9kaXNwb3NlQ2FsbGJhY2tzLmxlbmd0aCkge1xuICAgIGNhY2hlZC5ob3QuX2Rpc3Bvc2VDYWxsYmFja3MuZm9yRWFjaChmdW5jdGlvbiAoY2IpIHtcbiAgICAgIGNiKGJ1bmRsZS5ob3REYXRhW2lkXSk7XG4gICAgfSk7XG4gIH1cbiAgZGVsZXRlIGJ1bmRsZS5jYWNoZVtpZF07XG59XG5mdW5jdGlvbiBobXJBY2NlcHQoYnVuZGxlIC8qOiBQYXJjZWxSZXF1aXJlICovLCBpZCAvKjogc3RyaW5nICovKSB7XG4gIC8vIEV4ZWN1dGUgdGhlIG1vZHVsZS5cbiAgYnVuZGxlKGlkKTtcblxuICAvLyBSdW4gdGhlIGFjY2VwdCBjYWxsYmFja3MgaW4gdGhlIG5ldyB2ZXJzaW9uIG9mIHRoZSBtb2R1bGUuXG4gIHZhciBjYWNoZWQgPSBidW5kbGUuY2FjaGVbaWRdO1xuICBpZiAoY2FjaGVkICYmIGNhY2hlZC5ob3QgJiYgY2FjaGVkLmhvdC5fYWNjZXB0Q2FsbGJhY2tzLmxlbmd0aCkge1xuICAgIGNhY2hlZC5ob3QuX2FjY2VwdENhbGxiYWNrcy5mb3JFYWNoKGZ1bmN0aW9uIChjYikge1xuICAgICAgdmFyIGFzc2V0c1RvQWxzb0FjY2VwdCA9IGNiKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIGdldFBhcmVudHMobW9kdWxlLmJ1bmRsZS5yb290LCBpZCk7XG4gICAgICB9KTtcbiAgICAgIGlmIChhc3NldHNUb0Fsc29BY2NlcHQgJiYgYXNzZXRzVG9BY2NlcHQubGVuZ3RoKSB7XG4gICAgICAgIGFzc2V0c1RvQWxzb0FjY2VwdC5mb3JFYWNoKGZ1bmN0aW9uIChhKSB7XG4gICAgICAgICAgaG1yRGlzcG9zZShhWzBdLCBhWzFdKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gJEZsb3dGaXhNZVttZXRob2QtdW5iaW5kaW5nXVxuICAgICAgICBhc3NldHNUb0FjY2VwdC5wdXNoLmFwcGx5KGFzc2V0c1RvQWNjZXB0LCBhc3NldHNUb0Fsc29BY2NlcHQpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59IiwiLy8gQXJyYXkgdG8gc3RvcmUgdGhlIGV4Y2x1ZGVkIFVSTHNcbmxldCBleGNsdWRlZFVybHM6IHN0cmluZ1tdID0gW11cblxuLy8gVGhlIG1hcCB0byBzdG9yZSB1bmlxdWUgVVJMc1xubGV0IHVybE1hcCA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KClcblxuY2hyb21lLnRhYnMub25VcGRhdGVkLmFkZExpc3RlbmVyKGFzeW5jICh0YWJJZCwgaW5mbywgdGFiKSA9PiB7XG4gIC8vIEFsbG93IHVzZXJzIHRvIG9wZW4gdGhlIHNpZGViYXIgYnkgY2xpY2tpbmcgb24gdGhlIGFjdGlvbiB0b29sYmFyIGljb25cbiAgY2hyb21lLnNpZGVQYW5lbFxuICAgIC5zZXRQYW5lbEJlaGF2aW9yKHtvcGVuUGFuZWxPbkFjdGlvbkNsaWNrOiB0cnVlfSlcbiAgICAuY2F0Y2goKGVycm9yKSA9PiBjb25zb2xlLmVycm9yKGVycm9yKSlcbn0pXG5cbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigocmVxdWVzdCwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgc3dpdGNoIChyZXF1ZXN0LmNvbW1hbmQpIHtcbiAgICBjYXNlICdzdGFydENhcHR1cmUnOlxuICAgICAgLy8gR2V0IHRoZSBleGNsdWRlZCBVUkxzIGZyb20gdGhlIHJlcXVlc3RcbiAgICAgIGV4Y2x1ZGVkVXJscyA9IHJlcXVlc3QuZXhjbHVkZWRVcmxzIHx8IFtdXG4gICAgICB1cmxNYXAuY2xlYXIoKVxuICAgICAgLy8gU3RhcnQgdGhlIHdlYlJlcXVlc3QgbGlzdGVuZXJcbiAgICAgIGNocm9tZS53ZWJSZXF1ZXN0Lm9uQmVmb3JlUmVxdWVzdC5hZGRMaXN0ZW5lcihcbiAgICAgICAgbGlzdGVuZXIsXG4gICAgICAgIHt1cmxzOiBbJzxhbGxfdXJscz4nXX0sXG4gICAgICAgIFsncmVxdWVzdEJvZHknXVxuICAgICAgKVxuICAgICAgYnJlYWtcbiAgICBjYXNlICdzdG9wQ2FwdHVyZSc6XG4gICAgICAvLyBTdG9wIHRoZSB3ZWJSZXF1ZXN0IGxpc3RlbmVyXG4gICAgICBjaHJvbWUud2ViUmVxdWVzdC5vbkJlZm9yZVJlcXVlc3QucmVtb3ZlTGlzdGVuZXIobGlzdGVuZXIpXG4gICAgICBicmVha1xuICAgIGNhc2UgJ2dldFVybHMnOlxuICAgICAgLy8gUmV0dXJuIHRoZSBVUkwgc2V0IHdoZW4gcmVxdWVzdGVkXG4gICAgICBzZW5kUmVzcG9uc2UoQXJyYXkuZnJvbSh1cmxNYXApKVxuICAgICAgYnJlYWtcbiAgfVxuICByZXR1cm4gdHJ1ZSAvLyBUaGlzIGlzIHJlcXVpcmVkIHRvIGluZGljYXRlIHRoYXQgeW91IHdpbGwgc2VuZCBhIHJlc3BvbnNlIGFzeW5jaHJvbm91c2x5XG59KVxuXG5mdW5jdGlvbiBsaXN0ZW5lcihkZXRhaWxzOiBjaHJvbWUud2ViUmVxdWVzdC5XZWJSZXF1ZXN0Qm9keURldGFpbHMpIHtcbiAgdHJ5IHtcbiAgICAvLyBQYXJzZSB0aGUgVVJMIGFuZCBnZXQgdGhlIHBhdGhuYW1lICsgbWV0aG9kXG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChkZXRhaWxzLnVybClcbiAgICBjb25zdCBwYXRobmFtZSA9IHVybC5wYXRobmFtZVxuICAgIGNvbnN0IGhvc3RuYW1lID0gYCR7dXJsLnByb3RvY29sfS8vJHt1cmwuaG9zdG5hbWV9OiR7dXJsLnBvcnR9YFxuICAgIGNvbnN0IHttZXRob2R9ID0gZGV0YWlsc1xuXG4gICAgLy8gQ2hlY2sgaWYgdGhlIHBhdGhuYW1lIG1hdGNoZXMgYW55IG9mIHRoZSBleGNsdWRlZCBwYXR0ZXJuc1xuICAgIC8vIEFsc28gY2hlY2sgaWYgdGhlIHBhdHRlcm4gaXMgbm90IGFuIGVtcHR5IHN0cmluZ1xuICAgIGlmIChcbiAgICAgICFkZXRhaWxzLnVybC5pbmNsdWRlcygnJGJhdGNoJykgJiZcbiAgICAgICFleGNsdWRlZFVybHMuc29tZSgocGF0dGVybikgPT4gcGF0dGVybiAmJiBwYXRobmFtZS5pbmNsdWRlcyhwYXR0ZXJuKSkgJiZcbiAgICAgICF1cmxNYXAuaGFzKHBhdGhuYW1lKVxuICAgICkge1xuICAgICAgLy8gQWRkIHRoZSBwYXRobmFtZSBhbmQgbWV0aG9kIHRvIHRoZSBtYXBcbiAgICAgIHVybE1hcC5zZXQocGF0aG5hbWUsIG1ldGhvZClcblxuICAgICAgLy8gU2VuZCBhIG1lc3NhZ2UgdG8gdGhlIHNpZGUgcGFuZWwgd2l0aCB0aGUgbmV3IFVSTFxuICAgICAgc2VuZE1lc3NhZ2UoJ25ld1VybCcsIHBhdGhuYW1lLCBob3N0bmFtZSwgbWV0aG9kKVxuICAgIH1cblxuICAgIGlmIChcbiAgICAgIGRldGFpbHMudXJsLmluY2x1ZGVzKCckYmF0Y2gnKSAmJlxuICAgICAgZGV0YWlscy5yZXF1ZXN0Qm9keSAmJlxuICAgICAgZGV0YWlscy5yZXF1ZXN0Qm9keS5yYXdcbiAgICApIHtcbiAgICAgIC8vIEZpcnN0IHNob3cgdGhlIEJhdGNoIHJlcXVlc3RcbiAgICAgIC8vIFNlbmQgYSBtZXNzYWdlIHRvIHRoZSBzaWRlIHBhbmVsIHdpdGggdGhlIG5ldyBVUkxcbiAgICAgIHNlbmRNZXNzYWdlKCduZXdVcmwnLCBwYXRobmFtZSwgaG9zdG5hbWUsIG1ldGhvZClcblxuICAgICAgY29uc3QgYmFzZVBhdGggPSBwYXRobmFtZS5zcGxpdCgnJGJhdGNoJylbMF1cblxuICAgICAgLy8gRmV0Y2hpbmcgdGhlIHJlcXVlc3QgcGF5bG9hZFxuICAgICAgbGV0IGRlY29kZXIgPSBuZXcgVGV4dERlY29kZXIoJ3V0Zi04JylcbiAgICAgIGxldCBwYXlsb2FkID0gZGVjb2Rlci5kZWNvZGUoZGV0YWlscy5yZXF1ZXN0Qm9keS5yYXdbMF0uYnl0ZXMpXG5cbiAgICAgIC8vIFNwbGl0dGluZyB0aGUgcGF5bG9hZCBpbnRvIHNlcGFyYXRlIGxpbmVzXG4gICAgICBjb25zdCBsaW5lcyA9IHBheWxvYWQuc3BsaXQoJ1xcclxcbicpXG5cbiAgICAgIC8vIEZpbHRlciBvdXQgbGluZXMgdGhhdCBzdGFydCB3aXRoIEhUVFAgbWV0aG9kc1xuICAgICAgY29uc3QgcmVxdWVzdHMgPSBsaW5lcy5maWx0ZXIoKGxpbmUpID0+XG4gICAgICAgIFsnR0VUJywgJ1BPU1QnLCAnUFVUJywgJ0RFTEVURSddLnNvbWUoKGFueU1ldGhvZCkgPT5cbiAgICAgICAgICBsaW5lLnN0YXJ0c1dpdGgoYW55TWV0aG9kKVxuICAgICAgICApXG4gICAgICApXG5cbiAgICAgIHJlcXVlc3RzLmZvckVhY2goKHJlcXVlc3QsIGluZGV4KSA9PiB7XG4gICAgICAgIC8vIEV4dHJhY3QgdGhlIG1ldGhvZCwgdXJsIGFuZCBvdGhlciByZWxldmFudCBwYXJ0cyBmcm9tIHRoZSByZXF1ZXN0XG4gICAgICAgIGNvbnN0IFttZXRob2QsIHBhdGhdID0gcmVxdWVzdC50cmltKCkuc3BsaXQoJyAnKVxuICAgICAgICBjb25zdCB1cmwgPSBiYXNlUGF0aCArIHBhdGhcblxuICAgICAgICAvLyBDaGVjayBpZiB0aGUgVVJMIGlzIG5vdCBpbiB0aGUgZXhjbHVkZWQgVVJMcyBsaXN0XG4gICAgICAgIGlmICghZXhjbHVkZWRVcmxzLnNvbWUoKHBhdHRlcm4pID0+IHVybC5pbmNsdWRlcyhwYXR0ZXJuKSkpIHtcbiAgICAgICAgICAvLyBTZW5kIGEgbWVzc2FnZSB0byB0aGUgc2lkZSBwYW5lbCB3aXRoIHRoZSBuZXcgVVJMXG4gICAgICAgICAgc2VuZE1lc3NhZ2UoJ25ld1VybCcsIHVybCwgaG9zdG5hbWUsIG1ldGhvZCwgdHJ1ZSlcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihlcnJvcilcbiAgfVxufVxuXG5mdW5jdGlvbiBzZW5kTWVzc2FnZShcbiAgY29tbWFuZDogc3RyaW5nLFxuICB1cmw6IHN0cmluZyxcbiAgaG9zdG5hbWU6IHN0cmluZyxcbiAgbWV0aG9kOiBzdHJpbmcsXG4gIGJhdGNoPzogYm9vbGVhblxuKSB7XG4gIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHtjb21tYW5kLCB1cmwsIGhvc3RuYW1lLCBtZXRob2QsIGJhdGNofSlcbn1cbiJdLCJuYW1lcyI6W10sInZlcnNpb24iOjMsImZpbGUiOiJzZXJ2aWNlLXdvcmtlci45ZjNhZTY0Yi5qcy5tYXAifQ==
