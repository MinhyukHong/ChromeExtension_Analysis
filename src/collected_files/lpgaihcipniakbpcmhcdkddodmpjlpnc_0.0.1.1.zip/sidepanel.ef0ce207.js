document.addEventListener("DOMContentLoaded", ()=>{
    // Get references to the button and the URL container
    const toggleCaptureButton = document.getElementById("toggleCapture");
    const urlContainer = document.getElementById("urlContainer");
    const clearCaptureButton = document.getElementById("clearCapture");
    // Check if the elements exist in the DOM
    if (!toggleCaptureButton || !urlContainer || !clearCaptureButton) {
        console.error("Required elements are not found in the DOM");
        return;
    }
    // Known templates
    const templates = {
        fiori: {
            excludedUrls: [
                "/sap/opu/odata/UI2/INTEROP/",
                "/sap/bc/ui5_ui5/ui2/ushell/resources/",
                "/sap/bc/ui2/flp"
            ],
            includedUrls: [
                "/odata/"
            ]
        }
    };
    document.getElementById("templates")?.addEventListener("change", function() {
        if (this.value && templates[this.value]) {
            let template = templates[this.value];
            document.getElementById("excludedUrls").value = template.excludedUrls.join("\n");
            document.getElementById("includedUrls").value = template.includedUrls.join("\n");
        }
    });
    document.getElementById("loadTemplate")?.addEventListener("change", function() {
        if (this.files && this.files.length > 0) {
            let fileReader = new FileReader();
            fileReader.onload = function(event) {
                let template = JSON.parse(event.target?.result);
                document.getElementById("excludedUrls").value = template.excludedUrls.join("\n");
                document.getElementById("includedUrls").value = template.includedUrls.join("\n");
            };
            fileReader.readAsText(this.files[0]);
        }
    });
    document.getElementById("saveTemplate")?.addEventListener("click", function() {
        let template = {
            excludedUrls: document.getElementById("excludedUrls").value.split("\n"),
            includedUrls: document.getElementById("includedUrls").value.split("\n")
        };
        let blob = new Blob([
            JSON.stringify(template)
        ], {
            type: "application/json"
        });
        let url = URL.createObjectURL(blob);
        let a = document.createElement("a");
        a.href = url;
        a.download = "template.json";
        a.click();
    });
    clearCaptureButton.addEventListener("click", ()=>{
        // Empty the URL container
        urlContainer.innerHTML = "";
        // Reset the isCapturing flag
        isCapturing = false;
        // Reset the toggle capture button text
        toggleCaptureButton.innerText = "Start Capture";
        // Send a command to background.ts to stop capturing
        chrome.runtime.sendMessage({
            command: "stopCapture"
        });
    });
    // A flag to indicate whether we're capturing or not
    let isCapturing = false;
    // The current capture cycle details and list
    let currentDetails = null;
    let currentList = null;
    // Event listener for the button click
    toggleCaptureButton.addEventListener("click", ()=>{
        // Toggle the isCapturing flag
        isCapturing = !isCapturing;
        // Get the excluded URLs from the text area
        const excludedUrlsTextArea = document.getElementById("excludedUrls");
        const includedUrlsTextArea = document.getElementById("includedUrls");
        // Get the excluded URLs and included URLs from the text area, filter out empty strings
        const excludedUrls = excludedUrlsTextArea.value.split("\n").filter((url)=>url.trim() !== "");
        const includedUrls = includedUrlsTextArea.value.split("\n").filter((url)=>url.trim() !== "");
        // Send a command to background.ts to start/stop capturing
        chrome.runtime.sendMessage({
            command: isCapturing ? "startCapture" : "stopCapture",
            excludedUrls: excludedUrls,
            includedUrls: includedUrls
        });
        // Update the button text
        toggleCaptureButton.innerText = isCapturing ? "Stop Capture" : "Start Capture";
        // Create new capture cycle details and list when we start capturing
        if (isCapturing) {
            currentDetails = document.createElement("details");
            currentDetails.open = true // this line ensures the details are open by default
            ;
            const summary = document.createElement("summary");
            summary.textContent = `Capture Cycle ${urlContainer.children.length + 1}`;
            currentList = document.createElement("ul");
            currentDetails.appendChild(summary);
            currentDetails.appendChild(currentList);
            urlContainer.appendChild(currentDetails);
        }
    });
    // Variables to keep track of the current batch and its details
    let currentBatch = null;
    let currentBatchList = null;
    const createClickableLink = (method, pathname, hostname)=>{
        const listItem = document.createElement("li");
        if (method === "GET") {
            const link = document.createElement("a");
            link.href = hostname + pathname;
            link.textContent = `GET: ${pathname}`;
            link.target = "_blank";
            listItem.appendChild(link);
        } else listItem.textContent = `${method}: ${pathname}`;
        return listItem;
    };
    // Listen for 'newUrl' messages from the service worker
    chrome.runtime.onMessage.addListener((request, sender, sendResponse)=>{
        if (request.command === "newUrl" && currentList) {
            // const listItem = document.createElement('li')
            if (request.url.includes("$batch")) {
                const listItem = createClickableLink(request.method, request.url, request.hostname);
                // Create a details element for the batch
                const batchDetails = document.createElement("details");
                batchDetails.open = true // this line ensures the details are open by default
                ;
                const batchSummary = document.createElement("summary");
                batchSummary.textContent = "Batched Requests";
                batchDetails.appendChild(batchSummary);
                // Create a new ul element for the batched requests and add it to the batchDetails
                const batchList = document.createElement("ul");
                batchDetails.appendChild(batchList);
                // Append the details element to the listItem
                listItem.appendChild(batchDetails);
                // Store the current batch and its batch list
                currentBatch = listItem;
                currentBatchList = batchList;
                // Append the listItem to the currentList
                currentList.appendChild(listItem);
            } else if (request.batch && currentBatch && currentBatchList) {
                // This is a batched request, add it to the current batch list
                const batchRequestItem = createClickableLink(request.method, request.url, request.hostname);
                currentBatchList.appendChild(batchRequestItem);
            } else if (!request.url.includes("$batch")) {
                const listItem = createClickableLink(request.method, request.url, request.hostname);
                // If this is a non-batch request, clear the current batch
                currentBatch = null;
                currentBatchList = null;
                // Append the listItem to the currentList
                currentList.appendChild(listItem);
            }
        }
    });
});

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUIsb0JBQW9CO0lBQzVDLHFEQUFxRDtJQUNyRCxNQUFNLHNCQUFzQixTQUFTLGVBQ25DO0lBRUYsTUFBTSxlQUFlLFNBQVMsZUFBZTtJQUU3QyxNQUFNLHFCQUFxQixTQUFTLGVBQ2xDO0lBR0YseUNBQXlDO0lBQ3pDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxnQkFBZ0IsQ0FBQyxvQkFBb0I7UUFDaEUsUUFBUSxNQUFNO1FBQ2Q7SUFDRjtJQUVBLGtCQUFrQjtJQUNsQixNQUFNLFlBQVk7UUFDaEIsT0FBTztZQUNMLGNBQWM7Z0JBQ1o7Z0JBQ0E7Z0JBQ0E7YUFDRDtZQUNELGNBQWM7Z0JBQUM7YUFBVTtRQUUzQjtJQUNGO0lBRUEsU0FDRyxlQUFlLGNBQ2QsaUJBQWlCLFVBQVU7UUFDM0IsSUFBSSxJQUFJLENBQUMsU0FBUyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUN2QyxJQUFJLFdBQVcsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNO1lBRWxDLFNBQVMsZUFBZSxnQkFDeEIsUUFBUSxTQUFTLGFBQWEsS0FBSztZQUVuQyxTQUFTLGVBQWUsZ0JBQ3hCLFFBQVEsU0FBUyxhQUFhLEtBQUs7UUFDdkM7SUFDRjtJQUVGLFNBQ0csZUFBZSxpQkFDZCxpQkFBaUIsVUFBVTtRQUMzQixJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxNQUFNLFNBQVMsR0FBRztZQUN2QyxJQUFJLGFBQWEsSUFBSTtZQUNyQixXQUFXLFNBQVMsU0FBVSxLQUFLO2dCQUNqQyxJQUFJLFdBQVcsS0FBSyxNQUFNLE1BQU0sUUFBUTtnQkFFdEMsU0FBUyxlQUFlLGdCQUN4QixRQUFRLFNBQVMsYUFBYSxLQUFLO2dCQUVuQyxTQUFTLGVBQWUsZ0JBQ3hCLFFBQVEsU0FBUyxhQUFhLEtBQUs7WUFDdkM7WUFDQSxXQUFXLFdBQVcsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQ3JDO0lBQ0Y7SUFFRixTQUNHLGVBQWUsaUJBQ2QsaUJBQWlCLFNBQVM7UUFDMUIsSUFBSSxXQUFXO1lBQ2IsY0FBYyxBQUNaLFNBQVMsZUFBZSxnQkFDeEIsTUFBTSxNQUFNO1lBQ2QsY0FBYyxBQUNaLFNBQVMsZUFBZSxnQkFDeEIsTUFBTSxNQUFNO1FBQ2hCO1FBQ0EsSUFBSSxPQUFPLElBQUksS0FBSztZQUFDLEtBQUssVUFBVTtTQUFVLEVBQUU7WUFDOUMsTUFBTTtRQUNSO1FBQ0EsSUFBSSxNQUFNLElBQUksZ0JBQWdCO1FBQzlCLElBQUksSUFBSSxTQUFTLGNBQWM7UUFDL0IsRUFBRSxPQUFPO1FBQ1QsRUFBRSxXQUFXO1FBQ2IsRUFBRTtJQUNKO0lBRUYsbUJBQW1CLGlCQUFpQixTQUFTO1FBQzNDLDBCQUEwQjtRQUMxQixhQUFhLFlBQVk7UUFFekIsNkJBQTZCO1FBQzdCLGNBQWM7UUFFZCx1Q0FBdUM7UUFDdkMsb0JBQW9CLFlBQVk7UUFFaEMsb0RBQW9EO1FBQ3BELE9BQU8sUUFBUSxZQUFZO1lBQ3pCLFNBQVM7UUFDWDtJQUNGO0lBRUEsb0RBQW9EO0lBQ3BELElBQUksY0FBYztJQUVsQiw2Q0FBNkM7SUFDN0MsSUFBSSxpQkFBNEM7SUFDaEQsSUFBSSxjQUF1QztJQUUzQyxzQ0FBc0M7SUFDdEMsb0JBQW9CLGlCQUFpQixTQUFTO1FBQzVDLDhCQUE4QjtRQUM5QixjQUFjLENBQUM7UUFFZiwyQ0FBMkM7UUFDM0MsTUFBTSx1QkFBdUIsU0FBUyxlQUNwQztRQUVGLE1BQU0sdUJBQXVCLFNBQVMsZUFDcEM7UUFHRix1RkFBdUY7UUFDdkYsTUFBTSxlQUFlLHFCQUFxQixNQUN2QyxNQUFNLE1BQ04sT0FBTyxDQUFDLE1BQVEsSUFBSSxXQUFXO1FBQ2xDLE1BQU0sZUFBZSxxQkFBcUIsTUFDdkMsTUFBTSxNQUNOLE9BQU8sQ0FBQyxNQUFRLElBQUksV0FBVztRQUVsQywwREFBMEQ7UUFDMUQsT0FBTyxRQUFRLFlBQVk7WUFDekIsU0FBUyxjQUFjLGlCQUFpQjtZQUN4QyxjQUFjO1lBQ2QsY0FBYztRQUNoQjtRQUVBLHlCQUF5QjtRQUN6QixvQkFBb0IsWUFBWSxjQUM1QixpQkFDQTtRQUVKLG9FQUFvRTtRQUNwRSxJQUFJLGFBQWE7WUFDZixpQkFBaUIsU0FBUyxjQUFjO1lBQ3hDLGVBQWUsT0FBTyxLQUFLLG9EQUFvRDs7WUFDL0UsTUFBTSxVQUFVLFNBQVMsY0FBYztZQUN2QyxRQUFRLGNBQWMsQ0FBQyxjQUFjLEVBQUUsYUFBYSxTQUFTLFNBQVMsRUFBRSxDQUFDO1lBQ3pFLGNBQWMsU0FBUyxjQUFjO1lBQ3JDLGVBQWUsWUFBWTtZQUMzQixlQUFlLFlBQVk7WUFDM0IsYUFBYSxZQUFZO1FBQzNCO0lBQ0Y7SUFFQSwrREFBK0Q7SUFDL0QsSUFBSSxlQUFxQztJQUN6QyxJQUFJLG1CQUE0QztJQUVoRCxNQUFNLHNCQUFzQixDQUMxQixRQUNBLFVBQ0E7UUFFQSxNQUFNLFdBQVcsU0FBUyxjQUFjO1FBRXhDLElBQUksV0FBVyxPQUFPO1lBQ3BCLE1BQU0sT0FBTyxTQUFTLGNBQWM7WUFDcEMsS0FBSyxPQUFPLFdBQVc7WUFDdkIsS0FBSyxjQUFjLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQztZQUNyQyxLQUFLLFNBQVM7WUFDZCxTQUFTLFlBQVk7UUFDdkIsT0FDRSxTQUFTLGNBQWMsQ0FBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLFNBQVMsQ0FBQztRQUdqRCxPQUFPO0lBQ1Q7SUFFQSx1REFBdUQ7SUFDdkQsT0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLFNBQVMsUUFBUTtRQUNyRCxJQUFJLFFBQVEsWUFBWSxZQUFZLGFBQWE7WUFDL0MsZ0RBQWdEO1lBRWhELElBQUksUUFBUSxJQUFJLFNBQVMsV0FBVztnQkFDbEMsTUFBTSxXQUFXLG9CQUNmLFFBQVEsUUFDUixRQUFRLEtBQ1IsUUFBUTtnQkFHVix5Q0FBeUM7Z0JBQ3pDLE1BQU0sZUFBZSxTQUFTLGNBQWM7Z0JBQzVDLGFBQWEsT0FBTyxLQUFLLG9EQUFvRDs7Z0JBQzdFLE1BQU0sZUFBZSxTQUFTLGNBQWM7Z0JBQzVDLGFBQWEsY0FBYztnQkFDM0IsYUFBYSxZQUFZO2dCQUV6QixrRkFBa0Y7Z0JBQ2xGLE1BQU0sWUFBWSxTQUFTLGNBQWM7Z0JBQ3pDLGFBQWEsWUFBWTtnQkFFekIsNkNBQTZDO2dCQUM3QyxTQUFTLFlBQVk7Z0JBRXJCLDZDQUE2QztnQkFDN0MsZUFBZTtnQkFDZixtQkFBbUI7Z0JBRW5CLHlDQUF5QztnQkFDekMsWUFBWSxZQUFZO1lBQzFCLE9BQU8sSUFBSSxRQUFRLFNBQVMsZ0JBQWdCLGtCQUFrQjtnQkFDNUQsOERBQThEO2dCQUM5RCxNQUFNLG1CQUFtQixvQkFDdkIsUUFBUSxRQUNSLFFBQVEsS0FDUixRQUFRO2dCQUVWLGlCQUFpQixZQUFZO1lBQy9CLE9BQU8sSUFBSSxDQUFDLFFBQVEsSUFBSSxTQUFTLFdBQVc7Z0JBQzFDLE1BQU0sV0FBVyxvQkFDZixRQUFRLFFBQ1IsUUFBUSxLQUNSLFFBQVE7Z0JBR1YsMERBQTBEO2dCQUMxRCxlQUFlO2dCQUNmLG1CQUFtQjtnQkFFbkIseUNBQXlDO2dCQUN6QyxZQUFZLFlBQVk7WUFDMUI7UUFDRjtJQUNGO0FBQ0YiLCJzb3VyY2VzIjpbInNyYy9zaWRlcGFuZWwudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignRE9NQ29udGVudExvYWRlZCcsICgpID0+IHtcbiAgLy8gR2V0IHJlZmVyZW5jZXMgdG8gdGhlIGJ1dHRvbiBhbmQgdGhlIFVSTCBjb250YWluZXJcbiAgY29uc3QgdG9nZ2xlQ2FwdHVyZUJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFxuICAgICd0b2dnbGVDYXB0dXJlJ1xuICApIGFzIEhUTUxCdXR0b25FbGVtZW50XG4gIGNvbnN0IHVybENvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd1cmxDb250YWluZXInKSBhcyBIVE1MRGl2RWxlbWVudFxuXG4gIGNvbnN0IGNsZWFyQ2FwdHVyZUJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFxuICAgICdjbGVhckNhcHR1cmUnXG4gICkgYXMgSFRNTEJ1dHRvbkVsZW1lbnRcblxuICAvLyBDaGVjayBpZiB0aGUgZWxlbWVudHMgZXhpc3QgaW4gdGhlIERPTVxuICBpZiAoIXRvZ2dsZUNhcHR1cmVCdXR0b24gfHwgIXVybENvbnRhaW5lciB8fCAhY2xlYXJDYXB0dXJlQnV0dG9uKSB7XG4gICAgY29uc29sZS5lcnJvcignUmVxdWlyZWQgZWxlbWVudHMgYXJlIG5vdCBmb3VuZCBpbiB0aGUgRE9NJylcbiAgICByZXR1cm5cbiAgfVxuXG4gIC8vIEtub3duIHRlbXBsYXRlc1xuICBjb25zdCB0ZW1wbGF0ZXMgPSB7XG4gICAgZmlvcmk6IHtcbiAgICAgIGV4Y2x1ZGVkVXJsczogW1xuICAgICAgICAnL3NhcC9vcHUvb2RhdGEvVUkyL0lOVEVST1AvJyxcbiAgICAgICAgJy9zYXAvYmMvdWk1X3VpNS91aTIvdXNoZWxsL3Jlc291cmNlcy8nLFxuICAgICAgICAnL3NhcC9iYy91aTIvZmxwJyxcbiAgICAgIF0sXG4gICAgICBpbmNsdWRlZFVybHM6IFsnL29kYXRhLyddLFxuICAgICAgLy8gYWRkIG1vcmUga25vd24gdGVtcGxhdGVzIGhlcmVcbiAgICB9LFxuICB9XG5cbiAgZG9jdW1lbnRcbiAgICAuZ2V0RWxlbWVudEJ5SWQoJ3RlbXBsYXRlcycpXG4gICAgPy5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBmdW5jdGlvbiAodGhpczogSFRNTFNlbGVjdEVsZW1lbnQpIHtcbiAgICAgIGlmICh0aGlzLnZhbHVlICYmIHRlbXBsYXRlc1t0aGlzLnZhbHVlXSkge1xuICAgICAgICBsZXQgdGVtcGxhdGUgPSB0ZW1wbGF0ZXNbdGhpcy52YWx1ZV1cbiAgICAgICAgOyhcbiAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZXhjbHVkZWRVcmxzJykgYXMgSFRNTFRleHRBcmVhRWxlbWVudFxuICAgICAgICApLnZhbHVlID0gdGVtcGxhdGUuZXhjbHVkZWRVcmxzLmpvaW4oJ1xcbicpXG4gICAgICAgIDsoXG4gICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2luY2x1ZGVkVXJscycpIGFzIEhUTUxUZXh0QXJlYUVsZW1lbnRcbiAgICAgICAgKS52YWx1ZSA9IHRlbXBsYXRlLmluY2x1ZGVkVXJscy5qb2luKCdcXG4nKVxuICAgICAgfVxuICAgIH0pXG5cbiAgZG9jdW1lbnRcbiAgICAuZ2V0RWxlbWVudEJ5SWQoJ2xvYWRUZW1wbGF0ZScpXG4gICAgPy5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBmdW5jdGlvbiAodGhpczogSFRNTElucHV0RWxlbWVudCkge1xuICAgICAgaWYgKHRoaXMuZmlsZXMgJiYgdGhpcy5maWxlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGxldCBmaWxlUmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKVxuICAgICAgICBmaWxlUmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICAgIGxldCB0ZW1wbGF0ZSA9IEpTT04ucGFyc2UoZXZlbnQudGFyZ2V0Py5yZXN1bHQgYXMgc3RyaW5nKVxuICAgICAgICAgIDsoXG4gICAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZXhjbHVkZWRVcmxzJykgYXMgSFRNTFRleHRBcmVhRWxlbWVudFxuICAgICAgICAgICkudmFsdWUgPSB0ZW1wbGF0ZS5leGNsdWRlZFVybHMuam9pbignXFxuJylcbiAgICAgICAgICA7KFxuICAgICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2luY2x1ZGVkVXJscycpIGFzIEhUTUxUZXh0QXJlYUVsZW1lbnRcbiAgICAgICAgICApLnZhbHVlID0gdGVtcGxhdGUuaW5jbHVkZWRVcmxzLmpvaW4oJ1xcbicpXG4gICAgICAgIH1cbiAgICAgICAgZmlsZVJlYWRlci5yZWFkQXNUZXh0KHRoaXMuZmlsZXNbMF0pXG4gICAgICB9XG4gICAgfSlcblxuICBkb2N1bWVudFxuICAgIC5nZXRFbGVtZW50QnlJZCgnc2F2ZVRlbXBsYXRlJylcbiAgICA/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgZnVuY3Rpb24gKCkge1xuICAgICAgbGV0IHRlbXBsYXRlID0ge1xuICAgICAgICBleGNsdWRlZFVybHM6IChcbiAgICAgICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZXhjbHVkZWRVcmxzJykgYXMgSFRNTFRleHRBcmVhRWxlbWVudFxuICAgICAgICApLnZhbHVlLnNwbGl0KCdcXG4nKSxcbiAgICAgICAgaW5jbHVkZWRVcmxzOiAoXG4gICAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2luY2x1ZGVkVXJscycpIGFzIEhUTUxUZXh0QXJlYUVsZW1lbnRcbiAgICAgICAgKS52YWx1ZS5zcGxpdCgnXFxuJyksXG4gICAgICB9XG4gICAgICBsZXQgYmxvYiA9IG5ldyBCbG9iKFtKU09OLnN0cmluZ2lmeSh0ZW1wbGF0ZSldLCB7XG4gICAgICAgIHR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgIH0pXG4gICAgICBsZXQgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKVxuICAgICAgbGV0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcbiAgICAgIGEuaHJlZiA9IHVybFxuICAgICAgYS5kb3dubG9hZCA9ICd0ZW1wbGF0ZS5qc29uJ1xuICAgICAgYS5jbGljaygpXG4gICAgfSlcblxuICBjbGVhckNhcHR1cmVCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgLy8gRW1wdHkgdGhlIFVSTCBjb250YWluZXJcbiAgICB1cmxDb250YWluZXIuaW5uZXJIVE1MID0gJydcblxuICAgIC8vIFJlc2V0IHRoZSBpc0NhcHR1cmluZyBmbGFnXG4gICAgaXNDYXB0dXJpbmcgPSBmYWxzZVxuXG4gICAgLy8gUmVzZXQgdGhlIHRvZ2dsZSBjYXB0dXJlIGJ1dHRvbiB0ZXh0XG4gICAgdG9nZ2xlQ2FwdHVyZUJ1dHRvbi5pbm5lclRleHQgPSAnU3RhcnQgQ2FwdHVyZSdcblxuICAgIC8vIFNlbmQgYSBjb21tYW5kIHRvIGJhY2tncm91bmQudHMgdG8gc3RvcCBjYXB0dXJpbmdcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICBjb21tYW5kOiAnc3RvcENhcHR1cmUnLFxuICAgIH0pXG4gIH0pXG5cbiAgLy8gQSBmbGFnIHRvIGluZGljYXRlIHdoZXRoZXIgd2UncmUgY2FwdHVyaW5nIG9yIG5vdFxuICBsZXQgaXNDYXB0dXJpbmcgPSBmYWxzZVxuXG4gIC8vIFRoZSBjdXJyZW50IGNhcHR1cmUgY3ljbGUgZGV0YWlscyBhbmQgbGlzdFxuICBsZXQgY3VycmVudERldGFpbHM6IEhUTUxEZXRhaWxzRWxlbWVudCB8IG51bGwgPSBudWxsXG4gIGxldCBjdXJyZW50TGlzdDogSFRNTFVMaXN0RWxlbWVudCB8IG51bGwgPSBudWxsXG5cbiAgLy8gRXZlbnQgbGlzdGVuZXIgZm9yIHRoZSBidXR0b24gY2xpY2tcbiAgdG9nZ2xlQ2FwdHVyZUJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAvLyBUb2dnbGUgdGhlIGlzQ2FwdHVyaW5nIGZsYWdcbiAgICBpc0NhcHR1cmluZyA9ICFpc0NhcHR1cmluZ1xuXG4gICAgLy8gR2V0IHRoZSBleGNsdWRlZCBVUkxzIGZyb20gdGhlIHRleHQgYXJlYVxuICAgIGNvbnN0IGV4Y2x1ZGVkVXJsc1RleHRBcmVhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXG4gICAgICAnZXhjbHVkZWRVcmxzJ1xuICAgICkgYXMgSFRNTFRleHRBcmVhRWxlbWVudFxuICAgIGNvbnN0IGluY2x1ZGVkVXJsc1RleHRBcmVhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXG4gICAgICAnaW5jbHVkZWRVcmxzJ1xuICAgICkgYXMgSFRNTFRleHRBcmVhRWxlbWVudFxuXG4gICAgLy8gR2V0IHRoZSBleGNsdWRlZCBVUkxzIGFuZCBpbmNsdWRlZCBVUkxzIGZyb20gdGhlIHRleHQgYXJlYSwgZmlsdGVyIG91dCBlbXB0eSBzdHJpbmdzXG4gICAgY29uc3QgZXhjbHVkZWRVcmxzID0gZXhjbHVkZWRVcmxzVGV4dEFyZWEudmFsdWVcbiAgICAgIC5zcGxpdCgnXFxuJylcbiAgICAgIC5maWx0ZXIoKHVybCkgPT4gdXJsLnRyaW0oKSAhPT0gJycpXG4gICAgY29uc3QgaW5jbHVkZWRVcmxzID0gaW5jbHVkZWRVcmxzVGV4dEFyZWEudmFsdWVcbiAgICAgIC5zcGxpdCgnXFxuJylcbiAgICAgIC5maWx0ZXIoKHVybCkgPT4gdXJsLnRyaW0oKSAhPT0gJycpXG5cbiAgICAvLyBTZW5kIGEgY29tbWFuZCB0byBiYWNrZ3JvdW5kLnRzIHRvIHN0YXJ0L3N0b3AgY2FwdHVyaW5nXG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xuICAgICAgY29tbWFuZDogaXNDYXB0dXJpbmcgPyAnc3RhcnRDYXB0dXJlJyA6ICdzdG9wQ2FwdHVyZScsXG4gICAgICBleGNsdWRlZFVybHM6IGV4Y2x1ZGVkVXJscyxcbiAgICAgIGluY2x1ZGVkVXJsczogaW5jbHVkZWRVcmxzLFxuICAgIH0pXG5cbiAgICAvLyBVcGRhdGUgdGhlIGJ1dHRvbiB0ZXh0XG4gICAgdG9nZ2xlQ2FwdHVyZUJ1dHRvbi5pbm5lclRleHQgPSBpc0NhcHR1cmluZ1xuICAgICAgPyAnU3RvcCBDYXB0dXJlJ1xuICAgICAgOiAnU3RhcnQgQ2FwdHVyZSdcblxuICAgIC8vIENyZWF0ZSBuZXcgY2FwdHVyZSBjeWNsZSBkZXRhaWxzIGFuZCBsaXN0IHdoZW4gd2Ugc3RhcnQgY2FwdHVyaW5nXG4gICAgaWYgKGlzQ2FwdHVyaW5nKSB7XG4gICAgICBjdXJyZW50RGV0YWlscyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RldGFpbHMnKVxuICAgICAgY3VycmVudERldGFpbHMub3BlbiA9IHRydWUgLy8gdGhpcyBsaW5lIGVuc3VyZXMgdGhlIGRldGFpbHMgYXJlIG9wZW4gYnkgZGVmYXVsdFxuICAgICAgY29uc3Qgc3VtbWFyeSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N1bW1hcnknKVxuICAgICAgc3VtbWFyeS50ZXh0Q29udGVudCA9IGBDYXB0dXJlIEN5Y2xlICR7dXJsQ29udGFpbmVyLmNoaWxkcmVuLmxlbmd0aCArIDF9YFxuICAgICAgY3VycmVudExpc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd1bCcpXG4gICAgICBjdXJyZW50RGV0YWlscy5hcHBlbmRDaGlsZChzdW1tYXJ5KVxuICAgICAgY3VycmVudERldGFpbHMuYXBwZW5kQ2hpbGQoY3VycmVudExpc3QpXG4gICAgICB1cmxDb250YWluZXIuYXBwZW5kQ2hpbGQoY3VycmVudERldGFpbHMpXG4gICAgfVxuICB9KVxuXG4gIC8vIFZhcmlhYmxlcyB0byBrZWVwIHRyYWNrIG9mIHRoZSBjdXJyZW50IGJhdGNoIGFuZCBpdHMgZGV0YWlsc1xuICBsZXQgY3VycmVudEJhdGNoOiBIVE1MTElFbGVtZW50IHwgbnVsbCA9IG51bGxcbiAgbGV0IGN1cnJlbnRCYXRjaExpc3Q6IEhUTUxVTGlzdEVsZW1lbnQgfCBudWxsID0gbnVsbFxuXG4gIGNvbnN0IGNyZWF0ZUNsaWNrYWJsZUxpbmsgPSAoXG4gICAgbWV0aG9kOiBzdHJpbmcsXG4gICAgcGF0aG5hbWU6IHN0cmluZyxcbiAgICBob3N0bmFtZTogc3RyaW5nXG4gICk6IEhUTUxMSUVsZW1lbnQgPT4ge1xuICAgIGNvbnN0IGxpc3RJdGVtID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKVxuXG4gICAgaWYgKG1ldGhvZCA9PT0gJ0dFVCcpIHtcbiAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcbiAgICAgIGxpbmsuaHJlZiA9IGhvc3RuYW1lICsgcGF0aG5hbWVcbiAgICAgIGxpbmsudGV4dENvbnRlbnQgPSBgR0VUOiAke3BhdGhuYW1lfWBcbiAgICAgIGxpbmsudGFyZ2V0ID0gJ19ibGFuaydcbiAgICAgIGxpc3RJdGVtLmFwcGVuZENoaWxkKGxpbmspXG4gICAgfSBlbHNlIHtcbiAgICAgIGxpc3RJdGVtLnRleHRDb250ZW50ID0gYCR7bWV0aG9kfTogJHtwYXRobmFtZX1gXG4gICAgfVxuXG4gICAgcmV0dXJuIGxpc3RJdGVtXG4gIH1cblxuICAvLyBMaXN0ZW4gZm9yICduZXdVcmwnIG1lc3NhZ2VzIGZyb20gdGhlIHNlcnZpY2Ugd29ya2VyXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigocmVxdWVzdCwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgICBpZiAocmVxdWVzdC5jb21tYW5kID09PSAnbmV3VXJsJyAmJiBjdXJyZW50TGlzdCkge1xuICAgICAgLy8gY29uc3QgbGlzdEl0ZW0gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpXG5cbiAgICAgIGlmIChyZXF1ZXN0LnVybC5pbmNsdWRlcygnJGJhdGNoJykpIHtcbiAgICAgICAgY29uc3QgbGlzdEl0ZW0gPSBjcmVhdGVDbGlja2FibGVMaW5rKFxuICAgICAgICAgIHJlcXVlc3QubWV0aG9kLFxuICAgICAgICAgIHJlcXVlc3QudXJsLFxuICAgICAgICAgIHJlcXVlc3QuaG9zdG5hbWVcbiAgICAgICAgKVxuXG4gICAgICAgIC8vIENyZWF0ZSBhIGRldGFpbHMgZWxlbWVudCBmb3IgdGhlIGJhdGNoXG4gICAgICAgIGNvbnN0IGJhdGNoRGV0YWlscyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RldGFpbHMnKVxuICAgICAgICBiYXRjaERldGFpbHMub3BlbiA9IHRydWUgLy8gdGhpcyBsaW5lIGVuc3VyZXMgdGhlIGRldGFpbHMgYXJlIG9wZW4gYnkgZGVmYXVsdFxuICAgICAgICBjb25zdCBiYXRjaFN1bW1hcnkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdW1tYXJ5JylcbiAgICAgICAgYmF0Y2hTdW1tYXJ5LnRleHRDb250ZW50ID0gJ0JhdGNoZWQgUmVxdWVzdHMnXG4gICAgICAgIGJhdGNoRGV0YWlscy5hcHBlbmRDaGlsZChiYXRjaFN1bW1hcnkpXG5cbiAgICAgICAgLy8gQ3JlYXRlIGEgbmV3IHVsIGVsZW1lbnQgZm9yIHRoZSBiYXRjaGVkIHJlcXVlc3RzIGFuZCBhZGQgaXQgdG8gdGhlIGJhdGNoRGV0YWlsc1xuICAgICAgICBjb25zdCBiYXRjaExpc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd1bCcpXG4gICAgICAgIGJhdGNoRGV0YWlscy5hcHBlbmRDaGlsZChiYXRjaExpc3QpXG5cbiAgICAgICAgLy8gQXBwZW5kIHRoZSBkZXRhaWxzIGVsZW1lbnQgdG8gdGhlIGxpc3RJdGVtXG4gICAgICAgIGxpc3RJdGVtLmFwcGVuZENoaWxkKGJhdGNoRGV0YWlscylcblxuICAgICAgICAvLyBTdG9yZSB0aGUgY3VycmVudCBiYXRjaCBhbmQgaXRzIGJhdGNoIGxpc3RcbiAgICAgICAgY3VycmVudEJhdGNoID0gbGlzdEl0ZW1cbiAgICAgICAgY3VycmVudEJhdGNoTGlzdCA9IGJhdGNoTGlzdFxuXG4gICAgICAgIC8vIEFwcGVuZCB0aGUgbGlzdEl0ZW0gdG8gdGhlIGN1cnJlbnRMaXN0XG4gICAgICAgIGN1cnJlbnRMaXN0LmFwcGVuZENoaWxkKGxpc3RJdGVtKVxuICAgICAgfSBlbHNlIGlmIChyZXF1ZXN0LmJhdGNoICYmIGN1cnJlbnRCYXRjaCAmJiBjdXJyZW50QmF0Y2hMaXN0KSB7XG4gICAgICAgIC8vIFRoaXMgaXMgYSBiYXRjaGVkIHJlcXVlc3QsIGFkZCBpdCB0byB0aGUgY3VycmVudCBiYXRjaCBsaXN0XG4gICAgICAgIGNvbnN0IGJhdGNoUmVxdWVzdEl0ZW0gPSBjcmVhdGVDbGlja2FibGVMaW5rKFxuICAgICAgICAgIHJlcXVlc3QubWV0aG9kLFxuICAgICAgICAgIHJlcXVlc3QudXJsLFxuICAgICAgICAgIHJlcXVlc3QuaG9zdG5hbWVcbiAgICAgICAgKVxuICAgICAgICBjdXJyZW50QmF0Y2hMaXN0LmFwcGVuZENoaWxkKGJhdGNoUmVxdWVzdEl0ZW0pXG4gICAgICB9IGVsc2UgaWYgKCFyZXF1ZXN0LnVybC5pbmNsdWRlcygnJGJhdGNoJykpIHtcbiAgICAgICAgY29uc3QgbGlzdEl0ZW0gPSBjcmVhdGVDbGlja2FibGVMaW5rKFxuICAgICAgICAgIHJlcXVlc3QubWV0aG9kLFxuICAgICAgICAgIHJlcXVlc3QudXJsLFxuICAgICAgICAgIHJlcXVlc3QuaG9zdG5hbWVcbiAgICAgICAgKVxuXG4gICAgICAgIC8vIElmIHRoaXMgaXMgYSBub24tYmF0Y2ggcmVxdWVzdCwgY2xlYXIgdGhlIGN1cnJlbnQgYmF0Y2hcbiAgICAgICAgY3VycmVudEJhdGNoID0gbnVsbFxuICAgICAgICBjdXJyZW50QmF0Y2hMaXN0ID0gbnVsbFxuXG4gICAgICAgIC8vIEFwcGVuZCB0aGUgbGlzdEl0ZW0gdG8gdGhlIGN1cnJlbnRMaXN0XG4gICAgICAgIGN1cnJlbnRMaXN0LmFwcGVuZENoaWxkKGxpc3RJdGVtKVxuICAgICAgfVxuICAgIH1cbiAgfSlcbn0pXG4iXSwibmFtZXMiOltdLCJ2ZXJzaW9uIjozLCJmaWxlIjoic2lkZXBhbmVsLmVmMGNlMjA3LmpzLm1hcCJ9
