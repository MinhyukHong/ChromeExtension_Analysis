window._CORE_ = {
    "INJECT_FILES": {
        "resume": {
            "css": [],
            "js": [
                "content_script.resume.js"
            ]
        },
        "jobPosition": {
            "css": [],
            "js": [
                "content_script.job-position.js"
            ]
        }
    }
};