console.log('%c2号简历助手运行中...', 'color: #0093ff')

const storageKey = {
  config: '2haohr_resume_parser_config',
  log: '2haohr_resume_parser_log'
}

if (!localStorage.getItem(storageKey.log)) {
  localStorage.setItem(storageKey.log, 0)
}

/**
 * log操作
 */
class Log {
  _output(key, ...args) {
    if (localStorage.getItem(storageKey.log) === '1') {
      let args0 = '%c2号简历助手: ' + args[0]
      args.shift()
      console[key](args0, 'color: #808080', ...args)
    }
  }

  log(...args) {
    this._output('log', ...args)
  }

  warn(...args) {
    this._output('warn', ...args)
  }

  error(...args) {
    this._output('error', ...args)
  }

  timeEnd(...args) {
    this._output('timeEnd', ...args)
  }

  time(...args) {
    this._output('time', ...args)
  }
}
const _Log = new Log()
const log = _Log.log.bind(_Log)

/**
 * 事件操作类
 */
class ResumeHelperEvent {
  constructor() {
    // 简历助手的更新事件
    this.configUpdateEvent = new CustomEvent('on2haohrResumeParserConfigUpdate', {
      detail: {
        data: null,
        eventDesc: '插件配置更新时触发'
      }
    })
    // 简历助手状态变更事件（升级、禁用或卸载）
    this.disconnectEvent = new CustomEvent('on2haohrResumeParserDisconnect', {
      detail: {
        data: null,
        eventDesc:
          '当前页面与简历助手的连接断开。可能的原因：插件升级了新版本、已禁用或已卸载。当前页面必须刷新页面后才可能与简历助手重新建立连接。'
      }
    })
    this.dispatch = this.dispatch.bind(this)
    this.confgUpdate = this.confgUpdate.bind(this)
    this.disconnect = this.disconnect.bind(this)
  }

  /**
   * 派发事件
   * @param {string} eventName
   * @param {object} data
   */
  dispatch(eventName, data = {}) {
    switch (eventName) {
      case 'on2haohrResumeParserConfigUpdate':
        this.configUpdateEvent.detail.data = {
          ...data
        }
        window.dispatchEvent(this.configUpdateEvent)
        break
      case 'on2haohrResumeParserDisconnect':
        this.disconnectEvent.detail.data = {
          ...data
        }
        window.dispatchEvent(this.disconnectEvent)
        break
    }
    log('已派发事件', eventName, data)
  }

  /**
   * 派发配置更新事件
   * @param {object} data
   */
  confgUpdate(data) {
    return this.dispatch('on2haohrResumeParserConfigUpdate', data)
  }

  /**
   * 派发连接断开事件
   */
  disconnect(data) {
    return this.dispatch('on2haohrResumeParserDisconnect', data)
  }
}

const _event = new ResumeHelperEvent()

/**
 * 发送简单消息
 */
const sendMessage = message => {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(message, response => {
        resolve({
          ok: true,
          res: response
        })
      })
    } catch (error) {
      resolve({
        ok: false,
        err: error,
        res: null
      })
    }
  })
}

/**
 * 传递长连接消息
 */
const connect = options => {
  if (!chrome.runtime) {
    return
  }
  const port = chrome.runtime.connect({
    name: options.name
  })
  if (typeof options.onMessage === 'function') {
    port.onMessage.addListener(options.onMessage)
  }
  if (typeof options.onDisconnect === 'function') {
    const disconnectListener = (...args) => {
      port.onMessage.removeListener(options.onMessage)
      port.onDisconnect.removeListener(disconnectListener)
      options.onDisconnect(...args)
    }
    port.onDisconnect.addListener(disconnectListener)
  }
  return port
}

/**
 * 保存配置
 */
const saveConfig = (key, value) => {
  if (!window.__2haohr_resume_parser_config) {
    return
  }
  if (key) {
    window.__2haohr_resume_parser_config[key] = value
  }
  // 存储配置
  localStorage.setItem(storageKey.config, JSON.stringify(window.__2haohr_resume_parser_config))
  // 派发更新事件
  _event.confgUpdate(window.__2haohr_resume_parser_config)
}

/**
 * 刷新基础配置信息
 */
const refreshBaseInfo = async() => {
  await new Promise((resolve, reject) => {
    setTimeout(resolve, 1000)
  })
  let data = await sendMessage({ cmd: 'get.core' })
  if (data.ok && data.res) {
    window.__2haohr_resume_parser_config = data.res
    saveConfig()
    log(`%c配置已存储，获取方式：%clocalStorage.getItem('${storageKey.config}')`, 'color: green', 'font-weight: bold')
  }
}

// /**
//  * 在页面顶层上下文中执行脚本
//  * @param {string} code
//  */
// const executeScript = code => {
//   if (!code) {
//     return
//   }
//   let execScript = document.createElement('script')
//   execScript.textContent = code.replace(/\n/gi, '')
//   execScript.id = (Date.now() + Math.random()).toString(32).replace(/\./gi, '')
//   // 添加到页面执行
//   document.body.appendChild(execScript)
//   // 执行后移除
//   document.body.removeChild(execScript)
// }

/**
 * 与背景页构建连接
 */
// let port = null
const connectBg = async() => {
  await new Promise((resolve, reject) => {
    setTimeout(resolve, 3000)
  })
  // port =
  await connect({
    name: 'c2b',
    onMessage: async msg => {
      log(`%cRecive Message: ${JSON.stringify(msg.cmd)}`, 'color: #0093ff;')
      switch (msg.cmd) {
        case 'set.is_login':
          saveConfig('isLogin', msg.value)
          break
        case 'set.latestVersion':
          // saveConfig('latestVersion', msg.value)
          break
        case 'set.jobPositionList':
          // msg.value
          break
        case 'set.jobPositionId':
          // msg.value
          break
        case 'set.options':
          // msg.options
          break
        case 'set.company_info':
          saveConfig('corpInfo', msg.value)
          break
        case 'logout':
          // 刷新基础配置信息
          await refreshBaseInfo()
          break
        default:
          log(`%c接收来自Background，未处理的消息：${JSON.stringify(msg.cmd)}`, 'color: orange;')
          break
      }
    },
    onDisconnect: async port => {
      // 清理配置数据
      localStorage.removeItem(storageKey.config)
      _event.disconnect({})
      log('2号简历助手连接已断开，配置已清理', port.name)

      /* // 在顶层上下文发起notice提示
      if (window.location.href.includes('/recruitment/job-position/recruiting')) {
        const title = window.__2haohr_resume_parser_config.core.title
        const desc = `简历助手发生变更（升级了新版本、已禁用或已卸载）；需要刷新页面后才可以正常使用“发布职位到招聘网站”功能。`
        const duration = 0
        executeScript(`
          Vue.$notice
          ? Vue.$notice({
              type: 'warning',
              title: '${title}',
              desc: '${desc}',
              duration: ${duration},
              dangerouslyUseHTMLString: true
            })
          : Vue.$Notice.warning({ title: '${title}', desc: '${desc}', duration: ${duration} })
        `)
      } */
    }
  })
  saveConfig()
  log('%c与背景页构建连接成功', 'color: #0093ff')
}

/**
 * 运行
 */
;(async() => {
  // 构建连接
  connectBg()
  // 刷新基础配置信息
  refreshBaseInfo()
})()
