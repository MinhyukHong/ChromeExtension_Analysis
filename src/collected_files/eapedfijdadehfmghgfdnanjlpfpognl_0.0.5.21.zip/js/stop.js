
if (document.visibilityState === "hidden" && window.performance.getEntriesByType("navigation")[0].type !== "reload") {

    window.stop();

    chrome.runtime.sendMessage("stop");

}
