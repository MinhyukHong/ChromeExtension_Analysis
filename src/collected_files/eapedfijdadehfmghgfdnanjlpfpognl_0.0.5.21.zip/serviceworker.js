
var TIMEOUT = undefined;

var func = async function(value, sender, sendResponse) {

	if (value === "stop") {

		var obj = new Map();

		obj[sender.tab.id] = sender.tab.url;

		await chrome.storage.session.set(obj);	

		if (TIMEOUT === undefined) {

			main();
		
		}

	}

}

chrome.runtime.onMessage.addListener(function(value, sender, sendResponse) {

	func(value, sender, sendResponse);

	return true;

});

chrome.tabs.onActivated.addListener(async function(activeInfo) {
	
	var tabId = activeInfo.tabId;

	var items = await chrome.storage.session.get();

	if (items[tabId] !== undefined) {

		await chrome.storage.session.remove(tabId+"")

		await chrome.tabs.reload(tabId);

	}

});

chrome.tabs.onRemoved.addListener(async function(tabId, removeInfo) {

	var items = await chrome.storage.session.get();

	if (items[tabId] !== undefined) {

		await chrome.storage.session.remove(tabId+"");

	}

});

async function main() {

	TIMEOUT = setTimeout(async function() {

		var loadingTabs = await chrome.tabs.query({status:"loading"});

		if (loadingTabs.length === 0) {

			var items = await chrome.storage.session.get();

			items = Object.entries(items);
	
			if (items.length !== 0) {

				var item = items[0];
			
				var tabId = item[0];

				await chrome.storage.session.remove(tabId);

				await chrome.tabs.reload(tabId-0).catch(function(error) {

					main();

				});

				main();

			} else {

				TIMEOUT = undefined;

			}
		
		} else {

			main();

		}

	}, 500);

}
