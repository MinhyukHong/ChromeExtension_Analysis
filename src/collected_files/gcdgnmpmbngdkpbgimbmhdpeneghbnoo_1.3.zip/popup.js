let getSoundButton = document.getElementById('getSoundButton');
let noSoundText = document.getElementById("no-sound-found-text");

function query(queryString, callback) {
console.log(queryString)
chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
  chrome.tabs.executeScript(
    tabs[0].id,
    {code: queryString},
    callback
  );
});
}

var dactecDataCollector = {
  _url: null,
  _title: null,
  _type: null
};

Object.defineProperty(dactecDataCollector, 'url', {
  get: function() {
    return _url;
  },
  set: function(value) {
    _url = value;
    if (value) {
      noSoundText.style.visibility = "hidden";
      getSoundButton.innerHTML = "Download sound";
      getSoundButton.disabled = false;
    } else {
      noSoundText.style.visibility = "visible";
      getSoundButton.innerHTML = "No sound found";
      getSoundButton.disabled = true;
    }
  }
});

Object.defineProperty(dactecDataCollector, 'title', {
  get: function() {
    return _title;
  },
  set: function(value) {
    _title = value;
  }
});

Object.defineProperty(dactecDataCollector, 'type', {
  get: function() {
    return _type;
  },
  set: function(value) {
    _type = value;
  }
});

const showError = function() {
  top.prompt("If you see this message, contact us using our contact form on dactec.nl and copy/paste the following text:", "{type:" + dactecDataCollector.type + "|url:"+dactecDataCollector.url+"|title:"+dactecDataCollector.title+"}");
  noSoundText.style.visibility = "visible";
  getSoundButton.innerHTML = "Err, retry later.";
  getSoundButton.disabled = true;
}

getSoundButton.onclick = function () {
  if (dactecDataCollector.url) {
    let download = {};
    let url = dactecDataCollector.url;
    let parts = dactecDataCollector.url.split(".");
    let extension = parts[parts.length - 1]; // last part is the extension

    // If the extension is not mp3, m4a and we do not have an type, we cant do anything.
    if (extension !== "mp3" && extension !== "m4a" && !dactecDataCollector.type) {
      // This is weird, we've got an object probably.
      showError();
      return;
    }

    // If the extension is not mp3 or m4a but we have got an mime type that was set on the <audio> element
    if (extension !== "mp3" && extension !== "m4a") {
      // This is good, we've got an type so we can determine the extension maybe.
      switch (dactecDataCollector.type) {
        case "audio/mp3":
          extension = ".mp3";
          break;
        case "audio/m4a":
          extension = ".m4a";
          break;
        default:
          // no match so just error
          showError();
          return;
      }
    }

    // We have an supported extension
    if (dactecDataCollector.title) {
      download.filename = dactecDataCollector.title.split(" ").join("_").toLowerCase()+"."+extension;
    }

    // Set the url
    download.url = url;

    chrome.downloads.download(download);
  }
};

let getSoundQuery = `var sound = document.getElementsByClassName("music-card-container")[0].getElementsByTagName("video")[0]; JSON.stringify({ src: sound.src, type: sound.type });`;
let getSoundTitleQuery = `document.getElementsByClassName("share-title")[0].innerText;`;

const firstTry = function(result) {
  result = JSON.parse(result)
  if (!result || !result.src) {
    getSoundQuery = `document.getElementsByTagName("video")[0]`;
    query(getSoundQuery, secondTry);
    return
  }

  dactecDataCollector.url = result.src;
};

const secondTry = function(result) {
console.log(result);
  if (!result || !result.src) {
    getSoundQuery = `document.getElementsByTagName("audio")[0]`;
    query(getSoundQuery, thirdTry);
    return
  }

  dactecDataCollector.url = result.src;
};

const thirdTry = function(result) {
console.log(result);
  if (!result || !result.src) {
    getSoundQuery = `document.getElementsByTagName("source")[0]`;
    query(getSoundQuery, fourthTry);
    return
  }

  dactecDataCollector.url = result.src;
};

const fourthTry = function(result) {
console.log(result);
  if (!result || !result.src) {
    console.error("I give up, i cant find the sound, well done tiktok, again you ruined my chrome extension.");
    return
  }

  dactecDataCollector.url = result.src;
};

const soundTitle = function(result) {
  console.log(result);
  if (!result || !result[0] || result[0] === "") {
    console.error("No title found lmao");
    return
  }

  dactecDataCollector.title = result[0];
};

query(getSoundTitleQuery, soundTitle)
query(getSoundQuery, firstTry);








