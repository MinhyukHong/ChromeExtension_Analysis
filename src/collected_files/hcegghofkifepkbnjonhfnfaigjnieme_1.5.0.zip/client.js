'use strict';


var googlePlusUserLoader = (function() {

    var SENDER_KEY = "AIzaSyA8x-Qi_OC9tEa86XE5LJnqqcbAYCN2HFQ";

    var STATE_START = 1;
    var STATE_ACQUIRING_AUTHTOKEN = 2;
    var STATE_AUTHTOKEN_ACQUIRED = 3;

    var state = STATE_START;
    var signin_button, revoke_button, user_info_div, send_note_div;
    var config_notfound_info, submit_info_success, submit_info_error;
    var device_list_div, submit_info, user_name_div;
    var label_list_available, label_list_selected, label_section, label_section_toggler;

    var refreshDeviceList = false;
    var refreshLabelsList = false;

    var user_id = undefined;
    var device_ids = undefined;
    var total_labels_count = 0;
    var current_labels_count = 0;
    var available_labels = [];
    var selected_labels = [];

    function disableButton(button) {
        button.attr("disabled", "disabled");
    }

    function enableButton(button) {
        button.removeAttr("disabled");
    }

    function hideButton(button) {
        button.hide();
    }

    function showButton(button) {
        button.show();
    }

    function changeState(newState) {
        state = newState;
        switch (state) {
            case STATE_START:
                showButton(signin_button);
                enableButton(signin_button);
                hideButton(revoke_button);
                hideButton(send_note_div);
                hideButton(user_info_div);
                break;
            case STATE_ACQUIRING_AUTHTOKEN:
                console.log('Acquiring token...');
                disableButton(signin_button);
                hideButton(revoke_button);
                hideButton(send_note_div);
                hideButton(user_info_div);
                break;
            case STATE_AUTHTOKEN_ACQUIRED:
                hideButton(signin_button);
                showButton(revoke_button);
                showButton(send_note_div);
                showButton(user_info_div);
                break;
        }
    }


    // @corecode_begin getProtectedData
    function xhrWithAuth(url, callback) {
        var access_token;
        var retry = true;

        getToken();

        function getToken() {
            chrome.identity.getAuthToken({ interactive: false }, function(token) {
                if (chrome.runtime.lastError) {
                    callback(chrome.runtime.lastError);
                    return;
                }

                access_token = token;
                requestStart();
            });
        }

        function requestStart() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url);
            xhr.setRequestHeader('Authorization', 'Bearer ' + access_token);
            xhr.responseType = 'json';
            xhr.onload = requestComplete;
            xhr.send();
        }

        function requestComplete() {
            if (this.status == 401 && retry) {
                retry = false;
                chrome.identity.removeCachedAuthToken({ token: access_token }, getToken);
            } else {
                callback(null, this.status, this.response);
            }
        }
    }

    function sendGcm(data, callback) {
        var retry = true;

        requestStart();

        function requestStart() {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'https://android.googleapis.com/gcm/send');
            xhr.setRequestHeader('Authorization', 'key=' + SENDER_KEY);
            xhr.setRequestHeader("Content-type","application/json");
            xhr.responseType = 'json';
            xhr.onload = callComplete;
            xhr.send(data);
        }

        function callComplete() {
            if (this.status == 401 && retry) {
                retry = false;
                requestStart();
            } else {
                callback(null, this.status, this.response);
            }
        }
    }

    function refreshNoteablyConfig() {
        console.log("makeDriveRequest Run 1");
        xhrWithAuth('https://www.googleapis.com/drive/v2/files?q=title=\'NoteablyConfig\'', onNoteablyConfigMetadataFetched);
    }

    function onNoteablyConfigMetadataFetched(error, status, response) {
        if (!error && status == 200 && response !== undefined && response.items[0] !== undefined) {
            console.log("makeDriveRequest Run 2");
            var downloadUrl = response.items[0].downloadUrl;
            xhrWithAuth(downloadUrl, onNoteablyConfigContentFetched);
        } else {
            showButton(config_notfound_info);
            changeState(STATE_START);
        }
    }

    function onNoteablyConfigContentFetched(error, status, response) {
        if (!error && status == 200 && response !== undefined && user_id !== undefined) {
            var gcmEntries = response.gcmEntries;

            chrome.storage.local.set({'NoteablyConfig': JSON.stringify(response)}, function() {
                if (chrome.extension.lastError) {
                    console.log("An error occurred while saving data: " + chrome.extension.lastError.message);
                } else {
                    console.log("Data with key: NoteablyConfig saved!");
                }
            });

            chrome.storage.local.set({'DeviceGcmField': JSON.stringify(gcmEntries)}, function() {
                if (chrome.extension.lastError) {
                    console.log("An error occurred while saving data: " + chrome.extension.lastError.message);
                } else {
                    console.log("Data with key: DeviceGcmField saved!");
                }
            });

            device_ids = gcmEntries;
            if(refreshDeviceList)
                populateDeviceList();

            if(refreshLabelsList)
                fetchLabelFolderId(response.noteablyFolderResourceId);

            refreshDeviceList = false;
            refreshLabelsList = false;
        } else {
            showButton(config_notfound_info);
            changeState(STATE_START);
        }
    }

    function refreshLabels() {
        console.log("Refreshing Labels");
        chrome.storage.local.get('NoteablyConfig', function(result){
            if (result['NoteablyConfig'] === undefined) {
                refreshLabelsList = true;
                refreshNoteablyConfig();
            } else {
                var config = JSON.parse(result['NoteablyConfig']);
                fetchLabelFolderId(config.noteablyFolderResourceId);
            }
        });
    }

    function fetchLabelFolderId(noteablyFolderResourceId) {
        chrome.storage.local.get('FilterFolderId', function(result){
            var id = result['FilterFolderId'];
            if (id === undefined) {
                console.log("FilterFolderId not found!");
                xhrWithAuth('https://www.googleapis.com/drive/v2/files/'+noteablyFolderResourceId+'/children?q=title=\'LabelsFolder\'',
                    function(error, status, response) {
                        var filterFolderId = response.items[0].id;

                        chrome.storage.local.set({'FilterFolderId': filterFolderId}, function() {
                            if (chrome.extension.lastError) {
                                console.log("An error occurred while saving data: " + chrome.extension.lastError.message);
                            } else {
                                console.log("Data with key: FilterFolderId saved!");
                            }
                        });

                        xhrWithAuth('https://www.googleapis.com/drive/v2/files/'+filterFolderId+'/children', onLabelFolderContentFetched);
                    });
            } else {
                xhrWithAuth('https://www.googleapis.com/drive/v2/files/'+id+'/children', onLabelFolderContentFetched);
            }
        });
    }

    function onLabelFolderContentFetched(error, status, response) {
        if (!error && status == 200 && response !== undefined) {
            console.log("onLabelFolderContentFetched");
            total_labels_count = response.items.length;
            current_labels_count = 0;
            available_labels = [];
            console.log("Label count: "+total_labels_count);

            for (var i = 0; i < total_labels_count; i++) {
                var id = response.items[i].id;
                xhrWithAuth('https://www.googleapis.com/drive/v2/files/'+id,
                function(error, status, response) {
                    if (!error && status == 200 && response !== undefined) {
                        var downloadUrl = response.downloadUrl;
                        xhrWithAuth(downloadUrl, onSingleLabelContentFetched);
                    }
                });
            }
        } else {
            showButton(config_notfound_info);
            changeState(STATE_START);
        }
    }

    function onSingleLabelContentFetched(error, status, response) {
        if (!error && status == 200 && response !== undefined) {
            console.log("Fetched label: "+response.id);
            available_labels.push(response);
        }

        current_labels_count++;
        if(current_labels_count === total_labels_count) {
            chrome.storage.local.set({'LabelList': JSON.stringify(available_labels)}, function() {
                if (chrome.extension.lastError) {
                    console.log("An error occurred while saving data: " + chrome.extension.lastError.message);
                } else {
                    console.log("Data with key: LabelList saved!");
                    populateLabelList();
                }
            });
        }
    }

    function sendGcmToDevice(deviceId) {
        console.log("Sending gcm");

        var activeTabId;
        var data;

        $(".tab-content div").each(function (){
            if($(this).css("display") == "block"){
                activeTabId = $(this).attr('id');
            }
        });

        if(activeTabId === "tabLink") {
            data = "{\"data\": {" +
            "\"type\":\"link\"," +
            "\"userId\":\""+user_id+"\"," +
            "\"title\":\""+$('#titleLink').val()+"\"," +
            "\"note\":\""+$('#urlLink').val()+"\"," +
            "\"cover_url\":\""+$('#coverLink').val()+"\"," +
            "\"comment\":\""+$('#commentLink').val()+"\"," +
            "\"labelIds\":"+JSON.stringify(selected_labels)+"" +
            "},\"registration_ids\":[\""+deviceId+ "\"]}";
        } else {
            data = "{\"data\": {" +
            "\"type\":\"note\"," +
            "\"userId\":\""+user_id+"\"," +
            "\"title\":\""+$('#titleNote').val()+"\"," +
            "\"note\":\""+$('#textNote').val()+"\"," +
            "\"labelIds\":"+JSON.stringify(selected_labels)+"" +
            "},\"registration_ids\":[\""+deviceId+ "\"]}";
        }

        console.log("GCM data "+data);

        sendGcm(data, function(error, status, response) {
            console.log("Gcm result");
            console.log(error);
            console.log(status);
            console.log(response);

            if(status === 200) {
                showButton(submit_info_success);
                $('html,body').animate({scrollTop: submit_info_success.offset().top}, 'slow', "swing", function() {
                    submit_info_success.fadeOut(1000, function(){window.close()});
                });
            } else {
                showButton(submit_info_error);
                $('html,body').animate({scrollTop: submit_info_error.offset().top}, 'slow');
            }
        });
    }

    function getUserInfo() {
        xhrWithAuth(
            'https://www.googleapis.com/plus/v1/people/me',
            onUserInfoFetched);
    }
    // @corecode_end getProtectedData

    function loadNoteablyConfig() {
        console.log("Loading DeviceGcmField & Labels");
        chrome.storage.local.get(['DeviceGcmField', 'LabelList'], function(result){
            if (result['DeviceGcmField'] === undefined) {
                console.log("DeviceGcmField was not found. Setting refresh tag!");
                refreshDeviceList = true;
            } else {
                device_ids = JSON.parse(result['DeviceGcmField']);
                populateDeviceList();
            }

            if (result['LabelList'] === undefined) {
                console.log("LabelList was not found. Setting refresh tag!");
                refreshLabelsList = true;
            } else {
                available_labels = JSON.parse(result['LabelList']);
                populateLabelList();
            }

            console.log("loadNoteablyConfig finished. " +
            "RefreshDeviceList: "+refreshDeviceList+", RefreshLabelsList: "+refreshLabelsList);
            if(refreshDeviceList || refreshLabelsList)
                refreshNoteablyConfig();
        });

    }

    function populateDeviceList() {
        device_list_div.empty();

        var arrayLength = device_ids.length;
        device_ids.forEach(function(obj) {
            var name = obj.deviceName;
            var buildType = obj.buildType;

            if(buildType === "debug")
                name += " ("+buildType+")";

            device_list_div.append("<div class='device-name' id='"+obj.gcmRegId+"'>"+name+"</div>");
        });

        if(arrayLength === 1)
            hideButton(submit_info);
        else
            showButton(submit_info);
    }

    function populateLabelList() {
        label_list_available.empty();
        var arrayLength = available_labels.length;
        console.log("Populating "+arrayLength+" Labels.");

        available_labels.forEach(function(obj) {
            if(obj.deleted === null || obj.deleted === false)
                label_list_available.append("<div class='label-name' id='"+obj.id+"' style='color:"+obj.color.trim()+";'>"+getParentizedName(obj)+"</div>");
        });

        sortLabel(label_list_available);
        console.log("Populating Labels done.");
    }

    function sortLabel(parent) {
        var labelDivs = parent.children("div");
        console.log("Sorting " + labelDivs.length + " Label divs.");
        labelDivs.sortElements(function (a, b) {
            var contentA = $(a).text();
            var contentB = $(b).text();

            if (contentA < contentB) return -1;
            if (contentA > contentB) return 1;
            return 0;
        });
    }

    function getParentizedName(obj) {
        if(obj.parentLabel !== null && obj.parentLabel !== undefined) {
            var parentName = getParentizedName(obj.parentLabel);
            return parentName+"/"+obj.name;
        } else
            return obj.name;
    }

    function selectLabel(id) {
        var index = selected_labels.indexOf(id);
        if (index === -1)
            selected_labels.push(id);

        var elementID = "#"+id.replace( /(:|\.|\[|\])/g, "\\$1" );
        var element = label_list_available.find(elementID).detach();
        label_list_selected.append(element);
        sortLabel(label_list_selected);
    }

    function deselectLabel(id) {
        var index = selected_labels.indexOf(id);
        if (index > -1)
            selected_labels.splice(index, 1);

        var elementID = "#"+id.replace( /(:|\.|\[|\])/g, "\\$1" );
        var element = label_list_selected.find(elementID).detach();
        label_list_available.append(element);
        sortLabel(label_list_available);
    }

    // Code updating the user interface, when the user information has been
    // fetched or displaying the error.
    function onUserInfoFetched(error, status, response) {
        if (!error && status == 200) {
            changeState(STATE_AUTHTOKEN_ACQUIRED);
            user_id = response.id;
            populateUserInfo(response);
            loadNoteablyConfig();
        } else {
            changeState(STATE_START);
        }
    }

    function populateUserInfo(user_info) {
        user_name_div.text(user_info.displayName);
        fetchImageBytes(user_info);
    }

    function fetchImageBytes(user_info) {
        if (!user_info || !user_info.image || !user_info.image.url) return;
        var xhr = new XMLHttpRequest();
        xhr.open('GET', user_info.image.url, true);
        xhr.responseType = 'blob';
        xhr.onload = onImageFetched;
        xhr.send();
    }

    function onImageFetched(e) {
        if (this.status != 200)
            return;

        var objUrl = window.webkitURL.createObjectURL(this.response);

        var imgElem = document.createElement('img');
        imgElem.src = objUrl;
        imgElem.className = "avatar";
        imgElem.onload = function() {
            window.webkitURL.revokeObjectURL(objUrl);
        };

        $(".user-avatar").append(imgElem);
    }

    /**
     Retrieves a valid token. Since this is initiated by the user
     clicking in the Sign In button, we want it to be interactive -
     ie, when no token is found, the auth window is presented to the user.

     Observe that the token does not need to be cached by the app.
     Chrome caches tokens and takes care of renewing when it is expired.
     In that sense, getAuthToken only goes to the server if there is
     no cached token or if it is expired. If you want to force a new
     token (for example when user changes the password on the service)
     you need to call removeCachedAuthToken()
     **/
    function interactiveSignIn() {
        changeState(STATE_ACQUIRING_AUTHTOKEN);


        // @corecode_begin getAuthToken
        // @description This is the normal flow for authentication/authorization
        // on Google properties. You need to add the oauth2 client_id and scopes
        // to the app manifest. The interactive param indicates if a new window
        // will be opened when the user is not yet authenticated or not.
        // @see http://developer.chrome.com/apps/app_identity.html
        // @see http://developer.chrome.com/apps/identity.html#method-getAuthToken
        chrome.identity.getAuthToken({ 'interactive': true }, function(token) {
            if (chrome.runtime.lastError) {
                console.log(chrome.runtime.lastError);
                changeState(STATE_START);
            } else {
                console.log('Token acquired:'+token+'. See chrome://identity-internals for details.');
                changeState(STATE_AUTHTOKEN_ACQUIRED);
                getUserInfo();
            }
        });
        // @corecode_end getAuthToken
    }

    function revokeToken() {
        user_info_div.innerHTML="";
        chrome.identity.getAuthToken({ 'interactive': false },
            function(current_token) {
                if (!chrome.runtime.lastError) {

                    // @corecode_begin removeAndRevokeAuthToken
                    // @corecode_begin removeCachedAuthToken
                    // Remove the local cached token
                    chrome.identity.removeCachedAuthToken({ token: current_token },
                        function() {});
                    // @corecode_end removeCachedAuthToken


                    // Make a request to revoke token in the server
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'https://accounts.google.com/o/oauth2/revoke?token=' + current_token);
                    xhr.send();
                    // @corecode_end removeAndRevokeAuthToken


                    // Update the user interface accordingly
                    changeState(STATE_START);
                    user_id = undefined;
                    console.log('Token revoked and removed from cache. '+'Check chrome://identity-internals to confirm.');
                }
            });
    }

    return {
        onload: function () {

            send_note_div = jQuery("#send-content");
            user_info_div = jQuery("#user-info");
            user_name_div = jQuery("#user-name");

            label_section = jQuery("#label_section");
            label_section_toggler = jQuery("#toggle-labels");
            label_list_available = jQuery("#label_list_available");
            label_list_selected = jQuery("#label_list_selected");
            device_list_div = jQuery("#device_list");
            submit_info = jQuery("#submit-info");
            config_notfound_info = jQuery("#config-notfound-info");
            submit_info_success = jQuery("#submit-info_success");
            submit_info_error = jQuery("#submit-info_error");

            hideButton(config_notfound_info);
            hideButton(submit_info_success);
            hideButton(submit_info_error);
            hideButton(label_section);

            label_section_toggler.click(function(){
                label_section.slideToggle(400, function() {
                    if($(this).css('display')=='none'){
                        label_section_toggler.children('img').attr('src',"images/ic_expand_more_24px.svg");
                    }else{
                        label_section_toggler.children('img').attr('src',"images/ic_expand_less_24px.svg");
                    }
                });
            });

            signin_button = jQuery("#signin");
            signin_button.click(interactiveSignIn);

            revoke_button = jQuery("#revoke");
            revoke_button.click(revokeToken);

            jQuery("#refresh-devices").click(function(e) {
                refreshDeviceList = true;
                refreshNoteablyConfig();
                e.preventDefault();
            });

            jQuery("#refresh-labels").click(function(e) {
                refreshLabelsList = true;
                refreshLabels();
                e.preventDefault();
            });

            jQuery('.tabs-parent .tab-links a').on('click', function(e)  {
                var currentAttrValue = jQuery(this).attr('href');

                // Show/Hide Tabs
                jQuery('.tab-content ' + currentAttrValue).show().siblings().hide();

                // Change/remove current tab to active
                jQuery(this).parent('li').addClass('active').siblings().removeClass('active');

                e.preventDefault();
            });

            jQuery(document).on('click', ".device-list div", function(){
                var id = jQuery(this).attr("id");
                console.log(id);
                sendGcmToDevice(id);
            });

            jQuery(document).on('click', "#label_list_available div", function(){
                var id = $(this).attr('id');
                selectLabel(id);
            });

            jQuery(document).on('click', "#label_list_selected div", function(){
                var id = $(this).attr('id');
                deselectLabel(id);
            });

            // Trying to get user's info without signing in, it will work if the
            // application was previously authorized by the user.
            getUserInfo();

        }
    };
})();


window.onload = googlePlusUserLoader.onload;


