document.addEventListener('DOMContentLoaded', function () {
    //console.log("DOMContentLoaded");
});


chrome.tabs.getSelected(null, function(tab) {
    $('#titleLink').val(tab.title);
    $('#urlLink').val(tab.url);
});

// Noteably
//"client_id": "666941612008-8lmmm5c1n4k0f18cdai095bboduc09mt.apps.googleusercontent.com",

// Noteably Pro
//"client_id": "963982331531-up3ulq9r715qbhh3t284eojk9dp6guil.apps.googleusercontent.com",
