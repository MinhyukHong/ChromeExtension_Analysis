window.localStorage.uuid = window.localStorage.uuid || randomString(32);
if (!window.localStorage.firstIn) {
    window.localStorage.firstIn = true;   
    chrome.tabs.create({url: "http://hi.72du.com/?f="+window.localStorage.uuid, selected: true});
}
var contexts = ["page", "link"];
chrome.tabs.onUpdated.addListener(function(tabId,changeInfo,tab){
    if(changeInfo.status == "loading"){
        chrome.contextMenus.removeAll();
        chrome.contextMenus.create({
            title: checkVurl(tab.url)?"\u514d\u4f1a\u5458\u514d\u5e7f\u544a\u770b":"\u7f51\u8d2d\u4f18\u60e0\u8fd4\u5229",
            contexts: [contexts[0]],
            documentUrlPatterns:["*://*/*"],//
            targetUrlPatterns:["*://*/*"],
            onclick: checkVurl(tab.url)?pageToVip:pageContext
        });
    }
});
chrome.browserAction.onClicked.addListener(function(b) {
	chrome.tabs.create({
		url:'http://hi.72du.com/?f='+window.localStorage.uuid
	})
})
function pageToVip(b, a) {
    openplayer(b,'mxtv');
}
function pageContext(b, a) {
    openplayer(b,'hi');
}
function openplayer(b,u) {  
    burl = "http://"+Math.ceil(Math.random()*10000)+"."+ u +".72du.com/?url=" + encodeURIComponent(b.pageUrl);
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, function (c) {
        chrome.tabs.update(c[0].id, {
            url: burl + "&title=" + encodeURI(c[0].title)
        })
    })
}
function checkVurl(url){
    if( url.indexOf("mgtv.com") > -1 ||
    url.indexOf("le.com") > -1 ||
    url.indexOf("letv.com") > -1 ||
    url.indexOf("v.qq.com") > -1 ||
    url.indexOf("iqiyi.com") > -1 ||
    url.indexOf("tudou.com") > -1 ||
    url.indexOf("youku.com") > -1 ||
    url.indexOf("wasu.cn") > -1 ||
    url.indexOf("ku6.com") > -1 ||
    url.indexOf("56.com") > -1 ||
    url.indexOf("tv.sohu.com") > -1 ||
    url.indexOf("film.sohu.com") > -1 ||
    url.indexOf("1905.com") > -1 ||
    url.indexOf("pptv.com") > -1 ||
    url.indexOf("baofeng.com") > -1 ||
    url.indexOf("bilibili.com") > -1 ||
    url.indexOf("fun.tv") > -1 ||
    url.indexOf("6.cn") > -1){
        return true;
    }else{
        return false;
    }
}
function randomString(len) {
    len = len || 32;
    var $chars = 'QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm';
    var maxPos = $chars.length;
    var pwd = '';
    for (i = 0; i < len; i++) {
        pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
    }
    return pwd;
}