var DailyLimit = 3;
var SignupPage = 'https://tacticalarbitrage.threecolts.com/dashboard';

function getProductAsin (url) {
    var reg = /\/(B\d{2}\w{7}|B\d{1}\w{8}|\d{9}(X|\d)|\d{9}|\d{8})/;
    while ((myArray = reg.exec(url)) != null) {
        return myArray[1];
    }
    return '';
}
function getAmazonDomain (url) {
    var reg = /amazon.(\w+\.?\w*)\//;
    while ((myArray = reg.exec(url)) != null) {
        return myArray[1];
    };
    return 'com';
}
function PrepareBody () {
    jQuery('body').css({
        height: 'auto',
        width: 'auto',
        'min-width': '400px',
        padding: '10px'
    });
    jQuery('body').html('');
}
function BodyLoading () {
    jQuery('body').css({
        height: '50px',
        width: '50px',
        'min-width': '50px',
        padding: '0'
    });
    jQuery('body').html('<img class="main-loader" src="../images/loader_small.svg" style="height:50px;" />');
    jQuery('body').append('<div id="status" style="text-align: center;width: 50px;"></div>')
}

function stop_process (ASIN) {
    jQuery.ajax({
        url: 'https://api.tacticalarbitrage.com/',
        type: 'POST',
        async: true,
        contentType: 'application/x-www-form-urlencoded',
        data: {
            ASIN: ASIN,
            action: 'stop_process',
            check_key: 'iTAaKb5Bc3RtQEFUGGWGdgNVDr41HwlR4Gd9N0c8WIexiZUB66Wd4wviLDGY3jVZlUwDWZX1ejwAyRRXVVgtQ5AWYvvoWlP6ui2lXAiO'
        },
        success: function (data) {
            localStorage['active_process'] = 'no';
            jQuery('body').find('#status').html('');
            window.location.reload();
        },
        error: function (request, status, error) {
            localStorage['active_process'] = 'no';
            jQuery('body').find('#status').html('');
            window.location.reload();
        }
    });
}

function get_status (ASIN, lastPage, start) {
    if (jQuery('body').find('.main-loader').length > 0) {

        $("#stop").unbind('click');
        jQuery('body').on('click', '#stop', function () {
            stop_process(ASIN);
        });

        jQuery.ajax({
            url: 'https://api.tacticalarbitrage.com/',
            type: 'POST',
            async: true,
            contentType: 'application/x-www-form-urlencoded',
            data: {
                ASIN: ASIN,
                action: 'check_reviews_status',
                check_key: 'iTAaKb5Bc3RtQEFUGGWGdgNVDr41HwlR4Gd9N0c8WIexiZUB66Wd4wviLDGY3jVZlUwDWZX1ejwAyRRXVVgtQ5AWYvvoWlP6ui2lXAiO'
            },
            success: function (data) {
                if (data != '') {
                    if (data != '') {
                        jQuery('body').find('#status').html('Page ' + data + '/' + lastPage);
                        jQuery('body').find('#status').append('<p><a id="stop" href="javascript:void(0)">Stop Scan</a></p>');
                    }
                } else if (start) {
                    localStorage['active_process'] = 'no';
                    Success();
                }
            },
            error: function (request, status, error) {
                if (request.responseText != '') {
                    if (request.responseText != '') {
                        jQuery('body').find('#status').html('Page ' + request.responseText + '/' + lastPage);
                        jQuery('body').find('#status').append('<p><a id="stop" href="javascript:void(0)">Stop Scan</a></p>');
                    }
                } else if (start) {
                    localStorage['active_process'] = 'no';
                    Success();
                }
            }
        })
    }
}
function Success () {
    var get_info = function (ASIN, domain) {
        var pages_number = 1;
        // below doesn't work due to extension restrictions (no external requests allowed)
        jQuery.ajax({
            // https://www.amazon.com/product-reviews/B08BBB2ZWT/ref=cm_cr_dp_see_all_summary?ie=UTF8&showViewpoints=1&sortBy=helpful
            url: 'https://www.amazon.' + domain + '/product-reviews/' + ASIN + '/ref=cm_cr_dp_see_all_summary?ie=UTF8&showViewpoints=1&sortBy=helpful',
            method: 'get',
            success: function (data) {

                if (!isNaN(jQuery(data).find('.a-pagination li:last-child').prev().children().html())) {
                    pages_number = parseInt(jQuery(data).find('.a-pagination li:last-child').prev().children().html());
                }

                if (isNaN(pages_number)) {
                    var total_reviews = jQuery(data).find('.totalReviewCount').html();
                    if (total_reviews) {
                        total_reviews = total_reviews.replace(/,/g, '');
                        total_reviews = parseInt(total_reviews);
                        pages_number = Math.ceil(total_reviews / 10);
                    }
                }

                if (isNaN(pages_number)) {
                    var review_count_html = jQuery(data).find('*[data-hook="cr-filter-info-review-count"]').html();
                    if (review_count_html) {
                        // Showing 1-10 of 329 reviews
                        var tmp_arr = review_count_html.split(' of ');
                        if (tmp_arr.length > 0) {
                            var matches = tmp_arr[1].match(/\d+\,?\d*/);
                            if (matches) {
                                var total_reviews = matches[0].replace(/,/g, '');
                                //console.log('total_reviews [1]: ' + total_reviews);
                                total_reviews = parseInt(total_reviews);
                                pages_number = Math.ceil(total_reviews / 10);
                            }
                        }
                    }
                }

                if (isNaN(pages_number)) {
                    var review_count_html = jQuery(data).find('*[data-hook="cr-filter-info-review-rating-count"]').html();
                    if (review_count_html) {
                        // 3,356 global ratings | 841 global reviews
                        var tmp_arr = review_count_html.split(' | ');
                        if (tmp_arr.length > 1) {
                            var matches = tmp_arr[1].match(/\d+\,?\d*/);
                            if (matches) {
                                var total_reviews = matches[0].replace(/,/g, '');
                                //console.log('total_reviews [2]: ' + total_reviews);
                                total_reviews = parseInt(total_reviews);
                                pages_number = Math.ceil(total_reviews / 10);
                            }
                        }
                        // 5,898 total ratings, 936 with reviews
                        if (isNaN(pages_number)) {
                            var tmp_arr = review_count_html.split(', ');
                            if (tmp_arr.length > 1) {
                                var matches = tmp_arr[1].match(/\d+\,?\d*/);
                                if (matches) {
                                    var total_reviews = matches[0].replace(/,/g, '');
                                    //console.log('total_reviews [3]: ' + total_reviews);
                                    total_reviews = parseInt(total_reviews);
                                    pages_number = Math.ceil(total_reviews / 10);
                                }
                            }
                        }
                    }
                }

                PrepareBody();

                if (isNaN(pages_number) || (pages_number == 0)) {
                    jQuery('body').html('No reviews found for this product.');
                } else {
                    jQuery('body').html('How many pages of reviews to analyze?<input type="text" id="how_many" value="1"> <input type="button" value="Analyze" class="scrape">');  
                }
            }
        });
        jQuery('body').on('click', '.scrape', function () {
            var lastPage = parseInt(jQuery('#how_many').val());
            if (lastPage < 1) {
                lastPage = 1;
            }
            if (lastPage > 100) {
                lastPage = 100;
            };
            BodyLoading();
            localStorage['active_process'] = 'yes';
            localStorage['lastPage'] = lastPage;
            localStorage['ASIN'] = ASIN;
            localStorage['domain'] = domain;
            setInterval(function () {
                get_status(ASIN, lastPage, false)
            }, 4000);
            jQuery.ajax({
                url: 'https://tacticalarbitrage.com/API/',
                type: 'POST',
                async: true,
                contentType: 'application/x-www-form-urlencoded',
                data: {
                    ASIN: ASIN,
                    domain: domain,
                    action: 'get_product_options_from_reviews',
                    lastPage: lastPage,
                    check_key: 'iTAaKb5Bc3RtQEFUGGWGdgNVDr41HwlR4Gd9N0c8WIexiZUB66Wd4wviLDGY3jVZlUwDWZX1ejwAyRRXVVgtQ5AWYvvoWlP6ui2lXAiO'
                },
                success: function (data) {
                    localStorage['active_process'] = 'no';
                    if (data != '') {
                        if (data == 'server error') {
                            PrepareBody();
                            jQuery('body').html('Sorry. Analyze was aborted by Amazon.')
                        } else {
                            PrepareBody();
                            jQuery('body').html(data);
                        }
                    } else {
                        WrongProductMsg();
                    }
                },
                error: function (request, status, error) {
                    localStorage['active_process'] = 'no';
                    if (request.responseText != '') {
                        if (request.responseText == 'server error') {
                            PrepareBody();
                            jQuery('body').html('Sorry. Analyze was aborted by Amazon.');
                        } else {
                            PrepareBody();
                            jQuery('body').html(request.responseText);
                        }
                    } else {
                        WrongProductMsg();
                    }
                }
            })
        })
    };
    var ASIN = '';
    chrome.tabs.query({
        'active': true,
        'currentWindow': true
    }, function (tabs) {
        if (tabs.length > 0 && tabs[0].url) {
            ASIN = getProductAsin(tabs[0].url);
            if (tabs[0].url.indexOf('amazon.') != -1 && ASIN != '') {
                domain = getAmazonDomain(tabs[0].url);
                jQuery.ajax({
                    url: 'https://tacticalarbitrage.com/API/',
                    type: 'POST',
                    contentType: 'application/x-www-form-urlencoded',
                    data: {
                        ASIN: ASIN,
                        action: 'check_reviews_results',
                        check_key: 'iTAaKb5Bc3RtQEFUGGWGdgNVDr41HwlR4Gd9N0c8WIexiZUB66Wd4wviLDGY3jVZlUwDWZX1ejwAyRRXVVgtQ5AWYvvoWlP6ui2lXAiO'
                    },
                    success: function (data) {
                        if (data != '') {
                            localStorage['active_process'] = 'no';
                            PrepareBody();
                            jQuery('body').append('<p><a href="javascript:void(0)" id="rescan">Rescan?</a></p>');
                            jQuery('body').append(data);
                            jQuery('body').on('click', '#rescan', function () {
                                BodyLoading();
                                get_info(ASIN, domain);
                            })
                        } else {
                            get_info(ASIN, domain);
                        }
                    },
                    error: function (request, status, error) {
                        if (request.responseText != '') {
                            localStorage['active_process'] = 'no';
                            PrepareBody();
                            jQuery('body').append('<p><a href="javascript:void(0)" id="rescan">Rescan?</a></p>');
                            jQuery('body').append(request.responseText);
                            jQuery('body').on('click', '#rescan', function () {
                                BodyLoading();
                                get_info(ASIN, domain);
                            })
                        } else {
                            get_info(ASIN, domain);
                        }
                    }
                })
            } else {
                console.log(tabs[0]);
                WrongPageMsg();
            }
        } else {
            console.error("No active tab found.");
            console.log(tabs);
        }
    })
}
function Trial () {
    var _date = new Date();
    var _getdate = _date['getDate']();
    var _getMonth = _date['getMonth']() + 1;
    var _getFullYear = _date['getFullYear']();
    var _localStorage = localStorage[_getdate + '-' + _getMonth + '-' + _getFullYear];
    if (!_localStorage) {
        _localStorage = 0;
    } else {
        _localStorage++;
    };
    localStorage[_getdate + '-' + _getMonth + '-' + _getFullYear] = _localStorage;
    if (_localStorage > DailyLimit) {
        TrialMsg();
    } else {
        Success();
    }
}
function TrialMsg () {
    chrome.tabs['executeScript'](null, {
        file: 'js/executeTrialMessage.js'
    }, function () {
        if (chrome['extension']['lastError']) {
            alert(chrome['extension']['lastError']['message']);
        }
    })
}
function WrongPageMsg () {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs.length > 0) {
            const tab = tabs[0];
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ["js/executeWrongPageMessage.js"]
            }, function() {
                if (chrome.runtime.lastError) {
                    alert(chrome.runtime.lastError.message);
                }
            });
        } else {
            console.error("No active tab found.");
        }
    });
}
function WrongProductMsg () {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs.length > 0) {
            const tab = tabs[0];
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ["js/executeWrongProductMessage.js"]
            }, function() {
                if (chrome.runtime.lastError) {
                    alert(chrome.runtime.lastError.message);
                }
            });
        } else {
            console.error("No active tab found.");
        }
    });
}
function ActiveProcessMsg () {
    chrome.scripting.executeScript(null, {
        code: 'var ASIN = "' + localStorage['ASIN'] + '"; var domain = "' + localStorage['domain'] + '";'
    }, function () {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            if (tabs.length > 0) {
                const tab = tabs[0];
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ["js/executeActiveProcess.js"]
                }, function() {
                    if (chrome.runtime.lastError) {
                        alert(chrome.runtime.lastError.message);
                    }
                });
            } else {
                console.error("No active tab found.");
            }
        });
    });
}
function getCookie (cookieName) {
    var documentCookie = '; ' + document['cookie'];
    var cookies = documentCookie['split']('; ' + cookieName + '=');
    if (cookies.length == 2) {
        return decodeURIComponent(cookies['pop']()['split'](';')['shift']());
    }
}
function setCookie (cookieName, value, expiresAfter) {
    var now = new Date();
    now['setTime'](now['getTime']() + (expiresAfter * 1000));
    var expires = 'expires=' + now['toUTCString']();
    document['cookie'] = cookieName + '=' + value + '; ' + expires;
}
jQuery(document)['ready'](function () {
    chrome.permissions.contains({
        permissions: ['activeTab','cookies'],
        origins: ["https://tacticalarbitrage.com/*",
            "https://api.tacticalarbitrage.com/*"]
    }, function(result) {
        if (result) {
            init();
        } else {
            PrepareBody();
            jQuery('body').html('<p>Please, <input type="button" value="Allow" id="allow-permissions" class="scrape"> browser to access TA site</p>');
            jQuery('#allow-permissions').click(requestPermissions);
        }
    });

    chrome.runtime.onMessage.addListener(function (event) {
        if (event['action'] == 'closeLoader') {
            window['close']();
        }
    })
})

function requestPermissions(){
    chrome.permissions.request({
        permissions: ['activeTab','cookies'],
        origins: [
            "https://tacticalarbitrage.com/*",
            "https://api.tacticalarbitrage.com/*",
            "https://tacticalarbitrage.threecolts.com/*"
        ]
    }, function(granted) {
        if (granted) {
            init();
        }else{
            console.log('Permissions not granted');
        }
        window.close();
    });
}

function init(){

    chrome['cookies']['get']({
        "url": SignupPage,
        "name": 'active'
    }, function (event) {
        if (localStorage['active_process'] == 'yes') {
            chrome.tabs.query({
                'active': true
            }, function (tabs) {
                ASIN = getProductAsin(tabs[0].url);
                if (ASIN == localStorage['ASIN']) {
                    BodyLoading();
                    setInterval(function () {
                        get_status(localStorage['ASIN'], localStorage['lastPage'], true)
                    }, 3000);
                } else {
                    /*ActiveProcessMsg();*/
                    /* Cancel active process and start new */
                    stop_process(localStorage['ASIN']);
                }
            })
        } else {
            jQuery.get(SignupPage, function (page) {
                page = jQuery(page);
                if (page.find('title:contains("Tactical Arbitrage")').length == 0) {
                    localStorage['paid'] = 1;
                    Success();
                } else {
                    localStorage['paid'] = 0;
                    Trial();
                }
            }).fail(function () {
                localStorage['paid'] = 0;
                Trial();
            })
        }
    });

}