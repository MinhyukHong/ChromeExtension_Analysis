var result = confirm('You have reached the daily limit of 3 usages.\nWould you like to buy a license for unlimited access or login into your account?');
if (result == true) {
    window['open']('https://tacticalarbitrage.threecolts.com/', '_blank');
}