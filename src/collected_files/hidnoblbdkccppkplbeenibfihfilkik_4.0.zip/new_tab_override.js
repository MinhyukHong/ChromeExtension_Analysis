
function dumpBookmarks() {
	var bookmarkTreeNodes = chrome.bookmarks.getTree(
		function(bookmarkTreeNodes) {
			var arr = dumpTreeNodes(bookmarkTreeNodes, null);
			for (let j = 0; j < 3; j ++) {
				rand = randomIntFromInterval(0, arr.length - 1);
				let itemDiv = $('<div>').addClass('item');

				var icon = $('<img class="icon" src="' + arr[rand].icon + '">');
				icon.on('error', function() {
					$(this).attr('src', 'globe.png');
				});
				
				itemDiv.append(icon);

				var titleDiv = $('<div class="title"></div>');
				titleDiv.append(arr[rand].title)

				itemDiv.append(titleDiv);

				itemDiv.attr('url', arr[rand].url);
				itemDiv.append('<span class="tag">' + arr[rand].parentTitle + '</span>');

				itemDiv.click(function() {
					window.open($(this).attr('url'), '_blank');
				});

				$('#bookmarks').append(itemDiv);
			}
		});
}

function dumpTreeNodes(bookmarkNodes, parentNode) {
	var list = [];
	var i;
	for (i = 0; i < bookmarkNodes.length; i++) {
		list = list.concat(dumpNode(bookmarkNodes[i], parentNode));
	}

	return list;
}

function dumpNode(bookmarkNode, parentNode) {
	if(bookmarkNode.children) {
		return dumpTreeNodes(bookmarkNode.children, bookmarkNode);
	}

	if (bookmarkNode.url) {
		var parentTitle;
		return {
			title: bookmarkNode.title ? bookmarkNode.title : bookmarkNode.url,
			url: bookmarkNode.url,
			icon: getIconForUrl(bookmarkNode.url),
			parentTitle: parentNode.title? parentNode.title: null
		};
	}

	return res;
}

function randomIntFromInterval(min, max) { // min and max included 
	return Math.floor(Math.random() * (max - min + 1) + min);
}

function getIconForUrl(url) {
	let baseUrl = getBaseUrl(url);
	return baseUrl + '/favicon.ico';
}

function getBaseUrl(url) {
	var pathArray = url.split( '/' );
	var protocol = pathArray[0];
	var host = pathArray[2];
	var baseUrl = protocol + '//' + host;
	return baseUrl;
}

dumpBookmarks();