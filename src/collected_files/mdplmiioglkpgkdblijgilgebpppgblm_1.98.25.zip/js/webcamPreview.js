function delay(ms) {
	return new Promise(resolve => setTimeout(resolve, ms))
}

// eslint-disable-next-line no-undef
chrome.storage.local.get('videoDeviceId', function (result) {
	window.navigator.mediaDevices
		.getUserMedia({
			video: {width: 320, height: 240, deviceId: result.videoDeviceId},
		})
		.then(async function (stream) {
			let videoElement
			while (!videoElement) {
				videoElement = document.getElementById('webcam-preview')
				if (videoElement) break
				await delay(100)
			}
			videoElement.srcObject = stream
			window.parent.postMessage({name: 'webcamPreviewStarted'}, '*')
		})
		.catch(function (error) {
			console.log(error)
			if (error.message === 'Permission denied') {
				error = new Error('Could not get webcam')
			}
			window.parent.postMessage({name: 'webcamPreviewFailed', error}, '*')
		})
})
