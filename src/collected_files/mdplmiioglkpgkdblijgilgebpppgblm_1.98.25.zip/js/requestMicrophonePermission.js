window.navigator.mediaDevices
	.getUserMedia({
		audio: true,
	})
	.then(function (stream) {
		stream.getTracks().forEach(track => track.stop())
		window.parent.postMessage({name: 'microphonePermission', granted: true}, '*')
	})
	.catch(function (error) {
		window.parent.postMessage({name: 'microphonePermission', granted: false, reason: error.message}, '*')
	})
