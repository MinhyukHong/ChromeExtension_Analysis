const __vite__fileDeps=["js/ui/index.umd.js","js/ui/analytics.js","css/analytics.css"],__vite__mapDeps=i=>i.map(i=>__vite__fileDeps[i]);
import{aK as n,aL as a,J as o}from"./analytics.js";function u(i){return n(this,void 0,void 0,function(){var t;return a(this,function(e){switch(e.label){case 0:return[4,o(()=>import("./index.umd.js").then(r=>r.i),__vite__mapDeps([0,1,2]))];case 1:return t=e.sent(),i._plugins=t,[2]}})})}export{u as loadLegacyVideoPlugins};
//# sourceMappingURL=index5.js.map
