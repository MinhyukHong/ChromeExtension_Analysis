import{O as o}from"./analytics.js";const p=()=>({productName:"Bug Capture",productIcon:"mono/bug-capture",productUrl:o});export{p as u};
//# sourceMappingURL=useProductInfo.js.map
