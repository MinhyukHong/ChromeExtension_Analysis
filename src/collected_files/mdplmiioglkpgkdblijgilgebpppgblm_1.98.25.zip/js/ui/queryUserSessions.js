var m={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"queryUserSessions"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"collectionId"}},type:{kind:"NamedType",name:{kind:"Name",value:"uuid"}},directives:[]}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"userSessionsList"},arguments:[{kind:"Argument",name:{kind:"Name",value:"where"},value:{kind:"ObjectValue",fields:[{kind:"ObjectField",name:{kind:"Name",value:"collectionId"},value:{kind:"ObjectValue",fields:[{kind:"ObjectField",name:{kind:"Name",value:"_eq"},value:{kind:"Variable",name:{kind:"Name",value:"collectionId"}}}]}}]}},{kind:"Argument",name:{kind:"Name",value:"order_by"},value:{kind:"ObjectValue",fields:[{kind:"ObjectField",name:{kind:"Name",value:"uploadedAt"},value:{kind:"EnumValue",value:"desc"}}]}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"hostname"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"uploadedAt"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"title"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"ownerId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"ownerName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"uploaderEmail"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"uploadMethod"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"labels"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"color"},arguments:[],directives:[]}]}}]}},{kind:"Field",name:{kind:"Name",value:"integrations"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"state"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"url"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"type"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"commentId"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"assignees"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"user"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"email"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"name"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"avatar"},arguments:[],directives:[]}]}}]}}]}}]}}],loc:{start:0,end:423}};m.loc.source={body:`query queryUserSessions($collectionId: uuid) {
	userSessionsList(where: {collectionId: {_eq: $collectionId}}, order_by: {uploadedAt: desc}) {
		id
		hostname
		uploadedAt
		title
		ownerId
		ownerName
		uploaderEmail
		uploadMethod
		labels {
			label {
				id
				label
				color
			}
		}
		integrations {
			state
			url
			type
			commentId
		}
		assignees {
			user {
				id
				email
				name
				avatar
			}
		}
	}
}
`,name:"GraphQL request",locationOffset:{line:1,column:1}};function s(e,i){if(e.kind==="FragmentSpread")i.add(e.name.value);else if(e.kind==="VariableDefinition"){var n=e.type;n.kind==="NamedType"&&i.add(n.name.value)}e.selectionSet&&e.selectionSet.selections.forEach(function(t){s(t,i)}),e.variableDefinitions&&e.variableDefinitions.forEach(function(t){s(t,i)}),e.definitions&&e.definitions.forEach(function(t){s(t,i)})}var u={};(function(){m.definitions.forEach(function(i){if(i.name){var n=new Set;s(i,n),u[i.name.value]=n}})})();function o(e,i){for(var n=0;n<e.definitions.length;n++){var t=e.definitions[n];if(t.name&&t.name.value==i)return t}}function k(e,i){var n={kind:e.kind,definitions:[o(e,i)]};e.hasOwnProperty("loc")&&(n.loc=e.loc);var t=u[i]||new Set,r=new Set,d=new Set;for(t.forEach(function(a){d.add(a)});d.size>0;){var c=d;d=new Set,c.forEach(function(a){if(!r.has(a)){r.add(a);var l=u[a]||new Set;l.forEach(function(v){d.add(v)})}})}return r.forEach(function(a){var l=o(e,a);l&&n.definitions.push(l)}),n}k(m,"queryUserSessions");export{m as d};
//# sourceMappingURL=queryUserSessions.js.map
