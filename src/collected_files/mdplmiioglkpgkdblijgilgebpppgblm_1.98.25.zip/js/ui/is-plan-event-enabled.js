function l(e,d){var o,i;return typeof(d==null?void 0:d.enabled)=="boolean"?d.enabled:(i=(o=e==null?void 0:e.__default)===null||o===void 0?void 0:o.enabled)!==null&&i!==void 0?i:!0}export{l as i};
//# sourceMappingURL=is-plan-event-enabled.js.map
