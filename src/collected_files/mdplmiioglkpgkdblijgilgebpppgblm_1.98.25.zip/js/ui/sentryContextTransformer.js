function f(c){const t={};return Object.entries(c).forEach(([e,r])=>{t[e]={},Object.entries(r).forEach(([n,o])=>{t[e][n]=JSON.stringify(o)})}),t}export{f as default};
//# sourceMappingURL=sentryContextTransformer.js.map
