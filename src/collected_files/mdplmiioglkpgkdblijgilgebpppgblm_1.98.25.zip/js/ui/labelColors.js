const o=["#67C4FF","#3561EC","#BD31FF","#FD5252","#FF9141","#FECE2F","#BDFFCC","#00BA77","#00AFBA","#8790A3","#C1CBDC","#EAF5FF"];function t(){const F=Math.floor(Math.random()*o.length);return o[F]}export{o as defaultLabelColorPalette,t as getRandomLabelColor};
//# sourceMappingURL=labelColors.js.map
