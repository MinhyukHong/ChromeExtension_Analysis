var Ps = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Os(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var xr = { exports: {} };
(function(e, t) {
  (function(n, r) {
    r(e);
  })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : Ps, function(n) {
    var r, s;
    if (!((s = (r = globalThis.chrome) == null ? void 0 : r.runtime) != null && s.id))
      throw new Error("This script should only be loaded in a browser extension.");
    if (typeof globalThis.browser > "u" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
      const i = "The message port closed before a response was received.", o = (a) => {
        const c = {
          alarms: {
            clear: {
              minArgs: 0,
              maxArgs: 1
            },
            clearAll: {
              minArgs: 0,
              maxArgs: 0
            },
            get: {
              minArgs: 0,
              maxArgs: 1
            },
            getAll: {
              minArgs: 0,
              maxArgs: 0
            }
          },
          bookmarks: {
            create: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            getChildren: {
              minArgs: 1,
              maxArgs: 1
            },
            getRecent: {
              minArgs: 1,
              maxArgs: 1
            },
            getSubTree: {
              minArgs: 1,
              maxArgs: 1
            },
            getTree: {
              minArgs: 0,
              maxArgs: 0
            },
            move: {
              minArgs: 2,
              maxArgs: 2
            },
            remove: {
              minArgs: 1,
              maxArgs: 1
            },
            removeTree: {
              minArgs: 1,
              maxArgs: 1
            },
            search: {
              minArgs: 1,
              maxArgs: 1
            },
            update: {
              minArgs: 2,
              maxArgs: 2
            }
          },
          browserAction: {
            disable: {
              minArgs: 0,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            enable: {
              minArgs: 0,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            getBadgeBackgroundColor: {
              minArgs: 1,
              maxArgs: 1
            },
            getBadgeText: {
              minArgs: 1,
              maxArgs: 1
            },
            getPopup: {
              minArgs: 1,
              maxArgs: 1
            },
            getTitle: {
              minArgs: 1,
              maxArgs: 1
            },
            openPopup: {
              minArgs: 0,
              maxArgs: 0
            },
            setBadgeBackgroundColor: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            setBadgeText: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            setIcon: {
              minArgs: 1,
              maxArgs: 1
            },
            setPopup: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            setTitle: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            }
          },
          browsingData: {
            remove: {
              minArgs: 2,
              maxArgs: 2
            },
            removeCache: {
              minArgs: 1,
              maxArgs: 1
            },
            removeCookies: {
              minArgs: 1,
              maxArgs: 1
            },
            removeDownloads: {
              minArgs: 1,
              maxArgs: 1
            },
            removeFormData: {
              minArgs: 1,
              maxArgs: 1
            },
            removeHistory: {
              minArgs: 1,
              maxArgs: 1
            },
            removeLocalStorage: {
              minArgs: 1,
              maxArgs: 1
            },
            removePasswords: {
              minArgs: 1,
              maxArgs: 1
            },
            removePluginData: {
              minArgs: 1,
              maxArgs: 1
            },
            settings: {
              minArgs: 0,
              maxArgs: 0
            }
          },
          commands: {
            getAll: {
              minArgs: 0,
              maxArgs: 0
            }
          },
          contextMenus: {
            remove: {
              minArgs: 1,
              maxArgs: 1
            },
            removeAll: {
              minArgs: 0,
              maxArgs: 0
            },
            update: {
              minArgs: 2,
              maxArgs: 2
            }
          },
          cookies: {
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            getAll: {
              minArgs: 1,
              maxArgs: 1
            },
            getAllCookieStores: {
              minArgs: 0,
              maxArgs: 0
            },
            remove: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          },
          devtools: {
            inspectedWindow: {
              eval: {
                minArgs: 1,
                maxArgs: 2,
                singleCallbackArg: !1
              }
            },
            panels: {
              create: {
                minArgs: 3,
                maxArgs: 3,
                singleCallbackArg: !0
              },
              elements: {
                createSidebarPane: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            }
          },
          downloads: {
            cancel: {
              minArgs: 1,
              maxArgs: 1
            },
            download: {
              minArgs: 1,
              maxArgs: 1
            },
            erase: {
              minArgs: 1,
              maxArgs: 1
            },
            getFileIcon: {
              minArgs: 1,
              maxArgs: 2
            },
            open: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            pause: {
              minArgs: 1,
              maxArgs: 1
            },
            removeFile: {
              minArgs: 1,
              maxArgs: 1
            },
            resume: {
              minArgs: 1,
              maxArgs: 1
            },
            search: {
              minArgs: 1,
              maxArgs: 1
            },
            show: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            }
          },
          extension: {
            isAllowedFileSchemeAccess: {
              minArgs: 0,
              maxArgs: 0
            },
            isAllowedIncognitoAccess: {
              minArgs: 0,
              maxArgs: 0
            }
          },
          history: {
            addUrl: {
              minArgs: 1,
              maxArgs: 1
            },
            deleteAll: {
              minArgs: 0,
              maxArgs: 0
            },
            deleteRange: {
              minArgs: 1,
              maxArgs: 1
            },
            deleteUrl: {
              minArgs: 1,
              maxArgs: 1
            },
            getVisits: {
              minArgs: 1,
              maxArgs: 1
            },
            search: {
              minArgs: 1,
              maxArgs: 1
            }
          },
          i18n: {
            detectLanguage: {
              minArgs: 1,
              maxArgs: 1
            },
            getAcceptLanguages: {
              minArgs: 0,
              maxArgs: 0
            }
          },
          identity: {
            launchWebAuthFlow: {
              minArgs: 1,
              maxArgs: 1
            }
          },
          idle: {
            queryState: {
              minArgs: 1,
              maxArgs: 1
            }
          },
          management: {
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            getAll: {
              minArgs: 0,
              maxArgs: 0
            },
            getSelf: {
              minArgs: 0,
              maxArgs: 0
            },
            setEnabled: {
              minArgs: 2,
              maxArgs: 2
            },
            uninstallSelf: {
              minArgs: 0,
              maxArgs: 1
            }
          },
          notifications: {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            create: {
              minArgs: 1,
              maxArgs: 2
            },
            getAll: {
              minArgs: 0,
              maxArgs: 0
            },
            getPermissionLevel: {
              minArgs: 0,
              maxArgs: 0
            },
            update: {
              minArgs: 2,
              maxArgs: 2
            }
          },
          pageAction: {
            getPopup: {
              minArgs: 1,
              maxArgs: 1
            },
            getTitle: {
              minArgs: 1,
              maxArgs: 1
            },
            hide: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            setIcon: {
              minArgs: 1,
              maxArgs: 1
            },
            setPopup: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            setTitle: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            },
            show: {
              minArgs: 1,
              maxArgs: 1,
              fallbackToNoCallback: !0
            }
          },
          permissions: {
            contains: {
              minArgs: 1,
              maxArgs: 1
            },
            getAll: {
              minArgs: 0,
              maxArgs: 0
            },
            remove: {
              minArgs: 1,
              maxArgs: 1
            },
            request: {
              minArgs: 1,
              maxArgs: 1
            }
          },
          runtime: {
            getBackgroundPage: {
              minArgs: 0,
              maxArgs: 0
            },
            getPlatformInfo: {
              minArgs: 0,
              maxArgs: 0
            },
            openOptionsPage: {
              minArgs: 0,
              maxArgs: 0
            },
            requestUpdateCheck: {
              minArgs: 0,
              maxArgs: 0
            },
            sendMessage: {
              minArgs: 1,
              maxArgs: 3
            },
            sendNativeMessage: {
              minArgs: 2,
              maxArgs: 2
            },
            setUninstallURL: {
              minArgs: 1,
              maxArgs: 1
            }
          },
          sessions: {
            getDevices: {
              minArgs: 0,
              maxArgs: 1
            },
            getRecentlyClosed: {
              minArgs: 0,
              maxArgs: 1
            },
            restore: {
              minArgs: 0,
              maxArgs: 1
            }
          },
          storage: {
            local: {
              clear: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getBytesInUse: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            managed: {
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getBytesInUse: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            sync: {
              clear: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getBytesInUse: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            }
          },
          tabs: {
            captureVisibleTab: {
              minArgs: 0,
              maxArgs: 2
            },
            create: {
              minArgs: 1,
              maxArgs: 1
            },
            detectLanguage: {
              minArgs: 0,
              maxArgs: 1
            },
            discard: {
              minArgs: 0,
              maxArgs: 1
            },
            duplicate: {
              minArgs: 1,
              maxArgs: 1
            },
            executeScript: {
              minArgs: 1,
              maxArgs: 2
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            getCurrent: {
              minArgs: 0,
              maxArgs: 0
            },
            getZoom: {
              minArgs: 0,
              maxArgs: 1
            },
            getZoomSettings: {
              minArgs: 0,
              maxArgs: 1
            },
            goBack: {
              minArgs: 0,
              maxArgs: 1
            },
            goForward: {
              minArgs: 0,
              maxArgs: 1
            },
            highlight: {
              minArgs: 1,
              maxArgs: 1
            },
            insertCSS: {
              minArgs: 1,
              maxArgs: 2
            },
            move: {
              minArgs: 2,
              maxArgs: 2
            },
            query: {
              minArgs: 1,
              maxArgs: 1
            },
            reload: {
              minArgs: 0,
              maxArgs: 2
            },
            remove: {
              minArgs: 1,
              maxArgs: 1
            },
            removeCSS: {
              minArgs: 1,
              maxArgs: 2
            },
            sendMessage: {
              minArgs: 2,
              maxArgs: 3
            },
            setZoom: {
              minArgs: 1,
              maxArgs: 2
            },
            setZoomSettings: {
              minArgs: 1,
              maxArgs: 2
            },
            update: {
              minArgs: 1,
              maxArgs: 2
            }
          },
          topSites: {
            get: {
              minArgs: 0,
              maxArgs: 0
            }
          },
          webNavigation: {
            getAllFrames: {
              minArgs: 1,
              maxArgs: 1
            },
            getFrame: {
              minArgs: 1,
              maxArgs: 1
            }
          },
          webRequest: {
            handlerBehaviorChanged: {
              minArgs: 0,
              maxArgs: 0
            }
          },
          windows: {
            create: {
              minArgs: 0,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 2
            },
            getAll: {
              minArgs: 0,
              maxArgs: 1
            },
            getCurrent: {
              minArgs: 0,
              maxArgs: 1
            },
            getLastFocused: {
              minArgs: 0,
              maxArgs: 1
            },
            remove: {
              minArgs: 1,
              maxArgs: 1
            },
            update: {
              minArgs: 2,
              maxArgs: 2
            }
          }
        };
        if (Object.keys(c).length === 0)
          throw new Error("api-metadata.json has not been included in browser-polyfill");
        class u extends WeakMap {
          constructor(m, A = void 0) {
            super(A), this.createItem = m;
          }
          get(m) {
            return this.has(m) || this.set(m, this.createItem(m)), super.get(m);
          }
        }
        const f = (p) => p && typeof p == "object" && typeof p.then == "function", g = (p, m) => (...A) => {
          a.runtime.lastError ? p.reject(new Error(a.runtime.lastError.message)) : m.singleCallbackArg || A.length <= 1 && m.singleCallbackArg !== !1 ? p.resolve(A[0]) : p.resolve(A);
        }, h = (p) => p == 1 ? "argument" : "arguments", w = (p, m) => function(k, ...D) {
          if (D.length < m.minArgs)
            throw new Error(`Expected at least ${m.minArgs} ${h(m.minArgs)} for ${p}(), got ${D.length}`);
          if (D.length > m.maxArgs)
            throw new Error(`Expected at most ${m.maxArgs} ${h(m.maxArgs)} for ${p}(), got ${D.length}`);
          return new Promise((L, q) => {
            if (m.fallbackToNoCallback)
              try {
                k[p](...D, g({
                  resolve: L,
                  reject: q
                }, m));
              } catch (_) {
                console.warn(`${p} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, _), k[p](...D), m.fallbackToNoCallback = !1, m.noCallback = !0, L();
              }
            else
              m.noCallback ? (k[p](...D), L()) : k[p](...D, g({
                resolve: L,
                reject: q
              }, m));
          });
        }, E = (p, m, A) => new Proxy(m, {
          apply(k, D, L) {
            return A.call(D, p, ...L);
          }
        });
        let oe = Function.call.bind(Object.prototype.hasOwnProperty);
        const O = (p, m = {}, A = {}) => {
          let k = /* @__PURE__ */ Object.create(null), D = {
            has(q, _) {
              return _ in p || _ in k;
            },
            get(q, _, H) {
              if (_ in k)
                return k[_];
              if (!(_ in p))
                return;
              let C = p[_];
              if (typeof C == "function")
                if (typeof m[_] == "function")
                  C = E(p, p[_], m[_]);
                else if (oe(A, _)) {
                  let Te = w(_, A[_]);
                  C = E(p, p[_], Te);
                } else
                  C = C.bind(p);
              else if (typeof C == "object" && C !== null && (oe(m, _) || oe(A, _)))
                C = O(C, m[_], A[_]);
              else if (oe(A, "*"))
                C = O(C, m[_], A["*"]);
              else
                return Object.defineProperty(k, _, {
                  configurable: !0,
                  enumerable: !0,
                  get() {
                    return p[_];
                  },
                  set(Te) {
                    p[_] = Te;
                  }
                }), C;
              return k[_] = C, C;
            },
            set(q, _, H, C) {
              return _ in k ? k[_] = H : p[_] = H, !0;
            },
            defineProperty(q, _, H) {
              return Reflect.defineProperty(k, _, H);
            },
            deleteProperty(q, _) {
              return Reflect.deleteProperty(k, _);
            }
          }, L = Object.create(p);
          return new Proxy(L, D);
        }, le = (p) => ({
          addListener(m, A, ...k) {
            m.addListener(p.get(A), ...k);
          },
          hasListener(m, A) {
            return m.hasListener(p.get(A));
          },
          removeListener(m, A) {
            m.removeListener(p.get(A));
          }
        }), Be = new u((p) => typeof p != "function" ? p : function(A) {
          const k = O(
            A,
            {},
            {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            }
          );
          p(k);
        }), Le = new u((p) => typeof p != "function" ? p : function(A, k, D) {
          let L = !1, q, _ = new Promise(($e) => {
            q = function(te) {
              L = !0, $e(te);
            };
          }), H;
          try {
            H = p(A, k, q);
          } catch ($e) {
            H = Promise.reject($e);
          }
          const C = H !== !0 && f(H);
          if (H !== !0 && !C && !L)
            return !1;
          const Te = ($e) => {
            $e.then((te) => {
              D(te);
            }, (te) => {
              let xt;
              te && (te instanceof Error || typeof te.message == "string") ? xt = te.message : xt = "An unexpected error occurred", D({
                __mozWebExtensionPolyfillReject__: !0,
                message: xt
              });
            }).catch((te) => {
              console.error("Failed to send onMessage rejected reply", te);
            });
          };
          return Te(C ? H : _), !0;
        }), Rs = ({
          reject: p,
          resolve: m
        }, A) => {
          a.runtime.lastError ? a.runtime.lastError.message === i ? m() : p(new Error(a.runtime.lastError.message)) : A && A.__mozWebExtensionPolyfillReject__ ? p(new Error(A.message)) : m(A);
        }, An = (p, m, A, ...k) => {
          if (k.length < m.minArgs)
            throw new Error(`Expected at least ${m.minArgs} ${h(m.minArgs)} for ${p}(), got ${k.length}`);
          if (k.length > m.maxArgs)
            throw new Error(`Expected at most ${m.maxArgs} ${h(m.maxArgs)} for ${p}(), got ${k.length}`);
          return new Promise((D, L) => {
            const q = Rs.bind(null, {
              resolve: D,
              reject: L
            });
            k.push(q), A.sendMessage(...k);
          });
        }, Ms = {
          devtools: {
            network: {
              onRequestFinished: le(Be)
            }
          },
          runtime: {
            onMessage: le(Le),
            onMessageExternal: le(Le),
            sendMessage: An.bind(null, "sendMessage", {
              minArgs: 1,
              maxArgs: 3
            })
          },
          tabs: {
            sendMessage: An.bind(null, "sendMessage", {
              minArgs: 2,
              maxArgs: 3
            })
          }
        }, It = {
          clear: {
            minArgs: 1,
            maxArgs: 1
          },
          get: {
            minArgs: 1,
            maxArgs: 1
          },
          set: {
            minArgs: 1,
            maxArgs: 1
          }
        };
        return c.privacy = {
          network: {
            "*": It
          },
          services: {
            "*": It
          },
          websites: {
            "*": It
          }
        }, O(a, Ms, c);
      };
      n.exports = o(chrome);
    } else
      n.exports = globalThis.browser;
  });
})(xr);
var Cs = xr.exports;
const l = /* @__PURE__ */ Os(Cs), kr = Object.prototype.toString;
function sn(e) {
  switch (kr.call(e)) {
    case "[object Error]":
    case "[object Exception]":
    case "[object DOMException]":
    case "[object WebAssembly.Exception]":
      return !0;
    default:
      return _e(e, Error);
  }
}
function Ne(e, t) {
  return kr.call(e) === `[object ${t}]`;
}
function Tr(e) {
  return Ne(e, "ErrorEvent");
}
function In(e) {
  return Ne(e, "DOMError");
}
function Ds(e) {
  return Ne(e, "DOMException");
}
function ce(e) {
  return Ne(e, "String");
}
function on(e) {
  return typeof e == "object" && e !== null && "__sentry_template_string__" in e && "__sentry_template_values__" in e;
}
function an(e) {
  return e === null || on(e) || typeof e != "object" && typeof e != "function";
}
function Pe(e) {
  return Ne(e, "Object");
}
function yt(e) {
  return typeof Event < "u" && _e(e, Event);
}
function Ns(e) {
  return typeof Element < "u" && _e(e, Element);
}
function Fs(e) {
  return Ne(e, "RegExp");
}
function wt(e) {
  return !!(e && e.then && typeof e.then == "function");
}
function Bs(e) {
  return Pe(e) && "nativeEvent" in e && "preventDefault" in e && "stopPropagation" in e;
}
function _e(e, t) {
  try {
    return e instanceof t;
  } catch {
    return !1;
  }
}
function Rr(e) {
  return !!(typeof e == "object" && e !== null && (e.__isVue || e._isVue));
}
function Me(e, t = 0) {
  return typeof e != "string" || t === 0 || e.length <= t ? e : `${e.slice(0, t)}...`;
}
function xn(e, t) {
  if (!Array.isArray(e))
    return "";
  const n = [];
  for (let r = 0; r < e.length; r++) {
    const s = e[r];
    try {
      Rr(s) ? n.push("[VueViewModel]") : n.push(String(s));
    } catch {
      n.push("[value cannot be serialized]");
    }
  }
  return n.join(t);
}
function Ls(e, t, n = !1) {
  return ce(e) ? Fs(t) ? t.test(e) : ce(t) ? n ? e === t : e.includes(t) : !1 : !1;
}
function bt(e, t = [], n = !1) {
  return t.some((r) => Ls(e, r, n));
}
function $s(e, t, n = 250, r, s, i, o) {
  if (!i.exception || !i.exception.values || !o || !_e(o.originalException, Error))
    return;
  const a = i.exception.values.length > 0 ? i.exception.values[i.exception.values.length - 1] : void 0;
  a && (i.exception.values = js(
    Bt(
      e,
      t,
      s,
      o.originalException,
      r,
      i.exception.values,
      a,
      0
    ),
    n
  ));
}
function Bt(e, t, n, r, s, i, o, a) {
  if (i.length >= n + 1)
    return i;
  let c = [...i];
  if (_e(r[s], Error)) {
    kn(o, a);
    const u = e(t, r[s]), f = c.length;
    Tn(u, s, f, a), c = Bt(
      e,
      t,
      n,
      r[s],
      s,
      [u, ...c],
      u,
      f
    );
  }
  return Array.isArray(r.errors) && r.errors.forEach((u, f) => {
    if (_e(u, Error)) {
      kn(o, a);
      const g = e(t, u), h = c.length;
      Tn(g, `errors[${f}]`, h, a), c = Bt(
        e,
        t,
        n,
        u,
        s,
        [g, ...c],
        g,
        h
      );
    }
  }), c;
}
function kn(e, t) {
  e.mechanism = e.mechanism || { type: "generic", handled: !0 }, e.mechanism = {
    ...e.mechanism,
    ...e.type === "AggregateError" && { is_exception_group: !0 },
    exception_id: t
  };
}
function Tn(e, t, n, r) {
  e.mechanism = e.mechanism || { type: "generic", handled: !0 }, e.mechanism = {
    ...e.mechanism,
    type: "chained",
    source: t,
    exception_id: n,
    parent_id: r
  };
}
function js(e, t) {
  return e.map((n) => (n.value && (n.value = Me(n.value, t)), n));
}
function Mr(e) {
  if (e !== void 0)
    return e >= 400 && e < 500 ? "warning" : e >= 500 ? "error" : void 0;
}
const Ee = "8.38.0", I = globalThis;
function Et(e, t, n) {
  const r = I, s = r.__SENTRY__ = r.__SENTRY__ || {}, i = s[Ee] = s[Ee] || {};
  return i[e] || (i[e] = t());
}
const cn = I, Us = 80;
function Pr(e, t = {}) {
  if (!e)
    return "<unknown>";
  try {
    let n = e;
    const r = 5, s = [];
    let i = 0, o = 0;
    const a = " > ", c = a.length;
    let u;
    const f = Array.isArray(t) ? t : t.keyAttrs, g = !Array.isArray(t) && t.maxStringLength || Us;
    for (; n && i++ < r && (u = Ws(n, f), !(u === "html" || i > 1 && o + s.length * c + u.length >= g)); )
      s.push(u), o += u.length, n = n.parentNode;
    return s.reverse().join(a);
  } catch {
    return "<unknown>";
  }
}
function Ws(e, t) {
  const n = e, r = [];
  if (!n || !n.tagName)
    return "";
  if (cn.HTMLElement && n instanceof HTMLElement && n.dataset) {
    if (n.dataset.sentryComponent)
      return n.dataset.sentryComponent;
    if (n.dataset.sentryElement)
      return n.dataset.sentryElement;
  }
  r.push(n.tagName.toLowerCase());
  const s = t && t.length ? t.filter((o) => n.getAttribute(o)).map((o) => [o, n.getAttribute(o)]) : null;
  if (s && s.length)
    s.forEach((o) => {
      r.push(`[${o[0]}="${o[1]}"]`);
    });
  else {
    n.id && r.push(`#${n.id}`);
    const o = n.className;
    if (o && ce(o)) {
      const a = o.split(/\s+/);
      for (const c of a)
        r.push(`.${c}`);
    }
  }
  const i = ["aria-label", "type", "name", "title", "alt"];
  for (const o of i) {
    const a = n.getAttribute(o);
    a && r.push(`[${o}="${a}"]`);
  }
  return r.join("");
}
function qs() {
  try {
    return cn.document.location.href;
  } catch {
    return "";
  }
}
function Hs(e) {
  if (!cn.HTMLElement)
    return null;
  let t = e;
  const n = 5;
  for (let r = 0; r < n; r++) {
    if (!t)
      return null;
    if (t instanceof HTMLElement) {
      if (t.dataset.sentryComponent)
        return t.dataset.sentryComponent;
      if (t.dataset.sentryElement)
        return t.dataset.sentryElement;
    }
    t = t.parentNode;
  }
  return null;
}
const Fe = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__, Vs = "Sentry Logger ", Lt = [
  "debug",
  "info",
  "warn",
  "error",
  "log",
  "assert",
  "trace"
], gt = {};
function Ge(e) {
  if (!("console" in I))
    return e();
  const t = I.console, n = {}, r = Object.keys(gt);
  r.forEach((s) => {
    const i = gt[s];
    n[s] = t[s], t[s] = i;
  });
  try {
    return e();
  } finally {
    r.forEach((s) => {
      t[s] = n[s];
    });
  }
}
function Gs() {
  let e = !1;
  const t = {
    enable: () => {
      e = !0;
    },
    disable: () => {
      e = !1;
    },
    isEnabled: () => e
  };
  return Fe ? Lt.forEach((n) => {
    t[n] = (...r) => {
      e && Ge(() => {
        I.console[n](`${Vs}[${n}]:`, ...r);
      });
    };
  }) : Lt.forEach((n) => {
    t[n] = () => {
    };
  }), t;
}
const y = Et("logger", Gs), zs = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)([\w.-]+)(?::(\d+))?\/(.+)/;
function Ys(e) {
  return e === "http" || e === "https";
}
function _t(e, t = !1) {
  const { host: n, path: r, pass: s, port: i, projectId: o, protocol: a, publicKey: c } = e;
  return `${a}://${c}${t && s ? `:${s}` : ""}@${n}${i ? `:${i}` : ""}/${r && `${r}/`}${o}`;
}
function Ks(e) {
  const t = zs.exec(e);
  if (!t) {
    Ge(() => {
      console.error(`Invalid Sentry Dsn: ${e}`);
    });
    return;
  }
  const [n, r, s = "", i = "", o = "", a = ""] = t.slice(1);
  let c = "", u = a;
  const f = u.split("/");
  if (f.length > 1 && (c = f.slice(0, -1).join("/"), u = f.pop()), u) {
    const g = u.match(/^\d+/);
    g && (u = g[0]);
  }
  return Or({ host: i, pass: s, path: c, projectId: u, port: o, protocol: n, publicKey: r });
}
function Or(e) {
  return {
    protocol: e.protocol,
    publicKey: e.publicKey || "",
    pass: e.pass || "",
    host: e.host,
    port: e.port || "",
    path: e.path || "",
    projectId: e.projectId
  };
}
function Js(e) {
  if (!Fe)
    return !0;
  const { port: t, projectId: n, protocol: r } = e;
  return ["protocol", "publicKey", "host", "projectId"].find((o) => e[o] ? !1 : (y.error(`Invalid Sentry Dsn: ${o} missing`), !0)) ? !1 : n.match(/^\d+$/) ? Ys(r) ? t && isNaN(parseInt(t, 10)) ? (y.error(`Invalid Sentry Dsn: Invalid port ${t}`), !1) : !0 : (y.error(`Invalid Sentry Dsn: Invalid protocol ${r}`), !1) : (y.error(`Invalid Sentry Dsn: Invalid projectId ${n}`), !1);
}
function Xs(e) {
  const t = typeof e == "string" ? Ks(e) : Or(e);
  if (!(!t || !Js(t)))
    return t;
}
class re extends Error {
  /** Display name of this error instance. */
  constructor(t, n = "warn") {
    super(t), this.message = t, this.name = new.target.prototype.constructor.name, Object.setPrototypeOf(this, new.target.prototype), this.logLevel = n;
  }
}
function U(e, t, n) {
  if (!(t in e))
    return;
  const r = e[t], s = n(r);
  typeof s == "function" && Cr(s, r), e[t] = s;
}
function Se(e, t, n) {
  try {
    Object.defineProperty(e, t, {
      // enumerable: false, // the default, so we can save on bundle size by not explicitly setting it
      value: n,
      writable: !0,
      configurable: !0
    });
  } catch {
    Fe && y.log(`Failed to add non-enumerable property "${t}" to object`, e);
  }
}
function Cr(e, t) {
  try {
    const n = t.prototype || {};
    e.prototype = t.prototype = n, Se(e, "__sentry_original__", t);
  } catch {
  }
}
function un(e) {
  return e.__sentry_original__;
}
function Qs(e) {
  return Object.keys(e).map((t) => `${encodeURIComponent(t)}=${encodeURIComponent(e[t])}`).join("&");
}
function Dr(e) {
  if (sn(e))
    return {
      message: e.message,
      name: e.name,
      stack: e.stack,
      ...Mn(e)
    };
  if (yt(e)) {
    const t = {
      type: e.type,
      target: Rn(e.target),
      currentTarget: Rn(e.currentTarget),
      ...Mn(e)
    };
    return typeof CustomEvent < "u" && _e(e, CustomEvent) && (t.detail = e.detail), t;
  } else
    return e;
}
function Rn(e) {
  try {
    return Ns(e) ? Pr(e) : Object.prototype.toString.call(e);
  } catch {
    return "<unknown>";
  }
}
function Mn(e) {
  if (typeof e == "object" && e !== null) {
    const t = {};
    for (const n in e)
      Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t;
  } else
    return {};
}
function Zs(e, t = 40) {
  const n = Object.keys(Dr(e));
  n.sort();
  const r = n[0];
  if (!r)
    return "[object has no keys]";
  if (r.length >= t)
    return Me(r, t);
  for (let s = n.length; s > 0; s--) {
    const i = n.slice(0, s).join(", ");
    if (!(i.length > t))
      return s === n.length ? i : Me(i, t);
  }
  return "";
}
function Y(e) {
  return $t(e, /* @__PURE__ */ new Map());
}
function $t(e, t) {
  if (ei(e)) {
    const n = t.get(e);
    if (n !== void 0)
      return n;
    const r = {};
    t.set(e, r);
    for (const s of Object.getOwnPropertyNames(e))
      typeof e[s] < "u" && (r[s] = $t(e[s], t));
    return r;
  }
  if (Array.isArray(e)) {
    const n = t.get(e);
    if (n !== void 0)
      return n;
    const r = [];
    return t.set(e, r), e.forEach((s) => {
      r.push($t(s, t));
    }), r;
  }
  return e;
}
function ei(e) {
  if (!Pe(e))
    return !1;
  try {
    const t = Object.getPrototypeOf(e).constructor.name;
    return !t || t === "Object";
  } catch {
    return !0;
  }
}
const Nr = 50, ve = "?", Pn = /\(error: (.*)\)/, On = /captureMessage|captureException/;
function Fr(...e) {
  const t = e.sort((n, r) => n[0] - r[0]).map((n) => n[1]);
  return (n, r = 0, s = 0) => {
    const i = [], o = n.split(`
`);
    for (let a = r; a < o.length; a++) {
      const c = o[a];
      if (c.length > 1024)
        continue;
      const u = Pn.test(c) ? c.replace(Pn, "$1") : c;
      if (!u.match(/\S*Error: /)) {
        for (const f of t) {
          const g = f(u);
          if (g) {
            i.push(g);
            break;
          }
        }
        if (i.length >= Nr + s)
          break;
      }
    }
    return ni(i.slice(s));
  };
}
function ti(e) {
  return Array.isArray(e) ? Fr(...e) : e;
}
function ni(e) {
  if (!e.length)
    return [];
  const t = Array.from(e);
  return /sentryWrapped/.test(Qe(t).function || "") && t.pop(), t.reverse(), On.test(Qe(t).function || "") && (t.pop(), On.test(Qe(t).function || "") && t.pop()), t.slice(0, Nr).map((n) => ({
    ...n,
    filename: n.filename || Qe(t).filename,
    function: n.function || ve
  }));
}
function Qe(e) {
  return e[e.length - 1] || {};
}
const kt = "<anonymous>";
function he(e) {
  try {
    return !e || typeof e != "function" ? kt : e.name || kt;
  } catch {
    return kt;
  }
}
function Cn(e) {
  const t = e.exception;
  if (t) {
    const n = [];
    try {
      return t.values.forEach((r) => {
        r.stacktrace.frames && n.push(...r.stacktrace.frames);
      }), n;
    } catch {
      return;
    }
  }
}
const ct = {}, Dn = {};
function xe(e, t) {
  ct[e] = ct[e] || [], ct[e].push(t);
}
function ke(e, t) {
  if (!Dn[e]) {
    Dn[e] = !0;
    try {
      t();
    } catch (n) {
      Fe && y.error(`Error while instrumenting ${e}`, n);
    }
  }
}
function Q(e, t) {
  const n = e && ct[e];
  if (n)
    for (const r of n)
      try {
        r(t);
      } catch (s) {
        Fe && y.error(
          `Error while triggering instrumentation handler.
Type: ${e}
Name: ${he(r)}
Error:`,
          s
        );
      }
}
function ri(e) {
  const t = "console";
  xe(t, e), ke(t, si);
}
function si() {
  "console" in I && Lt.forEach(function(e) {
    e in I.console && U(I.console, e, function(t) {
      return gt[e] = t, function(...n) {
        Q("console", { args: n, level: e });
        const s = gt[e];
        s && s.apply(I.console, n);
      };
    });
  });
}
const jt = I;
function Br() {
  if (!("fetch" in jt))
    return !1;
  try {
    return new Headers(), new Request("http://www.example.com"), new Response(), !0;
  } catch {
    return !1;
  }
}
function Ut(e) {
  return e && /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(e.toString());
}
function ii() {
  if (typeof EdgeRuntime == "string")
    return !0;
  if (!Br())
    return !1;
  if (Ut(jt.fetch))
    return !0;
  let e = !1;
  const t = jt.document;
  if (t && typeof t.createElement == "function")
    try {
      const n = t.createElement("iframe");
      n.hidden = !0, t.head.appendChild(n), n.contentWindow && n.contentWindow.fetch && (e = Ut(n.contentWindow.fetch)), t.head.removeChild(n);
    } catch (n) {
      Fe && y.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ", n);
    }
  return e;
}
const Lr = 1e3;
function ze() {
  return Date.now() / Lr;
}
function oi() {
  const { performance: e } = I;
  if (!e || !e.now)
    return ze;
  const t = Date.now() - e.now(), n = e.timeOrigin == null ? t : e.timeOrigin;
  return () => (n + e.now()) / Lr;
}
const ue = oi();
(() => {
  const { performance: e } = I;
  if (!e || !e.now)
    return;
  const t = 3600 * 1e3, n = e.now(), r = Date.now(), s = e.timeOrigin ? Math.abs(e.timeOrigin + n - r) : t, i = s < t, o = e.timing && e.timing.navigationStart, c = typeof o == "number" ? Math.abs(o + n - r) : t, u = c < t;
  return i || u ? s <= c ? e.timeOrigin : o : r;
})();
function ai(e, t) {
  const n = "fetch";
  xe(n, e), ke(n, () => ci(void 0, t));
}
function ci(e, t = !1) {
  t && !ii() || U(I, "fetch", function(n) {
    return function(...r) {
      const { method: s, url: i } = ui(r), o = {
        args: r,
        fetchData: {
          method: s,
          url: i
        },
        startTimestamp: ue() * 1e3
      };
      Q("fetch", {
        ...o
      });
      const a = new Error().stack;
      return n.apply(I, r).then(
        async (c) => (Q("fetch", {
          ...o,
          endTimestamp: ue() * 1e3,
          response: c
        }), c),
        (c) => {
          throw Q("fetch", {
            ...o,
            endTimestamp: ue() * 1e3,
            error: c
          }), sn(c) && c.stack === void 0 && (c.stack = a, Se(c, "framesToPop", 1)), c;
        }
      );
    };
  });
}
function Wt(e, t) {
  return !!e && typeof e == "object" && !!e[t];
}
function Nn(e) {
  return typeof e == "string" ? e : e ? Wt(e, "url") ? e.url : e.toString ? e.toString() : "" : "";
}
function ui(e) {
  if (e.length === 0)
    return { method: "GET", url: "" };
  if (e.length === 2) {
    const [n, r] = e;
    return {
      url: Nn(n),
      method: Wt(r, "method") ? String(r.method).toUpperCase() : "GET"
    };
  }
  const t = e[0];
  return {
    url: Nn(t),
    method: Wt(t, "method") ? String(t.method).toUpperCase() : "GET"
  };
}
let Ze = null;
function di(e) {
  const t = "error";
  xe(t, e), ke(t, li);
}
function li() {
  Ze = I.onerror, I.onerror = function(e, t, n, r, s) {
    return Q("error", {
      column: r,
      error: s,
      line: n,
      msg: e,
      url: t
    }), Ze && !Ze.__SENTRY_LOADER__ ? Ze.apply(this, arguments) : !1;
  }, I.onerror.__SENTRY_INSTRUMENTED__ = !0;
}
let et = null;
function fi(e) {
  const t = "unhandledrejection";
  xe(t, e), ke(t, gi);
}
function gi() {
  et = I.onunhandledrejection, I.onunhandledrejection = function(e) {
    return Q("unhandledrejection", e), et && !et.__SENTRY_LOADER__ ? et.apply(this, arguments) : !0;
  }, I.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0;
}
function pi() {
  return "npm";
}
function mi() {
  const e = typeof WeakSet == "function", t = e ? /* @__PURE__ */ new WeakSet() : [];
  function n(s) {
    if (e)
      return t.has(s) ? !0 : (t.add(s), !1);
    for (let i = 0; i < t.length; i++)
      if (t[i] === s)
        return !0;
    return t.push(s), !1;
  }
  function r(s) {
    if (e)
      t.delete(s);
    else
      for (let i = 0; i < t.length; i++)
        if (t[i] === s) {
          t.splice(i, 1);
          break;
        }
  }
  return [n, r];
}
function X() {
  const e = I, t = e.crypto || e.msCrypto;
  let n = () => Math.random() * 16;
  try {
    if (t && t.randomUUID)
      return t.randomUUID().replace(/-/g, "");
    t && t.getRandomValues && (n = () => {
      const r = new Uint8Array(1);
      return t.getRandomValues(r), r[0];
    });
  } catch {
  }
  return ("10000000100040008000" + 1e11).replace(
    /[018]/g,
    (r) => (
      // eslint-disable-next-line no-bitwise
      (r ^ (n() & 15) >> r / 4).toString(16)
    )
  );
}
function $r(e) {
  return e.exception && e.exception.values ? e.exception.values[0] : void 0;
}
function ge(e) {
  const { message: t, event_id: n } = e;
  if (t)
    return t;
  const r = $r(e);
  return r ? r.type && r.value ? `${r.type}: ${r.value}` : r.type || r.value || n || "<unknown>" : n || "<unknown>";
}
function qt(e, t, n) {
  const r = e.exception = e.exception || {}, s = r.values = r.values || [], i = s[0] = s[0] || {};
  i.value || (i.value = t || ""), i.type || (i.type = "Error");
}
function He(e, t) {
  const n = $r(e);
  if (!n)
    return;
  const r = { type: "generic", handled: !0 }, s = n.mechanism;
  if (n.mechanism = { ...r, ...s, ...t }, t && "data" in t) {
    const i = { ...s && s.data, ...t.data };
    n.mechanism.data = i;
  }
}
function Fn(e) {
  if (e && e.__sentry_captured__)
    return !0;
  try {
    Se(e, "__sentry_captured__", !0);
  } catch {
  }
  return !1;
}
function jr(e) {
  return Array.isArray(e) ? e : [e];
}
function pe(e, t = 100, n = 1 / 0) {
  try {
    return Ht("", e, t, n);
  } catch (r) {
    return { ERROR: `**non-serializable** (${r})` };
  }
}
function Ur(e, t = 3, n = 100 * 1024) {
  const r = pe(e, t);
  return bi(r) > n ? Ur(e, t - 1, n) : r;
}
function Ht(e, t, n = 1 / 0, r = 1 / 0, s = mi()) {
  const [i, o] = s;
  if (t == null || // this matches null and undefined -> eqeq not eqeqeq
  ["boolean", "string"].includes(typeof t) || typeof t == "number" && Number.isFinite(t))
    return t;
  const a = hi(e, t);
  if (!a.startsWith("[object "))
    return a;
  if (t.__sentry_skip_normalization__)
    return t;
  const c = typeof t.__sentry_override_normalization_depth__ == "number" ? t.__sentry_override_normalization_depth__ : n;
  if (c === 0)
    return a.replace("object ", "");
  if (i(t))
    return "[Circular ~]";
  const u = t;
  if (u && typeof u.toJSON == "function")
    try {
      const w = u.toJSON();
      return Ht("", w, c - 1, r, s);
    } catch {
    }
  const f = Array.isArray(t) ? [] : {};
  let g = 0;
  const h = Dr(t);
  for (const w in h) {
    if (!Object.prototype.hasOwnProperty.call(h, w))
      continue;
    if (g >= r) {
      f[w] = "[MaxProperties ~]";
      break;
    }
    const E = h[w];
    f[w] = Ht(w, E, c - 1, r, s), g++;
  }
  return o(t), f;
}
function hi(e, t) {
  try {
    if (e === "domain" && t && typeof t == "object" && t._events)
      return "[Domain]";
    if (e === "domainEmitter")
      return "[DomainEmitter]";
    if (typeof global < "u" && t === global)
      return "[Global]";
    if (typeof window < "u" && t === window)
      return "[Window]";
    if (typeof document < "u" && t === document)
      return "[Document]";
    if (Rr(t))
      return "[VueViewModel]";
    if (Bs(t))
      return "[SyntheticEvent]";
    if (typeof t == "number" && !Number.isFinite(t))
      return `[${t}]`;
    if (typeof t == "function")
      return `[Function: ${he(t)}]`;
    if (typeof t == "symbol")
      return `[${String(t)}]`;
    if (typeof t == "bigint")
      return `[BigInt: ${String(t)}]`;
    const n = yi(t);
    return /^HTML(\w*)Element$/.test(n) ? `[HTMLElement: ${n}]` : `[object ${n}]`;
  } catch (n) {
    return `**non-serializable** (${n})`;
  }
}
function yi(e) {
  const t = Object.getPrototypeOf(e);
  return t ? t.constructor.name : "null prototype";
}
function wi(e) {
  return ~-encodeURI(e).split(/%..|./).length;
}
function bi(e) {
  return wi(JSON.stringify(e));
}
var ae;
(function(e) {
  e[e.PENDING = 0] = "PENDING";
  const n = 1;
  e[e.RESOLVED = n] = "RESOLVED";
  const r = 2;
  e[e.REJECTED = r] = "REJECTED";
})(ae || (ae = {}));
function Ae(e) {
  return new V((t) => {
    t(e);
  });
}
function pt(e) {
  return new V((t, n) => {
    n(e);
  });
}
class V {
  constructor(t) {
    V.prototype.__init.call(this), V.prototype.__init2.call(this), V.prototype.__init3.call(this), V.prototype.__init4.call(this), this._state = ae.PENDING, this._handlers = [];
    try {
      t(this._resolve, this._reject);
    } catch (n) {
      this._reject(n);
    }
  }
  /** JSDoc */
  then(t, n) {
    return new V((r, s) => {
      this._handlers.push([
        !1,
        (i) => {
          if (!t)
            r(i);
          else
            try {
              r(t(i));
            } catch (o) {
              s(o);
            }
        },
        (i) => {
          if (!n)
            s(i);
          else
            try {
              r(n(i));
            } catch (o) {
              s(o);
            }
        }
      ]), this._executeHandlers();
    });
  }
  /** JSDoc */
  catch(t) {
    return this.then((n) => n, t);
  }
  /** JSDoc */
  finally(t) {
    return new V((n, r) => {
      let s, i;
      return this.then(
        (o) => {
          i = !1, s = o, t && t();
        },
        (o) => {
          i = !0, s = o, t && t();
        }
      ).then(() => {
        if (i) {
          r(s);
          return;
        }
        n(s);
      });
    });
  }
  /** JSDoc */
  __init() {
    this._resolve = (t) => {
      this._setResult(ae.RESOLVED, t);
    };
  }
  /** JSDoc */
  __init2() {
    this._reject = (t) => {
      this._setResult(ae.REJECTED, t);
    };
  }
  /** JSDoc */
  __init3() {
    this._setResult = (t, n) => {
      if (this._state === ae.PENDING) {
        if (wt(n)) {
          n.then(this._resolve, this._reject);
          return;
        }
        this._state = t, this._value = n, this._executeHandlers();
      }
    };
  }
  /** JSDoc */
  __init4() {
    this._executeHandlers = () => {
      if (this._state === ae.PENDING)
        return;
      const t = this._handlers.slice();
      this._handlers = [], t.forEach((n) => {
        n[0] || (this._state === ae.RESOLVED && n[1](this._value), this._state === ae.REJECTED && n[2](this._value), n[0] = !0);
      });
    };
  }
}
function Ei(e) {
  const t = [];
  function n() {
    return e === void 0 || t.length < e;
  }
  function r(o) {
    return t.splice(t.indexOf(o), 1)[0] || Promise.resolve(void 0);
  }
  function s(o) {
    if (!n())
      return pt(new re("Not adding Promise because buffer limit was reached."));
    const a = o();
    return t.indexOf(a) === -1 && t.push(a), a.then(() => r(a)).then(
      null,
      () => r(a).then(null, () => {
      })
    ), a;
  }
  function i(o) {
    return new V((a, c) => {
      let u = t.length;
      if (!u)
        return a(!0);
      const f = setTimeout(() => {
        o && o > 0 && a(!1);
      }, o);
      t.forEach((g) => {
        Ae(g).then(() => {
          --u || (clearTimeout(f), a(!0));
        }, c);
      });
    });
  }
  return {
    $: t,
    add: s,
    drain: i
  };
}
function Tt(e) {
  if (!e)
    return {};
  const t = e.match(/^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
  if (!t)
    return {};
  const n = t[6] || "", r = t[8] || "";
  return {
    host: t[4],
    path: t[5],
    protocol: t[2],
    search: n,
    hash: r,
    relative: t[5] + n + r
    // everything minus origin
  };
}
const _i = ["fatal", "error", "warning", "log", "info", "debug"];
function Si(e) {
  return e === "warn" ? "warning" : _i.includes(e) ? e : "log";
}
const vi = "sentry-", Ai = /^sentry-/;
function Ii(e) {
  const t = xi(e);
  if (!t)
    return;
  const n = Object.entries(t).reduce((r, [s, i]) => {
    if (s.match(Ai)) {
      const o = s.slice(vi.length);
      r[o] = i;
    }
    return r;
  }, {});
  if (Object.keys(n).length > 0)
    return n;
}
function xi(e) {
  if (!(!e || !ce(e) && !Array.isArray(e)))
    return Array.isArray(e) ? e.reduce((t, n) => {
      const r = Bn(n);
      return Object.entries(r).forEach(([s, i]) => {
        t[s] = i;
      }), t;
    }, {}) : Bn(e);
}
function Bn(e) {
  return e.split(",").map((t) => t.split("=").map((n) => decodeURIComponent(n.trim()))).reduce((t, [n, r]) => (n && r && (t[n] = r), t), {});
}
function Ye(e, t = []) {
  return [e, t];
}
function ki(e, t) {
  const [n, r] = e;
  return [n, [...r, t]];
}
function Ln(e, t) {
  const n = e[1];
  for (const r of n) {
    const s = r[0].type;
    if (t(r, s))
      return !0;
  }
  return !1;
}
function Vt(e) {
  return I.__SENTRY__ && I.__SENTRY__.encodePolyfill ? I.__SENTRY__.encodePolyfill(e) : new TextEncoder().encode(e);
}
function Ti(e) {
  const [t, n] = e;
  let r = JSON.stringify(t);
  function s(i) {
    typeof r == "string" ? r = typeof i == "string" ? r + i : [Vt(r), i] : r.push(typeof i == "string" ? Vt(i) : i);
  }
  for (const i of n) {
    const [o, a] = i;
    if (s(`
${JSON.stringify(o)}
`), typeof a == "string" || a instanceof Uint8Array)
      s(a);
    else {
      let c;
      try {
        c = JSON.stringify(a);
      } catch {
        c = JSON.stringify(pe(a));
      }
      s(c);
    }
  }
  return typeof r == "string" ? r : Ri(r);
}
function Ri(e) {
  const t = e.reduce((s, i) => s + i.length, 0), n = new Uint8Array(t);
  let r = 0;
  for (const s of e)
    n.set(s, r), r += s.length;
  return n;
}
function Mi(e) {
  const t = typeof e.data == "string" ? Vt(e.data) : e.data;
  return [
    Y({
      type: "attachment",
      length: t.length,
      filename: e.filename,
      content_type: e.contentType,
      attachment_type: e.attachmentType
    }),
    t
  ];
}
const Pi = {
  session: "session",
  sessions: "session",
  attachment: "attachment",
  transaction: "transaction",
  event: "error",
  client_report: "internal",
  user_report: "default",
  profile: "profile",
  profile_chunk: "profile",
  replay_event: "replay",
  replay_recording: "replay",
  check_in: "monitor",
  feedback: "feedback",
  span: "span",
  statsd: "metric_bucket"
};
function $n(e) {
  return Pi[e];
}
function Wr(e) {
  if (!e || !e.sdk)
    return;
  const { name: t, version: n } = e.sdk;
  return { name: t, version: n };
}
function Oi(e, t, n, r) {
  const s = e.sdkProcessingMetadata && e.sdkProcessingMetadata.dynamicSamplingContext;
  return {
    event_id: e.event_id,
    sent_at: (/* @__PURE__ */ new Date()).toISOString(),
    ...t && { sdk: t },
    ...!!n && r && { dsn: _t(r) },
    ...s && {
      trace: Y({ ...s })
    }
  };
}
function Ci(e, t, n) {
  const r = [
    { type: "client_report" },
    {
      timestamp: ze(),
      discarded_events: e
    }
  ];
  return Ye(t ? { dsn: t } : {}, [r]);
}
const Di = 60 * 1e3;
function Ni(e, t = Date.now()) {
  const n = parseInt(`${e}`, 10);
  if (!isNaN(n))
    return n * 1e3;
  const r = Date.parse(`${e}`);
  return isNaN(r) ? Di : r - t;
}
function Fi(e, t) {
  return e[t] || e.all || 0;
}
function Bi(e, t, n = Date.now()) {
  return Fi(e, t) > n;
}
function Li(e, { statusCode: t, headers: n }, r = Date.now()) {
  const s = {
    ...e
  }, i = n && n["x-sentry-rate-limits"], o = n && n["retry-after"];
  if (i)
    for (const a of i.trim().split(",")) {
      const [c, u, , , f] = a.split(":", 5), g = parseInt(c, 10), h = (isNaN(g) ? 60 : g) * 1e3;
      if (!u)
        s.all = r + h;
      else
        for (const w of u.split(";"))
          w === "metric_bucket" ? (!f || f.split(";").includes("custom")) && (s[w] = r + h) : s[w] = r + h;
    }
  else
    o ? s.all = r + Ni(o, r) : t === 429 && (s.all = r + 60 * 1e3);
  return s;
}
function jn() {
  return {
    traceId: X(),
    spanId: X().substring(16)
  };
}
const Un = /* @__PURE__ */ new WeakMap();
function $i(e) {
  const t = I._sentryDebugIds;
  if (!t)
    return {};
  let n;
  const r = Un.get(e);
  return r ? n = r : (n = /* @__PURE__ */ new Map(), Un.set(e, n)), Object.keys(t).reduce((s, i) => {
    let o;
    const a = n.get(i);
    a ? o = a : (o = e(i), n.set(i, o));
    for (let c = o.length - 1; c >= 0; c--) {
      const u = o[c], f = u && u.filename;
      if (u && f) {
        s[f] = t[i];
        break;
      }
    }
    return s;
  }, {});
}
const tt = I;
function ji() {
  const e = tt.chrome, t = e && e.app && e.app.runtime, n = "history" in tt && !!tt.history.pushState && !!tt.history.replaceState;
  return !t && n;
}
const R = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__;
function St() {
  return dn(I), I;
}
function dn(e) {
  const t = e.__SENTRY__ = e.__SENTRY__ || {};
  return t.version = t.version || Ee, t[Ee] = t[Ee] || {};
}
function Ui(e) {
  const t = ue(), n = {
    sid: X(),
    init: !0,
    timestamp: t,
    started: t,
    duration: 0,
    status: "ok",
    errors: 0,
    ignoreDuration: !1,
    toJSON: () => qi(n)
  };
  return e && Oe(n, e), n;
}
function Oe(e, t = {}) {
  if (t.user && (!e.ipAddress && t.user.ip_address && (e.ipAddress = t.user.ip_address), !e.did && !t.did && (e.did = t.user.id || t.user.email || t.user.username)), e.timestamp = t.timestamp || ue(), t.abnormal_mechanism && (e.abnormal_mechanism = t.abnormal_mechanism), t.ignoreDuration && (e.ignoreDuration = t.ignoreDuration), t.sid && (e.sid = t.sid.length === 32 ? t.sid : X()), t.init !== void 0 && (e.init = t.init), !e.did && t.did && (e.did = `${t.did}`), typeof t.started == "number" && (e.started = t.started), e.ignoreDuration)
    e.duration = void 0;
  else if (typeof t.duration == "number")
    e.duration = t.duration;
  else {
    const n = e.timestamp - e.started;
    e.duration = n >= 0 ? n : 0;
  }
  t.release && (e.release = t.release), t.environment && (e.environment = t.environment), !e.ipAddress && t.ipAddress && (e.ipAddress = t.ipAddress), !e.userAgent && t.userAgent && (e.userAgent = t.userAgent), typeof t.errors == "number" && (e.errors = t.errors), t.status && (e.status = t.status);
}
function Wi(e, t) {
  let n = {};
  e.status === "ok" && (n = { status: "exited" }), Oe(e, n);
}
function qi(e) {
  return Y({
    sid: `${e.sid}`,
    init: e.init,
    // Make sure that sec is converted to ms for date constructor
    started: new Date(e.started * 1e3).toISOString(),
    timestamp: new Date(e.timestamp * 1e3).toISOString(),
    status: e.status,
    errors: e.errors,
    did: typeof e.did == "number" || typeof e.did == "string" ? `${e.did}` : void 0,
    duration: e.duration,
    abnormal_mechanism: e.abnormal_mechanism,
    attrs: {
      release: e.release,
      environment: e.environment,
      ip_address: e.ipAddress,
      user_agent: e.userAgent
    }
  });
}
const Gt = "_sentrySpan";
function Wn(e, t) {
  t ? Se(e, Gt, t) : delete e[Gt];
}
function qn(e) {
  return e[Gt];
}
const Hi = 100;
class ln {
  /** Flag if notifying is happening. */
  /** Callback for client to receive scope changes. */
  /** Callback list that will be called during event processing. */
  /** Array of breadcrumbs. */
  /** User */
  /** Tags */
  /** Extra */
  /** Contexts */
  /** Attachments */
  /** Propagation Context for distributed tracing */
  /**
   * A place to stash data which is needed at some point in the SDK's event processing pipeline but which shouldn't get
   * sent to Sentry
   */
  /** Fingerprint */
  /** Severity */
  /**
   * Transaction Name
   *
   * IMPORTANT: The transaction name on the scope has nothing to do with root spans/transaction objects.
   * It's purpose is to assign a transaction to the scope that's added to non-transaction events.
   */
  /** Session */
  /** Request Mode Session Status */
  /** The client on this scope */
  /** Contains the last event id of a captured event.  */
  // NOTE: Any field which gets added here should get added not only to the constructor but also to the `clone` method.
  constructor() {
    this._notifyingListeners = !1, this._scopeListeners = [], this._eventProcessors = [], this._breadcrumbs = [], this._attachments = [], this._user = {}, this._tags = {}, this._extra = {}, this._contexts = {}, this._sdkProcessingMetadata = {}, this._propagationContext = jn();
  }
  /**
   * @inheritDoc
   */
  clone() {
    const t = new ln();
    return t._breadcrumbs = [...this._breadcrumbs], t._tags = { ...this._tags }, t._extra = { ...this._extra }, t._contexts = { ...this._contexts }, t._user = this._user, t._level = this._level, t._session = this._session, t._transactionName = this._transactionName, t._fingerprint = this._fingerprint, t._eventProcessors = [...this._eventProcessors], t._requestSession = this._requestSession, t._attachments = [...this._attachments], t._sdkProcessingMetadata = { ...this._sdkProcessingMetadata }, t._propagationContext = { ...this._propagationContext }, t._client = this._client, t._lastEventId = this._lastEventId, Wn(t, qn(this)), t;
  }
  /**
   * @inheritDoc
   */
  setClient(t) {
    this._client = t;
  }
  /**
   * @inheritDoc
   */
  setLastEventId(t) {
    this._lastEventId = t;
  }
  /**
   * @inheritDoc
   */
  getClient() {
    return this._client;
  }
  /**
   * @inheritDoc
   */
  lastEventId() {
    return this._lastEventId;
  }
  /**
   * @inheritDoc
   */
  addScopeListener(t) {
    this._scopeListeners.push(t);
  }
  /**
   * @inheritDoc
   */
  addEventProcessor(t) {
    return this._eventProcessors.push(t), this;
  }
  /**
   * @inheritDoc
   */
  setUser(t) {
    return this._user = t || {
      email: void 0,
      id: void 0,
      ip_address: void 0,
      username: void 0
    }, this._session && Oe(this._session, { user: t }), this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  getUser() {
    return this._user;
  }
  /**
   * @inheritDoc
   */
  getRequestSession() {
    return this._requestSession;
  }
  /**
   * @inheritDoc
   */
  setRequestSession(t) {
    return this._requestSession = t, this;
  }
  /**
   * @inheritDoc
   */
  setTags(t) {
    return this._tags = {
      ...this._tags,
      ...t
    }, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  setTag(t, n) {
    return this._tags = { ...this._tags, [t]: n }, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  setExtras(t) {
    return this._extra = {
      ...this._extra,
      ...t
    }, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  setExtra(t, n) {
    return this._extra = { ...this._extra, [t]: n }, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  setFingerprint(t) {
    return this._fingerprint = t, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  setLevel(t) {
    return this._level = t, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  setTransactionName(t) {
    return this._transactionName = t, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  setContext(t, n) {
    return n === null ? delete this._contexts[t] : this._contexts[t] = n, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  setSession(t) {
    return t ? this._session = t : delete this._session, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  getSession() {
    return this._session;
  }
  /**
   * @inheritDoc
   */
  update(t) {
    if (!t)
      return this;
    const n = typeof t == "function" ? t(this) : t, [r, s] = n instanceof ye ? [n.getScopeData(), n.getRequestSession()] : Pe(n) ? [t, t.requestSession] : [], { tags: i, extra: o, user: a, contexts: c, level: u, fingerprint: f = [], propagationContext: g } = r || {};
    return this._tags = { ...this._tags, ...i }, this._extra = { ...this._extra, ...o }, this._contexts = { ...this._contexts, ...c }, a && Object.keys(a).length && (this._user = a), u && (this._level = u), f.length && (this._fingerprint = f), g && (this._propagationContext = g), s && (this._requestSession = s), this;
  }
  /**
   * @inheritDoc
   */
  clear() {
    return this._breadcrumbs = [], this._tags = {}, this._extra = {}, this._user = {}, this._contexts = {}, this._level = void 0, this._transactionName = void 0, this._fingerprint = void 0, this._requestSession = void 0, this._session = void 0, Wn(this, void 0), this._attachments = [], this._propagationContext = jn(), this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  addBreadcrumb(t, n) {
    const r = typeof n == "number" ? n : Hi;
    if (r <= 0)
      return this;
    const s = {
      timestamp: ze(),
      ...t
    }, i = this._breadcrumbs;
    return i.push(s), this._breadcrumbs = i.length > r ? i.slice(-r) : i, this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  getLastBreadcrumb() {
    return this._breadcrumbs[this._breadcrumbs.length - 1];
  }
  /**
   * @inheritDoc
   */
  clearBreadcrumbs() {
    return this._breadcrumbs = [], this._notifyScopeListeners(), this;
  }
  /**
   * @inheritDoc
   */
  addAttachment(t) {
    return this._attachments.push(t), this;
  }
  /**
   * @inheritDoc
   */
  clearAttachments() {
    return this._attachments = [], this;
  }
  /** @inheritDoc */
  getScopeData() {
    return {
      breadcrumbs: this._breadcrumbs,
      attachments: this._attachments,
      contexts: this._contexts,
      tags: this._tags,
      extra: this._extra,
      user: this._user,
      level: this._level,
      fingerprint: this._fingerprint || [],
      eventProcessors: this._eventProcessors,
      propagationContext: this._propagationContext,
      sdkProcessingMetadata: this._sdkProcessingMetadata,
      transactionName: this._transactionName,
      span: qn(this)
    };
  }
  /**
   * @inheritDoc
   */
  setSDKProcessingMetadata(t) {
    return this._sdkProcessingMetadata = { ...this._sdkProcessingMetadata, ...t }, this;
  }
  /**
   * @inheritDoc
   */
  setPropagationContext(t) {
    return this._propagationContext = t, this;
  }
  /**
   * @inheritDoc
   */
  getPropagationContext() {
    return this._propagationContext;
  }
  /**
   * @inheritDoc
   */
  captureException(t, n) {
    const r = n && n.event_id ? n.event_id : X();
    if (!this._client)
      return y.warn("No client configured on scope - will not capture exception!"), r;
    const s = new Error("Sentry syntheticException");
    return this._client.captureException(
      t,
      {
        originalException: t,
        syntheticException: s,
        ...n,
        event_id: r
      },
      this
    ), r;
  }
  /**
   * @inheritDoc
   */
  captureMessage(t, n, r) {
    const s = r && r.event_id ? r.event_id : X();
    if (!this._client)
      return y.warn("No client configured on scope - will not capture message!"), s;
    const i = new Error(t);
    return this._client.captureMessage(
      t,
      n,
      {
        originalException: t,
        syntheticException: i,
        ...r,
        event_id: s
      },
      this
    ), s;
  }
  /**
   * @inheritDoc
   */
  captureEvent(t, n) {
    const r = n && n.event_id ? n.event_id : X();
    return this._client ? (this._client.captureEvent(t, { ...n, event_id: r }, this), r) : (y.warn("No client configured on scope - will not capture event!"), r);
  }
  /**
   * This will be called on every set call.
   */
  _notifyScopeListeners() {
    this._notifyingListeners || (this._notifyingListeners = !0, this._scopeListeners.forEach((t) => {
      t(this);
    }), this._notifyingListeners = !1);
  }
}
const ye = ln;
function Vi() {
  return Et("defaultCurrentScope", () => new ye());
}
function Gi() {
  return Et("defaultIsolationScope", () => new ye());
}
class zi {
  constructor(t, n) {
    let r;
    t ? r = t : r = new ye();
    let s;
    n ? s = n : s = new ye(), this._stack = [{ scope: r }], this._isolationScope = s;
  }
  /**
   * Fork a scope for the stack.
   */
  withScope(t) {
    const n = this._pushScope();
    let r;
    try {
      r = t(n);
    } catch (s) {
      throw this._popScope(), s;
    }
    return wt(r) ? r.then(
      (s) => (this._popScope(), s),
      (s) => {
        throw this._popScope(), s;
      }
    ) : (this._popScope(), r);
  }
  /**
   * Get the client of the stack.
   */
  getClient() {
    return this.getStackTop().client;
  }
  /**
   * Returns the scope of the top stack.
   */
  getScope() {
    return this.getStackTop().scope;
  }
  /**
   * Get the isolation scope for the stack.
   */
  getIsolationScope() {
    return this._isolationScope;
  }
  /**
   * Returns the topmost scope layer in the order domain > local > process.
   */
  getStackTop() {
    return this._stack[this._stack.length - 1];
  }
  /**
   * Push a scope to the stack.
   */
  _pushScope() {
    const t = this.getScope().clone();
    return this._stack.push({
      client: this.getClient(),
      scope: t
    }), t;
  }
  /**
   * Pop a scope from the stack.
   */
  _popScope() {
    return this._stack.length <= 1 ? !1 : !!this._stack.pop();
  }
}
function Ce() {
  const e = St(), t = dn(e);
  return t.stack = t.stack || new zi(Vi(), Gi());
}
function Yi(e) {
  return Ce().withScope(e);
}
function Ki(e, t) {
  const n = Ce();
  return n.withScope(() => (n.getStackTop().scope = e, t(e)));
}
function Hn(e) {
  return Ce().withScope(() => e(Ce().getIsolationScope()));
}
function Ji() {
  return {
    withIsolationScope: Hn,
    withScope: Yi,
    withSetScope: Ki,
    withSetIsolationScope: (e, t) => Hn(t),
    getCurrentScope: () => Ce().getScope(),
    getIsolationScope: () => Ce().getIsolationScope()
  };
}
function fn(e) {
  const t = dn(e);
  return t.acs ? t.acs : Ji();
}
function de() {
  const e = St();
  return fn(e).getCurrentScope();
}
function Ke() {
  const e = St();
  return fn(e).getIsolationScope();
}
function Xi() {
  return Et("globalScope", () => new ye());
}
function Qi(...e) {
  const t = St(), n = fn(t);
  if (e.length === 2) {
    const [r, s] = e;
    return r ? n.withSetScope(r, s) : n.withScope(s);
  }
  return n.withScope(e[0]);
}
function N() {
  return de().getClient();
}
const Zi = "_sentryMetrics";
function eo(e) {
  const t = e[Zi];
  if (!t)
    return;
  const n = {};
  for (const [, [r, s]] of t)
    (n[r] || (n[r] = [])).push(Y(s));
  return n;
}
const to = "sentry.source", no = "sentry.sample_rate", ro = "sentry.op", so = "sentry.origin", io = 0, oo = 1, ao = 1;
function co(e) {
  const { spanId: t, traceId: n } = e.spanContext(), { parent_span_id: r } = mt(e);
  return Y({ parent_span_id: r, span_id: t, trace_id: n });
}
function Vn(e) {
  return typeof e == "number" ? Gn(e) : Array.isArray(e) ? e[0] + e[1] / 1e9 : e instanceof Date ? Gn(e.getTime()) : ue();
}
function Gn(e) {
  return e > 9999999999 ? e / 1e3 : e;
}
function mt(e) {
  if (lo(e))
    return e.getSpanJSON();
  try {
    const { spanId: t, traceId: n } = e.spanContext();
    if (uo(e)) {
      const { attributes: r, startTime: s, name: i, endTime: o, parentSpanId: a, status: c } = e;
      return Y({
        span_id: t,
        trace_id: n,
        data: r,
        description: i,
        parent_span_id: a,
        start_timestamp: Vn(s),
        // This is [0,0] by default in OTEL, in which case we want to interpret this as no end time
        timestamp: Vn(o) || void 0,
        status: go(c),
        op: r[ro],
        origin: r[so],
        _metrics_summary: eo(e)
      });
    }
    return {
      span_id: t,
      trace_id: n
    };
  } catch {
    return {};
  }
}
function uo(e) {
  const t = e;
  return !!t.attributes && !!t.startTime && !!t.name && !!t.endTime && !!t.status;
}
function lo(e) {
  return typeof e.getSpanJSON == "function";
}
function fo(e) {
  const { traceFlags: t } = e.spanContext();
  return t === ao;
}
function go(e) {
  if (!(!e || e.code === io))
    return e.code === oo ? "ok" : e.message || "unknown_error";
}
const po = "_sentryRootSpan";
function qr(e) {
  return e[po] || e;
}
function mo(e) {
  if (typeof __SENTRY_TRACING__ == "boolean" && !__SENTRY_TRACING__)
    return !1;
  const t = N(), n = t && t.getOptions();
  return !!n && (n.enableTracing || "tracesSampleRate" in n || "tracesSampler" in n);
}
const gn = "production", ho = "_frozenDsc";
function Hr(e, t) {
  const n = t.getOptions(), { publicKey: r } = t.getDsn() || {}, s = Y({
    environment: n.environment || gn,
    release: n.release,
    public_key: r,
    trace_id: e
  });
  return t.emit("createDsc", s), s;
}
function yo(e) {
  const t = N();
  if (!t)
    return {};
  const n = Hr(mt(e).trace_id || "", t), r = qr(e), s = r[ho];
  if (s)
    return s;
  const i = r.spanContext().traceState, o = i && i.get("sentry.dsc"), a = o && Ii(o);
  if (a)
    return a;
  const c = mt(r), u = c.data || {}, f = u[no];
  f != null && (n.sample_rate = `${f}`);
  const g = u[to], h = c.description;
  return g !== "url" && h && (n.transaction = h), mo() && (n.sampled = String(fo(r))), t.emit("createDsc", n, r), n;
}
function wo(e) {
  if (typeof e == "boolean")
    return Number(e);
  const t = typeof e == "string" ? parseFloat(e) : e;
  if (typeof t != "number" || isNaN(t) || t < 0 || t > 1) {
    R && y.warn(
      `[Tracing] Given sample rate is invalid. Sample rate must be a boolean or a number between 0 and 1. Got ${JSON.stringify(
        e
      )} of type ${JSON.stringify(typeof e)}.`
    );
    return;
  }
  return t;
}
function bo(e, t) {
  return t && (e.sdk = e.sdk || {}, e.sdk.name = e.sdk.name || t.name, e.sdk.version = e.sdk.version || t.version, e.sdk.integrations = [...e.sdk.integrations || [], ...t.integrations || []], e.sdk.packages = [...e.sdk.packages || [], ...t.packages || []]), e;
}
function Eo(e, t, n, r) {
  const s = Wr(n), i = {
    sent_at: (/* @__PURE__ */ new Date()).toISOString(),
    ...s && { sdk: s },
    ...!!r && t && { dsn: _t(t) }
  }, o = "aggregates" in e ? [{ type: "sessions" }, e] : [{ type: "session" }, e.toJSON()];
  return Ye(i, [o]);
}
function _o(e, t, n, r) {
  const s = Wr(n), i = e.type && e.type !== "replay_event" ? e.type : "event";
  bo(e, n && n.sdk);
  const o = Oi(e, s, r, t);
  return delete e.sdkProcessingMetadata, Ye(o, [[{ type: i }, e]]);
}
function zt(e, t, n, r = 0) {
  return new V((s, i) => {
    const o = e[r];
    if (t === null || typeof o != "function")
      s(t);
    else {
      const a = o({ ...t }, n);
      R && o.id && a === null && y.log(`Event processor "${o.id}" dropped event`), wt(a) ? a.then((c) => zt(e, c, n, r + 1).then(s)).then(null, i) : zt(e, a, n, r + 1).then(s).then(null, i);
    }
  });
}
function So(e, t) {
  const { fingerprint: n, span: r, breadcrumbs: s, sdkProcessingMetadata: i } = t;
  vo(e, t), r && xo(e, r), ko(e, n), Ao(e, s), Io(e, i);
}
function zn(e, t) {
  const {
    extra: n,
    tags: r,
    user: s,
    contexts: i,
    level: o,
    sdkProcessingMetadata: a,
    breadcrumbs: c,
    fingerprint: u,
    eventProcessors: f,
    attachments: g,
    propagationContext: h,
    transactionName: w,
    span: E
  } = t;
  je(e, "extra", n), je(e, "tags", r), je(e, "user", s), je(e, "contexts", i), je(e, "sdkProcessingMetadata", a), o && (e.level = o), w && (e.transactionName = w), E && (e.span = E), c.length && (e.breadcrumbs = [...e.breadcrumbs, ...c]), u.length && (e.fingerprint = [...e.fingerprint, ...u]), f.length && (e.eventProcessors = [...e.eventProcessors, ...f]), g.length && (e.attachments = [...e.attachments, ...g]), e.propagationContext = { ...e.propagationContext, ...h };
}
function je(e, t, n) {
  if (n && Object.keys(n).length) {
    e[t] = { ...e[t] };
    for (const r in n)
      Object.prototype.hasOwnProperty.call(n, r) && (e[t][r] = n[r]);
  }
}
function vo(e, t) {
  const { extra: n, tags: r, user: s, contexts: i, level: o, transactionName: a } = t, c = Y(n);
  c && Object.keys(c).length && (e.extra = { ...c, ...e.extra });
  const u = Y(r);
  u && Object.keys(u).length && (e.tags = { ...u, ...e.tags });
  const f = Y(s);
  f && Object.keys(f).length && (e.user = { ...f, ...e.user });
  const g = Y(i);
  g && Object.keys(g).length && (e.contexts = { ...g, ...e.contexts }), o && (e.level = o), a && e.type !== "transaction" && (e.transaction = a);
}
function Ao(e, t) {
  const n = [...e.breadcrumbs || [], ...t];
  e.breadcrumbs = n.length ? n : void 0;
}
function Io(e, t) {
  e.sdkProcessingMetadata = {
    ...e.sdkProcessingMetadata,
    ...t
  };
}
function xo(e, t) {
  e.contexts = {
    trace: co(t),
    ...e.contexts
  }, e.sdkProcessingMetadata = {
    dynamicSamplingContext: yo(t),
    ...e.sdkProcessingMetadata
  };
  const n = qr(t), r = mt(n).description;
  r && !e.transaction && e.type === "transaction" && (e.transaction = r);
}
function ko(e, t) {
  e.fingerprint = e.fingerprint ? jr(e.fingerprint) : [], t && (e.fingerprint = e.fingerprint.concat(t)), e.fingerprint && !e.fingerprint.length && delete e.fingerprint;
}
function To(e, t, n, r, s, i) {
  const { normalizeDepth: o = 3, normalizeMaxBreadth: a = 1e3 } = e, c = {
    ...t,
    event_id: t.event_id || n.event_id || X(),
    timestamp: t.timestamp || ze()
  }, u = n.integrations || e.integrations.map((O) => O.name);
  Ro(c, e), Oo(c, u), s && s.emit("applyFrameMetadata", t), t.type === void 0 && Mo(c, e.stackParser);
  const f = Do(r, n.captureContext);
  n.mechanism && He(c, n.mechanism);
  const g = s ? s.getEventProcessors() : [], h = Xi().getScopeData();
  if (i) {
    const O = i.getScopeData();
    zn(h, O);
  }
  if (f) {
    const O = f.getScopeData();
    zn(h, O);
  }
  const w = [...n.attachments || [], ...h.attachments];
  w.length && (n.attachments = w), So(c, h);
  const E = [
    ...g,
    // Run scope event processors _after_ all other processors
    ...h.eventProcessors
  ];
  return zt(E, c, n).then((O) => (O && Po(O), typeof o == "number" && o > 0 ? Co(O, o, a) : O));
}
function Ro(e, t) {
  const { environment: n, release: r, dist: s, maxValueLength: i = 250 } = t;
  "environment" in e || (e.environment = "environment" in t ? n : gn), e.release === void 0 && r !== void 0 && (e.release = r), e.dist === void 0 && s !== void 0 && (e.dist = s), e.message && (e.message = Me(e.message, i));
  const o = e.exception && e.exception.values && e.exception.values[0];
  o && o.value && (o.value = Me(o.value, i));
  const a = e.request;
  a && a.url && (a.url = Me(a.url, i));
}
function Mo(e, t) {
  const n = $i(t);
  try {
    e.exception.values.forEach((r) => {
      r.stacktrace.frames.forEach((s) => {
        s.filename && (s.debug_id = n[s.filename]);
      });
    });
  } catch {
  }
}
function Po(e) {
  const t = {};
  try {
    e.exception.values.forEach((r) => {
      r.stacktrace.frames.forEach((s) => {
        s.debug_id && (s.abs_path ? t[s.abs_path] = s.debug_id : s.filename && (t[s.filename] = s.debug_id), delete s.debug_id);
      });
    });
  } catch {
  }
  if (Object.keys(t).length === 0)
    return;
  e.debug_meta = e.debug_meta || {}, e.debug_meta.images = e.debug_meta.images || [];
  const n = e.debug_meta.images;
  Object.entries(t).forEach(([r, s]) => {
    n.push({
      type: "sourcemap",
      code_file: r,
      debug_id: s
    });
  });
}
function Oo(e, t) {
  t.length > 0 && (e.sdk = e.sdk || {}, e.sdk.integrations = [...e.sdk.integrations || [], ...t]);
}
function Co(e, t, n) {
  if (!e)
    return null;
  const r = {
    ...e,
    ...e.breadcrumbs && {
      breadcrumbs: e.breadcrumbs.map((s) => ({
        ...s,
        ...s.data && {
          data: pe(s.data, t, n)
        }
      }))
    },
    ...e.user && {
      user: pe(e.user, t, n)
    },
    ...e.contexts && {
      contexts: pe(e.contexts, t, n)
    },
    ...e.extra && {
      extra: pe(e.extra, t, n)
    }
  };
  return e.contexts && e.contexts.trace && r.contexts && (r.contexts.trace = e.contexts.trace, e.contexts.trace.data && (r.contexts.trace.data = pe(e.contexts.trace.data, t, n))), e.spans && (r.spans = e.spans.map((s) => ({
    ...s,
    ...s.data && {
      data: pe(s.data, t, n)
    }
  }))), r;
}
function Do(e, t) {
  if (!t)
    return e;
  const n = e ? e.clone() : new ye();
  return n.update(t), n;
}
function No(e) {
  if (e)
    return Fo(e) ? { captureContext: e } : Lo(e) ? {
      captureContext: e
    } : e;
}
function Fo(e) {
  return e instanceof ye || typeof e == "function";
}
const Bo = [
  "user",
  "level",
  "extra",
  "contexts",
  "tags",
  "fingerprint",
  "requestSession",
  "propagationContext"
];
function Lo(e) {
  return Object.keys(e).some((t) => Bo.includes(t));
}
function Vr(e, t) {
  return de().captureException(e, No(t));
}
function $o(e, t) {
  const r = { captureContext: t };
  return de().captureMessage(e, void 0, r);
}
function Gr(e, t) {
  return de().captureEvent(e, t);
}
function jo() {
  return !!N();
}
function Yn(e) {
  const t = N(), n = Ke(), r = de(), { release: s, environment: i = gn } = t && t.getOptions() || {}, { userAgent: o } = I.navigator || {}, a = Ui({
    release: s,
    environment: i,
    user: r.getUser() || n.getUser(),
    ...o && { userAgent: o },
    ...e
  }), c = n.getSession();
  return c && c.status === "ok" && Oe(c, { status: "exited" }), zr(), n.setSession(a), r.setSession(a), a;
}
function zr() {
  const e = Ke(), t = de(), n = t.getSession() || e.getSession();
  n && Wi(n), Yr(), e.setSession(), t.setSession();
}
function Yr() {
  const e = Ke(), t = de(), n = N(), r = t.getSession() || e.getSession();
  r && n && n.captureSession(r);
}
function Kn(e = !1) {
  if (e) {
    zr();
    return;
  }
  Yr();
}
const Uo = "7";
function Wo(e) {
  const t = e.protocol ? `${e.protocol}:` : "", n = e.port ? `:${e.port}` : "";
  return `${t}//${e.host}${n}${e.path ? `/${e.path}` : ""}/api/`;
}
function qo(e) {
  return `${Wo(e)}${e.projectId}/envelope/`;
}
function Ho(e, t) {
  return Qs({
    // We send only the minimum set of required information. See
    // https://github.com/getsentry/sentry-javascript/issues/2572.
    sentry_key: e.publicKey,
    sentry_version: Uo,
    ...t && { sentry_client: `${t.name}/${t.version}` }
  });
}
function Vo(e, t, n) {
  return t || `${qo(e)}?${Ho(e, n)}`;
}
const Jn = [];
function Go(e) {
  const t = {};
  return e.forEach((n) => {
    const { name: r } = n, s = t[r];
    s && !s.isDefaultInstance && n.isDefaultInstance || (t[r] = n);
  }), Object.values(t);
}
function zo(e) {
  const t = e.defaultIntegrations || [], n = e.integrations;
  t.forEach((o) => {
    o.isDefaultInstance = !0;
  });
  let r;
  Array.isArray(n) ? r = [...t, ...n] : typeof n == "function" ? r = jr(n(t)) : r = t;
  const s = Go(r), i = s.findIndex((o) => o.name === "Debug");
  if (i > -1) {
    const [o] = s.splice(i, 1);
    s.push(o);
  }
  return s;
}
function Yo(e, t) {
  const n = {};
  return t.forEach((r) => {
    r && Kr(e, r, n);
  }), n;
}
function Xn(e, t) {
  for (const n of t)
    n && n.afterAllSetup && n.afterAllSetup(e);
}
function Kr(e, t, n) {
  if (n[t.name]) {
    R && y.log(`Integration skipped because it was already installed: ${t.name}`);
    return;
  }
  if (n[t.name] = t, Jn.indexOf(t.name) === -1 && typeof t.setupOnce == "function" && (t.setupOnce(), Jn.push(t.name)), t.setup && typeof t.setup == "function" && t.setup(e), typeof t.preprocessEvent == "function") {
    const r = t.preprocessEvent.bind(t);
    e.on("preprocessEvent", (s, i) => r(s, i, e));
  }
  if (typeof t.processEvent == "function") {
    const r = t.processEvent.bind(t), s = Object.assign((i, o) => r(i, o, e), {
      id: t.name
    });
    e.addEventProcessor(s);
  }
  R && y.log(`Integration installed: ${t.name}`);
}
const Qn = "Not capturing exception because it's already been captured.";
class Ko {
  /** Options passed to the SDK. */
  /** The client Dsn, if specified in options. Without this Dsn, the SDK will be disabled. */
  /** Array of set up integrations. */
  /** Number of calls being processed */
  /** Holds flushable  */
  // eslint-disable-next-line @typescript-eslint/ban-types
  /**
   * Initializes this client instance.
   *
   * @param options Options for the client.
   */
  constructor(t) {
    if (this._options = t, this._integrations = {}, this._numProcessing = 0, this._outcomes = {}, this._hooks = {}, this._eventProcessors = [], t.dsn ? this._dsn = Xs(t.dsn) : R && y.warn("No DSN provided, client will not send events."), this._dsn) {
      const n = Vo(
        this._dsn,
        t.tunnel,
        t._metadata ? t._metadata.sdk : void 0
      );
      this._transport = t.transport({
        tunnel: this._options.tunnel,
        recordDroppedEvent: this.recordDroppedEvent.bind(this),
        ...t.transportOptions,
        url: n
      });
    }
  }
  /**
   * @inheritDoc
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  captureException(t, n, r) {
    const s = X();
    if (Fn(t))
      return R && y.log(Qn), s;
    const i = {
      event_id: s,
      ...n
    };
    return this._process(
      this.eventFromException(t, i).then(
        (o) => this._captureEvent(o, i, r)
      )
    ), i.event_id;
  }
  /**
   * @inheritDoc
   */
  captureMessage(t, n, r, s) {
    const i = {
      event_id: X(),
      ...r
    }, o = on(t) ? t : String(t), a = an(t) ? this.eventFromMessage(o, n, i) : this.eventFromException(t, i);
    return this._process(a.then((c) => this._captureEvent(c, i, s))), i.event_id;
  }
  /**
   * @inheritDoc
   */
  captureEvent(t, n, r) {
    const s = X();
    if (n && n.originalException && Fn(n.originalException))
      return R && y.log(Qn), s;
    const i = {
      event_id: s,
      ...n
    }, a = (t.sdkProcessingMetadata || {}).capturedSpanScope;
    return this._process(this._captureEvent(t, i, a || r)), i.event_id;
  }
  /**
   * @inheritDoc
   */
  captureSession(t) {
    typeof t.release != "string" ? R && y.warn("Discarded session because of missing or non-string release") : (this.sendSession(t), Oe(t, { init: !1 }));
  }
  /**
   * @inheritDoc
   */
  getDsn() {
    return this._dsn;
  }
  /**
   * @inheritDoc
   */
  getOptions() {
    return this._options;
  }
  /**
   * @see SdkMetadata in @sentry/types
   *
   * @return The metadata of the SDK
   */
  getSdkMetadata() {
    return this._options._metadata;
  }
  /**
   * @inheritDoc
   */
  getTransport() {
    return this._transport;
  }
  /**
   * @inheritDoc
   */
  flush(t) {
    const n = this._transport;
    return n ? (this.emit("flush"), this._isClientDoneProcessing(t).then((r) => n.flush(t).then((s) => r && s))) : Ae(!0);
  }
  /**
   * @inheritDoc
   */
  close(t) {
    return this.flush(t).then((n) => (this.getOptions().enabled = !1, this.emit("close"), n));
  }
  /** Get all installed event processors. */
  getEventProcessors() {
    return this._eventProcessors;
  }
  /** @inheritDoc */
  addEventProcessor(t) {
    this._eventProcessors.push(t);
  }
  /** @inheritdoc */
  init() {
    (this._isEnabled() || // Force integrations to be setup even if no DSN was set when we have
    // Spotlight enabled. This is particularly important for browser as we
    // don't support the `spotlight` option there and rely on the users
    // adding the `spotlightBrowserIntegration()` to their integrations which
    // wouldn't get initialized with the check below when there's no DSN set.
    this._options.integrations.some(({ name: t }) => t.startsWith("Spotlight"))) && this._setupIntegrations();
  }
  /**
   * Gets an installed integration by its name.
   *
   * @returns The installed integration or `undefined` if no integration with that `name` was installed.
   */
  getIntegrationByName(t) {
    return this._integrations[t];
  }
  /**
   * @inheritDoc
   */
  addIntegration(t) {
    const n = this._integrations[t.name];
    Kr(this, t, this._integrations), n || Xn(this, [t]);
  }
  /**
   * @inheritDoc
   */
  sendEvent(t, n = {}) {
    this.emit("beforeSendEvent", t, n);
    let r = _o(t, this._dsn, this._options._metadata, this._options.tunnel);
    for (const i of n.attachments || [])
      r = ki(r, Mi(i));
    const s = this.sendEnvelope(r);
    s && s.then((i) => this.emit("afterSendEvent", t, i), null);
  }
  /**
   * @inheritDoc
   */
  sendSession(t) {
    const n = Eo(t, this._dsn, this._options._metadata, this._options.tunnel);
    this.sendEnvelope(n);
  }
  /**
   * @inheritDoc
   */
  recordDroppedEvent(t, n, r) {
    if (this._options.sendClientReports) {
      const s = typeof r == "number" ? r : 1, i = `${t}:${n}`;
      R && y.log(`Recording outcome: "${i}"${s > 1 ? ` (${s} times)` : ""}`), this._outcomes[i] = (this._outcomes[i] || 0) + s;
    }
  }
  // Keep on() & emit() signatures in sync with types' client.ts interface
  /* eslint-disable @typescript-eslint/unified-signatures */
  /** @inheritdoc */
  /** @inheritdoc */
  on(t, n) {
    const r = this._hooks[t] = this._hooks[t] || [];
    return r.push(n), () => {
      const s = r.indexOf(n);
      s > -1 && r.splice(s, 1);
    };
  }
  /** @inheritdoc */
  /** @inheritdoc */
  emit(t, ...n) {
    const r = this._hooks[t];
    r && r.forEach((s) => s(...n));
  }
  /**
   * @inheritdoc
   */
  sendEnvelope(t) {
    return this.emit("beforeEnvelope", t), this._isEnabled() && this._transport ? this._transport.send(t).then(null, (n) => (R && y.error("Error while sending envelope:", n), n)) : (R && y.error("Transport disabled"), Ae({}));
  }
  /* eslint-enable @typescript-eslint/unified-signatures */
  /** Setup integrations for this client. */
  _setupIntegrations() {
    const { integrations: t } = this._options;
    this._integrations = Yo(this, t), Xn(this, t);
  }
  /** Updates existing session based on the provided event */
  _updateSessionFromEvent(t, n) {
    let r = !1, s = !1;
    const i = n.exception && n.exception.values;
    if (i) {
      s = !0;
      for (const c of i) {
        const u = c.mechanism;
        if (u && u.handled === !1) {
          r = !0;
          break;
        }
      }
    }
    const o = t.status === "ok";
    (o && t.errors === 0 || o && r) && (Oe(t, {
      ...r && { status: "crashed" },
      errors: t.errors || Number(s || r)
    }), this.captureSession(t));
  }
  /**
   * Determine if the client is finished processing. Returns a promise because it will wait `timeout` ms before saying
   * "no" (resolving to `false`) in order to give the client a chance to potentially finish first.
   *
   * @param timeout The time, in ms, after which to resolve to `false` if the client is still busy. Passing `0` (or not
   * passing anything) will make the promise wait as long as it takes for processing to finish before resolving to
   * `true`.
   * @returns A promise which will resolve to `true` if processing is already done or finishes before the timeout, and
   * `false` otherwise
   */
  _isClientDoneProcessing(t) {
    return new V((n) => {
      let r = 0;
      const s = 1, i = setInterval(() => {
        this._numProcessing == 0 ? (clearInterval(i), n(!0)) : (r += s, t && r >= t && (clearInterval(i), n(!1)));
      }, s);
    });
  }
  /** Determines whether this SDK is enabled and a transport is present. */
  _isEnabled() {
    return this.getOptions().enabled !== !1 && this._transport !== void 0;
  }
  /**
   * Adds common information to events.
   *
   * The information includes release and environment from `options`,
   * breadcrumbs and context (extra, tags and user) from the scope.
   *
   * Information that is already present in the event is never overwritten. For
   * nested objects, such as the context, keys are merged.
   *
   * @param event The original event.
   * @param hint May contain additional information about the original exception.
   * @param currentScope A scope containing event metadata.
   * @returns A new event with more information.
   */
  _prepareEvent(t, n, r, s = Ke()) {
    const i = this.getOptions(), o = Object.keys(this._integrations);
    return !n.integrations && o.length > 0 && (n.integrations = o), this.emit("preprocessEvent", t, n), t.type || s.setLastEventId(t.event_id || n.event_id), To(i, t, n, r, this, s).then((a) => {
      if (a === null)
        return a;
      const c = {
        ...s.getPropagationContext(),
        ...r ? r.getPropagationContext() : void 0
      };
      if (!(a.contexts && a.contexts.trace) && c) {
        const { traceId: f, spanId: g, parentSpanId: h, dsc: w } = c;
        a.contexts = {
          trace: Y({
            trace_id: f,
            span_id: g,
            parent_span_id: h
          }),
          ...a.contexts
        };
        const E = w || Hr(f, this);
        a.sdkProcessingMetadata = {
          dynamicSamplingContext: E,
          ...a.sdkProcessingMetadata
        };
      }
      return a;
    });
  }
  /**
   * Processes the event and logs an error in case of rejection
   * @param event
   * @param hint
   * @param scope
   */
  _captureEvent(t, n = {}, r) {
    return this._processEvent(t, n, r).then(
      (s) => s.event_id,
      (s) => {
        if (R) {
          const i = s;
          i.logLevel === "log" ? y.log(i.message) : y.warn(i);
        }
      }
    );
  }
  /**
   * Processes an event (either error or message) and sends it to Sentry.
   *
   * This also adds breadcrumbs and context information to the event. However,
   * platform specific meta data (such as the User's IP address) must be added
   * by the SDK implementor.
   *
   *
   * @param event The event to send to Sentry.
   * @param hint May contain additional information about the original exception.
   * @param currentScope A scope containing event metadata.
   * @returns A SyncPromise that resolves with the event or rejects in case event was/will not be send.
   */
  _processEvent(t, n, r) {
    const s = this.getOptions(), { sampleRate: i } = s, o = Xr(t), a = Jr(t), c = t.type || "error", u = `before send for type \`${c}\``, f = typeof i > "u" ? void 0 : wo(i);
    if (a && typeof f == "number" && Math.random() > f)
      return this.recordDroppedEvent("sample_rate", "error", t), pt(
        new re(
          `Discarding event because it's not included in the random sample (sampling rate = ${i})`,
          "log"
        )
      );
    const g = c === "replay_event" ? "replay" : c, w = (t.sdkProcessingMetadata || {}).capturedSpanIsolationScope;
    return this._prepareEvent(t, n, r, w).then((E) => {
      if (E === null)
        throw this.recordDroppedEvent("event_processor", g, t), new re("An event processor returned `null`, will not send event.", "log");
      if (n.data && n.data.__sentry__ === !0)
        return E;
      const O = Xo(this, s, E, n);
      return Jo(O, u);
    }).then((E) => {
      if (E === null) {
        if (this.recordDroppedEvent("before_send", g, t), o) {
          const Be = 1 + (t.spans || []).length;
          this.recordDroppedEvent("before_send", "span", Be);
        }
        throw new re(`${u} returned \`null\`, will not send event.`, "log");
      }
      const oe = r && r.getSession();
      if (!o && oe && this._updateSessionFromEvent(oe, E), o) {
        const le = E.sdkProcessingMetadata && E.sdkProcessingMetadata.spanCountBeforeProcessing || 0, Be = E.spans ? E.spans.length : 0, Le = le - Be;
        Le > 0 && this.recordDroppedEvent("before_send", "span", Le);
      }
      const O = E.transaction_info;
      if (o && O && E.transaction !== t.transaction) {
        const le = "custom";
        E.transaction_info = {
          ...O,
          source: le
        };
      }
      return this.sendEvent(E, n), E;
    }).then(null, (E) => {
      throw E instanceof re ? E : (this.captureException(E, {
        data: {
          __sentry__: !0
        },
        originalException: E
      }), new re(
        `Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.
Reason: ${E}`
      ));
    });
  }
  /**
   * Occupies the client with processing and event
   */
  _process(t) {
    this._numProcessing++, t.then(
      (n) => (this._numProcessing--, n),
      (n) => (this._numProcessing--, n)
    );
  }
  /**
   * Clears outcomes on this client and returns them.
   */
  _clearOutcomes() {
    const t = this._outcomes;
    return this._outcomes = {}, Object.entries(t).map(([n, r]) => {
      const [s, i] = n.split(":");
      return {
        reason: s,
        category: i,
        quantity: r
      };
    });
  }
  /**
   * Sends client reports as an envelope.
   */
  _flushOutcomes() {
    R && y.log("Flushing outcomes...");
    const t = this._clearOutcomes();
    if (t.length === 0) {
      R && y.log("No outcomes to send");
      return;
    }
    if (!this._dsn) {
      R && y.log("No dsn provided, will not send outcomes");
      return;
    }
    R && y.log("Sending outcomes:", t);
    const n = Ci(t, this._options.tunnel && _t(this._dsn));
    this.sendEnvelope(n);
  }
  /**
   * @inheritDoc
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
}
function Jo(e, t) {
  const n = `${t} must return \`null\` or a valid event.`;
  if (wt(e))
    return e.then(
      (r) => {
        if (!Pe(r) && r !== null)
          throw new re(n);
        return r;
      },
      (r) => {
        throw new re(`${t} rejected with ${r}`);
      }
    );
  if (!Pe(e) && e !== null)
    throw new re(n);
  return e;
}
function Xo(e, t, n, r) {
  const { beforeSend: s, beforeSendTransaction: i, beforeSendSpan: o } = t;
  if (Jr(n) && s)
    return s(n, r);
  if (Xr(n)) {
    if (n.spans && o) {
      const a = [];
      for (const c of n.spans) {
        const u = o(c);
        u ? a.push(u) : e.recordDroppedEvent("before_send", "span");
      }
      n.spans = a;
    }
    if (i) {
      if (n.spans) {
        const a = n.spans.length;
        n.sdkProcessingMetadata = {
          ...n.sdkProcessingMetadata,
          spanCountBeforeProcessing: a
        };
      }
      return i(n, r);
    }
  }
  return n;
}
function Jr(e) {
  return e.type === void 0;
}
function Xr(e) {
  return e.type === "transaction";
}
function Qo(e, t) {
  t.debug === !0 && (R ? y.enable() : Ge(() => {
    console.warn("[Sentry] Cannot initialize SDK with `debug` option using a non-debug bundle.");
  })), de().update(t.initialScope);
  const r = new e(t);
  return Zo(r), r.init(), r;
}
function Zo(e) {
  de().setClient(e);
}
const ea = 64;
function ta(e, t, n = Ei(
  e.bufferSize || ea
)) {
  let r = {};
  const s = (o) => n.drain(o);
  function i(o) {
    const a = [];
    if (Ln(o, (g, h) => {
      const w = $n(h);
      if (Bi(r, w)) {
        const E = Zn(g, h);
        e.recordDroppedEvent("ratelimit_backoff", w, E);
      } else
        a.push(g);
    }), a.length === 0)
      return Ae({});
    const c = Ye(o[0], a), u = (g) => {
      Ln(c, (h, w) => {
        const E = Zn(h, w);
        e.recordDroppedEvent(g, $n(w), E);
      });
    }, f = () => t({ body: Ti(c) }).then(
      (g) => (g.statusCode !== void 0 && (g.statusCode < 200 || g.statusCode >= 300) && R && y.warn(`Sentry responded with status code ${g.statusCode} to sent event.`), r = Li(r, g), g),
      (g) => {
        throw u("network_error"), g;
      }
    );
    return n.add(f).then(
      (g) => g,
      (g) => {
        if (g instanceof re)
          return R && y.error("Skipped sending event because buffer is full."), u("queue_overflow"), Ae({});
        throw g;
      }
    );
  }
  return {
    send: i,
    flush: s
  };
}
function Zn(e, t) {
  if (!(t !== "event" && t !== "transaction"))
    return Array.isArray(e) ? e[1] : void 0;
}
function na(e, t, n = [t], r = "npm") {
  const s = e._metadata || {};
  s.sdk || (s.sdk = {
    name: `sentry.javascript.${t}`,
    packages: n.map((i) => ({
      name: `${r}:@sentry/${i}`,
      version: Ee
    })),
    version: Ee
  }), e._metadata = s;
}
const ra = 100;
function Ie(e, t) {
  const n = N(), r = Ke();
  if (!n)
    return;
  const { beforeBreadcrumb: s = null, maxBreadcrumbs: i = ra } = n.getOptions();
  if (i <= 0)
    return;
  const a = { timestamp: ze(), ...e }, c = s ? Ge(() => s(a, t)) : a;
  c !== null && (n.emit && n.emit("beforeAddBreadcrumb", c, t), r.addBreadcrumb(c, i));
}
let er;
const sa = "FunctionToString", tr = /* @__PURE__ */ new WeakMap(), ia = () => ({
  name: sa,
  setupOnce() {
    er = Function.prototype.toString;
    try {
      Function.prototype.toString = function(...e) {
        const t = un(this), n = tr.has(N()) && t !== void 0 ? t : this;
        return er.apply(n, e);
      };
    } catch {
    }
  },
  setup(e) {
    tr.set(e, !0);
  }
}), oa = ia, aa = [
  /^Script error\.?$/,
  /^Javascript error: Script error\.? on line 0$/,
  /^ResizeObserver loop completed with undelivered notifications.$/,
  // The browser logs this when a ResizeObserver handler takes a bit longer. Usually this is not an actual issue though. It indicates slowness.
  /^Cannot redefine property: googletag$/,
  // This is thrown when google tag manager is used in combination with an ad blocker
  "undefined is not an object (evaluating 'a.L')",
  // Random error that happens but not actionable or noticeable to end-users.
  `can't redefine non-configurable property "solana"`,
  // Probably a browser extension or custom browser (Brave) throwing this error
  "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)",
  // Error thrown by GTM, seemingly not affecting end-users
  "Can't find variable: _AutofillCallbackHandler"
  // Unactionable error in instagram webview https://developers.facebook.com/community/threads/320013549791141/
], ca = "InboundFilters", ua = (e = {}) => ({
  name: ca,
  processEvent(t, n, r) {
    const s = r.getOptions(), i = la(e, s);
    return fa(t, i) ? null : t;
  }
}), da = ua;
function la(e = {}, t = {}) {
  return {
    allowUrls: [...e.allowUrls || [], ...t.allowUrls || []],
    denyUrls: [...e.denyUrls || [], ...t.denyUrls || []],
    ignoreErrors: [
      ...e.ignoreErrors || [],
      ...t.ignoreErrors || [],
      ...e.disableErrorDefaults ? [] : aa
    ],
    ignoreTransactions: [...e.ignoreTransactions || [], ...t.ignoreTransactions || []],
    ignoreInternal: e.ignoreInternal !== void 0 ? e.ignoreInternal : !0
  };
}
function fa(e, t) {
  return t.ignoreInternal && wa(e) ? (R && y.warn(`Event dropped due to being internal Sentry Error.
Event: ${ge(e)}`), !0) : ga(e, t.ignoreErrors) ? (R && y.warn(
    `Event dropped due to being matched by \`ignoreErrors\` option.
Event: ${ge(e)}`
  ), !0) : Ea(e) ? (R && y.warn(
    `Event dropped due to not having an error message, error type or stacktrace.
Event: ${ge(
      e
    )}`
  ), !0) : pa(e, t.ignoreTransactions) ? (R && y.warn(
    `Event dropped due to being matched by \`ignoreTransactions\` option.
Event: ${ge(e)}`
  ), !0) : ma(e, t.denyUrls) ? (R && y.warn(
    `Event dropped due to being matched by \`denyUrls\` option.
Event: ${ge(
      e
    )}.
Url: ${ht(e)}`
  ), !0) : ha(e, t.allowUrls) ? !1 : (R && y.warn(
    `Event dropped due to not being matched by \`allowUrls\` option.
Event: ${ge(
      e
    )}.
Url: ${ht(e)}`
  ), !0);
}
function ga(e, t) {
  return e.type || !t || !t.length ? !1 : ya(e).some((n) => bt(n, t));
}
function pa(e, t) {
  if (e.type !== "transaction" || !t || !t.length)
    return !1;
  const n = e.transaction;
  return n ? bt(n, t) : !1;
}
function ma(e, t) {
  if (!t || !t.length)
    return !1;
  const n = ht(e);
  return n ? bt(n, t) : !1;
}
function ha(e, t) {
  if (!t || !t.length)
    return !0;
  const n = ht(e);
  return n ? bt(n, t) : !0;
}
function ya(e) {
  const t = [];
  e.message && t.push(e.message);
  let n;
  try {
    n = e.exception.values[e.exception.values.length - 1];
  } catch {
  }
  return n && n.value && (t.push(n.value), n.type && t.push(`${n.type}: ${n.value}`)), t;
}
function wa(e) {
  try {
    return e.exception.values[0].type === "SentryError";
  } catch {
  }
  return !1;
}
function ba(e = []) {
  for (let t = e.length - 1; t >= 0; t--) {
    const n = e[t];
    if (n && n.filename !== "<anonymous>" && n.filename !== "[native code]")
      return n.filename || null;
  }
  return null;
}
function ht(e) {
  try {
    let t;
    try {
      t = e.exception.values[0].stacktrace.frames;
    } catch {
    }
    return t ? ba(t) : null;
  } catch {
    return R && y.error(`Cannot extract url for event ${ge(e)}`), null;
  }
}
function Ea(e) {
  return e.type || !e.exception || !e.exception.values || e.exception.values.length === 0 ? !1 : (
    // No top-level message
    !e.message && // There are no exception values that have a stacktrace, a non-generic-Error type or value
    !e.exception.values.some((t) => t.stacktrace || t.type && t.type !== "Error" || t.value)
  );
}
const _a = "Dedupe", Sa = () => {
  let e;
  return {
    name: _a,
    processEvent(t) {
      if (t.type)
        return t;
      try {
        if (Aa(t, e))
          return R && y.warn("Event dropped due to being a duplicate of previously captured event."), null;
      } catch {
      }
      return e = t;
    }
  };
}, va = Sa;
function Aa(e, t) {
  return t ? !!(Ia(e, t) || xa(e, t)) : !1;
}
function Ia(e, t) {
  const n = e.message, r = t.message;
  return !(!n && !r || n && !r || !n && r || n !== r || !Zr(e, t) || !Qr(e, t));
}
function xa(e, t) {
  const n = nr(t), r = nr(e);
  return !(!n || !r || n.type !== r.type || n.value !== r.value || !Zr(e, t) || !Qr(e, t));
}
function Qr(e, t) {
  let n = Cn(e), r = Cn(t);
  if (!n && !r)
    return !0;
  if (n && !r || !n && r || (n = n, r = r, r.length !== n.length))
    return !1;
  for (let s = 0; s < r.length; s++) {
    const i = r[s], o = n[s];
    if (i.filename !== o.filename || i.lineno !== o.lineno || i.colno !== o.colno || i.function !== o.function)
      return !1;
  }
  return !0;
}
function Zr(e, t) {
  let n = e.fingerprint, r = t.fingerprint;
  if (!n && !r)
    return !0;
  if (n && !r || !n && r)
    return !1;
  n = n, r = r;
  try {
    return n.join("") === r.join("");
  } catch {
    return !1;
  }
}
function nr(e) {
  return e.exception && e.exception.values && e.exception.values[0];
}
const M = I;
let Yt = 0;
function es() {
  return Yt > 0;
}
function ka() {
  Yt++, setTimeout(() => {
    Yt--;
  });
}
function De(e, t = {}, n) {
  if (typeof e != "function")
    return e;
  try {
    const s = e.__sentry_wrapped__;
    if (s)
      return typeof s == "function" ? s : e;
    if (un(e))
      return e;
  } catch {
    return e;
  }
  const r = function() {
    const s = Array.prototype.slice.call(arguments);
    try {
      const i = s.map((o) => De(o, t));
      return e.apply(this, i);
    } catch (i) {
      throw ka(), Qi((o) => {
        o.addEventProcessor((a) => (t.mechanism && (qt(a, void 0), He(a, t.mechanism)), a.extra = {
          ...a.extra,
          arguments: s
        }, a)), Vr(i);
      }), i;
    }
  };
  try {
    for (const s in e)
      Object.prototype.hasOwnProperty.call(e, s) && (r[s] = e[s]);
  } catch {
  }
  Cr(r, e), Se(e, "__sentry_wrapped__", r);
  try {
    Object.getOwnPropertyDescriptor(r, "name").configurable && Object.defineProperty(r, "name", {
      get() {
        return e.name;
      }
    });
  } catch {
  }
  return r;
}
const Je = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__;
function pn(e, t) {
  const n = mn(e, t), r = {
    type: Oa(t),
    value: Ca(t)
  };
  return n.length && (r.stacktrace = { frames: n }), r.type === void 0 && r.value === "" && (r.value = "Unrecoverable error caught"), r;
}
function Ta(e, t, n, r) {
  const s = N(), i = s && s.getOptions().normalizeDepth, o = La(t), a = {
    __serialized__: Ur(t, i)
  };
  if (o)
    return {
      exception: {
        values: [pn(e, o)]
      },
      extra: a
    };
  const c = {
    exception: {
      values: [
        {
          type: yt(t) ? t.constructor.name : r ? "UnhandledRejection" : "Error",
          value: Fa(t, { isUnhandledRejection: r })
        }
      ]
    },
    extra: a
  };
  if (n) {
    const u = mn(e, n);
    u.length && (c.exception.values[0].stacktrace = { frames: u });
  }
  return c;
}
function Rt(e, t) {
  return {
    exception: {
      values: [pn(e, t)]
    }
  };
}
function mn(e, t) {
  const n = t.stacktrace || t.stack || "", r = Ma(t), s = Pa(t);
  try {
    return e(n, r, s);
  } catch {
  }
  return [];
}
const Ra = /Minified React error #\d+;/i;
function Ma(e) {
  return e && Ra.test(e.message) ? 1 : 0;
}
function Pa(e) {
  return typeof e.framesToPop == "number" ? e.framesToPop : 0;
}
function ts(e) {
  return typeof WebAssembly < "u" && typeof WebAssembly.Exception < "u" ? e instanceof WebAssembly.Exception : !1;
}
function Oa(e) {
  const t = e && e.name;
  return !t && ts(e) ? e.message && Array.isArray(e.message) && e.message.length == 2 ? e.message[0] : "WebAssembly.Exception" : t;
}
function Ca(e) {
  const t = e && e.message;
  return t ? t.error && typeof t.error.message == "string" ? t.error.message : ts(e) && Array.isArray(e.message) && e.message.length == 2 ? e.message[1] : t : "No error message";
}
function Da(e, t, n, r) {
  const s = n && n.syntheticException || void 0, i = hn(e, t, s, r);
  return He(i), i.level = "error", n && n.event_id && (i.event_id = n.event_id), Ae(i);
}
function Na(e, t, n = "info", r, s) {
  const i = r && r.syntheticException || void 0, o = Kt(e, t, i, s);
  return o.level = n, r && r.event_id && (o.event_id = r.event_id), Ae(o);
}
function hn(e, t, n, r, s) {
  let i;
  if (Tr(t) && t.error)
    return Rt(e, t.error);
  if (In(t) || Ds(t)) {
    const o = t;
    if ("stack" in t)
      i = Rt(e, t);
    else {
      const a = o.name || (In(o) ? "DOMError" : "DOMException"), c = o.message ? `${a}: ${o.message}` : a;
      i = Kt(e, c, n, r), qt(i, c);
    }
    return "code" in o && (i.tags = { ...i.tags, "DOMException.code": `${o.code}` }), i;
  }
  return sn(t) ? Rt(e, t) : Pe(t) || yt(t) ? (i = Ta(e, t, n, s), He(i, {
    synthetic: !0
  }), i) : (i = Kt(e, t, n, r), qt(i, `${t}`), He(i, {
    synthetic: !0
  }), i);
}
function Kt(e, t, n, r) {
  const s = {};
  if (r && n) {
    const i = mn(e, n);
    i.length && (s.exception = {
      values: [{ value: t, stacktrace: { frames: i } }]
    });
  }
  if (on(t)) {
    const { __sentry_template_string__: i, __sentry_template_values__: o } = t;
    return s.logentry = {
      message: i,
      params: o
    }, s;
  }
  return s.message = t, s;
}
function Fa(e, { isUnhandledRejection: t }) {
  const n = Zs(e), r = t ? "promise rejection" : "exception";
  return Tr(e) ? `Event \`ErrorEvent\` captured as ${r} with message \`${e.message}\`` : yt(e) ? `Event \`${Ba(e)}\` (type=${e.type}) captured as ${r}` : `Object captured as ${r} with keys: ${n}`;
}
function Ba(e) {
  try {
    const t = Object.getPrototypeOf(e);
    return t ? t.constructor.name : void 0;
  } catch {
  }
}
function La(e) {
  for (const t in e)
    if (Object.prototype.hasOwnProperty.call(e, t)) {
      const n = e[t];
      if (n instanceof Error)
        return n;
    }
}
function $a(e, {
  metadata: t,
  tunnel: n,
  dsn: r
}) {
  const s = {
    event_id: e.event_id,
    sent_at: (/* @__PURE__ */ new Date()).toISOString(),
    ...t && t.sdk && {
      sdk: {
        name: t.sdk.name,
        version: t.sdk.version
      }
    },
    ...!!n && !!r && { dsn: _t(r) }
  }, i = ja(e);
  return Ye(s, [i]);
}
function ja(e) {
  return [{
    type: "user_report"
  }, e];
}
class Ua extends Ko {
  /**
   * Creates a new Browser SDK instance.
   *
   * @param options Configuration options for this SDK.
   */
  constructor(t) {
    const n = {
      // We default this to true, as it is the safer scenario
      parentSpanIsAlwaysRootSpan: !0,
      ...t
    }, r = M.SENTRY_SDK_SOURCE || pi();
    na(n, "browser", ["browser"], r), super(n), n.sendClientReports && M.document && M.document.addEventListener("visibilitychange", () => {
      M.document.visibilityState === "hidden" && this._flushOutcomes();
    });
  }
  /**
   * @inheritDoc
   */
  eventFromException(t, n) {
    return Da(this._options.stackParser, t, n, this._options.attachStacktrace);
  }
  /**
   * @inheritDoc
   */
  eventFromMessage(t, n = "info", r) {
    return Na(this._options.stackParser, t, n, r, this._options.attachStacktrace);
  }
  /**
   * Sends user feedback to Sentry.
   *
   * @deprecated Use `captureFeedback` instead.
   */
  captureUserFeedback(t) {
    if (!this._isEnabled()) {
      Je && y.warn("SDK not enabled, will not capture user feedback.");
      return;
    }
    const n = $a(t, {
      metadata: this.getSdkMetadata(),
      dsn: this.getDsn(),
      tunnel: this.getOptions().tunnel
    });
    this.sendEnvelope(n);
  }
  /**
   * @inheritDoc
   */
  _prepareEvent(t, n, r) {
    return t.platform = t.platform || "javascript", super._prepareEvent(t, n, r);
  }
}
const Wa = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__, F = I, qa = 1e3;
let rr, Jt, Xt;
function Ha(e) {
  const t = "dom";
  xe(t, e), ke(t, Va);
}
function Va() {
  if (!F.document)
    return;
  const e = Q.bind(null, "dom"), t = sr(e, !0);
  F.document.addEventListener("click", t, !1), F.document.addEventListener("keypress", t, !1), ["EventTarget", "Node"].forEach((n) => {
    const r = F[n] && F[n].prototype;
    !r || !r.hasOwnProperty || !r.hasOwnProperty("addEventListener") || (U(r, "addEventListener", function(s) {
      return function(i, o, a) {
        if (i === "click" || i == "keypress")
          try {
            const c = this, u = c.__sentry_instrumentation_handlers__ = c.__sentry_instrumentation_handlers__ || {}, f = u[i] = u[i] || { refCount: 0 };
            if (!f.handler) {
              const g = sr(e);
              f.handler = g, s.call(this, i, g, a);
            }
            f.refCount++;
          } catch {
          }
        return s.call(this, i, o, a);
      };
    }), U(
      r,
      "removeEventListener",
      function(s) {
        return function(i, o, a) {
          if (i === "click" || i == "keypress")
            try {
              const c = this, u = c.__sentry_instrumentation_handlers__ || {}, f = u[i];
              f && (f.refCount--, f.refCount <= 0 && (s.call(this, i, f.handler, a), f.handler = void 0, delete u[i]), Object.keys(u).length === 0 && delete c.__sentry_instrumentation_handlers__);
            } catch {
            }
          return s.call(this, i, o, a);
        };
      }
    ));
  });
}
function Ga(e) {
  if (e.type !== Jt)
    return !1;
  try {
    if (!e.target || e.target._sentryId !== Xt)
      return !1;
  } catch {
  }
  return !0;
}
function za(e, t) {
  return e !== "keypress" ? !1 : !t || !t.tagName ? !0 : !(t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable);
}
function sr(e, t = !1) {
  return (n) => {
    if (!n || n._sentryCaptured)
      return;
    const r = Ya(n);
    if (za(n.type, r))
      return;
    Se(n, "_sentryCaptured", !0), r && !r._sentryId && Se(r, "_sentryId", X());
    const s = n.type === "keypress" ? "input" : n.type;
    Ga(n) || (e({ event: n, name: s, global: t }), Jt = n.type, Xt = r ? r._sentryId : void 0), clearTimeout(rr), rr = F.setTimeout(() => {
      Xt = void 0, Jt = void 0;
    }, qa);
  };
}
function Ya(e) {
  try {
    return e.target;
  } catch {
    return null;
  }
}
let nt;
function ns(e) {
  const t = "history";
  xe(t, e), ke(t, Ka);
}
function Ka() {
  if (!ji())
    return;
  const e = F.onpopstate;
  F.onpopstate = function(...n) {
    const r = F.location.href, s = nt;
    if (nt = r, Q("history", { from: s, to: r }), e)
      try {
        return e.apply(this, n);
      } catch {
      }
  };
  function t(n) {
    return function(...r) {
      const s = r.length > 2 ? r[2] : void 0;
      if (s) {
        const i = nt, o = String(s);
        nt = o, Q("history", { from: i, to: o });
      }
      return n.apply(this, r);
    };
  }
  U(F.history, "pushState", t), U(F.history, "replaceState", t);
}
const ut = {};
function Ja(e) {
  const t = ut[e];
  if (t)
    return t;
  let n = F[e];
  if (Ut(n))
    return ut[e] = n.bind(F);
  const r = F.document;
  if (r && typeof r.createElement == "function")
    try {
      const s = r.createElement("iframe");
      s.hidden = !0, r.head.appendChild(s);
      const i = s.contentWindow;
      i && i[e] && (n = i[e]), r.head.removeChild(s);
    } catch (s) {
      Wa && y.warn(`Could not create sandbox iframe for ${e} check, bailing to window.${e}: `, s);
    }
  return n && (ut[e] = n.bind(F));
}
function ir(e) {
  ut[e] = void 0;
}
const Ue = "__sentry_xhr_v3__";
function Xa(e) {
  const t = "xhr";
  xe(t, e), ke(t, Qa);
}
function Qa() {
  if (!F.XMLHttpRequest)
    return;
  const e = XMLHttpRequest.prototype;
  e.open = new Proxy(e.open, {
    apply(t, n, r) {
      const s = ue() * 1e3, i = ce(r[0]) ? r[0].toUpperCase() : void 0, o = Za(r[1]);
      if (!i || !o)
        return t.apply(n, r);
      n[Ue] = {
        method: i,
        url: o,
        request_headers: {}
      }, i === "POST" && o.match(/sentry_key/) && (n.__sentry_own_request__ = !0);
      const a = () => {
        const c = n[Ue];
        if (c && n.readyState === 4) {
          try {
            c.status_code = n.status;
          } catch {
          }
          const u = {
            endTimestamp: ue() * 1e3,
            startTimestamp: s,
            xhr: n
          };
          Q("xhr", u);
        }
      };
      return "onreadystatechange" in n && typeof n.onreadystatechange == "function" ? n.onreadystatechange = new Proxy(n.onreadystatechange, {
        apply(c, u, f) {
          return a(), c.apply(u, f);
        }
      }) : n.addEventListener("readystatechange", a), n.setRequestHeader = new Proxy(n.setRequestHeader, {
        apply(c, u, f) {
          const [g, h] = f, w = u[Ue];
          return w && ce(g) && ce(h) && (w.request_headers[g.toLowerCase()] = h), c.apply(u, f);
        }
      }), t.apply(n, r);
    }
  }), e.send = new Proxy(e.send, {
    apply(t, n, r) {
      const s = n[Ue];
      if (!s)
        return t.apply(n, r);
      r[0] !== void 0 && (s.body = r[0]);
      const i = {
        startTimestamp: ue() * 1e3,
        xhr: n
      };
      return Q("xhr", i), t.apply(n, r);
    }
  });
}
function Za(e) {
  if (ce(e))
    return e;
  try {
    return e.toString();
  } catch {
  }
}
function ec(e, t = Ja("fetch")) {
  let n = 0, r = 0;
  function s(i) {
    const o = i.body.length;
    n += o, r++;
    const a = {
      body: i.body,
      method: "POST",
      referrerPolicy: "origin",
      headers: e.headers,
      // Outgoing requests are usually cancelled when navigating to a different page, causing a "TypeError: Failed to
      // fetch" error and sending a "network_error" client-outcome - in Chrome, the request status shows "(cancelled)".
      // The `keepalive` flag keeps outgoing requests alive, even when switching pages. We want this since we're
      // frequently sending events right before the user is switching pages (eg. when finishing navigation transactions).
      // Gotchas:
      // - `keepalive` isn't supported by Firefox
      // - As per spec (https://fetch.spec.whatwg.org/#http-network-or-cache-fetch):
      //   If the sum of contentLength and inflightKeepaliveBytes is greater than 64 kibibytes, then return a network error.
      //   We will therefore only activate the flag when we're below that limit.
      // There is also a limit of requests that can be open at the same time, so we also limit this to 15
      // See https://github.com/getsentry/sentry-javascript/pull/7553 for details
      keepalive: n <= 6e4 && r < 15,
      ...e.fetchOptions
    };
    if (!t)
      return ir("fetch"), pt("No fetch implementation available");
    try {
      return t(e.url, a).then((c) => (n -= o, r--, {
        statusCode: c.status,
        headers: {
          "x-sentry-rate-limits": c.headers.get("X-Sentry-Rate-Limits"),
          "retry-after": c.headers.get("Retry-After")
        }
      }));
    } catch (c) {
      return ir("fetch"), n -= o, r--, pt(c);
    }
  }
  return ta(e, s);
}
const tc = 30, nc = 50;
function Qt(e, t, n, r) {
  const s = {
    filename: e,
    function: t === "<anonymous>" ? ve : t,
    in_app: !0
    // All browser frames are considered in_app
  };
  return n !== void 0 && (s.lineno = n), r !== void 0 && (s.colno = r), s;
}
const rc = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i, sc = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, ic = /\((\S*)(?::(\d+))(?::(\d+))\)/, oc = (e) => {
  const t = rc.exec(e);
  if (t) {
    const [, r, s, i] = t;
    return Qt(r, ve, +s, +i);
  }
  const n = sc.exec(e);
  if (n) {
    if (n[2] && n[2].indexOf("eval") === 0) {
      const o = ic.exec(n[2]);
      o && (n[2] = o[1], n[3] = o[2], n[4] = o[3]);
    }
    const [s, i] = rs(n[1] || ve, n[2]);
    return Qt(i, s, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0);
  }
}, ac = [tc, oc], cc = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i, uc = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, dc = (e) => {
  const t = cc.exec(e);
  if (t) {
    if (t[3] && t[3].indexOf(" > eval") > -1) {
      const i = uc.exec(t[3]);
      i && (t[1] = t[1] || "eval", t[3] = i[1], t[4] = i[2], t[5] = "");
    }
    let r = t[3], s = t[1] || ve;
    return [s, r] = rs(s, r), Qt(r, s, t[4] ? +t[4] : void 0, t[5] ? +t[5] : void 0);
  }
}, lc = [nc, dc], fc = [ac, lc], gc = Fr(...fc), rs = (e, t) => {
  const n = e.indexOf("safari-extension") !== -1, r = e.indexOf("safari-web-extension") !== -1;
  return n || r ? [
    e.indexOf("@") !== -1 ? e.split("@")[0] : ve,
    n ? `safari-extension:${t}` : `safari-web-extension:${t}`
  ] : [e, t];
}, rt = 1024, pc = "Breadcrumbs", mc = (e = {}) => {
  const t = {
    console: !0,
    dom: !0,
    fetch: !0,
    history: !0,
    sentry: !0,
    xhr: !0,
    ...e
  };
  return {
    name: pc,
    setup(n) {
      t.console && ri(bc(n)), t.dom && Ha(wc(n, t.dom)), t.xhr && Xa(Ec(n)), t.fetch && ai(_c(n)), t.history && ns(Sc(n)), t.sentry && n.on("beforeSendEvent", yc(n));
    }
  };
}, hc = mc;
function yc(e) {
  return function(n) {
    N() === e && Ie(
      {
        category: `sentry.${n.type === "transaction" ? "transaction" : "event"}`,
        event_id: n.event_id,
        level: n.level,
        message: ge(n)
      },
      {
        event: n
      }
    );
  };
}
function wc(e, t) {
  return function(r) {
    if (N() !== e)
      return;
    let s, i, o = typeof t == "object" ? t.serializeAttribute : void 0, a = typeof t == "object" && typeof t.maxStringLength == "number" ? t.maxStringLength : void 0;
    a && a > rt && (Je && y.warn(
      `\`dom.maxStringLength\` cannot exceed ${rt}, but a value of ${a} was configured. Sentry will use ${rt} instead.`
    ), a = rt), typeof o == "string" && (o = [o]);
    try {
      const u = r.event, f = vc(u) ? u.target : u;
      s = Pr(f, { keyAttrs: o, maxStringLength: a }), i = Hs(f);
    } catch {
      s = "<unknown>";
    }
    if (s.length === 0)
      return;
    const c = {
      category: `ui.${r.name}`,
      message: s
    };
    i && (c.data = { "ui.component_name": i }), Ie(c, {
      event: r.event,
      name: r.name,
      global: r.global
    });
  };
}
function bc(e) {
  return function(n) {
    if (N() !== e)
      return;
    const r = {
      category: "console",
      data: {
        arguments: n.args,
        logger: "console"
      },
      level: Si(n.level),
      message: xn(n.args, " ")
    };
    if (n.level === "assert")
      if (n.args[0] === !1)
        r.message = `Assertion failed: ${xn(n.args.slice(1), " ") || "console.assert"}`, r.data.arguments = n.args.slice(1);
      else
        return;
    Ie(r, {
      input: n.args,
      level: n.level
    });
  };
}
function Ec(e) {
  return function(n) {
    if (N() !== e)
      return;
    const { startTimestamp: r, endTimestamp: s } = n, i = n.xhr[Ue];
    if (!r || !s || !i)
      return;
    const { method: o, url: a, status_code: c, body: u } = i, f = {
      method: o,
      url: a,
      status_code: c
    }, g = {
      xhr: n.xhr,
      input: u,
      startTimestamp: r,
      endTimestamp: s
    }, h = Mr(c);
    Ie(
      {
        category: "xhr",
        data: f,
        type: "http",
        level: h
      },
      g
    );
  };
}
function _c(e) {
  return function(n) {
    if (N() !== e)
      return;
    const { startTimestamp: r, endTimestamp: s } = n;
    if (s && !(n.fetchData.url.match(/sentry_key/) && n.fetchData.method === "POST"))
      if (n.error) {
        const i = n.fetchData, o = {
          data: n.error,
          input: n.args,
          startTimestamp: r,
          endTimestamp: s
        };
        Ie(
          {
            category: "fetch",
            data: i,
            level: "error",
            type: "http"
          },
          o
        );
      } else {
        const i = n.response, o = {
          ...n.fetchData,
          status_code: i && i.status
        }, a = {
          input: n.args,
          response: i,
          startTimestamp: r,
          endTimestamp: s
        }, c = Mr(o.status_code);
        Ie(
          {
            category: "fetch",
            data: o,
            type: "http",
            level: c
          },
          a
        );
      }
  };
}
function Sc(e) {
  return function(n) {
    if (N() !== e)
      return;
    let r = n.from, s = n.to;
    const i = Tt(M.location.href);
    let o = r ? Tt(r) : void 0;
    const a = Tt(s);
    (!o || !o.path) && (o = i), i.protocol === a.protocol && i.host === a.host && (s = a.relative), i.protocol === o.protocol && i.host === o.host && (r = o.relative), Ie({
      category: "navigation",
      data: {
        from: r,
        to: s
      }
    });
  };
}
function vc(e) {
  return !!e && !!e.target;
}
const Ac = [
  "EventTarget",
  "Window",
  "Node",
  "ApplicationCache",
  "AudioTrackList",
  "BroadcastChannel",
  "ChannelMergerNode",
  "CryptoOperation",
  "EventSource",
  "FileReader",
  "HTMLUnknownElement",
  "IDBDatabase",
  "IDBRequest",
  "IDBTransaction",
  "KeyOperation",
  "MediaController",
  "MessagePort",
  "ModalWindow",
  "Notification",
  "SVGElementInstance",
  "Screen",
  "SharedWorker",
  "TextTrack",
  "TextTrackCue",
  "TextTrackList",
  "WebSocket",
  "WebSocketWorker",
  "Worker",
  "XMLHttpRequest",
  "XMLHttpRequestEventTarget",
  "XMLHttpRequestUpload"
], Ic = "BrowserApiErrors", xc = (e = {}) => {
  const t = {
    XMLHttpRequest: !0,
    eventTarget: !0,
    requestAnimationFrame: !0,
    setInterval: !0,
    setTimeout: !0,
    ...e
  };
  return {
    name: Ic,
    // TODO: This currently only works for the first client this is setup
    // We may want to adjust this to check for client etc.
    setupOnce() {
      t.setTimeout && U(M, "setTimeout", or), t.setInterval && U(M, "setInterval", or), t.requestAnimationFrame && U(M, "requestAnimationFrame", Tc), t.XMLHttpRequest && "XMLHttpRequest" in M && U(XMLHttpRequest.prototype, "send", Rc);
      const n = t.eventTarget;
      n && (Array.isArray(n) ? n : Ac).forEach(Mc);
    }
  };
}, kc = xc;
function or(e) {
  return function(...t) {
    const n = t[0];
    return t[0] = De(n, {
      mechanism: {
        data: { function: he(e) },
        handled: !1,
        type: "instrument"
      }
    }), e.apply(this, t);
  };
}
function Tc(e) {
  return function(t) {
    return e.apply(this, [
      De(t, {
        mechanism: {
          data: {
            function: "requestAnimationFrame",
            handler: he(e)
          },
          handled: !1,
          type: "instrument"
        }
      })
    ]);
  };
}
function Rc(e) {
  return function(...t) {
    const n = this;
    return ["onload", "onerror", "onprogress", "onreadystatechange"].forEach((s) => {
      s in n && typeof n[s] == "function" && U(n, s, function(i) {
        const o = {
          mechanism: {
            data: {
              function: s,
              handler: he(i)
            },
            handled: !1,
            type: "instrument"
          }
        }, a = un(i);
        return a && (o.mechanism.data.handler = he(a)), De(i, o);
      });
    }), e.apply(this, t);
  };
}
function Mc(e) {
  const t = M, n = t[e] && t[e].prototype;
  !n || !n.hasOwnProperty || !n.hasOwnProperty("addEventListener") || (U(n, "addEventListener", function(r) {
    return function(s, i, o) {
      try {
        typeof i.handleEvent == "function" && (i.handleEvent = De(i.handleEvent, {
          mechanism: {
            data: {
              function: "handleEvent",
              handler: he(i),
              target: e
            },
            handled: !1,
            type: "instrument"
          }
        }));
      } catch {
      }
      return r.apply(this, [
        s,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        De(i, {
          mechanism: {
            data: {
              function: "addEventListener",
              handler: he(i),
              target: e
            },
            handled: !1,
            type: "instrument"
          }
        }),
        o
      ]);
    };
  }), U(
    n,
    "removeEventListener",
    function(r) {
      return function(s, i, o) {
        const a = i;
        try {
          const c = a && a.__sentry_wrapped__;
          c && r.call(this, s, c, o);
        } catch {
        }
        return r.call(this, s, a, o);
      };
    }
  ));
}
const Pc = "GlobalHandlers", Oc = (e = {}) => {
  const t = {
    onerror: !0,
    onunhandledrejection: !0,
    ...e
  };
  return {
    name: Pc,
    setupOnce() {
      Error.stackTraceLimit = 50;
    },
    setup(n) {
      t.onerror && (Dc(n), ar("onerror")), t.onunhandledrejection && (Nc(n), ar("onunhandledrejection"));
    }
  };
}, Cc = Oc;
function Dc(e) {
  di((t) => {
    const { stackParser: n, attachStacktrace: r } = ss();
    if (N() !== e || es())
      return;
    const { msg: s, url: i, line: o, column: a, error: c } = t, u = Lc(
      hn(n, c || s, void 0, r, !1),
      i,
      o,
      a
    );
    u.level = "error", Gr(u, {
      originalException: c,
      mechanism: {
        handled: !1,
        type: "onerror"
      }
    });
  });
}
function Nc(e) {
  fi((t) => {
    const { stackParser: n, attachStacktrace: r } = ss();
    if (N() !== e || es())
      return;
    const s = Fc(t), i = an(s) ? Bc(s) : hn(n, s, void 0, r, !0);
    i.level = "error", Gr(i, {
      originalException: s,
      mechanism: {
        handled: !1,
        type: "onunhandledrejection"
      }
    });
  });
}
function Fc(e) {
  if (an(e))
    return e;
  try {
    if ("reason" in e)
      return e.reason;
    if ("detail" in e && "reason" in e.detail)
      return e.detail.reason;
  } catch {
  }
  return e;
}
function Bc(e) {
  return {
    exception: {
      values: [
        {
          type: "UnhandledRejection",
          // String() is needed because the Primitive type includes symbols (which can't be automatically stringified)
          value: `Non-Error promise rejection captured with value: ${String(e)}`
        }
      ]
    }
  };
}
function Lc(e, t, n, r) {
  const s = e.exception = e.exception || {}, i = s.values = s.values || [], o = i[0] = i[0] || {}, a = o.stacktrace = o.stacktrace || {}, c = a.frames = a.frames || [], u = isNaN(parseInt(r, 10)) ? void 0 : r, f = isNaN(parseInt(n, 10)) ? void 0 : n, g = ce(t) && t.length > 0 ? t : qs();
  return c.length === 0 && c.push({
    colno: u,
    filename: g,
    function: ve,
    in_app: !0,
    lineno: f
  }), e;
}
function ar(e) {
  Je && y.log(`Global Handler attached: ${e}`);
}
function ss() {
  const e = N();
  return e && e.getOptions() || {
    stackParser: () => [],
    attachStacktrace: !1
  };
}
const $c = () => ({
  name: "HttpContext",
  preprocessEvent(e) {
    if (!M.navigator && !M.location && !M.document)
      return;
    const t = e.request && e.request.url || M.location && M.location.href, { referrer: n } = M.document || {}, { userAgent: r } = M.navigator || {}, s = {
      ...e.request && e.request.headers,
      ...n && { Referer: n },
      ...r && { "User-Agent": r }
    }, i = { ...e.request, ...t && { url: t }, headers: s };
    e.request = i;
  }
}), jc = "cause", Uc = 5, Wc = "LinkedErrors", qc = (e = {}) => {
  const t = e.limit || Uc, n = e.key || jc;
  return {
    name: Wc,
    preprocessEvent(r, s, i) {
      const o = i.getOptions();
      $s(
        // This differs from the LinkedErrors integration in core by using a different exceptionFromError function
        pn,
        o.stackParser,
        o.maxValueLength,
        n,
        t,
        r,
        s
      );
    }
  };
}, Hc = qc;
function Vc(e) {
  return [
    da(),
    oa(),
    kc(),
    hc(),
    Cc(),
    Hc(),
    va(),
    $c()
  ];
}
function Gc(e = {}) {
  const t = {
    defaultIntegrations: Vc(),
    release: typeof __SENTRY_RELEASE__ == "string" ? __SENTRY_RELEASE__ : M.SENTRY_RELEASE && M.SENTRY_RELEASE.id ? M.SENTRY_RELEASE.id : void 0,
    autoSessionTracking: !0,
    sendClientReports: !0
  };
  return e.defaultIntegrations == null && delete e.defaultIntegrations, { ...t, ...e };
}
function zc() {
  const e = typeof M.window < "u" && M;
  if (!e)
    return !1;
  const t = e.chrome ? "chrome" : "browser", n = e[t], r = n && n.runtime && n.runtime.id, s = M.location && M.location.href || "", i = ["chrome-extension:", "moz-extension:", "ms-browser-extension:", "safari-web-extension:"], o = !!r && M === M.top && i.some((c) => s.startsWith(`${c}//`)), a = typeof e.nw < "u";
  return !!r && !o && !a;
}
function Yc(e = {}) {
  const t = Gc(e);
  if (!t.skipBrowserExtensionCheck && zc()) {
    Ge(() => {
      console.error(
        "[Sentry] You cannot run Sentry this way in a browser extension, check: https://docs.sentry.io/platforms/javascript/best-practices/browser-extensions/"
      );
    });
    return;
  }
  Je && (Br() || y.warn(
    "No Fetch API detected. The Sentry SDK requires a Fetch API compatible environment to send events. Please add a Fetch API polyfill."
  ));
  const n = {
    ...t,
    stackParser: ti(t.stackParser || gc),
    integrations: zo(t),
    transport: t.transport || ec
  }, r = Qo(Ua, n);
  return t.autoSessionTracking && Kc(), r;
}
function Kc() {
  if (typeof M.document > "u") {
    Je && y.warn("Session tracking in non-browser environment with @sentry/browser is not supported.");
    return;
  }
  Yn({ ignoreDuration: !0 }), Kn(), ns(({ from: e, to: t }) => {
    e !== void 0 && e !== t && (Yn({ ignoreDuration: !0 }), Kn());
  });
}
const Jc = {
  dsn: "https://994d391237a545639aae5ecfb006680b@sentry.io/1800853",
  release: "extension@1.98.25-4f91ed0",
  environment: "production",
  attachProps: !1,
  logErrors: !0,
  ignoreErrors: [
    // Comming from video in session page https://bugs.chromium.org/p/chromium/issues/detail?id=809574
    "ResizeObserver loop limit exceeded",
    // Ignore rare IndexedDB issues we can't do anything about, which spam Sentry logs to an unbearable degree.
    // These issues are not entirely swallowed - debounced errors are sent to Sentry from `indexedDB.js`.
    "IndexedDB connection terminated",
    "Failed to execute 'transaction' on 'IDBDatabase': The database connection is closing.",
    "UnknownError: Internal error opening backing store for indexedDB.open.",
    "UnknownError: Internal error committing transaction.",
    "DataError: Failed to read large IndexedDB value",
    "AbortError: AbortError",
    // Ignore exception during DOM playback, see e.g. https://bird-eats-bug.sentry.io/issues/4040187945
    "The play() request was interrupted because the media was removed from the document.",
    "Cannot read properties of null (reading 'scrollTo')",
    // Ignore exception from outdated browser running our extension, see https://bird-eats-bug.sentry.io/issues/5414798440/
    "runtime.getContexts is not a function",
    // Ignore issue that popped up with MV 3 transition, probably due to the offscreen page - it does not have any traces attached, and has not been connected to issues experienced by users yet.
    "Frame with ID 0 is showing error page"
  ]
};
function Xc() {
  if (jo())
    throw new Error("Sentry cannot be initialized twice, because it can override options.");
  Yc({
    ...Jc
  });
}
const x = {
  inherit: "inherit",
  transparent: "transparent",
  white: "#FFFFFF",
  "gray-100": "#F4FAFF",
  "gray-200": "#E2E8F4",
  "gray-300": "#C1CBDC",
  "gray-350": "#a3adbe",
  "gray-400": "#8C95A8",
  "gray-500": "#4B566B",
  "gray-550": "#3D485D",
  "gray-600": "#353D4D",
  "gray-650": "#2C3443",
  "gray-700": "#222A39",
  "gray-800": "#1A202C",
  "gray-900": "#141622",
  "red-100": "#FFE0D0",
  "red-300": "#DA7D80",
  "red-400": "#FF7C6C",
  "red-500": "#FF6E64",
  "red-600": "#F24F39",
  "green-200": "#8ADC89",
  "green-300": "#1DE297",
  "green-500": "#00C57A",
  "green-800": "#00BA77",
  "blue-500": "#0BA7FF",
  "blue-700": "#0062a4",
  "blue-browserstack": "#2563EB",
  "yellow-400": "#FAD878",
  "yellow-500": "#FECE2F"
};
x.red = x["red-500"];
x.green = x["green-500"];
x.blue = x["blue-500"];
x.yellow = x["yellow-500"];
x.error = x["red-500"];
x.primary = x["green-500"];
x.warn = x["yellow-500"];
x.step = x["blue-500"];
x.video = x["green-500"];
x["background-dark"] = x["gray-800"];
x["background-light"] = x["gray-700"];
x.scrollbar = x["gray-900"];
x.badge = x["blue-browserstack"];
x.banner = x["blue-500"];
let is;
is = function() {
};
const Xe = is;
function Qc(e) {
  if (wn(e))
    return eu(e);
  if (bn(e))
    return st(e);
  if (En(e))
    return st(e);
  if (yn(e))
    return st(e);
  if (Zc(e))
    return st(e);
}
function yn(e) {
  return e.statusCode >= 400 && e.statusCode < 600;
}
function wn(e) {
  return e.error === "net::ERR_BLOCKED_BY_CLIENT";
}
function bn(e) {
  return e.error === "net::ERR_CACHE_MISS";
}
function En(e) {
  return e.error === "net::ERR_ABORTED";
}
function Zc(e) {
  return !!(e.error && !yn(e) && !wn(e) && !bn(e) && !En(e));
}
function st(e) {
  return {
    type: "network",
    ...os(e)
  };
}
function eu(e) {
  return {
    type: "networkBlocked",
    ...os(e)
  };
}
function os(e) {
  return {
    requestId: e.id || e.requestId,
    method: e.method,
    url: e.url,
    createdAt: e.endedAt,
    error: e.error,
    statusCode: e.statusCode
  };
}
function tu(e) {
  e = parseInt(e);
  let t = e > -1e3 ? "" : "-";
  const { hours: n, minutes: r, seconds: s } = nu(e);
  n > 0 && (t += n + ":");
  const i = n > 0 ? String(r).padStart(2, "0") : r;
  return t += i + ":", t += String(s).padStart(2, "0"), t;
}
function nu(e) {
  e = Math.abs(e);
  const t = Math.floor(e / 1e3 / 60 / 60 / 24);
  e -= t * 1e3 * 60 * 60 * 24;
  const n = Math.floor(e / 1e3 / 60 / 60);
  e -= n * 1e3 * 60 * 60;
  const r = Math.floor(e / 1e3 / 60);
  e -= r * 1e3 * 60;
  const s = Math.floor(e / 1e3);
  e -= s * 1e3;
  const i = Math.floor(e);
  return { days: t, hours: n, minutes: r, seconds: s, milliseconds: i };
}
function as(e) {
  return new Promise((t) => setTimeout(t, e));
}
function ru(e) {
  if (![
    "The tab was closed.",
    "No tab with id:",
    "Cannot access contents of url ",
    "This page cannot be scripted due to an ExtensionsSettings policy.",
    "The extensions gallery cannot be scripted.",
    "Cannot access a chrome-extension:// URL of different extension",
    "The frame was removed.",
    // See https://developer.chrome.com/blog/bfcache-extension-messaging-changes
    "The page keeping the extension port is moved into back/forward cache, so the message channel is closed.",
    // NOTE: this entry below does not make sense because we DO request access to all URLs.
    // However, it is regularly thrown with MV3 when executing scripts on URLs that are covered like https://www.npmjs.com
    // and somehow it seems that content script injection still works.
    "Cannot access contents of the page. Extension manifest must request permission to access the respective host."
  ].some((n) => {
    var r;
    return (r = e.message) == null ? void 0 : r.startsWith(n);
  }))
    throw e;
}
function $(e) {
  if (![
    "The tab was closed.",
    "No tab with id:",
    "Could not establish connection."
  ].some((n) => {
    var r;
    return (r = e.message) == null ? void 0 : r.startsWith(n);
  }))
    throw e;
}
function dt(e) {
  return l.action.setIcon({
    tabId: e,
    path: {
      16: "/icons/16.png",
      48: "/icons/48.png"
    }
  }).catch((t) => {
    $(t);
  });
}
function Ve(e, t = "") {
  return l.action.setBadgeText({
    text: String(t),
    tabId: parseInt(e)
  }).catch((n) => {
    $(n);
  });
}
async function cr(e) {
  return await l.action.setIcon({
    tabId: e,
    path: {
      16: "/icons/16-p.png",
      48: "/icons/48-p.png"
    }
  }).catch((t) => {
    $(t);
  }), Ve(e, "");
}
async function it(e) {
  return (await l.windows.getAll({ populate: !0 })).flatMap((n) => n.tabs.map((r) => e(r)));
}
const su = ["Tabs cannot be queried right now", "Tabs cannot be edited right now"];
async function Re(e) {
  if (e) {
    if (typeof e == "object")
      return e;
    if (!(!Number.isInteger(e) || e < 0))
      try {
        return await l.tabs.get(e);
      } catch (t) {
        if (su.some((n) => {
          var r;
          return (r = t.message) == null ? void 0 : r.startsWith(n);
        }))
          return await as(50), Re(e);
        $(t);
      }
  }
}
async function cs(e) {
  try {
    await l.action.setIcon({
      tabId: e,
      path: {
        16: "/icons/16-d.png",
        48: "/icons/48-d.png"
      }
    });
  } catch (t) {
    $(t);
  }
  return Ve(e, "");
}
const iu = [
  {
    regex: new RegExp("about:blank"),
    isInjectable: !1,
    isPossible: !1,
    reason: "For security reasons the browser restricts extensions from running scripts on special pages such as about:blank."
  },
  {
    regex: new RegExp("^file://.*$"),
    isInjectable: !1,
    isPossible: !1,
    reason: "For security reasons the browser restricts extensions from accessing local files. If you would like support for this feature please let us now. In the meanwhile please use a development server to access your file."
  },
  {
    regex: new RegExp("^chrome://.*$"),
    isInjectable: !1,
    isPossible: !1,
    reason: "For security reasons the browser restricts extensions from running scripts on special pages such as the Chrome webstore or browser settings."
  },
  {
    regex: new RegExp(`^${l.runtime.getURL("")}.*$`),
    isInjectable: !1,
    isPossible: !0
  },
  {
    regex: new RegExp("^chrome-extension://.*$"),
    isInjectable: !1,
    isPossible: !1,
    reason: "You are currently in another extension's page. The Bird extension does not have access to it and cannot support it."
    // TODO: update other messages to look like this one, since it seems to be more user friendly.
  },
  {
    regex: new RegExp("^chrome-error://.*$"),
    isInjectable: !1,
    isPossible: !1,
    reason: "For security reasons the browser restricts extensions from running scripts on special pages such as the Chrome error page."
  },
  {
    regex: new RegExp("^chrome-.*://.*$"),
    isInjectable: !1,
    isPossible: !1,
    reason: "For security reasons the browser restricts extensions from running scripts on special pages such as the Chrome webstore or browser settings."
  },
  {
    regex: new RegExp("^https://chrome.google.com/webstore.*$"),
    isInjectable: !1,
    isPossible: !1,
    reason: "For security reasons the browser restricts extensions from running scripts on the Chrome Webstore."
  },
  {
    // http + https
    regex: new RegExp("^https?://"),
    isInjectable: !0,
    isPossible: !0,
    reason: "For security reasons the browser restricts extensions from running scripts on special pages such as the extension store or browser settings."
  },
  {
    // disallow everything else
    regex: new RegExp(""),
    isInjectable: !1,
    isPossible: !1,
    reason: "For security reasons the browser restricts extensions from running scripts on special pages such as the extension webstore or browser settings."
  }
];
function _n(e) {
  return iu.find((t) => t.regex.test(e));
}
async function We(e, t) {
  if (!(e != null && e.id))
    throw new Error(`setupContentScript called without valid tab: ${e}`);
  try {
    if (!await l.tabs.sendMessage(e.id, { to: t, name: "setup" }))
      throw new Error("no response");
  } catch {
    if (!_n(e == null ? void 0 : e.url).isInjectable)
      return;
    try {
      await l.scripting.executeScript({
        target: { tabId: e.id },
        files: [`js/contentScripts/${t}.js`],
        injectImmediately: !0
      }), dt(e.id), Xe(`setupContentScript injected '${t}.js' into tab ${e.id} with URL ${e.url}`);
    } catch (r) {
      cs(e.id), ru(r), console.warn(
        `setupContentScript ${t}.js injection into tab ${e.id} with URL ${e.url} error: ${r.message}`
      );
    }
  }
}
function ou(e) {
  if (!Array.isArray(e) || e.length === 0)
    return [];
  const t = [];
  let n = -1;
  return e.forEach((r) => {
    var a, c;
    const [s, i] = ((a = r.createdAt) == null ? void 0 : a.split(".")) || [];
    delete r.id;
    const o = JSON.stringify({ ...r, createdAt: s });
    ((c = t[n]) == null ? void 0 : c.stringifiedEvent) === o ? t[n].count++ : (t.push({ stringifiedEvent: o, count: 1, ms: i }), n++);
  }), t.map(({ count: r, ms: s, stringifiedEvent: i }) => {
    const o = JSON.parse(i);
    return o.createdAt && s && (o.createdAt += `.${s}`), { ...o, count: r };
  });
}
function au(e = [], t) {
  return [...e].sort((n, r) => n[t] > r[t] ? 1 : n[t] < r[t] ? -1 : 0);
}
async function cu() {
  var t;
  const e = await ((t = l.windows) == null ? void 0 : t.getAll({ populate: !0 }));
  return (e == null ? void 0 : e.flatMap((n) => n.tabs).filter((n) => n.id && n.url)) || [];
}
let uu = (e = 21) => crypto.getRandomValues(new Uint8Array(e)).reduce((t, n) => (n &= 63, n < 36 ? t += n.toString(36) : n < 62 ? t += (n - 26).toString(36).toUpperCase() : n > 62 ? t += "-" : t += "_", t), "");
const du = {
  "Amazon Silk": "amazon_silk",
  "Android Browser": "android",
  Bada: "bada",
  BlackBerry: "blackberry",
  Chrome: "chrome",
  Chromium: "chromium",
  Electron: "electron",
  Epiphany: "epiphany",
  Firefox: "firefox",
  Focus: "focus",
  Generic: "generic",
  "Google Search": "google_search",
  Googlebot: "googlebot",
  "Internet Explorer": "ie",
  "K-Meleon": "k_meleon",
  Maxthon: "maxthon",
  "Microsoft Edge": "edge",
  "MZ Browser": "mz",
  "NAVER Whale Browser": "naver",
  Opera: "opera",
  "Opera Coast": "opera_coast",
  PhantomJS: "phantomjs",
  Puffin: "puffin",
  QupZilla: "qupzilla",
  QQ: "qq",
  QQLite: "qqlite",
  Safari: "safari",
  Sailfish: "sailfish",
  "Samsung Internet for Android": "samsung_internet",
  SeaMonkey: "seamonkey",
  Sleipnir: "sleipnir",
  Swing: "swing",
  Tizen: "tizen",
  "UC Browser": "uc",
  Vivaldi: "vivaldi",
  "WebOS Browser": "webos",
  WeChat: "wechat",
  "Yandex Browser": "yandex",
  Roku: "roku"
}, us = {
  amazon_silk: "Amazon Silk",
  android: "Android Browser",
  bada: "Bada",
  blackberry: "BlackBerry",
  chrome: "Chrome",
  chromium: "Chromium",
  electron: "Electron",
  epiphany: "Epiphany",
  firefox: "Firefox",
  focus: "Focus",
  generic: "Generic",
  googlebot: "Googlebot",
  google_search: "Google Search",
  ie: "Internet Explorer",
  k_meleon: "K-Meleon",
  maxthon: "Maxthon",
  edge: "Microsoft Edge",
  mz: "MZ Browser",
  naver: "NAVER Whale Browser",
  opera: "Opera",
  opera_coast: "Opera Coast",
  phantomjs: "PhantomJS",
  puffin: "Puffin",
  qupzilla: "QupZilla",
  qq: "QQ Browser",
  qqlite: "QQ Browser Lite",
  safari: "Safari",
  sailfish: "Sailfish",
  samsung_internet: "Samsung Internet for Android",
  seamonkey: "SeaMonkey",
  sleipnir: "Sleipnir",
  swing: "Swing",
  tizen: "Tizen",
  uc: "UC Browser",
  vivaldi: "Vivaldi",
  webos: "WebOS Browser",
  wechat: "WeChat",
  yandex: "Yandex Browser"
}, P = {
  tablet: "tablet",
  mobile: "mobile",
  desktop: "desktop",
  tv: "tv"
}, B = {
  WindowsPhone: "Windows Phone",
  Windows: "Windows",
  MacOS: "macOS",
  iOS: "iOS",
  Android: "Android",
  WebOS: "WebOS",
  BlackBerry: "BlackBerry",
  Bada: "Bada",
  Tizen: "Tizen",
  Linux: "Linux",
  ChromeOS: "Chrome OS",
  PlayStation4: "PlayStation 4",
  Roku: "Roku"
}, fe = {
  EdgeHTML: "EdgeHTML",
  Blink: "Blink",
  Trident: "Trident",
  Presto: "Presto",
  Gecko: "Gecko",
  WebKit: "WebKit"
};
class d {
  /**
   * Get first matched item for a string
   * @param {RegExp} regexp
   * @param {String} ua
   * @return {Array|{index: number, input: string}|*|boolean|string}
   */
  static getFirstMatch(t, n) {
    const r = n.match(t);
    return r && r.length > 0 && r[1] || "";
  }
  /**
   * Get second matched item for a string
   * @param regexp
   * @param {String} ua
   * @return {Array|{index: number, input: string}|*|boolean|string}
   */
  static getSecondMatch(t, n) {
    const r = n.match(t);
    return r && r.length > 1 && r[2] || "";
  }
  /**
   * Match a regexp and return a constant or undefined
   * @param {RegExp} regexp
   * @param {String} ua
   * @param {*} _const Any const that will be returned if regexp matches the string
   * @return {*}
   */
  static matchAndReturnConst(t, n, r) {
    if (t.test(n))
      return r;
  }
  static getWindowsVersionName(t) {
    switch (t) {
      case "NT":
        return "NT";
      case "XP":
        return "XP";
      case "NT 5.0":
        return "2000";
      case "NT 5.1":
        return "XP";
      case "NT 5.2":
        return "2003";
      case "NT 6.0":
        return "Vista";
      case "NT 6.1":
        return "7";
      case "NT 6.2":
        return "8";
      case "NT 6.3":
        return "8.1";
      case "NT 10.0":
        return "10";
      default:
        return;
    }
  }
  /**
   * Get macOS version name
   *    10.5 - Leopard
   *    10.6 - Snow Leopard
   *    10.7 - Lion
   *    10.8 - Mountain Lion
   *    10.9 - Mavericks
   *    10.10 - Yosemite
   *    10.11 - El Capitan
   *    10.12 - Sierra
   *    10.13 - High Sierra
   *    10.14 - Mojave
   *    10.15 - Catalina
   *
   * @example
   *   getMacOSVersionName("10.14") // 'Mojave'
   *
   * @param  {string} version
   * @return {string} versionName
   */
  static getMacOSVersionName(t) {
    const n = t.split(".").splice(0, 2).map((r) => parseInt(r, 10) || 0);
    if (n.push(0), n[0] === 10)
      switch (n[1]) {
        case 5:
          return "Leopard";
        case 6:
          return "Snow Leopard";
        case 7:
          return "Lion";
        case 8:
          return "Mountain Lion";
        case 9:
          return "Mavericks";
        case 10:
          return "Yosemite";
        case 11:
          return "El Capitan";
        case 12:
          return "Sierra";
        case 13:
          return "High Sierra";
        case 14:
          return "Mojave";
        case 15:
          return "Catalina";
        default:
          return;
      }
  }
  /**
   * Get Android version name
   *    1.5 - Cupcake
   *    1.6 - Donut
   *    2.0 - Eclair
   *    2.1 - Eclair
   *    2.2 - Froyo
   *    2.x - Gingerbread
   *    3.x - Honeycomb
   *    4.0 - Ice Cream Sandwich
   *    4.1 - Jelly Bean
   *    4.4 - KitKat
   *    5.x - Lollipop
   *    6.x - Marshmallow
   *    7.x - Nougat
   *    8.x - Oreo
   *    9.x - Pie
   *
   * @example
   *   getAndroidVersionName("7.0") // 'Nougat'
   *
   * @param  {string} version
   * @return {string} versionName
   */
  static getAndroidVersionName(t) {
    const n = t.split(".").splice(0, 2).map((r) => parseInt(r, 10) || 0);
    if (n.push(0), !(n[0] === 1 && n[1] < 5)) {
      if (n[0] === 1 && n[1] < 6)
        return "Cupcake";
      if (n[0] === 1 && n[1] >= 6)
        return "Donut";
      if (n[0] === 2 && n[1] < 2)
        return "Eclair";
      if (n[0] === 2 && n[1] === 2)
        return "Froyo";
      if (n[0] === 2 && n[1] > 2)
        return "Gingerbread";
      if (n[0] === 3)
        return "Honeycomb";
      if (n[0] === 4 && n[1] < 1)
        return "Ice Cream Sandwich";
      if (n[0] === 4 && n[1] < 4)
        return "Jelly Bean";
      if (n[0] === 4 && n[1] >= 4)
        return "KitKat";
      if (n[0] === 5)
        return "Lollipop";
      if (n[0] === 6)
        return "Marshmallow";
      if (n[0] === 7)
        return "Nougat";
      if (n[0] === 8)
        return "Oreo";
      if (n[0] === 9)
        return "Pie";
    }
  }
  /**
   * Get version precisions count
   *
   * @example
   *   getVersionPrecision("1.10.3") // 3
   *
   * @param  {string} version
   * @return {number}
   */
  static getVersionPrecision(t) {
    return t.split(".").length;
  }
  /**
   * Calculate browser version weight
   *
   * @example
   *   compareVersions('1.10.2.1',  '1.8.2.1.90')    // 1
   *   compareVersions('1.010.2.1', '1.09.2.1.90');  // 1
   *   compareVersions('1.10.2.1',  '1.10.2.1');     // 0
   *   compareVersions('1.10.2.1',  '1.0800.2');     // -1
   *   compareVersions('1.10.2.1',  '1.10',  true);  // 0
   *
   * @param {String} versionA versions versions to compare
   * @param {String} versionB versions versions to compare
   * @param {boolean} [isLoose] enable loose comparison
   * @return {Number} comparison result: -1 when versionA is lower,
   * 1 when versionA is bigger, 0 when both equal
   */
  /* eslint consistent-return: 1 */
  static compareVersions(t, n, r = !1) {
    const s = d.getVersionPrecision(t), i = d.getVersionPrecision(n);
    let o = Math.max(s, i), a = 0;
    const c = d.map([t, n], (u) => {
      const f = o - d.getVersionPrecision(u), g = u + new Array(f + 1).join(".0");
      return d.map(g.split("."), (h) => new Array(20 - h.length).join("0") + h).reverse();
    });
    for (r && (a = o - Math.min(s, i)), o -= 1; o >= a; ) {
      if (c[0][o] > c[1][o])
        return 1;
      if (c[0][o] === c[1][o]) {
        if (o === a)
          return 0;
        o -= 1;
      } else if (c[0][o] < c[1][o])
        return -1;
    }
  }
  /**
   * Array::map polyfill
   *
   * @param  {Array} arr
   * @param  {Function} iterator
   * @return {Array}
   */
  static map(t, n) {
    const r = [];
    let s;
    if (Array.prototype.map)
      return Array.prototype.map.call(t, n);
    for (s = 0; s < t.length; s += 1)
      r.push(n(t[s]));
    return r;
  }
  /**
   * Array::find polyfill
   *
   * @param  {Array} arr
   * @param  {Function} predicate
   * @return {Array}
   */
  static find(t, n) {
    let r, s;
    if (Array.prototype.find)
      return Array.prototype.find.call(t, n);
    for (r = 0, s = t.length; r < s; r += 1) {
      const i = t[r];
      if (n(i, r))
        return i;
    }
  }
  /**
   * Object::assign polyfill
   *
   * @param  {Object} obj
   * @param  {Object} ...objs
   * @return {Object}
   */
  static assign(t, ...n) {
    const r = t;
    let s, i;
    if (Object.assign)
      return Object.assign(t, ...n);
    for (s = 0, i = n.length; s < i; s += 1) {
      const o = n[s];
      typeof o == "object" && o !== null && Object.keys(o).forEach((c) => {
        r[c] = o[c];
      });
    }
    return t;
  }
  /**
   * Get short version/alias for a browser name
   *
   * @example
   *   getBrowserAlias('Microsoft Edge') // edge
   *
   * @param  {string} browserName
   * @return {string}
   */
  static getBrowserAlias(t) {
    return du[t];
  }
  /**
   * Get short version/alias for a browser name
   *
   * @example
   *   getBrowserAlias('edge') // Microsoft Edge
   *
   * @param  {string} browserAlias
   * @return {string}
   */
  static getBrowserTypeByAlias(t) {
    return us[t] || "";
  }
}
const T = /version\/(\d+(\.?_?\d+)+)/i, lu = [
  /* Googlebot */
  {
    test: [/googlebot/i],
    describe(e) {
      const t = {
        name: "Googlebot"
      }, n = d.getFirstMatch(/googlebot\/(\d+(\.\d+))/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  /* Opera < 13.0 */
  {
    test: [/opera/i],
    describe(e) {
      const t = {
        name: "Opera"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:opera)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  /* Opera > 13.0 */
  {
    test: [/opr\/|opios/i],
    describe(e) {
      const t = {
        name: "Opera"
      }, n = d.getFirstMatch(/(?:opr|opios)[\s/](\S+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/SamsungBrowser/i],
    describe(e) {
      const t = {
        name: "Samsung Internet for Android"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:SamsungBrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/Whale/i],
    describe(e) {
      const t = {
        name: "NAVER Whale Browser"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:whale)[\s/](\d+(?:\.\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/MZBrowser/i],
    describe(e) {
      const t = {
        name: "MZ Browser"
      }, n = d.getFirstMatch(/(?:MZBrowser)[\s/](\d+(?:\.\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/focus/i],
    describe(e) {
      const t = {
        name: "Focus"
      }, n = d.getFirstMatch(/(?:focus)[\s/](\d+(?:\.\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/swing/i],
    describe(e) {
      const t = {
        name: "Swing"
      }, n = d.getFirstMatch(/(?:swing)[\s/](\d+(?:\.\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/coast/i],
    describe(e) {
      const t = {
        name: "Opera Coast"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:coast)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/opt\/\d+(?:.?_?\d+)+/i],
    describe(e) {
      const t = {
        name: "Opera Touch"
      }, n = d.getFirstMatch(/(?:opt)[\s/](\d+(\.?_?\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/yabrowser/i],
    describe(e) {
      const t = {
        name: "Yandex Browser"
      }, n = d.getFirstMatch(/(?:yabrowser)[\s/](\d+(\.?_?\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/ucbrowser/i],
    describe(e) {
      const t = {
        name: "UC Browser"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:ucbrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/Maxthon|mxios/i],
    describe(e) {
      const t = {
        name: "Maxthon"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:Maxthon|mxios)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/epiphany/i],
    describe(e) {
      const t = {
        name: "Epiphany"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:epiphany)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/puffin/i],
    describe(e) {
      const t = {
        name: "Puffin"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:puffin)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/sleipnir/i],
    describe(e) {
      const t = {
        name: "Sleipnir"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:sleipnir)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/k-meleon/i],
    describe(e) {
      const t = {
        name: "K-Meleon"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/(?:k-meleon)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/micromessenger/i],
    describe(e) {
      const t = {
        name: "WeChat"
      }, n = d.getFirstMatch(/(?:micromessenger)[\s/](\d+(\.?_?\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/qqbrowser/i],
    describe(e) {
      const t = {
        name: /qqbrowserlite/i.test(e) ? "QQ Browser Lite" : "QQ Browser"
      }, n = d.getFirstMatch(/(?:qqbrowserlite|qqbrowser)[/](\d+(\.?_?\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/msie|trident/i],
    describe(e) {
      const t = {
        name: "Internet Explorer"
      }, n = d.getFirstMatch(/(?:msie |rv:)(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/\sedg\//i],
    describe(e) {
      const t = {
        name: "Microsoft Edge"
      }, n = d.getFirstMatch(/\sedg\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/edg([ea]|ios)/i],
    describe(e) {
      const t = {
        name: "Microsoft Edge"
      }, n = d.getSecondMatch(/edg([ea]|ios)\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/vivaldi/i],
    describe(e) {
      const t = {
        name: "Vivaldi"
      }, n = d.getFirstMatch(/vivaldi\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/seamonkey/i],
    describe(e) {
      const t = {
        name: "SeaMonkey"
      }, n = d.getFirstMatch(/seamonkey\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/sailfish/i],
    describe(e) {
      const t = {
        name: "Sailfish"
      }, n = d.getFirstMatch(/sailfish\s?browser\/(\d+(\.\d+)?)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/silk/i],
    describe(e) {
      const t = {
        name: "Amazon Silk"
      }, n = d.getFirstMatch(/silk\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/phantom/i],
    describe(e) {
      const t = {
        name: "PhantomJS"
      }, n = d.getFirstMatch(/phantomjs\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/slimerjs/i],
    describe(e) {
      const t = {
        name: "SlimerJS"
      }, n = d.getFirstMatch(/slimerjs\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
    describe(e) {
      const t = {
        name: "BlackBerry"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/blackberry[\d]+\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/(web|hpw)[o0]s/i],
    describe(e) {
      const t = {
        name: "WebOS Browser"
      }, n = d.getFirstMatch(T, e) || d.getFirstMatch(/w(?:eb)?[o0]sbrowser\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/bada/i],
    describe(e) {
      const t = {
        name: "Bada"
      }, n = d.getFirstMatch(/dolfin\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/tizen/i],
    describe(e) {
      const t = {
        name: "Tizen"
      }, n = d.getFirstMatch(/(?:tizen\s?)?browser\/(\d+(\.?_?\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/qupzilla/i],
    describe(e) {
      const t = {
        name: "QupZilla"
      }, n = d.getFirstMatch(/(?:qupzilla)[\s/](\d+(\.?_?\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/firefox|iceweasel|fxios/i],
    describe(e) {
      const t = {
        name: "Firefox"
      }, n = d.getFirstMatch(/(?:firefox|iceweasel|fxios)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/electron/i],
    describe(e) {
      const t = {
        name: "Electron"
      }, n = d.getFirstMatch(/(?:electron)\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/MiuiBrowser/i],
    describe(e) {
      const t = {
        name: "Miui"
      }, n = d.getFirstMatch(/(?:MiuiBrowser)[\s/](\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/chromium/i],
    describe(e) {
      const t = {
        name: "Chromium"
      }, n = d.getFirstMatch(/(?:chromium)[\s/](\d+(\.?_?\d+)+)/i, e) || d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/chrome|crios|crmo/i],
    describe(e) {
      const t = {
        name: "Chrome"
      }, n = d.getFirstMatch(/(?:chrome|crios|crmo)\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  {
    test: [/GSA/i],
    describe(e) {
      const t = {
        name: "Google Search"
      }, n = d.getFirstMatch(/(?:GSA)\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  /* Android Browser */
  {
    test(e) {
      const t = !e.test(/like android/i), n = e.test(/android/i);
      return t && n;
    },
    describe(e) {
      const t = {
        name: "Android Browser"
      }, n = d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  /* PlayStation 4 */
  {
    test: [/playstation 4/i],
    describe(e) {
      const t = {
        name: "PlayStation 4"
      }, n = d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  /* Safari */
  {
    test: [/safari|applewebkit/i],
    describe(e) {
      const t = {
        name: "Safari"
      }, n = d.getFirstMatch(T, e);
      return n && (t.version = n), t;
    }
  },
  /* Something else */
  {
    test: [/.*/i],
    describe(e) {
      const t = /^(.*)\/(.*) /, n = /^(.*)\/(.*)[ \t]\((.*)/, s = e.search("\\(") !== -1 ? n : t;
      return {
        name: d.getFirstMatch(s, e),
        version: d.getSecondMatch(s, e)
      };
    }
  }
], fu = [
  /* Roku */
  {
    test: [/Roku\/DVP/],
    describe(e) {
      const t = d.getFirstMatch(/Roku\/DVP-(\d+\.\d+)/i, e);
      return {
        name: B.Roku,
        version: t
      };
    }
  },
  /* Windows Phone */
  {
    test: [/windows phone/i],
    describe(e) {
      const t = d.getFirstMatch(/windows phone (?:os)?\s?(\d+(\.\d+)*)/i, e);
      return {
        name: B.WindowsPhone,
        version: t
      };
    }
  },
  /* Windows */
  {
    test: [/windows /i],
    describe(e) {
      const t = d.getFirstMatch(/Windows ((NT|XP)( \d\d?.\d)?)/i, e), n = d.getWindowsVersionName(t);
      return {
        name: B.Windows,
        version: t,
        versionName: n
      };
    }
  },
  /* Firefox on iPad */
  {
    test: [/Macintosh(.*?) FxiOS(.*?)\//],
    describe(e) {
      const t = {
        name: B.iOS
      }, n = d.getSecondMatch(/(Version\/)(\d[\d.]+)/, e);
      return n && (t.version = n), t;
    }
  },
  /* macOS */
  {
    test: [/macintosh/i],
    describe(e) {
      const t = d.getFirstMatch(/mac os x (\d+(\.?_?\d+)+)/i, e).replace(/[_\s]/g, "."), n = d.getMacOSVersionName(t), r = {
        name: B.MacOS,
        version: t
      };
      return n && (r.versionName = n), r;
    }
  },
  /* iOS */
  {
    test: [/(ipod|iphone|ipad)/i],
    describe(e) {
      const t = d.getFirstMatch(/os (\d+([_\s]\d+)*) like mac os x/i, e).replace(/[_\s]/g, ".");
      return {
        name: B.iOS,
        version: t
      };
    }
  },
  /* Android */
  {
    test(e) {
      const t = !e.test(/like android/i), n = e.test(/android/i);
      return t && n;
    },
    describe(e) {
      const t = d.getFirstMatch(/android[\s/-](\d+(\.\d+)*)/i, e), n = d.getAndroidVersionName(t), r = {
        name: B.Android,
        version: t
      };
      return n && (r.versionName = n), r;
    }
  },
  /* WebOS */
  {
    test: [/(web|hpw)[o0]s/i],
    describe(e) {
      const t = d.getFirstMatch(/(?:web|hpw)[o0]s\/(\d+(\.\d+)*)/i, e), n = {
        name: B.WebOS
      };
      return t && t.length && (n.version = t), n;
    }
  },
  /* BlackBerry */
  {
    test: [/blackberry|\bbb\d+/i, /rim\stablet/i],
    describe(e) {
      const t = d.getFirstMatch(/rim\stablet\sos\s(\d+(\.\d+)*)/i, e) || d.getFirstMatch(/blackberry\d+\/(\d+([_\s]\d+)*)/i, e) || d.getFirstMatch(/\bbb(\d+)/i, e);
      return {
        name: B.BlackBerry,
        version: t
      };
    }
  },
  /* Bada */
  {
    test: [/bada/i],
    describe(e) {
      const t = d.getFirstMatch(/bada\/(\d+(\.\d+)*)/i, e);
      return {
        name: B.Bada,
        version: t
      };
    }
  },
  /* Tizen */
  {
    test: [/tizen/i],
    describe(e) {
      const t = d.getFirstMatch(/tizen[/\s](\d+(\.\d+)*)/i, e);
      return {
        name: B.Tizen,
        version: t
      };
    }
  },
  /* Linux */
  {
    test: [/linux/i],
    describe() {
      return {
        name: B.Linux
      };
    }
  },
  /* Chrome OS */
  {
    test: [/CrOS/],
    describe() {
      return {
        name: B.ChromeOS
      };
    }
  },
  /* Playstation 4 */
  {
    test: [/PlayStation 4/],
    describe(e) {
      const t = d.getFirstMatch(/PlayStation 4[/\s](\d+(\.\d+)*)/i, e);
      return {
        name: B.PlayStation4,
        version: t
      };
    }
  }
], gu = [
  /* Googlebot */
  {
    test: [/googlebot/i],
    describe() {
      return {
        type: "bot",
        vendor: "Google"
      };
    }
  },
  /* Huawei */
  {
    test: [/huawei/i],
    describe(e) {
      const t = d.getFirstMatch(/(can-l01)/i, e) && "Nova", n = {
        type: P.mobile,
        vendor: "Huawei"
      };
      return t && (n.model = t), n;
    }
  },
  /* Nexus Tablet */
  {
    test: [/nexus\s*(?:7|8|9|10).*/i],
    describe() {
      return {
        type: P.tablet,
        vendor: "Nexus"
      };
    }
  },
  /* iPad */
  {
    test: [/ipad/i],
    describe() {
      return {
        type: P.tablet,
        vendor: "Apple",
        model: "iPad"
      };
    }
  },
  /* Firefox on iPad */
  {
    test: [/Macintosh(.*?) FxiOS(.*?)\//],
    describe() {
      return {
        type: P.tablet,
        vendor: "Apple",
        model: "iPad"
      };
    }
  },
  /* Amazon Kindle Fire */
  {
    test: [/kftt build/i],
    describe() {
      return {
        type: P.tablet,
        vendor: "Amazon",
        model: "Kindle Fire HD 7"
      };
    }
  },
  /* Another Amazon Tablet with Silk */
  {
    test: [/silk/i],
    describe() {
      return {
        type: P.tablet,
        vendor: "Amazon"
      };
    }
  },
  /* Tablet */
  {
    test: [/tablet(?! pc)/i],
    describe() {
      return {
        type: P.tablet
      };
    }
  },
  /* iPod/iPhone */
  {
    test(e) {
      const t = e.test(/ipod|iphone/i), n = e.test(/like (ipod|iphone)/i);
      return t && !n;
    },
    describe(e) {
      const t = d.getFirstMatch(/(ipod|iphone)/i, e);
      return {
        type: P.mobile,
        vendor: "Apple",
        model: t
      };
    }
  },
  /* Nexus Mobile */
  {
    test: [/nexus\s*[0-6].*/i, /galaxy nexus/i],
    describe() {
      return {
        type: P.mobile,
        vendor: "Nexus"
      };
    }
  },
  /* Mobile */
  {
    test: [/[^-]mobi/i],
    describe() {
      return {
        type: P.mobile
      };
    }
  },
  /* BlackBerry */
  {
    test(e) {
      return e.getBrowserName(!0) === "blackberry";
    },
    describe() {
      return {
        type: P.mobile,
        vendor: "BlackBerry"
      };
    }
  },
  /* Bada */
  {
    test(e) {
      return e.getBrowserName(!0) === "bada";
    },
    describe() {
      return {
        type: P.mobile
      };
    }
  },
  /* Windows Phone */
  {
    test(e) {
      return e.getBrowserName() === "windows phone";
    },
    describe() {
      return {
        type: P.mobile,
        vendor: "Microsoft"
      };
    }
  },
  /* Android Tablet */
  {
    test(e) {
      const t = Number(String(e.getOSVersion()).split(".")[0]);
      return e.getOSName(!0) === "android" && t >= 3;
    },
    describe() {
      return {
        type: P.tablet
      };
    }
  },
  /* Android Mobile */
  {
    test(e) {
      return e.getOSName(!0) === "android";
    },
    describe() {
      return {
        type: P.mobile
      };
    }
  },
  /* desktop */
  {
    test(e) {
      return e.getOSName(!0) === "macos";
    },
    describe() {
      return {
        type: P.desktop,
        vendor: "Apple"
      };
    }
  },
  /* Windows */
  {
    test(e) {
      return e.getOSName(!0) === "windows";
    },
    describe() {
      return {
        type: P.desktop
      };
    }
  },
  /* Linux */
  {
    test(e) {
      return e.getOSName(!0) === "linux";
    },
    describe() {
      return {
        type: P.desktop
      };
    }
  },
  /* PlayStation 4 */
  {
    test(e) {
      return e.getOSName(!0) === "playstation 4";
    },
    describe() {
      return {
        type: P.tv
      };
    }
  },
  /* Roku */
  {
    test(e) {
      return e.getOSName(!0) === "roku";
    },
    describe() {
      return {
        type: P.tv
      };
    }
  }
], pu = [
  /* EdgeHTML */
  {
    test(e) {
      return e.getBrowserName(!0) === "microsoft edge";
    },
    describe(e) {
      if (/\sedg\//i.test(e))
        return {
          name: fe.Blink
        };
      const n = d.getFirstMatch(/edge\/(\d+(\.?_?\d+)+)/i, e);
      return {
        name: fe.EdgeHTML,
        version: n
      };
    }
  },
  /* Trident */
  {
    test: [/trident/i],
    describe(e) {
      const t = {
        name: fe.Trident
      }, n = d.getFirstMatch(/trident\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  /* Presto */
  {
    test(e) {
      return e.test(/presto/i);
    },
    describe(e) {
      const t = {
        name: fe.Presto
      }, n = d.getFirstMatch(/presto\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  /* Gecko */
  {
    test(e) {
      const t = e.test(/gecko/i), n = e.test(/like gecko/i);
      return t && !n;
    },
    describe(e) {
      const t = {
        name: fe.Gecko
      }, n = d.getFirstMatch(/gecko\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  },
  /* Blink */
  {
    test: [/(apple)?webkit\/537\.36/i],
    describe() {
      return {
        name: fe.Blink
      };
    }
  },
  /* WebKit */
  {
    test: [/(apple)?webkit/i],
    describe(e) {
      const t = {
        name: fe.WebKit
      }, n = d.getFirstMatch(/webkit\/(\d+(\.?_?\d+)+)/i, e);
      return n && (t.version = n), t;
    }
  }
];
class ur {
  /**
   * Create instance of Parser
   *
   * @param {String} UA User-Agent string
   * @param {Boolean} [skipParsing=false] parser can skip parsing in purpose of performance
   * improvements if you need to make a more particular parsing
   * like {@link Parser#parseBrowser} or {@link Parser#parsePlatform}
   *
   * @throw {Error} in case of empty UA String
   *
   * @constructor
   */
  constructor(t, n = !1) {
    if (t == null || t === "")
      throw new Error("UserAgent parameter can't be empty");
    this._ua = t, this.parsedResult = {}, n !== !0 && this.parse();
  }
  /**
   * Get UserAgent string of current Parser instance
   * @return {String} User-Agent String of the current <Parser> object
   *
   * @public
   */
  getUA() {
    return this._ua;
  }
  /**
   * Test a UA string for a regexp
   * @param {RegExp} regex
   * @return {Boolean}
   */
  test(t) {
    return t.test(this._ua);
  }
  /**
   * Get parsed browser object
   * @return {Object}
   */
  parseBrowser() {
    this.parsedResult.browser = {};
    const t = d.find(lu, (n) => {
      if (typeof n.test == "function")
        return n.test(this);
      if (n.test instanceof Array)
        return n.test.some((r) => this.test(r));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.browser = t.describe(this.getUA())), this.parsedResult.browser;
  }
  /**
   * Get parsed browser object
   * @return {Object}
   *
   * @public
   */
  getBrowser() {
    return this.parsedResult.browser ? this.parsedResult.browser : this.parseBrowser();
  }
  /**
   * Get browser's name
   * @return {String} Browser's name or an empty string
   *
   * @public
   */
  getBrowserName(t) {
    return t ? String(this.getBrowser().name).toLowerCase() || "" : this.getBrowser().name || "";
  }
  /**
   * Get browser's version
   * @return {String} version of browser
   *
   * @public
   */
  getBrowserVersion() {
    return this.getBrowser().version;
  }
  /**
   * Get OS
   * @return {Object}
   *
   * @example
   * this.getOS();
   * {
   *   name: 'macOS',
   *   version: '10.11.12'
   * }
   */
  getOS() {
    return this.parsedResult.os ? this.parsedResult.os : this.parseOS();
  }
  /**
   * Parse OS and save it to this.parsedResult.os
   * @return {*|{}}
   */
  parseOS() {
    this.parsedResult.os = {};
    const t = d.find(fu, (n) => {
      if (typeof n.test == "function")
        return n.test(this);
      if (n.test instanceof Array)
        return n.test.some((r) => this.test(r));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.os = t.describe(this.getUA())), this.parsedResult.os;
  }
  /**
   * Get OS name
   * @param {Boolean} [toLowerCase] return lower-cased value
   * @return {String} name of the OS — macOS, Windows, Linux, etc.
   */
  getOSName(t) {
    const { name: n } = this.getOS();
    return t ? String(n).toLowerCase() || "" : n || "";
  }
  /**
   * Get OS version
   * @return {String} full version with dots ('10.11.12', '5.6', etc)
   */
  getOSVersion() {
    return this.getOS().version;
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  getPlatform() {
    return this.parsedResult.platform ? this.parsedResult.platform : this.parsePlatform();
  }
  /**
   * Get platform name
   * @param {Boolean} [toLowerCase=false]
   * @return {*}
   */
  getPlatformType(t = !1) {
    const { type: n } = this.getPlatform();
    return t ? String(n).toLowerCase() || "" : n || "";
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  parsePlatform() {
    this.parsedResult.platform = {};
    const t = d.find(gu, (n) => {
      if (typeof n.test == "function")
        return n.test(this);
      if (n.test instanceof Array)
        return n.test.some((r) => this.test(r));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.platform = t.describe(this.getUA())), this.parsedResult.platform;
  }
  /**
   * Get parsed engine
   * @return {{}}
   */
  getEngine() {
    return this.parsedResult.engine ? this.parsedResult.engine : this.parseEngine();
  }
  /**
   * Get engines's name
   * @return {String} Engines's name or an empty string
   *
   * @public
   */
  getEngineName(t) {
    return t ? String(this.getEngine().name).toLowerCase() || "" : this.getEngine().name || "";
  }
  /**
   * Get parsed platform
   * @return {{}}
   */
  parseEngine() {
    this.parsedResult.engine = {};
    const t = d.find(pu, (n) => {
      if (typeof n.test == "function")
        return n.test(this);
      if (n.test instanceof Array)
        return n.test.some((r) => this.test(r));
      throw new Error("Browser's test function is not valid");
    });
    return t && (this.parsedResult.engine = t.describe(this.getUA())), this.parsedResult.engine;
  }
  /**
   * Parse full information about the browser
   * @returns {Parser}
   */
  parse() {
    return this.parseBrowser(), this.parseOS(), this.parsePlatform(), this.parseEngine(), this;
  }
  /**
   * Get parsed result
   * @return {ParsedResult}
   */
  getResult() {
    return d.assign({}, this.parsedResult);
  }
  /**
   * Check if parsed browser matches certain conditions
   *
   * @param {Object} checkTree It's one or two layered object,
   * which can include a platform or an OS on the first layer
   * and should have browsers specs on the bottom-laying layer
   *
   * @returns {Boolean|undefined} Whether the browser satisfies the set conditions or not.
   * Returns `undefined` when the browser is no described in the checkTree object.
   *
   * @example
   * const browser = Bowser.getParser(window.navigator.userAgent);
   * if (browser.satisfies({chrome: '>118.01.1322' }))
   * // or with os
   * if (browser.satisfies({windows: { chrome: '>118.01.1322' } }))
   * // or with platforms
   * if (browser.satisfies({desktop: { chrome: '>118.01.1322' } }))
   */
  satisfies(t) {
    const n = {};
    let r = 0;
    const s = {};
    let i = 0;
    if (Object.keys(t).forEach((a) => {
      const c = t[a];
      typeof c == "string" ? (s[a] = c, i += 1) : typeof c == "object" && (n[a] = c, r += 1);
    }), r > 0) {
      const a = Object.keys(n), c = d.find(a, (f) => this.isOS(f));
      if (c) {
        const f = this.satisfies(n[c]);
        if (f !== void 0)
          return f;
      }
      const u = d.find(
        a,
        (f) => this.isPlatform(f)
      );
      if (u) {
        const f = this.satisfies(n[u]);
        if (f !== void 0)
          return f;
      }
    }
    if (i > 0) {
      const a = Object.keys(s), c = d.find(a, (u) => this.isBrowser(u, !0));
      if (c !== void 0)
        return this.compareVersion(s[c]);
    }
  }
  /**
   * Check if the browser name equals the passed string
   * @param browserName The string to compare with the browser name
   * @param [includingAlias=false] The flag showing whether alias will be included into comparison
   * @returns {boolean}
   */
  isBrowser(t, n = !1) {
    const r = this.getBrowserName().toLowerCase();
    let s = t.toLowerCase();
    const i = d.getBrowserTypeByAlias(s);
    return n && i && (s = i.toLowerCase()), s === r;
  }
  compareVersion(t) {
    let n = [0], r = t, s = !1;
    const i = this.getBrowserVersion();
    if (typeof i == "string")
      return t[0] === ">" || t[0] === "<" ? (r = t.substr(1), t[1] === "=" ? (s = !0, r = t.substr(2)) : n = [], t[0] === ">" ? n.push(1) : n.push(-1)) : t[0] === "=" ? r = t.substr(1) : t[0] === "~" && (s = !0, r = t.substr(1)), n.indexOf(
        d.compareVersions(i, r, s)
      ) > -1;
  }
  isOS(t) {
    return this.getOSName(!0) === String(t).toLowerCase();
  }
  isPlatform(t) {
    return this.getPlatformType(!0) === String(t).toLowerCase();
  }
  isEngine(t) {
    return this.getEngineName(!0) === String(t).toLowerCase();
  }
  /**
   * Is anything? Check if the browser is called "anything",
   * the OS called "anything" or the platform called "anything"
   * @param {String} anything
   * @param [includingAlias=false] The flag showing whether alias will be included into comparison
   * @returns {Boolean}
   */
  is(t, n = !1) {
    return this.isBrowser(t, n) || this.isOS(t) || this.isPlatform(t);
  }
  /**
   * Check if any of the given values satisfies this.is(anything)
   * @param {String[]} anythings
   * @returns {Boolean}
   */
  some(t = []) {
    return t.some((n) => this.is(n));
  }
}
/*!
 * Bowser - a browser detector
 * https://github.com/lancedikson/bowser
 * MIT License | (c) Dustin Diaz 2012-2015
 * MIT License | (c) Denis Demchenko 2015-2019
 */
class mu {
  /**
   * Creates a {@link Parser} instance
   *
   * @param {String} UA UserAgent string
   * @param {Boolean} [skipParsing=false] Will make the Parser postpone parsing until you ask it
   * explicitly. Same as `skipParsing` for {@link Parser}.
   * @returns {Parser}
   * @throws {Error} when UA is not a String
   *
   * @example
   * const parser = Bowser.getParser(window.navigator.userAgent);
   * const result = parser.getResult();
   */
  static getParser(t, n = !1) {
    if (typeof t != "string")
      throw new Error("UserAgent should be a string");
    return new ur(t, n);
  }
  /**
   * Creates a {@link Parser} instance and runs {@link Parser.getResult} immediately
   *
   * @param UA
   * @return {ParsedResult}
   *
   * @example
   * const result = Bowser.parse(window.navigator.userAgent);
   */
  static parse(t) {
    return new ur(t).getResult();
  }
  static get BROWSER_MAP() {
    return us;
  }
  static get ENGINE_MAP() {
    return fe;
  }
  static get OS_MAP() {
    return B;
  }
  static get PLATFORMS_MAP() {
    return P;
  }
}
async function Sn(e) {
  var a;
  const t = uu(44).split("_").join("-"), n = navigator.userAgent, r = mu.parse(n);
  try {
    const c = await ((a = navigator.userAgentData) == null ? void 0 : a.getHighEntropyValues(["fullVersionList"]));
    c && (r.browser.version = c.fullVersionList[0].version);
  } catch (c) {
    console.warn(c);
  }
  r.os.name === "macOS" && r.os.version === "10.15.7" && (r.os.version = ">=" + r.os.version);
  let s;
  try {
    s = new URL(e.url);
  } catch {
  }
  const i = navigator.languages && navigator.languages.length ? navigator.languages[0] : navigator.userLanguage || navigator.language || navigator.browserLanguage || "en", o = {
    id: t,
    host: s == null ? void 0 : s.host,
    hostname: s == null ? void 0 : s.hostname,
    tabId: e == null ? void 0 : e.id,
    tabTitle: e == null ? void 0 : e.title,
    userAgent: n,
    browserName: r.browser.name,
    browserVersion: r.browser.version,
    browserEngineName: r.engine.name,
    browserEngineVersion: r.engine.version,
    deviceType: r.platform.type,
    deviceVendor: r.platform.vendor,
    osName: r.os.name,
    osVersion: r.os.version,
    // NOTE: `screenWidth` and `screenHeight` are added in `LocalSession.vue`,
    // as they require access to `window.screen`. They are unlikely to change in the meantime.
    windowWidth: e == null ? void 0 : e.width,
    windowHeight: e == null ? void 0 : e.height,
    locale: i,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    browserExtensionVersion: "1.98.25",
    link: `https://app.birdeatsbug.com/${t}`
  };
  return Xe(`getNewSession "${o.id}" ${e ? `on tab "${e.id}-${s == null ? void 0 : s.host}"` : ""}`, o), o;
}
const b = {
  hostsWithBackgroundMonitoringEnabled: [],
  techMode: !0,
  isAwareOfTechMode: !0,
  recordMicrophone: !1,
  audioDeviceId: null,
  recordWebcam: !1,
  videoDeviceId: null,
  hasEnabledBackgroundMonitoringOnce: !1,
  isMiniConsoleVisible: !0,
  instantReplayWidget: !0,
  recordingSurface: "tab",
  isReplayEnabled: !0,
  isRecordingSettingsPopoverVisible: !1,
  isRecorderWidgetEnabled: !0,
  webcamPreviewShape: "circle",
  // | 'bird'
  recordedEventTypes: {
    click: !0,
    keystrokes: !0,
    "error-uncaught": !0,
    "error-promise": !0,
    network: !0,
    dom: !0,
    console: {
      debug: !0,
      log: !0,
      info: !0,
      warn: !0,
      error: !0,
      assert: !0,
      trace: !0,
      dir: !0,
      group: !0,
      table: !0,
      count: !0,
      profile: !0,
      time: !0
    },
    localStorage: !0,
    sessionStorage: !0
  },
  sessionUploadsByHost: {},
  userInformation: {},
  videoQuality: "auto",
  // For analytics
  anonymousId: void 0
}, W = ds();
async function j(e, t) {
  var n;
  return (n = l.storage.local) == null ? void 0 : n.set({ [e]: t });
}
async function ds() {
  var t, n;
  const e = await ((t = l.storage) == null ? void 0 : t.local.get(Object.keys(b))) || {};
  return Object.assign(b, {
    ...e,
    recordedEventTypes: {
      ...b.recordedEventTypes,
      ...e.recordedEventTypes
    }
  }), (n = l.storage) == null || n.onChanged.addListener((r) => {
    Object.keys(b).forEach((s) => {
      r[s] && (b[s] = r[s].newValue);
    });
  }), b;
}
const G = /* @__PURE__ */ new Map();
async function ls() {
  const e = [];
  for (const t of [...G.values()])
    e.push(await t);
  return e;
}
async function hu() {
  if (await W, !b.isReplayEnabled)
    return;
  const e = await v.getSessions({ awaitInitialization: !1 }), t = await cu();
  e.forEach((n) => {
    if (!n.isInstantReplay || !b.hostsWithBackgroundMonitoringEnabled.includes(n.hostname) && !b.hostsWithBackgroundMonitoringEnabled.includes(n.host))
      return;
    const r = t.find((s) => s.id === n.tabId);
    r != null && r.id && r.url.includes(n.hostname) && G.set(n.tabId, n);
  });
}
async function yu(e = {}) {
  if (!e.url)
    return G.get(e.id);
  let t;
  try {
    t = new URL(e.url);
  } catch {
  }
  if (!t || (await W, !b.isReplayEnabled) || !(b.hostsWithBackgroundMonitoringEnabled.includes(t.host) || b.hostsWithBackgroundMonitoringEnabled.includes(t.hostname)))
    return !1;
  let r = await G.get(e.id);
  if (!r) {
    if (await v.isInitialized, r = await G.get(e.id), r)
      return r;
    const s = Sn(e);
    G.set(e.id, s), r = await s, r.isInstantReplay = !0, r.tabId = e.id, await v.setSession(r), G.set(e.id, r);
  }
  return r;
}
const Zt = (e, t) => t.some((n) => e instanceof n);
let dr, lr;
function wu() {
  return dr || (dr = [
    IDBDatabase,
    IDBObjectStore,
    IDBIndex,
    IDBCursor,
    IDBTransaction
  ]);
}
function bu() {
  return lr || (lr = [
    IDBCursor.prototype.advance,
    IDBCursor.prototype.continue,
    IDBCursor.prototype.continuePrimaryKey
  ]);
}
const fs = /* @__PURE__ */ new WeakMap(), en = /* @__PURE__ */ new WeakMap(), gs = /* @__PURE__ */ new WeakMap(), Mt = /* @__PURE__ */ new WeakMap(), vt = /* @__PURE__ */ new WeakMap();
function Eu(e) {
  const t = new Promise((n, r) => {
    const s = () => {
      e.removeEventListener("success", i), e.removeEventListener("error", o);
    }, i = () => {
      n(me(e.result)), s();
    }, o = () => {
      r(e.error), s();
    };
    e.addEventListener("success", i), e.addEventListener("error", o);
  });
  return t.then((n) => {
    n instanceof IDBCursor && fs.set(n, e);
  }).catch(() => {
  }), vt.set(t, e), t;
}
function _u(e) {
  if (en.has(e))
    return;
  const t = new Promise((n, r) => {
    const s = () => {
      e.removeEventListener("complete", i), e.removeEventListener("error", o), e.removeEventListener("abort", o);
    }, i = () => {
      n(), s();
    }, o = () => {
      r(e.error || new DOMException("AbortError", "AbortError")), s();
    };
    e.addEventListener("complete", i), e.addEventListener("error", o), e.addEventListener("abort", o);
  });
  en.set(e, t);
}
let tn = {
  get(e, t, n) {
    if (e instanceof IDBTransaction) {
      if (t === "done")
        return en.get(e);
      if (t === "objectStoreNames")
        return e.objectStoreNames || gs.get(e);
      if (t === "store")
        return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
    }
    return me(e[t]);
  },
  set(e, t, n) {
    return e[t] = n, !0;
  },
  has(e, t) {
    return e instanceof IDBTransaction && (t === "done" || t === "store") ? !0 : t in e;
  }
};
function ps(e) {
  tn = e(tn);
}
function Su(e) {
  return e === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype) ? function(t, ...n) {
    const r = e.call(lt(this), t, ...n);
    return gs.set(r, t.sort ? t.sort() : [t]), me(r);
  } : bu().includes(e) ? function(...t) {
    return e.apply(lt(this), t), me(fs.get(this));
  } : function(...t) {
    return me(e.apply(lt(this), t));
  };
}
function vu(e) {
  return typeof e == "function" ? Su(e) : (e instanceof IDBTransaction && _u(e), Zt(e, wu()) ? new Proxy(e, tn) : e);
}
function me(e) {
  if (e instanceof IDBRequest)
    return Eu(e);
  if (Mt.has(e))
    return Mt.get(e);
  const t = vu(e);
  return t !== e && (Mt.set(e, t), vt.set(t, e)), t;
}
const lt = (e) => vt.get(e);
function Au(e, t, { blocked: n, upgrade: r, blocking: s, terminated: i } = {}) {
  const o = indexedDB.open(e, t), a = me(o);
  return r && o.addEventListener("upgradeneeded", (c) => {
    r(me(o.result), c.oldVersion, c.newVersion, me(o.transaction), c);
  }), n && o.addEventListener("blocked", (c) => n(
    // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
    c.oldVersion,
    c.newVersion,
    c
  )), a.then((c) => {
    i && c.addEventListener("close", () => i()), s && c.addEventListener("versionchange", (u) => s(u.oldVersion, u.newVersion, u));
  }).catch(() => {
  }), a;
}
const Iu = ["get", "getKey", "getAll", "getAllKeys", "count"], xu = ["put", "add", "delete", "clear"], Pt = /* @__PURE__ */ new Map();
function fr(e, t) {
  if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string"))
    return;
  if (Pt.get(t))
    return Pt.get(t);
  const n = t.replace(/FromIndex$/, ""), r = t !== n, s = xu.includes(n);
  if (
    // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
    !(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(s || Iu.includes(n))
  )
    return;
  const i = async function(o, ...a) {
    const c = this.transaction(o, s ? "readwrite" : "readonly");
    let u = c.store;
    return r && (u = u.index(a.shift())), (await Promise.all([
      u[n](...a),
      s && c.done
    ]))[0];
  };
  return Pt.set(t, i), i;
}
ps((e) => ({
  ...e,
  get: (t, n, r) => fr(t, n) || e.get(t, n, r),
  has: (t, n) => !!fr(t, n) || e.has(t, n)
}));
const ku = ["continue", "continuePrimaryKey", "advance"], gr = {}, nn = /* @__PURE__ */ new WeakMap(), ms = /* @__PURE__ */ new WeakMap(), Tu = {
  get(e, t) {
    if (!ku.includes(t))
      return e[t];
    let n = gr[t];
    return n || (n = gr[t] = function(...r) {
      nn.set(this, ms.get(this)[t](...r));
    }), n;
  }
};
async function* Ru(...e) {
  let t = this;
  if (t instanceof IDBCursor || (t = await t.openCursor(...e)), !t)
    return;
  t = t;
  const n = new Proxy(t, Tu);
  for (ms.set(n, t), vt.set(n, lt(t)); t; )
    yield n, t = await (nn.get(n) || t.continue()), nn.delete(n);
}
function pr(e, t) {
  return t === Symbol.asyncIterator && Zt(e, [IDBIndex, IDBObjectStore, IDBCursor]) || t === "iterate" && Zt(e, [IDBIndex, IDBObjectStore]);
}
ps((e) => ({
  ...e,
  get(t, n, r) {
    return pr(t, n) ? Ru : e.get(t, n, r);
  },
  has(t, n) {
    return pr(t, n) || e.has(t, n);
  }
}));
function Mu(e) {
  return e instanceof Date || (e = new Date(e)), (Date.now() - e.getTime()) / 1e3 / 60;
}
const At = [
  "videoEvents",
  "screenshotEvents",
  "consoleEvents",
  "navigationEvents",
  "networkEventsFromExtensionAPI",
  "networkEventsFromInstrumentation",
  "errorEvents",
  "domEvents"
];
let ee;
async function Pu() {
  ee = await Au("birdEatsBug", 8, {
    upgrade(e, t, n, r) {
      try {
        e.createObjectStore("sessions", {
          keyPath: "id"
        });
      } catch (s) {
        ne("sessionsStore", s);
      }
      try {
        e.createObjectStore("videoEvents", {
          keyPath: "id",
          autoIncrement: !0
        }).createIndex("sessionId", "sessionId");
      } catch (s) {
        ne("videoEvents", s);
      }
      try {
        e.createObjectStore("screenshotEvents", {
          keyPath: "id",
          autoIncrement: !0
        }).createIndex("sessionId", "sessionId");
      } catch (s) {
        ne("screenshotEvents", s);
      }
      try {
        e.createObjectStore("consoleEvents", {
          keyPath: "id",
          autoIncrement: !0
        }).createIndex("sessionId", "sessionId");
      } catch (s) {
        ne("consoleEvents", s);
      }
      try {
        e.createObjectStore("navigationEvents", {
          keyPath: "id",
          autoIncrement: !0
        }).createIndex("sessionId", "sessionId");
      } catch (s) {
        ne("navigationEvents", s);
      }
      try {
        e.createObjectStore("networkEventsFromExtensionAPI", {
          keyPath: "id",
          autoIncrement: !0
        }).createIndex("sessionId", "sessionId");
      } catch (s) {
        ne("networkEventsFromExtensionAPI", s);
      }
      try {
        e.createObjectStore(
          "networkEventsFromInstrumentation",
          {
            keyPath: "id",
            autoIncrement: !0
          }
        ).createIndex("sessionId", "sessionId");
      } catch (s) {
        ne("networkEventsFromInstrumentation", s);
      }
      try {
        e.createObjectStore("errorEvents", {
          keyPath: "id",
          autoIncrement: !0
        }).createIndex("sessionId", "sessionId");
      } catch (s) {
        ne("errorEvents", s);
      }
      try {
        e.createObjectStore("domEvents", {
          keyPath: "id",
          autoIncrement: !0
        }).createIndex("sessionId", "sessionId");
      } catch (s) {
        ne("domEvents", s);
        try {
          r.objectStore("domEvents").createIndex("sessionId", "sessionId");
        } catch (i) {
          ne("domEvents", i);
        }
      }
    },
    blocked() {
      throw new Error("IndexedDB connection blocked");
    },
    blocking() {
      throw new Error("IndexedDB connection blocking");
    },
    terminated() {
      throw new Error("IndexedDB connection terminated");
    }
  });
}
function ne(e, t) {
  if (!t.message.includes("An object store with the specified name already exists.") && !t.message.includes("An index with the specified name already exists."))
    throw new Error("sessionsStore upgrade: " + t.message);
}
async function Ou() {
  for (const e of At)
    await ee.clear(e);
}
async function Cu(e) {
  return ee.put("sessions", e);
}
async function Du(e) {
  return ee.get("sessions", e);
}
async function hs() {
  return ee.getAll("sessions");
}
async function Nu(e) {
  await ee.delete("sessions", e), await Lu(e);
}
async function Fu(e, t, n) {
  for (const r of n)
    r.sessionId = e, await ee.put(t, r);
}
async function Bu(e, t, n) {
  if (n) {
    const s = (await ee.transaction(t)).store.index("sessionId");
    for await (const i of s.iterate(e, "next"))
      n(i.value);
  } else
    return ee.getAllFromIndex(t, "sessionId", e);
}
async function Lu(e) {
  for (const t of At) {
    const n = await ee.transaction(t, "readwrite"), r = n.store.index("sessionId");
    for await (const s of r.iterate(e))
      s.delete();
    await n.done;
  }
}
async function $u(e) {
  const t = /* @__PURE__ */ new Set(), n = (await hs()).map((r) => r.id);
  for (const r of At) {
    const s = await ee.transaction(r, "readwrite");
    for await (const i of s.store.iterate()) {
      const o = i.value;
      if (!o) {
        i.delete();
        continue;
      }
      !e.includes(o.sessionId) && n.includes(o.sessionId) || Mu(o.createdAt || o.startedAt || o.endedAt) < 3 || (i.delete(), r === "errorEvents" && t.add(o.sessionId));
    }
    await s.done;
  }
  return t.values();
}
const ju = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  addSessionEvents: Fu,
  clear: Ou,
  deleteExpiredBackgroundMonitoringSessionEvents: $u,
  deleteSession: Nu,
  getSession: Du,
  getSessionEvents: Bu,
  getSessions: hs,
  indexedDBEventStores: At,
  init: Pu,
  setSession: Cu
}, Symbol.toStringTag, { value: "Module" }));
let Z = null, ie = new Promise((e) => {
  ws().then(e);
}), ft = [], mr;
function be(e) {
  const t = {
    name: e.name,
    message: e.message,
    cause: e.cause,
    stack: e.stack,
    createdAt: Date.now()
  };
  throw ft.push(t), e;
}
function Uu() {
  const e = Date.now() - 36e5;
  return ft = ft.filter(({ createdAt: t }) => t > Math.max(e, mr)), mr = Date.now(), ft;
}
async function Wu() {
  try {
    return await ie, await Z.clear();
  } catch (e) {
    be(e);
  }
}
async function qu(e) {
  try {
    return await ie, await Z.setSession(e);
  } catch (t) {
    be(t);
  }
}
async function ys(e) {
  try {
    return await ie, await Z.getSession(e);
  } catch (t) {
    be(t);
  }
}
async function Hu({ awaitInitialization: e = !0 } = {}) {
  try {
    return e && await ie, await Z.getSessions();
  } catch (t) {
    be(t);
  }
}
async function Vu(e) {
  try {
    await ie;
    const t = await ys(e);
    if (Xe("deleteSession", e, t), await Z.deleteSession(e), se.forEach((r, s) => {
      r === e && se.delete(s);
    }), !t)
      return;
    const n = await G.get(t.tabId);
    (n == null ? void 0 : n.id) === t.id && (G.delete(t.tabId), await we(t.tabId));
  } catch (t) {
    be(t);
  }
}
async function Gu(e, t, n) {
  try {
    if (!(n != null && n.length))
      return;
    await ie, await Z.addSessionEvents(e, t, n);
  } catch (r) {
    be(r);
  }
}
async function zu(e, t, n) {
  try {
    return await ie, await Z.getSessionEvents(e, t, n);
  } catch (r) {
    be(r);
  }
}
async function Yu(e) {
  try {
    return await ie, await Z.deleteExpiredBackgroundMonitoringSessionEvents(e);
  } catch (t) {
    be(t);
  }
}
async function ws() {
  if (!Z)
    try {
      Z = ju, await Z.init(), await hu(), ie = Promise.resolve();
    } catch (e) {
      throw Xe(e), $o(e), e;
    }
}
const v = {
  initialize: ws,
  isInitialized: ie,
  getRecentStorageErrors: Uu,
  clear: Wu,
  setSession: qu,
  getSession: ys,
  getSessions: Hu,
  deleteSession: Vu,
  addSessionEvents: Gu,
  getSessionEvents: zu,
  deleteExpiredBackgroundMonitoringSessionEvents: Yu
};
async function we(e) {
  if ((S == null ? void 0 : S.state.mediaRecorderState) === "recording" || (S == null ? void 0 : S.state.mediaRecorderState) === "paused")
    return;
  const t = await Re(e), n = t == null ? void 0 : t.id;
  if (!n)
    return;
  const s = !!(await l.runtime.getContexts({})).find((o) => o.contextType === "POPUP"), i = await K(t);
  if (!(i != null && i.isInstantReplay))
    s && hr(n, []), await Ve(n, "");
  else {
    const o = await v.getSessionEvents(i.id, "errorEvents"), a = o.length;
    if (s) {
      const c = ou(au(o, "createdAt"));
      hr(n, c);
    }
    await Ve(n, a > 0 ? a : "");
  }
}
async function hr(e, t) {
  try {
    await l.runtime.sendMessage({
      to: "popup",
      name: "updateTabSessionErrorEvents",
      tabId: e,
      errorEvents: t
    });
  } catch (n) {
    $(n);
  }
}
async function Ku(e) {
  try {
    await l.tabs.sendMessage(e.id, { name: "disable", to: "content" });
  } catch (t) {
    $(t);
  }
  await we(e);
}
async function bs() {
  (await l.windows.getAll({ populate: !0 })).forEach((t) => {
    t.tabs.forEach(z);
  });
}
async function z(e) {
  if ((e == null ? void 0 : e.status) === "unloaded")
    return;
  const t = (e == null ? void 0 : e.url) || (e == null ? void 0 : e.pendingUrl);
  if (!(e != null && e.id) || !t)
    return;
  if (!_n(t).isPossible)
    return cs(e.id);
  let n = [];
  if (S.isRecordingTab(e.id))
    n.push(We(e, "content"));
  else {
    const r = await K(e);
    r ? (n.push(We(e, "content")), r.isInstantReplay && we(e)) : Ku(e);
  }
  if ((S.isRecordingTab(e.id) || S.isPausedTab(e.id)) && n.push(We(e, "videoRecorderUI")), n.length !== 0)
    return Promise.all(n);
}
const rn = {
  session: null,
  tab: null,
  surface: null,
  showWebcamPreview: !1,
  isRecorderWidgetEnabled: null,
  /**
   * State of the recording session, queried from the `MediaRecorder` instance in `videoRecorderOffscreen.js`
   * @name mediaRecorderState
   * @type {null | undefined | "inactive" | "recording" | "paused"}
   * https://developer.mozilla.org/en-US/docs/Web/API/MediaRecorder/state
   */
  mediaRecorderState: null,
  focusedTabId: null,
  timer: null,
  elapsedTimeInSeconds: 0,
  elapsedTimeText: "0:00",
  isRecorderWidgetClosed: !1,
  webcamPreviewSide: "left",
  recordingWidgetPosition: {
    topPercent: null,
    leftPercent: null
  }
};
Object.freeze(rn);
const Ju = {
  set(e, t, n) {
    return l.storage.session.set({ videoRecorderState: { ...e, [t]: n } }), Reflect.set(...arguments);
  }
}, S = {
  state: new Proxy({ ...rn }, Ju),
  async initializeState() {
    const { videoRecorderState: e } = await l.storage.session.get("videoRecorderState");
    e && (Object.entries(e).forEach(([t, n]) => {
      t != null && (this.state[t] = n);
    }), this.state.mediaRecorderState === "recording" && (await this.startTimer(), this.state.tab && await z(this.state.tab)));
  },
  isRecordingTab(e) {
    return this.state.mediaRecorderState === "recording" && this.state.focusedTabId === e;
  },
  isPausedTab(e) {
    return this.state.mediaRecorderState === "paused" && this.state.focusedTabId === e;
  },
  async onTabActivated(e) {
    if (!this.state.mediaRecorderState || this.state.surface !== "screen")
      return;
    l.tabs.sendMessage(e, { name: "disableDomInstrumentation", to: "content" }).catch((s) => {
      $(s);
    });
    const t = this.state.focusedTabId;
    this.state.focusedTabId = e;
    const n = await Re(e);
    if (this.state.tab = n, n && await z(n), await this.updateMediaRecorderState(), this.state.mediaRecorderState === "paused" ? cr(e) : this.state.mediaRecorderState === "recording" && dt(e), t && l.tabs.sendMessage(t, { to: "videoRecorderUI", name: "hideVideoRecorderUI" }).catch((s) => {
      $(s);
    }), !this.state.session || (l.tabs.sendMessage(e, {
      to: "videoRecorderUI",
      name: "showVideoRecorderUI",
      showMouseClicks: this.state.mediaRecorderState === "recording",
      showWebcamPreview: this.state.showWebcamPreview,
      webcamPreviewSide: this.state.webcamPreviewSide,
      mediaRecorderState: this.state.mediaRecorderState,
      elapsedTimeText: this.state.elapsedTimeText,
      recordingWidgetPosition: this.state.recordingWidgetPosition,
      isRecorderWidgetClosed: this.state.isRecorderWidgetClosed,
      isRecorderWidgetEnabled: this.state.isRecorderWidgetEnabled,
      session: this.state.session
    }).catch((s) => {
      $(s);
    }), !(n != null && n.url)))
      return;
    const r = t && await Re(t);
    if (this.state.mediaRecorderState !== "paused") {
      const s = {
        type: "step",
        subType: "navigation",
        action: "focusTab",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: r == null ? void 0 : r.url,
        newUrl: n.url
      };
      await v.addSessionEvents(this.state.session.id, "navigationEvents", [s]);
    }
  },
  async start({
    session: e,
    surface: t,
    tab: n,
    recordMicrophone: r,
    audioDeviceId: s,
    recordWebcam: i,
    isRecorderWidgetEnabled: o,
    videoQuality: a
  }) {
    var c;
    try {
      if (!(n != null && n.id))
        throw new Error("Tab required to start video recording.");
      if (!(e != null && e.id))
        throw new Error("Session required to start video recording.");
      if (this.state.session = e, this.state.tab = n, this.state.focusedTabId = n.id, this.state.surface = t, this.state.showWebcamPreview = i, this.state.isRecorderWidgetEnabled = o, i && await this.startWebcamPreview(), r) {
        const { state: f } = await navigator.permissions.query({ name: "microphone" });
        if (f === "denied")
          throw new Error("Microphone: Permission denied");
      }
      let u = {};
      if (t === "tab") {
        !!(await l.tabCapture.getCapturedTabs()).find((w) => w.tabId === n.id) && await this.stopRecording();
        const h = await l.tabCapture.getMediaStreamId({ targetTabId: n.id });
        if (!h) {
          const w = ((c = l.runtime.lastError) == null ? void 0 : c.message) || "Failed to get video stream (error unknown).";
          throw new Error(w);
        }
        u = {
          audio: !1,
          video: {
            mandatory: {
              chromeMediaSource: "tab",
              chromeMediaSourceId: h,
              frameRate: { max: 30, ideal: 30 },
              width: { max: n.width, ideal: n.width },
              height: { max: n.height, ideal: n.height }
            }
          }
        };
      } else
        t === "screen" && (u = {
          video: {
            displaySurface: "monitor",
            frameRate: { max: 30, ideal: 30 }
          }
        });
      await this.recordFromOffscreenDocument({
        mediaConstraints: u,
        recordMicrophone: r,
        audioDeviceId: s,
        recordWebcam: i,
        videoQuality: a
      }), await We(this.state.tab, "videoRecorderUI"), await this.startTimer(), await l.tabs.sendMessage(n.id, {
        to: "videoRecorderUI",
        name: "showVideoRecorderUI",
        showMouseClicks: this.state.mediaRecorderState === "recording",
        showWebcamPreview: this.state.showWebcamPreview,
        webcamPreviewSide: this.state.webcamPreviewSide,
        mediaRecorderState: this.state.mediaRecorderState,
        elapsedTimeText: this.state.elapsedTimeText,
        recordingWidgetPosition: this.state.recordingWidgetPosition,
        isRecorderWidgetClosed: this.state.isRecorderWidgetClosed,
        isRecorderWidgetEnabled: this.state.isRecorderWidgetEnabled,
        session: e
      }).catch((f) => {
        $(f);
      }), l.tabs.sendMessage(n.id, { name: "disableDomInstrumentation", to: "content" }).catch((f) => {
        $(f);
      });
    } catch (u) {
      throw this.cleanup(), u;
    }
  },
  async recordFromOffscreenDocument({ mediaConstraints: e, recordMicrophone: t, audioDeviceId: n, recordWebcam: r, videoQuality: s }) {
    (await l.runtime.getContexts({})).find((a) => a.contextType === "OFFSCREEN_DOCUMENT") || await l.offscreen.createDocument({
      url: "videoRecorder.html",
      reasons: ["USER_MEDIA"],
      justification: "Recording screen with `chrome.tabCapture` or `navigator.mediaDevices.getDisplayMedia`"
    }), await l.runtime.sendMessage({
      to: "videoRecorderOffscreen",
      name: "startRecording",
      data: {
        surface: this.state.surface,
        mediaConstraints: e,
        session: this.state.session,
        recordMicrophone: t,
        audioDeviceId: n,
        recordWebcam: r,
        videoQuality: s
      }
    });
  },
  updateIconTimer() {
    this.state.elapsedTimeInSeconds++;
    const e = this.state.elapsedTimeInSeconds * 1e3;
    this.state.elapsedTimeText = tu(e), this.state.focusedTabId && l.tabs.sendMessage(this.state.focusedTabId, {
      to: "videoRecorderUI",
      name: "updateTimer",
      elapsedTimeText: this.state.elapsedTimeText
    }).catch((t) => {
      $(t);
    }), it((t) => l.action.setBadgeText({ tabId: t.id, text: this.state.elapsedTimeText }));
  },
  async updateMediaRecorderState() {
    this.state.mediaRecorderState = await l.runtime.sendMessage({
      to: "videoRecorderOffscreen",
      name: "getRecordingState"
    });
  },
  async requestMicrophonePermission() {
    var e;
    if (!((e = this.state.tab) != null && e.id))
      return console.warn("tab required to request mic permission");
    try {
      await l.scripting.executeScript({
        target: { tabId: this.state.tab.id },
        files: ["js/contentScripts/requestMicrophonePermission.js"]
      });
      const t = await l.tabs.sendMessage(this.state.tab.id, {
        to: "requestMicrophonePermission"
      });
      if ((t == null ? void 0 : t.granted) !== !0)
        throw new Error(t == null ? void 0 : t.reason);
    } catch (t) {
      throw console.error(t), new Error("Microphone: Permission denied");
    }
  },
  async startWebcamPreview() {
    var e;
    if (!((e = this.state.tab) != null && e.id))
      return console.warn("tab required to start webcam preview");
    try {
      await We(this.state.tab, "videoRecorderUI"), await as(100), await l.tabs.sendMessage(this.state.tab.id, {
        to: "videoRecorderUI",
        name: "showWebcamPreview",
        webcamPreviewSide: this.state.webcamPreviewSide
      });
    } catch (t) {
      throw console.error(t), new Error("Webcam: Permission denied");
    }
  },
  async startTimer() {
    this.state.timer && clearInterval(this.state.timer), this.state.timer = setInterval(() => {
      this.updateIconTimer(), this.updateMediaRecorderState();
    }, 1e3), this.updateIconTimer(), await this.updateMediaRecorderState();
  },
  async pause() {
    if (this.state.mediaRecorderState !== "recording")
      return this.afterStop();
    this.state.timer && clearInterval(this.state.timer);
    const e = this.state.tab && await Re(this.state.tab.id);
    if (await l.runtime.sendMessage({
      to: "videoRecorderOffscreen",
      name: "pauseRecording",
      data: { url: e == null ? void 0 : e.url }
    }), await this.updateMediaRecorderState(), e)
      try {
        await z(e);
      } catch (t) {
        console.error(t);
      }
    it((t) => {
      cr(t.id);
    });
  },
  async resume() {
    const e = this.state.tab && await Re(this.state.tab.id);
    if (await l.runtime.sendMessage({
      to: "videoRecorderOffscreen",
      name: "resumeRecording",
      data: { url: e == null ? void 0 : e.url }
    }), await this.updateMediaRecorderState(), e)
      try {
        await z(e);
      } catch (t) {
        console.error(t);
      }
    this.startTimer(), it((t) => dt(t.id));
  },
  async addMarker({ text: e }) {
    this.state.session = await v.getSession(this.state.session.id), this.state.session.description = `${this.state.session.description || ""}${this.state.elapsedTimeText} ${e}`.trim() + `
`, await v.setSession(this.state.session);
  },
  async stop() {
    await this.stopRecording(), await this.afterStop();
  },
  async stopRecording() {
    await l.runtime.sendMessage({
      to: "videoRecorderOffscreen",
      name: "stopRecording"
    });
  },
  async afterStop() {
    try {
      if (this.state.session) {
        this.state.session.endedAt = (/* @__PURE__ */ new Date()).toISOString(), await v.setSession(this.state.session);
        const e = l.runtime.getURL("localSession.html") + "#/?sessionId=" + this.state.session.id;
        await l.tabs.create({ url: e });
      }
    } finally {
      await this.cleanup();
    }
  },
  async cleanup() {
    this.state.timer && clearInterval(this.state.timer), Object.entries(rn).forEach(([e, t]) => {
      this.state[e] = t;
    }), it(this.restoreTabState.bind(this));
  },
  async restoreTabState(e) {
    if (!(e != null && e.url))
      return "Tab is opening, it does not have a url yet, no error counter to restore";
    try {
      dt(e.id), await l.tabs.sendMessage(e.id, { to: "videoRecorderUI", name: "hideVideoRecorderUI" });
    } catch {
    }
    try {
      await z(e);
    } catch (t) {
      console.error(t);
    }
  }
};
async function K(e = {}) {
  return S.isRecordingTab(e.id) ? S.state.session : yu(e);
}
const se = /* @__PURE__ */ new Map();
let Es = 1e6, qe = l.runtime.getURL("");
qe.at(-1) === "/" && (qe = qe.slice(0, -1));
function Xu(e) {
  var t;
  if (e.requestBody) {
    if (e.requestBody.raw) {
      const n = new TextDecoder();
      let r = 0, s = "";
      for (let i of e.requestBody.raw)
        if ((t = i.bytes) != null && t.byteLength) {
          if (r += i.bytes.byteLength, r >= Es)
            break;
          s += n.decode(new Uint8Array(i.bytes));
        }
      return { raw: s };
    }
    return e.requestBody;
  }
}
async function Ot(e) {
  if (e.frameId !== 0 || e.tabId < 0 || e.tabId === void 0 || !e.initiator || e.initiator === "null" || !b.recordedEventTypes.network || e.url.startsWith(qe) && !e.initiator.startsWith(qe))
    return;
  const t = await K({ id: e.tabId });
  if (!(t != null && t.id))
    return;
  se.set(e.requestId, t.id);
  const n = {
    requestId: e.requestId,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    initiator: e.initiator,
    method: e.method,
    type: e.type,
    url: e.url,
    requestBody: Xu(e)
  };
  await v.addSessionEvents(t.id, "networkEventsFromExtensionAPI", [n]);
}
async function yr(e) {
  const t = se.get(e.requestId);
  if (!t)
    return;
  const n = {
    requestId: e.requestId,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    requestHeaders: e.requestHeaders
  };
  await v.addSessionEvents(t, "networkEventsFromExtensionAPI", [n]);
}
async function wr(e) {
  const t = se.get(e.requestId);
  if (!t)
    return;
  const n = {
    requestId: e.requestId,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    redirectUrl: e.redirectUrl
  };
  await v.addSessionEvents(t, "networkEventsFromExtensionAPI", [n]);
}
async function br(e) {
  const t = se.get(e.requestId);
  if (!t)
    return;
  const n = {
    requestId: e.requestId,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    fromCache: e.fromCache,
    statusCode: e.statusCode,
    statusLine: e.statusLine,
    responseHeaders: e.responseHeaders
  };
  await v.addSessionEvents(t, "networkEventsFromExtensionAPI", [n]);
}
async function Er(e) {
  const t = se.get(e.requestId);
  if (!t)
    return;
  const n = {
    requestId: e.requestId,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    fromCache: e.fromCache,
    statusCode: e.statusCode,
    statusLine: e.statusLine,
    endedAt: (/* @__PURE__ */ new Date()).toISOString(),
    responseHeaders: e.responseHeaders
  };
  await v.addSessionEvents(t, "networkEventsFromExtensionAPI", [n]), se.delete(e.requestId), yn(e) && (e.sessionId = t, e.endedAt = n.endedAt, vn(e));
}
async function _r(e) {
  const t = se.get(e.requestId);
  if (!t)
    return;
  const n = {
    requestId: e.requestId,
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    endedAt: (/* @__PURE__ */ new Date()).toISOString(),
    error: e.error,
    fromCache: e.fromCache
  };
  e.sessionId = t, await v.addSessionEvents(t, "networkEventsFromExtensionAPI", [n]), se.delete(e.requestId), e.endedAt = n.endedAt, vn(e);
}
async function vn(e) {
  const t = Qc(e);
  if (!t)
    return;
  await v.addSessionEvents(e.sessionId, "consoleEvents", [t]);
  const n = await K({ id: e.tabId });
  n != null && n.isInstantReplay && (wn(e) || bn(e) || En(e) || (await v.addSessionEvents(n.id, "errorEvents", [t]), we(e.tabId)));
}
async function _s() {
  var t;
  const e = "<all_urls>";
  if (await W, Xe("setupWebRequestAPI()", b), b.recordedEventTypes.network !== !1) {
    if ((t = b.recordedEventTypes.network) != null && t.maxSizeInBytes && (Es = b.recordedEventTypes.network.maxSizeInBytes), l.webRequest.onBeforeRequest.hasListener(Ot, { urls: [e] }, ["requestBody"]))
      return;
    l.webRequest.onBeforeRequest.addListener(Ot, { urls: [e] }, ["requestBody"]), l.webRequest.onSendHeaders.addListener(yr, { urls: [e] }, [
      "requestHeaders",
      "extraHeaders"
    ]), l.webRequest.onBeforeRedirect.addListener(wr, { urls: [e] }, [
      "responseHeaders",
      "extraHeaders"
    ]), l.webRequest.onResponseStarted.addListener(br, { urls: [e] }, [
      "responseHeaders",
      "extraHeaders"
    ]), l.webRequest.onCompleted.addListener(Er, { urls: [e] }, ["responseHeaders", "extraHeaders"]), l.webRequest.onErrorOccurred.addListener(_r, { urls: [e] });
  } else
    l.webRequest.onBeforeRequest.removeListener(Ot, { urls: [e] }, ["requestBody"]), l.webRequest.onSendHeaders.removeListener(yr, { urls: [e] }, [
      "requestHeaders",
      "extraHeaders"
    ]), l.webRequest.onBeforeRedirect.removeListener(wr, { urls: [e] }, [
      "responseHeaders",
      "extraHeaders"
    ]), l.webRequest.onResponseStarted.removeListener(br, { urls: [e] }, ["responseHeaders"]), l.webRequest.onCompleted.removeListener(Er, { urls: [e] }, [
      "responseHeaders",
      "extraHeaders"
    ]), l.webRequest.onErrorOccurred.removeListener(_r, { urls: [e] });
}
let Ct = /* @__PURE__ */ new Map(), ot = /* @__PURE__ */ new Map(), at = /* @__PURE__ */ new Map();
async function Ss(e, t) {
  if (e.url || (e.url = at.get(e.id)), !e.url)
    return;
  const n = await K(e);
  if (!n.id)
    return;
  const r = {
    type: "step",
    subType: "navigation",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    action: t,
    tabId: e.id
  };
  if (t === "close")
    r.url = e.url;
  else if (t === "reload") {
    if (Ct.has(e.id) && Date.now() - Ct.get(e.id) < 1e3 || (Ct.set(e.id, Date.now()), ot.has(e.id) && Date.now() - ot.get(e.id) < 600))
      return;
    ot.set(e.id, Date.now()), r.url = e.url;
  } else if (t === "navigate")
    r.newUrl = e.url, at.has(e.id) && (r.oldUrl = at.get(e.id)), at.set(e.id, e.url), ot.set(e.id, Date.now());
  else
    throw new Error(`Unrecognized navigation action: ${t}`);
  await v.addSessionEvents(n.id, "navigationEvents", [r]), we(e);
}
async function Qu() {
  var s;
  const e = await vs(), t = (await v.getSessions()).map((i) => i.id), r = (await ls()).map((i) => i.id);
  for (const i of t)
    ((s = S.state.session) == null ? void 0 : s.id) != i && (r.includes(i) || e.includes(i) || await v.deleteSession(i));
}
async function Zu() {
  const e = await vs(), t = await ls(), n = t.map((s) => s.id).filter((s) => !e.includes(s)), r = await v.deleteExpiredBackgroundMonitoringSessionEvents(n);
  for (const s of r) {
    const i = t.find((o) => o.id === s);
    i != null && i.tabId && await we(i.tabId);
  }
}
async function vs() {
  return (await l.tabs.query({ url: l.runtime.getURL("localSession.html") })).map(({ url: t }) => t).join(", ");
}
async function Sr(e) {
  return e = e.split(":")[0], l.tabs.query({ url: [`*://${e}/*`, `chrome-extension://${e}/*`] });
}
function ed(e) {
  return !!(e.type.startsWith("error") || e.type === "assert");
}
async function Dt(e, t, n, r) {
  var u;
  if (t.events.length - n.length < 1)
    return;
  const i = (u = e.tab) == null ? void 0 : u.url, o = "content script events reached background as null events", a = o + " from " + i + " through " + r;
  if (console.warn(a), r === "saveNetworkEventsFromInstrumentationToIndexedDB" && (i != null && i.includes("mail1.ecomsolutions.net")))
    return;
  if (i != null && i.includes("localhost:"))
    return;
  const c = new Error(o);
  Vr(c, {
    extra: {
      url: i,
      eventHandler: r
    }
  });
}
const td = [
  "trackSubmit",
  "trackClick",
  "trackLink",
  "trackForm",
  "pageview",
  "identify",
  "reset",
  "group",
  "track",
  "ready",
  "alias",
  "debug",
  "page",
  "once",
  "off",
  "on",
  "addSourceMiddleware",
  "addIntegrationMiddleware",
  "setAnonymousId",
  "addDestinationMiddleware"
], nd = "seg-api.birdeatsbug.com/v1", rd = "https://eds.browserstack.com:443", vr = "live_plus", Nt = async (e, t, n = {}) => {
  const r = {
    api_key: "5PJymLNdWrOwzQNC7J6SXBuUFQGWq4Vuw",
    event_type: vr + "_events",
    data: {
      event_name: e,
      team: vr,
      ...t,
      event_json: { ...n, url: location.href }
    }
  };
  if (location.search) {
    const s = ["utm_campaign", "utm_content", "utm_keyword", "utm_medium", "utm_source", "utm_term"], i = new URLSearchParams(location.search);
    i == null || i.forEach((o, a) => {
      s.includes(a) && (r.data.event_json || (r.data.event_json = {}), r.data.event_json[a] = o);
    });
  }
  return await fetch(rd + "/send_event", {
    method: "POST",
    body: JSON.stringify(r),
    headers: {
      "Content-Type": "application/json"
    }
  });
}, J = {};
td.forEach((e) => {
  J[e] = (...t) => {
    console.info(`analytics.${e}`, ...t);
  };
});
{
  const e = "https://" + nd, t = {
    writeKey: "lZht9IA0sYtvNWfuWDSv757akG33DBWy",
    context: {
      // Anonymize IP address, see:
      // https://segment-docs.netlify.app/docs/connections/sources/catalog/libraries/website/javascript/identity/#anonymizing-ip
      ip: "0.0.0.0"
    }
  }, n = {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    }
  };
  J.track = async function(r, s = {}) {
    let i = { event: r, properties: s };
    i = await Ar(i), i = Ir(i);
    const o = await Ft(), a = `track - ${r}`;
    return Nt(a, o, s), fetch(e + "/track", { ...n, body: JSON.stringify({ ...t, ...i }) });
  }, J.page = async function(r, s = {}) {
    let i = { name: r, properties: s };
    i = await Ar(i), i = Ir(i);
    const o = await Ft();
    if (!o.browserstack_user_id)
      return;
    const a = `page - ${r}`;
    return Nt(a, o, s), fetch(e + "/page", { ...n, body: JSON.stringify({ ...t, ...i }) });
  }, J.identify = async function(r, s) {
    let i = { userId: r, traits: s };
    await W, b.anonymousId && (i.anonymousId = b.anonymousId);
    const o = await Ft();
    return o.browserstack_user_id ? (Nt("identify", o, s), fetch(e + "/identify", { ...n, body: JSON.stringify({ ...t, ...i }) })) : void 0;
  }, J.reset = async function() {
    j("anonymousId", null);
  };
}
async function Ar(e) {
  var t, n;
  if (await W, (n = (t = b.userInformation) == null ? void 0 : t.user) != null && n.id)
    e.userId = b.userInformation.user.id;
  else {
    let r = b.anonymousId;
    r || (r = crypto.randomUUID(), await j("anonymousId", r)), e.anonymousId = r;
  }
  return e;
}
function Ir(e) {
  return e.userId || (e.integrations || (e.integrations = {}), e.integrations["Customer.io"] = !1), e;
}
async function Ft() {
  var e, t, n, r;
  return await W, {
    beb_user_id: ((t = (e = b.userInformation) == null ? void 0 : e.user) == null ? void 0 : t.id) || "",
    browserstack_user_id: ((r = (n = b.userInformation) == null ? void 0 : n.user) == null ? void 0 : r.browserstackUserId) || ""
  };
}
async function As(e) {
  var r, s, i, o;
  await W;
  const t = JSON.parse(JSON.stringify(b.userInformation));
  e ? e = { ...t, ...e } : e = {}, await j("userInformation", e);
  const n = !Object.keys(b.sessionUploadsByHost).length;
  e && n && ((r = e.user) == null ? void 0 : r.jobRole) === "quality_assurance" && await j("recordingSurface", "screen"), (s = e.user) != null && s.id && ((i = t.user) == null ? void 0 : i.id) !== e.user.id ? J.identify(e.user.id) : (o = e.user) != null && o.id || J.reset();
}
l.runtime.onInstalled.addListener(async function({ reason: e }) {
  var t;
  if (e === "install") {
    const r = (t = await l.tabs.query({ url: "https://app.birdeatsbug.com/complete-signup/get-started" })) == null ? void 0 : t[0], s = "https://app.birdeatsbug.com/complete-signup/ready";
    r ? await l.tabs.update(r.id, { active: !0, url: s }) : await l.tabs.create({ url: s });
  } else if (e === "update") {
    const n = await l.storage.local.get([
      "webcamPreviewShape",
      "techMode",
      "isAwareOfTechMode"
    ]);
    n.webcamPreviewShape || await j("webcamPreviewShape", "circle"), n.techMode || (await j("techMode", !0), await j("isAwareOfTechMode", !0));
  }
});
l.action.setBadgeBackgroundColor({ color: x.badge });
l.runtime.onConnect.addListener(function() {
});
l.runtime.onMessage.addListener(async function(e, t) {
  var n, r;
  switch (e.name) {
    case "startVideoRecording":
      return await xs(e);
    case "requestMicrophonePermission":
      return await S.requestMicrophonePermission();
    case "getVideoRecorderUISettings": {
      if (!S.state.mediaRecorderState)
        return {};
      if (((n = S.state.tab) == null ? void 0 : n.id) !== t.tab.id && S.state.surface !== "screen")
        return {};
      const s = await K(t.tab);
      return {
        ...S.state,
        showMouseClicks: S.state.mediaRecorderState === "recording",
        session: s
      };
    }
    case "setRecordingWidgetPosition": {
      S.state.recordingWidgetPosition.topPercent = e.recordingWidgetPosition.topPercent, S.state.recordingWidgetPosition.leftPercent = e.recordingWidgetPosition.leftPercent;
      return;
    }
    case "getMediaRecorderState":
      return S.state.mediaRecorderState;
    case "changeWebcamPreviewSide": {
      S.state.webcamPreviewSide = e.side;
      return;
    }
    case "resumeVideoRecording":
      return S.resume();
    case "pauseVideoRecording":
      return S.pause();
    case "stopVideoRecording":
      return S.stop();
    case "addMarker":
      return S.addMarker(e);
    case "takeScreenshot": {
      await ks(e);
      return;
    }
    case "saveConsoleEventsToIndexedDB": {
      const s = await K(t.tab);
      if (!s)
        return;
      const i = e.events.filter((a) => a);
      await v.addSessionEvents(s.id, "consoleEvents", i);
      const o = i.filter(ed);
      s.isInstantReplay && o.length > 0 && (await v.addSessionEvents(s.id, "errorEvents", o), we(t.tab)), Dt(t, e, i, "saveConsoleEventsToIndexedDB");
      return;
    }
    case "saveDomEventsToIndexedDB": {
      const s = await K(t.tab);
      if (!(s != null && s.isInstantReplay))
        return;
      const i = e.events.filter((o) => o);
      await v.addSessionEvents(s.id, "domEvents", [{ events: i, createdAt: e.events[0].timestamp }]), Dt(t, e, i, "saveDomEventsToIndexedDB");
      return;
    }
    case "saveNetworkEventsFromInstrumentationToIndexedDB": {
      const s = await K(t.tab);
      if (!s)
        return;
      const i = e.events.filter((o) => o);
      await v.addSessionEvents(s.id, "networkEventsFromInstrumentation", i);
      for (const o of i)
        o.sessionId = s.id, o.tabId = t.tab.id, await vn(o);
      Dt(t, e, i, "saveNetworkEventsFromInstrumentationToIndexedDB");
      return;
    }
    case "updateBadgeAndPopupSessionErrors": {
      we(e.tab);
      return;
    }
    case "openSession": {
      await Ts(e, t);
      return;
    }
    case "deleteSession": {
      let s = e.session;
      await v.deleteSession(s.id);
      return;
    }
    case "enableBackgroundMonitoringForHost": {
      const s = Array.from(
        /* @__PURE__ */ new Set([...b.hostsWithBackgroundMonitoringEnabled, e.host])
      );
      await j("hostsWithBackgroundMonitoringEnabled", s);
      const i = await Sr(e.host), o = e.tabId && i.find((a) => a.id === e.tabId);
      o && await z(o), i.forEach((a) => {
        a.id !== (o == null ? void 0 : o.id) && a.url.includes(e.host) && z(a);
      });
      return;
    }
    case "disableBackgroundMonitoringForHost": {
      J.track("Background Monitoring Disabled", { host: e.host, from: e.from });
      const s = b.hostsWithBackgroundMonitoringEnabled.filter(
        (c) => c !== e.host && c !== e.host.split(":")[0]
      );
      await j("hostsWithBackgroundMonitoringEnabled", s);
      const i = await Sr(e.host), o = e.tabId && i.find((c) => c.id === e.tabId), a = async (c) => {
        const u = await G.get(c.id);
        u != null && u.id && (G.delete(c.id), await v.deleteSession(u.id)), await z(c);
      };
      o && await a(o), i.forEach((c) => {
        c.id !== (o == null ? void 0 : o.id) && c.url.includes(e.host) && a(c);
      });
      return;
    }
    case "toggleInstantReplayWidgetOnAllTabs": {
      const { enabled: s, from: i } = e;
      return J.track(`Instant Replay Widget ${s ? "Enabled" : "Disabled"}`, { from: i }), await W, await j("instantReplayWidget", s), bs();
    }
    case "toggleRecordingWidget": {
      const { enabled: s } = e;
      J.track(`Recording widget ${s ? "Enabled" : "Disabled"}`), await W, await j("isRecorderWidgetEnabled", s);
      return;
    }
    case "setupTab":
      return z(t.tab);
    case "setupWebRequestAPI":
      return _s();
    case "setBadgeText":
      return Ve(t.tab.id, e.text);
    case "getRecentStorageErrors":
      return v.getRecentStorageErrors();
    case "clearStorage":
      return await v.clear();
    case "getContentOptions":
      return await W, b;
    case "recordingWidgetClosed": {
      S.state.isRecorderWidgetClosed = !0, J.track("Recording Widget Closed", { host: ((r = t.tab) == null ? void 0 : r.url) && new URL(t.tab.url).host });
      return;
    }
    case "setUserInformation":
      return await As(e.userInformation);
    case "getUserInformation":
      return await W, b.userInformation;
    case "reauthenticate": {
      await Is(e);
      return;
    }
    case "logout": {
      await j("userInformation", {});
      return;
    }
  }
});
async function Is({ focus: e = !0, connection: t }) {
  const n = await l.tabs.query({ url: l.runtime.getURL("localSession.html") }), r = n.find((o) => o.url.includes("sessionId=")), s = r || n[0];
  if (!s)
    return !1;
  let i = `${s.url}&reauthenticate=true`;
  return t && (i += `&connection=${t}`), await l.tabs.update(r.id, {
    url: i,
    active: e
  }), !0;
}
async function xs(e) {
  const t = e.tab, n = await Sn(t);
  n.startedAt = (/* @__PURE__ */ new Date()).toISOString(), t && (n.startUrl = t.url), await Promise.all([
    v.setSession(n),
    S.start({
      session: n,
      tab: t,
      surface: e.surface,
      recordMicrophone: e.recordMicrophone,
      recordWebcam: e.recordWebcam,
      isRecorderWidgetEnabled: e.isRecorderWidgetEnabled,
      audioDeviceId: e.audioDeviceId,
      videoQuality: b.videoQuality
    })
  ]), t && z(t);
}
async function ks(e) {
  const t = await l.tabs.captureVisibleTab(), n = e.tab;
  let r = await K(n);
  r || (r = await Sn(n)), r.isInstantReplay || (r.startedAt = (/* @__PURE__ */ new Date()).toISOString(), r.startUrl = n.url);
  const s = {
    type: "screenshot",
    dataUrl: t,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  r.endedAt = (/* @__PURE__ */ new Date()).toISOString(), r.endUrl = n.url, await Promise.all([
    v.setSession(r),
    v.addSessionEvents(r.id, "screenshotEvents", [s])
  ]);
  const i = l.runtime.getURL("localSession.html") + "#/?sessionId=" + r.id + "&mediaType=Screenshot";
  await l.tabs.create({ url: i });
}
async function Ts(e, t) {
  const { from: n } = e, r = e.tab || t.tab, s = await K(r);
  s.isInstantReplay && (s.endedAt = (/* @__PURE__ */ new Date()).toISOString(), s.endUrl = r.url, await v.setSession(s), J.track("DOM Recording Instant Replay Session Opened", { from: n }));
  const i = l.runtime.getURL("localSession.html") + "#/?sessionId=" + s.id;
  if (s.isInstantReplay) {
    const a = (await l.tabs.query({ url: l.runtime.getURL("localSession.html") })).find((c) => c.url.includes(s.id));
    if (a)
      return l.tabs.reload(a.id), await l.tabs.update(a.id, { active: !0 });
  }
  await l.tabs.create({ url: i });
}
l.runtime.onMessageExternal.addListener(async function(e) {
  switch (e.name) {
    case "getExtensionMetadata":
      return {
        version: "1.98.25",
        shortHash: "4f91ed0",
        environment: "production"
      };
    case "setUserInformation":
      return await As(e.userInformation);
    case "reauthenticate": {
      await Is(e);
      return;
    }
    case "logout": {
      await j("userInformation", {});
      const t = await l.tabs.query({ url: l.runtime.getURL("localSession.html") }), n = t.find((i) => i.url.includes("sessionId=")), r = n || t[0];
      if (r) {
        const i = `${r.url}&forceLogout=true`;
        return await l.tabs.update(n.id, { url: i }), !0;
      }
      const s = `${l.runtime.getURL("localSession.html")}#/auth/logout?close=true`;
      return await l.tabs.create({ url: s }), !0;
    }
  }
});
l.tabs.onActivated.addListener(id);
l.tabs.onUpdated.addListener(async function(e, t, n) {
  t.status === "loading" && (await z(n), await Ss(n, t.url ? "navigate" : "reload"));
});
l.tabs.onRemoved.addListener(async function(e) {
  await Ss({ id: e }, "close"), G.delete(e);
});
l.alarms.onAlarm.addListener(sd);
l.runtime.setUninstallURL(
  "https://docs.google.com/forms/d/e/1FAIpQLSeZk95Mm6MXx1rI3jQs-XwLkwJ2gOnhktp6z8Reb9VLhoDClw/viewform?usp=sf_link"
);
async function sd(e) {
  switch (e.name) {
    case "cleanStorage":
      await Qu(), await Zu();
  }
}
async function id(e) {
  await S.onTabActivated(e.tabId);
}
l.alarms.create("cleanStorage", {
  delayInMinutes: 15,
  periodInMinutes: 5
});
l.commands.onCommand.addListener(async (e) => {
  var n, r;
  const t = {};
  if (t.tab = (n = await l.tabs.query({ active: !0, currentWindow: !0 })) == null ? void 0 : n[0], e === "startVideoRecording" || e === "startVideoRecordingScreen")
    if (_n((r = t.tab) == null ? void 0 : r.url).isPossible || (t.tab = null), S.state.mediaRecorderState === "recording")
      await W, await (b.isRecorderWidgetEnabled ? S.pause() : S.stop());
    else if (S.state.mediaRecorderState === "paused")
      await S.resume();
    else {
      if (await W, e === "startVideoRecordingScreen" || !t.tab ? t.surface = "screen" : t.surface = b.recordingSurface, t.recordMicrophone = b.recordMicrophone, t.recordWebcam = b.recordWebcam, t.isRecorderWidgetEnabled = b.isRecorderWidgetEnabled, t.videoDeviceId = b.videoDeviceId, t.audioDeviceId = b.audioDeviceId, !t.tab) {
        const [s] = await l.tabs.query({ active: !0 });
        t.tab = s;
      }
      await xs(t);
    }
  else if (e === "openReplay") {
    if (!t.tab || !(await K(t.tab)).isInstantReplay)
      return;
    t.from = "keyboardShortcut", await Ts(t);
  } else if (e === "takeScreenshot") {
    if (!t.tab)
      return;
    await ks(t);
  }
});
async function od() {
  await ds(), await v.initialize(), await S.initializeState(), _s(), bs();
}
od();
Xc();
//# sourceMappingURL=serviceWorker.js.map
