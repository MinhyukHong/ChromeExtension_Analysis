var ke = Object.defineProperty, Me = Object.defineProperties;
var Re = Object.getOwnPropertyDescriptors;
var Kt = Object.getOwnPropertySymbols;
var Ne = Object.prototype.hasOwnProperty, Fe = Object.prototype.propertyIsEnumerable;
var Lt = (s, t, e) => t in s ? ke(s, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : s[t] = e, pt = (s, t) => {
  for (var e in t || (t = {}))
    Ne.call(t, e) && Lt(s, e, t[e]);
  if (Kt)
    for (var e of Kt(t))
      Fe.call(t, e) && Lt(s, e, t[e]);
  return s;
}, Ut = (s, t) => Me(s, Re(t));
import { b as Yt, a as Jt, c as Qt, f as zt, w as Te, B as Oe } from "./core.js";
import { l as xt } from "./log.js";
import { i as Rt, a as Q, b as Nt, c as Ze, d as Be, e as le, g as ce, m as de, f as Ee, t as Ge, h as Zt, n as Ve, j as Bt, I as Ht, k as ge, l as We, s as xe, o as he, p as ue, q as J, M as z, r as ct, u as pe, v as Dt, w as ht, x as Et, y as Gt, z as F, A as Ie, B as me, P as tt, C as De, E, N as Ke, D as Le, F as lt, _ as Ue, G as Ye, S as Je, H as Qe, J as ze, K as He, L as Xe } from "./base64-arraybuffer.es5.js";
function Xt(s) {
  return "__ln" in s;
}
class Pe {
  constructor() {
    this.length = 0, this.head = null, this.tail = null;
  }
  get(t) {
    if (t >= this.length)
      throw new Error("Position outside of list range");
    let e = this.head;
    for (let o = 0; o < t; o++)
      e = (e == null ? void 0 : e.next) || null;
    return e;
  }
  addNode(t) {
    const e = { value: t, previous: null, next: null };
    if (t.__ln = e, t.previousSibling && Xt(t.previousSibling)) {
      const o = t.previousSibling.__ln.next;
      e.next = o, e.previous = t.previousSibling.__ln, t.previousSibling.__ln.next = e, o && (o.previous = e);
    } else if (t.nextSibling && Xt(t.nextSibling) && t.nextSibling.__ln.previous) {
      const o = t.nextSibling.__ln.previous;
      e.previous = o, e.next = t.nextSibling.__ln, t.nextSibling.__ln.previous = e, o && (o.next = e);
    } else
      this.head && (this.head.previous = e), e.next = this.head, this.head = e;
    e.next === null && (this.tail = e), this.length++;
  }
  removeNode(t) {
    const e = t.__ln;
    this.head && (e.previous ? (e.previous.next = e.next, e.next ? e.next.previous = e.previous : this.tail = e.previous) : (this.head = e.next, this.head ? this.head.previous = null : this.tail = null), t.__ln && delete t.__ln, this.length--);
  }
}
const Pt = (s, t) => `${s}@${t}`;
class je {
  constructor() {
    this.frozen = !1, this.locked = !1, this.texts = [], this.attributes = [], this.removes = [], this.mapRemoves = [], this.movedMap = {}, this.addedSet = /* @__PURE__ */ new Set(), this.movedSet = /* @__PURE__ */ new Set(), this.droppedSet = /* @__PURE__ */ new Set(), this.processMutations = (t) => {
      t.forEach(this.processMutation), this.emit();
    }, this.emit = () => {
      if (this.frozen || this.locked)
        return;
      const t = [], e = /* @__PURE__ */ new Set(), o = new Pe(), r = (n) => {
        let l = n, g = Ht;
        for (; g === Ht; )
          l = l && l.nextSibling, g = l && this.mirror.getId(l);
        return g;
      }, a = (n) => {
        if (!n.parentNode || !ge(n))
          return;
        const l = Nt(n.parentNode) ? this.mirror.getId(We(n)) : this.mirror.getId(n.parentNode), g = r(n);
        if (l === -1 || g === -1)
          return o.addNode(n);
        const Z = xe(n, { doc: this.doc, mirror: this.mirror, blockClass: this.blockClass, blockSelector: this.blockSelector, maskTextClass: this.maskTextClass, maskTextSelector: this.maskTextSelector, skipChild: !0, newlyAddedElement: !0, inlineStylesheet: this.inlineStylesheet, maskInputOptions: this.maskInputOptions, maskTextFn: this.maskTextFn, maskInputFn: this.maskInputFn, slimDOMOptions: this.slimDOMOptions, dataURLOptions: this.dataURLOptions, recordCanvas: this.recordCanvas, inlineImages: this.inlineImages, onSerialize: (y) => {
          he(y, this.mirror) && this.iframeManager.addIframe(y), ue(y, this.mirror) && this.stylesheetManager.trackLinkElement(y), Bt(n) && this.shadowDomManager.addShadowRoot(n.shadowRoot, this.doc);
        }, onIframeLoad: (y, f) => {
          this.iframeManager.attachIframe(y, f), this.shadowDomManager.observeAttachShadow(y);
        }, onStylesheetLoad: (y, f) => {
          this.stylesheetManager.attachLinkElement(y, f);
        } });
        Z && (t.push({ parentId: l, nextId: g, node: Z }), e.add(Z.id));
      };
      for (; this.mapRemoves.length; )
        this.mirror.removeNodeFromMap(this.mapRemoves.shift());
      for (const n of this.movedSet)
        jt(this.removes, n, this.mirror) && !this.movedSet.has(n.parentNode) || a(n);
      for (const n of this.addedSet)
        qt(this.droppedSet, n) || jt(this.removes, n, this.mirror) ? qt(this.movedSet, n) ? a(n) : this.droppedSet.add(n) : a(n);
      let u = null;
      for (; o.length; ) {
        let n = null;
        if (u) {
          const l = this.mirror.getId(u.value.parentNode), g = r(u.value);
          l !== -1 && g !== -1 && (n = u);
        }
        if (!n) {
          let l = o.tail;
          for (; l; ) {
            const g = l;
            if (l = l.previous, g) {
              const Z = this.mirror.getId(g.value.parentNode);
              if (r(g.value) === -1)
                continue;
              if (Z !== -1) {
                n = g;
                break;
              }
              {
                const y = g.value;
                if (y.parentNode && y.parentNode.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
                  const f = y.parentNode.host;
                  if (this.mirror.getId(f) !== -1) {
                    n = g;
                    break;
                  }
                }
              }
            }
          }
        }
        if (!n) {
          for (; o.head; )
            o.removeNode(o.head.value);
          break;
        }
        u = n.previous, o.removeNode(n.value), a(n.value);
      }
      const c = { texts: this.texts.map((n) => ({ id: this.mirror.getId(n.node), value: n.value })).filter((n) => !e.has(n.id)).filter((n) => this.mirror.has(n.id)), attributes: this.attributes.map((n) => {
        const { attributes: l } = n;
        if (typeof l.style == "string") {
          const g = JSON.stringify(n.styleDiff), Z = JSON.stringify(n._unchangedStyles);
          g.length < l.style.length && (g + Z).split("var(").length === l.style.split("var(").length && (l.style = n.styleDiff);
        }
        return { id: this.mirror.getId(n.node), attributes: l };
      }).filter((n) => !e.has(n.id)).filter((n) => this.mirror.has(n.id)), removes: this.removes, adds: t };
      (c.texts.length || c.attributes.length || c.removes.length || c.adds.length) && (this.texts = [], this.attributes = [], this.removes = [], this.addedSet = /* @__PURE__ */ new Set(), this.movedSet = /* @__PURE__ */ new Set(), this.droppedSet = /* @__PURE__ */ new Set(), this.movedMap = {}, this.mutationCb(c));
    }, this.processMutation = (t) => {
      if (Rt(t.target, this.mirror))
        return;
      let e;
      try {
        e = document.implementation.createHTMLDocument();
      } catch (o) {
        e = this.doc;
      }
      switch (t.type) {
        case "characterData": {
          const o = t.target.textContent;
          Q(t.target, this.blockClass, this.blockSelector, !1) || o === t.oldValue || this.texts.push({ value: Ve(t.target, this.maskTextClass, this.maskTextSelector) && o ? this.maskTextFn ? this.maskTextFn(o) : o.replace(/[\S]/g, "*") : o, node: t.target });
          break;
        }
        case "attributes": {
          const o = t.target;
          let r = t.attributeName, a = t.target.getAttribute(r);
          if (r === "value") {
            const c = ce(o);
            a = de({ element: o, maskInputOptions: this.maskInputOptions, tagName: o.tagName, type: c, value: a, maskInputFn: this.maskInputFn });
          }
          if (Q(t.target, this.blockClass, this.blockSelector, !1) || a === t.oldValue)
            return;
          let u = this.attributes.find((c) => c.node === t.target);
          if (o.tagName === "IFRAME" && r === "src" && !this.keepIframeSrcFn(a)) {
            if (o.contentDocument)
              return;
            r = "rr_src";
          }
          if (u || (u = { node: t.target, attributes: {}, styleDiff: {}, _unchangedStyles: {} }, this.attributes.push(u)), r === "type" && o.tagName === "INPUT" && (t.oldValue || "").toLowerCase() === "password" && o.setAttribute("data-rr-is-password", "true"), !Ee(o.tagName, r) && (u.attributes[r] = Ge(this.doc, Zt(o.tagName), Zt(r), a), r === "style")) {
            const c = e.createElement("span");
            t.oldValue && c.setAttribute("style", t.oldValue);
            for (const n of Array.from(o.style)) {
              const l = o.style.getPropertyValue(n), g = o.style.getPropertyPriority(n);
              l !== c.style.getPropertyValue(n) || g !== c.style.getPropertyPriority(n) ? u.styleDiff[n] = g === "" ? l : [l, g] : u._unchangedStyles[n] = [l, g];
            }
            for (const n of Array.from(c.style))
              o.style.getPropertyValue(n) === "" && (u.styleDiff[n] = !1);
          }
          break;
        }
        case "childList":
          if (Q(t.target, this.blockClass, this.blockSelector, !0))
            return;
          t.addedNodes.forEach((o) => this.genAdds(o, t.target)), t.removedNodes.forEach((o) => {
            const r = this.mirror.getId(o), a = Nt(t.target) ? this.mirror.getId(t.target.host) : this.mirror.getId(t.target);
            Q(t.target, this.blockClass, this.blockSelector, !1) || Rt(o, this.mirror) || !Ze(o, this.mirror) || (this.addedSet.has(o) ? (Vt(this.addedSet, o), this.droppedSet.add(o)) : this.addedSet.has(t.target) && r === -1 || Be(t.target, this.mirror) || (this.movedSet.has(o) && this.movedMap[Pt(r, a)] ? Vt(this.movedSet, o) : this.removes.push({ parentId: a, id: r, isShadow: !(!Nt(t.target) || !le(t.target)) || void 0 })), this.mapRemoves.push(o));
          });
      }
    }, this.genAdds = (t, e) => {
      if (!this.processedNodeManager.inOtherBuffer(t, this) && !this.addedSet.has(t) && !this.movedSet.has(t)) {
        if (this.mirror.hasNode(t)) {
          if (Rt(t, this.mirror))
            return;
          this.movedSet.add(t);
          let o = null;
          e && this.mirror.hasNode(e) && (o = this.mirror.getId(e)), o && o !== -1 && (this.movedMap[Pt(this.mirror.getId(t), o)] = !0);
        } else
          this.addedSet.add(t), this.droppedSet.delete(t);
        Q(t, this.blockClass, this.blockSelector, !1) || (t.childNodes.forEach((o) => this.genAdds(o)), Bt(t) && t.shadowRoot.childNodes.forEach((o) => {
          this.processedNodeManager.add(o, this), this.genAdds(o, t);
        }));
      }
    };
  }
  init(t) {
    ["mutationCb", "blockClass", "blockSelector", "maskTextClass", "maskTextSelector", "inlineStylesheet", "maskInputOptions", "maskTextFn", "maskInputFn", "keepIframeSrcFn", "recordCanvas", "inlineImages", "slimDOMOptions", "dataURLOptions", "doc", "mirror", "iframeManager", "stylesheetManager", "shadowDomManager", "canvasManager", "processedNodeManager"].forEach((e) => {
      this[e] = t[e];
    });
  }
  freeze() {
    this.frozen = !0, this.canvasManager.freeze();
  }
  unfreeze() {
    this.frozen = !1, this.canvasManager.unfreeze(), this.emit();
  }
  isFrozen() {
    return this.frozen;
  }
  lock() {
    this.locked = !0, this.canvasManager.lock();
  }
  unlock() {
    this.locked = !1, this.canvasManager.unlock(), this.emit();
  }
  reset() {
    this.shadowDomManager.reset(), this.canvasManager.reset();
  }
}
function Vt(s, t) {
  s.delete(t), t.childNodes.forEach((e) => Vt(s, e));
}
function jt(s, t, e) {
  return s.length !== 0 && Ce(s, t, e);
}
function Ce(s, t, e) {
  const { parentNode: o } = t;
  if (!o)
    return !1;
  const r = e.getId(o);
  return !!s.some((a) => a.id === r) || Ce(s, o, e);
}
function qt(s, t) {
  return s.size !== 0 && ye(s, t);
}
function ye(s, t) {
  const { parentNode: e } = t;
  return !!e && (!!s.has(e) || ye(s, e));
}
let dt;
function qe(s) {
  dt = s;
}
function _e() {
  dt = void 0;
}
const k = (s) => dt ? (...t) => {
  try {
    return s(...t);
  } catch (e) {
    if (dt && dt(e) === !0)
      return;
    throw e;
  }
} : s, nt = [];
function gt(s) {
  try {
    if ("composedPath" in s) {
      const t = s.composedPath();
      if (t.length)
        return t[0];
    } else if ("path" in s && s.path.length)
      return s.path[0];
  } catch (t) {
  }
  return s && s.target;
}
function fe(s, t) {
  var e, o;
  const r = new je();
  nt.push(r), r.init(s);
  let a = window.MutationObserver || window.__rrMutationObserver;
  const u = (o = (e = window == null ? void 0 : window.Zone) === null || e === void 0 ? void 0 : e.__symbol__) === null || o === void 0 ? void 0 : o.call(e, "MutationObserver");
  u && window[u] && (a = window[u]);
  const c = new a(k(r.processMutations.bind(r)));
  return c.observe(t, { attributes: !0, attributeOldValue: !0, characterData: !0, characterDataOldValue: !0, childList: !0, subtree: !0 }), c;
}
function $e({ mouseInteractionCb: s, doc: t, mirror: e, blockClass: o, blockSelector: r, sampling: a }) {
  if (a.mouseInteraction === !1)
    return () => {
    };
  const u = a.mouseInteraction === !0 || a.mouseInteraction === void 0 ? {} : a.mouseInteraction, c = [];
  let n = null;
  return Object.keys(z).filter((l) => Number.isNaN(Number(l)) && !l.endsWith("_Departed") && u[l] !== !1).forEach((l) => {
    let g = Zt(l);
    const Z = /* @__PURE__ */ ((y) => (f) => {
      const W = gt(f);
      if (Q(W, o, r, !0))
        return;
      let M = null, h = y;
      if ("pointerType" in f) {
        switch (f.pointerType) {
          case "mouse":
            M = tt.Mouse;
            break;
          case "touch":
            M = tt.Touch;
            break;
          case "pen":
            M = tt.Pen;
        }
        M === tt.Touch ? z[y] === z.MouseDown ? h = "TouchStart" : z[y] === z.MouseUp && (h = "TouchEnd") : tt.Pen;
      } else
        Et(f) && (M = tt.Touch);
      M !== null ? (n = M, (h.startsWith("Touch") && M === tt.Touch || h.startsWith("Mouse") && M === tt.Mouse) && (M = null)) : z[y] === z.Click && (M = n, n = null);
      const d = Et(f) ? f.changedTouches[0] : f;
      if (!d)
        return;
      const m = e.getId(W), { clientX: I, clientY: B } = d;
      k(s)(Object.assign({ type: z[h], id: m, x: I, y: B }, M !== null && { pointerType: M }));
    })(l);
    if (window.PointerEvent)
      switch (z[l]) {
        case z.MouseDown:
        case z.MouseUp:
          g = g.replace("mouse", "pointer");
          break;
        case z.TouchStart:
        case z.TouchEnd:
          return;
      }
    c.push(J(g, Z, t));
  }), k(() => {
    c.forEach((l) => l());
  });
}
function Se({ scrollCb: s, doc: t, mirror: e, blockClass: o, blockSelector: r, sampling: a }) {
  const u = k(ct(k((c) => {
    const n = gt(c);
    if (!n || Q(n, o, r, !0))
      return;
    const l = e.getId(n);
    if (n === t && t.defaultView) {
      const g = pe(t.defaultView);
      s({ id: l, x: g.left, y: g.top });
    } else
      s({ id: l, x: n.scrollLeft, y: n.scrollTop });
  }), a.scroll || 100));
  return J("scroll", u, t);
}
function _t(s, t) {
  const e = Object.assign({}, s);
  return t || delete e.userTriggered, e;
}
const ts = ["INPUT", "TEXTAREA", "SELECT"], $t = /* @__PURE__ */ new WeakMap();
function It(s) {
  return function(t, e) {
    if (mt("CSSGroupingRule") && t.parentRule instanceof CSSGroupingRule || mt("CSSMediaRule") && t.parentRule instanceof CSSMediaRule || mt("CSSSupportsRule") && t.parentRule instanceof CSSSupportsRule || mt("CSSConditionRule") && t.parentRule instanceof CSSConditionRule) {
      const o = Array.from(t.parentRule.cssRules).indexOf(t);
      e.unshift(o);
    } else if (t.parentStyleSheet) {
      const o = Array.from(t.parentStyleSheet.cssRules).indexOf(t);
      e.unshift(o);
    }
    return e;
  }(s, []);
}
function et(s, t, e) {
  let o, r;
  return s ? (s.ownerNode ? o = t.getId(s.ownerNode) : r = e.getId(s), { styleId: r, id: o }) : {};
}
function Ae({ mirror: s, stylesheetManager: t }, e) {
  var o, r, a;
  let u = null;
  u = e.nodeName === "#document" ? s.getId(e) : s.getId(e.host);
  const c = e.nodeName === "#document" ? (o = e.defaultView) === null || o === void 0 ? void 0 : o.Document : (a = (r = e.ownerDocument) === null || r === void 0 ? void 0 : r.defaultView) === null || a === void 0 ? void 0 : a.ShadowRoot, n = Object.getOwnPropertyDescriptor(c == null ? void 0 : c.prototype, "adoptedStyleSheets");
  return u !== null && u !== -1 && c && n ? (Object.defineProperty(e, "adoptedStyleSheets", { configurable: n.configurable, enumerable: n.enumerable, get() {
    var l;
    return (l = n.get) === null || l === void 0 ? void 0 : l.call(this);
  }, set(l) {
    var g;
    const Z = (g = n.set) === null || g === void 0 ? void 0 : g.call(this, l);
    if (u !== null && u !== -1)
      try {
        t.adoptStyleSheets(l, u);
      } catch (y) {
      }
    return Z;
  } }), k(() => {
    Object.defineProperty(e, "adoptedStyleSheets", { configurable: n.configurable, enumerable: n.enumerable, get: n.get, set: n.set });
  })) : () => {
  };
}
function es(s, t = {}) {
  const e = s.doc.defaultView;
  if (!e)
    return () => {
    };
  (function(h, d) {
    const { mutationCb: m, mousemoveCb: I, mouseInteractionCb: B, scrollCb: T, viewportResizeCb: w, inputCb: R, mediaInteractionCb: C, styleSheetRuleCb: O, styleDeclarationCb: S, canvasMutationCb: p, fontCb: v, selectionCb: A } = h;
    h.mutationCb = (...i) => {
      d.mutation && d.mutation(...i), m(...i);
    }, h.mousemoveCb = (...i) => {
      d.mousemove && d.mousemove(...i), I(...i);
    }, h.mouseInteractionCb = (...i) => {
      d.mouseInteraction && d.mouseInteraction(...i), B(...i);
    }, h.scrollCb = (...i) => {
      d.scroll && d.scroll(...i), T(...i);
    }, h.viewportResizeCb = (...i) => {
      d.viewportResize && d.viewportResize(...i), w(...i);
    }, h.inputCb = (...i) => {
      d.input && d.input(...i), R(...i);
    }, h.mediaInteractionCb = (...i) => {
      d.mediaInteaction && d.mediaInteaction(...i), C(...i);
    }, h.styleSheetRuleCb = (...i) => {
      d.styleSheetRule && d.styleSheetRule(...i), O(...i);
    }, h.styleDeclarationCb = (...i) => {
      d.styleDeclaration && d.styleDeclaration(...i), S(...i);
    }, h.canvasMutationCb = (...i) => {
      d.canvasMutation && d.canvasMutation(...i), p(...i);
    }, h.fontCb = (...i) => {
      d.font && d.font(...i), v(...i);
    }, h.selectionCb = (...i) => {
      d.selection && d.selection(...i), A(...i);
    };
  })(s, t);
  const o = fe(s, s.doc), r = function({ mousemoveCb: h, sampling: d, doc: m, mirror: I }) {
    if (d.mousemove === !1)
      return () => {
      };
    const B = typeof d.mousemove == "number" ? d.mousemove : 50, T = typeof d.mousemoveCallback == "number" ? d.mousemoveCallback : 500;
    let w, R = [];
    const C = ct(k((p) => {
      const v = Date.now() - w;
      h(R.map((A) => (A.timeOffset -= v, A)), p), R = [], w = null;
    }), T), O = k(ct(k((p) => {
      const v = gt(p), { clientX: A, clientY: i } = Et(p) ? p.changedTouches[0] : p;
      w || (w = Gt()), R.push({ x: A, y: i, id: I.getId(v), timeOffset: Gt() - w }), C(typeof DragEvent != "undefined" && p instanceof DragEvent ? F.Drag : p instanceof MouseEvent ? F.MouseMove : F.TouchMove);
    }), B, { trailing: !1 })), S = [J("mousemove", O, m), J("touchmove", O, m), J("drag", O, m)];
    return k(() => {
      S.forEach((p) => p());
    });
  }(s), a = $e(s), u = Se(s), c = function({ viewportResizeCb: h }, { win: d }) {
    let m = -1, I = -1;
    const B = k(ct(k(() => {
      const T = Ie(), w = me();
      m === T && I === w || (h({ width: Number(w), height: Number(T) }), m = T, I = w);
    }), 200));
    return J("resize", B, d);
  }(s, { win: e }), n = function({ inputCb: h, doc: d, mirror: m, blockClass: I, blockSelector: B, ignoreClass: T, ignoreSelector: w, maskInputOptions: R, maskInputFn: C, sampling: O, userTriggeredOnInput: S }) {
    function p(V) {
      let G = gt(V);
      const _ = V.isTrusted, H = G && G.tagName;
      if (G && H === "OPTION" && (G = G.parentElement), !G || !H || ts.indexOf(H) < 0 || Q(G, I, B, !0) || G.classList.contains(T) || w && G.matches(w))
        return;
      let rt = G.value, q = !1;
      const $ = ce(G) || "";
      $ === "radio" || $ === "checkbox" ? q = G.checked : (R[H.toLowerCase()] || R[$]) && (rt = de({ element: G, maskInputOptions: R, tagName: H, type: $, value: rt, maskInputFn: C })), v(G, k(_t)({ text: rt, isChecked: q, userTriggered: _ }, S));
      const it = G.name;
      $ === "radio" && it && q && d.querySelectorAll(`input[type="radio"][name="${it}"]`).forEach((X) => {
        X !== G && v(X, k(_t)({ text: X.value, isChecked: !q, userTriggered: !1 }, S));
      });
    }
    function v(V, G) {
      const _ = $t.get(V);
      if (!_ || _.text !== G.text || _.isChecked !== G.isChecked) {
        $t.set(V, G);
        const H = m.getId(V);
        k(h)(Object.assign(Object.assign({}, G), { id: H }));
      }
    }
    const A = (O.input === "last" ? ["change"] : ["input", "change"]).map((V) => J(V, k(p), d)), i = d.defaultView;
    if (!i)
      return () => {
        A.forEach((V) => V());
      };
    const N = i.Object.getOwnPropertyDescriptor(i.HTMLInputElement.prototype, "value"), U = [[i.HTMLInputElement.prototype, "value"], [i.HTMLInputElement.prototype, "checked"], [i.HTMLSelectElement.prototype, "value"], [i.HTMLTextAreaElement.prototype, "value"], [i.HTMLSelectElement.prototype, "selectedIndex"], [i.HTMLOptionElement.prototype, "selected"]];
    return N && N.set && A.push(...U.map((V) => Dt(V[0], V[1], { set() {
      k(p)({ target: this, isTrusted: !1 });
    } }, !1, i))), k(() => {
      A.forEach((V) => V());
    });
  }(s), l = function({ mediaInteractionCb: h, blockClass: d, blockSelector: m, mirror: I, sampling: B, doc: T }) {
    const w = k((C) => ct(k((O) => {
      const S = gt(O);
      if (!S || Q(S, d, m, !0))
        return;
      const { currentTime: p, volume: v, muted: A, playbackRate: i } = S;
      h({ type: C, id: I.getId(S), currentTime: p, volume: v, muted: A, playbackRate: i });
    }), B.media || 500)), R = [J("play", w(0), T), J("pause", w(1), T), J("seeked", w(2), T), J("volumechange", w(3), T), J("ratechange", w(4), T)];
    return k(() => {
      R.forEach((C) => C());
    });
  }(s), g = function({ styleSheetRuleCb: h, mirror: d, stylesheetManager: m }, { win: I }) {
    if (!I.CSSStyleSheet || !I.CSSStyleSheet.prototype)
      return () => {
      };
    const B = I.CSSStyleSheet.prototype.insertRule;
    I.CSSStyleSheet.prototype.insertRule = new Proxy(B, { apply: k((S, p, v) => {
      const [A, i] = v, { id: N, styleId: U } = et(p, d, m.styleMirror);
      return (N && N !== -1 || U && U !== -1) && h({ id: N, styleId: U, adds: [{ rule: A, index: i }] }), S.apply(p, v);
    }) });
    const T = I.CSSStyleSheet.prototype.deleteRule;
    let w, R;
    I.CSSStyleSheet.prototype.deleteRule = new Proxy(T, { apply: k((S, p, v) => {
      const [A] = v, { id: i, styleId: N } = et(p, d, m.styleMirror);
      return (i && i !== -1 || N && N !== -1) && h({ id: i, styleId: N, removes: [{ index: A }] }), S.apply(p, v);
    }) }), I.CSSStyleSheet.prototype.replace && (w = I.CSSStyleSheet.prototype.replace, I.CSSStyleSheet.prototype.replace = new Proxy(w, { apply: k((S, p, v) => {
      const [A] = v, { id: i, styleId: N } = et(p, d, m.styleMirror);
      return (i && i !== -1 || N && N !== -1) && h({ id: i, styleId: N, replace: A }), S.apply(p, v);
    }) })), I.CSSStyleSheet.prototype.replaceSync && (R = I.CSSStyleSheet.prototype.replaceSync, I.CSSStyleSheet.prototype.replaceSync = new Proxy(R, { apply: k((S, p, v) => {
      const [A] = v, { id: i, styleId: N } = et(p, d, m.styleMirror);
      return (i && i !== -1 || N && N !== -1) && h({ id: i, styleId: N, replaceSync: A }), S.apply(p, v);
    }) }));
    const C = {};
    Ct("CSSGroupingRule") ? C.CSSGroupingRule = I.CSSGroupingRule : (Ct("CSSMediaRule") && (C.CSSMediaRule = I.CSSMediaRule), Ct("CSSConditionRule") && (C.CSSConditionRule = I.CSSConditionRule), Ct("CSSSupportsRule") && (C.CSSSupportsRule = I.CSSSupportsRule));
    const O = {};
    return Object.entries(C).forEach(([S, p]) => {
      O[S] = { insertRule: p.prototype.insertRule, deleteRule: p.prototype.deleteRule }, p.prototype.insertRule = new Proxy(O[S].insertRule, { apply: k((v, A, i) => {
        const [N, U] = i, { id: V, styleId: G } = et(A.parentStyleSheet, d, m.styleMirror);
        return (V && V !== -1 || G && G !== -1) && h({ id: V, styleId: G, adds: [{ rule: N, index: [...It(A), U || 0] }] }), v.apply(A, i);
      }) }), p.prototype.deleteRule = new Proxy(O[S].deleteRule, { apply: k((v, A, i) => {
        const [N] = i, { id: U, styleId: V } = et(A.parentStyleSheet, d, m.styleMirror);
        return (U && U !== -1 || V && V !== -1) && h({ id: U, styleId: V, removes: [{ index: [...It(A), N] }] }), v.apply(A, i);
      }) });
    }), k(() => {
      I.CSSStyleSheet.prototype.insertRule = B, I.CSSStyleSheet.prototype.deleteRule = T, w && (I.CSSStyleSheet.prototype.replace = w), R && (I.CSSStyleSheet.prototype.replaceSync = R), Object.entries(C).forEach(([S, p]) => {
        p.prototype.insertRule = O[S].insertRule, p.prototype.deleteRule = O[S].deleteRule;
      });
    });
  }(s, { win: e }), Z = Ae(s, s.doc), y = function({ styleDeclarationCb: h, mirror: d, ignoreCSSAttributes: m, stylesheetManager: I }, { win: B }) {
    const T = B.CSSStyleDeclaration.prototype.setProperty;
    B.CSSStyleDeclaration.prototype.setProperty = new Proxy(T, { apply: k((R, C, O) => {
      var S;
      const [p, v, A] = O;
      if (m.has(p))
        return T.apply(C, [p, v, A]);
      const { id: i, styleId: N } = et((S = C.parentRule) === null || S === void 0 ? void 0 : S.parentStyleSheet, d, I.styleMirror);
      return (i && i !== -1 || N && N !== -1) && h({ id: i, styleId: N, set: { property: p, value: v, priority: A }, index: It(C.parentRule) }), R.apply(C, O);
    }) });
    const w = B.CSSStyleDeclaration.prototype.removeProperty;
    return B.CSSStyleDeclaration.prototype.removeProperty = new Proxy(w, { apply: k((R, C, O) => {
      var S;
      const [p] = O;
      if (m.has(p))
        return w.apply(C, [p]);
      const { id: v, styleId: A } = et((S = C.parentRule) === null || S === void 0 ? void 0 : S.parentStyleSheet, d, I.styleMirror);
      return (v && v !== -1 || A && A !== -1) && h({ id: v, styleId: A, remove: { property: p }, index: It(C.parentRule) }), R.apply(C, O);
    }) }), k(() => {
      B.CSSStyleDeclaration.prototype.setProperty = T, B.CSSStyleDeclaration.prototype.removeProperty = w;
    });
  }(s, { win: e }), f = s.collectFonts ? function({ fontCb: h, doc: d }) {
    const m = d.defaultView;
    if (!m)
      return () => {
      };
    const I = [], B = /* @__PURE__ */ new WeakMap(), T = m.FontFace;
    m.FontFace = function(R, C, O) {
      const S = new T(R, C, O);
      return B.set(S, { family: R, buffer: typeof C != "string", descriptors: O, fontSource: typeof C == "string" ? C : JSON.stringify(Array.from(new Uint8Array(C))) }), S;
    };
    const w = ht(d.fonts, "add", function(R) {
      return function(C) {
        return setTimeout(k(() => {
          const O = B.get(C);
          O && (h(O), B.delete(C));
        }), 0), R.apply(this, [C]);
      };
    });
    return I.push(() => {
      m.FontFace = T;
    }), I.push(w), k(() => {
      I.forEach((R) => R());
    });
  }(s) : () => {
  }, W = function(h) {
    const { doc: d, mirror: m, blockClass: I, blockSelector: B, selectionCb: T } = h;
    let w = !0;
    const R = k(() => {
      const C = d.getSelection();
      if (!C || w && (C != null && C.isCollapsed))
        return;
      w = C.isCollapsed || !1;
      const O = [], S = C.rangeCount || 0;
      for (let p = 0; p < S; p++) {
        const v = C.getRangeAt(p), { startContainer: A, startOffset: i, endContainer: N, endOffset: U } = v;
        Q(A, I, B, !0) || Q(N, I, B, !0) || O.push({ start: m.getId(A), startOffset: i, end: m.getId(N), endOffset: U });
      }
      T({ ranges: O });
    });
    return R(), J("selectionchange", R);
  }(s), M = [];
  for (const h of s.plugins)
    M.push(h.observer(h.callback, e, h.options));
  return k(() => {
    nt.forEach((h) => h.reset()), o.disconnect(), r(), a(), u(), c(), n(), l(), g(), Z(), y(), f(), W(), M.forEach((h) => h());
  });
}
function mt(s) {
  return window[s] !== void 0;
}
function Ct(s) {
  return !!(window[s] !== void 0 && window[s].prototype && "insertRule" in window[s].prototype && "deleteRule" in window[s].prototype);
}
class te {
  constructor(t) {
    this.generateIdFn = t, this.iframeIdToRemoteIdMap = /* @__PURE__ */ new WeakMap(), this.iframeRemoteIdToIdMap = /* @__PURE__ */ new WeakMap();
  }
  getId(t, e, o, r) {
    const a = o || this.getIdToRemoteIdMap(t), u = r || this.getRemoteIdToIdMap(t);
    let c = a.get(e);
    return c || (c = this.generateIdFn(), a.set(e, c), u.set(c, e)), c;
  }
  getIds(t, e) {
    const o = this.getIdToRemoteIdMap(t), r = this.getRemoteIdToIdMap(t);
    return e.map((a) => this.getId(t, a, o, r));
  }
  getRemoteId(t, e, o) {
    const r = o || this.getRemoteIdToIdMap(t);
    return typeof e != "number" ? e : r.get(e) || -1;
  }
  getRemoteIds(t, e) {
    const o = this.getRemoteIdToIdMap(t);
    return e.map((r) => this.getRemoteId(t, r, o));
  }
  reset(t) {
    if (!t)
      return this.iframeIdToRemoteIdMap = /* @__PURE__ */ new WeakMap(), void (this.iframeRemoteIdToIdMap = /* @__PURE__ */ new WeakMap());
    this.iframeIdToRemoteIdMap.delete(t), this.iframeRemoteIdToIdMap.delete(t);
  }
  getIdToRemoteIdMap(t) {
    let e = this.iframeIdToRemoteIdMap.get(t);
    return e || (e = /* @__PURE__ */ new Map(), this.iframeIdToRemoteIdMap.set(t, e)), e;
  }
  getRemoteIdToIdMap(t) {
    let e = this.iframeRemoteIdToIdMap.get(t);
    return e || (e = /* @__PURE__ */ new Map(), this.iframeRemoteIdToIdMap.set(t, e)), e;
  }
}
class ss {
  constructor(t) {
    this.iframes = /* @__PURE__ */ new WeakMap(), this.crossOriginIframeMap = /* @__PURE__ */ new WeakMap(), this.crossOriginIframeMirror = new te(De), this.crossOriginIframeRootIdMap = /* @__PURE__ */ new WeakMap(), this.mutationCb = t.mutationCb, this.wrappedEmit = t.wrappedEmit, this.stylesheetManager = t.stylesheetManager, this.recordCrossOriginIframes = t.recordCrossOriginIframes, this.crossOriginIframeStyleMirror = new te(this.stylesheetManager.styleMirror.generateId.bind(this.stylesheetManager.styleMirror)), this.mirror = t.mirror, this.recordCrossOriginIframes && window.addEventListener("message", this.handleMessage.bind(this));
  }
  addIframe(t) {
    this.iframes.set(t, !0), t.contentWindow && this.crossOriginIframeMap.set(t.contentWindow, t);
  }
  addLoadListener(t) {
    this.loadListener = t;
  }
  attachIframe(t, e) {
    var o;
    this.mutationCb({ adds: [{ parentId: this.mirror.getId(t), nextId: null, node: e }], removes: [], texts: [], attributes: [], isAttachIframe: !0 }), (o = this.loadListener) === null || o === void 0 || o.call(this, t), t.contentDocument && t.contentDocument.adoptedStyleSheets && t.contentDocument.adoptedStyleSheets.length > 0 && this.stylesheetManager.adoptStyleSheets(t.contentDocument.adoptedStyleSheets, this.mirror.getId(t.contentDocument));
  }
  handleMessage(t) {
    const e = t;
    if (e.data.type !== "rrweb" || e.origin !== e.data.origin || !t.source)
      return;
    const o = this.crossOriginIframeMap.get(t.source);
    if (!o)
      return;
    const r = this.transformCrossOriginEvent(o, e.data.event);
    r && this.wrappedEmit(r, e.data.isCheckout);
  }
  transformCrossOriginEvent(t, e) {
    var o;
    switch (e.type) {
      case E.FullSnapshot: {
        this.crossOriginIframeMirror.reset(t), this.crossOriginIframeStyleMirror.reset(t), this.replaceIdOnNode(e.data.node, t);
        const r = e.data.node.id;
        return this.crossOriginIframeRootIdMap.set(t, r), this.patchRootIdOnNode(e.data.node, r), { timestamp: e.timestamp, type: E.IncrementalSnapshot, data: { source: F.Mutation, adds: [{ parentId: this.mirror.getId(t), nextId: null, node: e.data.node }], removes: [], texts: [], attributes: [], isAttachIframe: !0 } };
      }
      case E.Meta:
      case E.Load:
      case E.DomContentLoaded:
        return !1;
      case E.Plugin:
        return e;
      case E.Custom:
        return this.replaceIds(e.data.payload, t, ["id", "parentId", "previousId", "nextId"]), e;
      case E.IncrementalSnapshot:
        switch (e.data.source) {
          case F.Mutation:
            return e.data.adds.forEach((r) => {
              this.replaceIds(r, t, ["parentId", "nextId", "previousId"]), this.replaceIdOnNode(r.node, t);
              const a = this.crossOriginIframeRootIdMap.get(t);
              a && this.patchRootIdOnNode(r.node, a);
            }), e.data.removes.forEach((r) => {
              this.replaceIds(r, t, ["parentId", "id"]);
            }), e.data.attributes.forEach((r) => {
              this.replaceIds(r, t, ["id"]);
            }), e.data.texts.forEach((r) => {
              this.replaceIds(r, t, ["id"]);
            }), e;
          case F.Drag:
          case F.TouchMove:
          case F.MouseMove:
            return e.data.positions.forEach((r) => {
              this.replaceIds(r, t, ["id"]);
            }), e;
          case F.ViewportResize:
            return !1;
          case F.MediaInteraction:
          case F.MouseInteraction:
          case F.Scroll:
          case F.CanvasMutation:
          case F.Input:
            return this.replaceIds(e.data, t, ["id"]), e;
          case F.StyleSheetRule:
          case F.StyleDeclaration:
            return this.replaceIds(e.data, t, ["id"]), this.replaceStyleIds(e.data, t, ["styleId"]), e;
          case F.Font:
            return e;
          case F.Selection:
            return e.data.ranges.forEach((r) => {
              this.replaceIds(r, t, ["start", "end"]);
            }), e;
          case F.AdoptedStyleSheet:
            return this.replaceIds(e.data, t, ["id"]), this.replaceStyleIds(e.data, t, ["styleIds"]), (o = e.data.styles) === null || o === void 0 || o.forEach((r) => {
              this.replaceStyleIds(r, t, ["styleId"]);
            }), e;
        }
    }
  }
  replace(t, e, o, r) {
    for (const a of r)
      (Array.isArray(e[a]) || typeof e[a] == "number") && (Array.isArray(e[a]) ? e[a] = t.getIds(o, e[a]) : e[a] = t.getId(o, e[a]));
    return e;
  }
  replaceIds(t, e, o) {
    return this.replace(this.crossOriginIframeMirror, t, e, o);
  }
  replaceStyleIds(t, e, o) {
    return this.replace(this.crossOriginIframeStyleMirror, t, e, o);
  }
  replaceIdOnNode(t, e) {
    this.replaceIds(t, e, ["id", "rootId"]), "childNodes" in t && t.childNodes.forEach((o) => {
      this.replaceIdOnNode(o, e);
    });
  }
  patchRootIdOnNode(t, e) {
    t.type === Ke.Document || t.rootId || (t.rootId = e), "childNodes" in t && t.childNodes.forEach((o) => {
      this.patchRootIdOnNode(o, e);
    });
  }
}
class os {
  constructor(t) {
    this.shadowDoms = /* @__PURE__ */ new WeakSet(), this.restoreHandlers = [], this.mutationCb = t.mutationCb, this.scrollCb = t.scrollCb, this.bypassOptions = t.bypassOptions, this.mirror = t.mirror, this.init();
  }
  init() {
    this.reset(), this.patchAttachShadow(Element, document);
  }
  addShadowRoot(t, e) {
    if (!le(t) || this.shadowDoms.has(t))
      return;
    this.shadowDoms.add(t);
    const o = fe(Object.assign(Object.assign({}, this.bypassOptions), { doc: e, mutationCb: this.mutationCb, mirror: this.mirror, shadowDomManager: this }), t);
    this.restoreHandlers.push(() => o.disconnect()), this.restoreHandlers.push(Se(Object.assign(Object.assign({}, this.bypassOptions), { scrollCb: this.scrollCb, doc: t, mirror: this.mirror }))), setTimeout(() => {
      t.adoptedStyleSheets && t.adoptedStyleSheets.length > 0 && this.bypassOptions.stylesheetManager.adoptStyleSheets(t.adoptedStyleSheets, this.mirror.getId(t.host)), this.restoreHandlers.push(Ae({ mirror: this.mirror, stylesheetManager: this.bypassOptions.stylesheetManager }, t));
    }, 0);
  }
  observeAttachShadow(t) {
    t.contentWindow && t.contentDocument && this.patchAttachShadow(t.contentWindow.Element, t.contentDocument);
  }
  patchAttachShadow(t, e) {
    const o = this;
    this.restoreHandlers.push(ht(t.prototype, "attachShadow", function(r) {
      return function(a) {
        const u = r.call(this, a);
        return this.shadowRoot && ge(this) && o.addShadowRoot(this.shadowRoot, e), u;
      };
    }));
  }
  reset() {
    this.restoreHandlers.forEach((t) => {
      try {
        t();
      } catch (e) {
      }
    }), this.restoreHandlers = [], this.shadowDoms = /* @__PURE__ */ new WeakSet();
  }
}
const ee = /* @__PURE__ */ new Map(), be = (s, t, e) => {
  if (!s || !we(s, t) && typeof s != "object")
    return;
  const o = function(a, u) {
    let c = ee.get(a);
    return c || (c = /* @__PURE__ */ new Map(), ee.set(a, c)), c.has(u) || c.set(u, []), c.get(u);
  }(e, s.constructor.name);
  let r = o.indexOf(s);
  return r === -1 && (r = o.length, o.push(s)), r;
};
function ft(s, t, e) {
  if (s instanceof Array)
    return s.map((o) => ft(o, t, e));
  if (s === null)
    return s;
  if (s instanceof Float32Array || s instanceof Float64Array || s instanceof Int32Array || s instanceof Uint32Array || s instanceof Uint8Array || s instanceof Uint16Array || s instanceof Int16Array || s instanceof Int8Array || s instanceof Uint8ClampedArray)
    return { rr_type: s.constructor.name, args: [Object.values(s)] };
  if (s instanceof ArrayBuffer)
    return { rr_type: s.constructor.name, base64: Le(s) };
  if (s instanceof DataView)
    return { rr_type: s.constructor.name, args: [ft(s.buffer, t, e), s.byteOffset, s.byteLength] };
  if (s instanceof HTMLImageElement) {
    const o = s.constructor.name, { src: r } = s;
    return { rr_type: o, src: r };
  }
  return s instanceof HTMLCanvasElement ? { rr_type: "HTMLImageElement", src: s.toDataURL() } : s instanceof ImageData ? { rr_type: s.constructor.name, args: [ft(s.data, t, e), s.width, s.height] } : we(s, t) || typeof s == "object" ? { rr_type: s.constructor.name, index: be(s, t, e) } : s;
}
const ve = (s, t, e) => [...s].map((o) => ft(o, t, e)), we = (s, t) => !!["WebGLActiveInfo", "WebGLBuffer", "WebGLFramebuffer", "WebGLProgram", "WebGLRenderbuffer", "WebGLShader", "WebGLShaderPrecisionFormat", "WebGLTexture", "WebGLUniformLocation", "WebGLVertexArrayObject", "WebGLVertexArrayObjectOES"].filter((o) => typeof t[o] == "function").find((o) => s instanceof t[o]);
function se(s, t, e, o) {
  const r = [];
  try {
    const a = ht(s.HTMLCanvasElement.prototype, "getContext", function(u) {
      return function(c, ...n) {
        if (!Q(this, t, e, !0)) {
          const l = /* @__PURE__ */ function(g) {
            return g === "experimental-webgl" ? "webgl" : g;
          }(c);
          if ("__context" in this || (this.__context = l), o && ["webgl", "webgl2"].includes(l))
            if (n[0] && typeof n[0] == "object") {
              const g = n[0];
              g.preserveDrawingBuffer || (g.preserveDrawingBuffer = !0);
            } else
              n.splice(0, 1, { preserveDrawingBuffer: !0 });
        }
        return u.apply(this, [c, ...n]);
      };
    });
    r.push(a);
  } catch (a) {
    console.error("failed to patch HTMLCanvasElement.prototype.getContext");
  }
  return () => {
    r.forEach((a) => a());
  };
}
function oe(s, t, e, o, r, a, u) {
  const c = [], n = Object.getOwnPropertyNames(s);
  for (const l of n)
    if (!["isContextLost", "canvas", "drawingBufferWidth", "drawingBufferHeight"].includes(l))
      try {
        if (typeof s[l] != "function")
          continue;
        const g = ht(s, l, function(Z) {
          return function(...y) {
            const f = Z.apply(this, y);
            if (be(f, u, this), "tagName" in this.canvas && !Q(this.canvas, o, r, !0)) {
              const W = ve([...y], u, this), M = { type: t, property: l, args: W };
              e(this.canvas, M);
            }
            return f;
          };
        });
        c.push(g);
      } catch (g) {
        const Z = Dt(s, l, { set(y) {
          e(this.canvas, { type: t, property: l, args: [y], setter: !0 });
        } });
        c.push(Z);
      }
  return c;
}
function ns(s, t, e) {
  var o = t === void 0 ? null : t, r = function(n, l) {
    var g = atob(n);
    if (l) {
      for (var Z = new Uint8Array(g.length), y = 0, f = g.length; y < f; ++y)
        Z[y] = g.charCodeAt(y);
      return String.fromCharCode.apply(null, new Uint16Array(Z.buffer));
    }
    return g;
  }(s, e !== void 0 && e), a = r.indexOf(`
`, 10) + 1, u = r.substring(a) + (o ? "//# sourceMappingURL=" + o : ""), c = new Blob([u], { type: "application/javascript" });
  return URL.createObjectURL(c);
}
var ne, re, ae, Ft, rs = (ne = btoa(`(function () {
    \'use strict\';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED \"AS IS\" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator[\"throw\"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    /*
     * base64-arraybuffer 1.0.1 <https://github.com/niklasvh/base64-arraybuffer>
     * Copyright (c) 2021 Niklas von Hertzen <https://hertzen.com>
     * Released under MIT License
     */
    var chars = \'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/\';
    // Use a lookup table to find the index.
    var lookup = typeof Uint8Array === \'undefined\' ? [] : new Uint8Array(256);
    for (var i = 0; i < chars.length; i++) {
        lookup[chars.charCodeAt(i)] = i;
    }
    var encode = function (arraybuffer) {
        var bytes = new Uint8Array(arraybuffer), i, len = bytes.length, base64 = \'\';
        for (i = 0; i < len; i += 3) {
            base64 += chars[bytes[i] >> 2];
            base64 += chars[((bytes[i] & 3) << 4) | (bytes[i + 1] >> 4)];
            base64 += chars[((bytes[i + 1] & 15) << 2) | (bytes[i + 2] >> 6)];
            base64 += chars[bytes[i + 2] & 63];
        }
        if (len % 3 === 2) {
            base64 = base64.substring(0, base64.length - 1) + \'=\';
        }
        else if (len % 3 === 1) {
            base64 = base64.substring(0, base64.length - 2) + \'==\';
        }
        return base64;
    };

    const lastBlobMap = new Map();
    const transparentBlobMap = new Map();
    function getTransparentBlobFor(width, height, dataURLOptions) {
        return __awaiter(this, void 0, void 0, function* () {
            const id = \`\${width}-\${height}\`;
            if (\'OffscreenCanvas\' in globalThis) {
                if (transparentBlobMap.has(id))
                    return transparentBlobMap.get(id);
                const offscreen = new OffscreenCanvas(width, height);
                offscreen.getContext(\'2d\');
                const blob = yield offscreen.convertToBlob(dataURLOptions);
                const arrayBuffer = yield blob.arrayBuffer();
                const base64 = encode(arrayBuffer);
                transparentBlobMap.set(id, base64);
                return base64;
            }
            else {
                return \'\';
            }
        });
    }
    const worker = self;
    worker.onmessage = function (e) {
        return __awaiter(this, void 0, void 0, function* () {
            if (\'OffscreenCanvas\' in globalThis) {
                const { id, bitmap, width, height, dataURLOptions } = e.data;
                const transparentBase64 = getTransparentBlobFor(width, height, dataURLOptions);
                const offscreen = new OffscreenCanvas(width, height);
                const ctx = offscreen.getContext(\'2d\');
                ctx.drawImage(bitmap, 0, 0);
                bitmap.close();
                const blob = yield offscreen.convertToBlob(dataURLOptions);
                const type = blob.type;
                const arrayBuffer = yield blob.arrayBuffer();
                const base64 = encode(arrayBuffer);
                if (!lastBlobMap.has(id) && (yield transparentBase64) === base64) {
                    lastBlobMap.set(id, base64);
                    return worker.postMessage({ id });
                }
                if (lastBlobMap.get(id) === base64)
                    return worker.postMessage({ id });
                worker.postMessage({
                    id,
                    type,
                    base64,
                    width,
                    height,
                });
                lastBlobMap.set(id, base64);
            }
            else {
                return worker.postMessage({ id: e.data.id });
            }
        });
    };

})();

`), re = null, ae = !1, function(s) {
  return Ft = Ft || ns(ne, re, ae), new Worker(Ft, s);
});
class as {
  reset() {
    this.pendingCanvasMutations.clear(), this.resetObservers && this.resetObservers();
  }
  freeze() {
    this.frozen = !0;
  }
  unfreeze() {
    this.frozen = !1;
  }
  lock() {
    this.locked = !0;
  }
  unlock() {
    this.locked = !1;
  }
  constructor(t) {
    this.pendingCanvasMutations = /* @__PURE__ */ new Map(), this.rafStamps = { latestId: 0, invokeId: null }, this.frozen = !1, this.locked = !1, this.processMutation = (n, l) => {
      !(this.rafStamps.invokeId && this.rafStamps.latestId !== this.rafStamps.invokeId) && this.rafStamps.invokeId || (this.rafStamps.invokeId = this.rafStamps.latestId), this.pendingCanvasMutations.has(n) || this.pendingCanvasMutations.set(n, []), this.pendingCanvasMutations.get(n).push(l);
    };
    const { sampling: e = "all", win: o, blockClass: r, blockSelector: a, recordCanvas: u, dataURLOptions: c } = t;
    this.mutationCb = t.mutationCb, this.mirror = t.mirror, u && e === "all" && this.initCanvasMutationObserver(o, r, a), u && typeof e == "number" && this.initCanvasFPSObserver(e, o, r, a, { dataURLOptions: c });
  }
  initCanvasFPSObserver(t, e, o, r, a) {
    const u = se(e, o, r, !0), c = /* @__PURE__ */ new Map(), n = new rs();
    n.onmessage = (f) => {
      const { id: W } = f.data;
      if (c.set(W, !1), !("base64" in f.data))
        return;
      const { base64: M, type: h, width: d, height: m } = f.data;
      this.mutationCb({ id: W, type: lt["2D"], commands: [{ property: "clearRect", args: [0, 0, d, m] }, { property: "drawImage", args: [{ rr_type: "ImageBitmap", args: [{ rr_type: "Blob", data: [{ rr_type: "ArrayBuffer", base64: M }], type: h }] }, 0, 0] }] });
    };
    const l = 1e3 / t;
    let g, Z = 0;
    const y = (f) => {
      Z && f - Z < l || (Z = f, (() => {
        const W = [];
        return e.document.querySelectorAll("canvas").forEach((M) => {
          Q(M, o, r, !0) || W.push(M);
        }), W;
      })().forEach((W) => Ye(this, void 0, void 0, function* () {
        var M;
        const h = this.mirror.getId(W);
        if (c.get(h))
          return;
        if (c.set(h, !0), ["webgl", "webgl2"].includes(W.__context)) {
          const m = W.getContext(W.__context);
          ((M = m == null ? void 0 : m.getContextAttributes()) === null || M === void 0 ? void 0 : M.preserveDrawingBuffer) === !1 && m.clear(m.COLOR_BUFFER_BIT);
        }
        const d = yield createImageBitmap(W);
        n.postMessage({ id: h, bitmap: d, width: W.width, height: W.height, dataURLOptions: a.dataURLOptions }, [d]);
      }))), g = requestAnimationFrame(y);
    };
    g = requestAnimationFrame(y), this.resetObservers = () => {
      u(), cancelAnimationFrame(g);
    };
  }
  initCanvasMutationObserver(t, e, o) {
    this.startRAFTimestamping(), this.startPendingCanvasMutationFlusher();
    const r = se(t, e, o, !1), a = function(c, n, l, g) {
      const Z = [], y = Object.getOwnPropertyNames(n.CanvasRenderingContext2D.prototype);
      for (const f of y)
        try {
          if (typeof n.CanvasRenderingContext2D.prototype[f] != "function")
            continue;
          const W = ht(n.CanvasRenderingContext2D.prototype, f, function(M) {
            return function(...h) {
              return Q(this.canvas, l, g, !0) || setTimeout(() => {
                const d = ve([...h], n, this);
                c(this.canvas, { type: lt["2D"], property: f, args: d });
              }, 0), M.apply(this, h);
            };
          });
          Z.push(W);
        } catch (W) {
          const M = Dt(n.CanvasRenderingContext2D.prototype, f, { set(h) {
            c(this.canvas, { type: lt["2D"], property: f, args: [h], setter: !0 });
          } });
          Z.push(M);
        }
      return () => {
        Z.forEach((f) => f());
      };
    }(this.processMutation.bind(this), t, e, o), u = function(c, n, l, g, Z) {
      const y = [];
      return y.push(...oe(n.WebGLRenderingContext.prototype, lt.WebGL, c, l, g, 0, n)), n.WebGL2RenderingContext !== void 0 && y.push(...oe(n.WebGL2RenderingContext.prototype, lt.WebGL2, c, l, g, 0, n)), () => {
        y.forEach((f) => f());
      };
    }(this.processMutation.bind(this), t, e, o, this.mirror);
    this.resetObservers = () => {
      r(), a(), u();
    };
  }
  startPendingCanvasMutationFlusher() {
    requestAnimationFrame(() => this.flushPendingCanvasMutations());
  }
  startRAFTimestamping() {
    const t = (e) => {
      this.rafStamps.latestId = e, requestAnimationFrame(t);
    };
    requestAnimationFrame(t);
  }
  flushPendingCanvasMutations() {
    this.pendingCanvasMutations.forEach((t, e) => {
      const o = this.mirror.getId(e);
      this.flushPendingCanvasMutationFor(e, o);
    }), requestAnimationFrame(() => this.flushPendingCanvasMutations());
  }
  flushPendingCanvasMutationFor(t, e) {
    if (this.frozen || this.locked)
      return;
    const o = this.pendingCanvasMutations.get(t);
    if (!o || e === -1)
      return;
    const r = o.map((u) => Ue(u, ["type"])), { type: a } = o[0];
    this.mutationCb({ id: e, type: a, commands: r }), this.pendingCanvasMutations.delete(t);
  }
}
class is {
  constructor(t) {
    this.trackedLinkElements = /* @__PURE__ */ new WeakSet(), this.styleMirror = new Je(), this.mutationCb = t.mutationCb, this.adoptedStyleSheetCb = t.adoptedStyleSheetCb;
  }
  attachLinkElement(t, e) {
    "_cssText" in e.attributes && this.mutationCb({ adds: [], removes: [], texts: [], attributes: [{ id: e.id, attributes: e.attributes }] }), this.trackLinkElement(t);
  }
  trackLinkElement(t) {
    this.trackedLinkElements.has(t) || (this.trackedLinkElements.add(t), this.trackStylesheetInLinkElement(t));
  }
  adoptStyleSheets(t, e) {
    if (t.length === 0)
      return;
    const o = { id: e, styleIds: [] }, r = [];
    for (const a of t) {
      let u;
      if (this.styleMirror.has(a))
        u = this.styleMirror.getId(a);
      else {
        u = this.styleMirror.add(a);
        const c = Array.from(a.rules || CSSRule);
        r.push({ styleId: u, rules: c.map((n, l) => ({ rule: Qe(n), index: l })) });
      }
      o.styleIds.push(u);
    }
    r.length > 0 && (o.styles = r), this.adoptedStyleSheetCb(o);
  }
  reset() {
    this.styleMirror.reset(), this.trackedLinkElements = /* @__PURE__ */ new WeakSet();
  }
  trackStylesheetInLinkElement(t) {
  }
}
class ls {
  constructor() {
    this.nodeMap = /* @__PURE__ */ new WeakMap(), this.loop = !0, this.periodicallyClear();
  }
  periodicallyClear() {
    requestAnimationFrame(() => {
      this.clear(), this.loop && this.periodicallyClear();
    });
  }
  inOtherBuffer(t, e) {
    const o = this.nodeMap.get(t);
    return o && Array.from(o).some((r) => r !== e);
  }
  add(t, e) {
    this.nodeMap.set(t, (this.nodeMap.get(t) || /* @__PURE__ */ new Set()).add(e));
  }
  clear() {
    this.nodeMap = /* @__PURE__ */ new WeakMap();
  }
  destroy() {
    this.loop = !1;
  }
}
function L(s) {
  return Object.assign(Object.assign({}, s), { timestamp: Gt() });
}
let K, St, Tt, bt = !1;
const j = He();
function at(s = {}) {
  const { emit: t, checkoutEveryNms: e, checkoutEveryNth: o, blockClass: r = "rr-block", blockSelector: a = null, ignoreClass: u = "rr-ignore", ignoreSelector: c = null, maskTextClass: n = "rr-mask", maskTextSelector: l = null, inlineStylesheet: g = !0, maskAllInputs: Z, maskInputOptions: y, slimDOMOptions: f, maskInputFn: W, maskTextFn: M, hooks: h, packFn: d, sampling: m = {}, dataURLOptions: I = {}, mousemoveWait: B, recordCanvas: T = !1, recordCrossOriginIframes: w = !1, recordAfter: R = s.recordAfter === "DOMContentLoaded" ? s.recordAfter : "load", userTriggeredOnInput: C = !1, collectFonts: O = !1, inlineImages: S = !1, plugins: p, keepIframeSrcFn: v = () => !1, ignoreCSSAttributes: A = /* @__PURE__ */ new Set([]), errorHandler: i } = s;
  qe(i);
  const N = !w || window.parent === window;
  let U = !1;
  if (!N)
    try {
      window.parent.document && (U = !1);
    } catch (b) {
      U = !0;
    }
  if (N && !t)
    throw new Error("emit function is required");
  B !== void 0 && m.mousemove === void 0 && (m.mousemove = B), j.reset();
  const V = Z === !0 ? { color: !0, date: !0, "datetime-local": !0, email: !0, month: !0, number: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0, textarea: !0, select: !0, password: !0 } : y !== void 0 ? y : { password: !0 }, G = f === !0 || f === "all" ? { script: !0, comment: !0, headFavicon: !0, headWhitespace: !0, headMetaSocial: !0, headMetaRobots: !0, headMetaHttpEquiv: !0, headMetaVerification: !0, headMetaAuthorship: f === "all", headMetaDescKeywords: f === "all" } : f || {};
  let _;
  ze();
  let H = 0;
  const rt = (b) => {
    for (const P of p || [])
      P.eventProcessor && (b = P.eventProcessor(b));
    return d && !U && (b = d(b)), b;
  };
  K = (b, P) => {
    var x;
    if (!(!((x = nt[0]) === null || x === void 0) && x.isFrozen()) || b.type === E.FullSnapshot || b.type === E.IncrementalSnapshot && b.data.source === F.Mutation || nt.forEach((Y) => Y.unfreeze()), N)
      t == null || t(rt(b), P);
    else if (U) {
      const Y = { type: "rrweb", event: rt(b), origin: window.location.origin, isCheckout: P };
      window.parent.postMessage(Y, "*");
    }
    if (b.type === E.FullSnapshot)
      _ = b, H = 0;
    else if (b.type === E.IncrementalSnapshot) {
      if (b.data.source === F.Mutation && b.data.isAttachIframe)
        return;
      H++;
      const Y = o && H >= o, ot = e && b.timestamp - _.timestamp > e;
      (Y || ot) && St(!0);
    }
  };
  const q = (b) => {
    K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.Mutation }, b) }));
  }, $ = (b) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.Scroll }, b) })), it = (b) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.CanvasMutation }, b) })), X = new is({ mutationCb: q, adoptedStyleSheetCb: (b) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.AdoptedStyleSheet }, b) })) }), st = new ss({ mirror: j, mutationCb: q, stylesheetManager: X, recordCrossOriginIframes: w, wrappedEmit: K });
  for (const b of p || [])
    b.getMirror && b.getMirror({ nodeMirror: j, crossOriginIframeMirror: st.crossOriginIframeMirror, crossOriginIframeStyleMirror: st.crossOriginIframeStyleMirror });
  const kt = new ls();
  Tt = new as({ recordCanvas: T, mutationCb: it, win: window, blockClass: r, blockSelector: a, mirror: j, sampling: m.canvas, dataURLOptions: I });
  const ut = new os({ mutationCb: q, scrollCb: $, bypassOptions: { blockClass: r, blockSelector: a, maskTextClass: n, maskTextSelector: l, inlineStylesheet: g, maskInputOptions: V, dataURLOptions: I, maskTextFn: M, maskInputFn: W, recordCanvas: T, inlineImages: S, sampling: m, slimDOMOptions: G, iframeManager: st, stylesheetManager: X, canvasManager: Tt, keepIframeSrcFn: v, processedNodeManager: kt }, mirror: j });
  St = (b = !1) => {
    K(L({ type: E.Meta, data: { href: window.location.href, width: me(), height: Ie() } }), b), X.reset(), ut.init(), nt.forEach((x) => x.lock());
    const P = Xe(document, { mirror: j, blockClass: r, blockSelector: a, maskTextClass: n, maskTextSelector: l, inlineStylesheet: g, maskAllInputs: V, maskTextFn: M, slimDOM: G, dataURLOptions: I, recordCanvas: T, inlineImages: S, onSerialize: (x) => {
      he(x, j) && st.addIframe(x), ue(x, j) && X.trackLinkElement(x), Bt(x) && ut.addShadowRoot(x.shadowRoot, document);
    }, onIframeLoad: (x, Y) => {
      st.attachIframe(x, Y), ut.observeAttachShadow(x);
    }, onStylesheetLoad: (x, Y) => {
      X.attachLinkElement(x, Y);
    }, keepIframeSrcFn: v });
    if (!P)
      return console.warn("Failed to snapshot the document");
    K(L({ type: E.FullSnapshot, data: { node: P, initialOffset: pe(window) } }), b), nt.forEach((x) => x.unlock()), document.adoptedStyleSheets && document.adoptedStyleSheets.length > 0 && X.adoptStyleSheets(document.adoptedStyleSheets, j.getId(document));
  };
  try {
    const b = [], P = (Y) => {
      var ot;
      return k(es)({ mutationCb: q, mousemoveCb: (D, Mt) => K(L({ type: E.IncrementalSnapshot, data: { source: Mt, positions: D } })), mouseInteractionCb: (D) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.MouseInteraction }, D) })), scrollCb: $, viewportResizeCb: (D) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.ViewportResize }, D) })), inputCb: (D) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.Input }, D) })), mediaInteractionCb: (D) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.MediaInteraction }, D) })), styleSheetRuleCb: (D) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.StyleSheetRule }, D) })), styleDeclarationCb: (D) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.StyleDeclaration }, D) })), canvasMutationCb: it, fontCb: (D) => K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.Font }, D) })), selectionCb: (D) => {
        K(L({ type: E.IncrementalSnapshot, data: Object.assign({ source: F.Selection }, D) }));
      }, blockClass: r, ignoreClass: u, ignoreSelector: c, maskTextClass: n, maskTextSelector: l, maskInputOptions: V, inlineStylesheet: g, sampling: m, recordCanvas: T, inlineImages: S, userTriggeredOnInput: C, collectFonts: O, doc: Y, maskInputFn: W, maskTextFn: M, keepIframeSrcFn: v, blockSelector: a, slimDOMOptions: G, dataURLOptions: I, mirror: j, iframeManager: st, stylesheetManager: X, shadowDomManager: ut, processedNodeManager: kt, canvasManager: Tt, ignoreCSSAttributes: A, plugins: ((ot = p == null ? void 0 : p.filter((D) => D.observer)) === null || ot === void 0 ? void 0 : ot.map((D) => ({ observer: D.observer, options: D.options, callback: (Mt) => K(L({ type: E.Plugin, data: { plugin: D.name, payload: Mt } })) }))) || [] }, h);
    };
    st.addLoadListener((Y) => {
      try {
        b.push(P(Y.contentDocument));
      } catch (ot) {
        console.warn(ot);
      }
    });
    const x = () => {
      St(), b.push(P(document)), bt = !0;
    };
    return document.readyState === "interactive" || document.readyState === "complete" ? x() : (b.push(J("DOMContentLoaded", () => {
      K(L({ type: E.DomContentLoaded, data: {} })), R === "DOMContentLoaded" && x();
    })), b.push(J("load", () => {
      K(L({ type: E.Load, data: {} })), R === "load" && x();
    }, window))), () => {
      b.forEach((Y) => Y()), kt.destroy(), bt = !1, _e();
    };
  } catch (b) {
    console.warn(b);
  }
}
at.addCustomEvent = (s, t) => {
  if (!bt)
    throw new Error("please add custom event after start recording");
  K(L({ type: E.Custom, data: { tag: s, payload: t } }));
}, at.freezePage = () => {
  nt.forEach((s) => s.freeze());
}, at.takeFullSnapshot = (s) => {
  if (!bt)
    throw new Error("please take full snapshot after start recording");
  St(s);
}, at.mirror = j, xt("instrumentDom.js");
let At, vt = !0, Wt = !1, yt = { sampling: { input: "last" }, slimDOMOptions: !0, userTriggeredOnInput: !0, blockSelector: '[data-birdeatsbug="ignore"]' };
function wt() {
  var s;
  try {
    if (!vt)
      return;
    at.takeFullSnapshot();
  } catch (t) {
    if ((s = t.message) != null && s.startsWith("please take full snapshot after start recording"))
      return;
    throw t;
  }
}
function ie(s) {
  var t;
  if (typeof ((t = s == null ? void 0 : s.detail) == null ? void 0 : t.rrwebOptions) == "object" && (yt = pt(pt({}, yt), s.detail.rrwebOptions)), xt("enableDom()", yt), vt = !0, Wt)
    return wt();
  At = at(Ut(pt({}, yt), { emit(e) {
    var o;
    o = e, vt && document.dispatchEvent(new CustomEvent(Oe, { detail: o }));
  } })), Wt = !0, setTimeout(() => wt(), 100);
}
function Ot() {
  xt("disableDom()"), vt = !1, Wt = !1, At == null || At();
}
document.addEventListener(Yt, ie), document.addEventListener(Jt, Ot), document.addEventListener(Qt, wt), document.addEventListener(zt, function s() {
  document.removeEventListener(Yt, ie), document.removeEventListener(Jt, Ot), document.removeEventListener(Qt, wt), document.removeEventListener(zt, s), Ot();
}), document.dispatchEvent(new CustomEvent(Te));
