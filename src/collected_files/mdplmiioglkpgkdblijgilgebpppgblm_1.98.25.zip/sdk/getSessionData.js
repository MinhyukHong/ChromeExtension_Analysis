var K = Object.defineProperty, P = Object.defineProperties;
var W = Object.getOwnPropertyDescriptors;
var C = Object.getOwnPropertySymbols;
var Y = Object.prototype.hasOwnProperty, $ = Object.prototype.propertyIsEnumerable;
var F = (t, n, r) => n in t ? K(t, n, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[n] = r, v = (t, n) => {
  for (var r in n || (n = {}))
    Y.call(n, r) && F(t, r, n[r]);
  if (C)
    for (var r of C(n))
      $.call(n, r) && F(t, r, n[r]);
  return t;
}, S = (t, n) => P(t, W(n));
var T = (t, n, r) => new Promise((p, d) => {
  var c = (l) => {
    try {
      g(r.next(l));
    } catch (f) {
      d(f);
    }
  }, u = (l) => {
    try {
      g(r.throw(l));
    } catch (f) {
      d(f);
    }
  }, g = (l) => l.done ? p(l.value) : Promise.resolve(l.value).then(c, u);
  g((r = r.apply(t, n)).next());
});
import { i as I } from "./core.js";
function z(t = []) {
  let n = [];
  return t.forEach((r) => {
    const p = function(d) {
      if (k(d))
        return function(c) {
          return v({ type: "networkBlocked" }, q(c));
        }(d);
      if (B(d) || U(d) || _(d) || function(c) {
        return !!(c.error && !_(c) && !k(c) && !B(c) && !U(c));
      }(d))
        return h(d);
    }(r);
    p && n.push(p);
  }), n;
}
function _(t) {
  return t.statusCode >= 400 && t.statusCode < 600;
}
function k(t) {
  return t.error === "net::ERR_BLOCKED_BY_CLIENT";
}
function B(t) {
  return t.error === "net::ERR_CACHE_MISS";
}
function U(t) {
  return t.error === "net::ERR_ABORTED";
}
function h(t) {
  return v({ type: "network" }, q(t));
}
function q(t) {
  return { requestId: t.id || t.requestId, method: t.method, url: t.url, createdAt: t.endedAt, error: t.error, statusCode: t.statusCode };
}
function L(t, n) {
  if (!n)
    return !1;
  const r = n.createdAt || n.startedAt || n.endedAt;
  return !(t.startedAt && r < t.startedAt) && !(t.endedAt && r > t.endedAt);
}
function N(t, n) {
  return n.forEach((r) => delete t[r]), t;
}
function V() {
  return T(this, null, function* () {
    var D, R, O;
    if (!window.birdeatsbug.session)
      return {};
    const t = v({}, window.birdeatsbug.session), [{ value: n }, { value: r }, { value: p }, { value: d }, { value: c }, { value: u }] = yield Promise.allSettled([I.getAllFromIndex("consoleEvents", "sessionId", t.id), I.getAllFromIndex("domEvents", "sessionId", t.id), I.getAllFromIndex("navigationEvents", "sessionId", t.id), I.getAllFromIndex("networkEventsFromInstrumentation", "sessionId", t.id), I.getAllFromIndex("screenshotEvents", "sessionId", t.id), I.getAllFromIndex("videoEvents", "sessionId", t.id)]), g = function(e, s = 120) {
      if (!(e != null && e.length))
        return [];
      const i = e[e.length - 1].timestamp;
      let o;
      for (let a = e.length - 1; a >= 0; a--) {
        if (e[a].type !== 4)
          continue;
        const A = (i - e[a].timestamp) / 1e3;
        if (A >= s)
          return o ? Math.abs(s - A) < Math.abs(s - o.timeDifference) ? e.slice(a) : e.slice(o.index) : e.slice(a);
        o = { index: a, timeDifference: A };
      }
      return o ? e.slice(o.index) : [];
    }(r.reduce((e, s) => [...e, ...s.events], []), t.isInstantReplay ? 120 : 3600);
    let l;
    (D = g[0]) != null && D.timestamp && (t.startedAt = new Date(g[0].timestamp).toISOString());
    let f = {}, w = [];
    if (u.length) {
      const e = u[0].events[0].type;
      e.split(";"), f.videoMimeType = e, f.videoWidth = (R = u[0].metadata) == null ? void 0 : R.width, f.videoHeight = (O = u[0].metadata) == null ? void 0 : O.height;
      const s = new Date(u[0].createdAt);
      s.setSeconds(s.getSeconds() - 1), f.videoDuration = new Date(u[u.length - 1].createdAt) - s;
      const i = new Date(u[u.length - 1].createdAt);
      w = [{ type: "videoStart", subType: "video", action: "start", createdAt: s.toISOString() }, { type: "videoStop", subType: "video", action: "stop", createdAt: i.toISOString() }], t.startedAt = s.toISOString(), i > new Date(t.endedAt) && (t.endedAt = i.toISOString());
      let o = new Blob(u.map((A) => A.events[0]), { type: e });
      const a = (yield import("./makeVideoBlobSeekable.js")).default;
      o = yield a(o, f.videoDuration), l = URL.createObjectURL(o);
    }
    const y = c[0], J = y && !(n != null && n.length) ? [] : function(e) {
      const s = [];
      if (e.startedAt && !e.isInstantReplay) {
        const i = new Date(e.startedAt);
        i.setMilliseconds(i.getMilliseconds() - 1), s.push({ source: "bird", type: "start", createdAt: i.toISOString(), sessionId: e.id, url: e.startUrl });
      }
      if (e.endedAt) {
        const i = new Date(e.endedAt);
        i.setMilliseconds(i.getMilliseconds() + 1), s.push({ source: "bird", type: "end", createdAt: i.toISOString(), sessionId: e.id, url: e.endUrl, isInstantReplay: e.isInstantReplay && !document.location.href.includes("mediaType=Screenshot") });
      }
      return s;
    }(t), E = [], H = [...w, ...n, ...p, ...z(d)];
    for (const e of H)
      L(t, e) && E.push(N(e, ["id", "sessionId"]));
    const j = function(e) {
      if (!Array.isArray(e) || e.length === 0)
        return [];
      const s = [];
      let i = -1;
      return e.forEach((o) => {
        var x, M;
        const [a, A] = ((x = o.createdAt) == null ? void 0 : x.split(".")) || [];
        delete o.id;
        const m = JSON.stringify(S(v({}, o), { createdAt: a }));
        ((M = s[i]) == null ? void 0 : M.stringifiedEvent) === m ? s[i].count++ : (s.push({ stringifiedEvent: m, count: 1, ms: A }), i++);
      }), s.map(({ count: o, ms: a, stringifiedEvent: A }) => {
        const m = JSON.parse(A);
        return m.createdAt && a && (m.createdAt += `.${a}`), S(v({}, m), { count: o });
      });
    }(function(e = [], s) {
      return [...e].sort((i, o) => i[s] > o[s] ? 1 : i[s] < o[s] ? -1 : 0);
    }([...J, ...E], "createdAt")), b = [];
    for (const e of d)
      L(t, e) && b.push(N(e, ["sessionId"]));
    return window.birdeatsbug.session = t, sessionStorage && (sessionStorage.birdeatsbugSession = JSON.stringify(t)), { session: t, events: j, domEvents: g, networkRequests: b, screenshot: y, videoDataUrl: l, videoMetadata: f };
  });
}
export {
  V as default
};
