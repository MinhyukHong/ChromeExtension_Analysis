var d = (n, i, e) => new Promise((s, m) => {
  var w = (t) => {
    try {
      a(e.next(t));
    } catch (c) {
      m(c);
    }
  }, b = (t) => {
    try {
      a(e.throw(t));
    } catch (c) {
      m(c);
    }
  }, a = (t) => t.done ? s(t.value) : Promise.resolve(t.value).then(w, b);
  a((e = e.apply(n, i)).next());
});
import "./instrumentDom.js";
import { B as r, a as v, i as f, b as h, c as y } from "./core.js";
let o, u;
function l() {
  const n = window.birdeatsbug.options.recordedEventTypes.dom;
  document.dispatchEvent(new CustomEvent(h, { detail: { rrwebOptions: n } })), document.addEventListener("visibilitychange", p), document.addEventListener(r, E), clearTimeout(u), clearTimeout(o), o = setInterval(g, 25e3);
}
function T() {
  document.removeEventListener(r, E), document.removeEventListener("visibilitychange", p), document.dispatchEvent(new CustomEvent(v)), clearTimeout(u), clearTimeout(o);
}
function g() {
  document.dispatchEvent(new CustomEvent(y));
}
function p() {
  return d(this, null, function* () {
    document.visibilityState === "hidden" ? u = setTimeout(() => {
      document.dispatchEvent(new CustomEvent(v)), clearTimeout(o);
    }, 12e4) : document.visibilityState === "visible" && l();
  });
}
function E(n) {
  (function(i) {
    return d(this, null, function* () {
      var s;
      const e = (s = window.birdeatsbug.session) == null ? void 0 : s.id;
      if (!e)
        return console.warn("DOM event captured without active session");
      yield f.add("domEvents", { events: [i.detail], createdAt: i.detail.timestamp, sessionId: e });
    });
  })(n);
}
const O = { start: l, stop: T };
export {
  O as default,
  T as stop
};
