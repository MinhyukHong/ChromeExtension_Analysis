var r = (t, o, i) => new Promise((n, v) => {
  var l = (a) => {
    try {
      d(i.next(a));
    } catch (c) {
      v(c);
    }
  }, h = (a) => {
    try {
      d(i.throw(a));
    } catch (c) {
      v(c);
    }
  }, d = (a) => a.done ? n(a.value) : Promise.resolve(a.value).then(l, h);
  d((i = i.apply(t, o)).next());
});
import "./instrumentDom.js";
import { n as u, i as b } from "./core.js";
let s, e, p;
function w() {
  (e == null ? void 0 : e.state) === "recording" && e.requestData();
}
function f() {
  window.birdeatsbug.stopSession();
}
function m() {
  return r(this, null, function* () {
    document.removeEventListener(u, w), e && (e.removeEventListener("dataavailable", g), e.removeEventListener("stop", m)), s && s.getTracks().forEach((t) => {
      t.removeEventListener("ended", f), t.stop();
    });
  });
}
function g(t) {
  return r(this, null, function* () {
    var i;
    const o = (i = window.birdeatsbug.session) == null ? void 0 : i.id;
    if (!o)
      return console.warn("video event captured without active session");
    t.data.size && (yield b.add("videoEvents", { events: [t.data], createdAt: (/* @__PURE__ */ new Date()).toISOString(), sessionId: o, metadata: p }));
  });
}
const L = { start: function() {
  return r(this, null, function* () {
    try {
      document.addEventListener(u, w), s = yield navigator.mediaDevices.getDisplayMedia({ preferCurrentTab: !0, selfBrowserSurface: "include", surfaceSwitching: "include", video: { displaySurface: "browser" }, audio: !1 });
      const t = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/mp4", "video/webm"].find((n) => MediaRecorder == null ? void 0 : MediaRecorder.isTypeSupported(n));
      e = new MediaRecorder(s, t ? { mimeType: t } : {}), e.ondataavailable = g, e.onstop = m, e.start(), s.getTracks().forEach((n) => n.addEventListener("ended", f));
      const { height: o, width: i } = s.getVideoTracks()[0].getSettings();
      p = { height: o, width: i };
    } catch (t) {
      throw console.error(t), t;
    }
  });
}, stop: function() {
  (e == null ? void 0 : e.state) !== "inactive" && (e == null || e.stop());
} };
export {
  L as default
};
