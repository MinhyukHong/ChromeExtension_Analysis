import { n as g } from "./core.js";
import { _ as p } from "./_plugin-vue_export-helper.js";
import { c as h, b as a, t as m, o as S } from "./runtime-core.esm-bundler.js";
function b(e) {
  let o = (e = parseInt(e)) > -1e3 ? "" : "-";
  const { hours: n, minutes: s, seconds: i } = function(t) {
    t = Math.abs(t);
    const r = Math.floor(t / 1e3 / 60 / 60 / 24);
    t -= 1e3 * r * 60 * 60 * 24;
    const d = Math.floor(t / 1e3 / 60 / 60);
    t -= 1e3 * d * 60 * 60;
    const c = Math.floor(t / 1e3 / 60);
    t -= 1e3 * c * 60;
    const u = Math.floor(t / 1e3);
    t -= 1e3 * u;
    const l = Math.floor(t);
    return { days: r, hours: d, minutes: c, seconds: u, milliseconds: l };
  }(e);
  return n > 0 && (o += n + ":"), o += (n > 0 ? String(s).padStart(2, "0") : s) + ":", o += String(i).padStart(2, "0"), o;
}
const x = { name: "RecordingControls", data: () => {
  var e;
  return { isAlreadyRecording: (sessionStorage == null ? void 0 : sessionStorage.birdeatsbugIsRecording) === "true", text: (e = window.birdeatsbug.options.ui.text) == null ? void 0 : e.recordingControls, recordingStatusText: "" };
}, computed: { buttonStopText() {
  var e;
  return ((e = this.text) == null ? void 0 : e.stopRecordingButton) || "Stop recording";
} }, mounted() {
  this.setInitialRecordingStatusText(), document.addEventListener(g, this.updateRecordingTime);
}, beforeUnmount() {
  document.removeEventListener(g, this.updateRecordingTime);
}, methods: { setInitialRecordingStatusText() {
  var e, o;
  this.isAlreadyRecording ? this.recordingStatusText = ((e = this.text) == null ? void 0 : e.recording) || "Recording..." : this.recordingStatusText = ((o = this.text) == null ? void 0 : o.starting) || "Starting...";
}, updateRecordingTime(e) {
  var o;
  this.recordingStatusText = `${((o = this.text) == null ? void 0 : o.recordingProgress) || "Recording for"} ${b(e.detail.time)}`;
}, onStopClick() {
  window.birdeatsbug.stopSession();
} } }, f = { class: "recording-controls" }, T = ["title", "aria-label"], R = { class: "recording-status" }, C = a("span", { class: "icon-stop", "aria-hidden": "" }, null, -1), w = p(x, [["render", function(e, o, n, s, i, t) {
  return S(), h("div", f, [a("button", { title: t.buttonStopText, "aria-label": t.buttonStopText, class: "button button-stop-recording", onClick: o[0] || (o[0] = (...r) => t.onStopClick && t.onStopClick(...r)) }, [a("span", R, m(i.recordingStatusText), 1), C], 8, T)]);
}]]);
export {
  w as default
};
