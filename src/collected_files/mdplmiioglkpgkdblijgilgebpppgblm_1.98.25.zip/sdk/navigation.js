var d = (s, i, o) => new Promise((t, n) => {
  var r = (e) => {
    try {
      c(o.next(e));
    } catch (p) {
      n(p);
    }
  }, w = (e) => {
    try {
      c(o.throw(e));
    } catch (p) {
      n(p);
    }
  }, c = (e) => e.done ? t(e.value) : Promise.resolve(e.value).then(r, w);
  c((o = o.apply(s, i)).next());
});
import { i as h } from "./core.js";
let g, u = !1, l = !1;
function f() {
  u = !1;
}
function a(s, ...i) {
  return d(this, null, function* () {
    var r;
    if (!u)
      return;
    const o = document.location.href;
    if (g === o)
      return;
    g = o, sessionStorage;
    const t = (r = window.birdeatsbug.session) == null ? void 0 : r.id, n = { type: "step", subType: "navigation", createdAt: (/* @__PURE__ */ new Date()).toISOString(), sessionId: t };
    if ((sessionStorage == null ? void 0 : sessionStorage.birdeatsbugLastUrl) === o ? (n.action = "reload", n.url = o) : (n.action = "navigate", n.newUrl = o, n.oldUrl = sessionStorage == null ? void 0 : sessionStorage.birdeatsbugLastUrl), sessionStorage && (sessionStorage.birdeatsbugLastUrl = o), !t)
      return console.warn("navigation event captured without active session");
    yield h.add("navigationEvents", n);
  });
}
const b = { start: function() {
  if (u = !0, l)
    return;
  const s = typeof window.onpopstate == "function" && window.onpopstate;
  window.onpopstate = function(...t) {
    s && s.apply(window, ...t), a("onpopstate", ...t);
  };
  const i = history.pushState;
  history.pushState = function(...t) {
    i.apply(history, t), a("onPushState", ...t);
  };
  const o = history.replaceState;
  history.replaceState = function(...t) {
    o.apply(history, t), a("onReplaceState", ...t);
  }, window.addEventListener("hashchange", (...t) => a("onHashChange", ...t)), (sessionStorage == null ? void 0 : sessionStorage.birdeatsbugIsRecording) === "true" && a("navigation.start while recording"), l = !0;
}, stop: f };
export {
  b as default,
  f as stop
};
