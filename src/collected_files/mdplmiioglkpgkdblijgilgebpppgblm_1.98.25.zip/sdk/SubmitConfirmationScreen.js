var b = (t, n, s) => new Promise((p, k) => {
  var o = (i) => {
    try {
      r(s.next(i));
    } catch (e) {
      k(e);
    }
  }, l = (i) => {
    try {
      r(s.throw(i));
    } catch (e) {
      k(e);
    }
  }, r = (i) => i.done ? p(i.value) : Promise.resolve(i.value).then(o, l);
  r((s = s.apply(t, n)).next());
});
import { H as y, W as L } from "./Watermark.js";
import { _ as S } from "./_plugin-vue_export-helper.js";
import { r as C, c as u, a as f, w, b as d, t as a, F as h, d as m, e as T, o as c } from "./runtime-core.esm-bundler.js";
const g = { class: "screen submit-confirmation-screen" }, x = { class: "footer" }, B = S({ name: "SubmitConfirmationScreen", components: { Header: y, Watermark: L }, inject: ["session"], data: () => {
  var t, n;
  return { text: (t = window.birdeatsbug.options.ui.text) == null ? void 0 : t.submitConfirmationScreen, showSessionLink: (n = window.birdeatsbug.options.ui.submitConfirmationScreen) == null ? void 0 : n.sessionLink, hasCopiedSessionLink: !1 };
}, computed: { titleText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.title) || "Bug report submitted";
}, confirmationText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.message) || "Thank you for reporting this issue. A member of our team will investigate and get back to you soon.";
}, buttonCopySessionLinkText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.copyLink) || "Copy link to your bug report";
}, buttonSessionLinkCopiedText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.copiedLink) || "Link copied!";
}, buttonCloseText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.confirmationButton) || "Close";
} }, methods: { onCopySessionLinkClick() {
  return b(this, null, function* () {
    var t;
    yield (t = navigator.clipboard) == null ? void 0 : t.writeText(this.session.link), this.hasCopiedSessionLink = !0;
  });
}, onDoneClick() {
  window.birdeatsbug.ui.close();
} } }, [["render", function(t, n, s, p, k, o) {
  var i;
  const l = C("Header"), r = C("Watermark");
  return c(), u("div", g, [f(l, null, { default: w(() => [m(a(o.titleText), 1)]), _: 1 }), d("p", null, a(o.confirmationText), 1), t.showSessionLink && ((i = o.session) != null && i.id) ? (c(), u("button", { key: 0, class: "button button-copy-session-link", onClick: n[0] || (n[0] = (...e) => o.onCopySessionLinkClick && o.onCopySessionLinkClick(...e)) }, [t.hasCopiedSessionLink ? (c(), u(h, { key: 0 }, [m(" ✓ " + a(o.buttonSessionLinkCopiedText), 1)], 64)) : (c(), u(h, { key: 1 }, [m(a(o.buttonCopySessionLinkText), 1)], 64))])) : T("", !0), d("div", x, [f(r), d("button", { class: "button button-primary", onClick: n[1] || (n[1] = (...e) => o.onDoneClick && o.onDoneClick(...e)) }, a(o.buttonCloseText), 1)])]);
}]]);
export {
  B as default
};
