const m = { type: "Arithmetic", shouldTransform: (e, t) => e === "number" && (t === 1 / 0 || t === -1 / 0 || function(r) {
  return 1 / r == -1 / 0;
}(t)), toSerializable: (e) => e === 1 / 0 ? 0 : e === -1 / 0 ? 1 : 2 }, y = { type: "Function", shouldTransform: (e, t) => typeof t == "function", toSerializable: (e) => ({ name: e.name, proto: Object.getPrototypeOf(e).constructor.name }) };
function b(e) {
  const t = {};
  for (let r of e.attributes)
    t[r.name] = r.value;
  return e.tagName.toLowerCase() === "input" && t.value && (t.type === "password" || ["current-password", "new-password", "one-time-code", "cc-number", "cc-csc", "cc-exp"].includes(t.autocomplete)) && (t.value = t.value.replace(/./g, "*")), t;
}
const _ = { type: "HTMLElement", shouldTransform: (e, t) => t && t.children && typeof t.innerHTML == "string" && typeof t.tagName == "string", toSerializable: (e) => ({ tagName: e.tagName.toLowerCase(), attributes: b(e), innerText: ((e == null ? void 0 : e.innerText) || "").substring(0, 100), version: "1.0.0" }) }, $ = /^#*@(t|r)$/, g = window, T = typeof ArrayBuffer == "function", O = typeof Map == "function", j = typeof Set == "function", k = new Set(["Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Uint16Array", "Int32Array", "Uint32Array", "Float32Array", "Float64Array"].filter((e) => typeof g[e] == "function")), f = Array.prototype.slice, z = { serialize: (e) => JSON.stringify(e), deserialize: (e) => JSON.parse(e) };
class p {
  constructor(t, r) {
    this.references = t, this.transforms = r, this.circularCandidates = /* @__PURE__ */ new Map(), this.circularRefCount = 0, this.breadthFirstQueue = [];
  }
  static _createRefMark(t) {
    const r = /* @__PURE__ */ Object.create(null);
    return r["@r"] = t, r;
  }
  _createCircularCandidate(t, r, s) {
    this.circularCandidates.set(t, { parent: r, key: s, refIdx: -1 });
  }
  _applyTransform(t, r, s, a) {
    const n = /* @__PURE__ */ Object.create(null), o = a.toSerializable(t);
    return typeof o == "object" && this._createCircularCandidate(t, r, s), n["@t"] = a.type, n.data = this._handleValue(o, r, s), n;
  }
  _handleArray(t) {
    const r = [];
    for (let s = 0; s < t.length; s++)
      this.breadthFirstQueue.push({ val: t[s], parent: r, key: s });
    return r;
  }
  _handlePlainObject(t) {
    const r = /* @__PURE__ */ Object.create(null);
    for (const a of Object.keys(t)) {
      const n = $.test(a) ? `#${a}` : a;
      this.breadthFirstQueue.push({ val: t[a], parent: r, key: n });
    }
    const { name: s } = t.__proto__.constructor;
    return s !== "Object" && (r.constructor = { name: s }), r;
  }
  _handleObject(t, r, s) {
    return this._createCircularCandidate(t, r, s), Array.isArray(t) ? this._handleArray(t) : this._handlePlainObject(t);
  }
  _ensureCircularReference(t) {
    const r = this.circularCandidates.get(t);
    return r ? (r.refIdx === -1 && (r.refIdx = r.parent ? ++this.circularRefCount : 0), p._createRefMark(r.refIdx)) : null;
  }
  _handleValue(t, r, s) {
    const a = typeof t, n = a === "object" && t !== null;
    try {
      if (n) {
        const o = this._ensureCircularReference(t);
        if (o)
          return o;
      }
      for (const o of this.transforms)
        if (o.shouldTransform(a, t))
          return this._applyTransform(t, r, s, o);
      return n ? this._handleObject(t, r, s) : t;
    } catch (o) {
      return null;
    }
  }
  transform() {
    const t = this._handleValue(this.references, null, null);
    let r = 0;
    for (; this.breadthFirstQueue.length > 0; ) {
      const a = this.breadthFirstQueue;
      this.breadthFirstQueue = [];
      for (const { val: n, parent: o, key: c } of a)
        r += 1, o[c] = r > 1e4 ? "Depth Limit Exceeded" : this._handleValue(n, o, c);
    }
    const s = [t];
    for (const a of this.circularCandidates.values())
      a.refIdx > 0 && (s[a.refIdx] = a.parent[a.key], a.parent[a.key] = p._createRefMark(a.refIdx));
    return s;
  }
}
const A = [{ type: "[[NaN]]", shouldTransform: (e, t) => e === "number" && isNaN(t), toSerializable: () => "" }, { type: "[[undefined]]", shouldTransform: (e) => e === "undefined", toSerializable: () => "" }, { type: "[[Date]]", shouldTransform: (e, t) => t instanceof Date, toSerializable: (e) => e.getTime() }, { type: "[[RegExp]]", shouldTransform: (e, t) => t instanceof RegExp, toSerializable(e) {
  const t = { src: e.source, flags: "" };
  return e.global && (t.flags += "g"), e.ignoreCase && (t.flags += "i"), e.multiline && (t.flags += "m"), t;
} }, { type: "[[Error]]", shouldTransform: (e, t) => t instanceof Error, toSerializable: (e) => ({ name: e.name, message: e.message, stack: e.stack }) }, { type: "[[ArrayBuffer]]", shouldTransform: (e, t) => T && t instanceof ArrayBuffer, toSerializable(e) {
  const t = new Int8Array(e);
  return f.call(t);
} }, { type: "[[TypedArray]]", shouldTransform: (e, t) => {
  var r;
  return k.has((r = t == null ? void 0 : t.constructor) == null ? void 0 : r.name);
}, toSerializable: (e) => ({ ctorName: e.constructor.name, arr: f.call(e) }) }, { type: "[[Map]]", shouldTransform: (e, t) => O && t instanceof Map, toSerializable(e) {
  const t = [];
  return e.forEach((r, s) => {
    t.push(s), t.push(r);
  }), t;
} }, { type: "[[Set]]", shouldTransform: (e, t) => j && t instanceof Set, toSerializable(e) {
  const t = [];
  return e.forEach((r) => {
    t.push(r);
  }), t;
} }], S = typeof Symbol == "function";
function d(e, { api: t }) {
  return t === "options" ? function(r) {
    var a, n;
    const s = {};
    if ((a = r.$options) != null && a.name && (s.name = r.$options.name), r.$attrs && Object.keys(r.$attrs).length > 0 && (s.$attrs = r.$attrs, delete s.$attrs.__vInternal), r.$props && Object.keys(r.$props).length > 0 && (s.props = r.$props), r.$data && (s.data = r.$data), (n = r.$options) == null ? void 0 : n.computed) {
      const o = Object.keys(r.$options.computed);
      o.length > 0 && (s.computed = {}, o.forEach((c) => {
        s.computed[c] = r[c];
      }));
    }
    return s;
  }(e) : function(r) {
    var u;
    const s = {};
    (u = r.$options) != null && u.name && (s.name = r.$options.name), r.$attrs && Object.keys(r.$attrs).length > 0 && (s.$attrs = r.$attrs, delete s.$attrs.__vInternal), r.$props && Object.keys(r.$props).length > 0 && (s.props = r.$props);
    const a = r.$options.setup(s.props, { attrs: s.attrs, expose: {}, slots: {}, emit: () => {
    } });
    if (!a)
      return s;
    const n = Object.keys(a).filter((i) => typeof a[i] != "function" && !("__v_isRef" in a[i])).reduce((i, l) => (i[l] = r[l], i), {});
    Object.keys(n).length > 0 && (s.reactive = n);
    const o = Object.keys(a).filter((i) => a[i].__v_isRef && !a[i].__v_isReadonly).reduce((i, l) => (i[l] = r[l], i), {});
    Object.keys(o).length > 0 && (s.ref = o);
    const c = Object.keys(a).filter((i) => a[i].__v_isRef && a[i].__v_isReadonly).reduce((i, l) => (i[l] = r[l], i), {});
    return Object.keys(c).length > 0 && (s.computed = c), s;
  }(e);
}
const v = [m, y, _, { type: "Symbol", shouldTransform: (e) => e === "symbol", toSerializable: (e) => ({ name: S ? e.description : "Symbol not supported" }) }, { type: "[[Vue]]", shouldTransform: (e, t) => {
  var r;
  return !!(t != null && t._isVue || t != null && t.__isVue || (r = t == null ? void 0 : t.proxy) != null && r.__isVue);
}, toSerializable: (e) => e._isVue ? function(t) {
  var s, a;
  const r = {};
  if ((s = t.$options) != null && s.name && (r.name = t.$options.name), (a = t.$options) != null && a._serializableTag && (r.serializableTag = t.$options._serializableTag), t.$attrs && Object.keys(t.$attrs).length > 0 && (r.$attrs = t.$attrs), t._props && (r.props = t._props), t._data && (r.data = t._data), t._computedWatchers) {
    const n = Object.keys(t._computedWatchers);
    n.length > 0 && (r.computed = {}, n.forEach((o) => {
      r.computed[o] = t._computedWatchers[o].value;
    }));
  }
  return r;
}(e) : e.__isVue ? d(e, { api: "options" }) : d(e.proxy, { api: "composition" }) }, { type: "[[React]]", shouldTransform: (e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.$$typeof) == null ? void 0 : r.description) === "react.element";
}, toSerializable(e) {
  var r, s;
  const t = {};
  return typeof e.type == "function" ? t.name = e.type.name : typeof e.type == "symbol" ? t.name = function(a = "") {
    return a.split(/(\.|_)/).map((n) => n[0].toUpperCase() + n.slice(1)).join("").replaceAll(/_/g, "");
  }(e.type.description) : ((s = (r = e == null ? void 0 : e.type) == null ? void 0 : r.$$typeof) == null ? void 0 : s.description) === "react.memo" && (t.name = `React.memo(${e.type.type.name})`), e.props && Object.keys(e.props).length > 0 && (t.props = e.props), t;
} }], h = new class {
  constructor(e) {
    this.transforms = [], this.transformsMap = /* @__PURE__ */ Object.create(null), this.serializer = e || z, this.addTransforms(A);
  }
  addTransforms(e) {
    e = Array.isArray(e) ? e : [e];
    for (const t of e) {
      if (this.transformsMap[t.type])
        throw new Error(`Transform with type "${t.type}" was already added.`);
      this.transforms.push(t), this.transformsMap[t.type] = t;
    }
    return this;
  }
  removeTransforms(e) {
    e = Array.isArray(e) ? e : [e];
    for (const t of e) {
      const r = this.transforms.indexOf(t);
      r > -1 && this.transforms.splice(r, 1), delete this.transformsMap[t.type];
    }
    return this;
  }
  encode(e) {
    const t = new p(e, this.transforms).transform();
    return this.serializer.serialize(t);
  }
}({ serialize: (e) => e });
function C(e) {
  return { version: "1.0.0", serialized: (t = e, h.encode(t)) };
  var t;
}
h.addTransforms(v);
export {
  C as b
};
