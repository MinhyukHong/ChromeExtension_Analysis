var w = (c, n, e) => new Promise((l, u) => {
  var s = (o) => {
    try {
      i(e.next(o));
    } catch (a) {
      u(a);
    }
  }, t = (o) => {
    try {
      i(e.throw(o));
    } catch (a) {
      u(a);
    }
  }, i = (o) => o.done ? l(o.value) : Promise.resolve(o.value).then(s, t);
  i((e = e.apply(c, n)).next());
});
function p(c) {
  return w(this, null, function* () {
    if (!window.zE)
      return;
    const n = c.session;
    let e = `Hey, I just reported an issue, here is the link: ${n.link}. `;
    n.title && (e += `It is about "${n.title}". `), n.description && (e += `More details: "${n.description}".`);
    try {
      return window.zE("webWidget", "open"), void window.zE("webWidget", "chat:send", e);
    } catch (u) {
      let s, t;
      for (window.zE("messenger", "open"); !s; )
        yield new Promise((r) => setTimeout(r, 50)), s = document.querySelector("iframe[title='Messaging window']");
      for (; !t; )
        yield new Promise((r) => setTimeout(r, 50)), t = s.contentDocument.querySelector('textarea[data-garden-id="forms.textarea"][placeholder="Type a message"]');
      t.focus(), yield new Promise((r) => setTimeout(r, 1500));
      const i = Object.getOwnPropertyDescriptor(t, "value").set, o = Object.getPrototypeOf(t), a = Object.getOwnPropertyDescriptor(o, "value").set;
      i && i !== a ? a.call(t, e) : i.call(t, e);
      var l = new Event("input", { bubbles: !0, cancelable: !1 });
      let d;
      for (t.dispatchEvent(l); !d; )
        yield new Promise((r) => setTimeout(r, 50)), d = s.contentDocument.querySelector('button[data-garden-id="buttons.icon_button"][title="Send message"]'), d.click();
      return;
    }
  });
}
export {
  p as default
};
