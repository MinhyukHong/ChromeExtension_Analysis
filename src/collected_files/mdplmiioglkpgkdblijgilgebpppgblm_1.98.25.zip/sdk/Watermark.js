import { _ as r } from "./_plugin-vue_export-helper.js";
import { o as a, c as o, b as l, r as c, g as C, a as u, h as f, d, e as m } from "./runtime-core.esm-bundler.js";
const w = {}, g = { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none", "aria-hidden": "true" }, k = [l("path", { "fill-rule": "evenodd", "clip-rule": "evenodd", fill: "currentColor", d: "M2.19147 11.8085C2.44676 12.0638 2.86067 12.0638 3.11596 11.8085L7 7.92449L10.884 11.8085C11.1393 12.0638 11.5532 12.0638 11.8085 11.8085C12.0638 11.5532 12.0638 11.1393 11.8085 10.884L7.92449 7L11.8085 3.11596C12.0638 2.86067 12.0638 2.44676 11.8085 2.19147C11.5532 1.93618 11.1393 1.93618 10.884 2.19147L7 6.07551L3.11596 2.19147C2.86067 1.93618 2.44676 1.93618 2.19147 2.19147C1.93618 2.44676 1.93618 2.86067 2.19147 3.11596L6.07551 7L2.19147 10.884C1.93618 11.1393 1.93618 11.5532 2.19147 11.8085Z" }, null, -1)], B = { class: "header" }, L = { class: "header-title" }, x = ["title", "aria-label"], P = r({ name: "Header", components: { IconClose: r(w, [["render", function(t, e) {
  return a(), o("svg", g, k);
}]]) }, data: () => {
  var t, e;
  return { closeButtonText: ((e = (t = window.birdeatsbug.options.ui) == null ? void 0 : t.text) == null ? void 0 : e.dismissButton) || "Dismiss" };
}, methods: { onCloseClick() {
  window.birdeatsbug.ui.close();
} } }, [["render", function(t, e, h, p, i, n) {
  const s = c("IconClose");
  return a(), o("header", B, [l("h1", L, [C(t.$slots, "default")]), l("button", { id: "birdeatsbug-close-button", title: i.closeButtonText, "aria-label": i.closeButtonText, class: "button button-icon", onClick: e[0] || (e[0] = (...b) => n.onCloseClick && n.onCloseClick(...b)) }, [u(s)], 8, x)]);
}]]), v = {}, y = { width: "19", height: "19", viewBox: "0 0 19 19", fill: "none", "aria-labelledby": "powered-by-title" }, _ = [f('<title id="powered-by-title">Bird Eats Bug</title><g clip-path="url(#clip0_190_11601)"><path d="M18.6667 9.03468L14.0001 14.3267L14.0001 3.74268L18.6667 9.03468Z" fill="#FECE2F"></path><path d="M14 3.74168V14.325C12.5341 15.9858 10.3894 17.0333 8 17.0333C3.58172 17.0333 0 13.4516 0 9.03333C0 4.61505 3.58172 1.03333 8 1.03333C10.3894 1.03333 12.5341 2.08084 14 3.74168Z" fill="#FF6E64"></path><ellipse cx="7.9999" cy="9.03335" rx="1.6" ry="1.6" fill="#141622"></ellipse></g><defs><clipPath id="clip0_190_11601"><rect width="18.6667" height="16" fill="white" transform="translate(0 1.03333)"></rect></clipPath></defs>', 3)], E = { key: 0, class: "watermark", "aria-hidden": "true" }, F = { class: "homepage-link", href: "https://birdeatsbug.com", target: "_blank", rel: "noopener noreferrer" }, T = r({ name: "Watermark", components: { IconBird: r(v, [["render", function(t, e) {
  return a(), o("svg", y, _);
}]]) }, data: () => ({ watermark: window.birdeatsbug.options.ui.watermark }) }, [["render", function(t, e, h, p, i, n) {
  const s = c("IconBird");
  return i.watermark ? (a(), o("div", E, [d(" Powered by "), l("a", F, [u(s, { class: "icon-bird" }), d(" Bird Eats Bug ")])])) : m("", !0);
}]]);
export {
  P as H,
  T as W
};
