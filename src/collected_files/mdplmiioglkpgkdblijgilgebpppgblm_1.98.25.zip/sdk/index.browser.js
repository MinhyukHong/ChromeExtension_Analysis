let o = (r = 21) => crypto.getRandomValues(new Uint8Array(r)).reduce((n, t) => n += (t &= 63) < 36 ? t.toString(36) : t < 62 ? (t - 26).toString(36).toUpperCase() : t > 62 ? "-" : "_", "");
export {
  o as nanoid
};
