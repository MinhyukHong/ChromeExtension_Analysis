var w = (n, i, t) => new Promise((d, e) => {
  var s = (o) => {
    try {
      a(t.next(o));
    } catch (c) {
      e(c);
    }
  }, r = (o) => {
    try {
      a(t.throw(o));
    } catch (c) {
      e(c);
    }
  }, a = (o) => o.done ? d(o.value) : Promise.resolve(o.value).then(s, r);
  a((t = t.apply(n, i)).next());
});
import { l as v } from "./log.js";
import { b as L } from "./birdifyArguments.js";
import { j as p, k as E, f as S, l as I, m as g, i as h } from "./core.js";
v("instrumentSessionStorage.js");
let m = !1;
const P = window.sessionStorage;
let u;
function f(n, i, t) {
  if (!m)
    return;
  let d;
  try {
    d = JSON.parse(t);
  } catch (s) {
    d = t;
  }
  const e = { source: "storage", type: "sessionStorage", action: n, createdAt: (/* @__PURE__ */ new Date()).toISOString(), args: L([i, t, d]) };
  document.dispatchEvent(new CustomEvent(g, { detail: e }));
}
const C = ["setItem", "removeItem", "clear"];
function y(n) {
  var t, d;
  if (m = ((d = (t = n == null ? void 0 : n.detail) == null ? void 0 : t.recordedEventTypes) == null ? void 0 : d.sessionStorage) !== !1, !m)
    return;
  v("enableSessionStorage()", u ? "re-enabling" : "1st enabling");
  const i = { get(e, s) {
    if (s in e) {
      const r = e[s];
      if (typeof r == "function" && C.includes(s)) {
        const a = r;
        return function(...o) {
          const c = a.apply(e, o);
          return f(s, o[0], o[1]), c;
        }.bind(e);
      }
      return typeof r == "function" ? r.bind(e) : r;
    }
  }, set: (e, s, r) => (f("set", s, r), e.setItem(s, r), !0), deleteProperty: (e, s) => (f("deleteProperty", s, null), e.removeItem(s), !0) };
  u = new Proxy(P, i), Object.defineProperty(window, "sessionStorage", { get: () => u, set(e) {
    u = new Proxy(e, i);
  } });
}
function l() {
  v("disableSessionStorage()"), m = !1;
}
function j() {
  document.removeEventListener(g, b), document.dispatchEvent(new CustomEvent(E));
}
function b(n) {
  (function(i) {
    return w(this, null, function* () {
      var t;
      i.detail.sessionId = (t = window.birdeatsbug.session) == null ? void 0 : t.id, i.detail.sessionId && (yield h.add("consoleEvents", i.detail));
    });
  })(n);
}
document.addEventListener(p, y), document.addEventListener(E, l), document.addEventListener(S, function n() {
  v("disconnectSessionStorage()"), document.removeEventListener(p, y), document.removeEventListener(E, l), document.removeEventListener(S, n), l();
}), document.dispatchEvent(new CustomEvent(I));
const A = { start: function() {
  const n = { recordedEventTypes: window.birdeatsbug.options.recordedEventTypes };
  document.dispatchEvent(new CustomEvent(p, { detail: n })), document.addEventListener(g, b);
}, stop: j };
export {
  A as default,
  j as stop
};
