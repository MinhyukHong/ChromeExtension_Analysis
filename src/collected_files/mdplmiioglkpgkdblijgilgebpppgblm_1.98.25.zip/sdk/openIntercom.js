var a = (s, e, t) => new Promise((n, i) => {
  var r = (o) => {
    try {
      m(t.next(o));
    } catch (c) {
      i(c);
    }
  }, w = (o) => {
    try {
      m(t.throw(o));
    } catch (c) {
      i(c);
    }
  }, m = (o) => o.done ? n(o.value) : Promise.resolve(o.value).then(r, w);
  m((t = t.apply(s, e)).next());
});
function u(s) {
  return a(this, null, function* () {
    if (!window.Intercom)
      return;
    const e = s.session;
    let t, n, i = `Hey, I just reported an issue, here is the link: ${e.link}. `;
    for (e.title && (i += `It is about "${e.title}". `), e.description && (i += `More details: "${e.description}".`), !window.intercomSettings.email && e.uploaderEmail && (window.intercomSettings.email = e.uploaderEmail, window.Intercom("boot", window.intercomSettings)), window.Intercom("showNewMessage", i); !t; )
      yield new Promise((r) => setTimeout(r, 50)), t = document.querySelector("iframe[name='intercom-messenger-frame']");
    for (; !n; )
      n = t.contentDocument.querySelector("#intercom-container button.intercom-composer-send-button"), yield new Promise((r) => setTimeout(r, 50));
    n.click();
  });
}
export {
  u as default
};
