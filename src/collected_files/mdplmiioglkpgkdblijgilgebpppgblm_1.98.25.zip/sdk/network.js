var $ = Object.defineProperty;
var S = Object.getOwnPropertySymbols;
var X = Object.prototype.hasOwnProperty, F = Object.prototype.propertyIsEnumerable;
var L = (e, t, s) => t in e ? $(e, t, { enumerable: !0, configurable: !0, writable: !0, value: s }) : e[t] = s, g = (e, t) => {
  for (var s in t || (t = {}))
    X.call(t, s) && L(e, s, t[s]);
  if (S)
    for (var s of S(t))
      F.call(t, s) && L(e, s, t[s]);
  return e;
};
var p = (e, t, s) => new Promise((a, n) => {
  var r = (c) => {
    try {
      o(s.next(c));
    } catch (f) {
      n(f);
    }
  }, i = (c) => {
    try {
      o(s.throw(c));
    } catch (f) {
      n(f);
    }
  }, o = (c) => c.done ? a(c.value) : Promise.resolve(c.value).then(r, i);
  o((s = s.apply(e, t)).next());
});
import { l } from "./log.js";
import { o as v, p as R, f as H, q as P, r as w, i as V } from "./core.js";
const _ = new RegExp(/(^text\/|json)/);
function k(e) {
  return !!e && _.test(e);
}
function T(e) {
  const t = {};
  for (const [s, a] of e)
    t[s] = a;
  return t;
}
l("instrumentNetwork.js");
let u = !0, q = !1;
const G = new TextDecoder(), C = new Uint32Array(1);
crypto.getRandomValues(C);
const z = C[0];
let y = 0, d = { maxSizeInBytes: 1e6 };
const m = (e) => `${e} not recorded because it was larger than ${Math.round(d.maxSizeInBytes / 1e3 / 1e3)}mb. See https://docs.birdeatsbug.com/latest/troubleshoot/network.html#change-maximum-recorded-request-body-size how to configure the maximum recorded size.`;
function J() {
  l("instrumentNetwork()", q), function() {
    const e = XMLHttpRequest.prototype, t = e.send, s = e.open;
    if (!t || !s)
      return console.warn("Bird Eats Bug: XHR instrumentation failure: `XMLHttpRequest.prototype` lacks methods `open` &/ `send`", e);
    e.open = function(n, r, ...i) {
      return this.url = r, this.method = n, this.startedAt = (/* @__PURE__ */ new Date()).toISOString(), s.apply(this, [n, r, ...i]);
    };
    const a = e.setRequestHeader;
    e.setRequestHeader = function(n, r) {
      return this.requestHeaders || (this.requestHeaders = {}), this.requestHeaders[n] ? this.requestHeaders[n] += ", " + r : this.requestHeaders[n] = r, a.apply(this, [n, r]);
    }, e.send = function(...n) {
      return this.addEventListener("load", function() {
        u && h({ request: this, args: n });
      }), this.addEventListener("error", function() {
        u && h({ request: this, args: n, errorMessage: "error" });
      }), this.addEventListener("abort", function() {
        u && h({ request: this, args: n, errorMessage: "net::ERR_ABORTED" });
      }), this.addEventListener("timeout", function() {
        u && h({ request: this, args: n, errorMessage: "timeout" });
      }), t.apply(this, n);
    };
  }(), function() {
    if (!("fetch" in window))
      return;
    const e = window.fetch;
    window.fetch = (...t) => {
      const [s, a] = t;
      let n;
      n = s instanceof Request ? s : new Request(s, a);
      const r = (/* @__PURE__ */ new Date()).toISOString();
      return e(...t).then((i) => {
        if (!u)
          return i;
        const o = i.clone();
        return B({ request: n, response: o, startedAt: r }), i;
      }).catch((i) => {
        throw B({ request: n, startedAt: r, errorMessage: i.message }), i;
      });
    };
  }(), q = !0;
}
function h(a) {
  return p(this, arguments, function* ({ request: e, args: t, errorMessage: s }) {
    if (!u)
      return;
    let n;
    const r = e.getResponseHeader("Content-Type");
    if (e.getResponseHeader("Content-Length") > d.maxSizeInBytes)
      n = m("Response body");
    else if (!k(r) && e.getResponseHeader("Content-Length") > 0)
      n = `Response body not recorded because the content-type ${r} is not supported.`;
    else {
      const o = e.responseType;
      o === "" || o === "text" ? n = e.responseText : o === "json" ? n = e.response : o === "blob" && e.response instanceof Blob && (n = yield e.response.text()), (n == null ? void 0 : n.length) > d.maxSizeInBytes && (n = m("Response body"));
    }
    y++;
    const i = { id: z + y, type: "xmlhttprequest", startedAt: e.startedAt, url: M(e.url), method: e.method, requestBody: yield D(t == null ? void 0 : t[0]), responseBody: n, statusCode: e.status, statusLine: e.statusText, endedAt: (/* @__PURE__ */ new Date()).toISOString(), requestHeaders: e.requestHeaders, responseHeaders: K(e.getAllResponseHeaders()) };
    e.responseType && (i.responseType = e.responseType), s && (i.error = s), s === "timeout" && (i.timeout = e.timeout), document.dispatchEvent(new CustomEvent(w, { detail: i }));
  });
}
function B(n) {
  return p(this, arguments, function* ({ request: e, response: t, startedAt: s, errorMessage: a }) {
    if (u)
      try {
        let r;
        const i = t == null ? void 0 : t.headers.get("Content-Type");
        (t == null ? void 0 : t.headers.get("Content-Length")) > d.maxSizeInBytes ? r = m("Response body") : t && !k(i) ? r = `Response body not recorded because the content-type "${i}" is not supported.` : t != null && t.body && (r = yield new Response(function(f) {
          const j = f.getReader();
          return new ReadableStream({ start(E) {
            return x();
            function x() {
              return j.read().then(({ done: N, value: O }) => {
                if (!N)
                  return E.enqueue(O), x();
                E.close();
              });
            }
          } });
        }(t.body)).text(), (r == null ? void 0 : r.length) > d.maxSizeInBytes && (r = m("Response body"))), y++;
        const o = { id: z + y, type: "fetch", startedAt: s, url: M(e.url), method: e.method, requestBody: yield D(e.body), responseBody: r, endedAt: (/* @__PURE__ */ new Date()).toISOString() };
        a ? o.error = a : (o.requestHeaders = I(e.headers), o.referrer = e.referrer, o.statusCode = t.status, t.statusText && (o.statusLine = t.statusText), o.responseHeaders = I(t.headers), t.redirected && o.url !== t.url && (o.redirectUrl = t.url)), document.dispatchEvent(new CustomEvent(w, { detail: o }));
      } catch (r) {
        console.error(r);
      }
  });
}
function M(e) {
  let t = e;
  return typeof e == "object" && (t = e instanceof Request ? e.url : e.toString()), (t == null ? void 0 : t.length) > d.maxSizeInBytes && (t = t.subtring(0, d.maxSizeInBytes) + "..."), t;
}
function K(e) {
  const t = {};
  for (const s of e.split(`\r
`)) {
    const a = s.split(": "), n = a[0], r = a == null ? void 0 : a[1];
    n && r && (t[n] ? t[n] += ", " + r : t[n] = r);
  }
  return t;
}
function D(e) {
  return p(this, null, function* () {
    if (e instanceof FormData)
      return T(e);
    if (e instanceof URLSearchParams)
      return e.toString();
    if (typeof (e == null ? void 0 : e.getReader) == "function") {
      if (e.locked)
        return "Request body not recorded because its ReadableStream was locked.";
      e = yield function(t) {
        return p(this, null, function* () {
          const s = t.getReader();
          let a = new Uint8Array();
          for (; ; ) {
            const { done: n, value: r } = yield s.read();
            if (n)
              break;
            a = new Uint8Array([...a, ...r]);
          }
          return a;
        });
      }(e.tee()[0]);
    }
    return e instanceof Uint8Array ? e.byteLength > d.maxSizeInBytes ? m("Request body") : G.decode(e) : e;
  });
}
function I(e) {
  return T(e.entries());
}
function A(e) {
  var t;
  typeof ((t = e == null ? void 0 : e.detail) == null ? void 0 : t.options) == "object" && (d = g(g({}, d), e.detail.options)), l("enableNetwork()", e), u = !0, q || J();
}
function b() {
  l("disableNetwork()"), u = !1;
}
function Q() {
  document.removeEventListener(w, U), document.dispatchEvent(new CustomEvent(R));
}
function U(e) {
  (function(t) {
    return p(this, null, function* () {
      var s;
      if (t.detail.sessionId = (s = window.birdeatsbug.session) == null ? void 0 : s.id, !t.detail.sessionId)
        return console.warn("network event captured without active session");
      yield V.add("networkEventsFromInstrumentation", t.detail);
    });
  })(e);
}
document.addEventListener(v, A), document.addEventListener(R, b), document.addEventListener(H, function e() {
  l("disconnectNetwork()"), document.removeEventListener(v, A), document.removeEventListener(R, b), document.removeEventListener(H, e), b();
}), document.dispatchEvent(new CustomEvent(P));
const ee = { start: function() {
  const e = window.birdeatsbug.options.recordedEventTypes.network;
  document.dispatchEvent(new CustomEvent(v, { detail: { options: e } })), document.addEventListener(w, U);
}, stop: Q };
export {
  ee as default,
  Q as stop
};
