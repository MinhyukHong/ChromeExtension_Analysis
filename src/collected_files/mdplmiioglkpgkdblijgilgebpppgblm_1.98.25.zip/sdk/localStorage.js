var w = (n, r, t) => new Promise((a, e) => {
  var o = (s) => {
    try {
      c(t.next(s));
    } catch (d) {
      e(d);
    }
  }, i = (s) => {
    try {
      c(t.throw(s));
    } catch (d) {
      e(d);
    }
  }, c = (s) => s.done ? a(s.value) : Promise.resolve(s.value).then(o, i);
  c((t = t.apply(n, r)).next());
});
import { l as m } from "./log.js";
import { b as S } from "./birdifyArguments.js";
import { d as p, e as E, f as y, g as I, h as g, i as h } from "./core.js";
m("instrumentLocalStorage.js");
let l = !1;
const P = window.localStorage;
let u;
function v(n, r, t) {
  if (!l)
    return;
  let a;
  try {
    a = JSON.parse(t);
  } catch (o) {
    a = t;
  }
  const e = { source: "storage", type: "localStorage", action: n, createdAt: (/* @__PURE__ */ new Date()).toISOString(), args: S([r, t, a]) };
  document.dispatchEvent(new CustomEvent(g, { detail: e }));
}
const C = ["setItem", "removeItem", "clear"];
function b(n) {
  var t, a;
  if (l = ((a = (t = n == null ? void 0 : n.detail) == null ? void 0 : t.recordedEventTypes) == null ? void 0 : a.localStorage) !== !1, !l)
    return;
  m("enableLocalStorage()", u ? "re-enabling" : "1st enabling");
  const r = { get(e, o) {
    if (o in e) {
      const i = e[o];
      if (typeof i == "function" && C.includes(o)) {
        const c = i;
        return function(...s) {
          const d = c.apply(e, s);
          return v(o, s[0], s[1]), d;
        }.bind(e);
      }
      return typeof i == "function" ? i.bind(e) : i;
    }
  }, set: (e, o, i) => (v("set", o, i), e.setItem(o, i), !0), deleteProperty: (e, o) => (v("deleteProperty", o, null), e.removeItem(o), !0) };
  u = new Proxy(P, r), Object.defineProperty(window, "localStorage", { get: () => u, set(e) {
    u = new Proxy(e, r);
  } });
}
function f() {
  m("disableLocalStorage()"), l = !1;
}
function x() {
  document.removeEventListener(g, L), document.dispatchEvent(new CustomEvent(E));
}
function L(n) {
  (function(r) {
    return w(this, null, function* () {
      var t;
      r.detail.sessionId = (t = window.birdeatsbug.session) == null ? void 0 : t.id, r.detail.sessionId && (yield h.add("consoleEvents", r.detail));
    });
  })(n);
}
document.addEventListener(p, b), document.addEventListener(E, f), document.addEventListener(y, function n() {
  m("disconnectLocalStorage()"), document.removeEventListener(p, b), document.removeEventListener(E, f), document.removeEventListener(y, n), f();
}), document.dispatchEvent(new CustomEvent(I));
const D = { start: function() {
  const n = { recordedEventTypes: window.birdeatsbug.options.recordedEventTypes };
  document.dispatchEvent(new CustomEvent(p, { detail: n })), document.addEventListener(g, L);
}, stop: x };
export {
  D as default,
  x as stop
};
