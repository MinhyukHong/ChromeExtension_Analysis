var m = (s, e, o) => new Promise((n, l) => {
  var i = (a) => {
    try {
      r(o.next(a));
    } catch (f) {
      l(f);
    }
  }, t = (a) => {
    try {
      r(o.throw(a));
    } catch (f) {
      l(f);
    }
  }, r = (a) => a.done ? n(a.value) : Promise.resolve(a.value).then(i, t);
  r((o = o.apply(s, e)).next());
});
import { withKeys as p, withModifiers as u } from "./vue.runtime.esm-bundler.js";
import { _ as b } from "./_plugin-vue_export-helper.js";
import { o as d, c, b as y, t as h, n as v, F as g, f as K, d as O, e as w } from "./runtime-core.esm-bundler.js";
const S = ["aria-label", "aria-expanded"], x = { key: 0 }, $ = { key: 1, class: "placeholder" }, A = { "aria-hidden": "", class: "caret" }, I = ["aria-label"], P = { class: "options-heading" }, V = ["aria-selected", "onClick", "onKeydown"], _ = { key: 0, class: "option-selected" }, L = b({ name: "Select", props: { modelValue: { type: String, default: void 0 }, options: { type: Array, required: !0 }, placeholder: { type: String, default: "" } }, emits: ["update:modelValue"], expose: ["close"], data: () => ({ isOpen: !1, inputHeight: "25px" }), computed: { selectedOptionLabel() {
  var s;
  return this.modelValue ? (s = this.options.find((e) => e.value === this.modelValue)) == null ? void 0 : s.label : this.placeholder;
}, selectedOptionIndex() {
  return Math.max(this.options.findIndex((s) => s.value === this.modelValue), 0);
} }, watch: { isOpen(s) {
  return m(this, null, function* () {
    var e;
    if (!s)
      return this.$refs.trigger.focus();
    yield this.$nextTick(), (e = this.$refs["option" + this.selectedOptionIndex]) == null || e[0].focus();
  });
} }, methods: { onSelect(s) {
  return m(this, null, function* () {
    this.$emit("update:modelValue", s), this.close();
  });
}, onArrowUpKeyPress(s) {
  var o, n;
  let e = s - 1;
  if (e < 0)
    return this.isOpen = !1;
  (n = (o = this.$refs["option" + e]) == null ? void 0 : o[0]) == null || n.focus();
}, onArrowDownKeyPress(s) {
  var o, n;
  let e = s + 1;
  e === this.options.length && (e = 0), (n = (o = this.$refs["option" + e]) == null ? void 0 : o[0]) == null || n.focus();
}, close() {
  this.isOpen = !1;
} } }, [["render", function(s, e, o, n, l, i) {
  return d(), c("div", { class: "select", onKeydown: [e[2] || (e[2] = p(u((t) => l.isOpen = !1, ["stop"]), ["esc"])), e[3] || (e[3] = p(u((t) => l.isOpen = !0, ["stop"]), ["arrow-down"]))] }, [y("button", { ref: "trigger", role: "combobox", "aria-label": o.placeholder, "aria-expanded": l.isOpen, "aria-haspopup": "", class: "trigger-button input", type: "button", onClick: e[0] || (e[0] = (t) => l.isOpen = !l.isOpen), onKeydown: e[1] || (e[1] = p(u(() => {
  }, ["prevent"]), ["enter"])) }, [o.modelValue ? (d(), c("span", x, h(i.selectedOptionLabel), 1)) : (d(), c("span", $, h(o.placeholder), 1)), y("span", A, h(l.isOpen ? ">" : "<"), 1)], 40, S), l.isOpen ? (d(), c("ul", { key: 0, class: "options", style: v({ bottom: l.inputHeight }), "aria-label": o.placeholder, role: "listbox" }, [y("li", P, h(o.placeholder), 1), (d(!0), c(g, null, K(o.options, (t, r) => (d(), c("li", { key: t.value, ref_for: !0, ref: "option" + r, tabindex: "0", "aria-selected": o.modelValue === t.value ? "true" : null, class: "option", onClick: (a) => i.onSelect(t.value), onKeydown: [p(u((a) => i.onSelect(t.value), ["stop", "prevent"]), ["space"]), p(u((a) => i.onSelect(t.value), ["stop", "prevent"]), ["enter"]), p((a) => i.onArrowUpKeyPress(r), ["arrow-up"]), p((a) => i.onArrowDownKeyPress(r), ["arrow-down"])] }, [O(h(t.label) + " ", 1), o.modelValue === t.value ? (d(), c("span", _, "✓")) : w("", !0)], 40, V))), 128))], 12, I)) : w("", !0)], 32);
}], ["__scopeId", "data-v-1cdc5359"]]);
export {
  L as default
};
