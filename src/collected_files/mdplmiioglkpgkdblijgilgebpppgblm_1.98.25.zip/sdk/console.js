var ve = Object.defineProperty;
var I = Object.getOwnPropertySymbols;
var _e = Object.prototype.hasOwnProperty, we = Object.prototype.propertyIsEnumerable;
var z = (i, g, f) => g in i ? ve(i, g, { enumerable: !0, configurable: !0, writable: !0, value: f }) : i[g] = f, J = (i, g) => {
  for (var f in g || (g = {}))
    _e.call(g, f) && z(i, f, g[f]);
  if (I)
    for (var f of I(g))
      we.call(g, f) && z(i, f, g[f]);
  return i;
};
var Z = (i, g, f) => new Promise((m, l) => {
  var u = (s) => {
    try {
      _(f.next(s));
    } catch (o) {
      l(o);
    }
  }, p = (s) => {
    try {
      _(f.throw(s));
    } catch (o) {
      l(o);
    }
  }, _ = (s) => s.done ? m(s.value) : Promise.resolve(s.value).then(u, p);
  _((f = f.apply(i, g)).next());
});
import { l as S } from "./log.js";
import { b as ye } from "./birdifyArguments.js";
import "./_commonjsHelpers.js";
import { x as $, y as F, f as H, z as be, A as G, i as Ce } from "./core.js";
var W, V, pe = { exports: {} }, X = { exports: {} }, Y = { exports: {} };
function D() {
  return W || (W = 1, Y.exports = function() {
    function i(r) {
      return !isNaN(parseFloat(r)) && isFinite(r);
    }
    function g(r) {
      return r.charAt(0).toUpperCase() + r.substring(1);
    }
    function f(r) {
      return function() {
        return this[r];
      };
    }
    var m = ["isConstructor", "isEval", "isNative", "isToplevel"], l = ["columnNumber", "lineNumber"], u = ["fileName", "functionName", "source"], p = ["args"], _ = ["evalOrigin"], s = m.concat(l, u, p, _);
    function o(r) {
      if (r)
        for (var a = 0; a < s.length; a++)
          r[s[a]] !== void 0 && this["set" + g(s[a])](r[s[a]]);
    }
    o.prototype = { getArgs: function() {
      return this.args;
    }, setArgs: function(r) {
      if (Object.prototype.toString.call(r) !== "[object Array]")
        throw new TypeError("Args must be an Array");
      this.args = r;
    }, getEvalOrigin: function() {
      return this.evalOrigin;
    }, setEvalOrigin: function(r) {
      if (r instanceof o)
        this.evalOrigin = r;
      else {
        if (!(r instanceof Object))
          throw new TypeError("Eval Origin must be an Object or StackFrame");
        this.evalOrigin = new o(r);
      }
    }, toString: function() {
      var r = this.getFileName() || "", a = this.getLineNumber() || "", c = this.getColumnNumber() || "", h = this.getFunctionName() || "";
      return this.getIsEval() ? r ? "[eval] (" + r + ":" + a + ":" + c + ")" : "[eval]:" + a + ":" + c : h ? h + " (" + r + ":" + a + ":" + c + ")" : r + ":" + a + ":" + c;
    } }, o.fromString = function(r) {
      var a = r.indexOf("("), c = r.lastIndexOf(")"), h = r.substring(0, a), d = r.substring(a + 1, c).split(","), v = r.substring(c + 1);
      if (v.indexOf("@") === 0)
        var w = /@(.+?)(?::(\d+))?(?::(\d+))?$/.exec(v, ""), b = w[1], C = w[2], A = w[3];
      return new o({ functionName: h, args: d || void 0, fileName: b, lineNumber: C || void 0, columnNumber: A || void 0 });
    };
    for (var e = 0; e < m.length; e++)
      o.prototype["get" + g(m[e])] = f(m[e]), o.prototype["set" + g(m[e])] = /* @__PURE__ */ function(r) {
        return function(a) {
          this[r] = !!a;
        };
      }(m[e]);
    for (var n = 0; n < l.length; n++)
      o.prototype["get" + g(l[n])] = f(l[n]), o.prototype["set" + g(l[n])] = /* @__PURE__ */ function(r) {
        return function(a) {
          if (!i(a))
            throw new TypeError(r + " must be a Number");
          this[r] = Number(a);
        };
      }(l[n]);
    for (var t = 0; t < u.length; t++)
      o.prototype["get" + g(u[t])] = f(u[t]), o.prototype["set" + g(u[t])] = /* @__PURE__ */ function(r) {
        return function(a) {
          this[r] = String(a);
        };
      }(u[t]);
    return o;
  }()), Y.exports;
}
function Oe() {
  return V ? X.exports : (V = 1, X.exports = (i = D(), g = /(^|@)\S+:\d+/, f = /^\s*at .*(\S+:\d+|\(native\))/m, m = /^(eval@)?(\[native code])?$/, { parse: function(l) {
    if (l.stacktrace !== void 0 || l["opera#sourceloc"] !== void 0)
      return this.parseOpera(l);
    if (l.stack && l.stack.match(f))
      return this.parseV8OrIE(l);
    if (l.stack)
      return this.parseFFOrSafari(l);
    throw new Error("Cannot parse given Error object");
  }, extractLocation: function(l) {
    if (l.indexOf(":") === -1)
      return [l];
    var u = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(l.replace(/[()]/g, ""));
    return [u[1], u[2] || void 0, u[3] || void 0];
  }, parseV8OrIE: function(l) {
    return l.stack.split(`
`).filter(function(u) {
      return !!u.match(f);
    }, this).map(function(u) {
      u.indexOf("(eval ") > -1 && (u = u.replace(/eval code/g, "eval").replace(/(\(eval at [^()]*)|(,.*$)/g, ""));
      var p = u.replace(/^\s+/, "").replace(/\(eval code/g, "(").replace(/^.*?\s+/, ""), _ = p.match(/ (\(.+\)$)/);
      p = _ ? p.replace(_[0], "") : p;
      var s = this.extractLocation(_ ? _[1] : p), o = _ && p || void 0, e = ["eval", "<anonymous>"].indexOf(s[0]) > -1 ? void 0 : s[0];
      return new i({ functionName: o, fileName: e, lineNumber: s[1], columnNumber: s[2], source: u });
    }, this);
  }, parseFFOrSafari: function(l) {
    return l.stack.split(`
`).filter(function(u) {
      return !u.match(m);
    }, this).map(function(u) {
      if (u.indexOf(" > eval") > -1 && (u = u.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g, ":$1")), u.indexOf("@") === -1 && u.indexOf(":") === -1)
        return new i({ functionName: u });
      var p = /((.*".+"[^@]*)?[^@]*)(?:@)/, _ = u.match(p), s = _ && _[1] ? _[1] : void 0, o = this.extractLocation(u.replace(p, ""));
      return new i({ functionName: s, fileName: o[0], lineNumber: o[1], columnNumber: o[2], source: u });
    }, this);
  }, parseOpera: function(l) {
    return !l.stacktrace || l.message.indexOf(`
`) > -1 && l.message.split(`
`).length > l.stacktrace.split(`
`).length ? this.parseOpera9(l) : l.stack ? this.parseOpera11(l) : this.parseOpera10(l);
  }, parseOpera9: function(l) {
    for (var u = /Line (\d+).*script (?:in )?(\S+)/i, p = l.message.split(`
`), _ = [], s = 2, o = p.length; s < o; s += 2) {
      var e = u.exec(p[s]);
      e && _.push(new i({ fileName: e[2], lineNumber: e[1], source: p[s] }));
    }
    return _;
  }, parseOpera10: function(l) {
    for (var u = /Line (\d+).*script (?:in )?(\S+)(?:: In function (\S+))?$/i, p = l.stacktrace.split(`
`), _ = [], s = 0, o = p.length; s < o; s += 2) {
      var e = u.exec(p[s]);
      e && _.push(new i({ functionName: e[3] || void 0, fileName: e[2], lineNumber: e[1], source: p[s] }));
    }
    return _;
  }, parseOpera11: function(l) {
    return l.stack.split(`
`).filter(function(u) {
      return !!u.match(g) && !u.match(/^Error created at/);
    }, this).map(function(u) {
      var p, _ = u.split("@"), s = this.extractLocation(_.pop()), o = _.shift() || "", e = o.replace(/<anonymous function(: (\w+))?>/, "$2").replace(/\([^)]*\)/g, "") || void 0;
      o.match(/\(([^)]*)\)/) && (p = o.replace(/^[^(]+\(([^)]*)\)$/, "$1"));
      var n = p === void 0 || p === "[arguments not available]" ? void 0 : p.split(",");
      return new i({ functionName: e, args: n, fileName: s[0], lineNumber: s[1], columnNumber: s[2], source: u });
    }, this);
  } }));
  var i, g, f, m;
}
var Q, K = { exports: {} };
function Ee() {
  return Q || (Q = 1, K.exports = (i = D(), { backtrace: function(g) {
    var f = [], m = 10;
    typeof g == "object" && typeof g.maxStackSize == "number" && (m = g.maxStackSize);
    for (var l = arguments.callee; l && f.length < m && l.arguments; ) {
      for (var u = new Array(l.arguments.length), p = 0; p < u.length; ++p)
        u[p] = l.arguments[p];
      /function(?:\s+([\w$]+))+\s*\(/.test(l.toString()) ? f.push(new i({ functionName: RegExp.$1 || void 0, args: u })) : f.push(new i({ args: u }));
      try {
        l = l.caller;
      } catch (_) {
        break;
      }
    }
    return f;
  } })), K.exports;
  var i;
}
var q, ee = { exports: {} }, E = {}, ne = {};
function re() {
  return q || (q = 1, function(i) {
    i.getArg = function(e, n, t) {
      if (n in e)
        return e[n];
      if (arguments.length === 3)
        return t;
      throw new Error('"' + n + '" is a required argument.');
    };
    var g = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.]*)(?::(\d+))?(\S*)$/, f = /^data:.+\,.+$/;
    function m(e) {
      var n = e.match(g);
      return n ? { scheme: n[1], auth: n[2], host: n[3], port: n[4], path: n[5] } : null;
    }
    function l(e) {
      var n = "";
      return e.scheme && (n += e.scheme + ":"), n += "//", e.auth && (n += e.auth + "@"), e.host && (n += e.host), e.port && (n += ":" + e.port), e.path && (n += e.path), n;
    }
    function u(e) {
      var n = e, t = m(e);
      if (t) {
        if (!t.path)
          return e;
        n = t.path;
      }
      for (var r, a = i.isAbsolute(n), c = n.split(/\/+/), h = 0, d = c.length - 1; d >= 0; d--)
        (r = c[d]) === "." ? c.splice(d, 1) : r === ".." ? h++ : h > 0 && (r === "" ? (c.splice(d + 1, h), h = 0) : (c.splice(d, 2), h--));
      return (n = c.join("/")) === "" && (n = a ? "/" : "."), t ? (t.path = n, l(t)) : n;
    }
    i.urlParse = m, i.urlGenerate = l, i.normalize = u, i.join = function(e, n) {
      e === "" && (e = "."), n === "" && (n = ".");
      var t = m(n), r = m(e);
      if (r && (e = r.path || "/"), t && !t.scheme)
        return r && (t.scheme = r.scheme), l(t);
      if (t || n.match(f))
        return n;
      if (r && !r.host && !r.path)
        return r.host = n, l(r);
      var a = n.charAt(0) === "/" ? n : u(e.replace(/\/+$/, "") + "/" + n);
      return r ? (r.path = a, l(r)) : a;
    }, i.isAbsolute = function(e) {
      return e.charAt(0) === "/" || !!e.match(g);
    }, i.relative = function(e, n) {
      e === "" && (e = "."), e = e.replace(/\/$/, "");
      for (var t = 0; n.indexOf(e + "/") !== 0; ) {
        var r = e.lastIndexOf("/");
        if (r < 0 || (e = e.slice(0, r)).match(/^([^\/]+:\/)?\/*$/))
          return n;
        ++t;
      }
      return Array(t + 1).join("../") + n.substr(e.length + 1);
    };
    var p = !("__proto__" in /* @__PURE__ */ Object.create(null));
    function _(e) {
      return e;
    }
    function s(e) {
      if (!e)
        return !1;
      var n = e.length;
      if (n < 9 || e.charCodeAt(n - 1) !== 95 || e.charCodeAt(n - 2) !== 95 || e.charCodeAt(n - 3) !== 111 || e.charCodeAt(n - 4) !== 116 || e.charCodeAt(n - 5) !== 111 || e.charCodeAt(n - 6) !== 114 || e.charCodeAt(n - 7) !== 112 || e.charCodeAt(n - 8) !== 95 || e.charCodeAt(n - 9) !== 95)
        return !1;
      for (var t = n - 10; t >= 0; t--)
        if (e.charCodeAt(t) !== 36)
          return !1;
      return !0;
    }
    function o(e, n) {
      return e === n ? 0 : e > n ? 1 : -1;
    }
    i.toSetString = p ? _ : function(e) {
      return s(e) ? "$" + e : e;
    }, i.fromSetString = p ? _ : function(e) {
      return s(e) ? e.slice(1) : e;
    }, i.compareByOriginalPositions = function(e, n, t) {
      var r = e.source - n.source;
      return r !== 0 || (r = e.originalLine - n.originalLine) !== 0 || (r = e.originalColumn - n.originalColumn) !== 0 || t || (r = e.generatedColumn - n.generatedColumn) !== 0 || (r = e.generatedLine - n.generatedLine) !== 0 ? r : e.name - n.name;
    }, i.compareByGeneratedPositionsDeflated = function(e, n, t) {
      var r = e.generatedLine - n.generatedLine;
      return r !== 0 || (r = e.generatedColumn - n.generatedColumn) !== 0 || t || (r = e.source - n.source) !== 0 || (r = e.originalLine - n.originalLine) !== 0 || (r = e.originalColumn - n.originalColumn) !== 0 ? r : e.name - n.name;
    }, i.compareByGeneratedPositionsInflated = function(e, n) {
      var t = e.generatedLine - n.generatedLine;
      return t !== 0 || (t = e.generatedColumn - n.generatedColumn) !== 0 || (t = o(e.source, n.source)) !== 0 || (t = e.originalLine - n.originalLine) !== 0 || (t = e.originalColumn - n.originalColumn) !== 0 ? t : o(e.name, n.name);
    };
  }(ne)), ne;
}
var te, oe = {};
function Ae() {
  return te || (te = 1, function(i) {
    function g(f, m, l, u, p, _) {
      var s = Math.floor((m - f) / 2) + f, o = p(l, u[s], !0);
      return o === 0 ? s : o > 0 ? m - s > 1 ? g(s, m, l, u, p, _) : _ == i.LEAST_UPPER_BOUND ? m < u.length ? m : -1 : s : s - f > 1 ? g(f, s, l, u, p, _) : _ == i.LEAST_UPPER_BOUND ? s : f < 0 ? -1 : f;
    }
    i.GREATEST_LOWER_BOUND = 1, i.LEAST_UPPER_BOUND = 2, i.search = function(f, m, l, u) {
      if (m.length === 0)
        return -1;
      var p = g(-1, m.length, f, m, l, u || i.GREATEST_LOWER_BOUND);
      if (p < 0)
        return -1;
      for (; p - 1 >= 0 && l(m[p], m[p - 1], !0) === 0; )
        --p;
      return p;
    };
  }(oe)), oe;
}
var ie, P = {}, ae, se, L = {}, N = {};
function Le() {
  if (ae)
    return N;
  ae = 1;
  var i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
  return N.encode = function(g) {
    if (0 <= g && g < i.length)
      return i[g];
    throw new TypeError("Must be between 0 and 63: " + g);
  }, N.decode = function(g) {
    return 65 <= g && g <= 90 ? g - 65 : 97 <= g && g <= 122 ? g - 97 + 26 : 48 <= g && g <= 57 ? g - 48 + 52 : g == 43 ? 62 : g == 47 ? 63 : -1;
  }, N;
}
var ue, ce, le, j = {};
function Ne() {
  if (ue)
    return j;
  function i(f, m, l) {
    var u = f[m];
    f[m] = f[l], f[l] = u;
  }
  function g(f, m, l, u) {
    if (l < u) {
      var p = l - 1;
      i(f, (e = l, n = u, Math.round(e + Math.random() * (n - e))), u);
      for (var _ = f[u], s = l; s < u; s++)
        m(f[s], _) <= 0 && i(f, p += 1, s);
      i(f, p + 1, s);
      var o = p + 1;
      g(f, m, l, o - 1), g(f, m, o + 1, u);
    }
    var e, n;
  }
  return ue = 1, j.quickSort = function(f, m) {
    g(f, m, 0, f.length - 1);
  }, j;
}
function Se() {
  if (ce)
    return E;
  ce = 1;
  var i = re(), g = Ae(), f = function() {
    if (ie)
      return P;
    ie = 1;
    var o = re(), e = Object.prototype.hasOwnProperty;
    function n() {
      this._array = [], this._set = /* @__PURE__ */ Object.create(null);
    }
    return n.fromArray = function(t, r) {
      for (var a = new n(), c = 0, h = t.length; c < h; c++)
        a.add(t[c], r);
      return a;
    }, n.prototype.size = function() {
      return Object.getOwnPropertyNames(this._set).length;
    }, n.prototype.add = function(t, r) {
      var a = o.toSetString(t), c = e.call(this._set, a), h = this._array.length;
      c && !r || this._array.push(t), c || (this._set[a] = h);
    }, n.prototype.has = function(t) {
      var r = o.toSetString(t);
      return e.call(this._set, r);
    }, n.prototype.indexOf = function(t) {
      var r = o.toSetString(t);
      if (e.call(this._set, r))
        return this._set[r];
      throw new Error('"' + t + '" is not in the set.');
    }, n.prototype.at = function(t) {
      if (t >= 0 && t < this._array.length)
        return this._array[t];
      throw new Error("No element indexed by " + t);
    }, n.prototype.toArray = function() {
      return this._array.slice();
    }, P.ArraySet = n, P;
  }().ArraySet, m = function() {
    if (se)
      return L;
    se = 1;
    var o = Le();
    return L.encode = function(e) {
      var n, t = "", r = function(a) {
        return a < 0 ? 1 + (-a << 1) : 0 + (a << 1);
      }(e);
      do
        n = 31 & r, (r >>>= 5) > 0 && (n |= 32), t += o.encode(n);
      while (r > 0);
      return t;
    }, L.decode = function(e, n, t) {
      var r, a, c, h, d = e.length, v = 0, w = 0;
      do {
        if (n >= d)
          throw new Error("Expected more digits in base 64 VLQ value.");
        if ((a = o.decode(e.charCodeAt(n++))) === -1)
          throw new Error("Invalid base64 digit: " + e.charAt(n - 1));
        r = !!(32 & a), v += (a &= 31) << w, w += 5;
      } while (r);
      t.value = (h = (c = v) >> 1, (1 & c) == 1 ? -h : h), t.rest = n;
    }, L;
  }(), l = Ne().quickSort;
  function u(o) {
    var e = o;
    return typeof o == "string" && (e = JSON.parse(o.replace(/^\)\]\}'/, ""))), e.sections != null ? new s(e) : new p(e);
  }
  function p(o) {
    var e = o;
    typeof o == "string" && (e = JSON.parse(o.replace(/^\)\]\}'/, "")));
    var n = i.getArg(e, "version"), t = i.getArg(e, "sources"), r = i.getArg(e, "names", []), a = i.getArg(e, "sourceRoot", null), c = i.getArg(e, "sourcesContent", null), h = i.getArg(e, "mappings"), d = i.getArg(e, "file", null);
    if (n != this._version)
      throw new Error("Unsupported version: " + n);
    t = t.map(String).map(i.normalize).map(function(v) {
      return a && i.isAbsolute(a) && i.isAbsolute(v) ? i.relative(a, v) : v;
    }), this._names = f.fromArray(r.map(String), !0), this._sources = f.fromArray(t, !0), this.sourceRoot = a, this.sourcesContent = c, this._mappings = h, this.file = d;
  }
  function _() {
    this.generatedLine = 0, this.generatedColumn = 0, this.source = null, this.originalLine = null, this.originalColumn = null, this.name = null;
  }
  function s(o) {
    var e = o;
    typeof o == "string" && (e = JSON.parse(o.replace(/^\)\]\}'/, "")));
    var n = i.getArg(e, "version"), t = i.getArg(e, "sections");
    if (n != this._version)
      throw new Error("Unsupported version: " + n);
    this._sources = new f(), this._names = new f();
    var r = { line: -1, column: 0 };
    this._sections = t.map(function(a) {
      if (a.url)
        throw new Error("Support for url field in sections not implemented.");
      var c = i.getArg(a, "offset"), h = i.getArg(c, "line"), d = i.getArg(c, "column");
      if (h < r.line || h === r.line && d < r.column)
        throw new Error("Section offsets must be ordered and non-overlapping.");
      return r = c, { generatedOffset: { generatedLine: h + 1, generatedColumn: d + 1 }, consumer: new u(i.getArg(a, "map")) };
    });
  }
  return u.fromSourceMap = function(o) {
    return p.fromSourceMap(o);
  }, u.prototype._version = 3, u.prototype.__generatedMappings = null, Object.defineProperty(u.prototype, "_generatedMappings", { get: function() {
    return this.__generatedMappings || this._parseMappings(this._mappings, this.sourceRoot), this.__generatedMappings;
  } }), u.prototype.__originalMappings = null, Object.defineProperty(u.prototype, "_originalMappings", { get: function() {
    return this.__originalMappings || this._parseMappings(this._mappings, this.sourceRoot), this.__originalMappings;
  } }), u.prototype._charIsMappingSeparator = function(o, e) {
    var n = o.charAt(e);
    return n === ";" || n === ",";
  }, u.prototype._parseMappings = function(o, e) {
    throw new Error("Subclasses must implement _parseMappings");
  }, u.GENERATED_ORDER = 1, u.ORIGINAL_ORDER = 2, u.GREATEST_LOWER_BOUND = 1, u.LEAST_UPPER_BOUND = 2, u.prototype.eachMapping = function(o, e, n) {
    var t, r = e || null;
    switch (n || u.GENERATED_ORDER) {
      case u.GENERATED_ORDER:
        t = this._generatedMappings;
        break;
      case u.ORIGINAL_ORDER:
        t = this._originalMappings;
        break;
      default:
        throw new Error("Unknown order of iteration.");
    }
    var a = this.sourceRoot;
    t.map(function(c) {
      var h = c.source === null ? null : this._sources.at(c.source);
      return h != null && a != null && (h = i.join(a, h)), { source: h, generatedLine: c.generatedLine, generatedColumn: c.generatedColumn, originalLine: c.originalLine, originalColumn: c.originalColumn, name: c.name === null ? null : this._names.at(c.name) };
    }, this).forEach(o, r);
  }, u.prototype.allGeneratedPositionsFor = function(o) {
    var e = i.getArg(o, "line"), n = { source: i.getArg(o, "source"), originalLine: e, originalColumn: i.getArg(o, "column", 0) };
    if (this.sourceRoot != null && (n.source = i.relative(this.sourceRoot, n.source)), !this._sources.has(n.source))
      return [];
    n.source = this._sources.indexOf(n.source);
    var t = [], r = this._findMapping(n, this._originalMappings, "originalLine", "originalColumn", i.compareByOriginalPositions, g.LEAST_UPPER_BOUND);
    if (r >= 0) {
      var a = this._originalMappings[r];
      if (o.column === void 0)
        for (var c = a.originalLine; a && a.originalLine === c; )
          t.push({ line: i.getArg(a, "generatedLine", null), column: i.getArg(a, "generatedColumn", null), lastColumn: i.getArg(a, "lastGeneratedColumn", null) }), a = this._originalMappings[++r];
      else
        for (var h = a.originalColumn; a && a.originalLine === e && a.originalColumn == h; )
          t.push({ line: i.getArg(a, "generatedLine", null), column: i.getArg(a, "generatedColumn", null), lastColumn: i.getArg(a, "lastGeneratedColumn", null) }), a = this._originalMappings[++r];
    }
    return t;
  }, E.SourceMapConsumer = u, p.prototype = Object.create(u.prototype), p.prototype.consumer = u, p.fromSourceMap = function(o) {
    var e = Object.create(p.prototype), n = e._names = f.fromArray(o._names.toArray(), !0), t = e._sources = f.fromArray(o._sources.toArray(), !0);
    e.sourceRoot = o._sourceRoot, e.sourcesContent = o._generateSourcesContent(e._sources.toArray(), e.sourceRoot), e.file = o._file;
    for (var r = o._mappings.toArray().slice(), a = e.__generatedMappings = [], c = e.__originalMappings = [], h = 0, d = r.length; h < d; h++) {
      var v = r[h], w = new _();
      w.generatedLine = v.generatedLine, w.generatedColumn = v.generatedColumn, v.source && (w.source = t.indexOf(v.source), w.originalLine = v.originalLine, w.originalColumn = v.originalColumn, v.name && (w.name = n.indexOf(v.name)), c.push(w)), a.push(w);
    }
    return l(e.__originalMappings, i.compareByOriginalPositions), e;
  }, p.prototype._version = 3, Object.defineProperty(p.prototype, "sources", { get: function() {
    return this._sources.toArray().map(function(o) {
      return this.sourceRoot != null ? i.join(this.sourceRoot, o) : o;
    }, this);
  } }), p.prototype._parseMappings = function(o, e) {
    for (var n, t, r, a, c, h = 1, d = 0, v = 0, w = 0, b = 0, C = 0, A = o.length, O = 0, U = {}, M = {}, x = [], R = []; O < A; )
      if (o.charAt(O) === ";")
        h++, O++, d = 0;
      else if (o.charAt(O) === ",")
        O++;
      else {
        for ((n = new _()).generatedLine = h, a = O; a < A && !this._charIsMappingSeparator(o, a); a++)
          ;
        if (r = U[t = o.slice(O, a)])
          O += t.length;
        else {
          for (r = []; O < a; )
            m.decode(o, O, M), c = M.value, O = M.rest, r.push(c);
          if (r.length === 2)
            throw new Error("Found a source, but no line and column");
          if (r.length === 3)
            throw new Error("Found a source and line, but no column");
          U[t] = r;
        }
        n.generatedColumn = d + r[0], d = n.generatedColumn, r.length > 1 && (n.source = b + r[1], b += r[1], n.originalLine = v + r[2], v = n.originalLine, n.originalLine += 1, n.originalColumn = w + r[3], w = n.originalColumn, r.length > 4 && (n.name = C + r[4], C += r[4])), R.push(n), typeof n.originalLine == "number" && x.push(n);
      }
    l(R, i.compareByGeneratedPositionsDeflated), this.__generatedMappings = R, l(x, i.compareByOriginalPositions), this.__originalMappings = x;
  }, p.prototype._findMapping = function(o, e, n, t, r, a) {
    if (o[n] <= 0)
      throw new TypeError("Line must be greater than or equal to 1, got " + o[n]);
    if (o[t] < 0)
      throw new TypeError("Column must be greater than or equal to 0, got " + o[t]);
    return g.search(o, e, r, a);
  }, p.prototype.computeColumnSpans = function() {
    for (var o = 0; o < this._generatedMappings.length; ++o) {
      var e = this._generatedMappings[o];
      if (o + 1 < this._generatedMappings.length) {
        var n = this._generatedMappings[o + 1];
        if (e.generatedLine === n.generatedLine) {
          e.lastGeneratedColumn = n.generatedColumn - 1;
          continue;
        }
      }
      e.lastGeneratedColumn = 1 / 0;
    }
  }, p.prototype.originalPositionFor = function(o) {
    var e = { generatedLine: i.getArg(o, "line"), generatedColumn: i.getArg(o, "column") }, n = this._findMapping(e, this._generatedMappings, "generatedLine", "generatedColumn", i.compareByGeneratedPositionsDeflated, i.getArg(o, "bias", u.GREATEST_LOWER_BOUND));
    if (n >= 0) {
      var t = this._generatedMappings[n];
      if (t.generatedLine === e.generatedLine) {
        var r = i.getArg(t, "source", null);
        r !== null && (r = this._sources.at(r), this.sourceRoot != null && (r = i.join(this.sourceRoot, r)));
        var a = i.getArg(t, "name", null);
        return a !== null && (a = this._names.at(a)), { source: r, line: i.getArg(t, "originalLine", null), column: i.getArg(t, "originalColumn", null), name: a };
      }
    }
    return { source: null, line: null, column: null, name: null };
  }, p.prototype.hasContentsOfAllSources = function() {
    return !!this.sourcesContent && this.sourcesContent.length >= this._sources.size() && !this.sourcesContent.some(function(o) {
      return o == null;
    });
  }, p.prototype.sourceContentFor = function(o, e) {
    if (!this.sourcesContent)
      return null;
    if (this.sourceRoot != null && (o = i.relative(this.sourceRoot, o)), this._sources.has(o))
      return this.sourcesContent[this._sources.indexOf(o)];
    var n;
    if (this.sourceRoot != null && (n = i.urlParse(this.sourceRoot))) {
      var t = o.replace(/^file:\/\//, "");
      if (n.scheme == "file" && this._sources.has(t))
        return this.sourcesContent[this._sources.indexOf(t)];
      if ((!n.path || n.path == "/") && this._sources.has("/" + o))
        return this.sourcesContent[this._sources.indexOf("/" + o)];
    }
    if (e)
      return null;
    throw new Error('"' + o + '" is not in the SourceMap.');
  }, p.prototype.generatedPositionFor = function(o) {
    var e = i.getArg(o, "source");
    if (this.sourceRoot != null && (e = i.relative(this.sourceRoot, e)), !this._sources.has(e))
      return { line: null, column: null, lastColumn: null };
    var n = { source: e = this._sources.indexOf(e), originalLine: i.getArg(o, "line"), originalColumn: i.getArg(o, "column") }, t = this._findMapping(n, this._originalMappings, "originalLine", "originalColumn", i.compareByOriginalPositions, i.getArg(o, "bias", u.GREATEST_LOWER_BOUND));
    if (t >= 0) {
      var r = this._originalMappings[t];
      if (r.source === n.source)
        return { line: i.getArg(r, "generatedLine", null), column: i.getArg(r, "generatedColumn", null), lastColumn: i.getArg(r, "lastGeneratedColumn", null) };
    }
    return { line: null, column: null, lastColumn: null };
  }, E.BasicSourceMapConsumer = p, s.prototype = Object.create(u.prototype), s.prototype.constructor = u, s.prototype._version = 3, Object.defineProperty(s.prototype, "sources", { get: function() {
    for (var o = [], e = 0; e < this._sections.length; e++)
      for (var n = 0; n < this._sections[e].consumer.sources.length; n++)
        o.push(this._sections[e].consumer.sources[n]);
    return o;
  } }), s.prototype.originalPositionFor = function(o) {
    var e = { generatedLine: i.getArg(o, "line"), generatedColumn: i.getArg(o, "column") }, n = g.search(e, this._sections, function(r, a) {
      var c = r.generatedLine - a.generatedOffset.generatedLine;
      return c || r.generatedColumn - a.generatedOffset.generatedColumn;
    }), t = this._sections[n];
    return t ? t.consumer.originalPositionFor({ line: e.generatedLine - (t.generatedOffset.generatedLine - 1), column: e.generatedColumn - (t.generatedOffset.generatedLine === e.generatedLine ? t.generatedOffset.generatedColumn - 1 : 0), bias: o.bias }) : { source: null, line: null, column: null, name: null };
  }, s.prototype.hasContentsOfAllSources = function() {
    return this._sections.every(function(o) {
      return o.consumer.hasContentsOfAllSources();
    });
  }, s.prototype.sourceContentFor = function(o, e) {
    for (var n = 0; n < this._sections.length; n++) {
      var t = this._sections[n].consumer.sourceContentFor(o, !0);
      if (t)
        return t;
    }
    if (e)
      return null;
    throw new Error('"' + o + '" is not in the SourceMap.');
  }, s.prototype.generatedPositionFor = function(o) {
    for (var e = 0; e < this._sections.length; e++) {
      var n = this._sections[e];
      if (n.consumer.sources.indexOf(i.getArg(o, "source")) !== -1) {
        var t = n.consumer.generatedPositionFor(o);
        if (t)
          return { line: t.line + (n.generatedOffset.generatedLine - 1), column: t.column + (n.generatedOffset.generatedLine === t.line ? n.generatedOffset.generatedColumn - 1 : 0) };
      }
    }
    return { line: null, column: null };
  }, s.prototype._parseMappings = function(o, e) {
    this.__generatedMappings = [], this.__originalMappings = [];
    for (var n = 0; n < this._sections.length; n++)
      for (var t = this._sections[n], r = t.consumer._generatedMappings, a = 0; a < r.length; a++) {
        var c = r[a], h = t.consumer._sources.at(c.source);
        t.consumer.sourceRoot !== null && (h = i.join(t.consumer.sourceRoot, h)), this._sources.add(h), h = this._sources.indexOf(h);
        var d = t.consumer._names.at(c.name);
        this._names.add(d), d = this._names.indexOf(d);
        var v = { source: h, generatedLine: c.generatedLine + (t.generatedOffset.generatedLine - 1), generatedColumn: c.generatedColumn + (t.generatedOffset.generatedLine === c.generatedLine ? t.generatedOffset.generatedColumn - 1 : 0), originalLine: c.originalLine, originalColumn: c.originalColumn, name: d };
        this.__generatedMappings.push(v), typeof v.originalLine == "number" && this.__originalMappings.push(v);
      }
    l(this.__generatedMappings, i.compareByGeneratedPositionsDeflated), l(this.__originalMappings, i.compareByOriginalPositions);
  }, E.IndexedSourceMapConsumer = s, E;
}
function Me() {
  return le || (le = 1, ee.exports = /* @__PURE__ */ function(i, g) {
    function f(e) {
      return new Promise(function(n, t) {
        var r = new XMLHttpRequest();
        r.open("get", e), r.onerror = t, r.onreadystatechange = function() {
          r.readyState === 4 && (r.status >= 200 && r.status < 300 || e.substr(0, 7) === "file://" && r.responseText ? n(r.responseText) : t(new Error("HTTP status: " + r.status + " retrieving " + e)));
        }, r.send();
      });
    }
    function m(e) {
      if (typeof window != "undefined" && window.atob)
        return window.atob(e);
      throw new Error("You must supply a polyfill for window.atob in this environment");
    }
    function l(e) {
      if (typeof JSON != "undefined" && JSON.parse)
        return JSON.parse(e);
      throw new Error("You must supply a polyfill for JSON.parse in this environment");
    }
    function u(e, n) {
      for (var t = [/['"]?([$_A-Za-z][$_A-Za-z0-9]*)['"]?\s*[:=]\s*function\b/, /function\s+([^('"`]*?)\s*\(([^)]*)\)/, /['"]?([$_A-Za-z][$_A-Za-z0-9]*)['"]?\s*[:=]\s*(?:eval|new Function)\b/, /\b(?!(?:if|for|switch|while|with|catch)\b)(?:(?:static)\s+)?(\S+)\s*\(.*?\)\s*\{/, /['"]?([$_A-Za-z][$_A-Za-z0-9]*)['"]?\s*[:=]\s*\(.*?\)\s*=>/], r = e.split(`
`), a = "", c = Math.min(n, 20), h = 0; h < c; ++h) {
        var d = r[n - h - 1], v = d.indexOf("//");
        if (v >= 0 && (d = d.substr(0, v)), d) {
          a = d + a;
          for (var w = t.length, b = 0; b < w; b++) {
            var C = t[b].exec(a);
            if (C && C[1])
              return C[1];
          }
        }
      }
    }
    function p() {
      if (typeof Object.defineProperty != "function" || typeof Object.create != "function")
        throw new Error("Unable to consume source maps in older browsers");
    }
    function _(e) {
      if (typeof e != "object")
        throw new TypeError("Given StackFrame is not an object");
      if (typeof e.fileName != "string")
        throw new TypeError("Given file name is not a String");
      if (typeof e.lineNumber != "number" || e.lineNumber % 1 != 0 || e.lineNumber < 1)
        throw new TypeError("Given line number must be a positive integer");
      if (typeof e.columnNumber != "number" || e.columnNumber % 1 != 0 || e.columnNumber < 0)
        throw new TypeError("Given column number must be a non-negative integer");
      return !0;
    }
    function s(e) {
      for (var n, t, r = /\/\/[#@] ?sourceMappingURL=([^\s'"]+)\s*$/gm; t = r.exec(e); )
        n = t[1];
      if (n)
        return n;
      throw new Error("sourceMappingURL not found");
    }
    function o(e, n, t) {
      return new Promise(function(r, a) {
        var c = n.originalPositionFor({ line: e.lineNumber, column: e.columnNumber });
        if (c.source) {
          var h = n.sourceContentFor(c.source);
          h && (t[c.source] = h), r(new g({ functionName: c.name || e.functionName, args: e.args, fileName: c.source, lineNumber: c.line, columnNumber: c.column }));
        } else
          a(new Error("Could not get original source for given stackframe and source map"));
      });
    }
    return function e(n) {
      if (!(this instanceof e))
        return new e(n);
      n = n || {}, this.sourceCache = n.sourceCache || {}, this.sourceMapConsumerCache = n.sourceMapConsumerCache || {}, this.ajax = n.ajax || f, this._atob = n.atob || m, this._get = function(t) {
        return new Promise(function(r, a) {
          var c = t.substr(0, 5) === "data:";
          if (this.sourceCache[t])
            r(this.sourceCache[t]);
          else if (n.offline && !c)
            a(new Error("Cannot make network requests in offline mode"));
          else if (c) {
            var h = /^data:application\/json;([\w=:"-]+;)*base64,/, d = t.match(h);
            if (d) {
              var v = d[0].length, w = t.substr(v), b = this._atob(w);
              this.sourceCache[t] = b, r(b);
            } else
              a(new Error("The encoding of the inline sourcemap is not supported"));
          } else {
            var C = this.ajax(t, { method: "get" });
            this.sourceCache[t] = C, C.then(r, a);
          }
        }.bind(this));
      }, this._getSourceMapConsumer = function(t, r) {
        return new Promise(function(a) {
          if (this.sourceMapConsumerCache[t])
            a(this.sourceMapConsumerCache[t]);
          else {
            var c = new Promise(function(h, d) {
              return this._get(t).then(function(v) {
                typeof v == "string" && (v = l(v.replace(/^\)\]\}'/, ""))), v.sourceRoot === void 0 && (v.sourceRoot = r), h(new i.SourceMapConsumer(v));
              }).catch(d);
            }.bind(this));
            this.sourceMapConsumerCache[t] = c, a(c);
          }
        }.bind(this));
      }, this.pinpoint = function(t) {
        return new Promise(function(r, a) {
          this.getMappedLocation(t).then(function(c) {
            function h() {
              r(c);
            }
            this.findFunctionName(c).then(r, h).catch(h);
          }.bind(this), a);
        }.bind(this));
      }, this.findFunctionName = function(t) {
        return new Promise(function(r, a) {
          _(t), this._get(t.fileName).then(function(c) {
            var h = t.lineNumber, d = t.columnNumber, v = u(c, h);
            r(v ? new g({ functionName: v, args: t.args, fileName: t.fileName, lineNumber: h, columnNumber: d }) : t);
          }, a).catch(a);
        }.bind(this));
      }, this.getMappedLocation = function(t) {
        return new Promise(function(r, a) {
          p(), _(t);
          var c = this.sourceCache, h = t.fileName;
          this._get(h).then(function(d) {
            var v = s(d), w = v.substr(0, 5) === "data:", b = h.substring(0, h.lastIndexOf("/") + 1);
            return v[0] === "/" || w || /^https?:\/\/|^\/\//i.test(v) || (v = b + v), this._getSourceMapConsumer(v, b).then(function(C) {
              return o(t, C, c).then(r).catch(function() {
                r(t);
              });
            });
          }.bind(this), a).catch(a);
        }.bind(this));
      };
    };
  }(Se(), D())), ee.exports;
}
pe.exports = /* @__PURE__ */ function(i, g, f) {
  var m = { filter: function(s) {
    return (s.functionName || "").indexOf("StackTrace$$") === -1 && (s.functionName || "").indexOf("ErrorStackParser$$") === -1 && (s.functionName || "").indexOf("StackTraceGPS$$") === -1 && (s.functionName || "").indexOf("StackGenerator$$") === -1;
  }, sourceCache: {} }, l = function() {
    try {
      throw new Error();
    } catch (s) {
      return s;
    }
  };
  function u(s, o) {
    var e = {};
    return [s, o].forEach(function(n) {
      for (var t in n)
        Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t]);
      return e;
    }), e;
  }
  function p(s) {
    return s.stack || s["opera#sourceloc"];
  }
  function _(s, o) {
    return typeof o == "function" ? s.filter(o) : s;
  }
  return { get: function(s) {
    var o = l();
    return p(o) ? this.fromError(o, s) : this.generateArtificially(s);
  }, getSync: function(s) {
    s = u(m, s);
    var o = l();
    return _(p(o) ? i.parse(o) : g.backtrace(s), s.filter);
  }, fromError: function(s, o) {
    o = u(m, o);
    var e = new f(o);
    return new Promise(function(n) {
      var t = _(i.parse(s), o.filter);
      n(Promise.all(t.map(function(r) {
        return new Promise(function(a) {
          function c() {
            a(r);
          }
          e.pinpoint(r).then(a, c).catch(c);
        });
      })));
    }.bind(this));
  }, generateArtificially: function(s) {
    s = u(m, s);
    var o = g.backtrace(s);
    return typeof s.filter == "function" && (o = o.filter(s.filter)), Promise.resolve(o);
  }, instrument: function(s, o, e, n) {
    if (typeof s != "function")
      throw new Error("Cannot instrument non-function object");
    if (typeof s.__stacktraceOriginalFn == "function")
      return s;
    var t = function() {
      try {
        return this.get().then(o, e).catch(e), s.apply(n || this, arguments);
      } catch (r) {
        throw p(r) && this.fromError(r).then(o, e).catch(e), r;
      }
    }.bind(this);
    return t.__stacktraceOriginalFn = s, t;
  }, deinstrument: function(s) {
    if (typeof s != "function")
      throw new Error("Cannot de-instrument non-function object");
    return typeof s.__stacktraceOriginalFn == "function" ? s.__stacktraceOriginalFn : s;
  }, report: function(s, o, e, n) {
    return new Promise(function(t, r) {
      var a = new XMLHttpRequest();
      if (a.onerror = r, a.onreadystatechange = function() {
        a.readyState === 4 && (a.status >= 200 && a.status < 400 ? t(a.responseText) : r(new Error("POST to " + o + " failed with status: " + a.status)));
      }, a.open("post", o), a.setRequestHeader("Content-Type", "application/json"), n && typeof n.headers == "object") {
        var c = n.headers;
        for (var h in c)
          Object.prototype.hasOwnProperty.call(c, h) && a.setRequestHeader(h, c[h]);
      }
      var d = { stack: s };
      e != null && (d.message = e), a.send(JSON.stringify(d));
    });
  } };
}(Oe(), Ee(), Me());
var xe = pe.exports;
S("instrumentConsole.js");
const ge = { dirxml: "dir", groupCollapsed: "group", groupEnd: "group", countReset: "count", profileEnd: "profile", timeLog: "time", timeEnd: "time", timeStamp: "time" };
let k = /* @__PURE__ */ new Set(), y = {};
function B(i) {
  var g, f;
  (y == null ? void 0 : y.console) !== !1 && ((g = y == null ? void 0 : y.console) == null ? void 0 : g[i.type]) !== !1 && ((f = y == null ? void 0 : y.console) == null ? void 0 : f[ge[i.type]]) !== !1 && document.dispatchEvent(new CustomEvent(G, { detail: i }));
}
function he(i) {
  const g = i.error && i.error.stack, f = i.message;
  (g || f !== "ResizeObserver loop limit exceeded") && B({ source: "window", type: "error-uncaught", createdAt: (/* @__PURE__ */ new Date()).toISOString(), content: { message: f, stack: g } });
}
function me(i) {
  B({ source: "window", type: "error-promise", createdAt: (/* @__PURE__ */ new Date()).toISOString(), content: { message: i.reason && i.reason.message, stack: i.reason && i.reason.stack } });
}
function fe(i) {
  var g;
  y = (g = i == null ? void 0 : i.detail) == null ? void 0 : g.recordedEventTypes, S("enableConsole()", k.size > 0 ? "re-enabling" : "1st enabling", y), y["error-uncaught"] !== !1 && window.addEventListener("error", he), y["error-promise"] !== !1 && window.addEventListener("unhandledrejection", me), Object.entries(console).forEach(([f, m]) => {
    var l, u;
    typeof m == "function" && (y == null ? void 0 : y.console) !== !1 && (((l = y == null ? void 0 : y.console) == null ? void 0 : l[f]) !== !0 && ((u = y == null ? void 0 : y.console) == null ? void 0 : u[ge[f]]) !== !0 || function(p) {
      if (k.has(p))
        return;
      k.add(p);
      const _ = console[p].bind(console);
      console[p] = function(...s) {
        const o = [];
        if (["error", "warn", "trace"].includes(p)) {
          const e = xe.getSync();
          for (const n of e) {
            const { fileName: t, functionName: r, source: a, lineNumber: c, columnNumber: h } = n;
            if ((t || r) && !a.includes("instrumentConsole.js")) {
              if (o.length > 20)
                break;
              if (r && o.push("at " + r), t) {
                let d = t.replace(document.location.origin + "/", "");
                c && (d += ":" + c), h && (d += ":" + h), o.push("   @ " + d);
              }
            }
          }
        }
        return B({ source: "console", type: p, createdAt: (/* @__PURE__ */ new Date()).toISOString(), args: ye(o.length > 0 ? [...s, J({}, o)] : s) }), _(...s);
      };
    }(f));
  });
}
function T() {
  S("disableConsole()"), y = {}, window.removeEventListener("error", he), window.removeEventListener("unhandledrejection", me);
}
function Re() {
  document.removeEventListener(G, de), document.dispatchEvent(new CustomEvent(F));
}
function de(i) {
  (function(g) {
    return Z(this, null, function* () {
      var f;
      g.detail.sessionId = (f = window.birdeatsbug.session) == null ? void 0 : f.id, g.detail.sessionId && (yield Ce.add("consoleEvents", g.detail));
    });
  })(i);
}
document.addEventListener($, fe), document.addEventListener(F, T), document.addEventListener(H, function i() {
  S("disconnectConsole()"), document.removeEventListener($, fe), document.removeEventListener(F, T), document.removeEventListener(H, i), T();
}), document.dispatchEvent(new CustomEvent(be));
const Ge = { start: function() {
  const i = { recordedEventTypes: window.birdeatsbug.options.recordedEventTypes };
  document.dispatchEvent(new CustomEvent($, { detail: i })), document.addEventListener(G, de);
}, stop: Re };
export {
  Ge as default,
  Re as stop
};
