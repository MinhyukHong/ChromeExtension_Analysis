let t;
t = function() {
};
const n = t;
export {
  n as l
};
