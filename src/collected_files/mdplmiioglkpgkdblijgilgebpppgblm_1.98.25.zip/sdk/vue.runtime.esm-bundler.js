import { p as B, q as C, s as L, u as D, v as H, x as I, y as K, z as x, A as q, B as z, C as O, D as E, E as U } from "./runtime-core.esm-bundler.js";
import { G as oe, aa as ie, F as le, ab as ce, S as ue, T as fe, H as de, I as me, J as pe, i as ve, e as he, c as ge, b as ye, h as be, d as Ce, a as Se, k as we, K as Ae, ac as xe, L as Ee, M as Ne, N as Te, ad as ke, ae as Re, af as Pe, ag as _e, ah as Ve, O as Me, ai as Be, m as Ke, P as Le, j as De, n as He, Q as Ie, R as qe, U as ze, V as Oe, W as Ue, X as We, Y as $e, Z as je, _ as Ge, $ as Fe, a0 as Xe, a1 as Je, o as Qe, a2 as Ye, aj as Ze, a3 as et, ak as tt, al as at, am as nt, f as st, g as rt, r as ot, l as it, a4 as lt, an as ct, a5 as ut, t as ft, aq as dt, ao as mt, ap as pt, a6 as vt, a7 as ht, a8 as gt, a9 as yt, w as bt } from "./runtime-core.esm-bundler.js";
const h = typeof document != "undefined" ? document : null, N = h && h.createElement("template"), W = { insert: (e, t, r) => {
  t.insertBefore(e, r || null);
}, remove: (e) => {
  const t = e.parentNode;
  t && t.removeChild(e);
}, createElement: (e, t, r, i) => {
  const o = t ? h.createElementNS("http://www.w3.org/2000/svg", e) : h.createElement(e, r ? { is: r } : void 0);
  return e === "select" && i && i.multiple != null && o.setAttribute("multiple", i.multiple), o;
}, createText: (e) => h.createTextNode(e), createComment: (e) => h.createComment(e), setText: (e, t) => {
  e.nodeValue = t;
}, setElementText: (e, t) => {
  e.textContent = t;
}, parentNode: (e) => e.parentNode, nextSibling: (e) => e.nextSibling, querySelector: (e) => h.querySelector(e), setScopeId(e, t) {
  e.setAttribute(t, "");
}, insertStaticContent(e, t, r, i, o, c) {
  const m = r ? r.previousSibling : t.lastChild;
  if (o && (o === c || o.nextSibling))
    for (; t.insertBefore(o.cloneNode(!0), r), o !== c && (o = o.nextSibling); )
      ;
  else {
    N.innerHTML = i ? `<svg>${e}</svg>` : e;
    const u = N.content;
    if (i) {
      const p = u.firstChild;
      for (; p.firstChild; )
        u.appendChild(p.firstChild);
      u.removeChild(p);
    }
    t.insertBefore(u, r);
  }
  return [m ? m.nextSibling : t.firstChild, r ? r.previousSibling : t.lastChild];
} }, $ = Symbol("_vtc"), j = Symbol("_vod"), T = /\s*!important$/;
function A(e, t, r) {
  if (K(r))
    r.forEach((i) => A(e, t, i));
  else if (r == null && (r = ""), t.startsWith("--"))
    e.setProperty(t, r);
  else {
    const i = function(o, c) {
      const m = S[c];
      if (m)
        return m;
      let u = q(c);
      if (u !== "filter" && u in o)
        return S[c] = u;
      u = z(u);
      for (let p = 0; p < k.length; p++) {
        const n = k[p] + u;
        if (n in o)
          return S[c] = n;
      }
      return c;
    }(e, t);
    T.test(r) ? e.setProperty(x(i), r.replace(T, ""), "important") : e[i] = r;
  }
}
const k = ["Webkit", "Moz", "ms"], S = {}, R = "http://www.w3.org/1999/xlink", P = Symbol("_vei");
function G(e, t, r, i, o = null) {
  const c = e[P] || (e[P] = {}), m = c[t];
  if (i && m)
    m.value = i;
  else {
    const [u, p] = function(n) {
      let a;
      if (_.test(n)) {
        let l;
        for (a = {}; l = n.match(_); )
          n = n.slice(0, n.length - l[0].length), a[l[0].toLowerCase()] = !0;
      }
      return [n[2] === ":" ? n.slice(3) : x(n.slice(2)), a];
    }(t);
    if (i) {
      const n = c[t] = function(a, s) {
        const l = (f) => {
          if (f._vts) {
            if (f._vts <= l.attached)
              return;
          } else
            f._vts = Date.now();
          U(function(d, y) {
            if (K(y)) {
              const b = d.stopImmediatePropagation;
              return d.stopImmediatePropagation = () => {
                b.call(d), d._stopped = !0;
              }, y.map((g) => (v) => !v._stopped && g && g(v));
            }
            return y;
          }(f, l.value), s, 5, [f]);
        };
        return l.value = a, l.attached = X(), l;
      }(i, o);
      (function(a, s, l, f) {
        a.addEventListener(s, l, f);
      })(e, u, n, p);
    } else
      m && (function(n, a, s, l) {
        n.removeEventListener(a, s, l);
      }(e, u, m, p), c[t] = void 0);
  }
}
const _ = /(?:Once|Passive|Capture)$/;
let w = 0;
const F = Promise.resolve(), X = () => w || (F.then(() => w = 0), w = Date.now()), V = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, J = ["ctrl", "shift", "alt", "meta"], Q = { stop: (e) => e.stopPropagation(), prevent: (e) => e.preventDefault(), self: (e) => e.target !== e.currentTarget, ctrl: (e) => !e.ctrlKey, shift: (e) => !e.shiftKey, alt: (e) => !e.altKey, meta: (e) => !e.metaKey, left: (e) => "button" in e && e.button !== 0, middle: (e) => "button" in e && e.button !== 1, right: (e) => "button" in e && e.button !== 2, exact: (e, t) => J.some((r) => e[`${r}Key`] && !t.includes(r)) }, te = (e, t) => e._withMods || (e._withMods = (r, ...i) => {
  for (let o = 0; o < t.length; o++) {
    const c = Q[t[o]];
    if (c && c(r, t))
      return;
  }
  return e(r, ...i);
}), Y = { esc: "escape", space: " ", up: "arrow-up", left: "arrow-left", right: "arrow-right", down: "arrow-down", delete: "backspace" }, ae = (e, t) => e._withKeys || (e._withKeys = (r) => {
  if (!("key" in r))
    return;
  const i = x(r.key);
  return t.some((o) => o === i || Y[o] === i) ? e(r) : void 0;
}), Z = D({ patchProp: (e, t, r, i, o = !1, c, m, u, p) => {
  t === "class" ? function(n, a, s) {
    const l = n[$];
    l && (a = (a ? [a, ...l] : [...l]).join(" ")), a == null ? n.removeAttribute("class") : s ? n.setAttribute("class", a) : n.className = a;
  }(e, i, o) : t === "style" ? function(n, a, s) {
    const l = n.style, f = C(s);
    if (s && !f) {
      if (a && !C(a))
        for (const d in a)
          s[d] == null && A(l, d, "");
      for (const d in s)
        A(l, d, s[d]);
    } else {
      const d = l.display;
      f ? a !== s && (l.cssText = s) : a && n.removeAttribute("style"), j in n && (l.display = d);
    }
  }(e, r, i) : H(t) ? I(t) || G(e, t, 0, i, m) : (t[0] === "." ? (t = t.slice(1), 1) : t[0] === "^" ? (t = t.slice(1), 0) : function(n, a, s, l) {
    if (l)
      return a === "innerHTML" || a === "textContent" || !!(a in n && V(a) && B(s));
    if (a === "spellcheck" || a === "draggable" || a === "translate" || a === "form" || a === "list" && n.tagName === "INPUT" || a === "type" && n.tagName === "TEXTAREA")
      return !1;
    if (a === "width" || a === "height") {
      const f = n.tagName;
      if (f === "IMG" || f === "VIDEO" || f === "CANVAS" || f === "SOURCE")
        return !1;
    }
    return V(a) && C(s) ? !1 : a in n;
  }(e, t, i, o)) ? function(n, a, s, l, f, d, y) {
    if (a === "innerHTML" || a === "textContent")
      return l && y(l, f, d), void (n[a] = s == null ? "" : s);
    const b = n.tagName;
    if (a === "value" && b !== "PROGRESS" && !b.includes("-")) {
      n._value = s;
      const v = s == null ? "" : s;
      return (b === "OPTION" ? n.getAttribute("value") : n.value) !== v && (n.value = v), void (s == null && n.removeAttribute(a));
    }
    let g = !1;
    if (s === "" || s == null) {
      const v = typeof n[a];
      v === "boolean" ? s = E(s) : s == null && v === "string" ? (s = "", g = !0) : v === "number" && (s = 0, g = !0);
    }
    try {
      n[a] = s;
    } catch (v) {
    }
    g && n.removeAttribute(a);
  }(e, t, i, c, m, u, p) : (t === "true-value" ? e._trueValue = i : t === "false-value" && (e._falseValue = i), function(n, a, s, l, f) {
    if (l && a.startsWith("xlink:"))
      s == null ? n.removeAttributeNS(R, a.slice(6, a.length)) : n.setAttributeNS(R, a, s);
    else {
      const d = O(a);
      s == null || d && !E(s) ? n.removeAttribute(a) : n.setAttribute(a, d ? "" : s);
    }
  }(e, t, i, o));
} }, W);
let M;
const ne = (...e) => {
  const t = (M || (M = L(Z))).createApp(...e), { mount: r } = t;
  return t.mount = (i) => {
    const o = function(u) {
      return C(u) ? document.querySelector(u) : u;
    }(i);
    if (!o)
      return;
    const c = t._component;
    B(c) || c.render || c.template || (c.template = o.innerHTML), o.innerHTML = "";
    const m = r(o, !1, o instanceof SVGElement);
    return o instanceof Element && (o.removeAttribute("v-cloak"), o.setAttribute("data-v-app", "")), m;
  }, t;
};
export {
  oe as Comment,
  ie as EffectScope,
  le as Fragment,
  ce as ReactiveEffect,
  ue as Static,
  fe as Text,
  U as callWithAsyncErrorHandling,
  de as callWithErrorHandling,
  q as camelize,
  z as capitalize,
  me as cloneVNode,
  pe as computed,
  ne as createApp,
  ve as createBlock,
  he as createCommentVNode,
  ge as createElementBlock,
  ye as createElementVNode,
  L as createRenderer,
  be as createStaticVNode,
  Ce as createTextVNode,
  Se as createVNode,
  we as defineAsyncComponent,
  Ae as defineComponent,
  xe as getCurrentScope,
  Ee as guardReactiveProps,
  Ne as handleError,
  Te as inject,
  ke as isProxy,
  Re as isReactive,
  Pe as isReadonly,
  _e as isRef,
  Ve as isShallow,
  Me as isVNode,
  Be as markRaw,
  Ke as mergeProps,
  Le as nextTick,
  De as normalizeClass,
  He as normalizeStyle,
  Ie as onActivated,
  qe as onBeforeMount,
  ze as onBeforeUnmount,
  Oe as onBeforeUpdate,
  Ue as onDeactivated,
  We as onErrorCaptured,
  $e as onMounted,
  je as onRenderTracked,
  Ge as onRenderTriggered,
  Fe as onServerPrefetch,
  Xe as onUnmounted,
  Je as onUpdated,
  Qe as openBlock,
  Ye as provide,
  Ze as proxyRefs,
  et as queuePostFlushCb,
  tt as reactive,
  at as readonly,
  nt as ref,
  st as renderList,
  rt as renderSlot,
  ot as resolveComponent,
  it as resolveDynamicComponent,
  lt as setBlockTracking,
  ct as shallowReactive,
  ut as ssrContextKey,
  ft as toDisplayString,
  dt as toHandlerKey,
  mt as toRaw,
  pt as unref,
  vt as useSSRContext,
  ht as version,
  gt as warn,
  yt as watch,
  bt as withCtx,
  ae as withKeys,
  te as withModifiers
};
