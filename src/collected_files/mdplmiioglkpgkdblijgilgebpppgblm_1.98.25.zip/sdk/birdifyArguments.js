import { b as n } from "./birdify.js";
function p(e) {
  return e.map((t) => {
    return (r = t) !== null && typeof r != "string" && typeof r != "number" && typeof r != "boolean" ? n(t) : t;
    var r;
  });
}
export {
  p as b
};
