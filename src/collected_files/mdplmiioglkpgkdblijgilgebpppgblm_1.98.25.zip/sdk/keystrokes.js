var Q = Object.defineProperty, J = Object.defineProperties;
var X = Object.getOwnPropertyDescriptors;
var D = Object.getOwnPropertySymbols;
var Y = Object.prototype.hasOwnProperty, Z = Object.prototype.propertyIsEnumerable;
var N = (t, n, e) => n in t ? Q(t, n, { enumerable: !0, configurable: !0, writable: !0, value: e }) : t[n] = e, k = (t, n) => {
  for (var e in n || (n = {}))
    Y.call(n, e) && N(t, e, n[e]);
  if (D)
    for (var e of D(n))
      Z.call(n, e) && N(t, e, n[e]);
  return t;
}, I = (t, n) => J(t, X(n));
var K = (t, n, e) => new Promise((i, r) => {
  var u = (o) => {
    try {
      c(e.next(o));
    } catch (a) {
      r(a);
    }
  }, p = (o) => {
    try {
      c(e.throw(o));
    } catch (a) {
      r(a);
    }
  }, c = (o) => o.done ? i(o.value) : Promise.resolve(o.value).then(u, p);
  c((e = e.apply(t, n)).next());
});
import { c as b, g as _ } from "./_commonjsHelpers.js";
import { b as tt } from "./birdify.js";
import { l as C } from "./log.js";
import { s as V, t as H, u as et, v as T, i as nt } from "./core.js";
var q = function(t) {
  var n = typeof t;
  return t != null && (n == "object" || n == "function");
}, ot = typeof b == "object" && b && b.Object === Object && b, rt = typeof self == "object" && self && self.Object === Object && self, G = ot || rt || Function("return this")(), it = G, at = function() {
  return it.Date.now();
}, ct = /\s/, ut = function(t) {
  for (var n = t.length; n-- && ct.test(t.charAt(n)); )
    ;
  return n;
}, st = /^\s+/, dt = function(t) {
  return t && t.slice(0, ut(t) + 1).replace(st, "");
}, O = G.Symbol, U = O, W = Object.prototype, ft = W.hasOwnProperty, lt = W.toString, g = U ? U.toStringTag : void 0, pt = function(t) {
  var n = ft.call(t, g), e = t[g];
  try {
    t[g] = void 0;
    var i = !0;
  } catch (u) {
  }
  var r = lt.call(t);
  return i && (n ? t[g] = e : delete t[g]), r;
}, mt = Object.prototype.toString, vt = pt, yt = function(t) {
  return mt.call(t);
}, $ = O ? O.toStringTag : void 0, ht = function(t) {
  return t == null ? t === void 0 ? "[object Undefined]" : "[object Null]" : $ && $ in Object(t) ? vt(t) : yt(t);
}, kt = function(t) {
  return t != null && typeof t == "object";
}, gt = dt, B = q, St = function(t) {
  return typeof t == "symbol" || kt(t) && ht(t) == "[object Symbol]";
}, Lt = /^[-+]0x[0-9a-f]+$/i, bt = /^0b[01]+$/i, At = /^0o[0-7]+$/i, wt = parseInt, Et = q, P = at, F = function(t) {
  if (typeof t == "number")
    return t;
  if (St(t))
    return NaN;
  if (B(t)) {
    var n = typeof t.valueOf == "function" ? t.valueOf() : t;
    t = B(n) ? n + "" : n;
  }
  if (typeof t != "string")
    return t === 0 ? t : +t;
  t = gt(t);
  var e = bt.test(t);
  return e || At.test(t) ? wt(t.slice(2), e ? 2 : 8) : Lt.test(t) ? NaN : +t;
}, Mt = Math.max, Pt = Math.min;
const jt = _(function(t, n, e) {
  var i, r, u, p, c, o, a = 0, s = !1, d = !1, l = !0;
  if (typeof t != "function")
    throw new TypeError("Expected a function");
  function m(f) {
    var v = i, y = r;
    return i = r = void 0, a = f, p = t.apply(y, v);
  }
  function L(f) {
    var v = f - o;
    return o === void 0 || v >= n || v < 0 || d && f - a >= u;
  }
  function h() {
    var f = P();
    if (L(f))
      return x(f);
    c = setTimeout(h, function(v) {
      var y = n - (v - o);
      return d ? Pt(y, u - (v - a)) : y;
    }(f));
  }
  function x(f) {
    return c = void 0, l && i ? m(f) : (i = r = void 0, p);
  }
  function M() {
    var f = P(), v = L(f);
    if (i = arguments, r = this, o = f, v) {
      if (c === void 0)
        return function(y) {
          return a = y, c = setTimeout(h, n), s ? m(y) : p;
        }(o);
      if (d)
        return clearTimeout(c), c = setTimeout(h, n), m(o);
    }
    return c === void 0 && (c = setTimeout(h, n)), p;
  }
  return n = F(n) || 0, Et(e) && (s = !!e.leading, u = (d = "maxWait" in e) ? Mt(F(e.maxWait) || 0, n) : u, l = "trailing" in e ? !!e.trailing : l), M.cancel = function() {
    c !== void 0 && clearTimeout(c), a = 0, i = o = r = c = void 0;
  }, M.flush = function() {
    return c === void 0 ? p : x(P());
  }, M;
}), Ct = I(k(k(k(k({}, [...Array(26)].reduce((t, n, e) => {
  const i = String.fromCharCode(97 + e);
  return t[`Key${i.toUpperCase()}`] = i, t;
}, {})), [...Array(10)].reduce((t, n, e) => (t[`Digit${e}`] = String(e), t), {})), [...Array(10)].reduce((t, n, e) => (t[`Numpad${e}`] = String(e), t), {})), [...Array(12)].reduce((t, n, e) => (t[`F${e + 1}`] = `F${e + 1}`, t), {})), { Backspace: "Backspace", Tab: "Tab", Enter: "Enter", ShiftLeft: "Shift", ShiftRight: "Shift", ControlLeft: "Control", ControlRight: "Control", AltLeft: "Alt", AltRight: "Alt", MetaLeft: "Meta", MetaRight: "Meta", CapsLock: "CapsLock", Escape: "Escape", Space: " ", PageUp: "PageUp", PageDown: "PageDown", End: "End", Home: "Home", Insert: "Insert", Delete: "Delete", ContextMenu: "ContextMenu", NumLock: "NumLock", ScrollLock: "ScrollLock", AudioVolumeMute: "AudioVolumeMute", AudioVolumeDown: "AudioVolumeDown", AudioVolumeUp: "AudioVolumeUp", MediaTrackNext: "MediaTrackNext", MediaTrackPrevious: "MediaTrackPrevious", MediaStop: "MediaStop", MediaPlayPause: "MediaPlayPause", LaunchMail: "LaunchMail", LaunchMediaSelect: "LaunchMediaSelect", LaunchApp1: "LaunchApp1", LaunchApp2: "LaunchApp2", Semicolon: ";", Equal: "=", Comma: ",", Minus: "-", Period: ".", Slash: "/", Backquote: "`", BracketLeft: "[", Backslash: "\\", BracketRight: "]", Quote: "'", IntlBackslash: "\\", Unidentified: "?", Alt: "Alt", AltGraph: "AltGraph", Control: "Ctrl", Fn: "Fn", FnLock: "FnLock", Hyper: "Hyper", Meta: "Meta", Pause: "Pause", Shift: "Shift", Super: "Super", Symbol: "Symbol", SymbolLock: "SymbolLock", ArrowDown: "↓", ArrowLeft: "←", ArrowRight: "→", ArrowUp: "↑", Paste: "Paste", PrintScreen: "PrintScreen", LaunchMediaPlayer: "LaunchMediaPlayer", LaunchApplication1: "LaunchApplication1", LaunchApplication2: "LaunchApplication2", hidden: "·" });
C("instrumentKeystrokes.js");
let A, E = [];
const j = { shiftKey: "Shift", ctrlKey: "Control", altKey: "Alt", metaKey: "Meta" };
function w(t) {
  const n = function(e) {
    if (e.key == "Dead" || e.target.closest('[data-birdeatsbug="ignore"]'))
      return;
    const { type: i, autocomplete: r } = e.target;
    return i == "password" || ["current-password", "new-password", "one-time-code", "cc-number", "cc-csc", "cc-exp"].includes(r) ? "hidden" : e.type == "input" ? e.data : Ct[e.code] || e.key;
  }(t);
  n && (n == "Enter" && S.flush(), A || (A = t.target), t.target.isEqualNode(A) || S.flush(), E.push({ key: n, event: t, timestamp: Date.now() }), A = t.target, S(), n == "Enter" && S.flush());
}
const S = jt(function() {
  if (!E.length)
    return;
  const t = function(e) {
    const i = e.filter(({ event: o }) => o.type == "input"), r = e.filter(({ event: o }) => o.type == "keydown"), u = /* @__PURE__ */ new Set();
    if (i.length)
      for (const o of i) {
        const a = o.key, s = r.findIndex((l, m) => [l.key, l.event.key].includes(a) && l.timestamp <= o.timestamp && !u.has(m));
        if (s == -1)
          continue;
        const d = r[s].event;
        u.add(s);
        for (const [l, m] of Object.entries(j)) {
          if (!d[l])
            continue;
          const L = r.findIndex(({ key: h }) => h == m);
          u.add(L);
        }
      }
    else
      r.forEach((o) => {
        if (!Object.entries(j).some(([s, d]) => o.event[s] && d != o.key))
          return;
        const a = /* @__PURE__ */ new Set();
        Object.entries(j).forEach(([s, d]) => {
          o.event[s] && a.add(d);
        }), a.add(o.key), o.key = Array.from(a).join("+");
        for (const s of a) {
          const d = r.find(({ key: l, timestamp: m }) => l == s && m < o.timestamp);
          d && u.add(r.indexOf(d));
        }
      });
    if (u.size) {
      const o = Array.from(u).sort((a, s) => s - a);
      for (const a of o)
        r.splice(a, 1);
    }
    const p = R(i), c = R(r);
    return [...p, ...c].sort((o, a) => o.event.timeStamp - a.event.timeStamp);
  }(E), n = { source: "document", type: t[0].event.type, target: tt(t[0].event.target), createdAt: new Date(t[0].timestamp).toISOString(), keys: t.map(({ key: e }) => e) };
  document.dispatchEvent(new CustomEvent(T, { detail: n })), E = [];
}, 1e3);
function R(t, n = 5) {
  return t.reduce((e, i) => (e.some((r) => r.key == i.key && Math.abs(r.timestamp - i.timestamp) < n) || e.push(i), e), []);
}
function Ot() {
  document.removeEventListener(T, z), document.dispatchEvent(new CustomEvent(H));
}
function z(t) {
  (function(e) {
    return K(this, arguments, function* ({ detail: n }) {
      var r;
      const i = (r = window.birdeatsbug.session) == null ? void 0 : r.id;
      if (!i)
        return console.warn("keystroke event captured without active session");
      n.sessionId = i, yield nt.add("consoleEvents", n);
    });
  })(t);
}
document.addEventListener(V, function() {
  C("enableKeystrokes()"), document.addEventListener("keydown", w, { passive: !0 }), document.addEventListener("input", w, { passive: !0 });
}), document.addEventListener(H, function() {
  C("disableKeystrokes()"), S.flush(), document.removeEventListener("keydown", w, { passive: !0 }), document.removeEventListener("input", w, { passive: !0 });
}), document.dispatchEvent(new CustomEvent(et));
const Kt = { start: function() {
  document.dispatchEvent(new CustomEvent(V)), document.addEventListener(T, z);
}, stop: Ot };
export {
  Kt as default,
  Ot as stop
};
