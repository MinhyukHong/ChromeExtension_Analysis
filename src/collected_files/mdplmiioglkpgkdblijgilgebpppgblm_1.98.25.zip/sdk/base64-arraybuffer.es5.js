var g;
function Re(e) {
  return e.nodeType === e.ELEMENT_NODE;
}
function _e(e) {
  var t = e == null ? void 0 : e.host;
  return (t == null ? void 0 : t.shadowRoot) === e;
}
function ke(e) {
  return Object.prototype.toString.call(e) === "[object ShadowRoot]";
}
function he(e) {
  try {
    var t = e.rules || e.cssRules;
    return t ? ((r = Array.from(t).map(We).join("")).includes(" background-clip: text;") && !r.includes(" -webkit-background-clip: text;") && (r = r.replace(" background-clip: text;", " -webkit-background-clip: text; background-clip: text;")), r) : null;
  } catch (n) {
    return null;
  }
  var r;
}
function We(e) {
  var t;
  if (function(r) {
    return "styleSheet" in r;
  }(e))
    try {
      t = he(e.styleSheet) || function(r) {
        var n = r.cssText;
        if (n.split('"').length < 3)
          return n;
        var o = ["@import", "url(".concat(JSON.stringify(r.href), ")")];
        return r.layerName === "" ? o.push("layer") : r.layerName && o.push("layer(".concat(r.layerName, ")")), r.supportsText && o.push("supports(".concat(r.supportsText, ")")), r.media.length && o.push(r.media.mediaText), o.join(" ") + ";";
      }(e);
    } catch (r) {
    }
  return function(r) {
    if (r.includes(":")) {
      var n = /(\[(?:[\w-]+)[^\\])(:(?:[\w-]+)\])/gm;
      return r.replace(n, "$1\\$2");
    }
    return r;
  }(t || e.cssText);
}
(function(e) {
  e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment";
})(g || (g = {}));
var Ce = function() {
  function e() {
    this.idNodeMap = /* @__PURE__ */ new Map(), this.nodeMetaMap = /* @__PURE__ */ new WeakMap();
  }
  return e.prototype.getId = function(t) {
    var r;
    if (!t)
      return -1;
    var n = (r = this.getMeta(t)) === null || r === void 0 ? void 0 : r.id;
    return n != null ? n : -1;
  }, e.prototype.getNode = function(t) {
    return this.idNodeMap.get(t) || null;
  }, e.prototype.getIds = function() {
    return Array.from(this.idNodeMap.keys());
  }, e.prototype.getMeta = function(t) {
    return this.nodeMetaMap.get(t) || null;
  }, e.prototype.removeNodeFromMap = function(t) {
    var r = this, n = this.getId(t);
    this.idNodeMap.delete(n), t.childNodes && t.childNodes.forEach(function(o) {
      return r.removeNodeFromMap(o);
    });
  }, e.prototype.has = function(t) {
    return this.idNodeMap.has(t);
  }, e.prototype.hasNode = function(t) {
    return this.nodeMetaMap.has(t);
  }, e.prototype.add = function(t, r) {
    var n = r.id;
    this.idNodeMap.set(n, t), this.nodeMetaMap.set(t, r);
  }, e.prototype.replace = function(t, r) {
    var n = this.getNode(t);
    if (n) {
      var o = this.nodeMetaMap.get(n);
      o && this.nodeMetaMap.set(r, o);
    }
    this.idNodeMap.set(t, r);
  }, e.prototype.reset = function() {
    this.idNodeMap = /* @__PURE__ */ new Map(), this.nodeMetaMap = /* @__PURE__ */ new WeakMap();
  }, e;
}();
function bt() {
  return new Ce();
}
function je(e) {
  var t = e.element, r = e.maskInputOptions, n = e.tagName, o = e.type, a = e.value, l = e.maskInputFn, c = a || "", s = o && ye(o);
  return (r[n.toLowerCase()] || s && r[s]) && (c = l ? l(c, t) : "*".repeat(c.length)), c;
}
function ye(e) {
  return e.toLowerCase();
}
var Ne = "__rrweb_original__";
function Be(e) {
  var t = e.type;
  return e.hasAttribute("data-rr-is-password") ? "password" : t ? ye(t) : null;
}
var ne, xe, Ge = 1, He = new RegExp("[^a-z0-9-_:]"), we = -2;
function Ve() {
  return Ge++;
}
var qe = /url\((?:(')([^']*)'|(")(.*?)"|([^)]*))\)/gm, Ye = /^(?:[a-z+]+:)?\/\//i, $e = /^www\..*/i, ze = /^(data:)([^,]*),(.*)/i;
function ve(e, t) {
  return (e || "").replace(qe, function(r, n, o, a, l, c) {
    var s, d = o || l || c, h = n || a || "";
    if (!d)
      return r;
    if (Ye.test(d) || $e.test(d) || ze.test(d))
      return "url(".concat(h).concat(d).concat(h, ")");
    if (d[0] === "/")
      return "url(".concat(h).concat((s = t, (s.indexOf("//") > -1 ? s.split("/").slice(0, 3).join("/") : s.split("/")[0]).split("?")[0] + d)).concat(h, ")");
    var b = t.split("/"), y = d.split("/");
    b.pop();
    for (var M = 0, m = y; M < m.length; M++) {
      var C = m[M];
      C !== "." && (C === ".." ? b.pop() : b.push(C));
    }
    return "url(".concat(h).concat(b.join("/")).concat(h, ")");
  });
}
var Xe = /^[^ \t\n\r\u000c]+/, Je = /^[, \t\n\r\u000c]+/;
function se(e, t) {
  if (!t || t.trim() === "")
    return t;
  var r = e.createElement("a");
  return r.href = t, r.href;
}
function Ke(e) {
  return !!(e.tagName === "svg" || e.ownerSVGElement);
}
function Se() {
  var e = document.createElement("a");
  return e.href = "", e.href;
}
function Qe(e, t, r, n) {
  return n && (r === "src" || r === "href" && (t !== "use" || n[0] !== "#") || r === "xlink:href" && n[0] !== "#" ? se(e, n) : r !== "background" || t !== "table" && t !== "td" && t !== "th" ? r === "srcset" ? function(o, a) {
    if (a.trim() === "")
      return a;
    var l = 0;
    function c(M) {
      var m, C = M.exec(a.substring(l));
      return C ? (m = C[0], l += m.length, m) : "";
    }
    for (var s = []; c(Je), !(l >= a.length); ) {
      var d = c(Xe);
      if (d.slice(-1) === ",")
        d = se(o, d.substring(0, d.length - 1)), s.push(d);
      else {
        var h = "";
        d = se(o, d);
        for (var b = !1; ; ) {
          var y = a.charAt(l);
          if (y === "") {
            s.push((d + h).trim());
            break;
          }
          if (b)
            y === ")" && (b = !1);
          else {
            if (y === ",") {
              l += 1, s.push((d + h).trim());
              break;
            }
            y === "(" && (b = !0);
          }
          h += y, l += 1;
        }
      }
    }
    return s.join(", ");
  }(e, n) : r === "style" ? ve(n, Se()) : t === "object" && r === "data" ? se(e, n) : n : se(e, n));
}
function Ze(e, t, r) {
  return (e === "video" || e === "audio") && t === "autoplay";
}
function ge(e, t, r) {
  if (!e)
    return !1;
  if (e.nodeType !== e.ELEMENT_NODE)
    return !!r && ge(e.parentNode, t, r);
  for (var n = e.classList.length; n--; ) {
    var o = e.classList[n];
    if (t.test(o))
      return !0;
  }
  return !!r && ge(e.parentNode, t, r);
}
function et(e, t, r) {
  try {
    var n = e.nodeType === e.ELEMENT_NODE ? e : e.parentElement;
    if (n === null)
      return !1;
    if (typeof t == "string") {
      if (n.classList.contains(t) || n.closest(".".concat(t)))
        return !0;
    } else if (ge(n, t, !0))
      return !0;
    if (r && (n.matches(r) || n.closest(r)))
      return !0;
  } catch (o) {
  }
  return !1;
}
function tt(e, t) {
  var r = t.doc, n = t.mirror, o = t.blockClass, a = t.blockSelector, l = t.maskTextClass, c = t.maskTextSelector, s = t.inlineStylesheet, d = t.maskInputOptions, h = d === void 0 ? {} : d, b = t.maskTextFn, y = t.maskInputFn, M = t.dataURLOptions, m = M === void 0 ? {} : M, C = t.inlineImages, L = t.recordCanvas, D = t.keepIframeSrcFn, E = t.newlyAddedElement, S = E !== void 0 && E, x = function(p, k) {
    if (k.hasNode(p)) {
      var _ = k.getId(p);
      return _ === 1 ? void 0 : _;
    }
  }(r, n);
  switch (e.nodeType) {
    case e.DOCUMENT_NODE:
      return e.compatMode !== "CSS1Compat" ? { type: g.Document, childNodes: [], compatMode: e.compatMode } : { type: g.Document, childNodes: [] };
    case e.DOCUMENT_TYPE_NODE:
      return { type: g.DocumentType, name: e.name, publicId: e.publicId, systemId: e.systemId, rootId: x };
    case e.ELEMENT_NODE:
      return function(p, k) {
        for (var _ = k.doc, F = k.blockClass, j = k.blockSelector, B = k.inlineStylesheet, u = k.maskInputOptions, i = u === void 0 ? {} : u, v = k.maskInputFn, w = k.dataURLOptions, I = w === void 0 ? {} : w, W = k.inlineImages, de = k.recordCanvas, be = k.keepIframeSrcFn, ae = k.newlyAddedElement, J = ae !== void 0 && ae, q = k.rootId, R = function(P, H, ee) {
          try {
            if (typeof H == "string") {
              if (P.classList.contains(H))
                return !0;
            } else
              for (var te = P.classList.length; te--; ) {
                var ie = P.classList[te];
                if (H.test(ie))
                  return !0;
              }
            if (ee)
              return P.matches(ee);
          } catch (Me) {
          }
          return !1;
        }(p, F, j), A = function(P) {
          if (P instanceof HTMLFormElement)
            return "form";
          var H = ye(P.tagName);
          return He.test(H) ? "div" : H;
        }(p), T = {}, pe = p.attributes.length, K = 0; K < pe; K++) {
          var Y = p.attributes[K];
          Ze(A, Y.name, Y.value) || (T[Y.name] = Qe(_, A, ye(Y.name), Y.value));
        }
        if (A === "link" && B) {
          var Q = Array.from(_.styleSheets).find(function(P) {
            return P.href === p.href;
          }), $ = null;
          Q && ($ = he(Q)), $ && (delete T.rel, delete T.href, T._cssText = ve($, Q.href));
        }
        if (A === "style" && p.sheet && !(p.innerText || p.textContent || "").trim().length && ($ = he(p.sheet)) && (T._cssText = ve($, Se())), A === "input" || A === "textarea" || A === "select") {
          var z = p.value, f = p.checked;
          if (T.type !== "radio" && T.type !== "checkbox" && T.type !== "submit" && T.type !== "button" && z) {
            var O = Be(p);
            T.value = je({ element: p, type: O, tagName: A, value: z, maskInputOptions: i, maskInputFn: v });
          } else
            f && (T.checked = f);
        }
        if (A === "option" && (p.selected && !i.select ? T.selected = !0 : delete T.selected), A === "canvas" && de) {
          if (p.__context === "2d")
            (function(P) {
              var H = P.getContext("2d");
              if (!H)
                return !0;
              for (var ee = 0; ee < P.width; ee += 50)
                for (var te = 0; te < P.height; te += 50) {
                  var ie = H.getImageData, Me = Ne in ie ? ie[Ne] : ie;
                  if (new Uint32Array(Me.call(H, ee, te, Math.min(50, P.width - ee), Math.min(50, P.height - te)).data.buffer).some(function(Pe) {
                    return Pe !== 0;
                  }))
                    return !1;
                }
              return !0;
            })(p) || (T.rr_dataURL = p.toDataURL(I.type, I.quality));
          else if (!("__context" in p)) {
            var re = p.toDataURL(I.type, I.quality), G = document.createElement("canvas");
            G.width = p.width, G.height = p.height, re !== G.toDataURL(I.type, I.quality) && (T.rr_dataURL = re);
          }
        }
        if (A === "img" && W) {
          ne || (ne = _.createElement("canvas"), xe = ne.getContext("2d"));
          var U = p, X = U.crossOrigin;
          U.crossOrigin = "anonymous";
          var Z = function() {
            U.removeEventListener("load", Z);
            try {
              ne.width = U.naturalWidth, ne.height = U.naturalHeight, xe.drawImage(U, 0, 0), T.rr_dataURL = ne.toDataURL(I.type, I.quality);
            } catch (P) {
              console.warn("Cannot inline img src=".concat(U.currentSrc, "! Error: ").concat(P));
            }
            X ? T.crossOrigin = X : U.removeAttribute("crossorigin");
          };
          U.complete && U.naturalWidth !== 0 ? Z() : U.addEventListener("load", Z);
        }
        if (A !== "audio" && A !== "video" || (T.rr_mediaState = p.paused ? "paused" : "played", T.rr_mediaCurrentTime = p.currentTime), J || (p.scrollLeft && (T.rr_scrollLeft = p.scrollLeft), p.scrollTop && (T.rr_scrollTop = p.scrollTop)), R) {
          var fe = p.getBoundingClientRect(), Ee = fe.width, Ue = fe.height;
          T = { class: T.class, rr_width: "".concat(Ee, "px"), rr_height: "".concat(Ue, "px") };
        }
        return A !== "iframe" || be(T.src) || (p.contentDocument || (T.rr_src = T.src), delete T.src), { type: g.Element, tagName: A, attributes: T, childNodes: [], isSVG: Ke(p) || void 0, needBlock: R, rootId: q };
      }(e, { doc: r, blockClass: o, blockSelector: a, inlineStylesheet: s, maskInputOptions: h, maskInputFn: y, dataURLOptions: m, inlineImages: C, recordCanvas: L, keepIframeSrcFn: D, newlyAddedElement: S, rootId: x });
    case e.TEXT_NODE:
      return function(p, k) {
        var _, F = k.maskTextClass, j = k.maskTextSelector, B = k.maskTextFn, u = k.rootId, i = p.parentNode && p.parentNode.tagName, v = p.textContent, w = i === "STYLE" || void 0, I = i === "SCRIPT" || void 0;
        if (w && v) {
          try {
            p.nextSibling || p.previousSibling || !((_ = p.parentNode.sheet) === null || _ === void 0) && _.cssRules && (v = he(p.parentNode.sheet));
          } catch (W) {
            console.warn("Cannot get CSS styles from text's parentNode. Error: ".concat(W), p);
          }
          v = ve(v, Se());
        }
        return I && (v = "SCRIPT_PLACEHOLDER"), !w && !I && v && et(p, F, j) && (v = B ? B(v) : v.replace(/[\S]/g, "*")), { type: g.Text, textContent: v || "", isStyle: w, rootId: u };
      }(e, { maskTextClass: l, maskTextSelector: c, maskTextFn: b, rootId: x });
    case e.CDATA_SECTION_NODE:
      return { type: g.CDATA, textContent: "", rootId: x };
    case e.COMMENT_NODE:
      return { type: g.Comment, textContent: e.textContent || "", rootId: x };
    default:
      return !1;
  }
}
function N(e) {
  return e == null ? "" : e.toLowerCase();
}
function ce(e, t) {
  var r, n = t.doc, o = t.mirror, a = t.blockClass, l = t.blockSelector, c = t.maskTextClass, s = t.maskTextSelector, d = t.skipChild, h = d !== void 0 && d, b = t.inlineStylesheet, y = b === void 0 || b, M = t.maskInputOptions, m = M === void 0 ? {} : M, C = t.maskTextFn, L = t.maskInputFn, D = t.slimDOMOptions, E = t.dataURLOptions, S = E === void 0 ? {} : E, x = t.inlineImages, p = x !== void 0 && x, k = t.recordCanvas, _ = k !== void 0 && k, F = t.onSerialize, j = t.onIframeLoad, B = t.iframeLoadTimeout, u = B === void 0 ? 5e3 : B, i = t.onStylesheetLoad, v = t.stylesheetLoadTimeout, w = v === void 0 ? 5e3 : v, I = t.keepIframeSrcFn, W = I === void 0 ? function() {
    return !1;
  } : I, de = t.newlyAddedElement, be = de !== void 0 && de, ae = t.preserveWhiteSpace, J = ae === void 0 || ae, q = tt(e, { doc: n, mirror: o, blockClass: a, blockSelector: l, maskTextClass: c, maskTextSelector: s, inlineStylesheet: y, maskInputOptions: m, maskTextFn: C, maskInputFn: L, dataURLOptions: S, inlineImages: p, recordCanvas: _, keepIframeSrcFn: W, newlyAddedElement: be });
  if (!q)
    return console.warn(e, "not serialized"), null;
  r = o.hasNode(e) ? o.getId(e) : !function(f, O) {
    return !!(O.comment && f.type === g.Comment || f.type === g.Element && (O.script && (f.tagName === "script" || f.tagName === "link" && (f.attributes.rel === "preload" || f.attributes.rel === "modulepreload") && f.attributes.as === "script" || f.tagName === "link" && f.attributes.rel === "prefetch" && typeof f.attributes.href == "string" && f.attributes.href.endsWith(".js")) || O.headFavicon && (f.tagName === "link" && f.attributes.rel === "shortcut icon" || f.tagName === "meta" && (N(f.attributes.name).match(/^msapplication-tile(image|color)$/) || N(f.attributes.name) === "application-name" || N(f.attributes.rel) === "icon" || N(f.attributes.rel) === "apple-touch-icon" || N(f.attributes.rel) === "shortcut icon")) || f.tagName === "meta" && (O.headMetaDescKeywords && N(f.attributes.name).match(/^description|keywords$/) || O.headMetaSocial && (N(f.attributes.property).match(/^(og|twitter|fb):/) || N(f.attributes.name).match(/^(og|twitter):/) || N(f.attributes.name) === "pinterest") || O.headMetaRobots && (N(f.attributes.name) === "robots" || N(f.attributes.name) === "googlebot" || N(f.attributes.name) === "bingbot") || O.headMetaHttpEquiv && f.attributes["http-equiv"] !== void 0 || O.headMetaAuthorship && (N(f.attributes.name) === "author" || N(f.attributes.name) === "generator" || N(f.attributes.name) === "framework" || N(f.attributes.name) === "publisher" || N(f.attributes.name) === "progid" || N(f.attributes.property).match(/^article:/) || N(f.attributes.property).match(/^product:/)) || O.headMetaVerification && (N(f.attributes.name) === "google-site-verification" || N(f.attributes.name) === "yandex-verification" || N(f.attributes.name) === "csrf-token" || N(f.attributes.name) === "p:domain_verify" || N(f.attributes.name) === "verify-v1" || N(f.attributes.name) === "verification" || N(f.attributes.name) === "shopify-checkout-api-token"))));
  }(q, D) && (J || q.type !== g.Text || q.isStyle || q.textContent.replace(/^\s+|\s+$/gm, "").length) ? Ve() : we;
  var R = Object.assign(q, { id: r });
  if (o.add(e, R), r === we)
    return null;
  F && F(e);
  var A = !h;
  if (R.type === g.Element) {
    A = A && !R.needBlock, delete R.needBlock;
    var T = e.shadowRoot;
    T && ke(T) && (R.isShadowHost = !0);
  }
  if ((R.type === g.Document || R.type === g.Element) && A) {
    D.headWhitespace && R.type === g.Element && R.tagName === "head" && (J = !1);
    for (var pe = { doc: n, mirror: o, blockClass: a, blockSelector: l, maskTextClass: c, maskTextSelector: s, skipChild: h, inlineStylesheet: y, maskInputOptions: m, maskTextFn: C, maskInputFn: L, slimDOMOptions: D, dataURLOptions: S, inlineImages: p, recordCanvas: _, preserveWhiteSpace: J, onSerialize: F, onIframeLoad: j, iframeLoadTimeout: u, onStylesheetLoad: i, stylesheetLoadTimeout: w, keepIframeSrcFn: W }, K = 0, Y = Array.from(e.childNodes); K < Y.length; K++)
      (z = ce(Y[K], pe)) && R.childNodes.push(z);
    if (Re(e) && e.shadowRoot)
      for (var Q = 0, $ = Array.from(e.shadowRoot.childNodes); Q < $.length; Q++) {
        var z;
        (z = ce($[Q], pe)) && (ke(e.shadowRoot) && (z.isShadow = !0), R.childNodes.push(z));
      }
  }
  return e.parentNode && _e(e.parentNode) && ke(e.parentNode) && (R.isShadow = !0), R.type === g.Element && R.tagName === "iframe" && function(f, O, re) {
    var G = f.contentWindow;
    if (G) {
      var U, X = !1;
      try {
        U = G.document.readyState;
      } catch (Ee) {
        return;
      }
      if (U === "complete") {
        var Z = "about:blank";
        if (G.location.href !== Z || f.src === Z || f.src === "")
          return setTimeout(O, 0), f.addEventListener("load", O);
        f.addEventListener("load", O);
      } else {
        var fe = setTimeout(function() {
          X || (O(), X = !0);
        }, re);
        f.addEventListener("load", function() {
          clearTimeout(fe), X = !0, O();
        });
      }
    }
  }(e, function() {
    var f = e.contentDocument;
    if (f && j) {
      var O = ce(f, { doc: f, mirror: o, blockClass: a, blockSelector: l, maskTextClass: c, maskTextSelector: s, skipChild: !1, inlineStylesheet: y, maskInputOptions: m, maskTextFn: C, maskInputFn: L, slimDOMOptions: D, dataURLOptions: S, inlineImages: p, recordCanvas: _, preserveWhiteSpace: J, onSerialize: F, onIframeLoad: j, iframeLoadTimeout: u, onStylesheetLoad: i, stylesheetLoadTimeout: w, keepIframeSrcFn: W });
      O && j(e, O);
    }
  }, u), R.type === g.Element && R.tagName === "link" && R.attributes.rel === "stylesheet" && function(f, O, re) {
    var G, U = !1;
    try {
      G = f.sheet;
    } catch (Z) {
      return;
    }
    if (!G) {
      var X = setTimeout(function() {
        U || (O(), U = !0);
      }, re);
      f.addEventListener("load", function() {
        clearTimeout(X), U = !0, O();
      });
    }
  }(e, function() {
    if (i) {
      var f = ce(e, { doc: n, mirror: o, blockClass: a, blockSelector: l, maskTextClass: c, maskTextSelector: s, skipChild: !1, inlineStylesheet: y, maskInputOptions: m, maskTextFn: C, maskInputFn: L, slimDOMOptions: D, dataURLOptions: S, inlineImages: p, recordCanvas: _, preserveWhiteSpace: J, onSerialize: F, onIframeLoad: j, iframeLoadTimeout: u, onStylesheetLoad: i, stylesheetLoadTimeout: w, keepIframeSrcFn: W });
      f && i(e, f);
    }
  }, w), R;
}
function kt(e, t) {
  var r = t || {}, n = r.mirror, o = n === void 0 ? new Ce() : n, a = r.blockClass, l = a === void 0 ? "rr-block" : a, c = r.blockSelector, s = c === void 0 ? null : c, d = r.maskTextClass, h = d === void 0 ? "rr-mask" : d, b = r.maskTextSelector, y = b === void 0 ? null : b, M = r.inlineStylesheet, m = M === void 0 || M, C = r.inlineImages, L = C !== void 0 && C, D = r.recordCanvas, E = D !== void 0 && D, S = r.maskAllInputs, x = S !== void 0 && S, p = r.maskTextFn, k = r.maskInputFn, _ = r.slimDOM, F = _ !== void 0 && _, j = r.dataURLOptions, B = r.preserveWhiteSpace, u = r.onSerialize, i = r.onIframeLoad, v = r.iframeLoadTimeout, w = r.onStylesheetLoad, I = r.stylesheetLoadTimeout, W = r.keepIframeSrcFn;
  return ce(e, { doc: e, mirror: o, blockClass: l, blockSelector: s, maskTextClass: h, maskTextSelector: y, skipChild: !1, inlineStylesheet: m, maskInputOptions: x === !0 ? { color: !0, date: !0, "datetime-local": !0, email: !0, month: !0, number: !0, range: !0, search: !0, tel: !0, text: !0, time: !0, url: !0, week: !0, textarea: !0, select: !0, password: !0 } : x === !1 ? { password: !0 } : x, maskTextFn: p, maskInputFn: k, slimDOMOptions: F === !0 || F === "all" ? { script: !0, comment: !0, headFavicon: !0, headWhitespace: !0, headMetaDescKeywords: F === "all", headMetaSocial: !0, headMetaRobots: !0, headMetaHttpEquiv: !0, headMetaAuthorship: !0, headMetaVerification: !0 } : F === !1 ? {} : F, dataURLOptions: j, inlineImages: L, recordCanvas: E, preserveWhiteSpace: B, onSerialize: u, onIframeLoad: i, iframeLoadTimeout: v, onStylesheetLoad: w, stylesheetLoadTimeout: I, keepIframeSrcFn: W === void 0 ? function() {
    return !1;
  } : W, newlyAddedElement: !1 });
}
var Ie = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g;
function rt(e, t) {
  t === void 0 && (t = {});
  var r = 1, n = 1;
  function o(u) {
    var i = u.match(/\n/g);
    i && (r += i.length);
    var v = u.lastIndexOf(`
`);
    n = v === -1 ? n + u.length : u.length - v;
  }
  function a() {
    var u = { line: r, column: n };
    return function(i) {
      return i.position = new l(u), M(), i;
    };
  }
  var l = function(u) {
    this.start = u, this.end = { line: r, column: n }, this.source = t.source;
  };
  l.prototype.content = e;
  var c = [];
  function s(u) {
    var i = new Error("".concat(t.source || "", ":").concat(r, ":").concat(n, ": ").concat(u));
    if (i.reason = u, i.filename = t.source, i.line = r, i.column = n, i.source = e, !t.silent)
      throw i;
    c.push(i);
  }
  function d() {
    return y(/^{\s*/);
  }
  function h() {
    return y(/^}/);
  }
  function b() {
    var u, i = [];
    for (M(), m(i); e.length && e.charAt(0) !== "}" && (u = j() || B()); )
      u && (i.push(u), m(i));
    return i;
  }
  function y(u) {
    var i = u.exec(e);
    if (i) {
      var v = i[0];
      return o(v), e = e.slice(v.length), i;
    }
  }
  function M() {
    y(/^\s*/);
  }
  function m(u) {
    var i;
    for (u === void 0 && (u = []); i = C(); )
      i && u.push(i), i = C();
    return u;
  }
  function C() {
    var u = a();
    if (e.charAt(0) === "/" && e.charAt(1) === "*") {
      for (var i = 2; e.charAt(i) !== "" && (e.charAt(i) !== "*" || e.charAt(i + 1) !== "/"); )
        ++i;
      if (i += 2, e.charAt(i - 1) === "")
        return s("End of comment missing");
      var v = e.slice(2, i - 2);
      return n += 2, o(v), e = e.slice(i), n += 2, u({ type: "comment", comment: v });
    }
  }
  function L() {
    var u = y(/^([^{]+)/);
    if (u)
      return V(u[0]).replace(/\/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*\/+/g, "").replace(/"(?:\\"|[^"])*"|'(?:\\'|[^'])*'/g, function(i) {
        return i.replace(/,/g, "‌");
      }).split(/\s*(?![^(]*\)),\s*/).map(function(i) {
        return i.replace(/\u200C/g, ",");
      });
  }
  function D() {
    var u = a(), i = y(/^(\*?[-#\/\*\\\w]+(\[[0-9a-z_-]+\])?)\s*/);
    if (i) {
      var v = V(i[0]);
      if (!y(/^:\s*/))
        return s("property missing ':'");
      var w = y(/^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^\)]*?\)|[^};])+)/), I = u({ type: "declaration", property: v.replace(Ie, ""), value: w ? V(w[0]).replace(Ie, "") : "" });
      return y(/^[;\s]*/), I;
    }
  }
  function E() {
    var u, i = [];
    if (!d())
      return s("missing '{'");
    for (m(i); u = D(); )
      u !== !1 && (i.push(u), m(i)), u = D();
    return h() ? i : s("missing '}'");
  }
  function S() {
    for (var u, i = [], v = a(); u = y(/^((\d+\.\d+|\.\d+|\d+)%?|[a-z]+)\s*/); )
      i.push(u[1]), y(/^,\s*/);
    if (i.length)
      return v({ type: "keyframe", values: i, declarations: E() });
  }
  var x, p = F("import"), k = F("charset"), _ = F("namespace");
  function F(u) {
    var i = new RegExp("^@" + u + "\\s*([^;]+);");
    return function() {
      var v = a(), w = y(i);
      if (w) {
        var I = { type: u };
        return I[u] = w[1].trim(), v(I);
      }
    };
  }
  function j() {
    if (e[0] === "@")
      return function() {
        var u = a(), i = y(/^@([-\w]+)?keyframes\s*/);
        if (i) {
          var v = i[1];
          if (!(i = y(/^([-\w]+)\s*/)))
            return s("@keyframes missing name");
          var w, I = i[1];
          if (!d())
            return s("@keyframes missing '{'");
          for (var W = m(); w = S(); )
            W.push(w), W = W.concat(m());
          return h() ? u({ type: "keyframes", name: I, vendor: v, keyframes: W }) : s("@keyframes missing '}'");
        }
      }() || function() {
        var u = a(), i = y(/^@media *([^{]+)/);
        if (i) {
          var v = V(i[1]);
          if (!d())
            return s("@media missing '{'");
          var w = m().concat(b());
          return h() ? u({ type: "media", media: v, rules: w }) : s("@media missing '}'");
        }
      }() || function() {
        var u = a(), i = y(/^@custom-media\s+(--[^\s]+)\s*([^{;]+);/);
        if (i)
          return u({ type: "custom-media", name: V(i[1]), media: V(i[2]) });
      }() || function() {
        var u = a(), i = y(/^@supports *([^{]+)/);
        if (i) {
          var v = V(i[1]);
          if (!d())
            return s("@supports missing '{'");
          var w = m().concat(b());
          return h() ? u({ type: "supports", supports: v, rules: w }) : s("@supports missing '}'");
        }
      }() || p() || k() || _() || function() {
        var u = a(), i = y(/^@([-\w]+)?document *([^{]+)/);
        if (i) {
          var v = V(i[1]), w = V(i[2]);
          if (!d())
            return s("@document missing '{'");
          var I = m().concat(b());
          return h() ? u({ type: "document", document: w, vendor: v, rules: I }) : s("@document missing '}'");
        }
      }() || function() {
        var u = a();
        if (y(/^@page */)) {
          var i = L() || [];
          if (!d())
            return s("@page missing '{'");
          for (var v, w = m(); v = D(); )
            w.push(v), w = w.concat(m());
          return h() ? u({ type: "page", selectors: i, declarations: w }) : s("@page missing '}'");
        }
      }() || function() {
        var u = a();
        if (y(/^@host\s*/)) {
          if (!d())
            return s("@host missing '{'");
          var i = m().concat(b());
          return h() ? u({ type: "host", rules: i }) : s("@host missing '}'");
        }
      }() || function() {
        var u = a();
        if (y(/^@font-face\s*/)) {
          if (!d())
            return s("@font-face missing '{'");
          for (var i, v = m(); i = D(); )
            v.push(i), v = v.concat(m());
          return h() ? u({ type: "font-face", declarations: v }) : s("@font-face missing '}'");
        }
      }();
  }
  function B() {
    var u = a(), i = L();
    return i ? (m(), u({ type: "rule", selectors: i, declarations: E() })) : s("selector missing");
  }
  return Te((x = b(), { type: "stylesheet", stylesheet: { source: t.source, rules: x, parsingErrors: c } }));
}
function V(e) {
  return e ? e.replace(/^\s+|\s+$/g, "") : "";
}
function Te(e, t) {
  for (var r = e && typeof e.type == "string", n = r ? e : t, o = 0, a = Object.keys(e); o < a.length; o++) {
    var l = e[a[o]];
    Array.isArray(l) ? l.forEach(function(c) {
      Te(c, n);
    }) : l && typeof l == "object" && Te(l, n);
  }
  return r && Object.defineProperty(e, "parent", { configurable: !0, writable: !0, enumerable: !1, value: t || null }), e;
}
var Le = { script: "noscript", altglyph: "altGlyph", altglyphdef: "altGlyphDef", altglyphitem: "altGlyphItem", animatecolor: "animateColor", animatemotion: "animateMotion", animatetransform: "animateTransform", clippath: "clipPath", feblend: "feBlend", fecolormatrix: "feColorMatrix", fecomponenttransfer: "feComponentTransfer", fecomposite: "feComposite", feconvolvematrix: "feConvolveMatrix", fediffuselighting: "feDiffuseLighting", fedisplacementmap: "feDisplacementMap", fedistantlight: "feDistantLight", fedropshadow: "feDropShadow", feflood: "feFlood", fefunca: "feFuncA", fefuncb: "feFuncB", fefuncg: "feFuncG", fefuncr: "feFuncR", fegaussianblur: "feGaussianBlur", feimage: "feImage", femerge: "feMerge", femergenode: "feMergeNode", femorphology: "feMorphology", feoffset: "feOffset", fepointlight: "fePointLight", fespecularlighting: "feSpecularLighting", fespotlight: "feSpotLight", fetile: "feTile", feturbulence: "feTurbulence", foreignobject: "foreignObject", glyphref: "glyphRef", lineargradient: "linearGradient", radialgradient: "radialGradient" }, Fe = /([^\\]):hover/, nt = new RegExp(Fe.source, "g");
function De(e, t) {
  var r = t == null ? void 0 : t.stylesWithHoverClass.get(e);
  if (r)
    return r;
  var n = rt(e, { silent: !0 });
  if (!n.stylesheet)
    return e;
  var o = [];
  if (n.stylesheet.rules.forEach(function(c) {
    "selectors" in c && (c.selectors || []).forEach(function(s) {
      Fe.test(s) && o.push(s);
    });
  }), o.length === 0)
    return e;
  var a = new RegExp(o.filter(function(c, s) {
    return o.indexOf(c) === s;
  }).sort(function(c, s) {
    return s.length - c.length;
  }).map(function(c) {
    return c.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }).join("|"), "g"), l = e.replace(a, function(c) {
    var s = c.replace(nt, "$1.\\:hover");
    return "".concat(c, ", ").concat(s);
  });
  return t == null || t.stylesWithHoverClass.set(e, l), l;
}
function wt() {
  return { stylesWithHoverClass: /* @__PURE__ */ new Map() };
}
function ot(e, t) {
  var r = t.doc, n = t.hackCss, o = t.cache;
  switch (e.type) {
    case g.Document:
      return r.implementation.createDocument(null, "", null);
    case g.DocumentType:
      return r.implementation.createDocumentType(e.name || "html", e.publicId, e.systemId);
    case g.Element:
      var a, l = function(E) {
        var S = Le[E.tagName] ? Le[E.tagName] : E.tagName;
        return S === "link" && E.attributes._cssText && (S = "style"), S;
      }(e);
      a = e.isSVG ? r.createElementNS("http://www.w3.org/2000/svg", l) : r.createElement(l);
      var c = {};
      for (var s in e.attributes)
        if (Object.prototype.hasOwnProperty.call(e.attributes, s)) {
          var d = e.attributes[s];
          if ((l !== "option" || s !== "selected" || d !== !1) && d !== null)
            if (d === !0 && (d = ""), s.startsWith("rr_"))
              c[s] = d;
            else {
              var h = l === "textarea" && s === "value", b = l === "style" && s === "_cssText";
              if (b && n && typeof d == "string" && (d = De(d, o)), !h && !b || typeof d != "string")
                try {
                  if (e.isSVG && s === "xlink:href")
                    a.setAttributeNS("http://www.w3.org/1999/xlink", s, d.toString());
                  else if (s === "onload" || s === "onclick" || s.substring(0, 7) === "onmouse")
                    a.setAttribute("_" + s, d.toString());
                  else {
                    if (l === "meta" && e.attributes["http-equiv"] === "Content-Security-Policy" && s === "content") {
                      a.setAttribute("csp-content", d.toString());
                      continue;
                    }
                    (l !== "link" || e.attributes.rel !== "preload" && e.attributes.rel !== "modulepreload" || e.attributes.as !== "script") && (l === "link" && e.attributes.rel === "prefetch" && typeof e.attributes.href == "string" && e.attributes.href.endsWith(".js") || (l === "img" && e.attributes.srcset && e.attributes.rr_dataURL ? a.setAttribute("rrweb-original-srcset", e.attributes.srcset) : a.setAttribute(s, d.toString())));
                  }
                } catch (E) {
                }
              else {
                for (var y = r.createTextNode(d), M = 0, m = Array.from(a.childNodes); M < m.length; M++) {
                  var C = m[M];
                  C.nodeType === a.TEXT_NODE && a.removeChild(C);
                }
                a.appendChild(y);
              }
            }
        }
      var L = function(E) {
        var S = c[E];
        if (l === "canvas" && E === "rr_dataURL") {
          var x = document.createElement("img");
          x.onload = function() {
            var k = a.getContext("2d");
            k && k.drawImage(x, 0, 0, x.width, x.height);
          }, x.src = S.toString(), a.RRNodeType && (a.rr_dataURL = S.toString());
        } else if (l === "img" && E === "rr_dataURL") {
          var p = a;
          p.currentSrc.startsWith("data:") || (p.setAttribute("rrweb-original-src", e.attributes.src), p.src = S.toString());
        }
        if (E === "rr_width")
          a.style.width = S.toString();
        else if (E === "rr_height")
          a.style.height = S.toString();
        else if (E === "rr_mediaCurrentTime" && typeof S == "number")
          a.currentTime = S;
        else if (E === "rr_mediaState")
          switch (S) {
            case "played":
              a.play().catch(function(k) {
                return console.warn("media playback error", k);
              });
              break;
            case "paused":
              a.pause();
          }
      };
      for (var D in c)
        L(D);
      if (e.isShadowHost)
        if (a.shadowRoot)
          for (; a.shadowRoot.firstChild; )
            a.shadowRoot.removeChild(a.shadowRoot.firstChild);
        else
          a.attachShadow({ mode: "open" });
      return a;
    case g.Text:
      return r.createTextNode(e.isStyle && n ? De(e.textContent, o) : e.textContent);
    case g.CDATA:
      return r.createCDATASection(e.textContent);
    case g.Comment:
      return r.createComment(e.textContent);
    default:
      return null;
  }
}
function Ae(e, t) {
  var r, n, o = t.doc, a = t.mirror, l = t.skipChild, c = l !== void 0 && l, s = t.hackCss, d = s === void 0 || s, h = t.afterAppend, b = t.cache;
  if (a.has(e.id)) {
    var y = a.getNode(e.id), M = a.getMeta(y);
    if (n = e, (r = M) && n && r.type === n.type && (r.type === g.Document ? r.compatMode === n.compatMode : r.type === g.DocumentType ? r.name === n.name && r.publicId === n.publicId && r.systemId === n.systemId : r.type === g.Comment || r.type === g.Text || r.type === g.CDATA ? r.textContent === n.textContent : r.type === g.Element && r.tagName === n.tagName && JSON.stringify(r.attributes) === JSON.stringify(n.attributes) && r.isSVG === n.isSVG && r.needBlock === n.needBlock))
      return a.getNode(e.id);
  }
  var m = ot(e, { doc: o, hackCss: d, cache: b });
  if (!m)
    return null;
  if (e.rootId && a.getNode(e.rootId) !== o && a.replace(e.rootId, o), e.type === g.Document && (o.close(), o.open(), e.compatMode === "BackCompat" && e.childNodes && e.childNodes[0].type !== g.DocumentType && (e.childNodes[0].type === g.Element && "xmlns" in e.childNodes[0].attributes && e.childNodes[0].attributes.xmlns === "http://www.w3.org/1999/xhtml" ? o.write('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "">') : o.write('<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "">')), m = o), a.add(m, e), (e.type === g.Document || e.type === g.Element) && !c)
    for (var C = function(E) {
      var S = Ae(E, { doc: o, mirror: a, skipChild: !1, hackCss: d, afterAppend: h, cache: b });
      if (!S)
        return console.warn("Failed to rebuild", E), "continue";
      if (E.isShadow && Re(m) && m.shadowRoot)
        m.shadowRoot.appendChild(S);
      else if (e.type === g.Document && E.type == g.Element) {
        var x = S, p = null;
        x.childNodes.forEach(function(k) {
          k.nodeName === "BODY" && (p = k);
        }), p ? (x.removeChild(p), m.appendChild(S), x.appendChild(p)) : m.appendChild(S);
      } else
        m.appendChild(S);
      h && h(S, E.id);
    }, L = 0, D = e.childNodes; L < D.length; L++)
      C(D[L]);
  return m;
}
function St(e, t) {
  var r = t.doc, n = t.onVisit, o = t.hackCss, a = o === void 0 || o, l = t.afterAppend, c = t.cache, s = t.mirror, d = s === void 0 ? new Ce() : s, h = Ae(e, { doc: r, mirror: d, skipChild: !1, hackCss: a, afterAppend: l, cache: c });
  return function(b, y) {
    for (var M = 0, m = b.getIds(); M < m.length; M++) {
      var C = m[M];
      b.has(C) && y(b.getNode(C));
    }
  }(d, function(b) {
    n && n(b), function(y, M) {
      var m = M.getMeta(y);
      if ((m == null ? void 0 : m.type) === g.Element) {
        var C = y;
        for (var L in m.attributes)
          if (Object.prototype.hasOwnProperty.call(m.attributes, L) && L.startsWith("rr_")) {
            var D = m.attributes[L];
            L === "rr_scrollLeft" && (C.scrollLeft = D), L === "rr_scrollTop" && (C.scrollTop = D);
          }
      }
    }(b, d);
  }), h;
}
function Tt(e, t, r = document) {
  const n = { capture: !0, passive: !0 };
  return r.addEventListener(e, t, n), () => r.removeEventListener(e, t, n);
}
const oe = `Please stop import mirror directly. Instead of that,\r
now you can use replayer.getMirror() to access the mirror instance of a replayer,\r
or you can use record.mirror to access the mirror instance during recording.`;
let Oe = { map: {}, getId: () => (console.error(oe), -1), getNode: () => (console.error(oe), null), removeNodeFromMap() {
  console.error(oe);
}, has: () => (console.error(oe), !1), reset() {
  console.error(oe);
} };
function Ct(e, t, r = {}) {
  let n = null, o = 0;
  return function(...a) {
    const l = Date.now();
    o || r.leading !== !1 || (o = l);
    const c = t - (l - o), s = this;
    c <= 0 || c > t ? (n && (clearTimeout(n), n = null), o = l, e.apply(s, a)) : n || r.trailing === !1 || (n = setTimeout(() => {
      o = r.leading === !1 ? 0 : Date.now(), n = null, e.apply(s, a);
    }, c));
  };
}
function at(e, t, r, n, o = window) {
  const a = o.Object.getOwnPropertyDescriptor(e, t);
  return o.Object.defineProperty(e, t, n ? r : { set(l) {
    setTimeout(() => {
      r.set.call(this, l);
    }, 0), a && a.set && a.set.call(this, l);
  } }), () => at(e, t, a || {}, !0);
}
function Et(e, t, r) {
  try {
    if (!(t in e))
      return () => {
      };
    const n = e[t], o = r(n);
    return typeof o == "function" && (o.prototype = o.prototype || {}, Object.defineProperties(o, { __rrweb_original__: { enumerable: !1, value: n } })), e[t] = o, () => {
      e[t] = n;
    };
  } catch (n) {
    return () => {
    };
  }
}
typeof window != "undefined" && window.Proxy && window.Reflect && (Oe = new Proxy(Oe, { get: (e, t, r) => (t === "map" && console.error(oe), Reflect.get(e, t, r)) }));
let it = Date.now;
function Mt(e) {
  var t, r, n, o, a, l;
  const c = e.document;
  return { left: c.scrollingElement ? c.scrollingElement.scrollLeft : e.pageXOffset !== void 0 ? e.pageXOffset : (c == null ? void 0 : c.documentElement.scrollLeft) || ((r = (t = c == null ? void 0 : c.body) === null || t === void 0 ? void 0 : t.parentElement) === null || r === void 0 ? void 0 : r.scrollLeft) || ((n = c == null ? void 0 : c.body) === null || n === void 0 ? void 0 : n.scrollLeft) || 0, top: c.scrollingElement ? c.scrollingElement.scrollTop : e.pageYOffset !== void 0 ? e.pageYOffset : (c == null ? void 0 : c.documentElement.scrollTop) || ((a = (o = c == null ? void 0 : c.body) === null || o === void 0 ? void 0 : o.parentElement) === null || a === void 0 ? void 0 : a.scrollTop) || ((l = c == null ? void 0 : c.body) === null || l === void 0 ? void 0 : l.scrollTop) || 0 };
}
function Nt() {
  return window.innerHeight || document.documentElement && document.documentElement.clientHeight || document.body && document.body.clientHeight;
}
function xt() {
  return window.innerWidth || document.documentElement && document.documentElement.clientWidth || document.body && document.body.clientWidth;
}
function It(e, t, r, n) {
  if (!e)
    return !1;
  const o = e.nodeType === e.ELEMENT_NODE ? e : e.parentElement;
  if (!o)
    return !1;
  try {
    if (typeof t == "string") {
      if (o.classList.contains(t) || n && o.closest("." + t) !== null)
        return !0;
    } else if (ge(o, t, n))
      return !0;
  } catch (a) {
  }
  return !!(r && (o.matches(r) || n && o.closest(r) !== null));
}
function Lt(e, t) {
  return t.getId(e) !== -1;
}
function Dt(e, t) {
  return t.getId(e) === we;
}
function st(e, t) {
  if (_e(e))
    return !1;
  const r = t.getId(e);
  return !t.has(r) || (!e.parentNode || e.parentNode.nodeType !== e.DOCUMENT_NODE) && (!e.parentNode || st(e.parentNode, t));
}
function Ot(e) {
  return !!e.changedTouches;
}
function Rt(e = window) {
  "NodeList" in e && !e.NodeList.prototype.forEach && (e.NodeList.prototype.forEach = Array.prototype.forEach), "DOMTokenList" in e && !e.DOMTokenList.prototype.forEach && (e.DOMTokenList.prototype.forEach = Array.prototype.forEach), Node.prototype.contains || (Node.prototype.contains = (...t) => {
    let r = t[0];
    if (!(0 in t))
      throw new TypeError("1 argument is required");
    do
      if (this === r)
        return !0;
    while (r = r && r.parentNode);
    return !1;
  });
}
function _t(e) {
  const t = {}, r = (o, a) => {
    const l = { value: o, parent: a, children: [] };
    return t[o.node.id] = l, l;
  }, n = [];
  for (const o of e) {
    const { nextId: a, parentId: l } = o;
    if (a && a in t) {
      const c = t[a];
      if (c.parent) {
        const s = c.parent.children.indexOf(c);
        c.parent.children.splice(s, 0, r(o, c.parent));
      } else {
        const s = n.indexOf(c);
        n.splice(s, 0, r(o, null));
      }
    } else if (l in t) {
      const c = t[l];
      c.children.push(r(o, c));
    } else
      n.push(r(o, null));
  }
  return n;
}
function ct(e, t) {
  t(e.value);
  for (let r = e.children.length - 1; r >= 0; r--)
    ct(e.children[r], t);
}
function Ft(e, t) {
  return !!(e.nodeName === "IFRAME" && t.getMeta(e));
}
function At(e, t) {
  return !!(e.nodeName === "LINK" && e.nodeType === e.ELEMENT_NODE && e.getAttribute && e.getAttribute("rel") === "stylesheet" && t.getMeta(e));
}
function lt(e, t) {
  var r, n;
  const o = (n = (r = e.ownerDocument) === null || r === void 0 ? void 0 : r.defaultView) === null || n === void 0 ? void 0 : n.frameElement;
  if (!o || o === t)
    return { x: 0, y: 0, relativeScale: 1, absoluteScale: 1 };
  const a = o.getBoundingClientRect(), l = lt(o, t), c = a.height / o.clientHeight;
  return { x: a.x * l.relativeScale + l.x, y: a.y * l.relativeScale + l.y, relativeScale: c, absoluteScale: l.absoluteScale * c };
}
function Ut(e) {
  return !!(e != null && e.shadowRoot);
}
function ut(e, t) {
  const r = e[t[0]];
  return t.length === 1 ? r : ut(r.cssRules[t[1]].cssRules, t.slice(2));
}
function Pt(e) {
  const t = [...e], r = t.pop();
  return { positions: t, index: r };
}
function Wt(e) {
  const t = /* @__PURE__ */ new Set(), r = [];
  for (let n = e.length; n--; ) {
    const o = e[n];
    t.has(o.id) || (r.push(o), t.add(o.id));
  }
  return r;
}
/[1-9][0-9]{12}/.test(Date.now().toString()) || (it = () => (/* @__PURE__ */ new Date()).getTime());
class jt {
  constructor() {
    this.id = 1, this.styleIDMap = /* @__PURE__ */ new WeakMap(), this.idStyleMap = /* @__PURE__ */ new Map();
  }
  getId(t) {
    var r;
    return (r = this.styleIDMap.get(t)) !== null && r !== void 0 ? r : -1;
  }
  has(t) {
    return this.styleIDMap.has(t);
  }
  add(t, r) {
    if (this.has(t))
      return this.getId(t);
    let n;
    return n = r === void 0 ? this.id++ : r, this.styleIDMap.set(t, n), this.idStyleMap.set(n, t), n;
  }
  getStyle(t) {
    return this.idStyleMap.get(t) || null;
  }
  reset() {
    this.styleIDMap = /* @__PURE__ */ new WeakMap(), this.idStyleMap = /* @__PURE__ */ new Map(), this.id = 1;
  }
  generateId() {
    return this.id++;
  }
}
function dt(e) {
  var t, r;
  let n = null;
  return ((r = (t = e.getRootNode) === null || t === void 0 ? void 0 : t.call(e)) === null || r === void 0 ? void 0 : r.nodeType) === Node.DOCUMENT_FRAGMENT_NODE && e.getRootNode().host && (n = e.getRootNode().host), n;
}
function pt(e) {
  const t = e.ownerDocument;
  if (!t)
    return !1;
  const r = function(n) {
    let o, a = n;
    for (; o = dt(a); )
      a = o;
    return a;
  }(e);
  return t.contains(r);
}
function Bt(e) {
  const t = e.ownerDocument;
  return !!t && (t.contains(e) || pt(e));
}
var ft = ((e) => (e[e.DomContentLoaded = 0] = "DomContentLoaded", e[e.Load = 1] = "Load", e[e.FullSnapshot = 2] = "FullSnapshot", e[e.IncrementalSnapshot = 3] = "IncrementalSnapshot", e[e.Meta = 4] = "Meta", e[e.Custom = 5] = "Custom", e[e.Plugin = 6] = "Plugin", e))(ft || {}), mt = ((e) => (e[e.Mutation = 0] = "Mutation", e[e.MouseMove = 1] = "MouseMove", e[e.MouseInteraction = 2] = "MouseInteraction", e[e.Scroll = 3] = "Scroll", e[e.ViewportResize = 4] = "ViewportResize", e[e.Input = 5] = "Input", e[e.TouchMove = 6] = "TouchMove", e[e.MediaInteraction = 7] = "MediaInteraction", e[e.StyleSheetRule = 8] = "StyleSheetRule", e[e.CanvasMutation = 9] = "CanvasMutation", e[e.Font = 10] = "Font", e[e.Log = 11] = "Log", e[e.Drag = 12] = "Drag", e[e.StyleDeclaration = 13] = "StyleDeclaration", e[e.Selection = 14] = "Selection", e[e.AdoptedStyleSheet = 15] = "AdoptedStyleSheet", e))(mt || {}), ht = ((e) => (e[e.MouseUp = 0] = "MouseUp", e[e.MouseDown = 1] = "MouseDown", e[e.Click = 2] = "Click", e[e.ContextMenu = 3] = "ContextMenu", e[e.DblClick = 4] = "DblClick", e[e.Focus = 5] = "Focus", e[e.Blur = 6] = "Blur", e[e.TouchStart = 7] = "TouchStart", e[e.TouchMove_Departed = 8] = "TouchMove_Departed", e[e.TouchEnd = 9] = "TouchEnd", e[e.TouchCancel = 10] = "TouchCancel", e))(ht || {}), vt = ((e) => (e[e.Mouse = 0] = "Mouse", e[e.Pen = 1] = "Pen", e[e.Touch = 2] = "Touch", e))(vt || {}), yt = ((e) => (e[e["2D"] = 0] = "2D", e[e.WebGL = 1] = "WebGL", e[e.WebGL2 = 2] = "WebGL2", e))(yt || {}), gt = ((e) => (e.Start = "start", e.Pause = "pause", e.Resume = "resume", e.Resize = "resize", e.Finish = "finish", e.FullsnapshotRebuilded = "fullsnapshot-rebuilded", e.LoadStylesheetStart = "load-stylesheet-start", e.LoadStylesheetEnd = "load-stylesheet-end", e.SkipStart = "skip-start", e.SkipEnd = "skip-end", e.MouseInteraction = "mouse-interaction", e.EventCast = "event-cast", e.CustomEvent = "custom-event", e.Flush = "flush", e.StateChange = "state-change", e.PlayBack = "play-back", e.Destroy = "destroy", e))(gt || {});
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function Gt(e, t) {
  var r = {};
  for (var n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function") {
    var o = 0;
    for (n = Object.getOwnPropertySymbols(e); o < n.length; o++)
      t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]]);
  }
  return r;
}
function Ht(e, t, r, n) {
  return new (r || (r = Promise))(function(o, a) {
    function l(d) {
      try {
        s(n.next(d));
      } catch (h) {
        a(h);
      }
    }
    function c(d) {
      try {
        s(n.throw(d));
      } catch (h) {
        a(h);
      }
    }
    function s(d) {
      var h;
      d.done ? o(d.value) : (h = d.value, h instanceof r ? h : new r(function(b) {
        b(h);
      })).then(l, c);
    }
    s((n = n.apply(e, [])).next());
  });
}
for (var le = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", ue = typeof Uint8Array == "undefined" ? [] : new Uint8Array(256), me = 0; me < 64; me++)
  ue[le.charCodeAt(me)] = me;
var Vt = function(e) {
  var t, r = new Uint8Array(e), n = r.length, o = "";
  for (t = 0; t < n; t += 3)
    o += le[r[t] >> 2], o += le[(3 & r[t]) << 4 | r[t + 1] >> 4], o += le[(15 & r[t + 1]) << 2 | r[t + 2] >> 6], o += le[63 & r[t + 2]];
  return n % 3 == 2 ? o = o.substring(0, o.length - 1) + "=" : n % 3 == 1 && (o = o.substring(0, o.length - 2) + "=="), o;
}, qt = function(e) {
  var t, r, n, o, a, l = 0.75 * e.length, c = e.length, s = 0;
  e[e.length - 1] === "=" && (l--, e[e.length - 2] === "=" && l--);
  var d = new ArrayBuffer(l), h = new Uint8Array(d);
  for (t = 0; t < c; t += 4)
    r = ue[e.charCodeAt(t)], n = ue[e.charCodeAt(t + 1)], o = ue[e.charCodeAt(t + 2)], a = ue[e.charCodeAt(t + 3)], h[s++] = r << 2 | n >> 4, h[s++] = (15 & n) << 4 | o >> 2, h[s++] = (3 & o) << 6 | 63 & a;
  return d;
};
export {
  lt as $,
  Nt as A,
  xt as B,
  Ve as C,
  Vt as D,
  ft as E,
  yt as F,
  Ht as G,
  We as H,
  we as I,
  Rt as J,
  bt as K,
  kt as L,
  ht as M,
  g as N,
  qt as O,
  vt as P,
  wt as Q,
  gt as R,
  jt as S,
  St as T,
  Ae as U,
  _t as V,
  ct as W,
  Wt as X,
  Pt as Y,
  ut as Z,
  Gt as _,
  It as a,
  _e as b,
  Lt as c,
  st as d,
  ke as e,
  Ze as f,
  Be as g,
  ye as h,
  Dt as i,
  Ut as j,
  Bt as k,
  dt as l,
  je as m,
  et as n,
  Ft as o,
  At as p,
  Tt as q,
  Ct as r,
  ce as s,
  Qe as t,
  Mt as u,
  at as v,
  Et as w,
  Ot as x,
  it as y,
  mt as z
};
