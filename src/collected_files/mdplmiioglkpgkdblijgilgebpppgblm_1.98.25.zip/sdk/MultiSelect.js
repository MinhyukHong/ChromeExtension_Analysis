var v = (t, e, s) => new Promise((n, a) => {
  var l = (i) => {
    try {
      o(s.next(i));
    } catch (r) {
      a(r);
    }
  }, f = (i) => {
    try {
      o(s.throw(i));
    } catch (r) {
      a(r);
    }
  }, o = (i) => i.done ? n(i.value) : Promise.resolve(i.value).then(l, f);
  o((s = s.apply(t, e)).next());
});
import { withKeys as p, withModifiers as g } from "./vue.runtime.esm-bundler.js";
import { _ as y } from "./_plugin-vue_export-helper.js";
import { o as u, c, b as h, t as d, n as m, F as x, f as w, d as b, e as K } from "./runtime-core.esm-bundler.js";
const $ = ["aria-expanded"], k = { key: 0, class: "placeholder" }, O = { key: 1 }, T = { "aria-hidden": "", class: "caret" }, A = { class: "options-heading" }, C = { class: "option-label" }, H = ["id", "name", "checked", "value", "onKeydown", "onChange"], S = y({ name: "MultiSelect", props: { formInputName: { type: String, required: !0 }, placeholder: { type: String, default: "" }, values: { type: Array, required: !0 }, options: { type: Array, required: !0 } }, emits: ["update:values"], expose: ["close"], data: () => ({ isOpen: !1, inputHeight: "25px" }), computed: { selectedValueText() {
  var t;
  return (t = this.values) != null && t.length ? this.values.map((e) => this.options.find((s) => s.value === e)).map((e) => e.label).join(", ") : this.placeholder;
} }, watch: { isOpen(t) {
  return v(this, null, function* () {
    if (!t)
      return this.$refs.trigger.focus();
    yield this.$nextTick(), this.$refs.option0[0].focus();
  });
} }, methods: { onCheckboxToggle(t) {
  return v(this, null, function* () {
    const e = this.values.includes(t) ? [...this.values].filter((s) => s !== t) : [...this.values, t];
    this.$emit("update:values", e), yield this.$nextTick(), this.inputHeight = this.$refs.trigger.clientHeight + "px";
  });
}, onArrowUpKeyPress(t) {
  var s, n;
  let e = t - 1;
  if (e < 0)
    return this.isOpen = !1;
  (n = (s = this.$refs["option" + e]) == null ? void 0 : s[0]) == null || n.focus();
}, onArrowDownKeyPress(t) {
  var s, n;
  let e = t + 1;
  e === this.options.length && (e = 0), (n = (s = this.$refs["option" + e]) == null ? void 0 : s[0]) == null || n.focus();
}, close() {
  this.isOpen = !1;
} } }, [["render", function(t, e, s, n, a, l) {
  var f;
  return u(), c("div", { class: "multi-select", onKeydown: [e[2] || (e[2] = p(g((o) => a.isOpen = !1, ["stop"]), ["esc"])), e[3] || (e[3] = p(g((o) => a.isOpen = !0, ["stop"]), ["arrow-down"]))] }, [h("button", { ref: "trigger", role: "combobox", "aria-multiselectable": "", "aria-expanded": a.isOpen, "aria-haspopup": "", class: "trigger-button input", type: "button", onClick: e[0] || (e[0] = (o) => a.isOpen = !a.isOpen), onKeydown: e[1] || (e[1] = p(g(() => {
  }, ["prevent"]), ["enter"])) }, [(f = s.values) != null && f.length ? (u(), c("span", O, d(l.selectedValueText), 1)) : (u(), c("span", k, d(s.placeholder), 1)), h("span", T, d(a.isOpen ? ">" : "<"), 1)], 40, $), a.isOpen ? (u(), c("ul", { key: 0, class: "options", style: m({ bottom: a.inputHeight }) }, [h("li", A, d(s.placeholder), 1), (u(!0), c(x, null, w(s.options, (o, i) => (u(), c("li", { key: o.value, class: "option" }, [h("label", C, [h("input", { id: o.value, ref_for: !0, ref: "option" + i, name: s.formInputName, checked: s.values.includes(o.value), value: s.values.includes(o.value), type: "checkbox", class: "option-checkbox", onKeydown: [p((r) => l.onArrowUpKeyPress(i), ["arrow-up"]), p((r) => l.onArrowDownKeyPress(i), ["arrow-down"]), p(g((r) => l.onCheckboxToggle(o.value), ["stop", "prevent"]), ["enter"])], onChange: (r) => l.onCheckboxToggle(o.value) }, null, 40, H), b(" " + d(o.label), 1)])]))), 128))], 4)) : K("", !0)], 32);
}], ["__scopeId", "data-v-90c589fa"]]);
export {
  S as default
};
