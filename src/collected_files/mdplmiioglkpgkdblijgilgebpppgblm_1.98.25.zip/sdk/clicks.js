var r = (s, n, t) => new Promise((i, c) => {
  var u = (e) => {
    try {
      o(t.next(e));
    } catch (a) {
      c(a);
    }
  }, l = (e) => {
    try {
      o(t.throw(e));
    } catch (a) {
      c(a);
    }
  }, o = (e) => e.done ? i(e.value) : Promise.resolve(e.value).then(u, l);
  o((t = t.apply(s, n)).next());
});
import { b as f } from "./birdify.js";
import { i as p } from "./core.js";
function m() {
  document.removeEventListener("click", d, { passive: !0 });
}
function d(s) {
  var t;
  if (s.target.closest('[data-birdeatsbug="ignore"]'))
    return;
  const n = (t = window.birdeatsbug.session) == null ? void 0 : t.id;
  if (!n)
    return console.warn("click event captured without active session");
  (function(i) {
    return r(this, null, function* () {
      yield p.add("consoleEvents", i.detail);
    });
  })({ detail: { source: "document", type: "click", createdAt: (/* @__PURE__ */ new Date()).toISOString(), target: f(s.target), sessionId: n } });
}
const b = { start: function() {
  document.addEventListener("click", d, { passive: !0 });
}, stop: m };
export {
  b as default,
  m as stop
};
