var ut = Object.defineProperty;
var Ee = Object.getOwnPropertySymbols;
var ht = Object.prototype.hasOwnProperty, mt = Object.prototype.propertyIsEnumerable;
var Se = (t, e, o) => e in t ? ut(t, e, { enumerable: !0, configurable: !0, writable: !0, value: o }) : t[e] = o, we = (t, e) => {
  for (var o in e || (e = {}))
    ht.call(e, o) && Se(t, o, e[o]);
  if (Ee)
    for (var o of Ee(e))
      mt.call(e, o) && Se(t, o, e[o]);
  return t;
};
var A = (t, e, o) => new Promise((i, n) => {
  var s = (l) => {
    try {
      a(o.next(l));
    } catch (c) {
      n(c);
    }
  }, r = (l) => {
    try {
      a(o.throw(l));
    } catch (c) {
      n(c);
    }
  }, a = (l) => l.done ? i(l.value) : Promise.resolve(l.value).then(s, r);
  a((o = o.apply(t, e)).next());
});
import { W as pt, H as ft } from "./Watermark.js";
import { _ as V } from "./_plugin-vue_export-helper.js";
import { E as D, z as C, R as N, G as H, O as gt, F as ue, Q as Te, K as vt, S as yt, J as bt, T as Et, U as re, o as ae, h as St, M as R, j as Q, V as wt, W as Tt, X as Nt, N as W, Y as Ne, Z as K, $ as Ct } from "./base64-arraybuffer.es5.js";
import { o as S, c as T, n as Dt, b as I, r as L, t as x, e as O, d as $, a as _, i as J, F as U, j as je, f as Mt, k as Ce, m as Rt, l as xt, w as It } from "./runtime-core.esm-bundler.js";
import { withModifiers as De } from "./vue.runtime.esm-bundler.js";
import { C as Me, D as Re, E as He, F as ee } from "./core.js";
var E;
(function(t) {
  t[t.Document = 0] = "Document", t[t.DocumentType = 1] = "DocumentType", t[t.Element = 2] = "Element", t[t.Text = 3] = "Text", t[t.CDATA = 4] = "CDATA", t[t.Comment = 5] = "Comment";
})(E || (E = {}));
var kt = function() {
  function t() {
    this.idNodeMap = /* @__PURE__ */ new Map(), this.nodeMetaMap = /* @__PURE__ */ new WeakMap();
  }
  return t.prototype.getId = function(e) {
    var o;
    if (!e)
      return -1;
    var i = (o = this.getMeta(e)) === null || o === void 0 ? void 0 : o.id;
    return i != null ? i : -1;
  }, t.prototype.getNode = function(e) {
    return this.idNodeMap.get(e) || null;
  }, t.prototype.getIds = function() {
    return Array.from(this.idNodeMap.keys());
  }, t.prototype.getMeta = function(e) {
    return this.nodeMetaMap.get(e) || null;
  }, t.prototype.removeNodeFromMap = function(e) {
    var o = this, i = this.getId(e);
    this.idNodeMap.delete(i), e.childNodes && e.childNodes.forEach(function(n) {
      return o.removeNodeFromMap(n);
    });
  }, t.prototype.has = function(e) {
    return this.idNodeMap.has(e);
  }, t.prototype.hasNode = function(e) {
    return this.nodeMetaMap.has(e);
  }, t.prototype.add = function(e, o) {
    var i = o.id;
    this.idNodeMap.set(i, e), this.nodeMetaMap.set(e, o);
  }, t.prototype.replace = function(e, o) {
    var i = this.getNode(e);
    if (i) {
      var n = this.nodeMetaMap.get(i);
      n && this.nodeMetaMap.set(o, n);
    }
    this.idNodeMap.set(e, o);
  }, t.prototype.reset = function() {
    this.idNodeMap = /* @__PURE__ */ new Map(), this.nodeMetaMap = /* @__PURE__ */ new WeakMap();
  }, t;
}();
function xe(t) {
  const e = [];
  for (const o in t) {
    const i = t[o];
    if (typeof i != "string")
      continue;
    const n = Lt(o);
    e.push(`${n}: ${i};`);
  }
  return e.join(" ");
}
const At = /-([a-z])/g, Ot = /^--[a-zA-Z0-9-]+$/, le = (t) => Ot.test(t) ? t : t.replace(At, (e, o) => o ? o.toUpperCase() : ""), Pt = /\B([A-Z])/g, Lt = (t) => t.replace(Pt, "-$1").toLowerCase();
class P {
  constructor(...e) {
    this.parentElement = null, this.parentNode = null, this.firstChild = null, this.lastChild = null, this.previousSibling = null, this.nextSibling = null, this.ELEMENT_NODE = M.ELEMENT_NODE, this.TEXT_NODE = M.TEXT_NODE;
  }
  get childNodes() {
    const e = [];
    let o = this.firstChild;
    for (; o; )
      e.push(o), o = o.nextSibling;
    return e;
  }
  contains(e) {
    if (!(e instanceof P) || e.ownerDocument !== this.ownerDocument)
      return !1;
    if (e === this)
      return !0;
    for (; e.parentNode; ) {
      if (e.parentNode === this)
        return !0;
      e = e.parentNode;
    }
    return !1;
  }
  appendChild(e) {
    throw new Error("RRDomException: Failed to execute 'appendChild' on 'RRNode': This RRNode type does not support this method.");
  }
  insertBefore(e, o) {
    throw new Error("RRDomException: Failed to execute 'insertBefore' on 'RRNode': This RRNode type does not support this method.");
  }
  removeChild(e) {
    throw new Error("RRDomException: Failed to execute 'removeChild' on 'RRNode': This RRNode type does not support this method.");
  }
  toString() {
    return "RRNode";
  }
}
function We(t) {
  return class extends t {
    constructor(e, o, i) {
      super(), this.nodeType = M.DOCUMENT_TYPE_NODE, this.RRNodeType = E.DocumentType, this.name = e, this.publicId = o, this.systemId = i, this.nodeName = e, this.textContent = null;
    }
    toString() {
      return "RRDocumentType";
    }
  };
}
function $e(t) {
  return class extends t {
    constructor(e) {
      super(), this.nodeType = M.ELEMENT_NODE, this.RRNodeType = E.Element, this.attributes = {}, this.shadowRoot = null, this.tagName = e.toUpperCase(), this.nodeName = e.toUpperCase();
    }
    get textContent() {
      let e = "";
      return this.childNodes.forEach((o) => e += o.textContent), e;
    }
    set textContent(e) {
      this.firstChild = null, this.lastChild = null, this.appendChild(this.ownerDocument.createTextNode(e));
    }
    get classList() {
      return new _t(this.attributes.class, (e) => {
        this.attributes.class = e;
      });
    }
    get id() {
      return this.attributes.id || "";
    }
    get className() {
      return this.attributes.class || "";
    }
    get style() {
      const e = this.attributes.style ? function(i) {
        const n = {}, s = /:(.+)/;
        return i.replace(/\/\*.*?\*\//g, "").split(/;(?![^(]*\))/g).forEach(function(r) {
          if (r) {
            const a = r.split(s);
            a.length > 1 && (n[le(a[0].trim())] = a[1].trim());
          }
        }), n;
      }(this.attributes.style) : {}, o = /\B([A-Z])/g;
      return e.setProperty = (i, n, s) => {
        if (o.test(i))
          return;
        const r = le(i);
        n ? e[r] = n : delete e[r], s === "important" && (e[r] += " !important"), this.attributes.style = xe(e);
      }, e.removeProperty = (i) => {
        if (o.test(i))
          return "";
        const n = le(i), s = e[n] || "";
        return delete e[n], this.attributes.style = xe(e), s;
      }, e;
    }
    getAttribute(e) {
      return this.attributes[e] || null;
    }
    setAttribute(e, o) {
      this.attributes[e] = o;
    }
    setAttributeNS(e, o, i) {
      this.setAttribute(o, i);
    }
    removeAttribute(e) {
      delete this.attributes[e];
    }
    appendChild(e) {
      return me(this, e);
    }
    insertBefore(e, o) {
      return Xe(this, e, o);
    }
    removeChild(e) {
      return Ze(this, e);
    }
    attachShadow(e) {
      const o = this.ownerDocument.createElement("SHADOWROOT");
      return this.shadowRoot = o, o;
    }
    dispatchEvent(e) {
      return !0;
    }
    toString() {
      let e = "";
      for (const o in this.attributes)
        e += `${o}="${this.attributes[o]}" `;
      return `${this.tagName} ${e}`;
    }
  };
}
function qe(t) {
  return class extends t {
    constructor(e) {
      super(), this.nodeType = M.TEXT_NODE, this.nodeName = "#text", this.RRNodeType = E.Text, this.data = e;
    }
    get textContent() {
      return this.data;
    }
    set textContent(e) {
      this.data = e;
    }
    toString() {
      return `RRText text=${JSON.stringify(this.data)}`;
    }
  };
}
function Ye(t) {
  return class extends t {
    constructor(e) {
      super(), this.nodeType = M.COMMENT_NODE, this.nodeName = "#comment", this.RRNodeType = E.Comment, this.data = e;
    }
    get textContent() {
      return this.data;
    }
    set textContent(e) {
      this.data = e;
    }
    toString() {
      return `RRComment text=${JSON.stringify(this.data)}`;
    }
  };
}
function Ge(t) {
  return class extends t {
    constructor(e) {
      super(), this.nodeName = "#cdata-section", this.nodeType = M.CDATA_SECTION_NODE, this.RRNodeType = E.CDATA, this.data = e;
    }
    get textContent() {
      return this.data;
    }
    set textContent(e) {
      this.data = e;
    }
    toString() {
      return `RRCDATASection data=${JSON.stringify(this.data)}`;
    }
  };
}
class _t {
  constructor(e, o) {
    if (this.classes = [], this.add = (...i) => {
      for (const n of i) {
        const s = String(n);
        this.classes.indexOf(s) >= 0 || this.classes.push(s);
      }
      this.onChange && this.onChange(this.classes.join(" "));
    }, this.remove = (...i) => {
      this.classes = this.classes.filter((n) => i.indexOf(n) === -1), this.onChange && this.onChange(this.classes.join(" "));
    }, e) {
      const i = e.trim().split(/\s+/);
      this.classes.push(...i);
    }
    this.onChange = o;
  }
}
function me(t, e) {
  return e.parentNode && e.parentNode.removeChild(e), t.lastChild ? (t.lastChild.nextSibling = e, e.previousSibling = t.lastChild) : (t.firstChild = e, e.previousSibling = null), t.lastChild = e, e.nextSibling = null, e.parentNode = t, e.parentElement = t, e.ownerDocument = t.ownerDocument, e;
}
function Xe(t, e, o) {
  if (!o)
    return me(t, e);
  if (o.parentNode !== t)
    throw new Error("Failed to execute 'insertBefore' on 'RRNode': The RRNode before which the new node is to be inserted is not a child of this RRNode.");
  return e === o || (e.parentNode && e.parentNode.removeChild(e), e.previousSibling = o.previousSibling, o.previousSibling = e, e.nextSibling = o, e.previousSibling ? e.previousSibling.nextSibling = e : t.firstChild = e, e.parentElement = t, e.parentNode = t, e.ownerDocument = t.ownerDocument), e;
}
function Ze(t, e) {
  if (e.parentNode !== t)
    throw new Error("Failed to execute 'removeChild' on 'RRNode': The RRNode to be removed is not a child of this RRNode.");
  return e.previousSibling ? e.previousSibling.nextSibling = e.nextSibling : t.firstChild = e.nextSibling, e.nextSibling ? e.nextSibling.previousSibling = e.previousSibling : t.lastChild = e.previousSibling, e.previousSibling = null, e.nextSibling = null, e.parentElement = null, e.parentNode = null, e;
}
var M;
(function(t) {
  t[t.PLACEHOLDER = 0] = "PLACEHOLDER", t[t.ELEMENT_NODE = 1] = "ELEMENT_NODE", t[t.ATTRIBUTE_NODE = 2] = "ATTRIBUTE_NODE", t[t.TEXT_NODE = 3] = "TEXT_NODE", t[t.CDATA_SECTION_NODE = 4] = "CDATA_SECTION_NODE", t[t.ENTITY_REFERENCE_NODE = 5] = "ENTITY_REFERENCE_NODE", t[t.ENTITY_NODE = 6] = "ENTITY_NODE", t[t.PROCESSING_INSTRUCTION_NODE = 7] = "PROCESSING_INSTRUCTION_NODE", t[t.COMMENT_NODE = 8] = "COMMENT_NODE", t[t.DOCUMENT_NODE = 9] = "DOCUMENT_NODE", t[t.DOCUMENT_TYPE_NODE = 10] = "DOCUMENT_TYPE_NODE", t[t.DOCUMENT_FRAGMENT_NODE = 11] = "DOCUMENT_FRAGMENT_NODE";
})(M || (M = {}));
const he = { svg: "http://www.w3.org/2000/svg", "xlink:href": "http://www.w3.org/1999/xlink", xmlns: "http://www.w3.org/2000/xmlns/" }, Ft = { altglyph: "altGlyph", altglyphdef: "altGlyphDef", altglyphitem: "altGlyphItem", animatecolor: "animateColor", animatemotion: "animateMotion", animatetransform: "animateTransform", clippath: "clipPath", feblend: "feBlend", fecolormatrix: "feColorMatrix", fecomponenttransfer: "feComponentTransfer", fecomposite: "feComposite", feconvolvematrix: "feConvolveMatrix", fediffuselighting: "feDiffuseLighting", fedisplacementmap: "feDisplacementMap", fedistantlight: "feDistantLight", fedropshadow: "feDropShadow", feflood: "feFlood", fefunca: "feFuncA", fefuncb: "feFuncB", fefuncg: "feFuncG", fefuncr: "feFuncR", fegaussianblur: "feGaussianBlur", feimage: "feImage", femerge: "feMerge", femergenode: "feMergeNode", femorphology: "feMorphology", feoffset: "feOffset", fepointlight: "fePointLight", fespecularlighting: "feSpecularLighting", fespotlight: "feSpotLight", fetile: "feTile", feturbulence: "feTurbulence", foreignobject: "foreignObject", glyphref: "glyphRef", lineargradient: "linearGradient", radialgradient: "radialGradient" };
let F = null;
function te(t, e, o, i = e.mirror || e.ownerDocument.mirror) {
  t = function(n, s, r, a) {
    var l;
    if (r.afterAppend && !F && (F = /* @__PURE__ */ new WeakSet(), setTimeout(() => {
      F = null;
    }, 0)), !pe(n, s)) {
      const c = oe(s, r.mirror, a);
      (l = n.parentNode) === null || l === void 0 || l.replaceChild(c, n), n = c;
    }
    switch (s.RRNodeType) {
      case E.Document:
        if (!q(n, s, r.mirror, a)) {
          const c = a.getMeta(s);
          c && (r.mirror.removeNodeFromMap(n), n.close(), n.open(), r.mirror.add(n, c), F == null || F.add(n));
        }
        break;
      case E.Element: {
        const c = n, d = s;
        switch (d.tagName) {
          case "IFRAME": {
            const u = n.contentDocument;
            if (!u)
              break;
            te(u, s.contentDocument, r, a);
            break;
          }
        }
        d.shadowRoot && (c.shadowRoot || c.attachShadow({ mode: "open" }), Ie(c.shadowRoot, d.shadowRoot, r, a));
        break;
      }
    }
    return n;
  }(t, e, o, i), Ie(t, e, o, i), function(n, s, r, a) {
    var l;
    switch (s.RRNodeType) {
      case E.Document: {
        const c = s.scrollData;
        c && r.applyScroll(c, !0);
        break;
      }
      case E.Element: {
        const c = n, d = s;
        switch (function(u, h, p) {
          const b = u.attributes, m = h.attributes;
          for (const g in m) {
            const y = m[g], f = p.getMeta(h);
            if (f != null && f.isSVG && he[g])
              u.setAttributeNS(he[g], g, y);
            else if (h.tagName === "CANVAS" && g === "rr_dataURL") {
              const v = document.createElement("img");
              v.src = y, v.onload = () => {
                const w = u.getContext("2d");
                w && w.drawImage(v, 0, 0, v.width, v.height);
              };
            } else {
              if (h.tagName === "IFRAME" && g === "srcdoc")
                continue;
              u.setAttribute(g, y);
            }
          }
          for (const { name: g } of Array.from(b))
            g in m || u.removeAttribute(g);
          h.scrollLeft && (u.scrollLeft = h.scrollLeft), h.scrollTop && (u.scrollTop = h.scrollTop);
        }(c, d, a), d.scrollData && r.applyScroll(d.scrollData, !0), d.inputData && r.applyInput(d.inputData), d.tagName) {
          case "AUDIO":
          case "VIDEO": {
            const u = n, h = d;
            h.paused !== void 0 && (h.paused ? u.pause() : u.play()), h.muted !== void 0 && (u.muted = h.muted), h.volume !== void 0 && (u.volume = h.volume), h.currentTime !== void 0 && (u.currentTime = h.currentTime), h.playbackRate !== void 0 && (u.playbackRate = h.playbackRate);
            break;
          }
          case "CANVAS": {
            const u = s;
            if (u.rr_dataURL !== null) {
              const h = document.createElement("img");
              h.onload = () => {
                const p = c.getContext("2d");
                p && p.drawImage(h, 0, 0, h.width, h.height);
              }, h.src = u.rr_dataURL;
            }
            u.canvasMutations.forEach((h) => r.applyCanvas(h.event, h.mutation, n));
            break;
          }
          case "STYLE": {
            const u = c.sheet;
            u && s.rules.forEach((h) => r.applyStyleSheetMutation(h, u));
            break;
          }
        }
        break;
      }
      case E.Text:
      case E.Comment:
      case E.CDATA:
        n.textContent !== s.data && (n.textContent = s.data);
    }
    F != null && F.has(n) && (F.delete(n), (l = r.afterAppend) === null || l === void 0 || l.call(r, n, r.mirror.getId(n)));
  }(t, e, o, i);
}
function Ie(t, e, o, i) {
  const n = Array.from(t.childNodes), s = e.childNodes;
  if (n.length === 0 && s.length === 0)
    return;
  let r, a, l = 0, c = n.length - 1, d = 0, u = s.length - 1, h = n[l], p = n[c], b = s[d], m = s[u];
  for (; l <= c && d <= u; )
    if (h === void 0)
      h = n[++l];
    else if (p === void 0)
      p = n[--c];
    else if (q(h, b, o.mirror, i))
      h = n[++l], b = s[++d];
    else if (q(p, m, o.mirror, i))
      p = n[--c], m = s[--u];
    else if (q(h, m, o.mirror, i)) {
      try {
        t.insertBefore(h, p.nextSibling);
      } catch (f) {
        console.warn(f);
      }
      h = n[++l], m = s[--u];
    } else if (q(p, b, o.mirror, i)) {
      try {
        t.insertBefore(p, h);
      } catch (f) {
        console.warn(f);
      }
      p = n[--c], b = s[++d];
    } else {
      if (!r) {
        r = {};
        for (let v = l; v <= c; v++) {
          const w = n[v];
          w && o.mirror.hasNode(w) && (r[o.mirror.getId(w)] = v);
        }
      }
      a = r[i.getId(b)];
      const f = n[a];
      if (a !== void 0 && f && q(f, b, o.mirror, i)) {
        try {
          t.insertBefore(f, h);
        } catch (v) {
          console.warn(v);
        }
        n[a] = void 0;
      } else {
        const v = oe(b, o.mirror, i);
        t.nodeName === "#document" && h && (v.nodeType === v.DOCUMENT_TYPE_NODE && h.nodeType === h.DOCUMENT_TYPE_NODE || v.nodeType === v.ELEMENT_NODE && h.nodeType === h.ELEMENT_NODE) && (t.removeChild(h), o.mirror.removeNodeFromMap(h), h = n[++l]);
        try {
          t.insertBefore(v, h || null);
        } catch (w) {
          console.warn(w);
        }
      }
      b = s[++d];
    }
  if (l > c) {
    const f = s[u + 1];
    let v = null;
    for (f && (v = o.mirror.getNode(i.getId(f))); d <= u; ++d) {
      const w = oe(s[d], o.mirror, i);
      try {
        t.insertBefore(w, v);
      } catch (B) {
        console.warn(B);
      }
    }
  } else if (d > u)
    for (; l <= c; l++) {
      const f = n[l];
      if (f && f.parentNode === t)
        try {
          t.removeChild(f), o.mirror.removeNodeFromMap(f);
        } catch (v) {
          console.warn(v);
        }
    }
  let g = t.firstChild, y = e.firstChild;
  for (; g !== null && y !== null; )
    te(g, y, o, i), g = g.nextSibling, y = y.nextSibling;
}
function oe(t, e, o) {
  const i = o.getId(t), n = o.getMeta(t);
  let s = null;
  if (i > -1 && (s = e.getNode(i)), s !== null && pe(s, t))
    return s;
  switch (t.RRNodeType) {
    case E.Document:
      s = new Document();
      break;
    case E.DocumentType:
      s = document.implementation.createDocumentType(t.name, t.publicId, t.systemId);
      break;
    case E.Element: {
      let r = t.tagName.toLowerCase();
      r = Ft[r] || r, s = n && "isSVG" in n && (n != null && n.isSVG) ? document.createElementNS(he.svg, r) : document.createElement(t.tagName);
      break;
    }
    case E.Text:
      s = document.createTextNode(t.data);
      break;
    case E.Comment:
      s = document.createComment(t.data);
      break;
    case E.CDATA:
      s = document.createCDATASection(t.data);
  }
  n && e.add(s, Object.assign({}, n));
  try {
    F == null || F.add(s);
  } catch (r) {
  }
  return s;
}
function pe(t, e) {
  return t.nodeType === e.nodeType && (t.nodeType !== t.ELEMENT_NODE || t.tagName.toUpperCase() === e.tagName);
}
function q(t, e, o, i) {
  const n = o.getId(t), s = i.getId(e);
  return n !== -1 && n === s && pe(t, e);
}
class X extends (/* @__PURE__ */ function(e) {
  return class ze extends e {
    constructor(...i) {
      super(i), this.nodeType = M.DOCUMENT_NODE, this.nodeName = "#document", this.compatMode = "CSS1Compat", this.RRNodeType = E.Document, this.textContent = null, this.ownerDocument = this;
    }
    get documentElement() {
      return this.childNodes.find((i) => i.RRNodeType === E.Element && i.tagName === "HTML") || null;
    }
    get body() {
      var i;
      return ((i = this.documentElement) === null || i === void 0 ? void 0 : i.childNodes.find((n) => n.RRNodeType === E.Element && n.tagName === "BODY")) || null;
    }
    get head() {
      var i;
      return ((i = this.documentElement) === null || i === void 0 ? void 0 : i.childNodes.find((n) => n.RRNodeType === E.Element && n.tagName === "HEAD")) || null;
    }
    get implementation() {
      return this;
    }
    get firstElementChild() {
      return this.documentElement;
    }
    appendChild(i) {
      const n = i.RRNodeType;
      if ((n === E.Element || n === E.DocumentType) && this.childNodes.some((r) => r.RRNodeType === n))
        throw new Error(`RRDomException: Failed to execute 'appendChild' on 'RRNode': Only one ${n === E.Element ? "RRElement" : "RRDoctype"} on RRDocument allowed.`);
      const s = me(this, i);
      return s.parentElement = null, s;
    }
    insertBefore(i, n) {
      const s = i.RRNodeType;
      if ((s === E.Element || s === E.DocumentType) && this.childNodes.some((a) => a.RRNodeType === s))
        throw new Error(`RRDomException: Failed to execute 'insertBefore' on 'RRNode': Only one ${s === E.Element ? "RRElement" : "RRDoctype"} on RRDocument allowed.`);
      const r = Xe(this, i, n);
      return r.parentElement = null, r;
    }
    removeChild(i) {
      return Ze(this, i);
    }
    open() {
      this.firstChild = null, this.lastChild = null;
    }
    close() {
    }
    write(i) {
      let n;
      if (i === '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "">' ? n = "-//W3C//DTD XHTML 1.0 Transitional//EN" : i === '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "">' && (n = "-//W3C//DTD HTML 4.0 Transitional//EN"), n) {
        const s = this.createDocumentType("html", n, "");
        this.open(), this.appendChild(s);
      }
    }
    createDocument(i, n, s) {
      return new ze();
    }
    createDocumentType(i, n, s) {
      const r = new (We(P))(i, n, s);
      return r.ownerDocument = this, r;
    }
    createElement(i) {
      const n = new ($e(P))(i);
      return n.ownerDocument = this, n;
    }
    createElementNS(i, n) {
      return this.createElement(n);
    }
    createTextNode(i) {
      const n = new (qe(P))(i);
      return n.ownerDocument = this, n;
    }
    createComment(i) {
      const n = new (Ye(P))(i);
      return n.ownerDocument = this, n;
    }
    createCDATASection(i) {
      const n = new (Ge(P))(i);
      return n.ownerDocument = this, n;
    }
    toString() {
      return "RRDocument";
    }
  };
}(P)) {
  get unserializedId() {
    return this._unserializedId--;
  }
  constructor(e) {
    super(), this.UNSERIALIZED_STARTING_ID = -2, this._unserializedId = this.UNSERIALIZED_STARTING_ID, this.mirror = new Gt(), this.scrollData = null, e && (this.mirror = e);
  }
  createDocument(e, o, i) {
    return new X();
  }
  createDocumentType(e, o, i) {
    const n = new Ut(e, o, i);
    return n.ownerDocument = this, n;
  }
  createElement(e) {
    const o = e.toUpperCase();
    let i;
    switch (o) {
      case "AUDIO":
      case "VIDEO":
        i = new Vt(o);
        break;
      case "IFRAME":
        i = new Ht(o, this.mirror);
        break;
      case "CANVAS":
        i = new Bt(o);
        break;
      case "STYLE":
        i = new jt(o);
        break;
      default:
        i = new Z(o);
    }
    return i.ownerDocument = this, i;
  }
  createComment(e) {
    const o = new $t(e);
    return o.ownerDocument = this, o;
  }
  createCDATASection(e) {
    const o = new qt(e);
    return o.ownerDocument = this, o;
  }
  createTextNode(e) {
    const o = new Wt(e);
    return o.ownerDocument = this, o;
  }
  destroyTree() {
    this.firstChild = null, this.lastChild = null, this.mirror.reset();
  }
  open() {
    super.open(), this._unserializedId = this.UNSERIALIZED_STARTING_ID;
  }
}
const Ut = We(P);
class Z extends $e(P) {
  constructor() {
    super(...arguments), this.inputData = null, this.scrollData = null;
  }
}
class Vt extends (/* @__PURE__ */ function(e) {
  return class extends e {
    attachShadow(o) {
      throw new Error("RRDomException: Failed to execute 'attachShadow' on 'RRElement': This RRElement does not support attachShadow");
    }
    play() {
      this.paused = !1;
    }
    pause() {
      this.paused = !0;
    }
  };
}(Z)) {
}
class Bt extends Z {
  constructor() {
    super(...arguments), this.rr_dataURL = null, this.canvasMutations = [];
  }
  getContext() {
    return null;
  }
}
class jt extends Z {
  constructor() {
    super(...arguments), this.rules = [];
  }
}
class Ht extends Z {
  constructor(e, o) {
    super(e), this.contentDocument = new X(), this.contentDocument.mirror = o;
  }
}
const Wt = qe(P), $t = Ye(P), qt = Ge(P);
function Qe(t, e, o, i) {
  let n;
  switch (t.nodeType) {
    case M.DOCUMENT_NODE:
      i && i.nodeName === "IFRAME" ? n = i.contentDocument : (n = e, n.compatMode = t.compatMode);
      break;
    case M.DOCUMENT_TYPE_NODE: {
      const a = t;
      n = e.createDocumentType(a.name, a.publicId, a.systemId);
      break;
    }
    case M.ELEMENT_NODE: {
      const a = t, l = (s = a) instanceof HTMLFormElement ? "FORM" : s.tagName.toUpperCase();
      n = e.createElement(l);
      const c = n;
      for (const { name: d, value: u } of Array.from(a.attributes))
        c.attributes[d] = u;
      a.scrollLeft && (c.scrollLeft = a.scrollLeft), a.scrollTop && (c.scrollTop = a.scrollTop);
      break;
    }
    case M.TEXT_NODE:
      n = e.createTextNode(t.textContent || "");
      break;
    case M.CDATA_SECTION_NODE:
      n = e.createCDATASection(t.data);
      break;
    case M.COMMENT_NODE:
      n = e.createComment(t.textContent || "");
      break;
    case M.DOCUMENT_FRAGMENT_NODE:
      n = i.attachShadow({ mode: "open" });
      break;
    default:
      return null;
  }
  var s;
  let r = o.getMeta(t);
  return e instanceof X && (r || (r = Ke(n, e.unserializedId), o.add(t, r)), e.mirror.add(n, Object.assign({}, r))), n;
}
function Yt(t, e = function() {
  return new kt();
}(), o = new X()) {
  return function i(n, s) {
    const r = Qe(n, o, e, s);
    if (r !== null)
      if ((s == null ? void 0 : s.nodeName) !== "IFRAME" && n.nodeType !== M.DOCUMENT_FRAGMENT_NODE && (s == null || s.appendChild(r), r.parentNode = s, r.parentElement = s), n.nodeName === "IFRAME") {
        const a = n.contentDocument;
        a && i(a, r);
      } else
        n.nodeType !== M.DOCUMENT_NODE && n.nodeType !== M.ELEMENT_NODE && n.nodeType !== M.DOCUMENT_FRAGMENT_NODE || (n.nodeType === M.ELEMENT_NODE && n.shadowRoot && i(n.shadowRoot, r), n.childNodes.forEach((a) => i(a, r)));
  }(t, null), o;
}
class Gt {
  constructor() {
    this.idNodeMap = /* @__PURE__ */ new Map(), this.nodeMetaMap = /* @__PURE__ */ new WeakMap();
  }
  getId(e) {
    var o;
    if (!e)
      return -1;
    const i = (o = this.getMeta(e)) === null || o === void 0 ? void 0 : o.id;
    return i != null ? i : -1;
  }
  getNode(e) {
    return this.idNodeMap.get(e) || null;
  }
  getIds() {
    return Array.from(this.idNodeMap.keys());
  }
  getMeta(e) {
    return this.nodeMetaMap.get(e) || null;
  }
  removeNodeFromMap(e) {
    const o = this.getId(e);
    this.idNodeMap.delete(o), e.childNodes && e.childNodes.forEach((i) => this.removeNodeFromMap(i));
  }
  has(e) {
    return this.idNodeMap.has(e);
  }
  hasNode(e) {
    return this.nodeMetaMap.has(e);
  }
  add(e, o) {
    const i = o.id;
    this.idNodeMap.set(i, e), this.nodeMetaMap.set(e, o);
  }
  replace(e, o) {
    const i = this.getNode(e);
    if (i) {
      const n = this.nodeMetaMap.get(i);
      n && this.nodeMetaMap.set(o, n);
    }
    this.idNodeMap.set(e, o);
  }
  reset() {
    this.idNodeMap = /* @__PURE__ */ new Map(), this.nodeMetaMap = /* @__PURE__ */ new WeakMap();
  }
}
function Ke(t, e) {
  switch (t.RRNodeType) {
    case E.Document:
      return { id: e, type: t.RRNodeType, childNodes: [] };
    case E.DocumentType: {
      const o = t;
      return { id: e, type: t.RRNodeType, name: o.name, publicId: o.publicId, systemId: o.systemId };
    }
    case E.Element:
      return { id: e, type: t.RRNodeType, tagName: t.tagName.toLowerCase(), attributes: {}, childNodes: [] };
    case E.Text:
    case E.Comment:
      return { id: e, type: t.RRNodeType, textContent: t.textContent || "" };
    case E.CDATA:
      return { id: e, type: t.RRNodeType, textContent: "" };
  }
}
function Je(t) {
  return { all: t = t || /* @__PURE__ */ new Map(), on: function(e, o) {
    var i = t.get(e);
    i ? i.push(o) : t.set(e, [o]);
  }, off: function(e, o) {
    var i = t.get(e);
    i && (o ? i.splice(i.indexOf(o) >>> 0, 1) : t.set(e, []));
  }, emit: function(e, o) {
    var i = t.get(e);
    i && i.slice().map(function(n) {
      n(o);
    }), (i = t.get("*")) && i.slice().map(function(n) {
      n(e, o);
    });
  } };
}
const Xt = Object.freeze(Object.defineProperty({ __proto__: null, default: Je }, Symbol.toStringTag, { value: "Module" }));
function Zt(t = window, e = document) {
  if ("scrollBehavior" in e.documentElement.style && t.__forceSmoothScrollPolyfill__ !== !0)
    return;
  const o = t.HTMLElement || t.Element, i = 468, n = { scroll: t.scroll || t.scrollTo, scrollBy: t.scrollBy, elementScroll: o.prototype.scroll || l, scrollIntoView: o.prototype.scrollIntoView }, s = t.performance && t.performance.now ? t.performance.now.bind(t.performance) : Date.now, r = (a = t.navigator.userAgent, new RegExp(["MSIE ", "Trident/", "Edge/"].join("|")).test(a) ? 1 : 0);
  var a;
  function l(m, g) {
    this.scrollLeft = m, this.scrollTop = g;
  }
  function c(m) {
    if (m === null || typeof m != "object" || m.behavior === void 0 || m.behavior === "auto" || m.behavior === "instant")
      return !0;
    if (typeof m == "object" && m.behavior === "smooth")
      return !1;
    throw new TypeError("behavior member of ScrollOptions " + m.behavior + " is not a valid value for enumeration ScrollBehavior.");
  }
  function d(m, g) {
    return g === "Y" ? m.clientHeight + r < m.scrollHeight : g === "X" ? m.clientWidth + r < m.scrollWidth : void 0;
  }
  function u(m, g) {
    const y = t.getComputedStyle(m, null)["overflow" + g];
    return y === "auto" || y === "scroll";
  }
  function h(m) {
    const g = d(m, "Y") && u(m, "Y"), y = d(m, "X") && u(m, "X");
    return g || y;
  }
  function p(m) {
    let g, y, f, v = (s() - m.startTime) / i;
    var w;
    v = v > 1 ? 1 : v, w = v, g = 0.5 * (1 - Math.cos(Math.PI * w)), y = m.startX + (m.x - m.startX) * g, f = m.startY + (m.y - m.startY) * g, m.method.call(m.scrollable, y, f), y === m.x && f === m.y || t.requestAnimationFrame(p.bind(t, m));
  }
  function b(m, g, y) {
    let f, v, w, B;
    const z = s();
    m === e.body ? (f = t, v = t.scrollX || t.pageXOffset, w = t.scrollY || t.pageYOffset, B = n.scroll) : (f = m, v = m.scrollLeft, w = m.scrollTop, B = l), p({ scrollable: f, method: B, startTime: z, startX: v, startY: w, x: g, y });
  }
  t.scroll = t.scrollTo = function() {
    arguments[0] !== void 0 && (c(arguments[0]) !== !0 ? b.call(t, e.body, arguments[0].left !== void 0 ? ~~arguments[0].left : t.scrollX || t.pageXOffset, arguments[0].top !== void 0 ? ~~arguments[0].top : t.scrollY || t.pageYOffset) : n.scroll.call(t, arguments[0].left !== void 0 ? arguments[0].left : typeof arguments[0] != "object" ? arguments[0] : t.scrollX || t.pageXOffset, arguments[0].top !== void 0 ? arguments[0].top : arguments[1] !== void 0 ? arguments[1] : t.scrollY || t.pageYOffset));
  }, t.scrollBy = function() {
    arguments[0] !== void 0 && (c(arguments[0]) ? n.scrollBy.call(t, arguments[0].left !== void 0 ? arguments[0].left : typeof arguments[0] != "object" ? arguments[0] : 0, arguments[0].top !== void 0 ? arguments[0].top : arguments[1] !== void 0 ? arguments[1] : 0) : b.call(t, e.body, ~~arguments[0].left + (t.scrollX || t.pageXOffset), ~~arguments[0].top + (t.scrollY || t.pageYOffset)));
  }, o.prototype.scroll = o.prototype.scrollTo = function() {
    if (arguments[0] === void 0)
      return;
    if (c(arguments[0]) === !0) {
      if (typeof arguments[0] == "number" && arguments[1] === void 0)
        throw new SyntaxError("Value could not be converted");
      return void n.elementScroll.call(this, arguments[0].left !== void 0 ? ~~arguments[0].left : typeof arguments[0] != "object" ? ~~arguments[0] : this.scrollLeft, arguments[0].top !== void 0 ? ~~arguments[0].top : arguments[1] !== void 0 ? ~~arguments[1] : this.scrollTop);
    }
    const m = arguments[0].left, g = arguments[0].top;
    b.call(this, this, m === void 0 ? this.scrollLeft : ~~m, g === void 0 ? this.scrollTop : ~~g);
  }, o.prototype.scrollBy = function() {
    arguments[0] !== void 0 && (c(arguments[0]) !== !0 ? this.scroll({ left: ~~arguments[0].left + this.scrollLeft, top: ~~arguments[0].top + this.scrollTop, behavior: arguments[0].behavior }) : n.elementScroll.call(this, arguments[0].left !== void 0 ? ~~arguments[0].left + this.scrollLeft : ~~arguments[0] + this.scrollLeft, arguments[0].top !== void 0 ? ~~arguments[0].top + this.scrollTop : ~~arguments[1] + this.scrollTop));
  }, o.prototype.scrollIntoView = function() {
    if (c(arguments[0]) === !0)
      return void n.scrollIntoView.call(this, arguments[0] === void 0 || arguments[0]);
    const m = function(f) {
      for (; f !== e.body && h(f) === !1; )
        f = f.parentNode || f.host;
      return f;
    }(this), g = m.getBoundingClientRect(), y = this.getBoundingClientRect();
    m !== e.body ? (b.call(this, m, m.scrollLeft + y.left - g.left, m.scrollTop + y.top - g.top), t.getComputedStyle(m).position !== "fixed" && t.scrollBy({ left: g.left, top: g.top, behavior: "smooth" })) : t.scrollBy({ left: y.left, top: y.top, behavior: "smooth" });
  };
}
class zt {
  constructor(e = [], o) {
    this.timeOffset = 0, this.raf = null, this.actions = e, this.speed = o.speed;
  }
  addAction(e) {
    const o = this.raf === !0;
    if (!this.actions.length || this.actions[this.actions.length - 1].delay <= e.delay)
      this.actions.push(e);
    else {
      const i = this.findActionIndex(e);
      this.actions.splice(i, 0, e);
    }
    o && (this.raf = requestAnimationFrame(this.rafCheck.bind(this)));
  }
  start() {
    this.timeOffset = 0, this.lastTimestamp = performance.now(), this.raf = requestAnimationFrame(this.rafCheck.bind(this));
  }
  rafCheck() {
    const e = performance.now();
    for (this.timeOffset += (e - this.lastTimestamp) * this.speed, this.lastTimestamp = e; this.actions.length; ) {
      const o = this.actions[0];
      if (!(this.timeOffset >= o.delay))
        break;
      this.actions.shift(), o.doAction();
    }
    this.actions.length > 0 ? this.raf = requestAnimationFrame(this.rafCheck.bind(this)) : this.raf = !0;
  }
  clear() {
    this.raf && (this.raf !== !0 && cancelAnimationFrame(this.raf), this.raf = null), this.actions.length = 0;
  }
  setSpeed(e) {
    this.speed = e;
  }
  isActive() {
    return this.raf !== null;
  }
  findActionIndex(e) {
    let o = 0, i = this.actions.length - 1;
    for (; o <= i; ) {
      const n = Math.floor((o + i) / 2);
      if (this.actions[n].delay < e.delay)
        o = n + 1;
      else {
        if (!(this.actions[n].delay > e.delay))
          return n + 1;
        i = n - 1;
      }
    }
    return o;
  }
}
function ke(t, e) {
  if (t.type === D.IncrementalSnapshot && t.data.source === C.MouseMove && t.data.positions && t.data.positions.length) {
    const o = t.data.positions[0].timeOffset, i = t.timestamp + o;
    return t.delay = i - e, i - e;
  }
  return t.delay = t.timestamp - e, t.delay;
}
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function Ae(t, e) {
  var o = typeof Symbol == "function" && t[Symbol.iterator];
  if (!o)
    return t;
  var i, n, s = o.call(t), r = [];
  try {
    for (; (e === void 0 || e-- > 0) && !(i = s.next()).done; )
      r.push(i.value);
  } catch (a) {
    n = { error: a };
  } finally {
    try {
      i && !i.done && (o = s.return) && o.call(s);
    } finally {
      if (n)
        throw n.error;
    }
  }
  return r;
}
var G;
(function(t) {
  t[t.NotStarted = 0] = "NotStarted", t[t.Running = 1] = "Running", t[t.Stopped = 2] = "Stopped";
})(G || (G = {}));
var et = { type: "xstate.init" };
function ce(t) {
  return t === void 0 ? [] : [].concat(t);
}
function Y(t) {
  return { type: "xstate.assign", assignment: t };
}
function Oe(t, e) {
  return typeof (t = typeof t == "string" && e && e[t] ? e[t] : t) == "string" ? { type: t } : typeof t == "function" ? { type: t.name, exec: t } : t;
}
function ne(t) {
  return function(e) {
    return t === e;
  };
}
function tt(t) {
  return typeof t == "string" ? { type: t } : t;
}
function Pe(t, e) {
  return { value: t, context: e, actions: [], changed: !1, matches: ne(t) };
}
function Le(t, e, o) {
  var i = e, n = !1;
  return [t.filter(function(s) {
    if (s.type === "xstate.assign") {
      n = !0;
      var r = Object.assign({}, i);
      return typeof s.assignment == "function" ? r = s.assignment(i, o) : Object.keys(s.assignment).forEach(function(a) {
        r[a] = typeof s.assignment[a] == "function" ? s.assignment[a](i, o) : s.assignment[a];
      }), i = r, !1;
    }
    return !0;
  }), i, n];
}
function ot(t, e) {
  e === void 0 && (e = {});
  var o = Ae(Le(ce(t.states[t.initial].entry).map(function(r) {
    return Oe(r, e.actions);
  }), t.context, et), 2), i = o[0], n = o[1], s = { config: t, _options: e, initialState: { value: t.initial, actions: i, context: n, matches: ne(t.initial) }, transition: function(r, a) {
    var l, c, d = typeof r == "string" ? { value: r, context: t.context } : r, u = d.value, h = d.context, p = tt(a), b = t.states[u];
    if (b.on) {
      var m = ce(b.on[p.type]);
      try {
        for (var g = function(k) {
          var se = typeof Symbol == "function" && Symbol.iterator, ye = se && k[se], be = 0;
          if (ye)
            return ye.call(k);
          if (k && typeof k.length == "number")
            return { next: function() {
              return k && be >= k.length && (k = void 0), { value: k && k[be++], done: !k };
            } };
          throw new TypeError(se ? "Object is not iterable." : "Symbol.iterator is not defined.");
        }(m), y = g.next(); !y.done; y = g.next()) {
          var f = y.value;
          if (f === void 0)
            return Pe(u, h);
          var v = typeof f == "string" ? { target: f } : f, w = v.target, B = v.actions, z = B === void 0 ? [] : B, fe = v.cond, st = fe === void 0 ? function() {
            return !0;
          } : fe, rt = w === void 0, at = w != null ? w : u, lt = t.states[at];
          if (st(h, p)) {
            var ie = Ae(Le((rt ? ce(z) : [].concat(b.exit, z, lt.entry).filter(function(k) {
              return k;
            })).map(function(k) {
              return Oe(k, s._options.actions);
            }), h, p), 3), ge = ie[0], ct = ie[1], dt = ie[2], ve = w != null ? w : u;
            return { value: ve, context: ct, actions: ge, changed: w !== u || ge.length > 0 || dt, matches: ne(ve) };
          }
        }
      } catch (k) {
        l = { error: k };
      } finally {
        try {
          y && !y.done && (c = g.return) && c.call(g);
        } finally {
          if (l)
            throw l.error;
        }
      }
    }
    return Pe(u, h);
  } };
  return s;
}
var _e = function(t, e) {
  return t.actions.forEach(function(o) {
    var i = o.exec;
    return i && i(t.context, e);
  });
};
function nt(t) {
  var e = t.initialState, o = G.NotStarted, i = /* @__PURE__ */ new Set(), n = { _machine: t, send: function(s) {
    o === G.Running && (e = t.transition(e, s), _e(e, tt(s)), i.forEach(function(r) {
      return r(e);
    }));
  }, subscribe: function(s) {
    return i.add(s), s(e), { unsubscribe: function() {
      return i.delete(s);
    } };
  }, start: function(s) {
    if (s) {
      var r = typeof s == "object" ? s : { context: t.config.context, value: s };
      e = { value: r.value, actions: [], context: r.context, matches: ne(r.value) };
    }
    return o = G.Running, _e(e, et), n;
  }, stop: function() {
    return o = G.Stopped, i.clear(), n;
  }, get state() {
    return e;
  }, get status() {
    return o;
  } };
  return n;
}
function Qt(t, { getCastFn: e, applyEventsSynchronously: o, emitter: i }) {
  return nt(ot({ id: "player", context: t, initial: "paused", states: { playing: { on: { PAUSE: { target: "paused", actions: ["pause"] }, CAST_EVENT: { target: "playing", actions: "castEvent" }, END: { target: "paused", actions: ["resetLastPlayedEvent", "pause"] }, ADD_EVENT: { target: "playing", actions: ["addEvent"] } } }, paused: { on: { PLAY: { target: "playing", actions: ["recordTimeOffset", "play"] }, CAST_EVENT: { target: "paused", actions: "castEvent" }, TO_LIVE: { target: "live", actions: ["startLive"] }, ADD_EVENT: { target: "paused", actions: ["addEvent"] } } }, live: { on: { ADD_EVENT: { target: "live", actions: ["addEvent"] }, CAST_EVENT: { target: "live", actions: ["castEvent"] } } } } }, { actions: { castEvent: Y({ lastPlayedEvent: (n, s) => s.type === "CAST_EVENT" ? s.payload.event : n.lastPlayedEvent }), recordTimeOffset: Y((n, s) => {
    let r = n.timeOffset;
    return "payload" in s && "timeOffset" in s.payload && (r = s.payload.timeOffset), Object.assign(Object.assign({}, n), { timeOffset: r, baselineTime: n.events[0].timestamp + r });
  }), play(n) {
    var s;
    const { timer: r, events: a, baselineTime: l, lastPlayedEvent: c } = n;
    r.clear();
    for (const p of a)
      ke(p, l);
    const d = function(p, b) {
      for (let m = p.length - 1; m >= 0; m--) {
        const g = p[m];
        if (g.type === D.Meta && g.timestamp <= b)
          return p.slice(m);
      }
      return p;
    }(a, l);
    let u = c == null ? void 0 : c.timestamp;
    (c == null ? void 0 : c.type) === D.IncrementalSnapshot && c.data.source === C.MouseMove && (u = c.timestamp + ((s = c.data.positions[0]) === null || s === void 0 ? void 0 : s.timeOffset)), l < (u || 0) && i.emit(N.PlayBack);
    const h = new Array();
    for (const p of d)
      if (!(u && u < l && (p.timestamp <= u || p === c)))
        if (p.timestamp < l)
          h.push(p);
        else {
          const b = e(p, !1);
          r.addAction({ doAction: () => {
            b();
          }, delay: p.delay });
        }
    o(h), i.emit(N.Flush), r.start();
  }, pause(n) {
    n.timer.clear();
  }, resetLastPlayedEvent: Y((n) => Object.assign(Object.assign({}, n), { lastPlayedEvent: null })), startLive: Y({ baselineTime: (n, s) => (n.timer.start(), s.type === "TO_LIVE" && s.payload.baselineTime ? s.payload.baselineTime : Date.now()) }), addEvent: Y((n, s) => {
    const { baselineTime: r, timer: a, events: l } = n;
    if (s.type === "ADD_EVENT") {
      const { event: c } = s.payload;
      ke(c, r);
      let d = l.length - 1;
      if (!l[d] || l[d].timestamp <= c.timestamp)
        l.push(c);
      else {
        let p = -1, b = 0;
        for (; b <= d; ) {
          const m = Math.floor((b + d) / 2);
          l[m].timestamp <= c.timestamp ? b = m + 1 : d = m - 1;
        }
        p === -1 && (p = b), l.splice(p, 0, c);
      }
      const u = c.timestamp < r, h = e(c, u);
      u ? h() : a.isActive() && a.addAction({ doAction: () => {
        h();
      }, delay: c.delay });
    }
    return Object.assign(Object.assign({}, n), { events: l });
  }) } }));
}
const Fe = /* @__PURE__ */ new Map();
function it(t, e) {
  let o = Fe.get(t);
  return o || (o = /* @__PURE__ */ new Map(), Fe.set(t, o)), o.has(e) || o.set(e, []), o.get(e);
}
function j(t, e, o) {
  return (i) => H(this, void 0, void 0, function* () {
    if (i && typeof i == "object" && "rr_type" in i) {
      if (o && (o.isUnchanged = !1), i.rr_type === "ImageBitmap" && "args" in i) {
        const n = yield j(t, e, o)(i.args);
        return yield createImageBitmap.apply(null, n);
      }
      if ("index" in i) {
        if (o || e === null)
          return i;
        const { rr_type: n, index: s } = i;
        return it(e, n)[s];
      }
      if ("args" in i) {
        const { rr_type: n, args: s } = i;
        return new window[n](...yield Promise.all(s.map(j(t, e, o))));
      }
      if ("base64" in i)
        return gt(i.base64);
      if ("src" in i) {
        const n = t.get(i.src);
        if (n)
          return n;
        {
          const s = new Image();
          return s.src = i.src, t.set(i.src, s), s;
        }
      }
      if ("data" in i && i.rr_type === "Blob") {
        const n = yield Promise.all(i.data.map(j(t, e, o)));
        return new Blob(n, { type: i.type });
      }
    } else if (Array.isArray(i))
      return yield Promise.all(i.map(j(t, e, o)));
    return i;
  });
}
const Kt = ["WebGLActiveInfo", "WebGLBuffer", "WebGLFramebuffer", "WebGLProgram", "WebGLRenderbuffer", "WebGLShader", "WebGLShaderPrecisionFormat", "WebGLTexture", "WebGLUniformLocation", "WebGLVertexArrayObject"];
function Jt({ mutation: t, target: e, type: o, imageMap: i, errorHandler: n }) {
  return H(this, void 0, void 0, function* () {
    try {
      const s = function(l, c) {
        try {
          return c === ue.WebGL ? l.getContext("webgl") || l.getContext("experimental-webgl") : l.getContext("webgl2");
        } catch (d) {
          return null;
        }
      }(e, o);
      if (!s)
        return;
      if (t.setter)
        return void (s[t.property] = t.args[0]);
      const r = s[t.property], a = yield Promise.all(t.args.map(j(i, s)));
      (function(l, c) {
        if (!(c != null && c.constructor))
          return;
        const { name: d } = c.constructor;
        if (!Kt.includes(d))
          return;
        const u = it(l, d);
        u.includes(c) || u.push(c);
      })(s, r.apply(s, a));
    } catch (s) {
      n(t, s);
    }
  });
}
function Ue({ event: t, mutation: e, target: o, imageMap: i, canvasEventMap: n, errorHandler: s }) {
  return H(this, void 0, void 0, function* () {
    try {
      const r = n.get(t) || e, a = "commands" in r ? r.commands : [r];
      if ([ue.WebGL, ue.WebGL2].includes(e.type)) {
        for (let l = 0; l < a.length; l++) {
          const c = a[l];
          yield Jt({ mutation: c, type: e.type, target: o, imageMap: i, errorHandler: s });
        }
        return;
      }
      yield function({ event: l, mutations: c, target: d, imageMap: u, errorHandler: h }) {
        return H(this, void 0, void 0, function* () {
          const p = d.getContext("2d");
          if (!p)
            return void h(c[0], new Error("Canvas context is null"));
          const b = c.map((m) => H(this, void 0, void 0, function* () {
            return Promise.all(m.args.map(j(u, p)));
          }));
          (yield Promise.all(b)).forEach((m, g) => {
            const y = c[g];
            try {
              if (y.setter)
                return void (p[y.property] = y.args[0]);
              const f = p[y.property];
              y.property === "drawImage" && typeof y.args[0] == "string" ? (u.get(l), f.apply(p, y.args)) : f.apply(p, m);
            } catch (f) {
              h(y, f);
            }
          });
        });
      }({ event: t, mutations: a, target: o, imageMap: i, errorHandler: s });
    } catch (r) {
      s(e, r);
    }
  });
}
const eo = Je || Xt, Ve = "[replayer]", de = { duration: 500, lineCap: "round", lineWidth: 3, strokeStyle: "red" };
function Be(t) {
  return t.type == D.IncrementalSnapshot && (t.data.source == C.TouchMove || t.data.source == C.MouseInteraction && t.data.type == R.TouchStart);
}
class to {
  get timer() {
    return this.service.state.context.timer;
  }
  constructor(e, o) {
    if (this.usingVirtualDom = !1, this.virtualDom = new X(), this.mouseTail = null, this.tailPositions = [], this.emitter = eo(), this.legacy_missingNodeRetryMap = {}, this.cache = Te(), this.imageMap = /* @__PURE__ */ new Map(), this.canvasEventMap = /* @__PURE__ */ new Map(), this.mirror = vt(), this.styleMirror = new yt(), this.firstFullSnapshot = null, this.newDocumentQueue = [], this.mousePos = null, this.touchActive = null, this.lastMouseDownEvent = null, this.lastSelectionData = null, this.constructedStyleMutations = [], this.adoptedStyleSheets = [], this.handleResize = (a) => {
      this.iframe.style.display = "inherit";
      for (const l of [this.mouseTail, this.iframe])
        l && (l.setAttribute("width", String(a.width)), l.setAttribute("height", String(a.height)));
    }, this.applyEventsSynchronously = (a) => {
      for (const l of a) {
        switch (l.type) {
          case D.DomContentLoaded:
          case D.Load:
          case D.Custom:
            continue;
          case D.FullSnapshot:
          case D.Meta:
          case D.Plugin:
          case D.IncrementalSnapshot:
        }
        this.getCastFn(l, !0)();
      }
    }, this.getCastFn = (a, l = !1) => {
      let c;
      switch (a.type) {
        case D.DomContentLoaded:
        case D.Load:
          break;
        case D.Custom:
          c = () => {
            this.emitter.emit(N.CustomEvent, a);
          };
          break;
        case D.Meta:
          c = () => this.emitter.emit(N.Resize, { width: a.data.width, height: a.data.height });
          break;
        case D.FullSnapshot:
          c = () => {
            var d;
            if (this.firstFullSnapshot) {
              if (this.firstFullSnapshot === a)
                return void (this.firstFullSnapshot = !0);
            } else
              this.firstFullSnapshot = !0;
            this.rebuildFullSnapshot(a, l), (d = this.iframe.contentWindow) === null || d === void 0 || d.scrollTo(a.data.initialOffset), this.styleMirror.reset();
          };
          break;
        case D.IncrementalSnapshot:
          c = () => {
            if (this.applyIncremental(a, l), !l && (a === this.nextUserInteractionEvent && (this.nextUserInteractionEvent = null, this.backToNormal()), this.config.skipInactive && !this.nextUserInteractionEvent)) {
              for (const d of this.service.state.context.events)
                if (!(d.timestamp <= a.timestamp) && this.isUserInteraction(d)) {
                  d.delay - a.delay > 1e4 * this.speedService.state.context.timer.speed && (this.nextUserInteractionEvent = d);
                  break;
                }
              if (this.nextUserInteractionEvent) {
                const d = this.nextUserInteractionEvent.delay - a.delay, u = { speed: Math.min(Math.round(d / 5e3), this.config.maxSpeed) };
                this.speedService.send({ type: "FAST_FORWARD", payload: u }), this.emitter.emit(N.SkipStart, u);
              }
            }
          };
      }
      return () => {
        c && c();
        for (const u of this.config.plugins || [])
          u.handler && u.handler(a, l, { replayer: this });
        this.service.send({ type: "CAST_EVENT", payload: { event: a } });
        const d = this.service.state.context.events.length - 1;
        if (!this.config.liveMode && a === this.service.state.context.events[d]) {
          const u = () => {
            d < this.service.state.context.events.length - 1 || (this.backToNormal(), this.service.send("END"), this.emitter.emit(N.Finish));
          };
          let h = 50;
          a.type === D.IncrementalSnapshot && a.data.source === C.MouseMove && a.data.positions.length && (h += Math.max(0, -a.data.positions[0].timeOffset)), setTimeout(u, h);
        }
        this.emitter.emit(N.EventCast, a);
      };
    }, !(o != null && o.liveMode) && e.length < 2)
      throw new Error("Replayer need at least 2 events.");
    const i = { speed: 1, maxSpeed: 360, root: document.body, loadTimeout: 0, skipInactive: !1, showWarning: !0, showDebug: !1, blockClass: "rr-block", liveMode: !1, insertStyleRules: [], triggerFocus: !0, UNSAFE_replayCanvas: !1, pauseAnimation: !0, mouseTail: de, useVirtualDom: !0, logger: console };
    this.config = Object.assign({}, i, o), this.handleResize = this.handleResize.bind(this), this.getCastFn = this.getCastFn.bind(this), this.applyEventsSynchronously = this.applyEventsSynchronously.bind(this), this.emitter.on(N.Resize, this.handleResize), this.setupDom();
    for (const a of this.config.plugins || [])
      a.getMirror && a.getMirror({ nodeMirror: this.mirror });
    this.emitter.on(N.Flush, () => {
      if (this.usingVirtualDom) {
        const a = { mirror: this.mirror, applyCanvas: (l, c, d) => {
          Ue({ event: l, mutation: c, target: d, imageMap: this.imageMap, canvasEventMap: this.canvasEventMap, errorHandler: this.warnCanvasMutationFailed.bind(this) });
        }, applyInput: this.applyInput.bind(this), applyScroll: this.applyScroll.bind(this), applyStyleSheetMutation: (l, c) => {
          l.source === C.StyleSheetRule ? this.applyStyleSheetRule(l, c) : l.source === C.StyleDeclaration && this.applyStyleDeclaration(l, c);
        }, afterAppend: (l, c) => {
          for (const d of this.config.plugins || [])
            d.onBuild && d.onBuild(l, { id: c, replayer: this });
        } };
        if (this.iframe.contentDocument)
          try {
            te(this.iframe.contentDocument, this.virtualDom, a, this.virtualDom.mirror);
          } catch (l) {
            console.warn(l);
          }
        if (this.virtualDom.destroyTree(), this.usingVirtualDom = !1, Object.keys(this.legacy_missingNodeRetryMap).length)
          for (const l in this.legacy_missingNodeRetryMap)
            try {
              const c = this.legacy_missingNodeRetryMap[l], d = oe(c.node, this.mirror, this.virtualDom.mirror);
              te(d, c.node, a, this.virtualDom.mirror), c.node = d;
            } catch (c) {
              this.warn(c);
            }
        this.constructedStyleMutations.forEach((l) => {
          this.applyStyleSheetMutation(l);
        }), this.constructedStyleMutations = [], this.adoptedStyleSheets.forEach((l) => {
          this.applyAdoptedStyleSheet(l);
        }), this.adoptedStyleSheets = [];
      }
      if (this.mousePos && (this.moveAndHover(this.mousePos.x, this.mousePos.y, this.mousePos.id, !0, this.mousePos.debugData), this.mousePos = null), this.touchActive === !0 ? this.mouse.classList.add("touch-active") : this.touchActive === !1 && this.mouse.classList.remove("touch-active"), this.touchActive = null, this.lastMouseDownEvent) {
        const [a, l] = this.lastMouseDownEvent;
        a.dispatchEvent(l);
      }
      this.lastMouseDownEvent = null, this.lastSelectionData && (this.applySelection(this.lastSelectionData), this.lastSelectionData = null);
    }), this.emitter.on(N.PlayBack, () => {
      this.firstFullSnapshot = null, this.mirror.reset(), this.styleMirror.reset();
    });
    const n = new zt([], { speed: this.config.speed });
    this.service = Qt({ events: e.map((a) => o && o.unpackFn ? o.unpackFn(a) : a).sort((a, l) => a.timestamp - l.timestamp), timer: n, timeOffset: 0, baselineTime: 0, lastPlayedEvent: null }, { getCastFn: this.getCastFn, applyEventsSynchronously: this.applyEventsSynchronously, emitter: this.emitter }), this.service.start(), this.service.subscribe((a) => {
      this.emitter.emit(N.StateChange, { player: a });
    }), this.speedService = nt(ot({ id: "speed", context: { normalSpeed: -1, timer: n }, initial: "normal", states: { normal: { on: { FAST_FORWARD: { target: "skipping", actions: ["recordSpeed", "setSpeed"] }, SET_SPEED: { target: "normal", actions: ["setSpeed"] } } }, skipping: { on: { BACK_TO_NORMAL: { target: "normal", actions: ["restoreSpeed"] }, SET_SPEED: { target: "normal", actions: ["setSpeed"] } } } } }, { actions: { setSpeed: (a, l) => {
      "payload" in l && a.timer.setSpeed(l.payload.speed);
    }, recordSpeed: Y({ normalSpeed: (a) => a.timer.speed }), restoreSpeed: (a) => {
      a.timer.setSpeed(a.normalSpeed);
    } } })), this.speedService.start(), this.speedService.subscribe((a) => {
      this.emitter.emit(N.StateChange, { speed: a });
    });
    const s = this.service.state.context.events.find((a) => a.type === D.Meta), r = this.service.state.context.events.find((a) => a.type === D.FullSnapshot);
    if (s) {
      const { width: a, height: l } = s.data;
      setTimeout(() => {
        this.emitter.emit(N.Resize, { width: a, height: l });
      }, 0);
    }
    r && setTimeout(() => {
      var a;
      this.firstFullSnapshot || (this.firstFullSnapshot = r, this.rebuildFullSnapshot(r), (a = this.iframe.contentWindow) === null || a === void 0 || a.scrollTo(r.data.initialOffset));
    }, 1), this.service.state.context.events.find(Be) && this.mouse.classList.add("touch-device");
  }
  on(e, o) {
    return this.emitter.on(e, o), this;
  }
  off(e, o) {
    return this.emitter.off(e, o), this;
  }
  setConfig(e) {
    Object.keys(e).forEach((o) => {
      e[o], this.config[o] = e[o];
    }), this.config.skipInactive || this.backToNormal(), e.speed !== void 0 && this.speedService.send({ type: "SET_SPEED", payload: { speed: e.speed } }), e.mouseTail !== void 0 && (e.mouseTail === !1 ? this.mouseTail && (this.mouseTail.style.display = "none") : (this.mouseTail || (this.mouseTail = document.createElement("canvas"), this.mouseTail.width = Number.parseFloat(this.iframe.width), this.mouseTail.height = Number.parseFloat(this.iframe.height), this.mouseTail.classList.add("replayer-mouse-tail"), this.wrapper.insertBefore(this.mouseTail, this.iframe)), this.mouseTail.style.display = "inherit"));
  }
  getMetaData() {
    const e = this.service.state.context.events[0], o = this.service.state.context.events[this.service.state.context.events.length - 1];
    return { startTime: e.timestamp, endTime: o.timestamp, totalTime: o.timestamp - e.timestamp };
  }
  getCurrentTime() {
    return this.timer.timeOffset + this.getTimeOffset();
  }
  getTimeOffset() {
    const { baselineTime: e, events: o } = this.service.state.context;
    return e - o[0].timestamp;
  }
  getMirror() {
    return this.mirror;
  }
  play(e = 0) {
    var o, i;
    this.service.state.matches("paused") || this.service.send({ type: "PAUSE" }), this.service.send({ type: "PLAY", payload: { timeOffset: e } }), (i = (o = this.iframe.contentDocument) === null || o === void 0 ? void 0 : o.getElementsByTagName("html")[0]) === null || i === void 0 || i.classList.remove("rrweb-paused"), this.emitter.emit(N.Start);
  }
  pause(e) {
    var o, i;
    e === void 0 && this.service.state.matches("playing") && this.service.send({ type: "PAUSE" }), typeof e == "number" && (this.play(e), this.service.send({ type: "PAUSE" })), (i = (o = this.iframe.contentDocument) === null || o === void 0 ? void 0 : o.getElementsByTagName("html")[0]) === null || i === void 0 || i.classList.add("rrweb-paused"), this.emitter.emit(N.Pause);
  }
  resume(e = 0) {
    this.warn("The 'resume' was deprecated in 1.0. Please use 'play' method which has the same interface."), this.play(e), this.emitter.emit(N.Resume);
  }
  destroy() {
    this.pause(), this.config.root.removeChild(this.wrapper), this.emitter.emit(N.Destroy);
  }
  startLive(e) {
    this.service.send({ type: "TO_LIVE", payload: { baselineTime: e } });
  }
  addEvent(e) {
    const o = this.config.unpackFn ? this.config.unpackFn(e) : e;
    Be(o) && this.mouse.classList.add("touch-device"), Promise.resolve().then(() => this.service.send({ type: "ADD_EVENT", payload: { event: o } }));
  }
  enableInteract() {
    this.iframe.setAttribute("scrolling", "auto"), this.iframe.style.pointerEvents = "auto";
  }
  disableInteract() {
    this.iframe.setAttribute("scrolling", "no"), this.iframe.style.pointerEvents = "none";
  }
  resetCache() {
    this.cache = Te();
  }
  setupDom() {
    this.wrapper = document.createElement("div"), this.wrapper.classList.add("replayer-wrapper"), this.config.root.appendChild(this.wrapper), this.mouse = document.createElement("div"), this.mouse.classList.add("replayer-mouse"), this.wrapper.appendChild(this.mouse), this.config.mouseTail !== !1 && (this.mouseTail = document.createElement("canvas"), this.mouseTail.classList.add("replayer-mouse-tail"), this.mouseTail.style.display = "inherit", this.wrapper.appendChild(this.mouseTail)), this.iframe = document.createElement("iframe");
    const e = ["allow-same-origin"];
    this.config.UNSAFE_replayCanvas && e.push("allow-scripts"), this.iframe.style.display = "none", this.iframe.setAttribute("sandbox", e.join(" ")), this.disableInteract(), this.wrapper.appendChild(this.iframe), this.iframe.contentWindow && this.iframe.contentDocument && (Zt(this.iframe.contentWindow, this.iframe.contentDocument), bt(this.iframe.contentWindow));
  }
  rebuildFullSnapshot(e, o = !1) {
    if (!this.iframe.contentDocument)
      return this.warn("Looks like your replayer has been destroyed.");
    Object.keys(this.legacy_missingNodeRetryMap).length && this.warn("Found unresolved missing node map", this.legacy_missingNodeRetryMap), this.legacy_missingNodeRetryMap = {};
    const i = [], n = (a, l) => {
      this.collectIframeAndAttachDocument(i, a);
      for (const c of this.config.plugins || [])
        c.onBuild && c.onBuild(a, { id: l, replayer: this });
    };
    this.usingVirtualDom && (this.virtualDom.destroyTree(), this.usingVirtualDom = !1), this.mirror.reset(), Et(e.data.node, { doc: this.iframe.contentDocument, afterAppend: n, cache: this.cache, mirror: this.mirror }), n(this.iframe.contentDocument, e.data.node.id);
    for (const { mutationInQueue: a, builtNode: l } of i)
      this.attachDocumentToIframe(a, l), this.newDocumentQueue = this.newDocumentQueue.filter((c) => c !== a);
    const { documentElement: s, head: r } = this.iframe.contentDocument;
    this.insertStyleRules(s, r), this.service.state.matches("playing") || this.iframe.contentDocument.getElementsByTagName("html")[0].classList.add("rrweb-paused"), this.emitter.emit(N.FullsnapshotRebuilded, e), o || this.waitForStylesheetLoad(), this.config.UNSAFE_replayCanvas && this.preloadAllImages();
  }
  insertStyleRules(e, o) {
    var i;
    const n = (s = this.config.blockClass, [`.${s} { background: currentColor }`, "noscript { display: none !important; }"]).concat(this.config.insertStyleRules);
    var s;
    if (this.config.pauseAnimation && n.push("html.rrweb-paused *, html.rrweb-paused *:before, html.rrweb-paused *:after { animation-play-state: paused !important; }"), this.usingVirtualDom) {
      const r = this.virtualDom.createElement("style");
      this.virtualDom.mirror.add(r, Ke(r, this.virtualDom.unserializedId)), e.insertBefore(r, o), r.rules.push({ source: C.StyleSheetRule, adds: n.map((a, l) => ({ rule: a, index: l })) });
    } else {
      const r = document.createElement("style");
      e.insertBefore(r, o);
      for (let a = 0; a < n.length; a++)
        (i = r.sheet) === null || i === void 0 || i.insertRule(n[a], a);
    }
  }
  attachDocumentToIframe(e, o) {
    const i = this.usingVirtualDom ? this.virtualDom.mirror : this.mirror, n = [], s = (r, a) => {
      this.collectIframeAndAttachDocument(n, r);
      const l = i.getMeta(r);
      if ((l == null ? void 0 : l.type) === W.Element && (l == null ? void 0 : l.tagName.toUpperCase()) === "HTML") {
        const { documentElement: c, head: d } = o.contentDocument;
        this.insertStyleRules(c, d);
      }
      if (!this.usingVirtualDom)
        for (const c of this.config.plugins || [])
          c.onBuild && c.onBuild(r, { id: a, replayer: this });
    };
    re(e.node, { doc: o.contentDocument, mirror: i, hackCss: !0, skipChild: !1, afterAppend: s, cache: this.cache }), s(o.contentDocument, e.node.id);
    for (const { mutationInQueue: r, builtNode: a } of n)
      this.attachDocumentToIframe(r, a), this.newDocumentQueue = this.newDocumentQueue.filter((l) => l !== r);
  }
  collectIframeAndAttachDocument(e, o) {
    if (ae(o, this.mirror)) {
      const i = this.newDocumentQueue.find((n) => n.parentId === this.mirror.getId(o));
      i && e.push({ mutationInQueue: i, builtNode: o });
    }
  }
  waitForStylesheetLoad() {
    var e;
    const o = (e = this.iframe.contentDocument) === null || e === void 0 ? void 0 : e.head;
    if (o) {
      const i = /* @__PURE__ */ new Set();
      let n, s = this.service.state;
      const r = () => {
        s = this.service.state;
      };
      this.emitter.on(N.Start, r), this.emitter.on(N.Pause, r);
      const a = () => {
        this.emitter.off(N.Start, r), this.emitter.off(N.Pause, r);
      };
      o.querySelectorAll('link[rel="stylesheet"]').forEach((l) => {
        l.sheet || (i.add(l), l.addEventListener("load", () => {
          i.delete(l), i.size === 0 && n !== -1 && (s.matches("playing") && this.play(this.getCurrentTime()), this.emitter.emit(N.LoadStylesheetEnd), n && clearTimeout(n), a());
        }));
      }), i.size > 0 && (this.service.send({ type: "PAUSE" }), this.emitter.emit(N.LoadStylesheetStart), n = setTimeout(() => {
        s.matches("playing") && this.play(this.getCurrentTime()), n = -1, a();
      }, this.config.loadTimeout));
    }
  }
  preloadAllImages() {
    return H(this, void 0, void 0, function* () {
      this.service.state;
      const e = () => {
        this.service.state;
      };
      this.emitter.on(N.Start, e), this.emitter.on(N.Pause, e);
      const o = [];
      for (const i of this.service.state.context.events)
        i.type === D.IncrementalSnapshot && i.data.source === C.CanvasMutation && (o.push(this.deserializeAndPreloadCanvasEvents(i.data, i)), ("commands" in i.data ? i.data.commands : [i.data]).forEach((n) => {
          this.preloadImages(n, i);
        }));
      return Promise.all(o);
    });
  }
  preloadImages(e, o) {
    if (e.property === "drawImage" && typeof e.args[0] == "string" && !this.imageMap.has(o)) {
      const i = document.createElement("canvas"), n = i.getContext("2d"), s = n == null ? void 0 : n.createImageData(i.width, i.height);
      s == null || s.data, JSON.parse(e.args[0]), n == null || n.putImageData(s, 0, 0);
    }
  }
  deserializeAndPreloadCanvasEvents(e, o) {
    return H(this, void 0, void 0, function* () {
      if (!this.canvasEventMap.has(o)) {
        const i = { isUnchanged: !0 };
        if ("commands" in e) {
          const n = yield Promise.all(e.commands.map((s) => H(this, void 0, void 0, function* () {
            const r = yield Promise.all(s.args.map(j(this.imageMap, null, i)));
            return Object.assign(Object.assign({}, s), { args: r });
          })));
          i.isUnchanged === !1 && this.canvasEventMap.set(o, Object.assign(Object.assign({}, e), { commands: n }));
        } else {
          const n = yield Promise.all(e.args.map(j(this.imageMap, null, i)));
          i.isUnchanged === !1 && this.canvasEventMap.set(o, Object.assign(Object.assign({}, e), { args: n }));
        }
      }
    });
  }
  applyIncremental(e, o) {
    var i, n, s;
    const { data: r } = e;
    switch (r.source) {
      case C.Mutation:
        try {
          this.applyMutation(r, o);
        } catch (a) {
          this.warn(`Exception in mutation ${a.message || a}`, r);
        }
        break;
      case C.Drag:
      case C.TouchMove:
      case C.MouseMove:
        if (o) {
          const a = r.positions[r.positions.length - 1];
          this.mousePos = { x: a.x, y: a.y, id: a.id, debugData: r };
        } else
          r.positions.forEach((a) => {
            const l = { doAction: () => {
              this.moveAndHover(a.x, a.y, a.id, o, r);
            }, delay: a.timeOffset + e.timestamp - this.service.state.context.baselineTime };
            this.timer.addAction(l);
          }), this.timer.addAction({ doAction() {
          }, delay: e.delay - ((i = r.positions[0]) === null || i === void 0 ? void 0 : i.timeOffset) });
        break;
      case C.MouseInteraction: {
        if (r.id === -1)
          break;
        const a = new Event(St(R[r.type])), l = this.mirror.getNode(r.id);
        if (!l)
          return this.debugNodeNotFound(r, r.id);
        this.emitter.emit(N.MouseInteraction, { type: r.type, target: l });
        const { triggerFocus: c } = this.config;
        switch (r.type) {
          case R.Blur:
            "blur" in l && l.blur();
            break;
          case R.Focus:
            c && l.focus && l.focus({ preventScroll: !0 });
            break;
          case R.Click:
          case R.TouchStart:
          case R.TouchEnd:
          case R.MouseDown:
          case R.MouseUp:
            o ? (r.type === R.TouchStart ? this.touchActive = !0 : r.type === R.TouchEnd && (this.touchActive = !1), r.type === R.MouseDown ? this.lastMouseDownEvent = [l, a] : r.type === R.MouseUp && (this.lastMouseDownEvent = null), this.mousePos = { x: r.x, y: r.y, id: r.id, debugData: r }) : (r.type === R.TouchStart && (this.tailPositions.length = 0), this.moveAndHover(r.x, r.y, r.id, o, r), r.type === R.Click ? (this.mouse.classList.remove("active"), this.mouse.offsetWidth, this.mouse.classList.add("active")) : r.type === R.TouchStart ? (this.mouse.offsetWidth, this.mouse.classList.add("touch-active")) : r.type === R.TouchEnd ? this.mouse.classList.remove("touch-active") : l.dispatchEvent(a));
            break;
          case R.TouchCancel:
            o ? this.touchActive = !1 : this.mouse.classList.remove("touch-active");
            break;
          default:
            l.dispatchEvent(a);
        }
        break;
      }
      case C.Scroll:
        if (r.id === -1)
          break;
        if (this.usingVirtualDom) {
          const a = this.virtualDom.mirror.getNode(r.id);
          if (!a)
            return this.debugNodeNotFound(r, r.id);
          a.scrollData = r;
          break;
        }
        this.applyScroll(r, o);
        break;
      case C.ViewportResize:
        this.emitter.emit(N.Resize, { width: r.width, height: r.height });
        break;
      case C.Input:
        if (r.id === -1)
          break;
        if (this.usingVirtualDom) {
          const a = this.virtualDom.mirror.getNode(r.id);
          if (!a)
            return this.debugNodeNotFound(r, r.id);
          a.inputData = r;
          break;
        }
        this.applyInput(r);
        break;
      case C.MediaInteraction: {
        const a = this.usingVirtualDom ? this.virtualDom.mirror.getNode(r.id) : this.mirror.getNode(r.id);
        if (!a)
          return this.debugNodeNotFound(r, r.id);
        const l = a;
        try {
          r.currentTime !== void 0 && (l.currentTime = r.currentTime), r.volume !== void 0 && (l.volume = r.volume), r.muted !== void 0 && (l.muted = r.muted), r.type === 1 && l.pause(), r.type === 0 && l.play(), r.type === 4 && (l.playbackRate = r.playbackRate);
        } catch (c) {
          this.warn(`Failed to replay media interactions: ${c.message || c}`);
        }
        break;
      }
      case C.StyleSheetRule:
      case C.StyleDeclaration:
        this.usingVirtualDom ? r.styleId ? this.constructedStyleMutations.push(r) : r.id && ((n = this.virtualDom.mirror.getNode(r.id)) === null || n === void 0 || n.rules.push(r)) : this.applyStyleSheetMutation(r);
        break;
      case C.CanvasMutation:
        if (!this.config.UNSAFE_replayCanvas)
          return;
        if (this.usingVirtualDom) {
          const a = this.virtualDom.mirror.getNode(r.id);
          if (!a)
            return this.debugNodeNotFound(r, r.id);
          a.canvasMutations.push({ event: e, mutation: r });
        } else {
          const a = this.mirror.getNode(r.id);
          if (!a)
            return this.debugNodeNotFound(r, r.id);
          Ue({ event: e, mutation: r, target: a, imageMap: this.imageMap, canvasEventMap: this.canvasEventMap, errorHandler: this.warnCanvasMutationFailed.bind(this) });
        }
        break;
      case C.Font:
        try {
          const a = new FontFace(r.family, r.buffer ? new Uint8Array(JSON.parse(r.fontSource)) : r.fontSource, r.descriptors);
          (s = this.iframe.contentDocument) === null || s === void 0 || s.fonts.add(a);
        } catch (a) {
          this.warn(a);
        }
        break;
      case C.Selection:
        if (o) {
          this.lastSelectionData = r;
          break;
        }
        this.applySelection(r);
        break;
      case C.AdoptedStyleSheet:
        this.usingVirtualDom ? this.adoptedStyleSheets.push(r) : this.applyAdoptedStyleSheet(r);
    }
  }
  applyMutation(e, o) {
    if (this.config.useVirtualDom && !this.usingVirtualDom && o && (this.usingVirtualDom = !0, Yt(this.iframe.contentDocument, this.mirror, this.virtualDom), Object.keys(this.legacy_missingNodeRetryMap).length))
      for (const l in this.legacy_missingNodeRetryMap)
        try {
          const c = this.legacy_missingNodeRetryMap[l], d = Qe(c.node, this.virtualDom, this.mirror);
          d && (c.node = d);
        } catch (c) {
          this.warn(c);
        }
    const i = this.usingVirtualDom ? this.virtualDom.mirror : this.mirror;
    e.removes = e.removes.filter((l) => !!i.getNode(l.id) || (this.warnNodeNotFound(e, l.id), !1)), e.removes.forEach((l) => {
      var c;
      const d = i.getNode(l.id);
      if (!d)
        return;
      let u = i.getNode(l.parentId);
      if (!u)
        return this.warnNodeNotFound(e, l.parentId);
      if (l.isShadow && Q(u) && (u = u.shadowRoot), i.removeNodeFromMap(d), u)
        try {
          u.removeChild(d), this.usingVirtualDom && d.nodeName === "#text" && u.nodeName === "STYLE" && ((c = u.rules) === null || c === void 0 ? void 0 : c.length) > 0 && (u.rules = []);
        } catch (h) {
          if (!(h instanceof DOMException))
            throw h;
          this.warn("parent could not remove child in mutation", u, d, e);
        }
    });
    const n = Object.assign({}, this.legacy_missingNodeRetryMap), s = [], r = (l) => {
      var c, d;
      if (!this.iframe.contentDocument)
        return this.warn("Looks like your replayer has been destroyed.");
      let u = i.getNode(l.parentId);
      if (!u)
        return l.node.type === W.Document ? this.newDocumentQueue.push(l) : s.push(l);
      l.node.isShadow && (Q(u) || u.attachShadow({ mode: "open" }), u = u.shadowRoot);
      let h = null, p = null;
      if (l.previousId && (h = i.getNode(l.previousId)), l.nextId && (p = i.getNode(l.nextId)), ((f) => {
        let v = null;
        return f.nextId && (v = i.getNode(f.nextId)), f.nextId !== null && f.nextId !== void 0 && f.nextId !== -1 && !v;
      })(l))
        return s.push(l);
      if (l.node.rootId && !i.getNode(l.node.rootId))
        return;
      const b = l.node.rootId ? i.getNode(l.node.rootId) : this.usingVirtualDom ? this.virtualDom : this.iframe.contentDocument;
      if (ae(u, i))
        return void this.attachDocumentToIframe(l, u);
      const m = (f, v) => {
        if (!this.usingVirtualDom)
          for (const w of this.config.plugins || [])
            w.onBuild && w.onBuild(f, { id: v, replayer: this });
      }, g = re(l.node, { doc: b, mirror: i, skipChild: !0, hackCss: !0, cache: this.cache, afterAppend: m });
      if (l.previousId === -1 || l.nextId === -1)
        return void (n[l.node.id] = { node: g, mutation: l });
      const y = i.getMeta(u);
      if (y && y.type === W.Element && y.tagName === "textarea" && l.node.type === W.Text) {
        const f = Array.isArray(u.childNodes) ? u.childNodes : Array.from(u.childNodes);
        for (const v of f)
          v.nodeType === u.TEXT_NODE && u.removeChild(v);
      } else if ((y == null ? void 0 : y.type) === W.Document) {
        const f = u;
        l.node.type === W.DocumentType && ((c = f.childNodes[0]) === null || c === void 0 ? void 0 : c.nodeType) === Node.DOCUMENT_TYPE_NODE && f.removeChild(f.childNodes[0]), g.nodeName === "HTML" && f.documentElement && f.removeChild(f.documentElement);
      }
      if (h && h.nextSibling && h.nextSibling.parentNode ? u.insertBefore(g, h.nextSibling) : p && p.parentNode ? u.contains(p) ? u.insertBefore(g, p) : u.insertBefore(g, null) : u.appendChild(g), m(g, l.node.id), this.usingVirtualDom && g.nodeName === "#text" && u.nodeName === "STYLE" && ((d = u.rules) === null || d === void 0 ? void 0 : d.length) > 0 && (u.rules = []), ae(g, this.mirror)) {
        const f = this.mirror.getId(g), v = this.newDocumentQueue.find((w) => w.parentId === f);
        v && (this.attachDocumentToIframe(v, g), this.newDocumentQueue = this.newDocumentQueue.filter((w) => w !== v));
      }
      (l.previousId || l.nextId) && this.legacy_resolveMissingNode(n, u, g, l);
    };
    e.adds.forEach((l) => {
      r(l);
    });
    const a = Date.now();
    for (; s.length; ) {
      const l = wt(s);
      if (s.length = 0, Date.now() - a > 500) {
        this.warn("Timeout in the loop, please check the resolve tree data:", l);
        break;
      }
      for (const c of l)
        i.getNode(c.value.parentId) ? Tt(c, (d) => {
          r(d);
        }) : this.debug("Drop resolve tree since there is no parent for the root node.", c);
    }
    Object.keys(n).length && Object.assign(this.legacy_missingNodeRetryMap, n), Nt(e.texts).forEach((l) => {
      var c;
      const d = i.getNode(l.id);
      if (!d)
        return e.removes.find((u) => u.id === l.id) ? void 0 : this.warnNodeNotFound(e, l.id);
      if (d.textContent = l.value, this.usingVirtualDom) {
        const u = d.parentNode;
        ((c = u == null ? void 0 : u.rules) === null || c === void 0 ? void 0 : c.length) > 0 && (u.rules = []);
      }
    }), e.attributes.forEach((l) => {
      const c = i.getNode(l.id);
      if (!c)
        return e.removes.find((d) => d.id === l.id) ? void 0 : this.warnNodeNotFound(e, l.id);
      for (const d in l.attributes)
        if (typeof d == "string") {
          const u = l.attributes[d];
          if (u === null)
            c.removeAttribute(d);
          else if (typeof u == "string")
            try {
              if (d === "_cssText" && (c.nodeName === "LINK" || c.nodeName === "STYLE"))
                try {
                  const h = i.getMeta(c);
                  Object.assign(h.attributes, l.attributes);
                  const p = re(h, { doc: c.ownerDocument, mirror: i, skipChild: !0, hackCss: !0, cache: this.cache }), b = c.nextSibling, m = c.parentNode;
                  if (p && m) {
                    m.removeChild(c), m.insertBefore(p, b), i.replace(l.id, p);
                    break;
                  }
                } catch (h) {
                }
              c.setAttribute(d, u);
            } catch (h) {
              this.warn("An error occurred may due to the checkout feature.", h);
            }
          else if (d === "style") {
            const h = u, p = c;
            for (const b in h)
              if (h[b] === !1)
                p.style.removeProperty(b);
              else if (h[b] instanceof Array) {
                const m = h[b];
                p.style.setProperty(b, m[0], m[1]);
              } else {
                const m = h[b];
                p.style.setProperty(b, m);
              }
          }
        }
    });
  }
  applyScroll(e, o) {
    var i, n;
    const s = this.mirror.getNode(e.id);
    if (!s)
      return this.debugNodeNotFound(e, e.id);
    const r = this.mirror.getMeta(s);
    if (s === this.iframe.contentDocument)
      (i = this.iframe.contentWindow) === null || i === void 0 || i.scrollTo({ top: e.y, left: e.x, behavior: o ? "auto" : "smooth" });
    else if ((r == null ? void 0 : r.type) === W.Document)
      (n = s.defaultView) === null || n === void 0 || n.scrollTo({ top: e.y, left: e.x, behavior: o ? "auto" : "smooth" });
    else
      try {
        s.scrollTo({ top: e.y, left: e.x, behavior: o ? "auto" : "smooth" });
      } catch (a) {
      }
  }
  applyInput(e) {
    const o = this.mirror.getNode(e.id);
    if (!o)
      return this.debugNodeNotFound(e, e.id);
    try {
      o.checked = e.isChecked, o.value = e.text;
    } catch (i) {
    }
  }
  applySelection(e) {
    try {
      const o = /* @__PURE__ */ new Set(), i = e.ranges.map(({ start: n, startOffset: s, end: r, endOffset: a }) => {
        const l = this.mirror.getNode(n), c = this.mirror.getNode(r);
        if (!l || !c)
          return;
        const d = new Range();
        d.setStart(l, s), d.setEnd(c, a);
        const u = l.ownerDocument, h = u == null ? void 0 : u.getSelection();
        return h && o.add(h), { range: d, selection: h };
      });
      o.forEach((n) => n.removeAllRanges()), i.forEach((n) => {
        var s;
        return n && ((s = n.selection) === null || s === void 0 ? void 0 : s.addRange(n.range));
      });
    } catch (o) {
    }
  }
  applyStyleSheetMutation(e) {
    var o;
    let i = null;
    e.styleId ? i = this.styleMirror.getStyle(e.styleId) : e.id && (i = ((o = this.mirror.getNode(e.id)) === null || o === void 0 ? void 0 : o.sheet) || null), i && (e.source === C.StyleSheetRule ? this.applyStyleSheetRule(e, i) : e.source === C.StyleDeclaration && this.applyStyleDeclaration(e, i));
  }
  applyStyleSheetRule(e, o) {
    var i, n, s, r;
    if ((i = e.adds) === null || i === void 0 || i.forEach(({ rule: a, index: l }) => {
      try {
        if (Array.isArray(l)) {
          const { positions: c, index: d } = Ne(l);
          K(o.cssRules, c).insertRule(a, d);
        } else {
          const c = l === void 0 ? void 0 : Math.min(l, o.cssRules.length);
          o == null || o.insertRule(a, c);
        }
      } catch (c) {
      }
    }), (n = e.removes) === null || n === void 0 || n.forEach(({ index: a }) => {
      try {
        if (Array.isArray(a)) {
          const { positions: l, index: c } = Ne(a);
          K(o.cssRules, l).deleteRule(c || 0);
        } else
          o == null || o.deleteRule(a);
      } catch (l) {
      }
    }), e.replace)
      try {
        (s = o.replace) === null || s === void 0 || s.call(o, e.replace);
      } catch (a) {
      }
    if (e.replaceSync)
      try {
        (r = o.replaceSync) === null || r === void 0 || r.call(o, e.replaceSync);
      } catch (a) {
      }
  }
  applyStyleDeclaration(e, o) {
    e.set && K(o.rules, e.index).style.setProperty(e.set.property, e.set.value, e.set.priority), e.remove && K(o.rules, e.index).style.removeProperty(e.remove.property);
  }
  applyAdoptedStyleSheet(e) {
    var o;
    const i = this.mirror.getNode(e.id);
    if (!i)
      return;
    (o = e.styles) === null || o === void 0 || o.forEach((r) => {
      var a;
      let l = null, c = null;
      if (Q(i) ? c = ((a = i.ownerDocument) === null || a === void 0 ? void 0 : a.defaultView) || null : i.nodeName === "#document" && (c = i.defaultView), c)
        try {
          l = new c.CSSStyleSheet(), this.styleMirror.add(l, r.styleId), this.applyStyleSheetRule({ source: C.StyleSheetRule, adds: r.rules }, l);
        } catch (d) {
        }
    });
    let n = 0;
    const s = (r, a) => {
      const l = a.map((c) => this.styleMirror.getStyle(c)).filter((c) => c !== null);
      Q(r) ? r.shadowRoot.adoptedStyleSheets = l : r.nodeName === "#document" && (r.adoptedStyleSheets = l), l.length !== a.length && n < 10 && (setTimeout(() => s(r, a), 0 + 100 * n), n++);
    };
    s(i, e.styleIds);
  }
  legacy_resolveMissingNode(e, o, i, n) {
    const { previousId: s, nextId: r } = n, a = s && e[s], l = r && e[r];
    if (a) {
      const { node: c, mutation: d } = a;
      o.insertBefore(c, i), delete e[d.node.id], delete this.legacy_missingNodeRetryMap[d.node.id], (d.previousId || d.nextId) && this.legacy_resolveMissingNode(e, o, c, d);
    }
    if (l) {
      const { node: c, mutation: d } = l;
      o.insertBefore(c, i.nextSibling), delete e[d.node.id], delete this.legacy_missingNodeRetryMap[d.node.id], (d.previousId || d.nextId) && this.legacy_resolveMissingNode(e, o, c, d);
    }
  }
  moveAndHover(e, o, i, n, s) {
    const r = this.mirror.getNode(i);
    if (!r)
      return this.debugNodeNotFound(s, i);
    const a = Ct(r, this.iframe), l = e * a.absoluteScale + a.x, c = o * a.absoluteScale + a.y;
    this.mouse.style.left = `${l}px`, this.mouse.style.top = `${c}px`, n || this.drawMouseTail({ x: l, y: c }), this.hoverElements(r);
  }
  drawMouseTail(e) {
    if (!this.mouseTail)
      return;
    const { lineCap: o, lineWidth: i, strokeStyle: n, duration: s } = this.config.mouseTail === !0 ? de : Object.assign({}, de, this.config.mouseTail), r = () => {
      if (!this.mouseTail)
        return;
      const a = this.mouseTail.getContext("2d");
      a && this.tailPositions.length && (a.clearRect(0, 0, this.mouseTail.width, this.mouseTail.height), a.beginPath(), a.lineWidth = i, a.lineCap = o, a.strokeStyle = n, a.moveTo(this.tailPositions[0].x, this.tailPositions[0].y), this.tailPositions.forEach((l) => a.lineTo(l.x, l.y)), a.stroke());
    };
    this.tailPositions.push(e), r(), setTimeout(() => {
      this.tailPositions = this.tailPositions.filter((a) => a !== e), r();
    }, s / this.speedService.state.context.timer.speed);
  }
  hoverElements(e) {
    var o;
    (o = this.lastHoveredRootNode || this.iframe.contentDocument) === null || o === void 0 || o.querySelectorAll(".\\:hover").forEach((n) => {
      n.classList.remove(":hover");
    }), this.lastHoveredRootNode = e.getRootNode();
    let i = e;
    for (; i; )
      i.classList && i.classList.add(":hover"), i = i.parentElement;
  }
  isUserInteraction(e) {
    return e.type === D.IncrementalSnapshot && e.data.source > C.Mutation && e.data.source <= C.Input;
  }
  backToNormal() {
    this.nextUserInteractionEvent = null, this.speedService.state.matches("normal") || (this.speedService.send({ type: "BACK_TO_NORMAL" }), this.emitter.emit(N.SkipEnd, { speed: this.speedService.state.context.normalSpeed }));
  }
  warnNodeNotFound(e, o) {
    this.warn(`Node with id '${o}' not found. `, e);
  }
  warnCanvasMutationFailed(e, o) {
    this.warn("Has error on canvas update", o, "canvas mutation:", e);
  }
  debugNodeNotFound(e, o) {
    this.debug(`Node with id '${o}' not found. `, e);
  }
  warn(...e) {
    this.config.showWarning && this.config.logger.warn(Ve, ...e);
  }
  debug(...e) {
    this.config.showDebug && this.config.logger.log(Ve, ...e);
  }
}
const oo = V({ name: "DomPreviewer", props: { domEvents: { type: Array, required: !0 } }, data: () => ({ domPlayerAspectRatio: "" }), domPlayer: null, mounted() {
  this.instantiateDomPlayer();
}, beforeUnmount() {
  var t;
  (t = this.$options.domPlayer) == null || t.pause();
}, methods: { instantiateDomPlayer() {
  return A(this, null, function* () {
    var l, c, d;
    if (!(((l = this.domEvents) == null ? void 0 : l.length) > 10))
      return;
    let t = 0, e = 0;
    for (const u of this.domEvents) {
      const h = (c = u == null ? void 0 : u.data) == null ? void 0 : c.width, p = (d = u == null ? void 0 : u.data) == null ? void 0 : d.height;
      h > t && (t = h), p > e && (e = p);
    }
    this.domPlayerAspectRatio = `${t}/${e}`, yield this.$nextTick(), this.$options.domPlayer = new to(this.domEvents, { root: this.$refs.domPlayer, skipInactive: !0, speed: 1.5, triggerFocus: !1, mouseTail: !1 });
    const { width: o, height: i } = this.$refs.domPlayer.getBoundingClientRect(), n = o / t, s = i / e, r = Math.min(n, s), a = document.querySelector(".dom-player .replayer-wrapper");
    a && (a.style.transform = `scale(${r})`, a.style.left = Math.round((o - t * r) / 2) + "px", this.$options.domPlayer.play(), this.$options.domPlayer.on("finish", () => this.$options.domPlayer.play(0)));
  });
} } }, [["render", function(t, e, o, i, n, s) {
  return S(), T("div", { ref: "domPlayer", class: "dom-player", style: Dt({ aspectRatio: n.domPlayerAspectRatio }) }, null, 4);
}]]), no = {}, io = { width: "20", height: "20", viewBox: "0 0 20 20", fill: "none", xmlns: "http://www.w3.org/2000/svg", "aria-hidden": "true" }, so = [I("path", { d: "M5.03226 5.03223C3.90987 5.03223 3 5.94209 3 7.06448V12.9354C3 14.0579 3.90987 14.9677 5.03226 14.9677H10.9032C12.0256 14.9677 12.9355 14.0579 12.9355 12.9354V12.2803L15.9936 13.9792C16.2034 14.0958 16.4592 14.0926 16.6661 13.9709C16.873 13.8492 17 13.6271 17 13.387V6.61707C17 6.37714 16.8731 6.15512 16.6663 6.03335C16.4596 5.9116 16.2039 5.90828 15.9941 6.02464L12.9355 7.72069V7.06448C12.9355 5.94209 12.0256 5.03223 10.9032 5.03223H5.03226ZM12.9355 9.26987L15.6452 7.76731V12.2358L12.9355 10.7304V9.26987ZM11.5806 7.06448V12.9354C11.5806 13.3096 11.2773 13.6129 10.9032 13.6129H5.03226C4.65813 13.6129 4.35484 13.3096 4.35484 12.9354V7.06448C4.35484 6.69035 4.65813 6.38707 5.03226 6.38707H10.9032C11.2773 6.38707 11.5806 6.69035 11.5806 7.06448Z", fill: "currentColor" }, null, -1)], ro = V(no, [["render", function(t, e) {
  return S(), T("svg", io, so);
}]]), ao = {}, lo = { width: "20", height: "20", viewBox: "0 0 20 20", fill: "none", xmlns: "http://www.w3.org/2000/svg", "aria-hidden": "true" }, co = [I("path", { d: "M5.03629 5.03259C3.9139 5.03259 3.00403 5.94246 3.00403 7.06485V12.9358C3.00403 14.0582 3.9139 14.9681 5.03629 14.9681L14.9637 14.9672C16.0861 14.9672 16.996 14.0574 16.996 12.9349V12.2798V7.7202V7.064C16.996 5.9416 16.0861 5.03174 14.9637 5.03174L5.03629 5.03259ZM15.6411 7.064V12.9349C15.6411 13.3091 15.3378 13.6124 14.9637 13.6124L5.03629 13.6132C4.66216 13.6132 4.35887 13.3099 4.35887 12.9358V7.06485C4.35887 6.69072 4.66216 6.38743 5.03629 6.38743L14.9637 6.38658C15.3378 6.38658 15.6411 6.68986 15.6411 7.064Z", fill: "currentColor" }, null, -1), I("path", { d: "M13.6 9.56587C13.6 10.2838 13.018 10.8659 12.3 10.8659C11.582 10.8659 11 10.2838 11 9.56587C11 8.8479 11.582 8.26587 12.3 8.26587C13.018 8.26587 13.6 8.8479 13.6 9.56587Z", fill: "currentColor" }, null, -1), I("path", { "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M9.51596 12.148C8.97811 11.5333 8.02186 11.5333 7.48401 12.148L5.48916 14.4278C5.25277 14.698 4.84212 14.7253 4.57196 14.489C4.30179 14.2526 4.27442 13.8419 4.51081 13.5718L6.50566 11.2919C7.56145 10.0853 9.43852 10.0853 10.4943 11.2919L12.4892 13.5718C12.7256 13.8419 12.6982 14.2526 12.428 14.489C12.1578 14.7253 11.7472 14.698 11.5108 14.4278L9.51596 12.148Z", fill: "currentColor" }, null, -1)], uo = { name: "VisualProof", components: { IconRecording: ro, IconScreenshot: V(ao, [["render", function(t, e) {
  return S(), T("svg", lo, co);
}]]), DomPreviewer: oo }, props: { domEvents: { type: Array, required: !1, default: null }, screenshotDataUrl: { type: String, required: !1, default: null }, videoDataUrl: { type: String, required: !1, default: null }, hasVisualProof: { type: Boolean } }, emits: ["remove"], data: () => {
  var t;
  return { options: window.birdeatsbug.options.ui.previewScreen, text: (t = window.birdeatsbug.options.ui.text) == null ? void 0 : t.previewScreen, isConfirmingRemoval: !1, isConfirmingReplace: !1 };
}, computed: { isRequiredVisualProofMissing() {
  var t;
  return ((t = this.options) == null ? void 0 : t.visualProof) === "required" && !this.hasVisualProof;
}, isInstantReplayEnabled: () => window.birdeatsbug.options.instantReplay, visualProofMissingErrorMessage() {
  var t;
  return ((t = this.text) == null ? void 0 : t.visualProofMissingErrorMessage) || "Please add a visual proof to complete your report.";
}, showStartScreenRecordingButton() {
  var t, e;
  return ((e = (t = this.options) == null ? void 0 : t.visualProofButtons) == null ? void 0 : e.screenRecording) !== !1;
}, showTakeScreenshotButton() {
  var t, e;
  return ((e = (t = this.options) == null ? void 0 : t.visualProofButtons) == null ? void 0 : e.screenshot) !== !1 && window.birdeatsbug.isScreenshotSupported;
}, buttonStartScreenRecordingText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.startScreenRecordingButton) || "Start recording";
}, buttonTakeScreenshotText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.takeScreenshotButton) || "Take screenshot";
}, buttonReplaceVisualProofText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.replaceVisualProofButton) || "Replace";
}, buttonRemoveVisualProofText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.removeVisualProofButton) || "Remove";
}, buttonCancelText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.cancelButton) || "Cancel";
}, buttonConfirmRemovalText() {
  var t;
  return ((t = this.text) == null ? void 0 : t.confirmVisualProofRemovalButton) || "Confirm removal";
} }, mounted() {
  return A(this, null, function* () {
    yield this.$nextTick();
    const t = this.$refs.buttonStartScreenRecording || this.$refs.buttonTakeScreenshot;
    t == null || t.focus();
  });
}, methods: { onStartRecordingClick(...t) {
  return A(this, null, function* () {
    yield window.birdeatsbug.deleteSession(), yield window.birdeatsbug.startRecording(...t);
  });
}, onTakeScreenshotClick() {
  return A(this, null, function* () {
    yield window.birdeatsbug.takeScreenshot();
  });
}, preloadScreenRecording() {
  window.birdeatsbug.loadRequiredRecorders(), window.birdeatsbug.options.ui.recordingControls && import("./RecordingControls.js");
}, onRemoveClick() {
  this.$emit("remove"), this.isConfirmingRemoval = !1;
} } }, ho = { key: 0 }, mo = { key: 1, class: "flex gap" }, po = { key: 2 }, fo = ["src"], go = ["src"], vo = { class: "visual-proof-actions" }, yo = V(uo, [["render", function(t, e, o, i, n, s) {
  const r = L("IconRecording"), a = L("IconScreenshot"), l = L("DomPreviewer");
  return S(), T(U, null, [s.isRequiredVisualProofMissing ? (S(), T("p", ho, x(s.visualProofMissingErrorMessage), 1)) : O("", !0), o.hasVisualProof || !s.showStartScreenRecordingButton && !s.showTakeScreenshotButton ? o.hasVisualProof ? (S(), T("div", po, [I("section", { class: je(["visual-proof", { "border-replace": n.isConfirmingReplace, "border-remove": n.isConfirmingRemoval }]) }, [o.domEvents ? (S(), J(l, { key: 0, "dom-events": o.domEvents, class: "media" }, null, 8, ["dom-events"])) : o.screenshotDataUrl ? (S(), T("img", { key: 1, src: o.screenshotDataUrl, class: "media screenshot" }, null, 8, fo)) : o.videoDataUrl ? (S(), T("video", { key: 2, ref: "videoPlayer", src: o.videoDataUrl, autoplay: "", muted: "", disablepictureinpicture: "", playsinline: "", class: "media", onClick: e[3] || (e[3] = (c) => t.$refs.videoPlayer.play()) }, null, 8, go)) : O("", !0), I("div", vo, [o.hasVisualProof ? !o.hasVisualProof || n.isConfirmingRemoval || n.isConfirmingReplace ? n.isConfirmingReplace ? (S(), T(U, { key: 2 }, [I("button", { class: "button button-secondary button-cancel-replace flex-grow rounded-none", onClick: e[9] || (e[9] = (c) => n.isConfirmingReplace = !1) }, x(s.buttonCancelText), 1), s.showStartScreenRecordingButton ? (S(), T("button", { key: 0, class: "button button-primary button-confirm-replace flex-grow rounded-none", onClick: e[10] || (e[10] = (c) => s.onStartRecordingClick({ isReplacingPreviousRecording: !0 })), onPointerenter: e[11] || (e[11] = (...c) => s.preloadScreenRecording && s.preloadScreenRecording(...c)) }, x(s.buttonStartScreenRecordingText), 33)) : O("", !0), s.showTakeScreenshotButton ? (S(), T("button", { key: 1, class: "button button-primary button-confirm-replace flex-grow rounded-none", onClick: e[12] || (e[12] = (...c) => s.onTakeScreenshotClick && s.onTakeScreenshotClick(...c)) }, x(s.buttonTakeScreenshotText), 1)) : O("", !0)], 64)) : n.isConfirmingRemoval ? (S(), T(U, { key: 3 }, [I("button", { class: "button button-confirm-remove flex-grow rounded-none", onClick: e[13] || (e[13] = (...c) => s.onRemoveClick && s.onRemoveClick(...c)) }, x(s.buttonConfirmRemovalText), 1), I("button", { class: "button button-cancel-remove flex-grow rounded-none", onClick: e[14] || (e[14] = (c) => n.isConfirmingRemoval = !1) }, x(s.buttonCancelText), 1)], 64)) : O("", !0) : (S(), T(U, { key: 1 }, [I("button", { class: "button button-secondary button-replace flex-grow rounded-none", onClick: e[7] || (e[7] = (c) => n.isConfirmingReplace = !0) }, x(s.buttonReplaceVisualProofText), 1), I("button", { class: "button button-remove flex-grow rounded-none", onClick: e[8] || (e[8] = (c) => n.isConfirmingRemoval = !0) }, x(s.buttonRemoveVisualProofText), 1)], 64)) : (S(), T(U, { key: 0 }, [s.showStartScreenRecordingButton ? (S(), T("button", { key: 0, class: "button button-primary w-full", onClick: e[4] || (e[4] = (...c) => s.onStartRecordingClick && s.onStartRecordingClick(...c)), onPointerenter: e[5] || (e[5] = (...c) => s.preloadScreenRecording && s.preloadScreenRecording(...c)) }, [$(x(s.buttonStartScreenRecordingText) + " ", 1), _(r)], 32)) : O("", !0), s.showTakeScreenshotButton ? (S(), T("button", { key: 1, class: "button button-primary w-full", onClick: e[6] || (e[6] = (...c) => s.onTakeScreenshotClick && s.onTakeScreenshotClick(...c)) }, [$(x(s.buttonTakeScreenshotText) + " ", 1), _(a)])) : O("", !0)], 64))])], 2)])) : O("", !0) : (S(), T("div", mo, [s.showStartScreenRecordingButton ? (S(), T("button", { key: 0, ref: "buttonStartScreenRecording", class: "button button-primary w-full", onClick: e[0] || (e[0] = (c) => s.onStartRecordingClick({ isReplacingPreviousRecording: s.isInstantReplayEnabled })), onPointerenter: e[1] || (e[1] = (...c) => s.preloadScreenRecording && s.preloadScreenRecording(...c)) }, [$(x(s.buttonStartScreenRecordingText) + " ", 1), _(r)], 544)) : O("", !0), s.showTakeScreenshotButton ? (S(), T("button", { key: 1, ref: "buttonTakeScreenshot", class: "button button-primary w-full", onClick: e[2] || (e[2] = (...c) => s.onTakeScreenshotClick && s.onTakeScreenshotClick(...c)) }, [$(x(s.buttonTakeScreenshotText) + " ", 1), _(a)], 512)) : O("", !0)]))], 64);
}]]), bo = {}, Eo = { width: "18", height: "18", viewBox: "0 0 22 22", fill: "none", "aria-hidden": "true" }, So = [I("path", { d: "M2.72786 9.05449C2.3402 9.20333 2.06516 9.55195 2.01026 9.96338C1.95593 10.3754 2.13081 10.7834 2.4664 11.0273L6.14043 13.7008L19.1897 3.43423L7.6509 14.8021L12.6735 18.4569C12.9927 18.6889 13.4053 18.7585 13.785 18.6436C14.1642 18.5282 14.4664 18.2401 14.6022 17.8694L19.9752 3.16315C20.0295 3.01374 19.991 2.8468 19.8778 2.73531C19.7652 2.62382 19.5983 2.58873 19.4489 2.64589L2.72786 9.05449Z", fill: "currentColor" }, null, -1), I("path", { d: "M5.26776 14.5899L5.29889 14.7602L6.01196 18.6589C6.06516 18.9487 6.25871 19.1914 6.52809 19.3086C6.79747 19.4252 7.10817 19.4003 7.35491 19.2412C8.34812 18.6006 9.64524 17.7506 9.61015 17.7008L5.26776 14.5899Z", fill: "currentColor" }, null, -1)], wo = V(bo, [["render", function(t, e) {
  return S(), T("svg", Eo, So);
}]]), To = {}, No = { width: "20", height: "20", viewBox: "0 0 22 22", fill: "none", "aria-hidden": "true" }, Co = [I("path", { "fill-rule": "evenodd", "clip-rule": "evenodd", d: "M12.375 1C12.375 0.447715 11.9273 0 11.375 0H10.625C10.0727 0 9.62499 0.447715 9.62499 1V4.5C9.62499 5.05228 10.0727 5.5 10.625 5.5H11.375C11.9273 5.5 12.375 5.05228 12.375 4.5V1ZM4.90123 2.95666C4.5107 2.56614 3.87754 2.56614 3.48701 2.95666L2.95668 3.48699C2.56616 3.87752 2.56616 4.51068 2.95668 4.9012L5.43156 7.37608C5.82208 7.7666 6.45525 7.7666 6.84577 7.37608L7.3761 6.84575C7.76663 6.45522 7.76663 5.82206 7.3761 5.43153L4.90123 2.95666ZM16.5685 14.6239C16.178 14.2334 15.5448 14.2334 15.1543 14.6239L14.6239 15.1543C14.2334 15.5448 14.2334 16.1779 14.6239 16.5685L17.0988 19.0433C17.4893 19.4339 18.1225 19.4339 18.513 19.0433L19.0434 18.513C19.4339 18.1225 19.4339 17.4893 19.0434 17.0988L16.5685 14.6239ZM11.375 16.5C11.9273 16.5 12.375 16.9477 12.375 17.5V21C12.375 21.5523 11.9273 22 11.375 22H10.625C10.0727 22 9.62498 21.5523 9.62498 21V17.5C9.62498 16.9477 10.0727 16.5 10.625 16.5H11.375ZM7.37603 15.1543C7.76656 15.5448 7.76656 16.1779 7.37603 16.5685L4.90116 19.0433C4.51064 19.4339 3.87747 19.4339 3.48695 19.0433L2.95662 18.513C2.56609 18.1225 2.56609 17.4893 2.95662 17.0988L5.43149 14.6239C5.82202 14.2334 6.45518 14.2334 6.8457 14.6239L7.37603 15.1543ZM19.0433 4.90121C19.4338 4.51068 19.4338 3.87752 19.0433 3.48699L18.513 2.95666C18.1224 2.56614 17.4893 2.56614 17.0988 2.95666L14.6239 5.43154C14.2334 5.82206 14.2334 6.45523 14.6239 6.84575L15.1542 7.37608C15.5447 7.76661 16.1779 7.76661 16.5684 7.37608L19.0433 4.90121ZM16.5 10.625C16.5 10.0727 16.9477 9.625 17.5 9.625H21C21.5523 9.625 22 10.0727 22 10.625V11.375C22 11.9273 21.5523 12.375 21 12.375H17.5C16.9477 12.375 16.5 11.9273 16.5 11.375V10.625ZM1 9.625C0.447715 9.625 0 10.0727 0 10.625V11.375C0 11.9273 0.447715 12.375 1 12.375H4.5C5.05228 12.375 5.5 11.9273 5.5 11.375V10.625C5.5 10.0727 5.05228 9.625 4.5 9.625H1Z", fill: "currentColor" }, null, -1)], Do = { name: "SubmitButton", components: { IconSend: wo, IconSpinner: V(To, [["render", function(t, e) {
  return S(), T("svg", No, Co);
}]]) }, props: { isUploading: Boolean, disabled: Boolean, progressPercentage: { type: Number, default: 0 }, hasError: Boolean }, data: () => {
  var t, e, o, i;
  return { submitButtonText: ((e = (t = window.birdeatsbug.options.ui.text) == null ? void 0 : t.previewScreen) == null ? void 0 : e.submitButton) || "Submit", submitButtonErrorText: ((i = (o = window.birdeatsbug.options.ui.text) == null ? void 0 : o.previewScreen) == null ? void 0 : i.uploadError) || "Error. Try again" };
} }, Mo = ["disabled"], Ro = V(Do, [["render", function(t, e, o, i, n, s) {
  const r = L("IconSpinner"), a = L("IconSend");
  return S(), T("button", { type: "submit", disabled: o.isUploading || o.disabled, class: je(["button", { "button-primary": !o.isUploading && !o.hasError, "button-uploading": o.isUploading, "button-error": o.hasError && !o.isUploading }]) }, [o.hasError && !o.isUploading ? (S(), T(U, { key: 0 }, [$(x(t.submitButtonErrorText), 1)], 64)) : o.isUploading ? (S(), T(U, { key: 1 }, [$(x(o.progressPercentage) + "% ", 1), _(r, { class: "icon-spinner" })], 64)) : (S(), T(U, { key: 2 }, [I("span", null, x(t.submitButtonText), 1), _(a)], 64))], 10, Mo);
}]]), xo = { name: "SessionUploadForm", components: { Select: Ce(() => import("./Select.js")), MultiSelect: Ce(() => import("./MultiSelect.js")), SessionUploadSubmitButton: Ro, Watermark: pt }, props: { session: { type: Object, required: !1, default: null }, hasVisualProof: { type: Boolean }, domEvents: { type: Array, required: !1, default: void 0 }, screenshotDataUrl: { type: String, required: !1, default: null }, videoDataUrl: { type: String, required: !1, default: null }, videoMetadata: { type: Object, required: !1, default: null }, events: { type: Array, required: !1, default: void 0 }, networkRequests: { type: Array, required: !1, default: void 0 } }, data: () => {
  var t;
  return { options: window.birdeatsbug.options.ui.previewScreen, text: (t = window.birdeatsbug.options.ui.text) == null ? void 0 : t.previewScreen, formInputs: {}, dataRedactionPatterns: void 0, selectableCollections: [], collectionId: null, selectableLabels: [], labelIds: [], isRequiredVisualProofMissing: !1, isUploading: !1, uploadProgressPercentage: 0, uploadErrorMessage: null, configErrorMessage: null };
}, computed: { collectionInputPlaceholder() {
  var t, e;
  return (((t = this.text) == null ? void 0 : t.collectionInputPlaceholder) || "Select folder") + (((e = this.text) == null ? void 0 : e.inputOptional) || " (optional)");
}, labelInputPlaceholder() {
  var t, e;
  return (((t = this.text) == null ? void 0 : t.labelInputPlaceholder) || "Select labels") + (((e = this.text) == null ? void 0 : e.inputOptional) || " (optional)");
}, visualProofMissingErrorMessage() {
  var t;
  return ((t = this.text) == null ? void 0 : t.visualProofMissingErrorMessage) || "Please add a visual proof to complete your report.";
} }, watch: { collectionId(t) {
  sessionStorage && (sessionStorage["birdeatsbug-collectionId"] = t);
}, labelIds(t) {
  sessionStorage && (sessionStorage["birdeatsbug-labelIds"] = JSON.stringify(t));
} }, created() {
  return A(this, null, function* () {
    this.createFormInputs(), this.fetchServerProvidedOptions(), document.addEventListener(Me, this.onOptionsUpdate), document.addEventListener(Re, this.onUploadProgress);
  });
}, beforeUnmount() {
  document.removeEventListener(Me, this.onOptionsUpdate), document.removeEventListener(Re, this.onUploadProgress);
}, methods: { createFormInputs() {
  var o;
  const t = {};
  for (const i of ["email", "title", "description"])
    t[i] = this.createFormInput(i);
  const e = t[(o = Object.keys(t)) == null ? void 0 : o[0]];
  e && this.hasVisualProof && (e.autoFocus = !0), this.formInputs = t;
}, fetchServerProvidedOptions() {
  return A(this, null, function* () {
    var e, o;
    let t;
    try {
      t = yield fetch("https://api.birdeatsbug.com/api/v1/sdk/options?publicAppId=" + window.birdeatsbug.options.publicAppId, { referrerPolicy: "origin" }).then((a) => a.json()), this.dataRedactionPatterns = (e = t.dataRedactionPatterns) == null ? void 0 : e.map((a) => new RegExp(a, "gm"));
      const i = (o = t.ui) == null ? void 0 : o.previewScreen;
      this.selectableCollections = i.selectableCollections || [];
      const n = sessionStorage == null ? void 0 : sessionStorage["birdeatsbug-collectionId"], s = this.selectableCollections.find((a) => a.id === n);
      this.collectionId = s ? n : i.defaultCollectionId, this.selectableLabels = i.selectableLabels || [];
      const r = sessionStorage == null ? void 0 : sessionStorage["birdeatsbug-labelIds"];
      if (!r)
        return;
      this.labelIds = JSON.parse(r).filter((a) => this.selectableLabels.find((l) => a === l.id));
    } catch (i) {
      (t == null ? void 0 : t.statusCode) === 401 && (this.configErrorMessage = t.message), console.error(i, t);
    }
  });
}, createFormInput(t) {
  var i, n, s, r, a, l;
  const e = (i = this.options) == null ? void 0 : i[t];
  if (!e)
    return !1;
  const o = { name: t, required: e === "required", value: (sessionStorage == null ? void 0 : sessionStorage[`birdeatsbug-${t}`]) || "", validationErrorMessage: null };
  switch (t) {
    case "title":
      o.htmlTag = "input", o.type = "text", o.placeholder = ((n = this.text) == null ? void 0 : n.titleInputPlaceholder) || "Add a title";
      break;
    case "description":
      o.htmlTag = "textarea", o.placeholder = ((s = this.text) == null ? void 0 : s.descriptionInputPlaceholder) || "Add a description", o.rows = 4;
      break;
    case "email":
      o.htmlTag = "input", o.type = "email", o.placeholder = ((r = this.text) == null ? void 0 : r.emailInputPlaceholder) || "Add an email", o.autocomplete = "email", o.inputmode = "email", o.value = ((a = window.birdeatsbug.options.user) == null ? void 0 : a.email) || o.value;
  }
  return o.required || (o.placeholder += ((l = this.text) == null ? void 0 : l.inputOptional) || " (optional)"), o;
}, onKeyDown(t) {
  const e = t.target.localName;
  if (!t.target.form)
    return;
  const o = Array.from(t.target.form.elements), i = document.getElementById("birdeatsbug-close-button"), n = o[o.length - 1];
  if (t.keyCode === 27)
    return i.focus();
  if (t.keyCode !== 13 || e === "button" && t.target.type === "submit" || e === "textarea" && !t.metaKey)
    return;
  if (e === "input" && t.metaKey)
    return n.focus();
  let s = o.findIndex((r) => r === t.target) + 1;
  return o[s] ? o[s].focus() : n.focus(), t.preventDefault(), !1;
}, onInput(t) {
  const e = t.target;
  this.formInputs[e.name] && (this.formInputs[e.name].value = e.value), sessionStorage && typeof e.value == "string" && (sessionStorage[`birdeatsbug-${e.name}`] = e.value);
}, validateInput(t) {
  const e = t.target;
  e.checkValidity() && (this.formInputs[e.name].invalid = !1, this.formInputs[e.name].validationErrorMessage = "");
}, onInvalidInput(t) {
  const e = t.target;
  this.formInputs[e.name].invalid = !0, this.formInputs[e.name].validationErrorMessage = e.validationMessage;
}, onOptionsUpdate(t) {
  return A(this, null, function* () {
    var i, n, s;
    const e = (n = (i = t.detail.changedOptions) == null ? void 0 : i.user) == null ? void 0 : n.email;
    if (!e || (s = this.formInputs.email) != null && s.value)
      return;
    this.formInputs.email.value = e, yield this.$nextTick();
    const o = Array.from(this.$refs.form.elements).find((r) => r.type === "email");
    o && o.dispatchEvent(new Event("blur"));
  });
}, onSubmit(t) {
  return A(this, null, function* () {
    var o, i, n, s, r;
    t.preventDefault();
    const e = t.target;
    if (e.checkValidity()) {
      if (this.isRequiredVisualProofMissing = ((o = this.options) == null ? void 0 : o.visualProof) === "required" && !this.hasVisualProof, !this.isRequiredVisualProofMissing) {
        this.isUploading = !0, this.uploadErrorMessage = null;
        try {
          for (; !this.session || !this.dataRedactionPatterns; )
            yield He(50);
          const a = this.session;
          if (a.title = (i = e.elements.title) == null ? void 0 : i.value, a.description = (n = e.elements.description) == null ? void 0 : n.value, a.uploaderEmail = ((s = e.elements.email) == null ? void 0 : s.value) || ((r = window.birdeatsbug.options.user) == null ? void 0 : r.email), a.collectionId = this.collectionId, a.labelIds = this.labelIds, this.videoMetadata)
            for (const [l, c] of Object.entries(this.videoMetadata))
              a[l] = c;
          if (yield window.birdeatsbug.uploadSession({ session: a, events: this.events, domEvents: this.domEvents, networkRequests: this.networkRequests, screenshot: this.screenshotDataUrl, video: this.videoDataUrl, dataRedactionPatterns: this.dataRedactionPatterns }), !sessionStorage)
            return;
          delete sessionStorage["birdeatsbug-title"], delete sessionStorage["birdeatsbug-description"], delete sessionStorage["birdeatsbug-labelIds"];
        } catch (a) {
          this.uploadErrorMessage = a.message, this.isUploading = !1;
        }
      }
    } else {
      t.stopImmediatePropagation();
      const a = Array.from(e.elements).find((l) => l.classList.contains("invalid"));
      a == null || a.focus();
    }
  });
}, onDiscardClick() {
  window.birdeatsbug.ui.close();
}, closeSelectInputs() {
  var t, e;
  (t = this.$refs.collectionInput) == null || t.close(), (e = this.$refs.labelInput) == null || e.close();
}, onUploadProgress(t) {
  var e;
  (e = t.detail) != null && e.progressPercentage && (this.uploadProgressPercentage = t.detail.progressPercentage);
} } }, Io = { key: 2, class: "input invalid" }, ko = { class: "form-error" }, Ao = { class: "form-footer" };
function Oo() {
  return A(this, null, function* () {
    var r, a;
    if (((r = navigator == null ? void 0 : navigator.connection) == null ? void 0 : r.downlink) < 10) {
      const l = navigator.connection.downlink, c = navigator.connection.rtt;
      return void document.dispatchEvent(new CustomEvent(ee, { detail: { speedInMbps: l, roundTripTimeInMs: c } }));
    }
    let t, e;
    t = (/* @__PURE__ */ new Date()).getTime();
    const o = "?nnn=" + t, i = new Image();
    i.src = "https://static.birdeatsbug.com/general/bird.jpg" + o, yield function(l) {
      return A(this, null, function* () {
        return new Promise((c) => {
          l.onload = c;
        });
      });
    }(i), e = (/* @__PURE__ */ new Date()).getTime();
    const n = (((69213312 / ((e - t) / 1e3)).toFixed(2) / 1024).toFixed(2) / 1024).toFixed(), s = (a = navigator.connection) == null ? void 0 : a.rtt;
    document.dispatchEvent(new CustomEvent(ee, { detail: { speedInMbps: n, roundTripTimeInMs: s } }));
  });
}
const Po = { class: "screen preview-screen" }, Ho = V({ name: "PreviewScreen", components: { Header: ft, VisualProof: yo, SessionUploadForm: V(xo, [["render", function(t, e, o, i, n, s) {
  const r = L("Select"), a = L("MultiSelect"), l = L("Watermark"), c = L("SessionUploadSubmitButton");
  return S(), T("form", { ref: "form", noValidate: "", onKeydown: e[4] || (e[4] = (...d) => s.onKeyDown && s.onKeyDown(...d)), onSubmit: e[5] || (e[5] = (...d) => s.onSubmit && s.onSubmit(...d)), onClick: e[6] || (e[6] = (...d) => s.closeSelectInputs && s.closeSelectInputs(...d)) }, [(S(!0), T(U, null, Mt(n.formInputs, (d) => (S(), T(U, null, [d ? (S(), J(xt(d.htmlTag), Rt({ key: 0 }, d, { key: d.name, class: [{ invalid: d.invalid }, "input"], "data-1p-ignore": "", "data-lp-ignore": "", onInput: s.onInput, onBlur: s.validateInput, onInvalid: s.onInvalidInput }), null, 16, ["class", "onInput", "onBlur", "onInvalid"])) : O("", !0), d.validationErrorMessage ? (S(), T("p", { key: d.name + "-error", class: "form-error" }, x(d.validationErrorMessage), 1)) : O("", !0)], 64))), 256)), n.selectableCollections.length > 1 ? (S(), J(r, { key: 0, ref: "collectionInput", modelValue: n.collectionId, "onUpdate:modelValue": e[0] || (e[0] = (d) => n.collectionId = d), placeholder: s.collectionInputPlaceholder, options: n.selectableCollections, onClick: e[1] || (e[1] = De(() => {
  }, ["stop"])) }, null, 8, ["modelValue", "placeholder", "options"])) : O("", !0), n.selectableLabels.length > 1 ? (S(), J(a, { key: 1, ref: "labelInput", values: n.labelIds, "onUpdate:values": e[2] || (e[2] = (d) => n.labelIds = d), "form-input-name": "labelIds", placeholder: s.labelInputPlaceholder, options: n.selectableLabels, onClick: e[3] || (e[3] = De(() => {
  }, ["stop"])) }, null, 8, ["values", "placeholder", "options"])) : O("", !0), n.isRequiredVisualProofMissing || n.uploadErrorMessage || n.configErrorMessage ? (S(), T("p", Io, [I("span", ko, x(n.isRequiredVisualProofMissing ? s.visualProofMissingErrorMessage : n.uploadErrorMessage || n.configErrorMessage), 1)])) : O("", !0), I("div", Ao, [_(l), _(c, { "is-uploading": n.isUploading, "progress-percentage": n.uploadProgressPercentage, disabled: n.configErrorMessage !== null, "has-error": n.uploadErrorMessage !== null }, null, 8, ["is-uploading", "progress-percentage", "disabled", "has-error"])])], 544);
}]]) }, inject: ["sessionDataPromise"], data: () => ({ session: null, hasVisualProof: !0, domEvents: null, screenshotDataUrl: null, videoDataUrl: null, events: null, networkRequests: null, videoMetadata: null }), computed: { headerText: () => {
  var t, e;
  return ((e = (t = window.birdeatsbug.options.ui.text) == null ? void 0 : t.previewScreen) == null ? void 0 : e.title) || "Report a bug";
} }, watch: { sessionDataPromise: { immediate: !0, handler: function(t) {
  return A(this, null, function* () {
    const e = yield t;
    this.updateStateFromNewSessionData(e);
  });
} } }, created() {
  return A(this, null, function* () {
    document.addEventListener(ee, this.onNetworkSpeedMeasured), Oo();
  });
}, beforeUnmount() {
  document.removeEventListener(ee, this.onNetworkSpeedMeasured), this.screenshotDataUrl && URL.revokeObjectURL(this.screenshotDataUrl), this.videoDataUrl && URL.revokeObjectURL(this.videoDataUrl);
}, methods: { updateStateFromNewSessionData(t) {
  return A(this, null, function* () {
    var e, o;
    t && (t.session ? this.session = we({}, t.session) : this.session = yield window.birdeatsbug.createSessionIfRequired(), ((e = t.domEvents) == null ? void 0 : e.length) > 10 ? (this.domEvents = t.domEvents, this.hasVisualProof = !0) : (o = t.screenshot) != null && o.dataUrl ? (this.screenshotDataUrl = t.screenshot.dataUrl, this.hasVisualProof = !0) : t.videoDataUrl ? (this.videoDataUrl = t.videoDataUrl, this.hasVisualProof = !0, this.videoMetadata = t.videoMetadata) : (this.domEvents = null, this.screenshotDataUrl = null, this.videoDataUrl = null, this.hasVisualProof = !1), this.events = t.events, this.networkRequests = t.networkRequests);
  });
}, onVisualProofRemove() {
  return A(this, null, function* () {
    yield window.birdeatsbug.deleteSession(), this.updateStateFromNewSessionData({});
  });
}, onNetworkSpeedMeasured(t) {
  return A(this, null, function* () {
    if (t.detail.speedInMbps) {
      for (; !this.session; )
        yield He(50);
      this.session.internetSpeedInMbps = t.detail.speedInMbps, this.session.internetLatencyInMs = t.detail.roundTripTimeInMs;
    }
  });
} } }, [["render", function(t, e, o, i, n, s) {
  const r = L("Header"), a = L("VisualProof"), l = L("SessionUploadForm");
  return S(), T("div", Po, [_(r, null, { default: It(() => [$(x(s.headerText), 1)]), _: 1 }), _(a, { "has-visual-proof": n.hasVisualProof, "dom-events": n.domEvents, "screenshot-data-url": n.screenshotDataUrl, "video-data-url": n.videoDataUrl, onRemove: s.onVisualProofRemove }, null, 8, ["has-visual-proof", "dom-events", "screenshot-data-url", "video-data-url", "onRemove"]), _(l, { session: n.session, "has-visual-proof": n.hasVisualProof, "dom-events": n.domEvents, "screenshot-data-url": n.screenshotDataUrl, "video-data-url": n.videoDataUrl, events: n.events, "network-requests": n.networkRequests, "video-metadata": n.videoMetadata }, null, 8, ["session", "has-visual-proof", "dom-events", "screenshot-data-url", "video-data-url", "events", "network-requests", "video-metadata"])]);
}]]);
export {
  Ho as default
};
