var ke = Object.defineProperty, De = Object.defineProperties;
var $e = Object.getOwnPropertyDescriptors;
var ne = Object.getOwnPropertySymbols;
var je = Object.prototype.hasOwnProperty, Re = Object.prototype.propertyIsEnumerable;
var se = (e, t, n) => t in e ? ke(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, O = (e, t) => {
  for (var n in t || (t = {}))
    je.call(t, n) && se(e, n, t[n]);
  if (ne)
    for (var n of ne(t))
      Re.call(t, n) && se(e, n, t[n]);
  return e;
}, A = (e, t) => De(e, $e(t));
var b = (e, t, n) => new Promise((s, o) => {
  var a = (c) => {
    try {
      r(n.next(c));
    } catch (u) {
      o(u);
    }
  }, i = (c) => {
    try {
      r(n.throw(c));
    } catch (u) {
      o(u);
    }
  }, r = (c) => c.done ? s(c.value) : Promise.resolve(c.value).then(a, i);
  r((n = n.apply(e, t)).next());
});
const l = "production", g = "sdk", We = `BirdEatsBugConsole:${l}:${g}`, Xe = `BirdEatsBugConsoleInjected:${l}:${g}`, Ze = `BirdEatsBugDisconnect:${l}:${g}`, Ye = `BirdEatsBugDom:${l}:${g}`, Ge = `BirdEatsBugDomInjected:${l}:${g}`, Qe = `BirdEatsBugDisableConsole:${l}:${g}`, et = `BirdEatsBugDisableDom:${l}:${g}`, tt = `BirdEatsBugDisableNetwork:${l}:${g}`, nt = `BirdEatsBugDisableKeystrokes:${l}:${g}`, st = `BirdEatsBugEnableConsole:${l}:${g}`, ot = `BirdEatsBugEnableDom:${l}:${g}`, it = `BirdEatsBugEnableKeystrokes:${l}:${g}`, rt = `BirdEatsBugEnableNetwork:${l}:${g}`, at = `BirdEatsBugKeystrokes:${l}:${g}`, dt = `BirdEatsBugKeystrokesInjected:${l}:${g}`, ct = `BirdEatsBugNetwork:${l}:${g}`, ut = `BirdEatsBugNetworkInjected:${l}:${g}`, lt = `BirdEatsBugNetworkSpeedMeasured:${l}:${g}`, gt = `BirdEatsBugTakeDomSnapshot:${l}:${g}`, Ce = `BirdeatsbugUpdateRecordingTime:${l}:${g}`, Oe = `BirdeatsbugUpdateSessionUploadProgress:${l}:${g}`, le = `BirdEatsBugOptionsUpdated:${l}:${g}`, bt = `BirdEatsBugLocalStorage:${l}:${g}`, wt = `BirdEatsBugLocalStorageInjected:${l}:${g}`, pt = `BirdEatsBugDisableLocalStorage:${l}:${g}`, ft = `BirdEatsBugEnableLocalStorage:${l}:${g}`, mt = `BirdEatsBugSessionStorage:${l}:${g}`, yt = `BirdEatsBugSessionStorageInjected:${l}:${g}`, vt = `BirdEatsBugDisableSessionStorage:${l}:${g}`, St = `BirdEatsBugEnableSessionStorage:${l}:${g}`;
function _(e, ...t) {
  if (!t.length)
    return e;
  const n = t.shift();
  if (x(e) && x(n))
    for (const s in n)
      x(n[s]) ? (x(e[s]) || Object.assign(e, { [s]: {} }), _(e[s], n[s])) : Object.assign(e, { [s]: n[s] });
  return _(e, ...t);
}
function x(e) {
  return e && typeof e == "object" && !Array.isArray(e);
}
const Ne = { ui: { theme: "dark", position: "bottom-right", watermark: !0, defaultButton: { icon: "brand" }, recordingControls: !0, previewScreen: { visualProof: "optional", visualProofButtons: { screenshot: !0, screenRecording: !0 }, email: "required", title: "optional", description: "optional" }, submitConfirmationScreen: { sessionLink: !1 } }, recordedEventTypes: { click: !0, keystrokes: !0, "error-uncaught": !0, "error-promise": !0, localStorage: !0, sessionStorage: !0, network: !0, dom: !0, console: { debug: !0, log: !0, info: !0, warn: !0, error: !0, assert: !0, trace: !0, dir: !0, group: !0, table: !0, count: !0, profile: !0, time: !0 } }, integrations: { intercom: !1, zendesk: !1 }, instantReplay: !1, recordVideo: !1 };
function q(e = "default") {
  document.querySelectorAll('[data-birdeatsbug="trigger"]').forEach((t) => {
    var s, o, a, i, r;
    const n = t.id === "birdeatsbug-default-button";
    e === "default" ? (n && (t.innerText = ((o = (s = window.birdeatsbug.options.ui) == null ? void 0 : s.text) == null ? void 0 : o.defaultButton) || "Report a bug"), t.style.visibility = "initial") : e === "loading" ? (n && (t.innerText = ((r = (i = (a = window.birdeatsbug.options.ui) == null ? void 0 : a.text) == null ? void 0 : i.recordingControls) == null ? void 0 : r.starting) || "Starting..."), t.style.visibility = "initial") : e === "hidden" && n && (t.style.visibility = "hidden");
  });
}
const Le = (e, t) => t.some((n) => e instanceof n);
let oe, ie;
const ge = /* @__PURE__ */ new WeakMap(), H = /* @__PURE__ */ new WeakMap(), be = /* @__PURE__ */ new WeakMap(), z = /* @__PURE__ */ new WeakMap(), U = /* @__PURE__ */ new WeakMap();
let J = { get(e, t, n) {
  if (e instanceof IDBTransaction) {
    if (t === "done")
      return H.get(e);
    if (t === "objectStoreNames")
      return e.objectStoreNames || be.get(e);
    if (t === "store")
      return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
  }
  return j(e[t]);
}, set: (e, t, n) => (e[t] = n, !0), has: (e, t) => e instanceof IDBTransaction && (t === "done" || t === "store") || t in e };
function Ae(e) {
  return e !== IDBDatabase.prototype.transaction || "objectStoreNames" in IDBTransaction.prototype ? (ie || (ie = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(e) ? function(...t) {
    return e.apply(V(this), t), j(ge.get(this));
  } : function(...t) {
    return j(e.apply(V(this), t));
  } : function(t, ...n) {
    const s = e.call(V(this), t, ...n);
    return be.set(s, t.sort ? t.sort() : [t]), j(s);
  };
}
function xe(e) {
  return typeof e == "function" ? Ae(e) : (e instanceof IDBTransaction && function(t) {
    if (H.has(t))
      return;
    const n = new Promise((s, o) => {
      const a = () => {
        t.removeEventListener("complete", i), t.removeEventListener("error", r), t.removeEventListener("abort", r);
      }, i = () => {
        s(), a();
      }, r = () => {
        o(t.error || new DOMException("AbortError", "AbortError")), a();
      };
      t.addEventListener("complete", i), t.addEventListener("error", r), t.addEventListener("abort", r);
    });
    H.set(t, n);
  }(e), Le(e, oe || (oe = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])) ? new Proxy(e, J) : e);
}
function j(e) {
  if (e instanceof IDBRequest)
    return function(n) {
      const s = new Promise((o, a) => {
        const i = () => {
          n.removeEventListener("success", r), n.removeEventListener("error", c);
        }, r = () => {
          o(j(n.result)), i();
        }, c = () => {
          a(n.error), i();
        };
        n.addEventListener("success", r), n.addEventListener("error", c);
      });
      return s.then((o) => {
        o instanceof IDBCursor && ge.set(o, n);
      }).catch(() => {
      }), U.set(s, n), s;
    }(e);
  if (z.has(e))
    return z.get(e);
  const t = xe(e);
  return t !== e && (z.set(e, t), U.set(t, e)), t;
}
const V = (e) => U.get(e), Te = ["get", "getKey", "getAll", "getAllKeys", "count"], Pe = ["put", "add", "delete", "clear"], M = /* @__PURE__ */ new Map();
function re(e, t) {
  if (!(e instanceof IDBDatabase) || t in e || typeof t != "string")
    return;
  if (M.get(t))
    return M.get(t);
  const n = t.replace(/FromIndex$/, ""), s = t !== n, o = Pe.includes(n);
  if (!(n in (s ? IDBIndex : IDBObjectStore).prototype) || !o && !Te.includes(n))
    return;
  const a = function(i, ...r) {
    return b(this, null, function* () {
      const c = this.transaction(i, o ? "readwrite" : "readonly");
      let u = c.store;
      return s && (u = u.index(r.shift())), (yield Promise.all([u[n](...r), o && c.done]))[0];
    });
  };
  return M.set(t, a), a;
}
var ae;
ae = (e) => A(O({}, e), { get: (t, n, s) => re(t, n) || e.get(t, n, s), has: (t, n) => !!re(t, n) || e.has(t, n) }), J = ae(J);
const we = function() {
  return b(this, null, function* () {
    try {
      return yield function(e, t, { blocked: n, upgrade: s, blocking: o, terminated: a } = {}) {
        const i = indexedDB.open(e, t), r = j(i);
        return s && i.addEventListener("upgradeneeded", (c) => {
          s(j(i.result), c.oldVersion, c.newVersion, j(i.transaction), c);
        }), n && i.addEventListener("blocked", (c) => n(c.oldVersion, c.newVersion, c)), r.then((c) => {
          a && c.addEventListener("close", () => a()), o && c.addEventListener("versionchange", (u) => o(u.oldVersion, u.newVersion, u));
        }).catch(() => {
        }), r;
      }("birdEatsBugSdk", 9, { upgrade(e, t, n, s) {
        try {
          let o;
          o = e.objectStoreNames.contains("consoleEvents") ? s.objectStore("consoleEvents") : e.createObjectStore("consoleEvents", { keyPath: "id", autoIncrement: !0 }), o.indexNames.contains("sessionId") || o.createIndex("sessionId", "sessionId");
        } catch (o) {
          R("consoleEvents", o);
        }
        try {
          let o;
          o = e.objectStoreNames.contains("navigationEvents") ? s.objectStore("navigationEvents") : e.createObjectStore("navigationEvents", { keyPath: "id", autoIncrement: !0 }), o.indexNames.contains("sessionId") || o.createIndex("sessionId", "sessionId");
        } catch (o) {
          R("navigationEvents", o);
        }
        try {
          let o;
          o = e.objectStoreNames.contains("networkEventsFromInstrumentation") ? s.objectStore("networkEventsFromInstrumentation") : e.createObjectStore("networkEventsFromInstrumentation", { keyPath: "id", autoIncrement: !0 }), o.indexNames.contains("sessionId") || o.createIndex("sessionId", "sessionId");
        } catch (o) {
          R("networkEventsFromInstrumentation", o);
        }
        try {
          let o;
          o = e.objectStoreNames.contains("domEvents") ? s.objectStore("domEvents") : e.createObjectStore("domEvents", { keyPath: "id", autoIncrement: !0 }), o.indexNames.contains("sessionId") || o.createIndex("sessionId", "sessionId");
        } catch (o) {
          R("domEvents", o);
        }
        try {
          let o;
          o = e.objectStoreNames.contains("screenshotEvents") ? s.objectStore("screenshotEvents") : e.createObjectStore("screenshotEvents", { keyPath: "id", autoIncrement: !0 }), o.indexNames.contains("sessionId") || o.createIndex("sessionId", "sessionId");
        } catch (o) {
          R("screenshotEvents", o);
        }
        try {
          let o;
          o = e.objectStoreNames.contains("videoEvents") ? s.objectStore("videoEventsStore") : e.createObjectStore("videoEvents", { keyPath: "id", autoIncrement: !0 }), o.indexNames.contains("sessionId") || o.createIndex("sessionId", "sessionId");
        } catch (o) {
          R("videoEvents", o);
        }
      }, blocked() {
        throw new Error("IndexedDB connection blocked");
      }, blocking() {
        throw new Error("IndexedDB connection blocking");
      }, terminated() {
        throw new Error("IndexedDB connection terminated");
      } });
    } catch (e) {
      fe(e);
    }
  });
}(), pe = ["add", "getAllFromIndex", "transaction"].reduce((e, t) => (e[t] = function(...n) {
  return b(this, null, function* () {
    try {
      return yield (yield we)[t](...n);
    } catch (s) {
      fe(s);
    }
  });
}, e), {});
function fe(e) {
  return b(this, null, function* () {
    console.error(e);
  });
}
function R(e, t) {
  if (!t.message.includes("An object store with the specified name already exists."))
    throw new Error(`${e} upgrade: ${t.message}`);
}
const me = Object.freeze(Object.defineProperty({ __proto__: null, default: pe, indexedDB: we, indexedDBEventStores: ["consoleEvents", "navigationEvents", "networkEventsFromInstrumentation", "domEvents", "screenshotEvents", "videoEvents"] }, Symbol.toStringTag, { value: "Module" }));
function ye() {
  return b(this, null, function* () {
    const e = document.getElementById("birdeatsbug-sdk");
    if (e && e.__vue_app__)
      if (e.__vue_app__)
        e.__vue_app__.unmount();
      else
        for (; e.firstElementChild; )
          e.firstElementChild.remove();
  });
}
function X(e) {
  return new Promise((t) => setTimeout(t, e));
}
const ve = () => b(void 0, null, function* () {
  if (yield X(300), document.visibilityState !== "visible")
    return ve();
}), qe = (e) => {
  const t = document.createElement("video");
  return t.autoplay = !0, t.muted = !0, t.playsInline = !0, t.srcObject = e, t.setAttribute("style", "position:fixed;top:0;left:0;pointer-events:none;visibility:hidden;"), t;
}, ze = (e) => {
  var o, a, i;
  const t = (o = e.srcObject) == null ? void 0 : o.getTracks()[0].getSettings(), n = document.createElement("canvas");
  n.width = (a = t == null ? void 0 : t.width) != null ? a : 0, n.height = (i = t == null ? void 0 : t.height) != null ? i : 0;
  const s = n.getContext("2d");
  return s == null || s.drawImage(e, 0, 0), n;
}, Ve = (e) => {
  var n;
  const t = (n = e.srcObject) == null ? void 0 : n.getTracks();
  t == null || t.forEach((s) => s.stop()), e.srcObject = null, e.remove();
};
function Me() {
  var t;
  if (!((t = window.birdeatsbug.session) != null && t.startedAt))
    return;
  const e = new Date(window.birdeatsbug.session.startedAt).getTime();
  document.dispatchEvent(new CustomEvent(Ce, { detail: { time: Date.now() - e } }));
}
function Fe() {
  return b(this, null, function* () {
    var s, o;
    if (!((s = window.birdeatsbug.options) != null && s.instantReplay) || !((o = window.birdeatsbug.session) != null && o.isInstantReplay))
      return;
    const { default: e, indexedDBEventStores: t } = yield Promise.resolve().then(() => me);
    for (const a of t) {
      const i = yield e.transaction(a, "readwrite");
      let r = yield i.store.index("sessionId").openCursor();
      for (; r; ) {
        const c = r.value;
        (n = c.createdAt || c.startedAt || c.endedAt) instanceof Date == 0 && (n = new Date(n)), (Date.now() - n.getTime()) / 1e3 / 60 > 2 && r.delete(), r = yield r.continue();
      }
      yield i.done;
    }
    var n;
  });
}
function T(e, t = []) {
  if (!e)
    return e;
  for (const n of t)
    e = e.replaceAll(n, K);
  return e;
}
function E(e, t = []) {
  return e && JSON.parse(JSON.stringify(e, (n, s) => {
    if (!s)
      return s;
    const o = typeof s;
    if (o === "object")
      return s;
    let a = String(n) + String(s), i = String(n);
    for (const r of t)
      a = a.replaceAll(r, K), i = i.replaceAll(r, K);
    return a = a.replace(i, ""), o === "number" ? Number.isNaN(Number.parseFloat(a)) ? a : Number.isInteger(Number.parseFloat(a)) ? Number.parseInt(a) : Number.parseFloat(a) : o === "boolean" && ["true", "false"].includes(a) ? !!a : a;
  }));
}
function K(e, ...t) {
  const n = typeof t.at(-1) == "object";
  return t.length > (n ? 3 : 2) ? (t.slice(0, n ? -3 : -2).forEach((s) => e = e.replace(s, "*".repeat(Math.max(s.length, 4)))), e) : "*".repeat(Math.max(e.length, 4));
}
function de() {
  return b(this, null, function* () {
    if (!navigator.onLine)
      return !1;
    try {
      return yield fetch("https://api.birdeatsbug.com/api/v1/"), !0;
    } catch (e) {
      return !1;
    }
  });
}
const k = "application/json", _e = { video: "video/webm", screenshot: "image/jpeg", events: k, networkRequests: k, domEvents: k, session: k };
let S = new Proxy({ fileSizeInBytes: 0, uploadedFileSizeInBytes: 0 }, { set(e, t) {
  if (t === "uploadedFileSizeInBytes") {
    let n = Math.min(Math.round(e.uploadedFileSizeInBytes / e.fileSizeInBytes * 100), 100);
    e.fileSizeInBytes === 0 && (n = 0), document.dispatchEvent(new CustomEvent(Oe, { detail: { progressPercentage: n } }));
  }
  return Reflect.set(...arguments);
} });
function He(e, t, n) {
  return b(this, null, function* () {
    let s = navigator.onLine;
    const o = [...Array(4).keys()], a = S.uploadedFileSizeInBytes;
    for (const i of o)
      try {
        let r = 0;
        for (; i > 0 && !s; )
          S.uploadedFileSizeInBytes = a, yield X(1e3 * Math.min(r + 1, 10)), s = yield de(), r++;
        i > 0 && (S.uploadedFileSizeInBytes = a), yield Ue(e, t, n);
        break;
      } catch (r) {
        if (console.error(r), i === 3 || r.isBadRequest)
          throw r;
        s = yield de();
      }
  });
}
function Ue(e, t, n) {
  return b(this, null, function* () {
    const s = S.uploadedFileSizeInBytes;
    return new Promise((o, a) => {
      const i = new XMLHttpRequest();
      i.open("PUT", e);
      for (const c in n)
        i.setRequestHeader(c, n[c]);
      const r = new AbortController();
      i.upload.addEventListener("progress", (c) => {
        const u = c.loaded / c.total;
        navigator.onLine && u !== 100 && (S.uploadedFileSizeInBytes = s + u * t.size);
      }), i.addEventListener("loadend", function() {
        var c, u;
        if (i.status === 200)
          S.uploadedFileSizeInBytes = s + t.size, o(i.response);
        else if (i.responseXML) {
          const w = new Error(`Error during upload HTTP ${i.status}`);
          try {
            const p = (c = i.responseXML.getElementsByTagName("Message")) == null ? void 0 : c[0].textContent, y = (u = i.responseXML.getElementsByTagName("Details")) == null ? void 0 : u[0].textContent;
            p && (w.name = p), y && (w.message = y), w.isBadRequest = String(i.status)[0] === "4";
          } catch (p) {
            console.error(p);
          }
          a(w);
        } else {
          const w = new Error("Please check your internet connection.");
          a(w);
        }
        r.abort();
      }), i.send(t);
    });
  });
}
function W(n) {
  return b(this, arguments, function* (e, t = {}) {
    let s = document.getElementById("birdeatsbug-sdk");
    if (s)
      ye(), s.style.removeProperty("top"), s.style.removeProperty("left");
    else {
      s = document.createElement("div"), s.id = "birdeatsbug-sdk";
      let i = 0, r = 0;
      const c = function(w) {
        w.preventDefault();
        const p = w.clientX - i, y = w.clientY - r;
        i = w.clientX, r = w.clientY;
        const B = s.getBoundingClientRect();
        s.offsetTop + y > 0 && s.offsetTop + y + B.height <= window.innerHeight && (s.style.top = `${s.offsetTop + y}px`), s.offsetLeft + p > 0 && s.offsetLeft + p + B.width <= window.innerWidth && (s.style.left = `${s.offsetLeft + p}px`), s.classList.add("dragging"), s.inert = !0;
      }, u = function() {
        document.removeEventListener("mousemove", c), document.removeEventListener("mouseup", u), s.classList.remove("dragging"), s.inert = !1;
      };
      s.onmousedown = function(w) {
        const p = w.target.classList;
        (p.contains("header-title") || p.contains("recording-status")) && (i = w.clientX, r = w.clientY, document.addEventListener("mousemove", c), document.addEventListener("mouseup", u));
      }, document.body.appendChild(s);
    }
    const { position: o, theme: a } = window.birdeatsbug.options.ui;
    if (s.classList = `${o} ${a}`, !e)
      return s;
    if (e instanceof Element)
      s.appendChild(e);
    else {
      const i = (0, (yield import("./vue.runtime.esm-bundler.js")).createApp)(e);
      for (const [r, c] of Object.entries(t))
        i.provide(r, c);
      i.mount(s);
    }
    return s;
  });
}
const Je = Object.freeze(Object.defineProperty({ __proto__: null, default: W }, Symbol.toStringTag, { value: "Module" }));
function Se() {
  var s, o;
  const e = window.birdeatsbug.options;
  if (!e.ui.defaultButton)
    return W();
  if (document.getElementById("birdeatsbug-default-button"))
    return;
  const t = document.createElement("button");
  t.id = "birdeatsbug-default-button", t.innerText = ((s = e.ui.text) == null ? void 0 : s.defaultButton) || "Report a bug", t.classList.add("button", "button-primary"), t.dataset.birdeatsbug = "trigger";
  const n = (o = e.ui.defaultButton) == null ? void 0 : o.icon;
  if (n) {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    if (a.setAttribute("fill", "none"), a.setAttribute("viewBox", "0 0 20 20"), a.setAttribute("width", "20"), a.setAttribute("height", "20"), a.setAttribute("aria-hidden", "true"), n == "exclamation") {
      const i = document.createElementNS("http://www.w3.org/2000/svg", "path");
      i.setAttribute("d", "M13.3334 1.66663H6.66669C3.90919 1.66663 1.66669 3.90913 1.66669 6.66663V17.5C1.66669 17.721 1.75448 17.9329 1.91076 18.0892C2.06704 18.2455 2.27901 18.3333 2.50002 18.3333H13.3334C16.0909 18.3333 18.3334 16.0908 18.3334 13.3333V6.66663C18.3334 3.90913 16.0909 1.66663 13.3334 1.66663ZM10.8334 15H9.16669V13.3333H10.8334V15ZM10.8334 11.6666H9.16669V4.99996H10.8334V11.6666Z"), i.setAttribute("fill", "currentColor"), a.appendChild(i);
    } else {
      let i = document.createElementNS("http://www.w3.org/2000/svg", "path");
      i.setAttribute("d", "M19.3367 10.0014L14.67 15.2934L14.67 4.70935L19.3367 10.0014Z"), i.setAttribute("fill", "currentColor"), a.appendChild(i), i = document.createElementNS("http://www.w3.org/2000/svg", "path"), i.setAttribute("d", "M8.66998 18C11.0594 18 13.2041 16.9525 14.67 15.2916V4.70835C13.2041 3.04751 11.0594 2 8.66998 2C4.2517 2 0.669983 5.58172 0.669983 10C0.669983 14.4183 4.2517 18 8.66998 18ZM8.67001 11.6C9.55366 11.6 10.27 10.8837 10.27 10C10.27 9.11637 9.55366 8.40002 8.67001 8.40002C7.78635 8.40002 7.07001 9.11637 7.07001 10C7.07001 10.8837 7.78635 11.6 8.67001 11.6Z"), i.setAttribute("fill", "currentColor"), i.setAttribute("fill-rule", "evenodd"), i.setAttribute("clip-rule", "evenodd"), i.setAttribute("opacity", "0.75"), a.appendChild(i);
    }
    t.appendChild(a);
  }
  W(t);
}
function he(e) {
  return e.addEventListener("click", window.birdeatsbug.trigger), e.addEventListener("pointerenter", ce), e.addEventListener("focusin", ce), e.style.visibility = "visible", e;
}
function ce() {
  var e;
  typeof ((e = window.birdeatsbug.options.hooks) == null ? void 0 : e.onTrigger) != "function" && import("./PreviewScreen.js");
}
function F(e, t) {
  return b(this, null, function* () {
    const [n, s] = yield Promise.all([Promise.resolve().then(() => Je), e]);
    return (0, n.default)(s.default, O({}, t));
  });
}
const P = { initialize: Be, setOptions: function(e = {}) {
  const t = _(Ne, window.birdeatsbug.options, e);
  window.birdeatsbug.options, window.birdeatsbug.options = t, document.dispatchEvent(new CustomEvent(le, { detail: { changedOptions: e, options: t } }));
}, loadRequiredRecorders: function() {
  return b(this, null, function* () {
    const e = window.birdeatsbug, t = e.options.recordedEventTypes, n = {};
    if (t.click === !1 || e.recordClicks || (n.recordClicks = import("./clicks.js")), t.keystrokes === !1 || e.recordKeystrokes || (n.recordKeystrokes = import("./keystrokes.js")), t.localStorage === !1 || e.recordLocalStorage || (n.recordLocalStorage = import("./localStorage.js")), t.sessionStorage === !1 || e.recordSessionStorage || (n.recordSessionStorage = import("./sessionStorage.js")), t.network === !1 || e.recordNetwork || (n.recordNetwork = import("./network.js")), e.options.recordVideo && e.isVideoRecordingSupported && !e.recordVideo && (n.recordVideo = import("./video.js")), t.dom === !1 || e.recordDom || (n.recordDom = import("./dom.js")), (t.console && Object.values(t.console).some((s) => s !== !1) || ["error-uncaught", "error-promise"].some((s) => t[s] !== !1)) && !e.recordConsole && (n.recordConsole = import("./console.js")), e.recordNavigation || (n.recordNavigation = import("./navigation.js")), Object.keys(n).length !== 0)
      return yield Promise.all(Object.values(n)), Promise.all(Object.entries(n).map((a) => b(this, [a], function* ([s, o]) {
        const i = yield o;
        window.birdeatsbug[s] = i.default;
      })));
  });
}, trigger: function() {
  return b(this, null, function* () {
    var e, t, n;
    q("loading"), window.birdeatsbug.options.instantReplay || window.birdeatsbug.deleteSession(), typeof ((e = window.birdeatsbug.options.hooks) == null ? void 0 : e.onTrigger) == "function" ? yield window.birdeatsbug.options.hooks.onTrigger() : window.birdeatsbug.stopSession(), (n = (t = window.birdeatsbug.options.hooks) == null ? void 0 : t.afterTrigger) == null || n.call(t), q("hidden");
  });
}, createSessionIfRequired: function() {
  return b(this, arguments, function* ({ isBackgroundRecording: e } = {}) {
    var n;
    if (window.birdeatsbug.session)
      return A(O({}, window.birdeatsbug.session), { isNewSession: !1 });
    const t = yield function() {
      return b(this, null, function* () {
        var p;
        const { nanoid: s } = yield import("./index.browser.js"), { default: o } = yield import("./bowser.js"), a = s(44).split("_").join("-"), i = window.navigator.userAgent, r = o.parse(i);
        try {
          const y = yield (p = window.navigator.userAgentData) == null ? void 0 : p.getHighEntropyValues(["uaFullVersion"]);
          y && (r.browser.version = y.uaFullVersion);
        } catch (y) {
          console.warn(y);
        }
        r.os.name === "macOS" && r.os.version === "10.15.7" && (r.os.version = ">=" + r.os.version);
        const c = document.location.hostname, u = window.navigator.languages && window.navigator.languages.length ? window.navigator.languages[0] : window.navigator.userLanguage || window.navigator.language || window.navigator.browserLanguage || "en", w = { id: a, hostname: c, tabTitle: document.title, userAgent: i, browserName: r.browser.name, browserVersion: r.browser.version, browserEngineName: r.engine.name, browserEngineVersion: r.engine.version, deviceType: r.platform.type, deviceVendor: r.platform.vendor, osName: r.os.name, osVersion: r.os.version, screenWidth: window.screen.width, screenHeight: window.screen.height, windowWidth: window.innerWidth, windowHeight: window.innerHeight, locale: u, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, browserExtensionVersion: "1.98.24", link: `https://app.birdeatsbug.com/${a}` };
        return w.id, w;
      });
    }();
    t.uploadMethod = "sdk", t.startedAt = (/* @__PURE__ */ new Date()).toISOString();
    try {
      const s = yield (n = navigator.userAgentData) == null ? void 0 : n.getHighEntropyValues(["fullVersionList"]);
      s && (t.browserVersion = s.fullVersionList[0].version);
    } catch (s) {
      console.warn(s);
    }
    return e && (t.isInstantReplay = !0), e || (t.startUrl = document.location.href), window.birdeatsbug.session = t, sessionStorage && (sessionStorage.birdeatsbugSession = JSON.stringify(t)), window.birdeatsbug.session;
  });
}, resumeSession: function() {
  return b(this, null, function* () {
    let e = (sessionStorage == null ? void 0 : sessionStorage.birdeatsbugSession) && JSON.parse(sessionStorage.birdeatsbugSession);
    if (window.birdeatsbug.session = e, !!window.birdeatsbug.options.instantReplay)
      e || (e = yield window.birdeatsbug.createSessionIfRequired({ isBackgroundRecording: !0 })), window.birdeatsbug.deleteOldEventInterval || (window.birdeatsbug.deleteOldEventInterval = setInterval(Fe, 3e4));
    else {
      if (!e || e.isInstantReplay)
        return;
      q("hidden");
    }
    if ((sessionStorage == null ? void 0 : sessionStorage.birdeatsbugIsRecording) !== "false" && e)
      return yield window.birdeatsbug.startRecording();
    const n = (0, (yield import("./getSessionData.js")).default)();
    return window.birdeatsbug.ui.showPreviewScreen(n);
  });
}, takeScreenshot: function e() {
  return b(this, null, function* () {
    var t, n, s, o, a;
    if (window.birdeatsbug.isScreenshotSupported) {
      (n = (t = window.birdeatsbug.options.hooks) == null ? void 0 : t.beforeScreenshot) == null || n.call(t);
      try {
        const i = yield navigator.mediaDevices.getDisplayMedia({ preferCurrentTab: !0, video: { frameRate: 30 } });
        ye(), yield ve();
        const r = qe(i);
        if (document.body.appendChild(r), ((s = r.srcObject) == null ? void 0 : s.getTracks()[0].readyState) === "ended")
          return e();
        yield X(300);
        const c = ze(r), u = c.toDataURL("image/png", 0.7);
        Ve(r), c.remove(), yield window.birdeatsbug.deleteSession();
        const w = yield window.birdeatsbug.createSessionIfRequired();
        yield pe.add("screenshotEvents", { type: "screenshot", dataUrl: u, createdAt: (/* @__PURE__ */ new Date()).toISOString(), sessionId: w.id });
        const p = (0, (yield import("./getSessionData.js")).default)();
        window.birdeatsbug.options.ui.previewScreen && window.birdeatsbug.ui.showPreviewScreen(p), sessionStorage && (sessionStorage.birdeatsbugIsRecording = "false"), (a = (o = window.birdeatsbug.options.hooks) == null ? void 0 : o.afterScreenshot) == null || a.call(o, p);
      } catch (i) {
        console.error(i);
      }
    }
  });
}, startRecording: function() {
  return b(this, arguments, function* ({ isReplacingPreviousRecording: e = !1 } = {}) {
    var i, r, c, u, w, p, y, B, C, m, d, f, h;
    const t = window.birdeatsbug, n = t.options;
    (r = (i = n.hooks) == null ? void 0 : i.beforeRecording) == null || r.call(i);
    const s = n.instantReplay === !0 && !e, o = yield t.createSessionIfRequired({ isBackgroundRecording: s });
    if (yield t.loadRequiredRecorders(), s || !n.recordVideo || !t.isVideoRecordingSupported)
      (c = t.recordDom) == null || c.start();
    else
      try {
        yield (u = t.recordVideo) == null ? void 0 : u.start(), o.isNewSession !== !1 && (o.startedAt = (/* @__PURE__ */ new Date()).toISOString(), window.birdeatsbug.session = o, sessionStorage && (sessionStorage.birdeatsbugSession = JSON.stringify(o)));
      } catch (I) {
        if (I.message === "Permission denied" || (w = I.message) != null && w.startsWith("The request is not allowed"))
          throw window.birdeatsbug.deleteSession(), I;
        console.error(I), (p = t.recordDom) == null || p.start();
      }
    let a;
    (y = t.recordClicks) == null || y.start(), (B = t.recordKeystrokes) == null || B.start(), (C = t.recordConsole) == null || C.start(), (m = t.recordNetwork) == null || m.start(), (d = t.recordLocalStorage) == null || d.start(), (f = t.recordSessionStorage) == null || f.start(), (h = t.recordNavigation) == null || h.start(), sessionStorage && (sessionStorage.birdeatsbugIsRecording = "true"), o.isInstantReplay || (a = setInterval(Me, 1e3)), sessionStorage && !o.isInstantReplay && (sessionStorage.birdeatsbugSessionTimerIntervalId && parseInt(sessionStorage.birdeatsbugSessionTimerIntervalId) !== a && clearInterval(sessionStorage.birdeatsbugSessionTimerIntervalId), sessionStorage.birdeatsbugSessionTimerIntervalId = a), o.isInstantReplay || n.ui.recordingControls === !1 || t.ui.showRecordingControls();
  });
}, stopRecording: function() {
  return b(this, null, function* () {
    var e, t, n, s, o, a, i, r, c;
    (e = window.birdeatsbug.recordClicks) == null || e.stop(), (t = window.birdeatsbug.recordKeystrokes) == null || t.stop(), (n = window.birdeatsbug.recordConsole) == null || n.stop(), (s = window.birdeatsbug.recordDom) == null || s.stop(), (o = window.birdeatsbug.recordVideo) == null || o.stop(), (a = window.birdeatsbug.recordNetwork) == null || a.stop(), (i = window.birdeatsbug.recordLocalStorage) == null || i.stop(), (r = window.birdeatsbug.recordSessionStorage) == null || r.stop(), (c = window.birdeatsbug.recordNavigation) == null || c.stop(), sessionStorage && (clearInterval(sessionStorage.birdeatsbugSessionTimerIntervalId), delete sessionStorage.birdeatsbugSessionTimerIntervalId, sessionStorage.birdeatsbugIsRecording = "false", delete sessionStorage.birdeatsbugLastUrl);
  });
}, stopSession: function() {
  return b(this, null, function* () {
    var n, s;
    window.birdeatsbug.stopRecording();
    const e = window.birdeatsbug.session;
    e && (e.endedAt = (/* @__PURE__ */ new Date()).toISOString(), e.isInstantReplay && (e.endUrl = document.location.href), window.birdeatsbug.session = e, sessionStorage && (sessionStorage.birdeatsbugSession = JSON.stringify(e)));
    const t = (0, (yield import("./getSessionData.js")).default)();
    window.birdeatsbug.options.ui.previewScreen && window.birdeatsbug.ui.showPreviewScreen(t), window.birdeatsbug.session && ((s = (n = window.birdeatsbug.options.hooks) == null ? void 0 : n.afterRecording) == null || s.call(n, t));
  });
}, uploadSession: function(r) {
  return b(this, arguments, function* ({ session: e, events: t = [], domEvents: n = [], networkRequests: s = [], screenshot: o, video: a, dataRedactionPatterns: i = [] }) {
    var c, u, w, p, y, B, C;
    if (!window.birdeatsbug.isUploading) {
      window.birdeatsbug.isUploading = !0, t = t.map((m) => function(d, f = []) {
        var h;
        if (!f.length)
          return d;
        if (d.source === "console")
          d.args = E(d.args, f);
        else if (["error-uncaught", "error-promise"].includes(d.type))
          d.content = E(d.content, f);
        else if (d.type === "click")
          d.target = E(d.target, f);
        else if (["keydown", "input"].includes(d.type))
          (h = d.target) != null && h.serialized && (d.target.serialized = E(d.target.serialized, f));
        else if (d.source === "storage" && ["set", "setItem"].includes(d.action)) {
          const I = { [d.args[0]]: d.args[1] }, N = { [d.args[0]]: d.args[2] }, Z = E(I, f), L = E(N, f);
          d.args = [Object.keys(Z)[0], Object.values(Z)[0], Object.values(L)[0]];
        }
        return d;
      }(m, i)), s = s.map((m) => function(d, f = []) {
        if (!f.length)
          return d;
        if (d.url = T(d.url, f), d.initiator && (d.initiator = T(d.initiator, f)), d.requestHeaders && (d.requestHeaders = E(d.requestHeaders, f)), d.responseHeaders && (d.responseHeaders = E(d.responseHeaders, f)), d.requestBody && typeof d.requestBody == "string")
          try {
            d.requestBody = JSON.parse(d.requestBody);
          } catch (h) {
            d.requestBody = T(d.requestBody, f);
          }
        if (d.requestBody && typeof d.requestBody == "object" && (d.requestBody = E(d.requestBody, f)), d.responseBody && typeof d.responseBody == "string")
          try {
            d.responseBody = JSON.parse(d.responseBody);
          } catch (h) {
            d.responseBody = T(d.responseBody, f);
          }
        return d.responseBody && typeof d.responseBody == "object" && (d.responseBody = E(d.responseBody, f)), d;
      }(m, i)), typeof ((c = window.birdeatsbug.options.hooks) == null ? void 0 : c.beforeUpload) == "function" && ({ session: e, events: t, domEvents: n, networkRequests: s, screenshot: o } = yield window.birdeatsbug.options.hooks.beforeUpload({ session: e, events: t, domEvents: n, networkRequests: s, screenshot: o, video: a }));
      try {
        yield function(Z) {
          return b(this, arguments, function* ({ session: m, events: d, domEvents: f, networkRequests: h, screenshot: I, video: N }) {
            var Q;
            const L = window.birdeatsbug.options.publicAppId;
            S.fileSizeInBytes = 0, S.uploadedFileSizeInBytes = 0;
            const D = {}, Y = { "X-Bird-Client": "sdk v1.98.24", "X-Bird-Downlink": (Q = navigator.connection) == null ? void 0 : Q.downlink };
            if (d != null && d.length) {
              const v = new Blob([JSON.stringify(d)], { type: k });
              D.events = v, S.fileSizeInBytes += v.size;
            }
            if ((f == null ? void 0 : f.length) > 10) {
              const v = new Blob([JSON.stringify(f)], { type: k });
              D.domEvents = v, S.fileSizeInBytes += v.size;
            }
            if (h != null && h.length) {
              const v = JSON.stringify({ fromInstrumentation: h }), $ = new Blob([v], { type: k });
              D.networkRequests = $, S.fileSizeInBytes += $.size;
            }
            if (I) {
              const v = yield fetch(I).then(($) => $.blob());
              D.screenshot = v, S.fileSizeInBytes += v.size;
            }
            if (N) {
              const v = yield fetch(N).then(($) => $.blob());
              D.video = v, S.fileSizeInBytes += v.size;
            }
            if (Object.keys(D).length) {
              const v = new URLSearchParams([...Object.entries({ publicAppId: L })]).toString(), $ = yield fetch(`https://api.birdeatsbug.com/api/v1/sessions/${m.id}/files?${v}`, { method: "POST", headers: A(O({}, Y), { "Content-Type": k }), body: JSON.stringify({ files: Object.keys(D) }), referrerPolicy: "origin" }), { signedUploadUrls: ee } = yield $.json();
              m.files = Object.keys(ee);
              for (const [te, Ie] of Object.entries(ee))
                yield He(Ie, D[te], { "Content-Type": _e[te] });
            }
            const G = new FormData();
            G.append("session", new Blob([JSON.stringify(m)], { type: k }));
            const Ee = new URLSearchParams([...Object.entries({ publicAppId: L, collectionId: m.collectionId, labelIds: m.labelIds })]);
            yield fetch("https://api.birdeatsbug.com/api/v1/sdk/sessions/" + m.id + "?" + Ee.toString(), { method: "POST", body: G, referrerPolicy: "origin", headers: Y });
          });
        }({ session: e, events: t, domEvents: n, networkRequests: s, screenshot: o, video: a }), window.birdeatsbug.isUploading = !1, yield (w = (u = window.birdeatsbug.options.hooks) == null ? void 0 : u.afterUpload) == null ? void 0 : w.call(u, { session: e, events: t, domEvents: n, networkRequests: s, screenshot: o, video: a }), Object.values(window.birdeatsbug.options.integrations).some((m) => m === !0) ? (window.birdeatsbug.options.integrations.intercom && (0, (yield import("./openIntercom.js")).default)({ session: e }), window.birdeatsbug.options.integrations.zendesk && (0, (yield import("./openZendesk.js")).default)({ session: e }), (y = (p = window.birdeatsbug.ui) == null ? void 0 : p.close) == null || y.call(p)) : window.birdeatsbug.options.ui.submitConfirmationScreen ? window.birdeatsbug.ui.showSubmitConfirmationScreen({ session: e, events: t, domEvents: n, networkRequests: s, screenshot: o }) : (C = (B = window.birdeatsbug.ui) == null ? void 0 : B.close) == null || C.call(B), yield window.birdeatsbug.deleteSession();
      } catch (m) {
        throw console.error(m), window.birdeatsbug.isUploading = !1, m;
      }
    }
  });
}, deleteSession: function() {
  return b(this, null, function* () {
    var s;
    const e = (s = window.birdeatsbug.session) == null ? void 0 : s.id;
    if (delete window.birdeatsbug.session, sessionStorage && (delete sessionStorage.birdeatsbugSession, delete sessionStorage.birdeatsbugIsRecording), !e)
      return;
    const { default: t, indexedDBEventStores: n } = yield Promise.resolve().then(() => me);
    for (const o of n) {
      const a = yield t.transaction(o, "readwrite");
      let i = yield a.store.index("sessionId").openCursor();
      for (; i; )
        i.value.sessionId === e && i.delete(), i = yield i.continue();
      yield a.done;
    }
  });
}, ui: { showRecordingControls: function() {
  F(import("./RecordingControls.js"));
}, showPreviewScreen: function(e) {
  F(import("./PreviewScreen.js"), { sessionDataPromise: e });
}, showSubmitConfirmationScreen: function(e) {
  F(import("./SubmitConfirmationScreen.js"), e);
}, close: function() {
  return b(this, null, function* () {
    var e, t;
    Se(), document.querySelectorAll('[data-birdeatsbug="trigger"]').forEach(he), (t = (e = window.birdeatsbug.options.hooks) == null ? void 0 : e.afterClose) == null || t.call(e), yield window.birdeatsbug.deleteSession(), window.birdeatsbug.resumeSession();
  });
} } };
function ue(e) {
  return b(this, null, function* () {
    var s;
    const t = (s = window.birdeatsbug) != null && s[0] ? [...window.birdeatsbug] : [];
    let n = -1;
    for (const [o, ...a] of t)
      n++, P[o] && typeof P[o] == "function" && (e && !e.includes(o) || (yield P[o](...a), window.birdeatsbug.splice(n, 1), n--));
  });
}
function Be() {
  return b(this, null, function* () {
    var o, a, i;
    if (window.birdeatsbug.initialized)
      return;
    const e = typeof MutationObserver == "function", t = typeof ((o = navigator.mediaDevices) == null ? void 0 : o.getDisplayMedia) == "function", n = t;
    if (window.birdeatsbug.isBrowserSupported = e, window.birdeatsbug.isScreenshotSupported = t, window.birdeatsbug.isVideoRecordingSupported = n, e) {
      yield ue(["setOptions"]), Object.entries(P).forEach(([c, u]) => window.birdeatsbug[c] = u), window.birdeatsbug.version = "1.98.24";
      const r = window.birdeatsbug.options;
      if (!(r != null && r.publicAppId))
        return console.warn('aborting Bird Eats Bug SDK initialization: `window.birdeatsbug.setOptions({publicAppId: "myAppId"})` must be called before the snippet is executed.');
      Se();
    }
    const s = document.querySelectorAll('[data-birdeatsbug="trigger"]');
    s.forEach((r) => {
      e ? he(r) : r.style.visibility = "hidden";
    }), window.birdeatsbug.initialized = !0, (i = (a = window.birdeatsbug.options.hooks) == null ? void 0 : a.afterInit) == null || i.call(a, { isBrowserSupported: e, isScreenshotSupported: t, isVideoRecordingSupported: n, triggerButtons: s }), yield ue(), window.birdeatsbug.resumeSession(), document.addEventListener(le, (r) => {
      var u;
      const c = (u = r.detail.changedOptions) == null ? void 0 : u.instantReplay;
      if (c !== void 0) {
        if (c)
          return window.birdeatsbug.resumeSession();
        window.birdeatsbug.stopRecording(), window.birdeatsbug.deleteSession();
      }
    });
  });
}
Be();
export {
  We as A,
  Ye as B,
  le as C,
  Oe as D,
  X as E,
  lt as F,
  et as a,
  ot as b,
  gt as c,
  ft as d,
  pt as e,
  Ze as f,
  wt as g,
  bt as h,
  pe as i,
  St as j,
  vt as k,
  yt as l,
  mt as m,
  Ce as n,
  rt as o,
  tt as p,
  ut as q,
  ct as r,
  it as s,
  nt as t,
  dt as u,
  at as v,
  Ge as w,
  st as x,
  Qe as y,
  Xe as z
};
