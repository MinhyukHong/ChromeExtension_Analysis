chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "downloadResumes") {
        downloadResumes(message.tabId);
    }
});

function downloadResumes(tabId) {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: () => {
            function downloadCandidateResumes() {
                console.log("downloadCandidateResumes initiated (means the extension is running for first time.");
                // Function to get current, next, next-next, and previous items
                let candidateResumeRecord = [];

                function generateUniqueIds(n, length) {
                    const uniqueIds = new Set();
                    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                
                    while (uniqueIds.size < n) {
                        let id = '';
                        for (let i = 0; i < length; i++) {
                            id += characters.charAt(Math.floor(Math.random() * characters.length));
                        }
                        uniqueIds.add(id); // Set automatically handles duplicates
                    }
                
                    return Array.from(uniqueIds);
                }

                const project_id = generateUniqueIds(1, 20)[0];

                chrome.storage.local.get('userId', (result) => {
                    const userId = result.userId;
                    console.log('Retrieved user_id:', userId);
                    // Use the user_id as needed
                    if (userId) {

                        // function updateCreditText(credits) {
                        //     const creditTextSpan = document.getElementById('credits-remaining-text')
                        //     // console.log('updateing credits', creditTextSpan)
                        //     if (creditTextSpan) {
                        //         creditTextSpan.innerText = `Credits: ${credits}`;
                        //     }
                        // }
                    
                    
                    // charge the credits
                    fetch('https://www.valyee.com/extension/charge-resume-download', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ user_id: userId ,
                                               project_id: project_id
                        })
                    })
                    .then(response => {
                        if (!response.ok) {
                            return response.json().then(data => {
                                // Handle the error from the server
                                showMessage("Insufficient credits! Please top up your credits.");
                                throw new Error("Insufficient credits! Please top up your credits.");
                            });
                        }
                        return response.json();
                    })
                    .then(data => {
                        const credits = data.credits;
                        // updateCreditText(credits);
                        
                        
                        function showMessage(message) {
                        const popupContainer = document.querySelector('.popup-container');
                        const messageElement = document.createElement('p');
                        messageElement.textContent = message;
                        popupContainer.appendChild(messageElement);
                    }
                
                    async function processOnePage() {
                        const pendingSet = new Set();
                        let exitAttemptLoop = false; // Flag to indicate whether to exit the loops
                        // let completedSet = new Set();
                        
                        let listContainer = document.querySelector('.hiring-applicants__list-container .artdeco-list');
                        
                        if (!listContainer) {
                            console.log('Candidate list not found');
                            return;
                        }
                        
                        
                        const mainCandidateList = listContainer.querySelectorAll('li');
                        console.log("Main Candidate list found", mainCandidateList);
                        
                        
                        const subCandidatesList = listContainer.querySelectorAll('li.hiring-applicants__list-item');
                        
                        const candidatesDict = new Map();
                        
                        for (let ii = 0; ii < subCandidatesList.length; ii++) {
                            const subItem = subCandidatesList[ii];
                            for (let i = 0; i < mainCandidateList.length; i++) {
                                const mainItem = mainCandidateList[i];
                                if (mainItem === subItem) {
                                    const nextMainItem = mainCandidateList[i+1];
                                    candidatesDict.set(ii, [nextMainItem, subItem]); 
                                }
                                
                            }
                        }
                
                        console.log("Candidates list found", candidatesDict);
                        
                        // Create an iterator for the candidate entries
                        const candidateArray = Array.from(candidatesDict.entries());
                        
                        // 3 tries to download
                        const totalDownloadedAttempts = 3;
                        for (let attempt = 0; attempt < totalDownloadedAttempts; attempt++) {
                
                            console.log("attempt no. ", attempt);
                            console.log("exitAttemptLoop : ", exitAttemptLoop)
                            if (pendingSet.size === 0 && attempt > 0) break;
                            
                            for (let i = 0; i < candidatesDict.size; i++) {
                                // const [key, value] = entriesIterator.next().value;
                                // const candidateClick = value[0];
                                // const candidateItem = value[1];
                                
                                if (i !==0) {
                                    const previousCandidate = candidateArray[i-1][1] || null;
                                    const previousCandidateClick = previousCandidate[0];
                                    console.log("previousCandidateClick", previousCandidateClick)
                                    // previousCandidateClick.click();
                                }
                                
                                const currentCandidate = candidateArray[i][1] || null;
                                const candidateClick = currentCandidate[0];
                                const candidateItem = currentCandidate[1];
                                
                                console.log("candidateClick", candidateClick)
                                console.log("candidateItem", candidateItem)
                                
                                
                                console.log("#### pendingSet :", pendingSet);
                                // console.log("#### completedSet :", completedSet);
                                
                                // if the pending set is not empty
                                if (pendingSet.size !== 0) {
                                    if (attempt>0) {
                                        // not the first attempt eg. 2,3,4
                                        // handling situaltion where only one candidate left
                                        if (!pendingSet.has(i) && pendingSet.size > 0) {
                                            // if the item is not in the pending set it will be skipped
                                            continue;} else {
                                                // if the pending set is not empty and the item is in the pending set
                                                if (pendingSet.size ==1) {
                                                    // if pendingset size is 1
                                                    if (candidatesDict.size == 1) {
                                                        // if there is only 1 candidate
                                                        // location.reload();
                                                    } else {
                                                        // if there are more than one candidate
                                                        if (i!==0) {
                                                            // if the current candidate is not the first
                                                            // click the previous candidate
                                                            const previousCandidate = candidateArray[i-1][1] || null;
                                                            const previousCandidateClick = previousCandidate[0];
                                                            previousCandidateClick.click();
                                                            // candidatesList[i-1].click();
                                                        } else {
                                                                // if the current candidate is the first
                                                                // click the next candidate
                                                                const nextCandidate = candidateArray[i+1][1] || null;
                                                                const nextCandidateClick = nextCandidate[0];
                                                                nextCandidateClick.click();
                                                                // candidatesList[i+1].click();
                                                                
                                                            }
                                                    }
                                                    
                                                }
                                        }
                                    }
                                } else {
                                    // if the pending set is empty
                                    if (attempt>0) {
                                        // if the it is not the first attempt
                                        exitAttemptLoop = true; // Set the flag to exit loops
                                        break; // Break the inner loop
                                    }
                                }
                                
                                if (!exitAttemptLoop) {
                                    try {
                                        
                                        const candidate = candidateItem;
                                        candidateClick.click();
                                        
                                        await new Promise(resolve => setTimeout(resolve, 3000));
                                        
                                        const candidateResult = processCandidate(candidate);
                                        if (!candidateResult) {
                                            pendingSet.add(i);
                                        } else {
                                            pendingSet.delete(i);
                                        }
                                    } catch (error) {
                                        console.error('Error processing candidate:', error);
                                        pendingSet.delete(i);
                                    }
                                }
                                
                                // // stopping at first resume for testing
                                // break;
                            }
                            // console.log("#### pendingSet :", pendingSet);
                            if (exitAttemptLoop) break;
                            
                        }
                    }
                    
                    
                    function processCandidate(candidate) {
                        const resumeCards = document.querySelectorAll('.p0.mt4.artdeco-card');
                        const resumeCard = resumeCards[1]; // Select the second occurrence (index 1)
                        
                        if (resumeCard) {
                            const downloadLink = resumeCard.querySelector('a[href*="ambry"]');
                            
                            const scanningMessage = resumeCard.querySelector('.hiring-resume-viewer__virus-scan-icon');
                            if (scanningMessage) {
                                console.log('Resume virus scanning in progress from LinkedIn. Adding to pending list');
                                return false;
                            } else {
                                if (downloadLink) {
                                    if (!candidateResumeRecord.includes(downloadLink.href)) {
                                        
                                        console.log('Downloading resume for candidate:', downloadLink.href);
                                        const link = document.createElement('a');
                                        link.href = downloadLink.href;
                                        link.download = true;
                                        candidate.appendChild(link);
                                        link.click();
                                        candidateResumeRecord.push(downloadLink.href);
                                        candidate.removeChild(link);
                                        return true;
                                    } else {
                                        console.log('Resume already downloaded for candidate:', candidate);
                                        return true;
                                    }
                                    
                                } else {
                                    console.log('Download button not found for candidate');
                                    return true;
                                }
                            }
                        } else {
                            console.log('Resume card not found for candidate');
                            return true;
                        }
                    }
                    
                    const pageNumContainer = document.querySelector('.hiring-applicants__list-container .artdeco-pagination__pages--number');
                    
                    
                    if (pageNumContainer) {
                        
                        const numberList = pageNumContainer.querySelectorAll('li');
                        
                        let startIndex = 0;
                        
                        for (let i = 0; i < numberList.length; i++) {
                            if (numberList[i].classList.contains('active')) {
                                startIndex = i;
                                break;
                            }
                        }
                        
                        console.log('startIndex : ', startIndex);
                        
                        (async function processPages() {
                            for (let i = startIndex; i < numberList.length; i++) {
                                if (i > startIndex) {
                                    const newNumberList = pageNumContainer.querySelectorAll('li');
                                    console.log("numberlist : ",newNumberList)
                                    const button = newNumberList[i].querySelector('button'); // Find the button inside the second <li>
                                    console.log(button)
                                    button.click();
                                    await new Promise(resolve => setTimeout(resolve, 5000));
                                }
                                await processOnePage();
                            }
                            
                            console.log('All Resumes downloaded!!!')
                            showMessage('Completed: All Resumes downloaded!!!');
                            showResumeDownloadNotification();
                        })();
                        
                    } else {
                        (async function processPagesWithNoNumbers() {
                            await processOnePage();
                            
                            console.log('All Resumes downloaded!!!');
                            showMessage('Completed: All Resumes downloaded!!!');
                            showResumeDownloadNotification();
                        })();          
                    }
                })
                .catch(error => {
                    console.error('Error:', error)
                    alert('Insufficient credits! Please top up your credits.');
                });
                }
            });


            // resume downloaded notification

            function showResumeDownloadNotification() {
                var notification = document.getElementById('resume-download-notification');
                notification.style.display = 'flex';
            }
        
        
            function closeResumeDownloadNotification() {
                var notification = document.getElementById('resume-download-notification');
                notification.style.display = 'none';
            }
            
            
            document.getElementById('close-resume-download-notification').addEventListener('click', closeResumeDownloadNotification);


            }
            setTimeout(downloadCandidateResumes, 3000); // Add a 5-second delay before executing downloadCandidateResumes
        }
    });
}

// function initiateDownload() {
//     setTimeout(() => {
//         console.log("downloadCandidateResumes initiated (means the extension is running for first time.");
//         downloadCandidateResumes(); // Call the main function after a delay
//     }, 5000);
// }

