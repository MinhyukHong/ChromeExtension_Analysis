document.addEventListener('DOMContentLoaded', function() {

    const closePopupButton = document.getElementById('closePopup');
    
    // define project_id
    let project_id = null;

    let userId = null;

    // define csv file name
    let xlsxFileName = null;


    // hide the upload-resumes div by default
    document.getElementById('resume-upload-container').style.display = 'none';
    

    // logggin user
    let userLoggedIn = false;

    // Check if the user has previously logged in
    // chrome.storage.local.get(['loggedIn'], function(result) {
    //     if (result.loggedIn === undefined || result.loggedIn === false) {
    //         console.log("No login information found. User needs to log in.");
    //         showLoginButton();
    //     } else {
    //         chrome.identity.getAuthToken({ interactive: false }, function(token) {
    //             if (chrome.runtime.lastError || !token) {
    //                 console.log("Token is not valid, user needs to log in.");
    //                 showLoginButton();
    //                 togglePopupContainer(false);
    //             } else {
    //                 console.log("User is already logged in.");
    //                 getUserInfo(token);
    //                 showLogoutButton();
    //                 togglePopupContainer(true);
    //                 userLoggedIn = true;

    //             }
    //         });
    //     }
    // });

    chrome.storage.local.get(['loggedIn'], function(result) {
        if (result.loggedIn === undefined || result.loggedIn === false) {
            console.log("No login information found. User needs to log in.");
            showLoginButton();
        } else {
            chrome.identity.getAuthToken({ interactive: false }, function(token) {
                if (chrome.runtime.lastError || !token) {
                    console.log("Token is not valid, user needs to log in.");
                    showLoginButton();
                    togglePopupContainer(false);
                } else {
                    console.log("User is already logged in.");
                    getUserInfo(token)
                        .then((userId) => {
                            // All subsequent operations that require userId go here
                            showLogoutButton();
                            togglePopupContainer(true);
                            userLoggedIn = true;
    
                            // unhide the upload-resumes div
                            document.getElementById('upload-resumes').style.display = 'block';
                        })
                        .catch((error) => {
                            console.error("Error occurred during user information retrieval:", error);
                        });
                }
            });
        }
    });

    if (userLoggedIn) {
        // unhide the upload-resumes div
        document.getElementById('upload-resumes').style.display = 'block';
    }


    // get extraction fields
    let selectedUserFields = [];

    fetch('https://www.valyee.com/extension/get-extract-fields', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ user_id: userId }) // Send user_id in the request body

    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const dropdown = document.getElementById('extractFieldsDropdown');
            data.fields.forEach(field => {
                const option = document.createElement('option');
                option.value = field;
                option.text = field.charAt(0).toUpperCase() + field.slice(1);
                dropdown.appendChild(option);
            });
        }
    })
    .catch(error => console.error('Error fetching fields:', error));

    const dropdown = document.getElementById('extractFieldsDropdown');
    dropdown.addEventListener('change', function() {
        const selectedField = dropdown.value;
        if (selectedField && !selectedUserFields.includes(selectedField)) {
            selectedUserFields.push(selectedField);
            updateSelectedFields();
            hideOption(selectedField);
        }
        dropdown.selectedIndex = 0; // Reset dropdown
    });

    function updateSelectedFields() {
        const selectedFieldsContainer = document.getElementById('selectedFields');
        selectedFieldsContainer.innerHTML = ''; // Clear previous tags

        selectedUserFields.forEach(field => {
            const fieldTag = document.createElement('div');
            fieldTag.className = 'field-tag';
            fieldTag.innerText = field.charAt(0).toUpperCase() + field.slice(1);

            const removeButton = document.createElement('span');
            removeButton.className = 'remove-tag';
            removeButton.innerText = '×';
            removeButton.onclick = function() {
                selectedUserFields = selectedUserFields.filter(f => f !== field);
                updateSelectedFields();
                showOption(field);
            };

            fieldTag.appendChild(removeButton);
            selectedFieldsContainer.appendChild(fieldTag);
        });

        // console.log(selectedUserFields);
    }

    function hideOption(field) {
        const optionToHide = Array.from(dropdown.options).find(option => option.value === field);
        if (optionToHide) {
            optionToHide.style.display = 'none';
        }
    }

    function showOption(field) {
        const optionToShow = Array.from(dropdown.options).find(option => option.value === field);
        if (optionToShow) {
            optionToShow.style.display = '';
        }
    }

    function getUserId(){
        return userId
    }

    function fetchAndApplyUserFields(userId) {
        fetch('https://www.valyee.com/extension/get-user-fields', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ user_id: userId }) // Send userId in the request body
        })
        .then(response => response.json())
        .then(data => {
            // Apply user fields as already selected
            if (data.user_fields && Array.isArray(data.user_fields)) {
                data.user_fields.forEach(field => {
                    if (!selectedUserFields.includes(field)) {
                        selectedUserFields.push(field);
                        updateSelectedFields(); // Update UI with selected fields
                        hideOption(field); // Hide the option in the dropdown
                    }
                });
            }
            
        })
        .catch(error => console.error('Error fetching user fields:', error));
    }
    
    

    function togglePopupContainer(visibility) {
        const popupContainer = document.querySelector('.popup-container');
    
        if (visibility) {
            if (!popupContainer) {
                // If the popup container doesn't exist, create it and append it to the main container
                const mainContainer = document.getElementById('main-container');
                const authContainer = document.getElementById('after-header-content-container');
    
                const newPopupContainer = document.createElement('div');
                newPopupContainer.classList.add('popup-container');
    
                   
                // newPopupContainer.innerHTML = `
                    

                //     <h1>LinkedIn Resume Downloader</h1>
                //     <p>Click the button below to start downloading resumes.</p>
                //     <button id="startDownload">Start Download</button>
                // `;

                newPopupContainer.innerHTML = `
                    <div id="download-subcontainer">
                        <p class="transparent-black">Click the 'Download' button to start downloading resumes, or Upload resumes to extract information as a Excel (xlsx) file.</p>
                        <div class="download-checkbox-group">
                            <label>
                            <input type="checkbox" disabled>
                            <span class="transparent-black">Fetch Job Description (Coming Soon)</span>
                            </label>
                            <!-- <label>
                                <input type="checkbox">
                                <span class="transparent-black">Download all Resumes</span>
                            </label> -->
                            <label>
                                <input type="checkbox" disabled>
                                <span class="transparent-black">Include responses to screening questions (Coming Soon)</span>
                            </label>
                            <label>
                                <input type="checkbox" disabled>
                                <span class="transparent-black">Filter Candidates by Relevance (+1 Credits) (Coming Soon)</span>
                            </label>
                        </div>
                    </div>
                   <div id="download-upload-div">
                        <button id="downloadSettingBtn" class="popup-btn">Download</button>
                        <button id="openUploadWindowBtn" class="popup-btn">Upload <img src="icons/upload-i-logo.svg" alt="(i)"> </button>
                    </div>

                    <!-- resume download settings -->
                    <div id="resume-download-settings-window-container">
                        <hr style="width: 100%; width: 175%; margin-left: -4rem; border-color: #3369ff; margin-bottom: 2rem;">
                        <h1 id="download-settings-header-text">Select Download Settings</h1>

                        <div class="download-settings-section">
                            <h2 class="download-settings-section-title">Local Download:</h2>
                            <p class="download-settings-section-description">
                                We will download resumes directly to your PC, in the default download folder. You can change the folder to which resumes are downloaded from your settings.
                            </p>
                            <p class="download-settings-section-description">
                                You can also use our ‘Upload’ feature to upload downloaded resumes and view extracted candidate data in
                                excel (xlsx) format.
                            </p>
                            <button id="download-settings-download-btn-id" class="download-settings-download-btn popup-btn">Download</button>
                        </div>

                        <div class="download-settings-section">
                            <h2 class="download-settings-section-title">Cloud Download:</h2>
                            <p class="download-settings-section-description">
                                We will download resumes and store them on our server instead of your PC. We will automatically extract
                                relevant data from the resumes, and generate a Google Sheet with all information and links to the resumes
                                for your review.
                            </p>
                            <button class="download-settings-coming-soon-btn" disabled>Coming Soon</button>
                        </div>
                    </div>


                    <div id="final-download-container">
                        <h1 id="final-download-header-text">Download Resumes</h1>
                        <p>We use RPA to automate the download process, so you may notice your screen refreshing / tabs opening and closing as downloads progress. This is normal, expected behaviour.</p>

                        <div id="final-download-window-text-content-div">
                            <p>By default we will download the resumes in the default download folder. You can <a href="#"  id="changeDownloadFolder" style="font-size=14px; font-weight: 600;">change the folder</a> to which resumes are downloaded from your settings.</p>
                        </div>

                        <p>By Clicking on the "Download" button below, you agree to our <a href="https://www.valyee.com/extension/terms-and-conditions" target="_blank">Terms & Conditions</a></p>
                        <div id="final-download-btn-container">
                            <button id="final-download-back-btn" class="popup-btn">Back</button>
                            <button id="startDownload" class="popup-btn">Download</button>

                        </div>

                    </div>
                `;
    

                // Insert the newPopupContainer after the authentication-container
                mainContainer.insertBefore(newPopupContainer, authContainer.nextSibling);

                const startDownloadButton = document.getElementById('startDownload');
                const openUploadWindowBtn = document.getElementById('openUploadWindowBtn');
                const downloadSettingBtn = document.getElementById('downloadSettingBtn');
                const downloadSettingsDownloadBtn = document.querySelector('.download-settings-download-btn');
                const finalDownloadBackBtn = document.getElementById('final-download-back-btn');
                
                // hide the resume download settings window and final donwload container
                const resumeDownloadSettingsWindowContainer = document.getElementById('resume-download-settings-window-container');
                const finalDownloadContainer = document.getElementById('final-download-container');
                
                resumeDownloadSettingsWindowContainer.style.display = 'none';
                finalDownloadContainer.style.display = 'none';


                downloadSettingBtn.addEventListener('click', function() {
                    const downloadSettingsWindowContainer = document.getElementById('resume-download-settings-window-container');
                    const resumeUploadContainer = document.getElementById('resume-upload-container');
                    const downloadSubcontainer = document.getElementById('download-subcontainer');
                    const feedbackContainer = document.getElementById('feedback-container');
                    const feedbackText = document.getElementById('feedback-text');
                    
                    downloadSubcontainer.style.display = 'block';
                    
                    if (downloadSettingsWindowContainer.style.display === 'block') {
                        downloadSettingsWindowContainer.style.display = 'none';
                        feedbackContainer.style.display = 'block';
                        feedbackText.style.display = 'block';
                    } else {    
                        downloadSettingsWindowContainer.style.display = 'block';
                        resumeUploadContainer.style.display = 'none';
                        feedbackContainer.style.display = 'none';
                    }
                });
                
                downloadSettingsDownloadBtn.addEventListener('click', function() {
                    const downloadSubcontainer = document.getElementById('download-subcontainer');
                    const downloadUploadDiv = document.getElementById('download-upload-div');
                    const downloadSettingsWindowContainer = document.getElementById('resume-download-settings-window-container');
                    const finalDownloadContainer = document.getElementById('final-download-container');
                    const resumeUploadContainer = document.getElementById('resume-upload-container');


                    downloadSettingsWindowContainer.style.display = 'none';
                    finalDownloadContainer.style.display = 'block';
                    downloadSubcontainer.style.display = 'none';
                    downloadUploadDiv.style.display = 'none';
                    resumeUploadContainer.style.display = 'none';
                });

                startDownloadButton.addEventListener('click', function() {
                    const finalDownloadHeaderText = document.getElementById('final-download-header-text');
                    const finalDownloadWindowTextContentDiv = document.getElementById('final-download-window-text-content-div');

                    finalDownloadHeaderText.textContent = "Resume Download in Process"
                    finalDownloadWindowTextContentDiv.style.display = 'none';

                    checkUrl(function(tabId) {
                        chrome.runtime.sendMessage({ action: "downloadResumes", tabId: tabId });
                    });
                });

                finalDownloadBackBtn.addEventListener('click', function() {
                    const finalDownloadContainer = document.getElementById('final-download-container');
                    const downloadUploadDiv = document.getElementById('download-upload-div');
                    const downloadSubcontainer = document.getElementById('download-subcontainer');
                    const resumeUploadContainer = document.getElementById('resume-upload-container');
                    const feedbackContainer = document.getElementById('feedback-container');


                    finalDownloadContainer.style.display = 'none';
                    downloadSubcontainer.style.display = 'block';
                    downloadUploadDiv.style.display = 'grid';
                    resumeUploadContainer.style.display = 'none';
                    feedbackContainer.style.display = 'block';

                })

                openUploadWindowBtn.addEventListener('click', function() {
                    const uploadDiv = document.getElementById('resume-upload-container');
                    const downloadSubcontainer = document.getElementById('download-subcontainer');
                    const feedbackText = document.getElementById('feedback-text');
                    const feedbackContainer = document.getElementById('feedback-container');


                    // hide download subcontainer
                    const downloadSettingsWindowContainer = document.getElementById('resume-download-settings-window-container');
                    downloadSettingsWindowContainer.style.display = 'none';

                    if (uploadDiv) {
                        if (uploadDiv.style.display === 'block') {
                            uploadDiv.style.display = 'none';
                            downloadSubcontainer.style.display = 'block';
                            feedbackText.style.display = 'block';
                            feedbackContainer.style.display = 'block';
                        } else {
                            feedbackContainer.style.display = 'none';
                            const user_id = getUserId();

                            fetchAndApplyUserFields(user_id);

                            // fetch('https://www.valyee.com/extension/get-user-fields', {
                            //     method: 'POST',
                            //     headers: {
                            //         'Content-Type': 'application/json'
                            //     },
                            //     body: JSON.stringify({ user_id: user_id }) // Send user_id in the request body
                            // })
                            // .then(response => response.json())
                            // .then(data => {
                            //     // Apply user fields as already selected
                            //     if (data.user_fields && Array.isArray(data.user_fields)) {
                            //         data.user_fields.forEach(field => {
                            //             if (!selectedUserFields.includes(field)) {
                            //                 selectedUserFields.push(field);
                            //                 updateSelectedFields(); // Update UI with selected fields
                            //                 hideOption(field); // Hide the option in the dropdown
                            //             }
                            //         });
                            //     }
                            //     console.log("user fields: ", data.user_fields);
                            //     console.log("user id: ", user_id);
                            //     console.log("selected user fields: ", selectedUserFields);
                            // })
                            // .catch(error => console.error('Error fetching user fields:', error));

                            

                            uploadDiv.style.display = 'block';
                            downloadSubcontainer.style.display = 'none';
                            feedbackText.style.display = 'none';
                            showFirstUploadWindow();
                        }
                    }
                });

                // change download folder
                document.getElementById('changeDownloadFolder').addEventListener('click', function(event) {
                    event.preventDefault(); // Prevent the default anchor action
                    chrome.tabs.create({ url: 'chrome://settings/downloads' }); // Open the Chrome downloads settings page
                });
                

                // show the upload-resumes div
                document.getElementById('upload-resumes').style.display = 'block';

                 // get the number of credits remaining
                 fetch('https://www.valyee.com/extension/get-credits', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ user_id: userId }) // Send user_id in the request body
                })
                .then(response => response.json())
                .then(data => {
                    updateCreditText(data.credits)
                    // const creditText = document.getElementById('credits-remaining-text');
                    // creditText.textContent = `Credits Remaining: ${data.credits}`;
                })
                .catch(error => {
                    console.error('Error fetching credits:', error);
                });
            }
        } else {
            // If visibility is false and popup container exists, remove it from the DOM
            if (popupContainer) {
                popupContainer.remove();
            }
        }
    }

    // set up the next button

    const nextUploadBtn = document.getElementById('next-upload-btn');
    nextUploadBtn.addEventListener('click', function() {
        showSecondUploadWindow();
    });

    // set up back button

    const backUploadBtn = document.getElementById('back-btn');
    backUploadBtn.addEventListener('click', function() {
        showFirstUploadWindow();
    });



    // show the first window of the upload

    function showFirstUploadWindow() {
        const firstUploadWindow = document.getElementById('first-upload-window-container');
        const secondUploadWindow = document.getElementById('second-upload-window-container');

        firstUploadWindow.style.display = 'block';
        secondUploadWindow.style.display = 'none';
    }

    // show the second window of the upload

    function showSecondUploadWindow() {
        const firstUploadWindow = document.getElementById('first-upload-window-container');
        const secondUploadWindow = document.getElementById('second-upload-window-container');

        firstUploadWindow.style.display = 'none';
        secondUploadWindow.style.display = 'block';
    }

    // change job description file name
    document.getElementById('jobDescriptionFile').addEventListener('change', function(event) {
        const fileInput = event.target;
        const fileName = fileInput.files[0]?.name || ''; // Get the selected file name
        const supportedFilesText = document.getElementById('supported-files-text');
        
        // Check if a file was selected and if its extension is valid
        if (fileName) {
            const validExtensions = ['pdf', 'doc', 'docx', 'txt'];
            const fileExtension = fileName.split('.').pop().toLowerCase();
            
            if (validExtensions.includes(fileExtension)) {
                supportedFilesText.textContent = fileName; // Replace text with file name
            } else {
                // If an invalid file type is selected, show an error message or reset the input
                alert('Invalid file type. Please select a PDF, Word Doc, or text file.');
                fileInput.value = ''; // Clear the file input
            }
        }
    });

    // Get the image element and the file input element
    const uploadIcon = document.querySelector('.upload-icon');
    const jobDescriptionFileInput = document.getElementById('jobDescriptionFile');
    const jobDescriptionDropArea = document.getElementById('job-description-drop-area');


    // Add a click event listener to the image
    uploadIcon.addEventListener('click', function() {
        jobDescriptionFileInput.click(); // Trigger the click event on the hidden file input
    });




    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        jobDescriptionDropArea.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    // Highlight drop area when item is dragged over
    jobDescriptionDropArea.addEventListener('dragenter', () => jobDescriptionDropArea.classList.add('highlight'), false);
    jobDescriptionDropArea.addEventListener('dragover', () => jobDescriptionDropArea.classList.add('highlight'), false);

    // Remove highlight when item is dragged out or dropped
    jobDescriptionDropArea.addEventListener('dragleave', () => jobDescriptionDropArea.classList.remove('highlight'), false);
    jobDescriptionDropArea.addEventListener('drop', () => jobDescriptionDropArea.classList.remove('highlight'), false);

    // Handle dropped files
    jobDescriptionDropArea.addEventListener('drop', handleJobDescriptionDrop, false);

    function handleJobDescriptionDrop(e) {
        let dt = e.dataTransfer;
        let files = dt.files;
    
        if (files.length > 0) {
            jobDescriptionFileInput.files = files; // Assign the dropped file to the input
    
            // Optionally, update the UI with the file name
            const fileName = files[0].name;
            const supportedFilesText = document.getElementById('supported-files-text');
            supportedFilesText.textContent = fileName; // Display the file name
        }
    }
    

    


    // updates remaining credits
    // function updateCreditText(credits) {
    //     document.getElementById('credits-remaining-text').innerText = `Credits: ${credits}`;
    // }
    

    function updateCreditText(credits) {
        const creditsContainer = document.getElementById('credits-remaining-text');
    
        // Create a div to hold the text and image
        const creditsContainerDiv = document.createElement('div');
        creditsContainerDiv.id = 'credits-remaining-text-subcontainer';
    
        // Create the text node showing the remaining credits
        const creditsText = document.createTextNode(`Credits: ${credits}`);
    
        // Create the image that will act as a clickable element
        const redirectImage = document.createElement('img');
        redirectImage.src = chrome.runtime.getURL('icons/buy-credits.svg');  // Get the correct path for the image
        redirectImage.alt = 'Buy Credits'; // Add an alt text for accessibility
    
        // Add click event to redirect to the pricing page
        redirectImage.addEventListener('click', function() {
            chrome.tabs.create({ url: 'https://www.valyee.com/extension/pricing' });
        });
    
        // Append the text and the image to the container div
        creditsContainerDiv.appendChild(creditsText);
        creditsContainerDiv.appendChild(redirectImage);
    
        // Clear any existing children (in case this function is called multiple times)
        while (creditsContainer.firstChild) {
            creditsContainer.removeChild(creditsContainer.firstChild);
        }
    
        // Append the container div to the main container
        creditsContainer.appendChild(creditsContainerDiv);
    }
    
    
    



    // Function to check if the current URL matches the required pattern
    function checkUrl(callback) {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            const currentUrl = tabs[0].url;

            if (currentUrl.includes('www.linkedin.com/hiring/jobs') && currentUrl.includes('/applicants')) {
                // console.log('Success: The right URL is selected');
                showMessage('Success: The right URL is selected');
                callback(tabs[0].id);
            } else {
                // console.log('Error: The URL is not correct');
                showMessage('Error: The URL is not correct');
            }
        });
    }

    // Function to show message in the popup
    function showMessage(message) {
        const popupContainer = document.querySelector('.popup-container');
        // Check if the message container already exists
        const existingMessageElement = document.getElementById('showMessageContainer');

        if (existingMessageElement) {
            // If the element exists, just update its text content
            existingMessageElement.textContent = message;
        } else {
            const messageElement = document.createElement('p');
            messageElement.id = "showMessageContainer";
            messageElement.textContent = message;


            if (!popupContainer) {
                // const mainContainer = document.getElementById('main-container');
                // const loginMainContainer = document.getElementById('login-main-container');
                // const newPopupContainer = document.createElement('div');
                // newPopupContainer.classList.add('popup-container');
                // newPopupContainer.innerHTML = ``;
                
                // newPopupContainer.appendChild(messageElement);
                // mainContainer.insertBefore(newPopupContainer, loginMainContainer);
    
    
            } else {
    
                popupContainer.appendChild(messageElement);
            }
        }

    }

    

    // startDownloadButton.addEventListener('click', function() {
    //     checkUrl(function(tabId) {
    //         chrome.runtime.sendMessage({ action: "downloadResumes", tabId: tabId });
    //     });
    // });
    
    checkUrl(() => {});


    // upload resumes

    document.getElementById('login-button').addEventListener('click', function() {
        chrome.identity.getAuthToken({ interactive: true }, function(token) {
            if (chrome.runtime.lastError) {
                console.error('Error during authentication:', chrome.runtime.lastError);
                togglePopupContainer(false);
            } else {
                getUserInfo(token);
                chrome.storage.local.set({ loggedIn: true });
                showLogoutButton();
                togglePopupContainer(true);

                
            }
        });
    });
    
    document.getElementById('logout-button').addEventListener('click', function() {
        chrome.identity.getAuthToken({ interactive: false }, function(currentToken) {
            if (currentToken) {
                chrome.identity.removeCachedAuthToken({ token: currentToken }, function() {
                    console.log("User has been logged out.");
                    chrome.storage.local.set({ loggedIn: false });
                    showLoginButton();
                    togglePopupContainer(false);
    
                    // Hide the upload-resumes div
                    document.getElementById('upload-resumes').style.display = 'none';
                });
            }
        });
    });
    
    // function getUserInfo(token) {
    //     fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
    //         headers: {
    //             'Authorization': 'Bearer ' + token
    //         },
    
    //     })
    //     .then(response => response.json())
    //     .then(data => {
    //         userId = data.sub; // Google User ID
    //         console.log("Google User ID: " + userId);
    //         chrome.storage.local.set({ userId: userId }); // Store userId for later use
    //         document.getElementById('upload-resumes').style.display = 'block'; // Show upload area
    //         document.getElementById('upload-btn').style.display = 'block'; // Show upload button
    //     })
    //     .catch(error => console.error('Error fetching user info:', error));
    // }

    function getUserInfo(token) {
        return new Promise((resolve, reject) => {
            fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                headers: {
                    'Authorization': 'Bearer ' + token
                },
            })
            .then(response => response.json())
            .then(data => {
                userId = data.sub; // Google User ID
                chrome.storage.local.set({ userId: userId }); // Store userId for later use
                document.getElementById('upload-resumes').style.display = 'block'; // Show upload area
                document.getElementById('upload-btn').style.display = 'block'; // Show upload button
                resolve(userId); // Resolve the promise with userId
            })
            .catch(error => {
                console.error('Error fetching user info:', error);
                reject(error); // Reject the promise if there's an error
            });
        });
    }
    
    function showLoginButton() {
        document.getElementById('logout-button').style.display = 'none';
        document.getElementById('login-button').style.display = 'block';
        document.getElementById('feedback-container').style.display = 'none';


        document.getElementById('credits-remaining-text').style.display = 'none';
        const welcomeText = document.getElementById('welcome-text-after-loggedin')
        welcomeText.style.display = 'none';
        welcomeText.style.marginTop = '1rem';

        document.getElementById('after-header-content-container').style.justifyContent = 'center';

        showLoginContent(true);
    }
    
    function showLogoutButton() {
        document.getElementById('login-button').style.display = 'none';
        document.getElementById('logout-button').style.display = 'block';
        document.getElementById('feedback-container').style.display = 'block';
        const welcomeText = document.getElementById('welcome-text-after-loggedin')
        welcomeText.style.display = 'block';
        welcomeText.style.marginTop = '0rem';

        document.getElementById('after-header-content-container').style.justifyContent = 'space-between';



        document.getElementById('credits-remaining-text').style.display = 'block';

        showLoginContent(false);
    }

    function showLoginContent(status) {
        if (status) {

            const loginMainContainer = document.createElement('div')
            loginMainContainer.id = 'login-main-container'
            
            loginMainContainer.innerHTML = `<div>
        <p class="login-welcome-text">Welcome to Recruitbot!</p>
        <p class="login-inner-text transparent-black">Our Chrome Extension allows you to bulk download CVs from LinkedIn, extract relevant data, and add it to a Google Sheet!</p>
        <p class="login-inner-text transparent-black">
        Please Sign In to Continue.
        </p>
        </div>`
            

        const mainContainer = document.getElementById("main-container")
        const afterHeadContentContainer = document.getElementById('after-header-content-container');

        
        // Insert loginMainContainer before afterHeadContentContainer
        mainContainer.insertBefore(loginMainContainer, afterHeadContentContainer);
    } else {
        // remove loginMainContainer
        const loginMainContainer = document.getElementById('login-main-container');
        if (loginMainContainer) {
        loginMainContainer.remove();
        }
    }
    }
    
    let filesToUpload = new Map();
    let uploadBtn = document.getElementById('upload-btn');
    let dragDropArea = document.querySelector('.drag-drop-area');
    let uploadedFilesContainer = document.querySelector('.uploaded-files');

    // Initial state: disable the upload button
    setUploadButtonState(false);

    // Function to set the upload button state
    function setUploadButtonState(isEnabled) {
        const uploadBtn = document.getElementById('upload-btn');
        if (isEnabled) {
            uploadBtn.disabled = false;
            uploadBtn.classList.remove('not-allowed-cursor');
            uploadBtn.removeAttribute('title'); // Remove the title when the button is enabled
        } else {
            uploadBtn.disabled = true;
            uploadBtn.classList.add('not-allowed-cursor');
            uploadBtn.setAttribute('title', 'Please add resumes to upload'); // Set the title when the button is disabled
        }
    }
    

    
    uploadBtn.onclick = function(event) {
        event.preventDefault();
        // Disable the button to avoid multiple clicks
        uploadBtn.disabled = true;
        // showMessage("Upload process started!");
        
        if (filesToUpload.size > 0) {
            showUploadStartedNotification();
            submitFiles();
        } else {
            alert('No files to upload.');
        }
    };
    
    dragDropArea.addEventListener('dragover', function(event) {
        event.preventDefault();
        dragDropArea.classList.add('dragging');
    });
    
    dragDropArea.addEventListener('dragleave', function() {
        dragDropArea.classList.remove('dragging');
    });
    
    dragDropArea.addEventListener('drop', function(event) {
        event.preventDefault();
        dragDropArea.classList.remove('dragging');
        handleFiles(event.dataTransfer.files);
    });
    
    function handleFiles(files) {
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            if (file.type === 'application/pdf' || file.type === 'application/msword' || file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
                if (!filesToUpload.has(file.name)) {
                    filesToUpload.set(file.name, file);
                    addFileToList(file.name);
                } else {
                    // console.log('Duplicate file ignored:', file.name);
                }
            } else {
                alert('Only PDF, DOC, and DOCX files are allowed.');
            }
        }

        // Update the upload button state based on whether there are files to upload
        setUploadButtonState(filesToUpload.size > 0);
    }
    
    function truncateFileName(fileName, maxLength) {
        var extension = fileName.slice(fileName.lastIndexOf('.'));
        var baseName = fileName.slice(0, fileName.lastIndexOf('.'));
        if (baseName.length > maxLength) {
            baseName = baseName.substring(0, maxLength) + '...';
        }
        return baseName + extension;
    }
    
    function addFileToList(fileName) {
        var shortFileName = truncateFileName(fileName, 17);
        var uploadedFile = document.createElement('div');
        uploadedFile.className = 'uploaded-file';
    
        var fileIcon = document.createElement('span');
        fileIcon.className = 'file-icon';
        fileIcon.style.backgroundImage = 'url("../icons/pdf-image.svg")';
    
        var fileNameSpan = document.createElement('span');
        fileNameSpan.className = 'file-name';
        fileNameSpan.textContent = shortFileName;
    
        var removeButton = document.createElement('button');
        removeButton.className = 'remove-file-btn';
        removeButton.textContent = 'x';
        removeButton.onclick = function() {
            uploadedFilesContainer.removeChild(uploadedFile);
            filesToUpload.delete(fileName);

            // Update the upload button state based on whether there are files to upload
            setUploadButtonState(filesToUpload.size > 0);
        
        };
    
        uploadedFile.appendChild(fileIcon);
        uploadedFile.appendChild(fileNameSpan);
        uploadedFile.appendChild(removeButton);
    
        uploadedFilesContainer.appendChild(uploadedFile);
    }
    
    
    
    async function uploadFiles(files, userId, projectId) {
        var uploadedCount = 0;
        var progressBar = createProgressBar(files.length);

        function generateUniqueIds(n, length) {
            const uniqueIds = new Set();
            const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        
            while (uniqueIds.size < n) {
                let id = '';
                for (let i = 0; i < length; i++) {
                    id += characters.charAt(Math.floor(Math.random() * characters.length));
                }
                uniqueIds.add(id); // Set automatically handles duplicates
            }
        
            return Array.from(uniqueIds);
        }

        const ids = generateUniqueIds(files.length, 20);
    
        // for (const file of files) {
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const uniqueId = ids[i]; // Get the corresponding unique ID for this file
            
            var formData = new FormData();
            formData.append('file', file);
            formData.append('user_id', userId);
            formData.append('unique_id', uniqueId);
            formData.append('project_id', projectId);
    
            try {
                const response = await fetch('https://www.valyee.com/extension/upload', {
                    method: 'POST',
                    body: formData,
    
                });
    
                const data = await response.json();
    
                if (data.success) {
                    uploadedCount++;
                    updateProgressBar(progressBar, uploadedCount, files.length);
                    if (uploadedCount === files.length) {
                        showUploadSuccessNotification();
                        // Hide the upload-resumes div and show loading animation
                        showLoadingAnimation(true);
                        // document.getElementById('upload-resumes').style.display = 'none';
                        // document.getElementById('loading-animation').style.display = 'block';
                        fetchCSVResult(userId, projectId);
                    }
                } else {
                    console.error('File upload failed:', file.name);
                }
            } catch (error) {
                console.error('Error uploading file:', error);
            }
    
            // Add a 500ms delay between each file upload
            await new Promise(resolve => setTimeout(resolve, 500));
        }
    }

    function showLoadingAnimation(status) {
        if (status) {
            document.getElementById('upload-resumes').style.display = 'none';
            document.getElementById('loading-animation').style.display = 'block';
            document.getElementById('data-processing-title-text').style.display = 'flex';

            // hide all details
            document.getElementById('main-container').style.display = 'none';
        } else {
            document.getElementById('upload-resumes').style.display = 'block';
            document.getElementById('loading-animation').style.display = 'none';
            document.getElementById('data-processing-title-text').style.display = 'none';

            // unhide all details
            document.getElementById('main-container').style.display = 'grid';
        }
    }

    showLoadingAnimation(false);
    
    
    
    
    // function fetchCSVResult(userId) {
    //     var formData = new FormData();
    //     formData.append('unique_id', userId);
    
    //     fetch('https://www.valyee.com/extension/get-result', {
    //         method: 'POST',
    //         body: formData
    //     })
    //     .then(response => response.blob())
    //     .then(blob => {
    //         var link = document.createElement('a');
    //         link.href = window.URL.createObjectURL(blob);
    //         link.download = 'result.csv';
    //         link.click();
    //         showUploadSuccessNotification();
    //     })
    //     .catch(error => console.error('Error fetching CSV result:', error));
    // }
    
    
    function submitFiles() {
        chrome.storage.local.get(['userId'], function(result) {
            const userId = result.userId;
            if (!userId) {
                alert('User ID not found. Please log in again.');
                return;
            }

            // send basic job info to the server
             // Get values from the input fields
            const jobTitle = document.getElementById("jobTitle").value;
            const rememberExtractedFields = document.getElementById("remember-extracted-fields-checkbox").checked;

            const jobDescriptionFile = document.getElementById("jobDescriptionFile").files[0];
            // const selectedFields = Array.from(document.getElementById("extractFieldsDropdown").selectedOptions).map(option => option.value);

            // defining csv file name with job title and todays date
            xlsxFileName = jobTitle + '-' + new Date().toISOString().slice(0, 10) + '.xlsx';

            // Create a FormData object to include the file
            let formData = new FormData();
            formData.append("user_id", userId);
            formData.append("job_title", jobTitle);
            formData.append("job_description", jobDescriptionFile);
            formData.append("job_extracted_fields", JSON.stringify(selectedUserFields)); // Convert array to JSON string
            formData.append("remember_extracted_fields", rememberExtractedFields);


            // Send the POST request using fetch
            fetch('https://www.valyee.com/extension/upload-initial-info', {
                method: 'POST',
                body: formData,
                headers: {
                    'Accept': 'application/json'
                }
            })
            .then(response => {
                if (response.ok) {
                    // console.log("Data uploaded successfully!");
                    return response.json(); // Parse the JSON response
                } else {
                    throw new Error(`Server responded with status: ${response.status}`);
                }
            })
            .then(data=>{
                // Access the project_id from the response data
                const projectId = data.project_id;
                uploadFiles(Array.from(filesToUpload.values()), userId, projectId); 
            })
            .catch(error => {
                console.error("Error:", error);
                alert("Insufficient credits! Please top up your credits.");
            });

    
        });
    }
    
    // function fetchCSVResult(userId) {
    //     var formData = new FormData();
    //     formData.append('user_id', userId);
    
    //     fetch('https://www.valyee.com/extension/get-result', {
    //         method: 'POST',
    //         body: formData,
    //     })
    //     .then(response => response.blob())
    //     .then(blob => {
    //         var link = document.createElement('a');
    //         link.href = window.URL.createObjectURL(blob);
    //         link.download = 'result.csv';
    //         link.click();
    //         showCsvDownloadedNotification();
            
    //         // re-enable the upload button
    //         uploadBtn.disabled = false;
    //     })
    //     .catch(error => console.error('Error fetching CSV result:', error))
    //     .finally(() => {
    //         // Hide the loading animation and show the upload-resumes div
    //         document.getElementById('loading-animation').style.display = 'none';
    //         document.getElementById('upload-resumes').style.display = 'block';
    //     });
    // }


    function fetchCSVResult(userId, projectId) {
        
        var formData = new FormData();
        formData.append('user_id', userId);
        formData.append('project_id', projectId);
        
        function checkForCSV() {
            fetch('https://www.valyee.com/extension/get-result', {
                method: 'POST',
                body: formData,
            })
            .then(response => {
                // Check if the response is a XLSX file
                if (response.headers.get('Content-Type').includes('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
                    // Extract the filename from the Content-Disposition header
                    const contentDisposition = response.headers.get('Content-Disposition');
                    let fileName = xlsxFileName; // Fallback name in case we can't extract it

    
                    if (contentDisposition) {
                        const fileNameMatch = contentDisposition.match(/filename="(.+)"/);
                        if (fileNameMatch.length > 1) {
                            fileName = fileNameMatch[1]; // Extracted filename
                        }
                    }
    
                    return response.blob().then(blob => ({ blob, fileName }));
                } else {
                    return response.json(); // Handle JSON response if status is pending
                }
            })
            .then(data => {
                if (data.blob) { // Check if data is a Blob (indicating a CSV file)
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(data.blob);
                    link.download = data.fileName; // Use the dynamic filename
                    link.click();

                    // show the upload-resumes div and hide loading animation after csv is downlaoded
                    showLoadingAnimation(false);
                    // document.getElementById('upload-resumes').style.display = 'block';
                    // document.getElementById('loading-animation').style.display = 'none';

                    showCsvDownloadedNotification();
    
                    // re-enable the upload button
                    uploadBtn.disabled = false;
                } else if (data.status === "pending") { // Check if the status is pending
                    console.log("Result is pending. Trying again in 4 seconds...");
    
                    // Retry after a 4-second delay
                    setTimeout(checkForCSV, 4000);
                } else {
                    console.error('Unexpected response:', data);
                }
            })
            .catch(error => console.error('Error fetching CSV result:', error))
            .finally(() => {
                // // Hide the loading animation and show the upload-resumes div
                // document.getElementById('loading-animation').style.display = 'none';
                // document.getElementById('upload-resumes').style.display = 'block';
            });
        }
    
        // Start the check loop
        checkForCSV();
    }
    
    
    
    
    
    function createProgressBar(totalFiles) {
        var progressBarContainer = document.createElement('div');
        progressBarContainer.className = 'progress-bar-container';
    
        var progressBar = document.createElement('div');
        progressBar.className = 'progress-bar';
        progressBar.style.width = '0%';
        progressBar.textContent = `0 / ${totalFiles} files uploaded`;
    
        progressBarContainer.appendChild(progressBar);
        document.querySelector('.upload-area').insertAdjacentElement('afterend', progressBarContainer);
    
        return progressBar;
    }
    
    function updateProgressBar(progressBar, uploadedCount, totalFiles) {
        var percentage = (uploadedCount / totalFiles) * 100;
        progressBar.style.width = percentage + '%';
        progressBar.textContent = `${uploadedCount} / ${totalFiles} files uploaded`;
    
        if (uploadedCount === totalFiles) {
            setTimeout(() => {
                progressBar.parentElement.remove();
                filesToUpload.clear();
                uploadedFilesContainer.innerHTML = '';
            }, 2000);
        }
    }


    // show notification functions
    function showUploadStartedNotification() {
        var notification = document.getElementById('upload-started-notification');
        notification.style.display = 'flex';

        // Automatically close after 5 seconds
        setTimeout(closeUploadStartedNotification, 5000);
    }
    
    function showUploadSuccessNotification() {
        var notification = document.getElementById('upload-success-notification');
        notification.style.display = 'flex';

        // Automatically close after 5 seconds
        setTimeout(closeUploadNotification, 5000);
    }
    
    function showCsvDownloadedNotification() {
        var notification = document.getElementById('csv-download-notification');
        notification.style.display = 'flex';
    }
    
    
    
    // close notification functions
    
    function closeUploadStartedNotification() {
        var notification = document.getElementById('upload-started-notification');
        notification.style.display = 'none';
    }

    function closeUploadNotification() {
        var notification = document.getElementById('upload-success-notification');
        notification.style.display = 'none';
    }
    
    function closeCsvNotification() {
        var notification = document.getElementById('csv-download-notification');
        notification.style.display = 'none';
    }

    
    
    document.getElementById('close-upload-notification').addEventListener('click', closeUploadNotification);
    
    document.getElementById('close-csv-notification').addEventListener('click', closeCsvNotification);

    document.getElementById('close-upload-started-notification').addEventListener('click', closeUploadStartedNotification);

    

    // feedback
    // Global scope variable
    var email = null;
    var encryptedEmailStr = null;

    function getUserEmail() {
        return new Promise((resolve, reject) => {
            chrome.identity.getAuthToken({ interactive: true }, function(token) {
                if (chrome.runtime.lastError || !token) {
                    console.error("Failed to get auth token:", chrome.runtime.lastError);
                    reject("User is not authenticated");
                } else {
                    // Make an authenticated request to get the user's profile information
                    fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                        headers: {
                            'Authorization': 'Bearer ' + token
                        }
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Failed to retrieve user information');
                        }
                        return response.json();
                    })
                    .then(data => {
                        // Extract the email from the user's profile information
                        if (data.email) {
                            console.log("User's email:", data.email);
                            email = data.email;  // Save the email to the global variable
                            resolve(email);
                        } else {
                            reject("Email not found in the user's profile information");
                        }
                    })
                    .catch(error => {
                        console.error("Error occurred while retrieving user information:", error);
                        reject(error);
                    });
                }
            });
        });
    }  


    async function encryptEmail(email) {
        try {
            const response = await fetch('https://www.valyee.com/extension/encrypt-email', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email: email })
            });
    
            if (!response.ok) {
                throw new Error(`Encryption failed with status ${response.status}`);
            }
    
            const data = await response.json();
    
            if (data.encrypted_email) {
                return data.encrypted_email;
            } else {
                throw new Error('Encryption failed: No encrypted_email field in response');
            }
        } catch (error) {
            console.error('Error during encryption:', error);
            throw error;
        }
    }


    async function processEmail(emailInput) {
        try {
            // If state is true, encrypt the email
            encryptedEmailStr = await encryptEmail(emailInput);
            console.log('Encrypted Email:', encryptedEmailStr);

        } catch (error) {
            console.error('Error processing email:', error);
        }
    }


    document.getElementById('share-feedback-btn').addEventListener('click', async function() {
        try {
            await getUserEmail();
            console.log("the email is: ", email);
            // Call processEmail with the email
            await processEmail(email);
            
            // Redirect to the URL with the encrypted email
            if (encryptedEmailStr) {
                redirectUrl = `https://www.valyee.com/extension/feedback/${encryptedEmailStr}`;
                console.log("redirect url :", redirectUrl);
                window.open(redirectUrl, '_blank');  // Open in a new tab
            } else {
                console.error('Encrypted email string is not available.');
            }
        } catch (error) {
            console.error('Error during email encryption or redirection:', error);
        }
    });


    
});
