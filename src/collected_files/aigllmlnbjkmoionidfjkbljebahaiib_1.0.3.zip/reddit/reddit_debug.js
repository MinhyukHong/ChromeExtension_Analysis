// general purpose functions

/*
    General purpose console logger, very simple for logging single item
    hint: to add description, call using template strings (backticks)
    e.g. df(cLog, [`The item is: ${item}`])
 */
function consoleLog(item, CSS) {
    if (!CSS) {
        console.log(item);
    } else {
        console.log(item, CSS);
    }
}

/*
    General purpose error handler. A boolean controls whether to
    invoke the debugger as well;
 */
function defaultErrorHandler(err, invokeDebugger) {
    console.log("General purpose error handler: ", err);
    if (invokeDebugger && enableDebugger) debugger;
}

/*
    General purpose replacement for if (enableDebugger) debugger;
 */
function halt() {
    if (enableDebugger) debugger;
}
if (enableDebugger) document.getElementsByTagName("HTML")[0].setAttribute("reddit-intel-debug", "true");

/* ------------------------------------------------------------------------- */

function getCallActionType_addAction(searchText, referenceElement, referenceElementNew, adRoot) {
    console.log(`need to add ${searchText} to actionTypes array`, referenceElement, referenceElementNew, adRoot);
    actionTypes.push(searchText);
    if (enableDebugger) debugger;
}

function getCallActionType_catch(err, adRoot) {
    console.log("getCallActionType error:");
    console.log(err, adRoot);
    if (enableDebugger) debugger;
}

/* ------------------------------------------------------------------------- */

function getUserData_NoUser(err) {
    if (enableDebugger) console.log("can't get username", err);
}