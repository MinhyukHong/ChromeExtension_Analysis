// reddit-intelligence Tool
// This script runs in its own scope
if (enableDebugger) console.log("reddit_feed_parser loaded");

let sponsoredClass = null;
let optSponsoredClass = null;
let updatedSponsored = null;
let sideSponsoredClass = null;
let recentSponsored = null;
let latestSponsored = null;
let simpleSponsored = null;
let birthday = '';

let defaultGeoData = {
    serviceId: null,
    lastUpdated: null,
    userCity: null,
    userState: null,
    userCountry: null,
    userIP: ""
};
let geoData = {};

// chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
//     geoData = Object.assign(geoData, result.geoData);
//     if (geoData.lastUpdated < (Date.now() - 2 * 60 * 60 * 1000)) {
//         geoData.userIP = null;
//         buildUpGeoData();
//     }
// });
chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
    geoData = Object.assign(geoData, result.geoData);
    const minDelay = 2 * 60 * 60 * 1000; // 2 hours in milliseconds
    const maxDelay = 3 * 60 * 60 * 1000; // 3 hours in milliseconds
    const randomDelay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;

    if (geoData.lastUpdated < (Date.now() - randomDelay)) {
        geoData.userIP = null;
        buildUpGeoData();
    }
});

const geoFunctions = [db_ip_com];

const adData = {
    type: null,
    category: null,
    post_owner: null,
    ad_title: null,
    news_feed_description: null,
    likes: null,
    share: null,
    comment: null,
    platform: null,
    call_to_action: null,
    image_video_url: null,
    image_video_url_original: null,
    destination_url: null,
    side_url: null,
    ad_id: null,
    post_date: null,
    first_seen: null,
    last_seen: null,
    city: null,
    state: null,
    country: null,
    lower_age: null,
    upper_age: null,
    post_owner_image: null,
    ad_position: null,
    ad_text: null,
    advert_id: null,
    ad_url: null,
    version: null,
    ip_address: null,
    page_verified: null,
    source: null
};

const requiredData = {
    ad_id: {
        attribute: "data-reddit-intel-ad_id",
        method: getAdId
    },
    category: {
        attribute: "data-reddit-intel-category",
        method: getCategory
    },
    ad_position: {
        attribute: "data-reddit-intel-ad_position",
        method: getPosition
    },
    image_video_url: {
        attribute: "data-reddit-intel-image_video_url",
        method: getAdVideoUrl
    },
    image_video_url_original: {
        attribute: "data-reddit-intel-image_video_url_original",
        method: getAdVideoUrlOriginal
    },
    post_owner: {
        attribute: "data-reddit-intel-post_owner",
        method: getOwner
    },
    ad_title: {
        attribute: "data-reddit-intel-ad_title",
        method: getTitle
    },
    news_feed_description: {
        attribute: "data-reddit-intel-news_feed_description",
        method: getNewsfeedDescription
    },
    likes: {
        attribute: "data-reddit-intel-likes",
        method: getLikesCount
    },
    share: {
        attribute: "data-reddit-intel-share",
        method: getSharesCount
    },
    comment: {
        attribute: "data-reddit-intel-comment",
        method: getCommentsCount
    },
    platform: {
        attribute: "data-reddit-intel-platform",
        method: getPlatform
    },
    call_to_action: {
        attribute: "data-reddit-intel-call_to_action",
        method: getCallActionType
    },
    destination_url: {
        attribute: "data-reddit-intel-destination_url",
        method: getDestinationUrl
    },
    /*
    side_url: {
        attribute: "data-reddit-intel-side_url",
        method: getUndefined
    },
    */
    post_date: {
        attribute: "data-reddit-intel-post_date",
        method: getPostDate
    },
    first_seen: {
        attribute: "data-reddit-intel-first_seen",
        method: getFirstSeen
    },
    last_seen: {
        attribute: "data-reddit-intel-last_seen",
        method: getLastSeen
    },
    city: {
        attribute: "data-reddit-intel-city",
        method: getUserCity
    },
    state: {
        attribute: "data-reddit-intel-state",
        method: getUserState
    },
    country: {
        attribute: "data-reddit-intel-country",
        method: getUserCountry
    },
    lower_age: {
        attribute: "data-reddit-intel-lower_age",
        method: getLowerAdAge
    },
    upper_age: {
        attribute: "data-reddit-intel-upper_age",
        method: getUpperAdAge
    },
    /*
    post_owner_image: {
        attribute: "data-reddit-intel-post_owner_image",
        method: getPostOwnerImage
    },
    */

    /*
    advert_id: {
        attribute: "data-reddit-intel-advert_id",
        method: getAdvertId
    },
    */
    ad_url: {
        attribute: "data-reddit-intel-ad_url",
        method: getAdUrl
    },
    version: {
        attribute: "data-reddit-intel-version",
        method: getVersion
    },
    ip_address: {
        attribute: "data-reddit-intel-ip_address",
        method: getUserIp
    },
    type: {
        attribute: "data-reddit-intel-type",
        method: getType
    },
    page_verified: {
        attribute: "data-reddit-intel-page_verified",
        method: getPageVerified
    },
    ad_text: {
        attribute: "data-reddit-intel-ad_text",
        method: getAdText
    },
    reddit_id: {
        attribute: "data-reddit-intel-reddit_id",
        method: getRedditId
    },
    source: {
        attribute: "data-reddit-intel-source",
        method: getSource
    }
};

let isProcessing = false;
let scrollCounter = 0;

let intervalTimer = null;
let scrollTimer = null;


if (enableDebugger) document.getElementsByTagName("HTML")[0].setAttribute("reddit-intel-debug", "true");

try {
    getUserData();
    userDetails();
    userAdPreferences();
} catch (err) {
    df(defaultErrorHandler, [err]);
}

window.onscroll = function () {
    // if (document.location.href === "https://www.facebook.com/") {
    clearTimeout(scrollTimer);
    clearInterval(intervalTimer);
    scrollTimer = setTimeout(processScroll, 200);
    intervalTimer = setInterval(processScroll, 1000);
    // }
};

function processScroll() {
    // if (enableDebugger) console.log("process scroll");

    if (isProcessing)
        return;

    scrollCounter += 1;
    // const startTime = Date.now();
    isProcessing = true;

    try {
        // determine the class that fb uses for "sponsored"
        if (!sponsoredClass) {
            //sponsoredClass = "a._3e_2 div._14bf";
            sponsoredClass = "_2oEYZXchPfHwcf9mTMGMg8";
            optSponsoredClass = "SpSonSsoSredS%20%C2%B7";
            updatedSponsored = "SpSonSsoSredSSS%20%C2%B7%20";
            latestSponsored = "SpSpSononSsosoSredredSSS%20%C2%B7%20";
            recentSponsored = "Sp%0ASpS%0Aon%0AonS%0Aso%0AsoS%0Ared%0AredSSS%20%C2%B7%20";
            simpleSponsored = "Sponsored%20%C2%B7%20";
            //sponsoredClass = "SpSonSsoSredS";
            sideSponsoredClass = "Sponsored";
        }
        // todo use hasNoContent
        if (!reddit_dtsg || !composerId) {
            getUserData();
        }

        if (!geoData.userCity) {
            buildUpGeoData();
            isProcessing = false;
            return;
        }
        // setTimeout(checkForNew, 100);
        // setTimeout(triageItems, 100);
        // setTimeout(extractDataFromItems, 100);
        // setTimeout(getSponsoredAdCount, 100);
        // setTimeout(saveSponsoredAds, 100);
        // setTimeout(hideOrShowAds, 100);
        // setTimeout(addEventListeners, 100);
    } catch (e) {

    }
    isProcessing = false;

    // const delta = Date.now() - startTime;
    // chrome.runtime.sendMessage(null, { "mainLoopTime": delta });
}











