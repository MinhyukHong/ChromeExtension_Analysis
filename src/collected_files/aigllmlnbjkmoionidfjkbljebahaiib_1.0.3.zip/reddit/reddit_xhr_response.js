let [redditid, usercity, userstate, usercountry, userip, fSeen, lSeen] = [
  null,
  null,
  null,
  null,
  null,
  null,
  null,
];

//Get geodata
(() => {
  const retryDelay = 1000; // Adjust the delay as needed (in milliseconds)

  function fetchData() {
    userip = getUserIp();
    usercity = getUserCity();
    userstate = getUserState();
    usercountry = getUserCountry();

    if (
      userip === null ||
      usercity === null ||
      userstate === null ||
      usercountry === null
    ) {
      // If any of the values are null, retry after a delay
      setTimeout(fetchData, retryDelay);
    } else {
      // All values are available, proceed with the data
      // Do something with userip, usercity, userstate, usercountry
      userip = getUserIp();
      usercity = getUserCity();
      userstate = getUserState();
      usercountry = getUserCountry();
      redditid = getUserId();
      fSeen = getFirstSeen();
      lSeen = getLastSeen();
    }
  }

  fetchData(); // Initial call to start fetching data
})();

//For fetch()
function saveadsdata(event) {
  let ads = event.detail.adsData;
  try {
    const adData = {
      type: ads?.attributes["ad-type"] === "display" ? "IMAGE" : "VIDEO",
      category: "No Category",
      post_owner: ads?.attributes?.author,
      ad_title: ads?.attributes["post-title"]
        ? ads?.attributes["post-title"].replace(/\\/g, "")
        : "",
      news_feed_description: ads?.attributes?.domain,
      likes: ads?.attributes?.score || "0",
      share: "0",
      comment: ads?.attributes["comment-count"],
      platform: "3",
      call_to_action: ads?.attributes["call-to-action"],
      image_video_url:
        ads?.children[3]?.children[1]?.children[0]?.children[0]?.children[0]
          ?.attributes?.src ||
        ads?.attributes["content-href"] + "/DASH_720.mp4",
      image_video_url_original:
        ads?.children[3]?.children[1]?.children[0]?.children[0]?.children[0]
          ?.attributes?.src ||
        ads?.attributes["content-href"] + "/DASH_720.mp4",
      destination_url: ads?.attributes["outbound-link-url"],
      side_url: null,
      ad_id: ads?.attributes?.id,
      post_date: getPostDate(ads),
      first_seen: `${fSeen}`,
      last_seen: `${lSeen}`,
      city: usercity,
      state: userstate,
      country: usercountry,
      lower_age: "18",
      upper_age: "65",
      post_owner_image: ads?.attributes?.icon,
      ad_position: "FEED",
      ad_text: ads?.children[2]?.textContent[1]
        ? ads?.children[2]?.textContent[1].replace(/\\/g, "")
        : "",
      advert_id: null,
      ad_url: "https://www.reddit.com" + ads?.attributes?.permalink,
      version: version,
      reddit_id: redditid,
      ip_address: userip,
      page_verified: "true",
      source: "desktop",
      thumbnail_url: findThumbnail(ads,'poster')[0] || null
    };

    if (
      adData["image_video_url"].length > 0 &&
      adData["destination_url"].length > 0 &&
      !adData["image_video_url"].includes("gallery") &&
      adData["destination_url"].includes("https")
    ) {
      if (adData.type === "IMAGE") sendPost(adData);
      if (adData.type === "VIDEO") {
        analyzeVideoUrl(adData.image_video_url).then((res) => {
          if (res) sendPost(adData);
        });
      }
    }
  } catch (error) {}
}

//Send json data to server
async function sendPost(post) {
  try {
    const response = await fetch(`${powerAdSpyRedditApi}redAdsData`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(post),
    });
    const message = await response.text();
  } catch (error) {}
}

//Find thumbnail
function findThumbnail(obj,keyToFind) {

 try {
  let result = [];
  if (typeof obj !== 'object' || obj === null) return result;
  for (let key in obj) {
      if (obj.hasOwnProperty(key)) {
          let value = obj[key];
          if (key === keyToFind) {
              result.push(value);
          }
          if (typeof value === 'object' && value !== null) {
              result = result.concat(findThumbnail(value, keyToFind));
          }
      }
  }
  return result;
 } catch (error) {
  // console.log(error)
 }
}



//Get Postdate
function getPostDate(ads) {
  let date;
  if (Array.isArray(ads)) {
    return getFirstSeen();
  } else if (ads?.node) {
    date = ads?.node?.createdAt;
  } else if (ads?.attributes) {
    date = ads?.attributes["created-timestamp"];
  }
  let epochTime = new Date(date).getTime() / 1000; // Date is in this format "2023-09-11T21:33:09.999000+0000"
  return JSON.stringify(epochTime).split(".")[0]; //After converting in epoch it comes in decimal so we split from decimal and taking data from zeroth element of array
}

// for user Id
function getUserId() {
try {
  let RedditId = document
  .querySelector(".text-12.text-secondary-weak")
  .innerHTML.split("u/")[1];
return RedditId.trim(); // Trim to remove any leading or trailing whitespace
} catch (error) {
  
} 
}

//Get image video url
function getimagevideourl(ads) {
  try {
    if (Array.isArray(ads)) {
      let url = ads[0];
      if (ads[9] === "VIDEO") {
        return url.split("96.mp4").join("720.mp4");
      } else {
        return url;
      }
    } else if (
      ads?.node?.media?.typeHint == "VIDEO" ||
      ads?.media?.type == "video"
    ) {
      let video =
        ads?.node?.media?.streaming?.scrubberMediaUrl ||
        ads?.media?.scrubberThumbSource;
      return video.split("96.mp4").join("720.mp4");
    }
    // else if(ads?.attributes["content-href"]){
    //   return ads?.attributes["content-href"].includes('reddit.com/gallery') ?
    // }
    return (
      ads?.node?.media?.still?.xlarge?.url ||
      ads?.media?.resolutions[3]?.url ||
      ""
    );
  } catch (error) {}
}

//for fetch
document.addEventListener("redditAds", saveadsdata);

async function analyzeVideoUrl(videoUrl) {
  return fetch(videoUrl)
    .then((response) => {
      return response.status === 200 ? true : false;
    })
    .catch((error) => {
      return false;
    });
}

//Get ad url
// function getadurl(ads) {
//   if (Array.isArray(ads)) {
//     return ads[10];
//   } else if (ads?.node) {
//     return (
//       "https://reddit.com" +
//       ads?.node?.permalink +
//       "?p=1&impressionid=" +
//       ads?.node?.impressionId
//     );
//   }
//   return ads?.permalink + "?p=1&impressionid=" + ads?.impressionId;
// }

// //Get ad ID
// function getadid(ads) {
//   try {
//     let ID = ads[10];
//     let id = ID || ads?.node?.permalink || ads?.permalink.split("com/")[1];
//     let match = id.match(/\/comments\/(\w+)\//); //Extracting the id from url
//     return match ? match[1] : null;
//   } catch (error) {}
// }

// //Get type
// function gettype(ads) {
//   try {
//     if (Array.isArray(ads)) {
//       return ads[9];
//     } else if (
//       ads?.node?.media?.typeHint == "VIDEO" ||
//       ads?.media?.type == "video"
//     ) {
//       return "VIDEO";
//     }
//     return "IMAGE";
//   } catch (error) {}
// }

// //Get comment
// function getcomment(ads) {
//   try {
//     if (Array.isArray(ads)) {
//       let comment;
//       if (ads[7].includes("Comments")) {
//         comment = ads[7].split("Comments")[0];
//       } else {
//         comment = ads[7].split("comments")[0];
//       }
//       if (comment.includes("k")) {
//         return parseFloat(comment) * 1000;
//       } else {
//         return comment;
//       }
//     } else if (ads?.node) {
//       return ads?.node?.commentCount;
//     }
//     return ads?.numComments;
//   } catch (error) {}
// }

// //Get image video url
// function getimagevideourl(ads) {
//   try {
//     if (Array.isArray(ads)) {
//       let url = ads[0];
//       if (ads[9] === "VIDEO") {
//         return url.split("96.mp4").join("720.mp4");
//       } else {
//         return url;
//       }
//     } else if (
//       ads?.node?.media?.typeHint == "VIDEO" ||
//       ads?.media?.type == "video"
//     ) {
//       let video =
//         ads?.node?.media?.streaming?.scrubberMediaUrl ||
//         ads?.media?.scrubberThumbSource;
//       return video.split("96.mp4").join("720.mp4");
//     }
//     return (
//       ads?.node?.media?.still?.xlarge?.url ||
//       ads?.media?.resolutions[3]?.url ||
//       ""
//     );
//   } catch (error) {}
// }

// //Get likes
// function getLikes(ads) {
//   try {
//     if (Array.isArray(ads)) {
//       const likesValue = ads[8];
//       if (likesValue === "Vote") {
//         return "0";
//       } else if (likesValue.includes("k")) {
//         return parseFloat(likesValue) * 1000;
//       } else {
//         return likesValue;
//       }
//     }
//     return ads?.score || ads?.node?.score || "0";
//   } catch (error) {}
// }

//Get ad text
// function getadtext(ads) {
//   if (Array.isArray(ads)) {
//     if (ads[3] == ads[4]) {
//       return ""
//     }
//     else {
//       return ads[3];
//     }
//   } else {
//     let text =
//       ads?.node?.adSupplementaryTextRichtext || ads?.adSupplementaryText;
//     if (text != null) {
//       return JSON.parse(text)
//         ?.document[0]?.c.map((t) => t.t)
//         .join("");
//     }
//   }
//   return "";
// }

// //Get between
// function getBetween(pageSource, firstData, secondData) {
//   try {
//     const resSplit = pageSource.split(firstData);
//     const indexSec = resSplit[1].indexOf(secondData);
//     return resSplit[1].substring(0, indexSec);
//   } catch (e) {
//     return "";
//   }
// }

// //Get ads from element
// function processElement(element) {
//   //This function is responsible for processing a single HTML element.
//   try {
//     if (element.getAttribute("class").length > 150) {
//       // Here element.getAttribute("class").length is greater than 150 for promoted data
//       let title,
//         postOwner,
//         like,
//         comment,
//         arr = [];

//       let image = Array.from(element.querySelectorAll("img"));
//       let video = $(element).find('div[data-testid="shreddit-player-wrapper"]');
//       title = element.querySelector("h3");
//       postOwner = element.querySelectorAll("a");
//       like = element.querySelectorAll("div");
//       comment = element.querySelectorAll("span");
//       if (image.length > 2) {
//         if (image[2].src != "") {
//           arr.push(
//             image[2].src,
//             postOwner[4].innerText,
//             postOwner[5].innerText,
//             like[17].innerText,
//             title.innerText,
//             postOwner[1].innerText,
//             postOwner[4].href,
//             comment[7].innerText,
//             like[3].innerText,
//             "IMAGE",
//             postOwner[6].href
//           );
//         } else {
//           let img = getBetween(like[19].style.backgroundImage, "url(", ")");

//           arr.push(
//             img,
//             postOwner[4].innerText,
//             postOwner[5].innerText,
//             like[17].innerText,
//             title.innerText,
//             postOwner[1].innerText,
//             postOwner[4].href,
//             comment[7].innerText,
//             like[2].innerText,
//             "IMAGE",
//             postOwner[6].href
//           );
//         }
//       } else if (
//         video &&
//         video.find("shreddit-player").attr("preview") != undefined
//       ) {
//         arr.push(
//           video.find("shreddit-player").attr("preview"),
//           postOwner[3].innerText,
//           postOwner[4].innerText,
//           like[17].innerText,
//           title.innerText,
//           postOwner[1].innerText,
//           postOwner[4].href,
//           comment[7].innerText,
//           like[3].innerText,
//           "VIDEO",
//           postOwner[5].href
//         );
//       }
//       if (arr[6] != "") {
//         // saveadsdata(arr);
//       }
//     }
//   } catch (error) {}
// }

// function processElements() {
//   //This function is responsible for selecting all elements on the page with a specific class
//   try {
//     let data = document.querySelectorAll("._1oQyIsiPHYt6nx7VOmd1sz");
//     // data.forEach(processElement);
//   } catch (error) {}
// }

// setTimeout(processElements, 8000);

//************************************************************************************************************************************ */
// let abc = null;
// const interceptorScript = document.createElement("script");
// interceptorScript.src = chrome.runtime.getURL("library/xhr-interceptor.js");
// interceptorScript.onload = function () {
//   this.remove();
// };

// (document.head || document.documentElement).appendChild(interceptorScript);

// //Get xhr response
// async function handleXhrIntercepted(event) {
//   try {
//     const { responseURL, response } = event.detail;
//     let res = JSON.parse(response)?.data?.home?.elements?.edges;

//     if (response.includes) {
//       res.map((ads) => {
//         if (
//           ads?.node?.__typename === "AdPost" &&
//           ads?.node?.isBlank === false &&
//           ads?.node?.content == null &&
//           ads?.node?.gallery == null
//         ) {
//           // saveadsdata(ads);
//         }
//       });
//     }
//   } catch (error) {}
// }

//Get page source
// (async () => {
//   let res = await fetch("https://www.reddit.com/");
//   let result = await res.text();
//   let object = getBetween(result, "window.___r =", ";</script><script>");
//   let ads = JSON.parse(object)?.posts?.models;
//   for (const ad in ads) {
//     if (
//       ads[ad].isSponsored === true &&
//       ads[ad].isBlank === false &&
//       ad.length <= 15
//     ) {
//       // saveadsdata(ads[ad]);
//     }
//   }
// })

//*********************************************************************************************************************** */
//xhr event listener
// document.addEventListener("XHR_INTERCEPTED", handleXhrIntercepted);

//Save ads data
// function saveadsdata(ads) {
//   try {
//     const adData = {
//       type: gettype(ads),
//       category: "No Category",
//       post_owner:
//         ads?.node?.authorInfo?.name || ads?.author || ads[5].split("u/")[1],
//       ad_title: ads?.node?.title || ads?.title || ads[4],
//       news_feed_description:
//         ads?.node?.gallery?.items[0]?.displayAddress ||
//         ads?.node?.domain ||
//         ads?.domain ||
//         ads[1] ||
//         "",
//       likes: getLikes(ads),
//       share: "0",
//       comment: getcomment(ads),
//       platform: "3",
//       call_to_action:
//         ads?.node?.gallery?.items[0]?.callToAction ||
//         ads?.node?.callToAction ||
//         ads?.callToAction ||
//         ads[2] ||
//         "",
//       image_video_url: getimagevideourl(ads),
//       image_video_url_original: getimagevideourl(ads),
//       destination_url:
//         ads?.node?.outboundLink?.url ||
//         ads?.source?.outboundUrl ||
//         ads[6] ||
//         "",
//       side_url: null,
//       ad_id: getadid(ads),
//       post_date: getPostDate(ads),
//       first_seen: getFirstSeen(),
//       last_seen: getLastSeen(),
//       city: usercity,
//       state: userstate,
//       country: usercountry,
//       lower_age: "18",
//       upper_age: "65",
//       post_owner_image: null,
//       ad_position: "FEED",
//       ad_text: getadtext(ads),
//       advert_id: null,
//       ad_url: getadurl(ads),
//       version: version,
//       reddit_id: redditid,
//       ip_address: userip,
//       page_verified: "true",
//       source: "desktop",
//     };

//     // if(adData["image_video_url"].length >0) sendPost(adData);
//     // console.log(adData)
//   } catch (error) {}
// }
