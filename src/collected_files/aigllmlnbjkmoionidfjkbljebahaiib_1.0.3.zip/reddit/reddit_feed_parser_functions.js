/*global birthday */
function df(fnName, parameters) {
	// if (typeof fnName === "string" && typeof this[fnName] === 'function') {
	//     this[fnName].apply(null, parameters)
	// } else {
	//     if (typeof fnName === "function") fnName.apply(null, parameters);
	// }
}

let reddit_dtsg = null;
let composerId = null;
let user_ID = null;
let isProcessingGeoData = false;

let actionTypes = [
	'Learn More', 'Sign Up', 'Shop Now', 'Interested', 'Send Message', 'Book Now', 'Play Now', 'Download',
	'Get Offer', 'Make Reservation', 'Donate', 'Use App', 'Play Game', 'Watch Video', 'See Offers', 'Book Appointment',
	'Listen', 'Send Email', 'Request Time', 'Read articles', 'Video Call Room', 'Start Order', 'Get Directions',
	'Get Tickets', 'WhatsApp', 'Play Music', 'Visit group', 'Apply Now', 'Buy', 'Buy Now', 'Buy Tickets',
	'Call Now', 'Contact Us', 'Donate Now', 'Download', 'Get Deal', 'Get Offer', 'Get Quote', 'Get Your Code',
	'Install App', 'Install Now', 'Learn Page', 'Like Page', 'Liked', 'Listen Now', 'Listen on Apple Music',
	'Listen On Deezer', 'Listen on Whooshkaa', 'Open Link', 'Order Now', 'Play Game', 'Play', 'Save Offer',
	'Save', 'SaveSaved', 'See Details', 'See Menu', 'Sell Now', 'Spotify Icon', 'Spotify IconAdd to Spotify',
	'Use Now', 'View Event', 'Visit Website', 'Vote Now', 'Watch More', 'Free Trial', 'Install',
	'View More',
	'None'
];

function getVersion() {
	return version;
}

const sendDefaultAttempts = 7; // change this to < 9 to give up and send "" for not found items

function getBetween(pageSource, firstData, secondData) {
	try {
		const resSplit = pageSource.split(firstData);
		const indexSec = resSplit[1].indexOf(secondData);
		return resSplit[1].substring(0, indexSec);
	} catch (e) {
		return '';
	}
}

/*
 function getAdvertId() {
 return null;
 }
 */

function getRedditId() {

	let userid = $('button#USER_DROPDOWN_ID').find('span._2BMnTatQ5gjKGK5OWROgaG');
	userid = userid[0].innerText;

	return userid;
	//return user_ID;
}


/**
 * Should get the postOwner e.g. adobe so we can go to user/adobe and get more info such as postOwnerImage
 * @param adRoot
 * @returns {null}
 */
function getOwner(adRoot) {
	let owner = null;
	const adType = $(adRoot).attr('data-reddit-intel-ad-type');
	try {
		if (adType === 'feed') {
			owner = $(adRoot).find('._2mHuuvyV9doV3zwbZPtIPG a._2tbHP6ZydRpjI44J3syuqC').first().text();
			if (owner.includes('/')) {
				owner = owner.split('/')[1];
			}
		} else {
		}
	} catch (err) {
		df('defaultErrorHandler', [err, true]);
	}
	if (!owner) return null;
	return owner;
}

function getTitle(adRoot) {
	const adType = $(adRoot).attr('data-reddit-intel-ad-type');
	if (adType === 'feed') {
		return $(adRoot).find('h3').text() || $(adRoot).find('h1').text() || 'No Title';
	}
}


function getAdText(adRoot) {
	let text = "";
	if ($(adRoot).find('div[data-testid*="-ad-supplementary-text"]').length > 0) {
		text = $(adRoot).find('div[data-testid*="-ad-supplementary-text"]').first().text();
	}
	return text;
}


function getAdUrl(adRoot) {
	let commentsUrl = 'https://reddit.com' + $(adRoot).find('a[data-click-id=comments]').attr('href');
	if ($(adRoot).find('a[data-click-id=comments]').length) {
		df('consoleLog', [commentsUrl]);
	} else {
		return `${window.location.href}`
	}

	return commentsUrl;
}

function getNewsfeedDescription(adRoot) {
	let adLinkURL = null;
	try {
		const adType = $(adRoot).attr('data-reddit-intel-ad-type');
		if (adType === 'feed') {
			adLinkURL = $(adRoot).find('a.styled-outbound-link').first();

			return adLinkURL.text().match(/^(?:https?:\/\/)?(?:[^@\/\n]+@)?(?:www\.)?([^:\/\n]+)/)[1];
		}

		// allow anyway if still null and attempts > 7
		if (parseInt($(adRoot).attr('data-reddit-intel-attempts')) >= sendDefaultAttempts) {
			adLinkURL = ''; // this will allow save
		}
		return adLinkURL;
	} catch (e) {
		return null;
	}
}

function getPageVerified() {
	return true;
}

function getCategory() {
	return 'No Category';
}

function getAdVideoUrlOriginal(adRoot) {

	const adType = $(adRoot).attr('data-reddit-intel-type');
	let image, retVal, video;
	if (adType === 'IMAGE') {
		image = $(adRoot).find('img[alt="Post image"]').first()[0];
		retVal = $(image).attr('src');
		return retVal;
	} else if (adType === 'VIDEO') {
		let retVal1;
		if($(adRoot).find('video._1EQJpXY7ExS04odI1YBBlj').length > 0){
			retVal1 = $(adRoot).find('video._1EQJpXY7ExS04odI1YBBlj').find('source').attr('src');
			retVal1 = getBetween(retVal1, 'https://v.redd.it/', '/');
		}
		else if($(adRoot).find('shreddit-player[preview]').length > 0){
			retVal1 = $(adRoot).find('shreddit-player[preview]').attr('src');
			retVal1 = getBetween(retVal1, 'https://v.redd.it/', '/');
		}
		if (!retVal1) {
			return null;
		}
		retVal1 = 'https://v.redd.it/' + retVal1 + '/DASH_96.mp4';
		return retVal1;
	}
}

function getAdVideoUrl(adRoot) {

	return $(adRoot).attr('data-reddit-intel-image_video_url_original');
}


function extractCount(text) {
	text = text.trim().toLowerCase();
	let value = 0;
	if (text !== '') {
		const re = new RegExp(/\d[km]/i);
		const matchResult = re.exec(text);
		if (matchResult) {
			if (text.includes('k')) {
				value = 1000 * parseFloat(text);//.replace('k', '.'));
			} else if (text.includes('m')) {
				value = 1000000 * parseFloat(text);//.replace('m', '.'));
			}
		} else {
			value = parseInt(text);
		}
	}
	return value;
}

function getLikesCount(adRoot) {

	let likesCount = -1;

	try {
		const adType = $(adRoot).attr('data-reddit-intel-ad-type');
		if (adType === 'feed') {
			const upVote = $(adRoot).find('button[data-click-id=upvote]').first();
			let likes = $(upVote).next()[0].innerText;
			likesCount = isNumber(likes) ? likes : transformCount(likes);
			if (likesCount <= 0 || likesCount == "Vote") return '0';
		}
	} catch (e) {
		df('defaultErrorHandler', [e, true]);
	}
	return likesCount;
}

function transformCount(count) {
	const charKilo = 'k';
	const charMega = 'm';
	const kilo = 1000;
	const mega = 1000000;

	if (count.includes(charKilo)) {
		return parseFloat(count) * kilo;
	}

	if (count.includes(charMega)) {
		return parseFloat(count) * mega;
	}

	return count;
}

const isNumber = function (str) {
	const pattern = /^\d+$/;
	return pattern.test(str);
};

function getSharesCount(adRoot) {
	const adType = $(adRoot).attr('data-reddit-intel-ad-type');
	if (adType === 'feed') {
		let sharesCount = -1; // because it might genuinely be zero
		try {
			let shares = $(adRoot).find('button[data-click-id=share]');
			if (typeof shares === 'undefined' || !shares || shares.length === 0) return null;
			let sharesCountString = $(shares).find('span')[0].innerText;
			sharesCount = extractCount(sharesCountString);
			sharesCount = (sharesCount !== -1 && !isNaN(sharesCount)) ? sharesCount : 0;
		} catch (error) {
			df('halt');
		}
		return (sharesCount !== -1 && !isNaN(sharesCount)) ? sharesCount : 0;
	} else if ($(adRoot).attr('data-reddit-intel-ad-type') === 'side') {

		return 0;
	}
}

function getCommentsCount(adRoot) {
	const adType = $(adRoot).attr('data-reddit-intel-ad-type');
	if (adType === 'feed') {
		let commentsCount = -1; // because it might genuinely be zero
		try {
			let comments = !($(adRoot).find('a[data-click-id=comments]').length) ?
				$(adRoot).find('._1UoeAeSRhOKSNdY_h3iS1O') : $(adRoot).find('a[data-click-id=comments]');
			if (typeof comments === 'undefined' || !comments || comments.length === 0) return null;
			let commentsCountString = $(comments).find('span')[0].innerText;
			commentsCount = extractCount(commentsCountString);
			commentsCount = (commentsCount !== -1 && !isNaN(commentsCount)) ? commentsCount : 0;
		} catch (error) {
			df('halt');
		}
		return (commentsCount !== -1 && !isNaN(commentsCount)) ? commentsCount : 0;
	} else if ($(adRoot).attr('data-reddit-intel-ad-type') === 'side') {

		return 0;
	}
}

function getPlatform() {
	return Platform;
}


function getDestinationUrl(adRoot) {

	let adLinkURL = null;
	try {
		const adType = $(adRoot).attr('data-reddit-intel-ad-type');
		if (adType === 'feed') {
			adLinkURL = $(adRoot).find('a.styled-outbound-link').first().attr('href');
		} else if ($(adRoot).attr('data-reddit-intel-ad-type') === 'side') {
		}
		// allow anyway if still null and attempts > 7
		if (!adLinkURL && parseInt($(adRoot).attr('data-reddit-intel-attempts')) >= sendDefaultAttempts) {
			adLinkURL = ''; // this will allow save
		}
		return adLinkURL;
	} catch (e) {
		//adLinkURL="";
		return null;
	}
}

function getCallActionType(adRoot) {
	let call_to_action = '';
	if ($(adRoot).find("._2pjSQOdNtYd1I2W0Z1Im8I ").length > 0) {
		call_to_action = $(adRoot).find("._2pjSQOdNtYd1I2W0Z1Im8I ").text();
	}
	return call_to_action;
}

function getLowerAdAge() {

	if (!birthday) {
		return '18';
	}
	return birthday.toString();
}

function getUpperAdAge() {
	return '65';
}

//function getPostOwnerImage(adRoot) {
//    if ($(adRoot).attr('data-reddit-intel-ad-type') === 'feed') {
//        return $(adRoot).find('img._s0').first().attr('src');
//    } else if ($(adRoot).attr('data-reddit-intel-ad-type') === 'side') {
//        return "";
//    }
//}

function getPostOwnerImage(adRoot) {

	const adType = $(adRoot).attr('data-reddit-intel-ad-type');
	const postOwner = $(adRoot).attr('data-reddit-intel-post_owner');
	if (adType === 'feed') {
		try {
			const ownerUrl = 'https://www.reddit.com/user/' + postOwner;
			let ownerImage = '';
			const reqJson = {
				async: true,
				crossDomain: false,
				url: ownerUrl,
				method: 'GET',
				headers: {
					'content-type': 'application/json',
					'cache-control': 'no-cache',
					'Accept': 'text/html'
				},
				data: { adRoot: adRoot },
				processData: false
			};
			(function (thisAdRoot) {
				$.ajax(reqJson).done(function (pageSource) {
					ownerImage = $(pageSource).find('img[alt="Profile icon"]').first().attr('src');
					$(thisAdRoot).attr('data-reddit-intel-post_owner_image', ownerImage);
				}).fail(function (error) {
					df('consoleLog', [`ajax fail: ${error}`]);
				});
			}(adRoot));
		} catch (error) {
			df('defaultErrorHandler', [error, true]);
		}
	}
	return null;
}

function getUserIp() {
	return !!geoData.userIP ? geoData.userIP : null;
}

function getUserCity() {
	return !!geoData.userCity ? geoData.userCity : null;
}

function getUserState() {
	return !!geoData.userState ? geoData.userState : null;
}

function getUserCountry() {
	return !!geoData.userCountry ? geoData.userCountry : null;
}

function getFirstSeen() {
	const d = new Date();
	return d.getTime();
}

function getLastSeen() {
	const d = new Date();
	return d.getTime();
}

let postDateBusy = false;

/**
 * The full accurate date can only be found by doing a mouseover the date indicator to bring up the tooltip
 * the tooltip appears as a div at the end of the body just for as long as the mouseover is active
 * Uses a timer to allow alternate threads and to give the tooltip time to appear
 * @param adRoot
 */
function getPostDate(adRoot) {
	// if ($(adRoot).attr('data-reddit-intel-post_date')) return;
	// if (postDateBusy) return;
	// postDateBusy = true;
	// // let adPostTime;
	// let postType = $(adRoot).attr('data-reddit-intel-ad-type');
	// if (postType === 'feed_video' || postType === 'feed_image') {
	//     let el = $(adRoot).find("a[data-click-id=timestamp]")[0];
	//     let event = document.createEvent('HTMLEvents');
	//     event.initEvent('mouseover', true, false);
	//     el.dispatchEvent(event);
	//     setTimeout(function (that) {
	//         let $postDate = $('body').find('div').last();
	//         let isoDate = $postDate[0].innerText;
	//         let postTime = +new Date(isoDate);
	//         $(that).attr('data-reddit-intel-post_date', postTime);
	//         postDateBusy = false;
	//     }, 500, adRoot);
	// } else {
	//     // todo side ads
	//     postDateBusy = false;
	// }

	const d = new Date();
	return d.getTime();
	/*
	 let updatedTime = adPostTime.split(";");
	 let adPostedTime = updatedTime[4];
	 adPostedTime = "tm" + adPostedTime;
	 adPostTime = getBetween(adPostedTime, "tm", ":");
	 */
	/*
	 } else if ($(adRoot).attr('data-reddit-intel-ad-type') === 'side') {
	 const d = new Date();
	 return d.getTime();
	 }
	 return adPostTime;

	 */
}

function getAdId(adRoot) {
	try {
		const href = $(adRoot).find('a[data-click-id="comments"]').attr('href');
		return getBetween(href || window.location.href, 'comments/', '/');
	} catch (err) {
		df('defaultErrorHandler', [err, true]);
	}
}

function getType(adRoot) {
	if ($(adRoot).attr('data-reddit-intel-ad-type').includes('feed')) {
		if ($(adRoot).find('shreddit-player').length > 0 || $(adRoot).find('video').length > 0) {
			return 'VIDEO';
		} else if ($(adRoot).find('img.ImageBox-image').length > 0) {
			return 'IMAGE';
		}
	}
}


function getPosition(adRoot) {
	if ($(adRoot).attr('data-reddit-intel-ad-type').includes('feed')) {
		return 'FEED';
	} else if ($(adRoot).attr('data-reddit-intel-ad-type') === 'side') {
		return 'SIDE'
	} else {
		return null;
	}
}


function getUndefined() {
	return 'Not implemented yet';
}


function hideOrShowAds() {
	if (scrollCounter % 10 === 0) {
		chrome.storage.local.get({ 'issponsored': 'OFF' }, function (result) {
			if (result.issponsored === 'OFF') {
				$('div[data-reddit-intel-triaged="not-sponsored"]').show();
			} else {
				$('div[data-reddit-intel-triaged="not-sponsored"]').hide();
			}
		});
	}
}

function getSource() {
	return 'desktop';
}

function getUserData() {
	if (user_ID && reddit_dtsg && composerId) return;
	try {
		const accountIcon = $('button#USER_DROPDOWN_ID').find('img[alt="Account icon"]');
		const username = $(accountIcon).next().find('span').first()[0];
		if (username) {
			user_ID = $(username)[0].innerText;
			reddit_dtsg = ' ';
			composerId = ' ';
		}
		df('consoleLog', [`username is ${user_ID}`, true]);

	} catch (err) {
		user_ID = 'not logged in';
		df('getUserData_NoUser', [err, true]);
	}
	if (user_ID !== undefined && user_ID !== '') {
		chrome.storage.local.get('userid', function (result) {
			const userid = result.userid;
			if (userid !== user_ID) {
				chrome.storage.local.set({ 'userid': user_ID });
			}
		});
	}
	return null;
}


function buildUpGeoData() {
	if (isProcessingGeoData) {
		return;
	}
	isProcessingGeoData = true;

	if (!geoData.userIP || !geoData.userCity || !geoData.userState || !geoData.userCountry) {
		if (!geoData.userIP) {
			const ourIP = "https://geolocation.poweradspy.com/";
			$.ajax({
				url: ourIP,
				type: "GET",
				async: true,
				success: function (IpResponse) {
					const ourIpResponse = JSON.parse(IpResponse);
					geoData.userIP = ourIpResponse.ip;
					geoData.userCity = ourIpResponse.cityName;
					geoData.userState = ourIpResponse.regionName;
					geoData.userCountry = ourIpResponse.countryName;
					geoData.lastUpdated = Date.now();
					chrome.storage.local.set({ "geoData": geoData });
					isProcessingGeoData = false;
				}
			});
		}
	}
}

function userDetails() {
}

function userAdPreferences() {
}

/**
 * data-reddit-intel-ad-type is set to feed_video, feed_image or side
 */
function checkForNewOld() {

	let countNot0 = 0, countNot1 = 0, countNot2 = 0;
	$('div.promotedlink:not([data-reddit-intel-triaged])').each(function () {
		countNot0++;
		if ($(this).parent().parent().find('iframe').length === 0) {
			if ($(this).find('button[data-click-id^=upvote]').length > 0) {
				// todo may try removing this again
				if (/promoted/i.test($(this).find('span').text())) {
					countNot1++;
					$(this)
						.attr('data-reddit-ad', 'yes')
						.attr('data-reddit-intel-triaged', 'sponsored')
						.addClass('reddit-intel-ad');
					if ($(this).find('video').length > 0) {
						$(this).attr('data-reddit-intel-ad-type', 'feed_video')
					} else {
						$(this).attr('data-reddit-intel-ad-type', 'feed_image')
					}
				} else {
					// if there's no iframe and no upvote button, we're looking at an ad that hasn't loaded yet so wait for another loop
					return null;
				}
			}
		} else {
			countNot2++;
			$(this).parent().parent()
				.attr('data-reddit-ad', 'no')
				.attr('data-reddit-intel-ad-type', 'side')
				.attr('data-reddit-intel-triaged', 'not-sponsored')
				.attr('data-reddit-intel-attempts', '48'); // so we don't clog up console
			// because we set the grandparent, need to flag this as well to stop it being continuously picked up
			$(this).attr('data-reddit-intel-triaged', 'not-sponsored');
		}
	});

	$('div.promotedlink:not([data-reddit-intel-triaged])').each(function () {
		if ($(this).parent().parent().find('iframe').length === 0) {
			if ($(this).find('button[data-click-id^=upvote]').length > 0) {
				// todo may try removing this again
				if ($(this).find('video._1EQJpXY7ExS04odI1YBBlj').length > 0) {
					$(this)
						.attr('data-reddit-ad', 'yes')
						.attr('data-reddit-intel-ad-type', 'feed_video')
						.attr('data-reddit-intel-triaged', 'sponsored')
						.addClass('reddit-intel-ad');
				}
			}
		}
	});

	$('div.Post:not([data-reddit-intel-triaged])').each(function () {
		$(this).attr('data-reddit-intel-triaged', 'not-sponsored').addClass('reddit-intel-ad');
	});
}
function checkForNew() {
	$('div[data-testid="post-container"]:not([data-reddit-intel-triaged])')
		.attr("data-reddit-intel-triaged", "no")
		.attr("data-reddit-ad", "yes")
		.attr("data-reddit-intel-ad-type", "feed")
		.addClass("reddit-intel-ad");
}

function triageItems() {
	// leaving function here but we do the triage as part of checking for new, it's easier and more reliable
	$("div.reddit-intel-ad[data-reddit-intel-triaged='no']").each(function () {
		try {
			if ($(this).find('span.V0WjfoF5BV7_qbExmbmeR').length > 0) {
				let sponsoredText = $(this).find('span.V0WjfoF5BV7_qbExmbmeR').text().toLowerCase();
				if (sponsoredText.includes('promoted')) {
					$(this).attr("data-reddit-intel-triaged", "sponsored");
				} else {
					$(this).attr("data-reddit-intel-triaged", "not-sponsored");
				}
			}
		} catch {

		}
	});
}

function extractDataFromItems() {

	// const startTime = Date.now();
	$('div.reddit-intel-ad[data-reddit-intel-triaged=\'sponsored\']:not([data-reddit-intel-parsed])').each(function () {


		let allFound = true;
		let debugPanel = '';

		let attempts = $(this).attr('data-reddit-intel-attempts');
		if (!attempts) {
			attempts = '1';
		} else {
			attempts = parseInt(attempts) + 1;
			if (attempts > 50) {
				$(this).attr('data-reddit-intel-parsed', 'incomplete');
			}
		}

		debugPanel += '<p class="save-status"></p>';

		$(this).attr('data-reddit-intel-attempts', attempts);
		debugPanel += `<p>attempts: ${attempts}</p>`;
		for (const [key, value] of Object.entries(requiredData)) {

			let attrValue = $(this).attr(value.attribute);
			if (attrValue === null || attrValue === undefined) {
				attrValue = value.method.apply(null, $(this));
			}

			if (attrValue !== null && attrValue !== undefined) {
				$(this).attr(value.attribute, `${attrValue}`);
				debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
			} else {
				//debugger;
				debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
				allFound = false;
			}
		}

		if (allFound) {
			$(this).attr('data-reddit-intel-parsed', 'complete'); // this means ad can be written
		}

		if ($('html').attr('reddit-intel-debug')) {
			if ($(this).find('div.reddit-intel-debug').length === 0) {
				$(this).append($('<div class="reddit-intel-debug" style="display: block"></div>'));
			}

			debugPanel += `<p>sponsoredClass: ${sponsoredClass}</p>`;
			$(this).find('div.reddit-intel-debug').first().html(debugPanel);
		}
	});
}

function getSponsoredAdCount() {
	$("div.reddit-intel-ad[data-reddit-intel-parsed=complete][data-reddit-intel-saved]:not([data-reddit-intel-count-updated])").each(function () {
		//$('div.reddit-intel-ad[data-reddit-intel-parsed]:not([data-reddit-intel-count-updated])').each(function () {
		const owner = $(this).attr('data-reddit-intel-post_owner') || 'dummy owner';
		// add attr but set to false otherwise another attempt might happen before the response from the first
		$(this).attr('data-reddit-intel-count-updated', false);
		if (owner) {
			let searchPostOwnerDataFeed = `{"post_owner": "${owner}"}`;

			const reqJson = {
				async: true,
				crossDomain: true,
				url: powerAdSpyRedditApi + 'postowner',
				method: 'POST',
				headers: {
					'content-type': 'application/json',
					'cache-control': 'no-cache'
				},
				processData: false,
				data: searchPostOwnerDataFeed
			};

			//const attachTo = $(this).find("div._5pcp").first();
			const attachTo = $(this).find('span._2oEYZXchPfHwcf9mTMGMg8').first();
			$.ajax(reqJson).done((function (pAttachTo, pOwner, adRoot) {
				return function (response) {
					try {
						const returnObj = JSON.parse(response);
						const adCount = returnObj.data.count;
						$(pAttachTo).append($('<a></a>')
							.attr('href', powerAdSpyLanderReddit + encodeURIComponent(pOwner))
							.attr('target', '_blank')
							.attr('class', 'ads-count')
							.text('Total Ads: ' + adCount)
						);
						$(adRoot).attr('data-reddit-intel-count-updated', true);
					} catch (err) {
						df('defaultErrorHandler', [err, true]);
					}
				};
			})(attachTo, owner, $(this)));

		}
	});
}

function toDataURL(url, thisAdData, adRoot, callback) {
	let xhr = new XMLHttpRequest();
	xhr.onload = function () {
		let reader = new FileReader();
		reader.onloadend = function () {
			callback(reader.result, thisAdData, adRoot);
		};
		reader.readAsDataURL(xhr.response);
	};
	xhr.open('GET', url);
	xhr.responseType = 'blob';
	xhr.send();
}

function saveSponsoredAds() {

	$('div.reddit-intel-ad[data-reddit-intel-parsed=complete]:not([data-reddit-intel-saved])').each(function () {
		// Set state
		const adRoot = this;
		let thisAdData = $.extend(true, {}, adData);
		for (const [key, value] of Object.entries(requiredData)) {
			thisAdData[key] = $(adRoot).attr(value.attribute);
		}
		const postData = JSON.stringify(thisAdData);
		$(adRoot).attr('data-reddit-intel-saved', 'await');
		$.ajax({
			'async': true,
			'crossDomain': true,
			'url': powerAdSpyRedditApi + 'redditAdsData',
			'method': 'POST',
			'headers': {
				'content-type': 'application/json',
				'cache-control': 'no-cache'
			},
			'processData': false,
			'data': postData
		})
			.done(function (response) {
				try {
					if (response.code == 200) {
						$(adRoot).attr('data-reddit-intel-saved', 'saved');
					} else {
						$(adRoot).attr('data-reddit-intel-triaged', 'completeforpages');
						$(adRoot).attr('data-reddit-intel-saved', 'success');
					}
				} catch {
				}
			}).fail(function () {
				$(adRoot).attr('data-reddit-intel-triaged', 'complete');
				$(adRoot).attr('data-reddit-intel-saved', 'failed');
			});


	});
}

function addEventListeners() {
	$('div.reddit-intel-ad[data-reddit-intel-triaged=\'sponsored\']:not([data-reddit-intel-events-added])').each(function () {
		$(this).attr('data-reddit-intel-events-added', 'true');
	});
}
