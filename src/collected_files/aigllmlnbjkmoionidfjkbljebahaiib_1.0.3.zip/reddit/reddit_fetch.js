
if (!window.divElement) {
  const divElement = document.createElement("div");
  window.divElement = divElement;
}

function onFetch(callback) {
  let logFetch = window.fetch;
  window.fetch = function (input, init) {
    return new Promise((resolve, reject) => {
      logFetch(input, init).then(function (response) {
        callback(response.clone());
        resolve(response);
      }, reject);
    });
  };
}


onFetch((response) => {
  // console.log(response);
  if (
    response.url.includes("home-feed") ||
    response.url.includes("svc/shreddit/feeds") ||
    response.url.includes("svc/shreddit/comments") ||
    response.url.includes("shreddit/community") 
  ) {
    response
      .clone() // Clone the response to create a new body stream
      .text()
      .then((res) => {
        // console.log(res)
        divElement.innerHTML = res;
        divElement.querySelectorAll("shreddit-ad-post").forEach((element) => {
          const adsData = htmlElementToObject(element);
          document.dispatchEvent(
            new CustomEvent("redditAds", {
              detail: {
                adsData,
              },
            })
          );
        });
      })
      .catch((error) => {
      });
  }
});

function htmlElementToObject(element) {
  const obj = {};
  obj.tagName = element.tagName.toLowerCase();

  // Convert attributes to object properties
  obj.attributes = {};
  for (let i = 0; i < element.attributes.length; i++) {
    const attribute = element.attributes[i];
    obj.attributes[attribute.name] = attribute.value;
  }

  // Convert non-empty text content to object property
  const textContent = element.textContent.trim();
  if (textContent !== "") {
    const textArray = textContent.split(/\s*\n\s*/).filter(Boolean);
    obj.textContent = {};
    textArray.forEach((text, index) => {
      obj.textContent[index] = text.trim();
    });
  }

  // Convert child elements to objects recursively
  obj.children = [];
  for (let i = 0; i < element.children.length; i++) {
    obj.children.push(htmlElementToObject(element.children[i]));
  }

  return obj;
}

// document.getElementById('divElement').querySelectorAll("shreddit-ad-post").forEach((element) => {
//   const adsData = htmlElementToObject(element);
//   console.log(adsData)
// })
// //*