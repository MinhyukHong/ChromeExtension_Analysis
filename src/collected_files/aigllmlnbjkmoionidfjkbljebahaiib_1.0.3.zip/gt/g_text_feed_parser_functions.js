/**
 * Only helping functions are in this file
 * Pluggin start from here
 * start function "Start()"
 */

let toptextadcount = 0;
let bottomtextadcount = 0;
let topshoppingadcount = 0;
let bottomshoppingadcount = 0;
let sideshoppingadcount = 0;
let isProcessingGeoData = false;
const sendDefaultAttempts = 7; // change this to < 9 to give up and send "" for not found items

function getVersion() {
  return version;
}

function base64ToHex(str) {
  const raw = atob(str);
  let result = "";
  for (let i = 0; i < raw.length; i++) {
    const hex = raw.charCodeAt(i).toString(16);
    result += hex.length === 2 ? hex : "0" + hex;
  }
  return result;
}

function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}

function getsource() {
  return "desktop";
}

function getnetwork() {
  return "GoogleText";
}

function getpostownerimage(adRoot) {
  let ownerImage = "";
  if ($(adRoot).find(".v5yQqb img.XNo5Ab").length > 0) {
    let ownerImagePath = $(adRoot).find(".v5yQqb img.XNo5Ab")[0];
    ownerImage = $(ownerImagePath).attr("src");
  }
  return ownerImage;
}

function gettargettext() {
  return null;
}

function gettargetpage() {
  let targetPage = "";
  if (document.getElementsByClassName("SJajHc").length > 0) {
    targetPage = document.getElementsByClassName("SJajHc")[0].innerText;
  }

  if (
    targetPage == "" &&
    document.getElementsByClassName("YyVfkd").length > 0
  ) {
    targetPage = document.getElementsByClassName("YyVfkd")[0].innerText;
  }

  if (targetPage == "" && document.getElementsByClassName("cur").length > 0) {
    targetPage = document.getElementsByClassName("cur")[0].innerText;
  }
  return targetPage;
}

function getAdImage(adRoot) {
  let adimage = null;
  if (
    $(adRoot).attr("data-fb-intel-ad-type") === "feed" ||
    $(adRoot).attr("data-fb-intel-ad-type-organic") === "organic"
  ) {
    adimage = "";
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find("img").length == 1
  ) {
    adimage = $(adRoot).find("img")[0].currentSrc;
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find("img").length > 1
  ) {
    adimage = $(adRoot).find("img")[1].currentSrc;
  }
  return adimage?.includes('gif')? null: adimage;
}

function getAdGTempUrl(adRoot) {
  let g_url = null;
  if (
    $(adRoot).attr("data-fb-intel-ad-type") === "feed" &&
    $(adRoot).find("a").length > 0
  ) {
    //g_url = adLinkURL = $(adRoot).find("a")[0].href;
    //g_url = adLinkURL = $(adRoot).find("a").attr("data-rw");
    g_url = "";
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).attr("data-fb-intel-ad-type-organic") === "organic"
  ) {
    g_url = $(adRoot).find("a")[0].href;
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".pla-unit-title").find("a").length > 0
  ) {
    g_url = $(adRoot).find(".pla-unit-title").find("a")[0].href;
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".plantl").length > 1
  ) {
    g_url = $(adRoot).find(".plantl")[2].href;
  }else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".KZmu8e").find("a").length > 0
  ) {
    g_url =$(adRoot).find(".KZmu8e").find("a")[0].href;
  }else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".pla-unit").find("a").length > 0
  ) {
    g_url =$(adRoot).find(".pla-unit").find("a")[0].href;
  }
  return g_url||"";
  
}

function getOwnerOld(adRoot) {
  let owner = null;
  if (
    $(adRoot).attr("data-fb-intel-ad-type") === "feed" &&
    //$(adRoot).find("cite").length > 0      //old
    $(adRoot).find(".d8lRkd .x2VHCd").length > 0
  ) {
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find("cite").length > 0
  ) {
    owner = $(adRoot).find(".iUh30")[0].innerText;
    var postowner = owner;
    if (postowner.includes(".")) {
      var tempstr = postowner.split(".");
      if (tempstr.length > 2) {
        tempstr[0] = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        tempstr[1] = tempstr[1]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        if (tempstr[0].length > tempstr[1].length) {
          owner = tempstr[0];
        } else {
          owner = tempstr[1];
        }
      } else if (tempstr.length == 2) {
        if (tempstr[0].includes("http")) {
          owner = tempstr[0]
            .replace("https://", "")
            .replace("http://", "")
            .replace("www", "");
        } else {
          owner = tempstr[0];
        }
      }
    }
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".LbUacb").length > 0
  ) {
    owner = $(adRoot).find(".LbUacb")[0].innerText;
    var postowner = owner;
    //postowner = postowner.replace('http://','').replace('https://','').replace('www.','');
    if (postowner.includes(".")) {
      var tempstr = postowner.split(".");
      if (tempstr.length > 2) {
        tempstr[0] = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        tempstr[1] = tempstr[1]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        if (tempstr[0].length > tempstr[1].length) {
          owner = tempstr[0];
        } else {
          owner = tempstr[1];
        }
      } else if (tempstr.length == 2) {
        if (tempstr[0].includes("http")) {
          owner = tempstr[0]
            .replace("https://", "")
            .replace("http://", "")
            .replace("www", "");
        } else {
          owner = tempstr[0];
        }
      }
    }
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".Ndt4Qb").length > 0
  ) {
    owner = $(adRoot).find(".Ndt4Qb")[0].innerText;
    var postowner = owner;
    //postowner = postowner.replace('http://','').replace('https://','').replace('www.','');
    if (postowner.includes(".")) {
      var tempstr = postowner.split(".");
      if (tempstr.length > 2) {
        tempstr[0] = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        tempstr[1] = tempstr[1]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        if (tempstr[0].length > tempstr[1].length) {
          owner = tempstr[0];
        } else {
          owner = tempstr[1];
        }
      } else if (tempstr.length == 2) {
        if (tempstr[0].includes("http")) {
          owner = tempstr[0]
            .replace("https://", "")
            .replace("http://", "")
            .replace("www", "");
        } else {
          owner = tempstr[0];
        }
      }
    }
  }
  return owner||"";
}

function getOwner(adRoot) {
  let owner = null;
  if (
    $(adRoot).attr("data-fb-intel-ad-type") === "feed" &&
    $(adRoot).find(".yUTMj span.OSrXXb").length > 0
  ) {
    owner = $(adRoot).find(".yUTMj span.OSrXXb").first().text();
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find("div span.VuuXrf").length > 0
  ) {
    owner = $(adRoot).find("div span.VuuXrf").first().text();
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".LbUacb").length > 0
  ) {
    owner = $(adRoot).find(".LbUacb")[0].innerText;
    let postowner = owner;
    if (postowner.includes(".")) {
      var tempstr = postowner.split(".");
      if (tempstr.length > 2) {
        tempstr[0] = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        tempstr[1] = tempstr[1]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        if (tempstr[0].length > tempstr[1].length) {
          owner = tempstr[0];
        } else {
          owner = tempstr[1];
        }
      } else if (tempstr.length == 2) {
        if (tempstr[0].includes("http")) {
          owner = tempstr[0]
            .replace("https://", "")
            .replace("http://", "")
            .replace("www", "");
        } else {
          owner = tempstr[0];
        }
      }
    }
  }else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".sh-np__seller-container").length > 0
  ) {
    owner = $(adRoot).find(".sh-np__seller-container")[0].innerText;
    let postowner = owner;
    if (postowner.includes(".")) {
      var tempstr = postowner.split(".");
      if (tempstr.length > 2) {
        tempstr[0] = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        tempstr[1] = tempstr[1]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        if (tempstr[0].length > tempstr[1].length) {
          owner = tempstr[0];
        } else {
          owner = tempstr[1];
        }
      } else if (tempstr.length == 2) {
        if (tempstr[0].includes("http")) {
          owner = tempstr[0]
            .replace("https://", "")
            .replace("http://", "")
            .replace("www", "");
        } else {
          owner = tempstr[0];
        }
      }
    }
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".kaNpvd.nLaBQd").length > 0
  ) {
    owner = $(adRoot).find(".kaNpvd.nLaBQd")[0].innerText;
    let postowner = owner;
    if (postowner.includes(".")) {
      var tempstr = postowner.split(".");
      if (tempstr.length > 2) {
        tempstr[0] = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        tempstr[1] = tempstr[1]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
        if (tempstr[0].length > tempstr[1].length) {
          owner = tempstr[0];
        } else {
          owner = tempstr[1];
        }
      } else if (tempstr.length == 2) {
        if (tempstr[0].includes("http")) {
          owner = tempstr[0]
            .replace("https://", "")
            .replace("http://", "")
            .replace("www", "");
        } else {
          owner = tempstr[0];
        }
      }
    }
  }
  return owner||"";
  
}

//Title , addId, Target KeyWord, Target Page, Positions
function getTitle(adRoot) {
  let title = null;
  let adPostId;
  let trgettext = null;
  // let trgetpage = null;
  if (
    $(adRoot).attr("data-fb-intel-ad-type") === "feed" &&
    //$(adRoot).find("h3").length > 0    //old code
    $(adRoot).find(".CCgQ5").length > 0
  ) {
    //title = $(adRoot).find("h3")[0].innerText;   old code
    title = $(adRoot).find(".CCgQ5")[0].innerText;
    if ($(adRoot).attr("data-fb-intel-ad-type") === "feed") {
      adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
      //adPostId = hashCode(title);
      $(adRoot).attr("data-fb-intel-ad_id", adPostId);
      var search = $("[aria-label=Search]");
      if (search.length > 0) {
        var searchText = search[0].defaultValue;
        if (trgettext != "") {
          $(adRoot).attr("data-fb-intel-target_keyword", searchText);
        }
      }
    }
    if ($(adRoot)[0].parentNode.parentNode.parentNode.id == "tvcap") {
      toptextadcount = toptextadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
      $(adRoot).attr("data-fb-intel-ad_number_position", toptextadcount);
    } else if (
      $(adRoot)[0].parentNode.parentNode.parentNode.id == "bottomads"
    ) {
      bottomtextadcount = bottomtextadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "BOTTOM");
      $(adRoot).attr("data-fb-intel-ad_number_position", bottomtextadcount);
    } else {
      toptextadcount = toptextadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
      $(adRoot).attr("data-fb-intel-ad_number_position", toptextadcount);
    }
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).attr("data-fb-intel-ad-type-organic") === "organic" &&
    $(adRoot).find("h3").length > 0
  ) {
    title = $(adRoot).find("h3")[0].innerText;
    title = title.replace(/<[^>]*>/g, "").replace("\n", "");
    adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
    //adPostId = hashCode(title);
    $(adRoot).attr("data-fb-intel-ad_id", adPostId);

    trgettext = document.getElementsByName("q")[0].value; //Vikash
    if (trgettext != "")
      $(adRoot).attr("data-fb-intel-target_keyword", trgettext);

    toptextadcount = toptextadcount + 1;
    $(adRoot).attr("data-fb-intel-ad_position", "FEED");
    $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
    $(adRoot).attr("data-fb-intel-ad_number_position", toptextadcount);
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".pla-unit-title").length > 0
  ) {
    title = $(adRoot).find(".pla-unit-title")[0].innerText;
    title = title.replace(/<[^>]*>/g, "").replace("\n", "");
    if ($(adRoot).attr("data-fb-intel-ad-type") === "shopping") {
      adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
      //adPostId = hashCode(title);
      $(adRoot).attr("data-fb-intel-ad_id", adPostId);
      // trgettext = document.getElementById('lst-ib').value;
      trgettext = document.getElementsByName("q")[0].value; //Vikash
      if (trgettext != "") {
        $(adRoot).attr("data-fb-intel-target_keyword", trgettext);
      }
    }
    if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.id ==
      "tvcap"
    ) {
      topshoppingadcount = topshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
      $(adRoot).attr("data-fb-intel-ad_number_position", topshoppingadcount);
    } else if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.id ==
      "bottomads"
    ) {
      bottomshoppingadcount = bottomshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "BOTTOM");
      $(adRoot).attr("data-fb-intel-ad_number_position", bottomshoppingadcount);
    } else if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.id == "rcnt"
    ) {
      sideshoppingadcount = sideshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "SIDE");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "");
      $(adRoot).attr("data-fb-intel-ad_number_position", sideshoppingadcount);
    } else {
      topshoppingadcount = topshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
      $(adRoot).attr("data-fb-intel-ad_number_position", topshoppingadcount);
    }
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".plantl").length > 0
  ) {
    // debugger;

    title = $(adRoot).find(".plantl")[2].innerText;
    title = title.replace(/<[^>]*>/g, "").replace("\n", "");
    adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
    //adPostId = hashCode(title);
    if (adPostId < 0) adPostId *= -1;
    $(adRoot).attr("data-fb-intel-ad_id", adPostId);
    var search = $("[name=q]");
    if (search.length > 0) {
      var searchText = search[0].defaultValue;
      if (trgettext != "") {
        $(adRoot).attr("data-fb-intel-target_keyword", searchText);
      }
    }
    toptextadcount = toptextadcount + 1;
    $(adRoot).attr("data-fb-intel-ad_position", "SIDE");
    $(adRoot).attr("data-fb-intel-ad_sub_position", "");
    $(adRoot).attr("data-fb-intel-ad_number_position", toptextadcount);
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".sh-np__product-title").length > 0
  ) {
    title = $(adRoot).find(".sh-np__product-title")[0].innerText;
    title = title.replace(/<[^>]*>/g, "").replace("\n", "");
    if ($(adRoot).attr("data-fb-intel-ad-type") === "shopping") {
      adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
      $(adRoot).attr("data-fb-intel-ad_id", adPostId);
      trgettext = document.getElementsByName("q")[0].value; //TAEGET TEXT
      if (trgettext != "") {
        $(adRoot).attr("data-fb-intel-target_keyword", trgettext);
      }
    }
    if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.id ==
      "tvcap"
    ) {
      topshoppingadcount = topshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
      $(adRoot).attr("data-fb-intel-ad_number_position", topshoppingadcount);
    } else if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.id ==
      "bottomads"
    ) {
      bottomshoppingadcount = bottomshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "BOTTOM");
      $(adRoot).attr("data-fb-intel-ad_number_position", bottomshoppingadcount);
    } else if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.id == "rcnt"
    ) {
      sideshoppingadcount = sideshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "SIDE");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "");
      $(adRoot).attr("data-fb-intel-ad_number_position", sideshoppingadcount);
    } else {
      topshoppingadcount = topshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
      $(adRoot).attr("data-fb-intel-ad_number_position", topshoppingadcount);
    }
  }
  //
  else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".iKMEte.X7oSNe").length > 0
  ) {
    title = $(adRoot).find(".iKMEte.X7oSNe")[0].innerText;
    title = title.replace(/<[^>]*>/g, "").replace("\n", "");
    if ($(adRoot).attr("data-fb-intel-ad-type") === "shopping") {
      adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
      $(adRoot).attr("data-fb-intel-ad_id", adPostId);
      trgettext = document.getElementsByName("q")[0].value; //TAEGET TEXT
      if (trgettext != "") {
        $(adRoot).attr("data-fb-intel-target_keyword", trgettext);
      }
    }
    if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.id ==
      "tvcap"
    ) {
      topshoppingadcount = topshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
      $(adRoot).attr("data-fb-intel-ad_number_position", topshoppingadcount);
    } else if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.id ==
      "bottomads"
    ) {
      bottomshoppingadcount = bottomshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "BOTTOM");
      $(adRoot).attr("data-fb-intel-ad_number_position", bottomshoppingadcount);
    } else if (
      $(adRoot)[0].parentNode.parentNode.parentNode.parentNode.parentNode
        .parentNode.parentNode.parentNode.parentNode.parentNode.id == "rcnt"
    ) {
      sideshoppingadcount = sideshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "SIDE");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "");
      $(adRoot).attr("data-fb-intel-ad_number_position", sideshoppingadcount);
    } else {
      topshoppingadcount = topshoppingadcount + 1;
      $(adRoot).attr("data-fb-intel-ad_position", "FEED");
      $(adRoot).attr("data-fb-intel-ad_sub_position", "TOP");
      $(adRoot).attr("data-fb-intel-ad_number_position", topshoppingadcount);
    }
  }
  return title||"";
}
let insertTextCount = 0;
function getAdText(adRoot) {
  //
  //if (enableDebugger)
  let smallDescription = null;
  if (
    $(adRoot).attr("data-fb-intel-ad-type") === "feed" &&
    $(adRoot).find(".d8lRkd .x2VHCd").length > 0
  ) {
    smallDescription = $(adRoot).find(".d8lRkd .x2VHCd")[0].innerText;
    smallDescription = smallDescription
      .replace(/<[^>]*>/g, "")
      .replace("\n", "");
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).attr("data-fb-intel-ad-type-organic") === "organic" &&
    $(adRoot).find(".byrV5b cite.cHaqb").length > 0
  ) {
    smallDescription = $(adRoot).find(".byrV5b cite.cHaqb")[0].innerText;
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".T4OwTb .e10twf").length > 0
  ) {
    smallDescription = $(adRoot).find(".T4OwTb .e10twf")[0].innerText;
    smallDescription = smallDescription.replace(/<[^>]*>/g, "");
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".plantl").length > 0
  ) {
    smallDescription = $(adRoot).find(".plantl")[2].innerText;
    smallDescription = smallDescription
      .replace(/<[^>]*>/g, "")
      .replace("\n", "");
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".T14wmb .translate-content").length > 0
  ) {
    smallDescription = $(adRoot).find(".T14wmb .translate-content")[0].innerText;
    smallDescription = smallDescription.replace(/<[^>]*>/g, "");
  }
  //div.t3Ss7.X7oSNe
  else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find("div.t3Ss7.X7oSNe").length > 0
  ) {
    smallDescription = $(adRoot).find("div.t3Ss7.X7oSNe")[0].innerText;
    smallDescription = smallDescription.replace(/<[^>]*>/g, "");
  }
  return smallDescription||"";
}

function getNewsfeedDescription(adRoot) {
  let newsfeedDescription = null;
  let firstnewsfeedDescription = null;
  let secondnewsfeedDescription = null;
  let thirdnewsfeedDescription = null;
  let fourthnewsfeedDescription = null;

  if (
    $(adRoot).attr("data-fb-intel-ad-type") === "feed" &&
    $(adRoot).find('div[class="Va3FIb r025kc lVm3ye"]').length > 0
  ) {
    newsfeedDescription = $(adRoot).find('div[class="Va3FIb r025kc lVm3ye"]').text();
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).attr("data-fb-intel-ad-type-organic") === "organic" &&
    $(adRoot).find("div.s").length > 0
  ) {
    newsfeedDescription = $(adRoot).find("div.s")[0].innerText;
    newsfeedDescription = newsfeedDescription.replace(/<[^>]*>/g, "");
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).attr("data-fb-intel-ad-type-organic") === "organic" &&
    $(adRoot).find("div.VwiC3b.yXK7lf").length > 0
  ) {
    newsfeedDescription = $(adRoot).find("div.VwiC3b.yXK7lf")[0].innerText;
    newsfeedDescription = newsfeedDescription.replace(/<[^>]*>/g, "");
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".LbUacb").length > 0
  ) {
    newsfeedDescription = $(adRoot).find(".LbUacb")[0].innerText;
    if ($(adRoot).find(".Am8Kud").length > 0) {
      firstnewsfeedDescription = $(adRoot).find(".Am8Kud")[0].innerText;
      //console.log("Extra feeds description---------   "+tempnewsfeedDescription);
      if (firstnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + firstnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".placc").length > 0) {
      secondnewsfeedDescription = $(adRoot).find(".placc")[0].innerText;
      //console.log("Extra feeds description---------   "+tempnewsfeedDescription);
      if (secondnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + secondnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".xEKYJc").length > 0) {
      thirdnewsfeedDescription = $(adRoot).find(".xEKYJc")[0].defaultValue;
      //console.log("Extra feeds description---------   "+tempnewsfeedDescription);
      if (thirdnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + thirdnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".goog-inline-block").length > 0) {
      fourthnewsfeedDescription =
        $(adRoot).find(".goog-inline-block")[0].innerText;
      //console.log("Extra feeds description---------   "+tempnewsfeedDescription);
      if (fourthnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + fourthnewsfeedDescription;
      }
    }
    newsfeedDescription = newsfeedDescription
      .replace(/<[^>]*>/g, "")
      .replace("\n", "");
  } else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".Ndt4Qb").length > 0
  ) {
    newsfeedDescription = $(adRoot).find(".Ndt4Qb")[0].innerText;
  }else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".sh-np__seller-container").length > 0
  ) {
    newsfeedDescription = $(adRoot).find(".sh-np__seller-container")[0].innerText;
    if ($(adRoot).find(".Am8Kud").length > 0) {
      firstnewsfeedDescription = $(adRoot).find(".Am8Kud")[0].innerText;
      if (firstnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + firstnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".placc").length > 0) {
      secondnewsfeedDescription = $(adRoot).find(".placc")[0].innerText;
      if (secondnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + secondnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".xEKYJc").length > 0) {
      thirdnewsfeedDescription = $(adRoot).find(".xEKYJc")[0].defaultValue;
      if (thirdnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + thirdnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".goog-inline-block").length > 0) {
      fourthnewsfeedDescription =
        $(adRoot).find(".goog-inline-block")[0].innerText;
      if (fourthnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + fourthnewsfeedDescription;
      }
    }
    newsfeedDescription = newsfeedDescription
      .replace(/<[^>]*>/g, "")
      .replace("\n", "");
  }
  //.kaNpvd.X7oSNe
  else if (
    $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
    $(adRoot).find(".kaNpvd.X7oSNe").length > 0
  ) {
    newsfeedDescription = $(adRoot).find(".kaNpvd.X7oSNe")[0].innerText;
    if ($(adRoot).find(".Am8Kud").length > 0) {
      firstnewsfeedDescription = $(adRoot).find(".Am8Kud")[0].innerText;
      if (firstnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + firstnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".placc").length > 0) {
      secondnewsfeedDescription = $(adRoot).find(".placc")[0].innerText;
      if (secondnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + secondnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".xEKYJc").length > 0) {
      thirdnewsfeedDescription = $(adRoot).find(".xEKYJc")[0].defaultValue;
      if (thirdnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + thirdnewsfeedDescription + " ";
      }
    }
    if ($(adRoot).find(".goog-inline-block").length > 0) {
      fourthnewsfeedDescription =
        $(adRoot).find(".goog-inline-block")[0].innerText;
      if (fourthnewsfeedDescription != "") {
        newsfeedDescription =
          newsfeedDescription + " " + fourthnewsfeedDescription;
      }
    }
    newsfeedDescription = newsfeedDescription
      .replace(/<[^>]*>/g, "")
      .replace("\n", "");
  }

  return newsfeedDescription||"";
}

function getPlatform() {
  return Platform;
}

function getDestinationUrl(adRoot) {
  let adLinkURL = null;
  try {
    if ($(adRoot).attr("data-fb-intel-ad-type")) {
      //adLinkURL = $(adRoot).find("a")[1].href;
      adLinkURL = $(adRoot).find("a")[0].href;
    } else if (
      $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
      $(adRoot).attr("data-fb-intel-ad-type-organic") === "organic"
    ) {
      adLinkURL = $(adRoot).find("a")[0].href;
    } else if (
      $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
      $(adRoot).find(".pla-unit-title").find("a").length > 1
    ) {
      adLinkURL = $(adRoot).find(".pla-unit-title").find("a")[1].href;
    } else if (
      $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
      $(adRoot).find(".plantl").length > 1
    ) {
      adLinkURL = $(adRoot).find(".plantl")[2].href;
    } else if (
      $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
      $(adRoot).find(".KZmu8e").find("a").length > 1
    ) {
      adLinkURL ="https://www.google.com"+ $(adRoot).find(".KZmu8e").find("a")[0].href;
    }
    //
    else if (
      $(adRoot).attr("data-fb-intel-ad-type") === "shopping" &&
      $(adRoot).find(".jCaeMe.nMN3Nd").find("a").length > 1
    ) {
      adLinkURL =$(adRoot).find(".jCaeMe.nMN3Nd").find("a")[0].href;
    }
  } catch (e) {
    return adLinkURL;
  }

  if (
    $(adRoot).attr("data-fb-intel-g_temp_url") &&
    $(adRoot).attr("data-fb-intel-g_temp_url") === adLinkURL &&
    $(adRoot).find(".rc>.r a").length > 0
  ) {
    adLinkURL = $(adRoot).find(".rc>.r a")[0].href;
  }

  return adLinkURL;
}

function getUserIp() {
  return !!GooglegeoData.userIP ? GooglegeoData.userIP : null;
}

function getUserCity() {
  return !!GooglegeoData.userCity ? GooglegeoData.userCity : null;
}

function getUserState() {
  return !!GooglegeoData.userState ? GooglegeoData.userState : null;
}

function getUserCountry() {
  return !!GooglegeoData.userCountry ? GooglegeoData.userCountry : null;
}

function getFirstSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}

function getLastSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}

function getPostDate(adRoot) {
  let adPostTime;
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  adPostTime = parseInt(myDate);
  return adPostTime;
}

function getAdId(adRoot) {
  return null;
}

function getType(adRoot) {
  if ($(adRoot).attr("data-fb-intel-ad-type") === "feed") {
    return "TEXT";
  } else if ($(adRoot).attr("data-fb-intel-ad-type-organic") === "organic") {
    return "ORGANIC SEARCH";
  } else if ($(adRoot).attr("data-fb-intel-ad-type") === "shopping") {
    return "IMAGE";
  }
}

async function getScreenshot(adRoot) {
  if (adRoot) {
    const canvas = await html2canvas(adRoot);
    const base64Image = canvas.toDataURL();
    $(adRoot).attr("data-fb-intel-screenshot", base64Image);
  }
}
function getPosition(adRoot) {
  return null;
}

function getsubPosition(adRoot) {
  return null;
}

function getnumberPosition(adRoot) {
  return null;
}

function buildUpGeoData() {
  if (isProcessingGeoData) {
    return;
  }
  isProcessingGeoData = true;
  if (
    !GooglegeoData.userIP ||
    !GooglegeoData.userCity ||
    !GooglegeoData.userState ||
    !GooglegeoData.userCountry
  ) {
    if (!GooglegeoData.userIP || !GooglegeoData.userCity) {
      const ourIP = "https://geolocation.poweradspy.com/";
      $.ajax({
        url: ourIP,
        type: "GET",
        crossDomain: true,
        dataType: "json",
        async: true,
        success: function (ourIpResponse) {
          GooglegeoData.userIP = ourIpResponse.ip;
          GooglegeoData.userCity = ourIpResponse.cityName;
          GooglegeoData.userState = ourIpResponse.regionName;
          GooglegeoData.userCountry = ourIpResponse.countryName;
          GooglegeoData.lastUpdated = Date.now();
          chrome.storage.local.set({ GooglegeoData: GooglegeoData });
          isProcessingGeoData = false;
        },
      });
    }
  }
}

function checkForNew() {
  try {
    let liAds = document.querySelector("li.ads-fr");
    let divAds = document.querySelector("div.uEierd");
    let divTextAds = document.querySelector("div.pla-unit-container");
    let divsideAds = document.querySelector("div.ptJHdc.mnr-c");
    let divimagesideAds = document.querySelector("div.twpSFc.mnr-c");
    let divimageshoppingAds = document.querySelectorAll(".KZmu8e");
    let divimagesImagesAds = document.querySelectorAll(".jCaeMe.nMN3Nd");//IMAGES

    //div.classList.contains('secondary');
    // debugger;
    //$("li.ads-ad:not([data-fb-intel-triaged])")
    if (
      liAds !== null ||
      divAds !== null ||
      divTextAds !== null ||
      divsideAds !== null ||
      divimagesideAds !== null ||
      divimageshoppingAds !== null ||
      divimagesImagesAds !==null
    ) {
      $("li.ads-fr:not([data-fb-intel-triaged])") //checking text ads
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "feed")
        .addClass("fb-intel-ad");

      $("div.uEierd:not([data-fb-intel-triaged])") //checking text ads
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "feed")
        .addClass("fb-intel-ad");

      $("div.pla-unit-container:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .addClass("fb-intel-ad");

      //for side ads
      // $("div.twpSFc.mnr-c:not([data-fb-intel-triaged])")
      // $("div.TxZWcc>.mnr-c:not([data-fb-intel-triaged])")
      $("div.ptJHdc.mnr-c:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "shopping")
        .addClass("fb-intel-ad");

      $("div.twpSFc.mnr-c:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "shopping")
        .addClass("fb-intel-ad");

      // For Google organic search (not ad, actual results)
      $("div.g:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "shopping")
        .attr("data-fb-intel-ad-type-organic", "organic")
        .addClass("fb-intel-ad");

         //shopping ads
         $(".KZmu8e:not([data-fb-intel-triaged])") //checking shopping ads
         .attr("data-fb-intel-triaged", "no")
         .attr("data-fb-ad", "yes")
         .attr("data-fb-intel-ad-type", "shopping")
         .addClass("fb-intel-ad");
 
          //From IMAGES ads
          $(".jCaeMe.nMN3Nd:not([data-fb-intel-triaged])") //checking Images ads
          .attr("data-fb-intel-triaged", "no")
          .attr("data-fb-ad", "yes")
          .attr("data-fb-intel-ad-type", "shopping")
          .addClass("fb-intel-ad");
    }
  } catch {}
}

function triageItems() {
  // //
  const startTime = Date.now();
  if (sponsoredClass) {
    $(
      "li.fb-intel-ad[data-fb-intel-triaged='no'], li.fb-intel-ad[data-fb-intel-triaged='not-sponsored']"
    ).each(function () {
      let sponsoredLinkCount = "";
      //console.log($(this).find('.Z98Wse').length);
      if (
        $(this).find(".Z98Wse").length > 0 ||
        $(this).find(".VqFMTc").length > 0
      ) {
        try {
          sponsoredLinkCount = $(this).find(".Z98Wse")[0].innerText;
        } catch (error) {}

        try {
          if (!sponsoredLinkCount) {
            sponsoredLinkCount = $(this).find(".VqFMTc")[0].innerText;
          }
        } catch (error) {}

        // console.log('========', sponsoredClassShopping, '++++++++', sponsoredClass, '_______', sponsoredLinkCount);

        if (sponsoredLinkCount.includes(sponsoredClass)) {
          //if (sponsoredLinkCount != sponsoredClass) {
          $(this).attr("data-fb-intel-triaged", "sponsored");
        } else if (sponsoredLinkCount == sponsoredClass) {
          $(this).attr("data-fb-intel-triaged", "not-sponsored");
        }
      }
    });
  }

  //new code
  if (sponsoredClass) {
    $(
      "div.fb-intel-ad[data-fb-intel-triaged='no'], div.fb-intel-ad[data-fb-intel-triaged='not-sponsored']"
    ).each(function () {
      let sponsoredLinkCount = "";
      //console.log($(this).find('.Z98Wse').length);
      if (
        $(this).find(".CnP9N").length > 0 ||
        $(this).find(".VqFMTc").length > 0 ||
        $(this).find("span.U3A9Ac.qV8iec").length > 0 ||
        $(this).find("span.c0oU4c.U3A9Ac.irmCpc").length > 0 || 
        $(this).find("span.PsRem").length > 0
      ) {
        try {
          sponsoredLinkCount = $(this).find(".CnP9N")[0].innerText;
        } catch (error) {}

        try {
          if (!sponsoredLinkCount) {
            sponsoredLinkCount = $(this).find(".U3A9Ac.qV8iec")[0].innerText;
          }
        } catch (error) {}

        try {
          if (!sponsoredLinkCount) {
            sponsoredLinkCount =
              $(this).find("span.U3A9Ac.qV8iec")[0].innerText;
          }
        } catch {}

        try {
          if (!sponsoredLinkCount) {
            sponsoredLinkCount =
              $(this).find("span.c0oU4c.U3A9Ac.irmCpc").innerText;
          }
        } catch {}

        try {
          if (!sponsoredLinkCount) {
            sponsoredLinkCount =
              $(this).find("span.PsRem").innerText;
          }
        } catch {}

        if (sponsoredLinkCount.includes("Sponsored")) {
          //if (sponsoredLinkCount != sponsoredClass) {
          $(this).attr("data-fb-intel-triaged", "sponsored");
        } else if (sponsoredLinkCount == sponsoredClass) {
          $(this).attr("data-fb-intel-triaged", "not-sponsored");
        }

        // console.log('========', sponsoredClassShopping, '++++++++', sponsoredClass, '_______', sponsoredLinkCount);

        if (sponsoredLinkCount.includes(sponsoredClass)) {
          //if (sponsoredLinkCount != sponsoredClass) {
          $(this).attr("data-fb-intel-triaged", "sponsored");
        } else if (sponsoredLinkCount == sponsoredClass) {
          $(this).attr("data-fb-intel-triaged", "not-sponsored");
        }
      }
    });
  }
  //new code
  if (sponsoredClassShopping) {
    $(
      "div.fb-intel-ad[data-fb-intel-triaged='no'], div.fb-intel-ad[data-fb-intel-triaged='not-sponsored']"
    ).each(function () {
      $(this).attr("data-fb-intel-ad-type", "shopping");
      $(this).attr("data-fb-intel-triaged", "sponsored");
      //document.getElementsByClassName('C4eCVc')[0].parentNode.id
      //$(this).attr("data-fb-intel-triaged", "sponsored");
    });
  }

  const delta = Date.now() - startTime;
  //  chrome.runtime.sendMessage(null, {"triageTime": delta});
}

function extractDataFromItems() {
  const startTime = Date.now();

  $(
    "li.fb-intel-ad[data-fb-intel-triaged='sponsored']:not([data-fb-intel-parsed])"
  ).each(function () {
    let allFound = true;
    let debugPanel = "";

    let attempts = $(this).attr("data-fb-intel-attempts");
    if (!attempts) {
      attempts = "1";
    } else {
      attempts = parseInt(attempts) + 1;
      if (attempts > 8) {
        $(this).attr("data-fb-intel-parsed", "incomplete");
      }
    }
    $(this).attr("data-fb-intel-attempts", attempts);
    debugPanel += `<p>attempts: ${attempts}</p>`;
    for (const [key, value] of Object.entries(requiredData)) {
      let attrValue = $(this).attr(value.attribute);
      if (attrValue === null || attrValue === undefined) {
        attrValue = value.method.apply(null, $(this));
      }
      if (
        attrValue !== null &&
        attrValue !== undefined &&
        !(attrValue instanceof Promise)
      ) {
        $(this).attr(value.attribute, `${attrValue}`);
        debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
      } else {
        debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
        allFound = false;
      }
    }
    if (allFound) {
      $(this).attr("data-fb-intel-parsed", "complete"); // this means ad can be written
    }

    // console.log('=====Panel===', debugPanel);
  });

  // seems it's duplicates code strings 864-897. Is it by design?
  $(
    "div.fb-intel-ad[data-fb-intel-triaged='sponsored']:not([data-fb-intel-parsed])"
  ).each(function () {
    let allFound = true;
    let debugPanel = "";

    let attempts = $(this).attr("data-fb-intel-attempts");
    if (!attempts) {
      attempts = "1";
    } else {
      attempts = parseInt(attempts) + 1;
      if (attempts > 8) {
        $(this).attr("data-fb-intel-parsed", "incomplete");
      }
    }
    $(this).attr("data-fb-intel-attempts", attempts);
    debugPanel += `<p>attempts: ${attempts}</p>`;
    for (const [key, value] of Object.entries(requiredData)) {
      let attrValue = $(this).attr(value.attribute);
      if (attrValue === null || attrValue === undefined) {
        attrValue = value.method.apply(null, $(this));
      }
      if (
        attrValue !== null &&
        attrValue !== undefined &&
        !(attrValue instanceof Promise)
      ) {
        $(this).attr(value.attribute, `${attrValue}`);
        debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
      } else {
        debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
        allFound = false;
      }
    }
    if (allFound) {
      $(this).attr("data-fb-intel-parsed", "complete"); // this means ad can be written
    }

    // console.log('=====debugPanel===', debugPanel);
  });

  const delta = Date.now() - startTime;
  //chrome.runtime.sendMessage(null, {"extractTime": delta});
}

function saveSponsoredAds() {
  $(
    "li.fb-intel-ad[data-fb-intel-parsed='complete']:not([data-fb-intel-saved])"
  ).each(function () {
    const adRoot = this;
    let thisAdData = Object.assign({}, adData);
    for (const [key, value] of Object.entries(requiredData)) {
      thisAdData[key] = $(adRoot).attr(value.attribute) || "";
      if (thisAdData[key] === null) {
      }
    }
    const postData = JSON.stringify(thisAdData);
    const settings = {
      async: true,
      crossDomain: true,
      url: powerAdSpyGText + "gtAdsData",
      method: "POST",
      headers: {
        "content-type": "application/json",
        "cache-control": "no-cache",
      },
      processData: false,
      data: postData,
    };
    $(adRoot).attr("data-fb-intel-saved", "pending");

    if (
      thisAdData.type == "IMAGE" ||
      thisAdData.type == "ORGANIC SEARCH" ||
      thisAdData.type == "TEXT"
    ) {
      $.ajax(settings)
        .done(function (response) {
          if (response.code == "200") {
            $(adRoot).attr("data-fb-intel-saved", "saved");
          } else {
            $(adRoot).attr("data-fb-intel-triaged", "complete");
            $(adRoot).attr("data-fb-intel-saved", "success");
          }
        })
        .fail(function () {
          $(adRoot).attr("data-fb-intel-triaged", "complete");
          $(adRoot).attr("data-fb-intel-saved", "failed");
        });
    } else {
      $(adRoot).attr("data-fb-intel-saved", "saved");
    }
  });

  $(
    "div.fb-intel-ad[data-fb-intel-parsed='complete']:not([data-fb-intel-saved])"
  ).each(function () {
    const adRoot = this;
    let thisAdData = Object.assign({}, adData);
    for (const [key, value] of Object.entries(requiredData)) {
      thisAdData[key] = $(adRoot).attr(value.attribute) || "";
      if (thisAdData[key] === null) {
      }
    }
    const postData = JSON.stringify(thisAdData);
    const settings = {
      async: true,
      crossDomain: true,
      url: powerAdSpyGText + "gtAdsData",
      method: "POST",
      headers: {
        "content-type": "application/json",
        "cache-control": "no-cache",
      },
      processData: false,
      data: postData,
    };
    $(adRoot).attr("data-fb-intel-saved", "pending");

    if (
      thisAdData.type == "IMAGE" ||
      thisAdData.type == "ORGANIC SEARCH" ||
      thisAdData.type == "TEXT"
    ) {
      $.ajax(settings)
        .done(function (response) {
          if (response.code == "200") {
            $(adRoot).attr("data-fb-intel-saved", "saved");
          } else {
            $(adRoot).attr("data-fb-intel-triaged", "complete");
            $(adRoot).attr("data-fb-intel-saved", "success");
          }
        })
        .fail(function () {
          $(adRoot).attr("data-fb-intel-triaged", "complete");
          $(adRoot).attr("data-fb-intel-saved", "failed");
        });
    } else {
      $(adRoot).attr("data-fb-intel-saved", "saved");
    }
  });
}

function hashCode(str) {
  return str
    .split("")
    .reduce(
      (prevHash, currVal) =>
        ((prevHash << 5) - prevHash + currVal.charCodeAt(0)) | 0,
      0
    );
}
