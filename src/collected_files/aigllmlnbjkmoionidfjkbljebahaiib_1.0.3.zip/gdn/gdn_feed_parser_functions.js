/**
 * Only helping functions are in this file
 * Pluggin start from here
 * start function "Start()"
 */

function buildUpGeoData() {
  if (
    !geoData.userIP ||
    !geoData.userCity ||
    !geoData.userState ||
    !geoData.userCountry
  ) {
    if (!geoData.userIP) {
      const ourIP = "https://plugin.poweradspy.com/";
      $.ajax({
        url: ourIP,
        type: "GET",
        async: true,
        success: function (ourIpResponse) {
          geoData.userIP = ourIpResponse.ipAddress;
          geoData.userCity = ourIpResponse.userCity || ourIpResponse.city;
          geoData.userState =
            ourIpResponse.userState || ourIpResponse.stateProv;
          geoData.userCountry =
            ourIpResponse.userCountry || ourIpResponse.countryName;
          geoData.lastUpdated = Date.now();
          // chrome.storage.local.set({"geoData":geoData});
        }
      });
    } else {
      // have ip so get geoData
      geoData.serviceId = (geoData.serviceId + 1) % geoFunctions.length;
      geoFunctions[geoData.serviceId].call(null, geoData.userIP);
    }
  }
}
function hashCode(str) {
  return str
    .split("")
    .reduce(
      (prevHash, currVal) =>
        ((prevHash << 5) - prevHash + currVal.charCodeAt(0)) | 0,
      0
    );
}
function random4DigitNumber() {
  return JSON.stringify(Math.floor(1000 + Math.random() * 9000));
}
function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}
// ======================================================================== //
// ======================================================================== //
// --- Starting From here --- //
// ======================================================================== //
// ======================================================================== //

function checkForNew() {
  //for gdn ads
  $("iframe[id*=google]:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "gdn")
    .addClass("native-intel-ad");
}
function triageItems() {
  // for gdn
  $(".native-intel-ad[data-native-intel-triaged='no']").each(function () {
    $(this).attr("data-native-intel-triaged", "sponsored");
  });
  // // for outbrain
  // $("li.native-intel-ad[data-native-intel-triaged='no']").each(function() {
  //   $(this).attr("data-native-intel-triaged", "sponsored");
  // });
}
function extractDataFromItems() {
  $(
    ".native-intel-ad[data-native-intel-triaged='sponsored']:not([data-native-intel-parsed])"
  ).each(function () {
    let allFound = true;
    let debugPanel = "";

    let attempts = $(this).attr("data-native-intel-attempts");
    if (!attempts) attempts = "1";
    else {
      attempts = parseInt(attempts) + 1;
      if (attempts > 8) $(this).attr("data-native-intel-parsed", "incomplete");
    }
    $(this).attr("data-native-intel-attempts", attempts);

    debugPanel += `<p>attempts: ${attempts}</p>`;
    for (const [key, value] of Object.entries(requiredData)) {
      let attrValue = $(this).attr(value.attribute);
      if (attrValue === null || attrValue === undefined) {
        attrValue = value.method.apply(null, $(this));
      }
      if (attrValue !== null && attrValue !== undefined) {
        $(this).attr(value.attribute, `${attrValue}`);
        debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
      } else {
        debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
        allFound = false;
        if (enableDebugger) {
          console.log("______________", debugPanel, "+++++++++++++++");
          // break;
        }
      }
    }
    if (allFound) {
      $(this).attr("data-native-intel-parsed", "complete"); // this means ad can be written
    }
    if (enableDebugger) {
      $(this).append(debugPanel);
      document
        .getElementsByTagName("HTML")[0]
        .setAttribute("native-intel-debug", "true");
    }
  });
}
function saveSponsoredAds() {
  $(
    ".native-intel-ad[data-native-intel-parsed='complete']:not([data-native-intel-saved])"
  ).each(function () {
    // Preparing post data from the scraped ads data
    const adRoot = this;
    let thisAdData = Object.assign({}, adData);
    for (const [key, value] of Object.entries(requiredData)) {
      thisAdData[key] = $(adRoot).attr(value.attribute) || "";
      if (thisAdData[key] === null) {
        if (enableDebugger) debugger;
      }
    }
    // Stringifying before sending to the Server
    const postData = JSON.stringify(thisAdData);
    // Ajax setting
    const settings = {
      async: true,
      crossDomain: true,
      url: powerAdSpyNativeApi + "insert-ads",
      method: "POST",
      headers: {
        "content-type": "application/json",
        "cache-control": "no-cache"
      },
      processData: false,
      data: postData
    };
    // Initially it will be in pending state if uploaded in saved else failed
    $(adRoot).attr("data-native-intel-saved", "pending");
    $.ajax(settings)
      .done(function (response) {
        if (response.code == "200") {
          $(adRoot).attr("data-native-intel-saved", "saved");
        } else {
          $(adRoot).attr("data-native-intel-triaged", "complete");
          $(adRoot).attr("data-native-intel-saved", "success");
        }
      })
      .fail(function () {
        // mark as done so we won't retry
        $(adRoot).attr("data-native-intel-triaged", "complete");
        $(adRoot).attr("data-native-intel-saved", "failed");
      });
  });
}
function getPlacementUrl() {
  return location.href;
}
function getTargetSite() {
  let targetSite = null;
  targetSite = location.href.split("/");
  targetSite = targetSite[0] + "://" + targetSite[2];
  return targetSite;
}
function getPostOwnerImage() {
  return "";
}
function getPostDate(adRoot) {
  let adPostTime;
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  adPostTime = parseInt(myDate);
  return adPostTime;
}
function getOwner(adRoot) {
  alert("meeee");
  debugger;
  // From destination URL
  let owner = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find("a").length > 0
  ) {
    owner = $(adRoot).find("a")[0].hostname;

    if (owner) {
      owner = owner.split(".");

      if (owner.length > 2) owner = owner[1];
      else if (owner.length > 1) owner = owner[0];
      else owner = null;
    }
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find("a.ob-dynamic-rec-link").length > 0
  ) {
    owner = $(adRoot).find("a.ob-dynamic-rec-link")[0].hostname;

    if (owner) {
      owner = owner.split(".");

      if (owner.length > 2) owner = owner[1];
      else if (owner.length > 1) owner = owner[0];
      else owner = null;
    }
  }

  return owner;
}
function getNetwork(adRoot) {
  if ($(adRoot).attr("data-native-intel-ad-network") === "taboola") {
    return "Taboola";
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "outbrain") {
    return "Outbrain";
  }
}
function getFirstSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}
function getLastSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}
function getUserIp() {
  return !!geoData.userIP ? geoData.userIP : null;
}
function getUserCity() {
  return !!geoData.userCity ? geoData.userCity : null;
}
function getUserState() {
  return !!geoData.userState ? geoData.userState : null;
}
function getUserCountry() {
  return !!geoData.userCountry ? geoData.userCountry : null;
}
function getAdId(adRoot) {
  let adTitle = null,
    adImage = null;
  let adId = adTitle + adImage;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".video-title").length > 0
  ) {
    adTitle = $(adRoot).find(".video-title")[0].innerText;
    adImage = $(adRoot).find(".thumbBlock")[0].style.backgroundImage;
    if (adImage) {
      adImage = adImage.split('"')[1];
    }

    if (adTitle && adImage) adId = hashCode(adId + adImage);
    else if (adTitle && !adImage) adId = hashCode(adId + random4DigitNumber());
    else adId = Date.now() + "" + random4DigitNumber();

    if (adId == 0) adId = null;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find("img.ob-rec-image").length > 0
  ) {
    adTitle = $(adRoot).find(".ob-unit.ob-rec-text")[0].title;
    adImage = $(adRoot).find("img.ob-rec-image")[0].src;

    if (adTitle && adImage) adId = hashCode(adId + adImage);
    else if (adTitle && !adImage) adId = hashCode(adId + random4DigitNumber());
    else adId = Date.now() + "" + random4DigitNumber();

    if (adId == 0) adId = null;
  }
  return adId;
}
function getAdText(adRoot) {
  let adText = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".branding").length > 0
  ) {
    adText = $(adRoot).find(".branding")[0].textContent;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find(".ob-unit.ob-rec-text").length > 0
  ) {
    adText = ""; //$(adRoot).find(".ob-unit.ob-rec-text")[0].title;
  }
  return adText;
}
function getPosition(adRoot) {
  return "SIDE";
}
function getImageOriginalUrl(adRoot) {
  let adImage = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".thumbBlock").length > 0
  ) {
    adImage = $(adRoot).find(".thumbBlock")[0].style.backgroundImage;
    if (adImage) {
      adImage = adImage.split('"')[1];
    }
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find("img.ob-rec-image").length > 0
  ) {
    adImage = $(adRoot).find("img.ob-rec-image")[0].src;
  }
  return adImage;
}
function getAdImage(adRoot) {
  let adImage = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".thumbBlock").length > 0
  ) {
    adImage = $(adRoot).find(".thumbBlock")[0].style.backgroundImage;
    if (adImage) {
      adImage = adImage.split('"')[1];
    }
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find("img.ob-rec-image").length > 0
  ) {
    adImage = $(adRoot).find("img.ob-rec-image")[0].src;
  }
  return adImage;
}
function getTitle(adRoot) {
  let title = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".video-title").length > 0
  ) {
    title = $(adRoot).find(".video-title")[0].innerText;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find(".ob-unit.ob-rec-text").length > 0
  ) {
    title = $(adRoot).find(".ob-unit.ob-rec-text")[0].title;
  }
  return title;
}
function getNumberPosition(adRoot) {
  return 1;
}
function getType(adRoot) {
  if ($(adRoot).attr("data-native-intel-ad-network") === "taboola") {
    return "IMAGE";
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "outbrain") {
    return "IMAGE";
  }
}
function getDestinationUrl(adRoot) {
  let adLinkURL = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find("a").length > 0
  ) {
    adLinkURL = $(adRoot).find("a")[0].href;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find("a.ob-dynamic-rec-link").length > 0
  ) {
    adLinkURL = $(adRoot).find("a.ob-dynamic-rec-link")[0].href;
  }
  return adLinkURL;
}
function getNewsfeedDescription(adRoot) {
  return "";
}
function getVersion() {
  return version;
}
function getsource() {
  return "desktop";
}
function getPlatform() {
  return Platform;
}
