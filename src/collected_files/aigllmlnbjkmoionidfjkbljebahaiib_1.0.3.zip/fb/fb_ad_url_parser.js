const state = {
  openedDialogNode: undefined,
  currentAd: undefined,
  styleElement: undefined,
};

const adsQueue = [];

const embedDialogClassNames = new Set([
  "cjfnh4rs l9j0dhe7 du4w35lb j83agx80 cbu4d94t lzcic4wl ni8dbmo4 stjgntxs oqq733wu cwj9ozl2 io0zqebd m5lcvass fbipl8qg nwvqtn77 nwpbqux9 iy3k6uwz e9a99x49 g8p4j16d bv25afu3 d2edcug0",
  "cjfnh4rs l9j0dhe7 du4w35lb j83agx80 cbu4d94t lzcic4wl ni8dbmo4 stjgntxs oqq733wu cwj9ozl2 io0zqebd m5lcvass fbipl8qg nwvqtn77 nwpbqux9 iy3k6uwz e9a99x49 g8p4j16d bv25afu3 gc7gaz0o k4urcfbm",
  "l9j0dhe7 du4w35lb cjfnh4rs j83agx80 cbu4d94t lzcic4wl ni8dbmo4 stjgntxs oqq733wu cwj9ozl2 io0zqebd m5lcvass fbipl8qg nwvqtn77 nwpbqux9 iy3k6uwz e9a99x49 g8p4j16d bv25afu3 d2edcug0",
  "om3e55n1 g4tp4svg l56fsmiw alzwoclg cqf1kptm icdlwmnq lq84ybu9 hf30pyar bjrpyg6s k0kqjr44 g6da2mms yn3a2qjl b52o6v01 a96hb305 qdjxsfl2 jydkgpbv pikqa3ac s0xl3u4v r1od7cao gvxzyvdx",
  "x1n2onr6 x1ja2u2z x1afcbsf x78zum5 xdt5ytf x1a2a7pz x6ikm8r x10wlt62 x71s49j x1jx94hy x1qpq9i9 xdney7k xu5ydu1 xt3gfkd x104qc98 x1g2kw80 x16n5opg xl7ujzl xhkep3z x193iq5w"
]);

function enqueueGetAdURL(adRoot) {
  adsQueue.push(adRoot);
}

const hidePopups = () => {
  if (state.styleElement) {
    return
  }
  const styleEl = document.createElement("style");
  state.styleElement = styleEl;
  document.head.appendChild(styleEl);
  const styleSheet = styleEl.sheet;
  if (!styleSheet) {
    throw new Error("No stylesheet");
  }
  styleSheet.insertRule('body .__fb-light-mode { visibility: hidden }', 0);
  styleSheet.insertRule('body .__fb-dark-mode { visibility: hidden }', 0);
  styleSheet.insertRule('body .__fb-light-mode div[aria-label="Embed Video"] { visibility: hidden }', 0);
  styleSheet.insertRule('body .__fb-dark-mode div[aria-label="Embed Video"] { visibility: hidden }', 0);
};

const unhidePopups = () => {
  if (state.styleElement) {
    state.styleElement.remove();
    state.styleElement = null;
  }
};

window.setInterval(() => {
  if (adsQueue.length && !state.currentAd && !state.styleElement) {
    window.setTimeout(() => {
      hidePopups();
      state.currentAd = adsQueue.shift();
      const postMenuButton = state.currentAd.querySelector('[aria-haspopup="menu"]');
      if (!postMenuButton) {
        throw new Error("No post menu button!");
      }
      //console.log("Open context menu");
      postMenuButton.click();
    }, 0);
  }
}, 500);

const targetNode = document.getElementsByTagName("body")[0];

// Options for the observer (which mutations to observe)
const config = { attributes: false, childList: true, subtree: true };

const embedInputconfig = { attributes: true, childList: false, subtree: false };
const embedInputCallback = function (mutationsList, observer) {
  const valueMutation = [...mutationsList].find(mutation => mutation.attributeName === "value");
  if (valueMutation) {
    const adUrl = processEmbedValue(valueMutation.target.value);
    const adId = extractAdId(adUrl);
    if (state.currentAd && state.openedDialogNode) {
      state.openedDialogNode.querySelector('[role="button"]').click();
      state.currentAd.setAttribute("data-fb-intel-ad_id", adId);
      state.currentAd.setAttribute("data-fb-intel-ad_url", adUrl);
      state.currentAd = undefined;
      window.setTimeout(() => {
        unhidePopups();
      }, 500)
    }
  }
  observer.disconnect();
};
const embedInputObserver = new MutationObserver(embedInputCallback);

const callback = function (mutationsList, observer) {
  for (const mutation of mutationsList) {
    if (mutation.type === "childList") {
      const contextMenuNode = [...mutation.addedNodes].find(node => {
        if (!(node instanceof Element)) {
          return;
        }
        if (node && node.attributes && node.attributes.role && node.attributes.role.nodeValue === "menu") {
          return node;
        }
      });

      if (state.currentAd && contextMenuNode) {
        let hidead = null;
        const menuItems = contextMenuNode.querySelectorAll("[role='menuitem']");
        const embedMenuItem = [...menuItems].find(item => {
          const itemIcon = item.querySelector(".x1i10hfl .xu06os2");
          if (itemIcon && $(itemIcon).text() === 'Hide ad') {
            hidead = 'Hide ad';
          }
          if (hidead && itemIcon && $(itemIcon).text() === 'Embed') {
            return itemIcon && $(itemIcon).text() === 'Embed';
          }
        });
        if (embedMenuItem) {
          //console.log("Embed menu item found");
          embedMenuItem.click();
        } else {
          //console.log("Embed menu item not found!");
          const postMenuButton = state.currentAd.querySelector('[aria-haspopup="menu"]');
          postMenuButton.click();
          state.currentAd = undefined;
          unhidePopups();
        }
        return;
      }

      const dialogNode = [...mutation.addedNodes].find(node => {
        if (!(node instanceof Element) || !state.currentAd) {
          return;
        }

        const dialog = node.querySelector("[role='dialog']");

        if (dialog && embedDialogClassNames.has(dialog.className)) {
          return dialog;
        }

        return null;
      });

      if (dialogNode && state.currentAd) {
        //console.log("Embed dialog opened");
        state.openedDialogNode = dialogNode;
        const closeButton = dialogNode.querySelector('[role="button"]');
        const embedInput = dialogNode.querySelector("input[type='text']");
        if (embedInput) {
          if (embedInput.value) {
            const adUrl = processEmbedValue(embedInput.value);
            const adId = extractAdId(adUrl);
            // console.log(`ad_url: ${adUrl}`);
            //console.log(`ad_id: ${adId}`);
            closeButton.click();
            state.currentAd.setAttribute("data-fb-intel-ad_id", adId);
            state.currentAd.setAttribute("data-fb-intel-ad_url", adUrl);
            state.currentAd = undefined;
            unhidePopups();
            return;
          }
          embedInputObserver.observe(embedInput, embedInputconfig);
        }
      }
    }
  }
};

const processEmbedValue = value => {
  const srcRe = /src\s*=\s*"(.+?)"/;
  const match = value.match(srcRe);
  const iFrameUrl = match[1];
  const url = new URL(iFrameUrl);
  const ad_url = url.searchParams.get("href");
  return ad_url;
};

const extractAdId = adUrl => {
  const res = adUrl.match(/(?<adId>[0-9]+)\/?$/);
  if (res) {
    return res.groups.adId;
  }
  return '';
  //return hashCode(adUrl);
};

// Create an observer instance linked to the callback function
const observer = new MutationObserver(callback);

// Start observing the target node for configured mutations
observer.observe(targetNode, config);
