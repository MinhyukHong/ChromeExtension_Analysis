
let sponsoredClass = null;
let optSponsoredClass = null;
let updatedSponsored = null;
let sideSponsoredClass = null;
let recentSponsored = null;
let latestSponsored = null;
let simpleSponsored = null;
let birthday = '';
let user_ID, fb_dtsg, composerId;
let currentIp = null;
let USERNAME;

let adKwStatus = null;

let defaultGeoData = {
  serviceId: null,
  lastUpdated: null,
  userCity: null,
  userState: null,
  userCountry: null,
  userIP: '',
};
let geoData = {};
getUserData();
userDetails();
chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
  geoData = Object.assign(geoData, result.geoData);
  const minDelay = 2 * 60 * 60 * 1000; // 2 hours in milliseconds
  const maxDelay = 3 * 60 * 60 * 1000; // 3 hours in milliseconds
  const randomDelay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;
  if (geoData.lastUpdated < (Date.now() - randomDelay)) {
      geoData.userIP = null;
      buildUpGeoData();
  }
});


//For first side ad
setTimeout(function () {
  const scriptTags = Array.from(document.querySelectorAll("script[data-sjs]"));
  scriptTags.forEach((script) => {
    try {
      if (script.textContent.includes("SideFeed")) {
        const scriptContent = JSON.parse(script.textContent);
        let sideObjects;
        const paths = [
          [7, 3, 1],
          [3, 3, 1],
          [5, 3, 1],
        ];
        for (const [a, b, c] of paths) {
          try {
            sideObjects =
              scriptContent?.require[0][3][0]?.__bbox?.require[a][b][c]?.__bbox
                ?.result?.data?.viewer?.sideFeed?.nodes[0]?.ads?.nodes;
            if (sideObjects) break;
          } catch (error) {}
        }
        sideObjects.forEach((ad) => {
          let sideAdsData = sideAds(ad);
          sendPost(sideAdsData);
        });
      }
    } catch (error) {}
  });
}, 5000);
//first side ad end here

// First marketplace ad
setTimeout(function () {
  const scriptTags = Array.from(document.querySelectorAll("script[data-sjs]"));
  scriptTags.forEach((script) => {
    if (
      script.textContent.includes(
        "MarketplaceCometBrowseFeedLight_dataConnection$stream$MarketplaceBrowseFeedLight_marketplace_home_feed"
      )
    ) {
      JSON.parse(script.textContent).require[0][3][0].__bbox.require.forEach(
        (e) => {
          let temp = e[3];
          if (
            temp !== undefined &&
            temp[1] !== undefined &&
            temp[1].hasOwnProperty("__bbox")
          ) {
            if (
              temp[1].__bbox.result.data.node.story_attachment_style !==
              "large_carousel_tile"
            ) {
              let marketplaceAdsData = marketplaceImageVideoAds(
                temp[1].__bbox.result.data
              );
              if (
                marketplaceAdsData?.ad_id &&
                marketplaceAdsData?.image_video_url &&
                marketplaceAdsData?.destination_url
              ) {
                sendPost(marketplaceAdsData);
              }
            } else {
              let marketplaceAdsData = marketplaceCarouselAds(
                temp[1].__bbox.result.data
              );
              if (
                marketplaceAdsData?.ad_id &&
                marketplaceAdsData?.image_video_url &&
                marketplaceAdsData?.destination_url
              ) {
                sendPost(marketplaceAdsData);
              }
            }
          }
        }
      );
    }
  });
}, 5000);
// First marketplace ad ends here

const interceptorScript = document.createElement('script');
interceptorScript.src = chrome.runtime.getURL('library/xhr-interceptor.js');

interceptorScript.onload = function () {
  this.remove();
};

(document.head || document.documentElement).appendChild(interceptorScript);

async function handleXhrIntercepted(event) {
  const { responseURL, response } = event.detail;
  //watch feed starts here
  try {
    var ads = response.split("\n");
  } catch (e) { }
  try {
    ads.forEach(async function (ad) {
      try {
        ad = JSON.parse(ad);
        if (ad["label"] === "CometVideoHomeFeedSectionPagination_section$stream$CometVideoHomeFeedSection_section_components") {
          if (ad["data"]["node"]["feed_unit"]["sponsored_data"].hasOwnProperty("ad_id")) {
            var watchAdResult = {};
            watchAdResult['meta_ad_id'] = ad?.data?.node?.feed_unit?.sponsored_data?.ad_id || ''
            watchAdResult["thumbnail_url"] = ad?.data?.node?.feed_unit?.attachments[0]?.media?.thumbnailImage?.uri || ad?.data?.node?.feed_unit?.attachments[0]?.media?.preferred_thumbnail?.image?.uri || ""
            try { watchAdResult['post_owner'] = ad.data.node.feed_unit.actors[0].name; } catch { }
            try { watchAdResult['post_owner_image'] = ad.data.node.feed_unit.actors[0].profile_picture.uri; } catch { }
            try { watchAdResult['ad_text'] = ad.data.node.feed_unit.message.text; } catch { }
            if (!watchAdResult['ad_text']) watchAdResult['ad_text'] = '';
            try { watchAdResult['ad_title'] = ad.data.node.feed_unit.attachments[0].comet_footer_renderer.attachment.title_with_entities.text; } catch { }
            if (!watchAdResult['ad_title']) watchAdResult['ad_title'] = '';
            try { watchAdResult['call_to_action'] = ad.data.node.feed_unit.attachments[0].comet_footer_renderer.attachment.call_to_action_renderer.action_link.title; } catch { }
            try { watchAdResult['image_video_url'] = ad.data.node.feed_unit.attachments[0].style_type_renderer.attachment.media.flexible_height_share_image.uri; } catch { }
            try { watchAdResult['news_feed_description'] = ad.data.node.feed_unit.attachments[0].comet_footer_renderer.attachment.description.text; } catch { }
            try { watchAdResult['destination_url'] = ad.data.node.feed_unit.attachments[0].style_type_renderer.attachment.story_attachment_link_renderer.attachment.web_link.url; } catch { }
            if (!watchAdResult['news_feed_description']) watchAdResult['news_feed_description'] = '';
            try { watchAdResult['likes'] = ad.data.node.feed_unit.feedback_context.feedback_target_with_context.reaction_count.count; } catch { }
            if (!watchAdResult['likes']) watchAdResult['likes'] = '0';
            try { watchAdResult['comment'] = ad.data.node.feed_unit.feedback_context.feedback_target_with_context.total_comment_count; } catch { }
            watchAdResult['share'] = '0';
            watchAdResult['views'] = ""
            try { watchAdResult['ad_id'] = ad.data.node.feed_unit.post_id; } catch { }
            try { watchAdResult['ad_url'] = ad.data.node.feed_unit.feedback_context.feedback_target_with_context.url; } catch { }
            var ad_type = ad.data.node.feed_unit.feedback_context.feedback_target_with_context.ufi_action_renderers[0].feedback.associated_video;
            if (ad_type === null) {
              watchAdResult["type"] = 'IMAGE';
              try { watchAdResult['image_video_url'] = ad.data.node.feed_unit.attachments[0].style_type_renderer.attachment.media.flexible_height_share_image.uri; } catch { }
              if (!watchAdResult['image_video_url']) watchAdResult['image_video_url'] = ad.data.node.feed_unit.attachments[0].style_type_renderer.attachment.media.large_share_image.uri;
            } else {
              watchAdResult["type"] = 'VIDEO';
              watchAdResult['views'] = ad?.data?.node?.feed_unit?.feedback_context?.feedback_target_with_context?.video_view_count_renderer?.feedback?.video_view_count || ""
              try { watchAdResult['image_video_url'] = ad.data.node.feed_unit.attachments[0].media.playable_url; } catch { }
              if(!watchAdResult['image_video_url']){
                watchAdResult['image_video_url'] = ad.data.node.feed_unit.attachments[0].media.browser_native_hd_url;
              }
              try { watchAdResult['ad_title'] = ad.data.node.feed_unit.attachments[0].comet_footer_renderer.attachment.action_links[0].link_title; } catch { }
              if (!watchAdResult['ad_title']) watchAdResult['ad_title'] = '';
              try { watchAdResult['call_to_action'] = ad.data.node.feed_unit.attachments[0].comet_footer_renderer.attachment.call_to_action_renderer.action_link.title; } catch { }
              try { watchAdResult['destination_url'] = ad.data.node.feed_unit.attachments[0].comet_footer_renderer.attachment.call_to_action_renderer.action_link.url; } catch { }
              if (!watchAdResult['destination_url']) watchAdResult['destination_url'] = '';
            }
            watchAdResult["other_multimedia"] = "";
            watchAdResult["ad_position"] = "VIDEO FEED";
            watchAdResult["side_url"] = "Not implemented yet";
            watchAdResult["category"] = "No category";
            watchAdResult["ip_address"] = getUserIp();
            watchAdResult["city"] = getUserCity();
            watchAdResult["state"] = getUserState();
            watchAdResult["country"] = getUserCountry();
            // watchAdResult["facebook_id"] = user_ID;
            watchAdResult["lower_age"] = getLowerAdAge();
            watchAdResult["upper_age"] = getUpperAdAge();
            watchAdResult["version"] = getVersion();
            watchAdResult["platform"] = getPlatform();
            watchAdResult["first_seen"] = getFirstSeen().toString();
            watchAdResult["last_seen"] = getLastSeen().toString();
            if (!watchAdResult["destination_url"] || !watchAdResult["call_to_action"]) watchAdResult["call_to_action"] = "";
            var pDate = await postDate(watchAdResult.ad_url, watchAdResult.ad_id, null);
            if (pDate === undefined) {
              watchAdResult["post_date"] = "";
            }
            else {
              watchAdResult["post_date"] = pDate;
            }
            sendPost(watchAdResult);
          }
        }
      } catch (e) {
      }
    });
  } catch {

  }
  //watch feed ends here

  // search feed auto scroll starts

  if (responseURL === 'https://www.facebook.com/api/graphql/' && response.indexOf('SEARCH_ADS') !== -1 && autoScrollProcess === true) {
    try {
      const searchAdsPosts = response.split('\n');
      const searchResults = searchAdsPosts.map(searchpost => JSON.parse(searchpost));
      const searchPosts = searchResults[0].data.serpResponse.results.edges.filter(post => post.node.role === "SEARCH_ADS");
      for (const searchPost of searchPosts) {
        var jResponse = JSON.stringify(searchPost);
        var searchAdResult = {};
        searchAdResult["meta_ad_id"] = searchPost?.relay_rendering_strategy?.view_model?.story?.sponsored_data?.ad_id || ""
        try { searchAdResult['post_owner'] = searchPost.relay_rendering_strategy.view_model.story.comet_sections.title.story.actors[0].name; } catch { }
        searchAdResult['post_owner_image'] = searchPost.relay_rendering_strategy.view_model.story.actors[0].profile_picture.uri;
        try { searchAdResult['ad_text'] = searchPost.relay_rendering_strategy.view_model.story.comet_sections.message.story.message.text; } catch { }
        if (!searchAdResult['ad_text']) searchAdResult['ad_text'] = "";
        try { searchAdResult['ad_title'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].title_with_entities.text; } catch { }
        if (!searchAdResult['ad_title']) searchAdResult['ad_title'] = "";
        try { searchAdResult['news_feed_description'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].comet_footer_renderer.attachment.description.text; } catch { }
        if (!searchAdResult['news_feed_description']) searchAdResult['news_feed_description'] = "";
        try { searchAdResult['call_to_action'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].comet_footer_renderer.attachment.call_to_action_renderer.action_link.title; } catch { }
        try { searchAdResult['comment'] = searchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.total_comment_count; } catch { }
        if (!searchAdResult['comment']) searchAdResult['comment'] = "0";
        try { searchAdResult['likes'] = searchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.reaction_count.count; } catch { }
        if (!searchAdResult['likes']) searchAdResult['likes'] = "0";
        try { searchAdResult['share'] = searchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.share_count.count; } catch { }
        if (!searchAdResult['share']) searchAdResult['share'] = "0";
        try { searchAdResult["destination_url"] = searchPost.relay_rendering_strategy.view_model.story.shareable.url; } catch { }
        if (!searchAdResult["destination_url"]) searchAdResult["destination_url"] = "";
        try { searchAdResult['ad_id'] = searchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.ufi_action_renderers[2].feedback.share_fbid; } catch { }
        if (!searchAdResult['ad_id']) searchAdResult['ad_id'] = userSearchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.subscription_target_id;
        searchAdResult['ad_url'] = searchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.url;
        searchAdResult['image_url_original'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].media.imageLargeAspect.uri;
        searchAdResult['verified'] = "";
        searchAdResult['views'] = ""
        searchAdResult['thumbnail_url'] = ""
        if (jResponse.indexOf('card_title') !== -1) {
          //continue;
          let otherMultimedia;
          let title;
          let extraImage;
          try { extraImage = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.style_list[0]; } catch { }
          var cardImages = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.subattachments;
          const urlsImage = cardImages.map((cardImage) => cardImage.multi_share_media_card_renderer.attachment.media.image.uri);
          urlsImage.splice(0, 1);
          otherMultimedia = urlsImage.join('||,');
          try {
            if (extraImage !== "multi_share_no_end_card") {
              let etcImage = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.media.card_image.uri;
              otherMultimedia = otherMultimedia + '||,' + etcImage;
            }
          } catch { }
          searchAdResult["other_multimedia"] = otherMultimedia;
          searchAdResult['image_url_original'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.subattachments[0].multi_share_media_card_renderer.attachment.media.image.uri;
          searchAdResult['call_to_action'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.subattachments[0].call_to_action_renderer.action_link.title;
          searchAdResult['destination_url'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.subattachments[1].multi_share_media_card_renderer.attachment.url;
          const cardTitle = cardImages.map((cardTitle) => cardTitle.card_title.text);
          title = cardTitle.join('||,');
          try {
            if (extraImage !== "multi_share_no_end_card") {
              let etcTitle = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.source.text;
              title = title + '||,' + 'See more at ' + etcTitle.toUpperCase();
            }
          } catch { }
          searchAdResult["ad_title"] = title;
        } else {
          searchAdResult["other_multimedia"] = "";
        }
        searchAdResult["ad_position"] = "FEED";
        searchAdResult["side_url"] = "Not implemented yet";
        searchAdResult["category"] = "No category";
        var countryData = [];
        var countryName = getUserCountry();
        countryData.push(countryName);
        searchAdResult["country"] = countryData;
        searchAdResult["lower_age"] = getLowerAdAge();
        searchAdResult["upper_age"] = getUpperAdAge();
        searchAdResult["version"] = getVersion();
        searchAdResult["platform"] = getPlatform();
        searchAdResult["first_seen"] = getFirstSeen().toString();
        searchAdResult["last_seen"] = getLastSeen().toString();
        if (!searchAdResult["destination_url"]) searchAdResult["call_to_action"] = "";
        var videoType = searchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.associated_video;
        if (videoType === null) {
          searchAdResult["type"] = 'IMAGE';
        } else {
          searchAdResult["type"] = 'VIDEO';
          searchAdResult['views'] = searchPost?.relay_rendering_strategy?.view_model?.story?.search_feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback?.video_view_count || "";
          searchAdResult['image_url_original'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.media.playable_url;
          if (!searchAdResult['image_url_original']) {
            searchAdResult['image_url_original'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.media.browser_native_hd_url;
          }
          searchAdResult['destination_url'] = searchPost.relay_rendering_strategy.view_model.story.attachments[0].story_attachment_link_renderer.attachment.action_links[0].url;
          if (!searchAdResult['destination_url']) searchAdResult['destination_url'] = "";
        }
        chrome.storage.local.get('UserRequest', function (requestResult) {
          searchAdResult['user_request_id'] = requestResult.UserRequest.data[0].id;
          if (requestResult.UserRequest.data[0].keywords) {
            searchAdResult['user_request_value'] = 1;
          } else {
            searchAdResult['user_request_value'] = 2;
          }
        });
        chrome.storage.local.get('advertiserAdProcessingStatus', function (requestResult) {
          if (requestResult) {
            adKwStatus = requestResult.advertiserAdProcessingStatus;
            if (adKwStatus === 0) {
              searchAdResult['user_request_value'] = 1;
            } else if (adKwStatus === 1) {
              searchAdResult['user_request_value'] = 2;
            }
          }
        });
        let commentData = [];
        let redirects = [];
        let outgoingUrls = [];
        searchAdResult['code'] = 200;
        searchAdResult['view_count'] = "";
        searchAdResult['gender'] = "";
        searchAdResult['male_count'] = 0;
        searchAdResult['female_count'] = 0;
        searchAdResult['comments_data'] = commentData;
        searchAdResult['redirects'] = redirects;
        searchAdResult['outgoing_url'] = outgoingUrls;
        searchAdResult['keyword_id'] = 0;
        var pDate = await postDate(searchAdResult.ad_url, searchAdResult.ad_id, null);
        if (pDate === undefined || pDate === "") {
          searchAdResult["post_date"] = "";
        }
        else {
          searchAdResult["post_date"] = pDate;
        }
        searchAdResult['image_video_url'] = searchAdResult['image_url_original'];
        await sendUserRequestPost(searchAdResult);
      }
    } catch (e) { }
  }
  // search feed auto scroll ends

  // search feed user request start
  if (responseURL === 'https://www.facebook.com/api/graphql/' && response.indexOf('SEARCH_ADS') !== -1 && userRequestProcess === true) {
    try {
      const userSearchAdsPosts = response.split('\n');
      const userSearchResults = userSearchAdsPosts.map(searchpost => JSON.parse(searchpost));
      const userSearchPosts = userSearchResults[0].data.serpResponse.results.edges.filter(post => post.node.role === "SEARCH_ADS");
      for (const userSearchPost of userSearchPosts) {
        var userjsonResponse = JSON.stringify(userSearchPost);
        var userSearchAdResult = {};
        userSearchAdResult["meta_ad_id"] = userSearchPost?.relay_rendering_strategy?.view_model?.story?.sponsored_data?.ad_id || ""
        try { userSearchAdResult['post_owner'] = userSearchPost.relay_rendering_strategy.view_model.story.comet_sections.title.story.actors[0].name; } catch { }
        userSearchAdResult['post_owner_image'] = userSearchPost.relay_rendering_strategy.view_model.story.actors[0].profile_picture.uri;
        try { userSearchAdResult['ad_text'] = userSearchPost.relay_rendering_strategy.view_model.story.comet_sections.message.story.message.text; } catch { }
        if (!userSearchAdResult['ad_text']) userSearchAdResult['ad_text'] = "";
        try { userSearchAdResult['ad_title'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].title_with_entities.text; } catch { }
        if (!userSearchAdResult['ad_title']) userSearchAdResult['ad_title'] = "";
        try { userSearchAdResult['news_feed_description'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].comet_footer_renderer.attachment.description.text; } catch { }
        if (!userSearchAdResult['news_feed_description']) userSearchAdResult['news_feed_description'] = "";
        try { userSearchAdResult['call_to_action'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].comet_footer_renderer.attachment.call_to_action_renderer.action_link.title; } catch { }
        try { userSearchAdResult['comment'] = userSearchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.total_comment_count; } catch { }
        if (!userSearchAdResult['comment']) userSearchAdResult['comment'] = "0";
        try { userSearchAdResult['likes'] = userSearchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.reaction_count.count; } catch { }
        if (!userSearchAdResult['likes']) userSearchAdResult['likes'] = "0";
        try { userSearchAdResult['share'] = userSearchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.share_count.count; } catch { }
        if (!userSearchAdResult['share']) userSearchAdResult['share'] = "0";
        try { userSearchAdResult["destination_url"] = userSearchPost.relay_rendering_strategy.view_model.story.shareable.url; } catch { }
        if (!userSearchAdResult["destination_url"]) userSearchAdResult["destination_url"] = "";
        try { userSearchAdResult['ad_id'] = userSearchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.ufi_action_renderers[2].feedback.share_fbid; } catch { }
        if (!userSearchAdResult['ad_id']) userSearchAdResult['ad_id'] = userSearchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.subscription_target_id;
        userSearchAdResult['ad_url'] = userSearchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.url;
        userSearchAdResult['image_video_url'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].media.imageLargeAspect.uri;
        userSearchAdResult['page_verified'] = "";
        userSearchAdResult['views'] = ""
        userSearchAdResult['thumbnail_url'] = ""
        if (userjsonResponse.indexOf('card_title') !== -1) {
          let otherMultimedia;
          let title;
          let extraImage;
          try { extraImage = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.style_list[0]; } catch { }
          var cardImages = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.subattachments;
          const urlsImage = cardImages.map((cardImage) => cardImage.multi_share_media_card_renderer.attachment.media.image.uri);
          urlsImage.splice(0, 1);
          otherMultimedia = urlsImage.join('||,');
          try {
            if (extraImage !== "multi_share_no_end_card") {
              let etcImage = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.media.card_image.uri;
              otherMultimedia = otherMultimedia + '||,' + etcImage;
            }
          } catch { }
          userSearchAdResult["other_multimedia"] = otherMultimedia;
          userSearchAdResult['image_video_url'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.subattachments[0].multi_share_media_card_renderer.attachment.media.image.uri;
          userSearchAdResult['call_to_action'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.subattachments[0].call_to_action_renderer.action_link.title;
          userSearchAdResult['destination_url'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.subattachments[1].multi_share_media_card_renderer.attachment.url;
          const cardTitle = cardImages.map((cardTitle) => cardTitle.card_title.text);
          title = cardTitle.join('||,');
          try {
            if (extraImage !== "multi_share_no_end_card") {
              let etcTitle = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.source.text;
              title = title + '||,' + 'See more at ' + etcTitle.toUpperCase();
            }
          } catch { }
          userSearchAdResult["ad_title"] = title;
        } else {
          userSearchAdResult["other_multimedia"] = "";
        }
        userSearchAdResult["ad_position"] = "FEED";
        userSearchAdResult["side_url"] = "Not implemented yet";
        userSearchAdResult["category"] = "No category";
        userSearchAdResult["ip_address"] = getUserIp();
        userSearchAdResult["city"] = getUserCity();
        userSearchAdResult["state"] = getUserState();
        userSearchAdResult["country"] = getUserCountry();
        // userSearchAdResult["facebook_id"] = user_ID;
        userSearchAdResult["lower_age"] = getLowerAdAge();
        userSearchAdResult["upper_age"] = getUpperAdAge();
        userSearchAdResult["version"] = getVersion();
        userSearchAdResult["platform"] = getPlatform();
        userSearchAdResult["first_seen"] = getFirstSeen().toString();
        userSearchAdResult["last_seen"] = getLastSeen().toString();
        if (!userSearchAdResult["destination_url"]) userSearchAdResult["call_to_action"] = "";
        var videoType = userSearchPost.relay_rendering_strategy.view_model.story.search_feedback_context.feedback_target_with_context.ufi_renderer.feedback.comet_ufi_summary_and_actions_renderer.feedback.associated_video;
        if (videoType === null) {
          userSearchAdResult["type"] = 'IMAGE';
        } else {
          userSearchAdResult["type"] = 'VIDEO';
          userSearchAdResult['views'] = userSearchPost?.relay_rendering_strategy?.view_model?.story?.search_feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback?.video_view_count || "";
          userSearchAdResult['image_video_url'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.media.playable_url;
          if (!userSearchAdResult['image_video_url']) {
            userSearchAdResult['image_video_url'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].style_type_renderer.attachment.media.browser_native_hd_url;
          }
          userSearchAdResult['destination_url'] = userSearchPost.relay_rendering_strategy.view_model.story.attachments[0].story_attachment_link_renderer.attachment.action_links[0].url;
          if (!userSearchAdResult['destination_url']) userSearchAdResult['destination_url'] = "";
        }
        if (!userSearchAdResult["destination_url"]) userSearchAdResult["call_to_action"] = "";
        var pDate = await postDate(userSearchAdResult.ad_url, userSearchAdResult.ad_id, null);
        if (pDate === undefined) {
          userSearchAdResult["post_date"] = "";
        }
        else {
          userSearchAdResult["post_date"] = pDate;
        }
        sendPost(userSearchAdResult);
      }
    } catch (e) {
    }
  }

  //side ads starts here
  if (
    responseURL === "https://www.facebook.com/api/graphql/" &&
    response.includes("sideFeed")
  ) {
    try {
      let sideObject = JSON.parse(response);
      sideObject = sideObject?.data?.viewer?.sideFeed?.nodes[0]?.ads?.nodes;
      sideObject.forEach((ad) => {
        let sideAdsData = sideAds(ad);
        sendPost(sideAdsData);
      });
    } catch (error) { }
  }
  //side ads ends

  //marketplace starts here
  if (
    responseURL === "https://www.facebook.com/api/graphql/" &&
    response.includes(
      "MarketplaceCometBrowseFeedLight_dataConnection$stream$MarketplaceBrowseFeedLight_marketplace_home_feed"
    )
  ) {
    response.split("\n").map((ad) => {
      let Ad = JSON.parse(ad);
      let dataType =
        Ad?.data?.marketplace_home_feed?.edges[0]?.node?.story_type ||
        Ad?.data?.node?.story_type;
      if (dataType && dataType === "AD") {
        // console.log(Ad);
        let adType = null;
        if (Ad?.data?.node?.story_attachment_style) {
          adType = Ad.data.node.story_attachment_style;
          Ad = Ad.data;
        }
        if (
          Ad?.data?.marketplace_home_feed?.edges[0]?.node
            ?.story_attachment_style
        ) {
          adType =
            Ad?.data?.marketplace_home_feed?.edges[0]?.node
              ?.story_attachment_style;
          Ad = Ad.data.marketplace_home_feed.edges[0];
        }
        if (adType !== "large_carousel_tile") {
          let marketplaceAdsData = marketplaceImageVideoAds(Ad);
          if (
            marketplaceAdsData?.ad_id &&
            marketplaceAdsData?.image_video_url &&
            marketplaceAdsData?.destination_url
          ) {
            sendPost(marketplaceAdsData);
          }
        }
        if (adType === "large_carousel_tile") {
          let marketplaceCarouselAdsData = marketplaceCarouselAds(Ad);
          if (
            marketplaceCarouselAdsData?.ad_id &&
            marketplaceCarouselAdsData?.image_video_url &&
            marketplaceCarouselAdsData?.destination_url
          ) {
            sendPost(marketplaceCarouselAdsData);
          }
        }
      }
    });
  }
  //marketplace ends here

  //feed post starts
  const FB_GQL_URL = 'https://www.facebook.com/api/graphql/';
  const LABEL = 'CometNewsFeed_viewerConnection$stream$CometNewsFeed_viewer_news_feed';

  if (responseURL !== FB_GQL_URL || response.indexOf(LABEL) === -1) {
    return;
  }

  const posts = response.split('\n');
  try {
    let sponsoredPosts = null;
    sponsoredPosts = posts
      .map(post => JSON.parse(post))
      .filter(post => (post?.data?.node?.lbl_sp_data?.__typename === 'SponsoredData') || (post?.data?.node?.sponsored_data?.__typename === 'SponsoredData'));
    // if (sponsoredPosts.length === 0 && posts[0].includes('SPONSORED')) {
    //   let differentPosts = JSON.parse(posts[0]);
    //   if (differentPosts.data.viewer.news_feed.edges[0].category === 'SPONSORED') {
    //     sponsoredPosts = [differentPosts];
    //   }
    // }
    for (const post of sponsoredPosts) {
      let adResponse = JSON.stringify(post);
      let adResult = {};
      try {
        let format_data = AnalysePostdata(post);
        if (format_data != null) {
          adResult["meta_ad_id"] = post?.data?.node?.sponsored_data?.id_for_advertisement || post?.data?.node?.comet_sections?.content?.story?.sponsored_data?.ad_id || post?.data?.node?.lbl_sp_data?.ad_id || "";
          adResult["views"] = ""
          adResult["thumbnail_url"] = ""
          if (format_data.type === 2) {
            adResult["type"] = 'VIDEO';
            adResult["views"] = format_data?.view_count || "";
            adResult["image_video_url"] = format_data["video_url"];
            adResult["thumbnail_url"] = format_data?.video_preview_image_url || "";
          } else if (format_data.type === 1) {
            adResult["type"] = 'IMAGE';
            adResult["image_video_url"] = format_data["image_url"];
          }
          adResult["destination_url"] = format_data.raw_cta_url ? format_data.raw_cta_url : "";
          try { adResult["ad_title"] = post.data.node.comet_sections.content.story.attachments[0].styles.attachment.title_with_entities.text; } catch { }
          try { if (!adResult["ad_title"]) adResult["ad_title"] = post.data.node.comet_sections.content.story.attachments[0].comet_footer_renderer.attachment.action_links[0].link_title; } catch { }
          try { if (!adResult["ad_title"]) adResult["ad_title"] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.title_with_entities.text; } catch { }
          try { if (!adResult["ad_title"]) adResult["ad_title"] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].comet_footer_renderer.attachment.action_links[0].link_title; } catch { }
          adResult["ad_title"] = adResult["ad_title"] ? adResult["ad_title"] : "";
          try { adResult["ad_text"] = post.data.node.comet_sections.content.story.message.text; } catch { }
          try { if (!adResult["ad_text"]) adResult["ad_text"] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.comet_sections.message.story.message.text; } catch { }
          adResult["ad_text"] = adResult["ad_text"] ? adResult["ad_text"] : "";
          adResult["likes"] = format_data.like_count;
          adResult["comment"] = format_data.comment_count;
          adResult["share"] = format_data.share_count;
          try { adResult["call_to_action"] = post.data.node.comet_sections.content.story.attachments[0].comet_footer_renderer.attachment.call_to_action_renderer.action_link.title; } catch { }
          try { if (!adResult["call_to_action"]) adResult["call_to_action"] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].comet_footer_renderer.attachment.call_to_action_renderer.action_link.title; } catch { }
          try { if (!adResult["call_to_action"]) adResult["call_to_action"] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.cta_screen_renderer.action_link.title; } catch { }
          adResult["call_to_action"] = adResult["call_to_action"] ? adResult["call_to_action"] : "";
          adResult["post_owner"] = format_data.page_name;
          try { adResult["ad_id"] = post.data.node.post_id; } catch { }
          adResult["ad_id"] = adResult["ad_id"] ? adResult["ad_id"] : post.data.viewer.news_feed.edges[0].node.post_id;
          try {
            adResult["post_owner_image"] =
              post?.data?.node?.comet_sections?.content?.story?.comet_sections
                ?.context_layout?.story?.actor_photo?.story?.actors[0]
                ?.profile_picture?.uri ||
              post?.data?.node?.comet_sections?.context_layout?.story
                ?.comet_sections?.actor_photo?.story?.actors[0]?.profile_picture
                ?.uri;
          } catch {}
          try { adResult["post_owner_image"] = post.data.node.comet_sections.content.story.comet_sections.context_layout.story.comet_sections.actor_photo.story.actors[0].profile_picture.uri; } catch { }
          try { adResult["ad_url"] = post.data.node.comet_sections.content.story.wwwURL; } catch { }
          if (!adResult["ad_url"]) adResult["ad_url"] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.wwwURL;
          try { adResult["page_verified"] = post.data.node.comet_sections.content.story.comet_sections.context_layout.story.comet_sections.title.story.comet_sections.badge ? "verified" : "not-verified"; } catch { }
          if (!adResult["page_verified"]) adResult["page_verified"] = "";
          try { adResult["news_feed_description"] = post.data.node.comet_sections.content.story.attachments[0].comet_footer_renderer.attachment.description.text } catch { }
          try { if (!adResult["news_feed_description"]) adResult["news_feed_description"] = post.data.node.comet_sections.content.story.attachments[0].comet_footer_renderer.attachment.action_links[0].link_description; } catch { }
          if (!adResult["news_feed_description"]) adResult["news_feed_description"] = "";
          if (adResponse.indexOf('card_title') !== -1 && format_data.type !== 13) {
            let otherMultimedia;
            let title;
            let extraImage;
            try { extraImage = post.data.node.comet_sections.content.story.comet_sections.message_container.story.attachments[0].style_list[0]; } catch { }
            const cardImages = post.data.node.comet_sections.content.story.attachments[0].styles.attachment.subattachments;
            const urlsImage = cardImages.map((cardImage) => cardImage.multi_share_media_card_renderer.attachment.media.image.uri);
            urlsImage.splice(0, 1);
            otherMultimedia = urlsImage.join('||,');
            try {
              if (extraImage !== "multi_share_no_end_card") {
                let etcImage = post.data.node.comet_sections.content.story.attachments[0].styles.attachment.media.card_image.uri;
                otherMultimedia = otherMultimedia + '||,' + etcImage;
              }
            } catch { }
            adResult["other_multimedia"] = otherMultimedia;
            adResult["type"] = 'IMAGE';
            adResult['image_video_url'] = post.data.node.comet_sections.content.story.attachments[0].styles.attachment.subattachments[0].multi_share_media_card_renderer.attachment.media.image.uri;
            adResult['call_to_action'] = post.data.node.comet_sections.content.story.attachments[0].styles.attachment.subattachments[0].call_to_action_renderer.action_link.title;
            adResult['destination_url'] = post.data.node.comet_sections.content.story.attachments[0].styles.attachment.subattachments[0].call_to_action_renderer.action_link.url;
            const cardTitle = cardImages.map((cardTitle) => cardTitle.card_title.text);
            title = cardTitle.join('||,');
            try {
              if (extraImage !== "multi_share_no_end_card") {
                let etcTitle = post.data.node.comet_sections.content.story.attachments[0].styles.attachment.source.text;
                title = title + '||,' + 'See more at ' + etcTitle.toUpperCase();
              }
            } catch { }
            adResult["ad_title"] = title;
          } else if (format_data.type === 13) {
            try { extraImage = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.comet_sections.message_container.story.attachments[0].style_list[0]; } catch { }
            const cardImages = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.subattachments;
            const urlsImage = cardImages.map((cardImage) => cardImage.multi_share_media_card_renderer.attachment.media.image.uri);
            urlsImage.splice(0, 1);
            otherMultimedia = urlsImage.join('||,');
            try {
              if (extraImage !== "multi_share_no_end_card") {
                let etcImage = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.media.card_image.uri;
                otherMultimedia = otherMultimedia + '||,' + etcImage;
              }
            } catch { }
            adResult["other_multimedia"] = otherMultimedia;
            const cardTitle = cardImages.map((cardTitle) => cardTitle.card_title.text);
            title = cardTitle.join('||,');
            try {
              if (extraImage !== "multi_share_no_end_card") {
                let etcTitle = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.source.text;
                title = title + '||,' + 'See more at ' + etcTitle.toUpperCase();
              }
            } catch { }
            adResult["ad_title"] = title;
            adResult["type"] = 'IMAGE';
            adResult['image_video_url'] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.subattachments[0].multi_share_media_card_renderer.attachment.media.image.uri;
            adResult['call_to_action'] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.subattachments[0].call_to_action_renderer.action_link.title;
            adResult['destination_url'] = post.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.subattachments[0].call_to_action_renderer.action_link.url;
          } else {
            adResult["other_multimedia"] = "";
          }
          adResult["ad_position"] = "FEED";
          adResult["side_url"] = "Not implemented yet";
          adResult["category"] = "No category";
          adResult["ip_address"] = getUserIp();
          adResult["city"] = getUserCity();
          adResult["state"] = getUserState();
          adResult["country"] = getUserCountry();
          // adResult["facebook_id"] = user_ID;
          adResult["lower_age"] = getLowerAdAge();
          adResult["upper_age"] = getUpperAdAge();
          adResult["version"] = getVersion();
          adResult["platform"] = getPlatform();
          adResult["first_seen"] = getFirstSeen().toString();
          adResult["last_seen"] = getLastSeen().toString();
          if (!adResult["destination_url"]) adResult["call_to_action"] = "";
          var pDate = await postDate(adResult.ad_url, adResult.ad_id, format_data);
          if (pDate === undefined) {
            adResult["post_date"] = "";
          }
          else {
            adResult["post_date"] = pDate;
          }
          //console.log(JSON.stringify(adResult));
          sendPost(adResult);
        }
      } catch (e) { }
    }
  } catch (error) { console.error(error) }
}

document.addEventListener('XHR_INTERCEPTED', handleXhrIntercepted);

async function postDate(ad_url, ad_id, format_data) {
  const response = await fetch(ad_url, {
    method: 'GET',
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-cache',
      'Accept': 'text/html'
    }
  });

  const postPage = await response.text();
  const regPostDate = new RegExp(`"creation_time":(\\d*),.*${ad_id}`);
  try {
    const postDate = postPage.match(regPostDate)[1];
    return postDate ? postDate : "";
  }
  catch (e) {
    try {
      if (format_data.video_id) {
        try {
          const regPostDatevideo = new RegExp(`"creation_time":(\\d*),.*${format_data.video_id}`);
          const postDatevideo = postPage.match(regPostDatevideo)[1];
          return postDatevideo ? postDatevideo : "";
        }
        catch { return ""; }
      }
    } catch { return "" };
  }
}

async function sendPost(post) {
  if(post.image_video_url.includes('.mpd')) return;

  if (post?.type === "VIDEO" && !post?.views){
    const likes = post?.likes;
    const shares = post?.share;
    const comments = post?.comment;
    console.log(likes,shares,comments)
    const views = calculateViews(likes, shares, comments);
    post.views = views;
  }
  
  if(post.views) {
    let adbudget = fbAdBudget(post.views);
    post['lowerBudget'] = adbudget[0]
    post['upperBudget'] = adbudget[1]
  }
  try {
    const response = await fetch(`${powerAdSpyApi}metaAdsData`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(post)
    });
  } catch (error) { }
}

async function sendUserRequestPost(post) {
  try {
    const response = await fetch(`${powerAdSpyApi}adspyAd`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(post)
    });
    var message = await response.text();
    if (
      message.includes("adsData added successfully") ||
      message.includes("Duplicate Ad found")
    ) {
      emptyStatus = 1;
    }
  } catch (error) { }
}

function sendEmptyData() {
  let emptyResult = {
    "code": 400, "type": "", "view_count": "", "category": "No Category", "post_owner": "", "ad_title": "",
    "news_feed_description": "", "likes": "0", "share": "0", "comment": "0", "platform": 10, "call_to_action": "",
    "image_url_original": "", "image_video_url": "", "gender": "", "male_count": 0, "female_count": 0,
    "side_url": "Not implemented yet", "ad_id": "", "post_date": "", "first_seen": "", "last_seen": "", "country": [],
    "lower_age": "", "upper_age": "", "post_owner_image": "", "ad_position": "", "ad_text": "", "ad_url": "",
    "version": "3.0.8", "destination_url": "", "comments_data": [], "keyword_status": 4, "user_request_id": 0, "keyword_id": 0,
    "verified": 0, "user_request_value": 1, "redirects": [], "outgoing_url": []
  }

  chrome.storage.local.get('UserRequest', function (EmptyrequestResult) {
    emptyResult['user_request_id'] = EmptyrequestResult.UserRequest.data[0].id;
    if (EmptyrequestResult.UserRequest.data[0].keywords) {
      emptyResult['user_request_value'] = 1;
    } else {
      emptyResult['user_request_value'] = 2;
    }
    sendUserRequestPost(emptyResult);
  });
}

function AnalysePostdata(post_raw_data) {
  try {
    return checkPostData(post_raw_data)
  } catch (error) {
    return null
  }
}

function checkPostData(post_raw_data) {
  var data = {}
  if ((post_raw_data?.data?.node?.sponsored_data?.__typename === "SponsoredData") || (post_raw_data?.data?.node?.lbl_sp_data?.__typename === "SponsoredData")) {
    var content = post_raw_data["data"]["node"]["comet_sections"]["content"]
    var comet_sections = post_raw_data["data"]["node"]["comet_sections"]
    var creative = content["story"]["attachments"][0]["styles"]["attachment"]
    var __typename = creative['media'] ? creative['media']['__typename'] : null
    var __typename2 = content["story"]["attachments"][0]["styles"]['__typename']
    if (__typename === 'StoryAttachmentMultiShareStyleRenderer' || __typename2 === 'StoryAttachmentMultiShareStyleRenderer') { // è½®æ’­å›¾ç±»åž‹
      var res = type_three(creative["subattachments"])
      data['card_list'] = res.card_list
      var flag = res.flag;
      if (flag === 1) {
        data["is_video"] = 1
      }
      data['type'] = 3
    } else if (__typename === "StoryAttachmentAlbumFrameStyleRenderer" || __typename2 === "StoryAttachmentAlbumFrameStyleRenderer") {
      data['image_list'] = type_five(creative[Object.keys(creative)[Object.keys(creative).length - 1]]["nodes"])
      data['type'] = 5
    } else if (__typename === 'StoryAttachmentAlbumStyleRenderer' || __typename2 === 'StoryAttachmentAlbumStyleRenderer') {
      data['image_list'] = type_four(creative["all_subattachments"]["nodes"])
      data['type'] = 4
    } else if (__typename === 'Video' || __typename2 === "Video") {
      var type_two_res = type_two(creative)
      data['video_preview_image_url'] = type_two_res.video_preview_image_url
      data["video_url"] = type_two_res.video_url
      data["video_id"] = type_two_res.video_id
      data['type'] = 2
    } else {
      data['type'] = 1
      var type_one_res = type_one(__typename, __typename2, creative, content)
      data['image_url'] = type_one_res.image_url
      data['image_width'] = type_one_res.image_width
      data['image_height'] = type_one_res.image_height
      data['raw_cta_url'] = type_one_res.raw_cta_url
      data["title"] = type_one_res.title
      data["body"] = type_one_res.body
    }
    if(!data['comment_count']) data['comment_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.total_comment_count;
    if(!data['comment_count']) data['comment_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.total_comment_count
    if(!data['comment_count']) data['comment_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comment_rendering_instance?.comments?.total_count;
    if(!data['comment_count']) data['comment_count'] = comet_sections?.feedback.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comment_rendering_instance?.comments?.total_count
    if(!data['comment_count']) data['comment_count'] = comet_sections?.feedback?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.comments_count_summary_renderer?.feedback?.comment_rendering_instance?.comments?.total_count
    if(!data['like_count']) data['like_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback?.if_viewer_cannot_see_seen_by_member_list?.reaction_count?.count;
    if(!data['like_count']) data['like_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.reaction_count?.count
    if(!data['like_count']) data['like_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.reaction_count?.count
    if(!data['like_count']) data['like_count'] = comet_sections?.feedback?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.reaction_count?.count
    if(!data['like_count']) data['like_count'] = comet_sections?.feedback?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.if_viewer_cannot_see_seen_by_member_list?.reaction_count?.count
    if(!data['share_count']) data['share_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback?.share_count?.count;
    if(!data['share_count']) data['share_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.share_count?.count
    if(!data['share_count']) data['share_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.share_count?.count
    if(!data['share_count']) data['share_count'] = comet_sections?.feedback?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.share_count.count
    if (data['type'] === 2) {
      try {
        data['view_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback?.video_view_count;
        if(!data['view_count']) data['view_count'] = comet_sections?.feedback?.story?.comet_feed_ufi_container?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.video_view_count
      if(!data['view_count']) data['view_count'] = comet_sections?.feedback?.story?.story_ufi_container?.story?.feedback_context?.feedback_target_with_context?.comet_ufi_summary_and_actions_renderer?.feedback?.video_view_count
      } catch (error) { }
    }
    var page = comet_sections["context_layout"]["story"]["comet_sections"]["actor_photo"]["story"]["actors"][0]
    // page
    data['page_id'] = page["id"]
    data['page_name'] = page["name"]
    data['page_profile_url'] = page["profile_url"]
  } else if (post_raw_data.data.viewer.news_feed.edges[0].category === 'SPONSORED') {
    data['like_count'] = post_raw_data?.data?.viewer?.news_feed?.edges[0]?.node?.comet_sections?.feedback?.story?.feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback?.reaction_count?.count;
    if(!data['like_count']) data['like_count'] = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.feedback.story.comet_feed_ufi_container.story.story_ufi_container.story.feedback_context.feedback_target_with_context.comet_ufi_summary_and_actions_renderer.feedback.reaction_count.count
    data['comment_count'] = post_raw_data?.data?.viewer?.news_feed?.edges[0]?.node?.comet_sections?.feedback?.story?.feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.total_comment_count;
    if(!data['comment_count']) data['comment_count'] = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.feedback.story.comet_feed_ufi_container.story.story_ufi_container.story.feedback_context.feedback_target_with_context.total_comment_count;
    data['share_count'] = post_raw_data?.data?.viewer?.news_feed?.edges[0]?.node.comet_sections?.feedback?.story?.feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback?.share_count?.count;
    if(!data['share_count']) post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.feedback.story.comet_feed_ufi_container.story.story_ufi_container.story.feedback_context.feedback_target_with_context.comet_ufi_summary_and_actions_renderer.feedback.share_count.count;
    try { data['raw_cta_url'] = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.story_attachment_link_renderer.attachment.web_link.url; } catch { }
    let videoType = post_raw_data?.data?.viewer?.news_feed?.edges[0]?.node?.comet_sections?.feedback?.story?.feedback_context?.feedback_target_with_context?.ufi_renderer?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback?.associated_video;
    if(!videoType) videoType = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.feedback.story.comet_feed_ufi_container.story.story_ufi_container.story.feedback_context.feedback_target_with_context.comet_ufi_summary_and_actions_renderer.feedback.associated_video
    if (videoType === null) {
      let cardType = null;
      try { cardType = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.subattachments[0].card_title; } catch { }
      if (!cardType) {
        data['type'] = 1;
        data['image_url'] = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.media.flexible_height_share_image.uri;
      } else {
        data['type'] = 13;
      }
    } else {
      data['type'] = 2;
      data['raw_cta_url'] = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].comet_footer_renderer.attachment.call_to_action_renderer.action_link.url;
      data['video_url'] = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.content.story.attachments[0].styles.attachment.media.browser_native_hd_url;
    }
    data['page_name'] = post_raw_data.data.viewer.news_feed.edges[0].node.comet_sections.content.story.comet_sections.context_layout.story.comet_sections.actor_photo.story.actors[0].name;
  }
  return data
}

function type_one(typename, typename2, creative, content) {
  var image_url;
  var image_width;
  var image_height;
  var raw_cta_url;
  var title;
  var body;
  if (typename === 'StoryAttachmentPhotoStyleRenderer' || typename2 === 'StoryAttachmentPhotoStyleRenderer') {
    image_url = creative["media"]["photo_image"]["uri"]
    image_width = creative["media"]["photo_image"]["width"]
    image_height = creative["media"]["photo_image"]["height"]
    raw_cta_url = ''
    title = ''
    body = ''
  } else {
    var image = creative["media"]["flexible_height_share_image"] || creative["media"]["large_share_image"] || creative["media"]["image"] || creative["media"]["photo_image"];
    image_url = image["uri"]
    image_width = image["width"]
    image_height = image["height"]
    if (content["story"]["attachments"][0]["comet_footer_renderer"]) {
      raw_cta_url = content["story"]["attachments"][0]["comet_footer_renderer"]["attachment"]["target"]["external_url"]
      title = content["story"]["attachments"][0]["comet_footer_renderer"]["attachment"]["title_with_entities"]["text"]
      body = content["story"]["attachments"][0]["comet_footer_renderer"]["attachment"]["description"]["text"]
    }
  }
  return { image_url: image_url, image_width: image_width, image_height: image_height, raw_cta_url: raw_cta_url, title: title, body: body }
}

function type_two(creative) {
  var video_preview_image_url = creative["media"]["thumbnailImage"] ? creative["media"]["thumbnailImage"]["uri"] : creative["media"]["photo_image"]["uri"]
  var video_url = creative["media"]["browser_native_hd_url"] ? creative["media"]["browser_native_hd_url"] : creative["media"]["playable_url"];
  var video_id = creative["media"]["videoId"];

  return { video_preview_image_url: video_preview_image_url, video_url: video_url, video_id: video_id }
}

function type_three(creative_subattachments) {
  var card_list = []
  var subattachments = creative_subattachments
  var flag = 0;
  subattachments.forEach(subattachment => {
    var creative_url;
    if (subattachment["multi_share_media_card_renderer"]["attachment"]["media"]["__typename"] === "Video") {
      creative_url = subattachment["multi_share_media_card_renderer"]["attachment"]["media"]["playable_url"]
      flag = 1;
    } else {
      creative_url = subattachment["multi_share_media_card_renderer"]["attachment"]["media"]["image"] ? subattachment["multi_share_media_card_renderer"]["attachment"]["media"]["image"]["uri"] : ""
    }

    var _d = {
      title: subattachment["card_title"]["text"],
      body: subattachment["card_description"]["text"],
      creative_url: creative_url
    }
    if (subattachment["story_attachment_link_renderer"]["attachment"]["web_link"]) {
      _d.raw_cta_url = subattachment["story_attachment_link_renderer"]["attachment"]["web_link"]["url"]
    }
    var call_to_action_renderer = subattachment["call_to_action_renderer"]
    if (call_to_action_renderer) {
      _d.cta_text = subattachment["call_to_action_renderer"]["action_link"]["title"]
      _d.cta_type = subattachment["call_to_action_renderer"]["action_link"]["link_type"]
    }
    card_list.push(_d)
  })
  return { card_list: card_list, flag: flag }
}

function type_four(creative_nodes) {
  var type_four_list = []
  var type_four_nodes = creative_nodes
  type_four_nodes.forEach(node => {
    type_four_list.push(node["media"]["image"]["uri"])
  })
  return type_four_list
}

function type_five(creative_nodes) {
  var type_five_list = []
  var type_five_nodes = creative_nodes

  type_five_nodes.forEach(node => {
    type_five_list.push(node["media"]["image"]["uri"])
  })
  return type_five_list;
}