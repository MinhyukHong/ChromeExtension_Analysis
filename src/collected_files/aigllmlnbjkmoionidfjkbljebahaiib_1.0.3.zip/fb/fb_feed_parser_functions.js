/*global birthday */
const DOMAINS = ['.academy', '.accountant', '.accountants', '.active', '.actor', '.adult', '.aero', '.agency', '.airforce', '.apartments',
  '.app', '.archi', '.army', '.associates', '.asia', '.attorney', '.auction', '.audio', '.autos', '.biz', '.cat', '.com', '.coop', '.co',
  '.dance', '.edu', '.eus', '.family', '.gov', '.info', '.int', '.jobs', '.mil', '.mobi', '.museum', '.name', '.net', '.one', '.ong',
  '.onl', '.online', '.ooo', '.org', '.organic', '.partners', '.parts', '.party', '.pharmacy', '.photo', '.photography', '.photos',
  '.physio', '.pics', '.pictures', '.feedback', '.pink', '.pizza', '.place', '.plumbing', '.plus', '.poker', '.porn', '.post', '.press',
  '.pro', '.productions', '.prof', '.properties', '.property', '.qpon', '.racing', '.recipes', '.red', '.rehab', '.ren', '.rent',
  '.rentals', '.repair', '.report', '.republican', '.rest', '.review', '.reviews', '.rich', '.site', '.tel', '.trade', '.travel', '.xxx',
  '.xyz', '.yoga', '.zone', '.ninja', '.art', '.moe', '.dev'];
const REGION_DOMAINS = ['.ac', '.ad', '.ae', '.af', '.ag', '.ai', '.al', '.am', '.an', '.ao', '.aq', '.ar',
  '.as', '.at', '.au', '.aw', '.ax', '.az', '.ba', '.bb', '.bd', '.be', '.bf', '.bg', '.bh', '.bi', '.bj', '.bm', '.bn', '.bo', '.br',
  '.bs', '.bt', '.bv', '.bw', '.by', '.бел', '.bz', '.ca', '.cc', '.cd', '.cf', '.cg', '.ch', '.ci', '.ck', '.cl', '.cm', '.cn',
  '.cr', '.cu', '.cv', '.cx', '.cy', '.cz', '.de', '.dj', '.dk', '.dm', '.do', '.dz', '.ec', '.ee', '.eg', '.er', '.es', '.et', '.eu',
  '.fi', '.fj', '.fk', '.fm', '.fo', '.fr', '.ga', '.gb', '.gd', '.ge', '.gf', '.gg', '.gh', '.gi', '.gl', '.gm', '.gn', '.gp', '.gq',
  '.gr', '.gs', '.gt', '.gu', '.gw', '.gy', '.hk', '.hm', '.hn', '.hr', '.ht', '.hu', '.id', '.ie', '.il', '.im', '.in', '.io', '.iq',
  '.ir', '.is', '.it', '.je', '.jm', '.jo', '.jp', '.ke', '.kg', '.kh', '.ki', '.km', '.kn', '.kp', '.kr', '.kw', '.ky', '.kz', '.la',
  '.lb', '.lc', '.li', '.lk', '.lr', '.ls', '.lt', '.lu', '.lv', '.ly', '.ma', '.mc', '.md', '.me', '.mg', '.mh', '.mk', '.ml', '.mm',
  '.mn', '.мон', '.mo', '.mp', '.mq', '.mr', '.ms', '.mt', '.mu', '.mv', '.mw', '.mx', '.my', '.mz', '.na', '.nc', '.ne', '.nf', '.ng',
  '.ni', '.nl', '.no', '.np', '.nr', '.nu', '.nz', '.om', '.pa', '.pe', '.pf', '.pg', '.ph', '.pk', '.pl', '.pm', '.pn', '.pr', '.ps',
  '.pt', '.pw', '.py', '.qa', '.re', '.ro', '.rs', '.срб', '.ru', '.рф', '.rw', '.sa', '.sb', '.sc', '.sd', '.se', '.sg', '.sh', '.si',
  '.sj', '.sk', '.sl', '.sm', '.sn', '.so', '.sr', '.st', '.su', '.sv', '.sy', '.sz', '.tc', '.td', '.tf', '.tg', '.th', '.tj', '.tk',
  '.tl', '.tm', '.tn', '.to', '.tp', '.tr', '.tt', '.tv', '.tw', '.tz', '.ua', '.укр', '.ug', '.uk', '.us', '.uy', '.uz', '.va', '.vc',
  '.ve', '.vg', '.vi', '.vn', '.vu', '.wf', '.ws', '.ye', '.yt', '.za', '.zm', '.zw'];

const KILO_REGION = ['k', 'ಸಾ', 'हज़ार'];

const MEGA_REGION = ['m', 'ಲ', 'लाख'];

let isProcessingGeoData = false;
let userDataProcessing = false;
let videoUrlProcessing = false;
let tempuserid = null;
let failResponse = false;

function getVersion() {
  return version;
}

const sendDefaultAttempts = 20;

function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return '';
  }
}

function getFacebookId() {
  return user_ID;
}

function finalUrl(adRoot, adLinkURL) {
  const destUrl = { "url": adLinkURL };
  const reqJson = {
    async: true,
    crossDomain: true,
    url: "https://postowner.poweradspy.com/get-post-owner",
    method: 'POST',
    rejectUnauthorized: false,
    requestCert: true,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-cache'
    },
    processData: false,
    data: JSON.stringify(destUrl)
  };

  if (!($(adRoot).attr('data-desturl-promise') === 'pending')) {
    $.ajax(reqJson)
      .done((destUrlSrc) => {
        if (destUrlSrc.code === 200) {
          $(adRoot).attr('data-fb-intel-destination_url', destUrlSrc.final_url);
          $(adRoot).attr('data-fb-intel-post_owner', destUrlSrc.post_owner);
          $(adRoot).attr('data-desturl-promise', 'fulfilled');
        }
      })
      .fail(() => {
        $(adRoot).attr('data-desturl-promise', 'fulfilled');
      });
    $(adRoot).attr('data-desturl-promise', 'pending');
  }
}

function getOwner(adRoot) {
  let owner;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    const ownerElement = $(adRoot).find('a > strong');
    owner = ownerElement.length > 0 ? ownerElement.text() : $(adRoot).find('strong a').first().text();
  } else if ($(adRoot).attr('data-fb-intel-ad-type') === 'marketplace') {
    var postOwnerData = $(adRoot).find('.xu06os2 span.x193iq5w span.x1j85h84').first().text();
    var destUrl = $(adRoot).attr('data-fb-intel-destination_url')
    if (destUrl) {
      destUrl = decodeURIComponent(destUrl);
      finalUrl(adRoot, destUrl);
    }
    return postOwnerData;
  } else {
    let domainName = $(adRoot).find('.x1kyqaxf').text();

    if (domainName.includes('http')) {
      domainName = domainName.split('https://')[1];
    }

    if (domainName.includes('www.')) {
      domainName = domainName.split('www.')[1];
    }

    DOMAINS.forEach((domain) => {
      if (domainName.includes(domain)) {
        domainName = domainName.split(domain)[0];
        owner = domainName;
      }
    });

    REGION_DOMAINS.forEach((domain) => {
      if (domainName.includes(domain)) {
        domainName = !domainName.split(domain)[1] || domainName.split(domain)[1].includes('/')
          ? domainName.split(domain)[0] : domainName.match(/([^.\s]+)[^.\s]+$/)[0];
        owner = domainName;
      }
    });

    if (domainName.includes('.')) {
      owner = domainName.match(/([^.\s]+)[^.\s]+$/)[0];
    }
  }

  return owner;
}

function getTitle(adRoot) {
  let title = "";
  if (!USERNAME)
    USERNAME = $('.x1iyjqo2 ul li').first().text();

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    if ($(adRoot).find('ul').length > 0) {
      const titleElements = $(adRoot).find('ul li span.x193iq5w span.x1lliihq div[id*="jsc"]')
      if (titleElements.length > 1) {
        const ad_title = [...titleElements].map((element) => $(element).text());
        ad_title.splice(0, 1);
        title = ad_title.join('||,');
      }
      $(adRoot).attr('data-slider', 'slider');
    } else if ($(adRoot).find('.x1n2onr6 .x10wlt62.x6ikm8r a .x1ok221b span.x1n2onr6.x1j85h84').length > 0) {
      title = $(adRoot).find('.x1n2onr6 .x10wlt62.x6ikm8r a .x1ok221b span.x1n2onr6.x1j85h84').text().trim();
    }
  } else if ($(adRoot).attr('data-fb-intel-ad-type') === 'side') {
    const titleElement = $(adRoot).find('.xu06os2.x1ok221b .x1n2onr6');
    title = titleElement.length > 0
      ? titleElement.first().text().trim()
        ? titleElement.first().text().trim() : ""
      : "";
  } else if ($(adRoot).attr('data-fb-intel-ad-type') === 'marketplace') {
    title = $(adRoot).find('.xu06os2.x1ok221b:nth-child(2)').text();
  }
  if (USERNAME.includes(title)) return '';

  return title;
}

function getAdText(adRoot) {
  let adText;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    const openFullAdText = $(adRoot).find('.x1i10hfl:contains("See more")');

    if (openFullAdText.length > 0) {
      openFullAdText.click();
      return;
    }

    if (!openFullAdText.length) {
      const textElement = $(adRoot).find('div[data-ad-preview="message"]');
      adText = textElement.length > 0 ? textElement.text() : "";
    }
  } else {
    adText = "";
  }

  return adText;
}

function getAdUrl(adRoot) {
  let adUrl;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    let ad_id = $(adRoot).attr('data-fb-intel-ad_id');
    if (ad_id) adUrl = 'https://www.facebook.com/' + ad_id;
  } else {
    adUrl = "";
  }

  return adUrl;
}

function getNewsFeedDescription(adRoot) {
  let newsFeedDescription;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    if ($(adRoot).attr('data-slider') === 'slider') {
      const descriptionElement = $(adRoot).find('ul span.d2edcug0 span.g0qnabr5').first();
      newsFeedDescription = descriptionElement.length > 0
        ? descriptionElement.text()
          ? descriptionElement.text() : ""
        : "";
    } else {
      const descriptionElement = $(adRoot).find('div.enqfppq2 span.d2edcug0 span.g0qnabr5');
      newsFeedDescription = descriptionElement.length > 0
        ? descriptionElement.text()
          ? descriptionElement.text() : ""
        : "";
    }
  } else {
    newsFeedDescription = "";
  }

  return newsFeedDescription;
}

function getPageVerified(adRoot) {
  let pageVerified;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    pageVerified = $(adRoot).find('div[aria-label="Verified"]').length ? 'verified' : 'not-verified';
  } else {
    pageVerified = "";
  }

  return pageVerified;
}

function getCategory(adRoot) {
  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    let categoryUrlPost;

    if ($(adRoot).find('h4 span.xt0psk2 a').length > 0) {
      categoryUrlPost = $(adRoot).find('h4 span.xt0psk2 a').attr('href');
    } else if ($(adRoot).find('strong a').length > 0) {
      categoryUrlPost = $(adRoot).find('strong a').first().attr('href');
    } else {
      //categoryUrlPost = $(adRoot).find('div.nc684nl6 a.gpro0wi8').first().attr('href').split('apps.').join('');
      //categoryUrlPost = $(adRoot).find('h4 a.lrazzd5p').first().attr('href').split('apps.').join('');
    }

    if (categoryUrlPost) {
      const reqJson = {
        async: true,
        crossDomain: true,
        url: categoryUrlPost,
        method: 'GET',
        headers: {
          'content-type': 'application/json',
          'cache-control': 'no-cache',
          'Accept': 'text/html',
        },
        processData: false,
      };

      if (!($(adRoot).attr('data-category-promise') === 'pending')) {
        $.ajax(reqJson)
          .done((advertiserPage) => {
            const categoryPost = getBetween(advertiserPage, 'category_name":"', '","verification_status').replace('\\', '');
            $(adRoot).attr('data-fb-intel-category', categoryPost ? categoryPost : 'No category');
            $(adRoot).attr('data-category-promise', 'fulfilled');
          })
          .fail(() => {
            $(adRoot).attr('data-fb-intel-category', 'No category');
            $(adRoot).attr('data-category-promise', 'fulfilled');
          });
        $(adRoot).attr('data-category-promise', 'pending');
      }
    }
  } else {
    return 'No category';
  }
}

function getAdVideoUrl(adRoot) {

  const videoAdUrl = $(adRoot).attr('data-fb-intel-ad_url');
  const adType = $(adRoot).attr('data-fb-intel-type');
  if (adType === 'VIDEO') {
    if (!videoAdUrl) {
      return
    }

    const watchVideoId = /^https?:\/\/(?:www\.)?facebook\.com\/watch\/\?v=(?<videoId>[\d]+).*$/i.exec(videoAdUrl);
    const videosVideoId = /^https:\/\/www\.facebook\.com\/(.+w?)\/videos\/(?<videoId>.+d?).$/i.exec(videoAdUrl);
    const videoIdMatch = watchVideoId || videosVideoId;
    if (videoIdMatch) {
      const videoId = videoIdMatch.groups.videoId
      $.get(`https://www.facebook.com/share/dialog/?app_id=${user_ID}&id=${videoId}`, function (content) {
        let videoUrl;
        let parts = content.split('sd_src:"');
        parts[1] === undefined && (parts = content.split('sd_src":"'));
        parts[1] !== undefined && ((parts = parts[1].split('"')), (videoUrl = parts[0]), (videoUrl = videoUrl.replace(/\\\//g, '/')));
        if (videoUrl) {
          $(adRoot).attr('data-fb-intel-image_video_url', videoUrl);
        } else {
          $(adRoot).attr('data-fb-intel-image_video_url', "");
        }
      })
    }
    return
  }

  let imageVideoUrl;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    if ($(adRoot).attr('data-slider') === 'slider') {
      imageVideoUrl = $(adRoot).attr('data-fb-intel-type') === 'IMAGE'
        ? $(adRoot).find('ul li.om3e55n1 img').first().attr('src')
        : "";
    } else {
      imageVideoUrl = $(adRoot).attr('data-fb-intel-type') === 'IMAGE'
        ? $(adRoot).find('.x6s0dn4 .xqtp20y img').attr('src')
        : "";
    }
  } else if ($(adRoot).attr('data-fb-intel-ad-type') === 'marketplace') {
    var postownerImage = $(adRoot).attr('data-fb-intel-post_owner_image');
    if (!postownerImage) {
      return null;
    }
    if ($(adRoot).find('ul li img').length > 0 || $(adRoot).find('ul.x78zum5.x1q0g3np li.x1n2onr6 img').length > 0) {
      return null;
    } else {
      imageVideoUrl = $(adRoot).find('img').attr('src');
    }
  } else if ($(adRoot).attr('data-fb-intel-ad-type') === 'side') {
    imageVideoUrl = $(adRoot).find('img').attr('src');
  }
  if (postownerImage === imageVideoUrl) return null;
  return imageVideoUrl;
}

function getOtherMultimedia(adRoot) {
  let otherMultimedia;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    if ($(adRoot).attr('data-slider') === 'slider') {
      if ($(adRoot).attr('data-fb-intel-type') === 'IMAGE') {
        const imageElements = $(adRoot).find('ul li.x1n2onr6 img');
        const urlsImage = [...imageElements].map((element) => element.getAttribute('src'));
        urlsImage.splice(0, 1);
        otherMultimedia = urlsImage.join('||,');
      } else {
        otherMultimedia = "";
      }
    } else {
      otherMultimedia = "";
    }
  } else {
    otherMultimedia = "";
  }

  return otherMultimedia;
}

function getLikesCount(adRoot) {
  let likesCount;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    likesCount = $(adRoot).find('.x4k7w5x span.xt0b8zv span.x16hj40l');
    likesCount = likesCount.length > 0 ? transformCount(likesCount.text().toLowerCase()) : 0;
  } else {
    likesCount = 0;
  }
  return likesCount;
}

const isNumber = function (str) {
  const pattern = /^\d+$/;
  return pattern.test(str);
};

function getSharesCount(adRoot) {
  let sharesCount;
  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    sharesCount = $(adRoot).find('.x1n2onr6 .xnfveip .x193iq5w.xeuugli:contains("hare")');
    if (!sharesCount.length) {
      sharesCount = $(adRoot).find('.x1n2onr6 .xnfveip .x193iq5w.xeuugli:contains("ಹಂಚಿಕೆ")');
    }
    if (!sharesCount.length) {
      sharesCount = $(adRoot).find('.x1n2onr6 .xnfveip .x193iq5w.xeuugli:contains("शेयर")');
    }
    sharesCount = sharesCount.length > 0 ? transformCount(sharesCount.text().toLowerCase().split(' ')[0]) : 0;
  } else {
    sharesCount = 0;
  }

  return sharesCount;
}

function transformCount(count) {
  const charKilo = 'k';
  const charMega = 'm';
  const kilo = 1000;
  const mega = 1000000;

  for (const KILO of KILO_REGION) {
    if (count.includes(KILO)) {
      return parseFloat(count) * kilo;
    }
  }

  for (const MEGA of MEGA_REGION) {
    if (count.includes(MEGA)) {
      return parseFloat(count) * mega;
    }
  }

  return count;
}

function getCommentsCount(adRoot) {
  let commentsCount;
  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    commentsCount = $(adRoot).find('.x1n2onr6 .xnfveip .x193iq5w.xeuugli:contains("ommen")');
    if (!commentsCount.length) {
      commentsCount = $(adRoot).find('.x1n2onr6 .xnfveip .x193iq5w.xeuugli:contains("ಒಕ್ಕಣೆ")');
    }
    if (!commentsCount.length) {
      commentsCount = $(adRoot).find('.x1n2onr6 .xnfveip .x193iq5w.xeuugli:contains("कमेंट")');
    }
    commentsCount = commentsCount.length > 0 ? transformCount(commentsCount.text().toLowerCase().split(' ')[0]) : 0;
  } else {
    commentsCount = 0;
  }

  return commentsCount;
}

function getPlatform() {
  return Platform;
}

function transformFacebookUrl(url) {
  if (url.includes('https://l.facebook.com/l.php?u=')) {
    url = url.replace('https://l.facebook.com/l.php?u=', '');
    if (url.includes('&h=AT')) {
      const tempUrl = url.split('&h=AT');
      url = tempUrl[0];
    }
  } else if (url.includes('https://ad.doubleclick.net')) {
    url = url.split('https')[2];
    url = `https${url}`;
  }

  return url.includes('http') ? url : null;
}

function getDestinationUrl(adRoot) {
  let adLinkURL;
  try {
    if ($(adRoot).attr("data-fb-intel-ad-type") === "feed" ||
      $(adRoot).attr("data-fb-intel-ad-type") === "marketplace") {
      adLinkURL = $(adRoot)
        .find('a[href^="https://l.facebook.com/l.php?u=http"]')
        .first()
        .attr("href");
      if (adLinkURL) {
        return transformFacebookUrl(adLinkURL);
      }
      adLinkURL = $(adRoot)
        .find('a[href^="https://l.facebook.com/l.php?u="]')
        .first()
        .attr("href");
      if (adLinkURL) {
        return adLinkURL.includes("http") ? adLinkURL : null;
      }
      adLinkURL = $(adRoot)
        .find('a[target="_blank"]')
        .first()
        .attr("href");
      if (adLinkURL) {
        return adLinkURL.includes("http") ? adLinkURL : null;
      }
      adLinkURL = $(adRoot)
        .find('a[href^="http"]')
        .first()
        .attr("href");
      if (adLinkURL) {
        return adLinkURL.includes("http") ? adLinkURL : null;
      }
      return null;
    } else if ($(adRoot).attr("data-fb-intel-ad-type") === "side") {
      adLinkURL = $(adRoot)
        .find('a[href^="https://l.facebook.com/l.php?u=http"]')
        .first()
        .attr("href");
      if (adLinkURL) {
        return transformFacebookUrl(adLinkURL);
      }
      adLinkURL = $(adRoot)
        .find('a[href^="https://l.facebook.com/l.php?u="]')
        .first()
        .attr("href");
      if (adLinkURL) {
        return adLinkURL.includes("http") ? adLinkURL : null;
      }
      adLinkURL = $(adRoot)
        .find('a[target="_blank"]')
        .first()
        .attr("href");
      if (adLinkURL) {
        return adLinkURL.includes("http") ? adLinkURL : null;
      }
      adLinkURL = $(adRoot).attr("href");
      if (adLinkURL) {
        return adLinkURL.includes("http") ? adLinkURL : null;
      }

    }
    // allow anyway if still null and attempts > 7
    if (!adLinkURL) {
      adLinkURL = ""; // this will allow save
    }

    return adLinkURL;
  } catch (e) {
    //adLinkURL="";
    return null;
  }
}

function getCallActionType(adRoot) {
  let callActionType;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    if ($(adRoot).attr('data-slider') === 'slider') {
      callActionType = $(adRoot).find('.tkr6xdv7 a.oajrlxb2.g5ia77u1').attr('aria-label');
      if (!callActionType)
        return "";
    }
    else {
      return null;
    }
  } else {
    callActionType = "";
  }

  return callActionType;
}

function getLowerAdAge() {
  if (birthday === '' || birthday === null || birthday === undefined) {
    return '';
  }
  return birthday.toString();
}

function getUpperAdAge() {
  if (birthday === '' || birthday === null || birthday === undefined) {
    return '';
  }
  return birthday.toString();
}

function getPostOwnerImage(adRoot) {
  let postOwnerImage;

  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    postOwnerImage = $(adRoot).find('image').attr('xlink:href');
  } else if ($(adRoot).attr('data-fb-intel-ad-type') === 'marketplace') {
    postOwnerImage = $(adRoot).find('a[aria-label="brand logo"] img').attr('src');
    if (!postOwnerImage)
      postOwnerImage = $(adRoot).find('.x10l6tqk.x13vifvy img.x1e558r4').attr('src');
  }
  else {
    postOwnerImage = "";
  }
  return postOwnerImage;
}

function getUserIp() {
  return !!geoData.userIP ? geoData.userIP : null;
}

function getUserCity() {
  return !!geoData.userCity ? geoData.userCity : null;
}

function getUserState() {
  return !!geoData.userState ? geoData.userState : null;
}

function getUserCountry() {
  return !!geoData.userCountry ? geoData.userCountry : null;
}

function getFirstSeen() {
  return Date.now();
}

function getLastSeen() {
  return Date.now();
}

function getPostDate(adRoot) {
  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    const adUrl = $(adRoot).attr('data-fb-intel-ad_url');
    const adId = $(adRoot).attr('data-fb-intel-ad_id');

    if (!adUrl || !adId) {
      return;
    }

    if (adUrl) {
      const reqJson = {
        async: true,
        crossDomain: true,
        url: adUrl,
        method: 'GET',
        headers: {
          'content-type': 'application/json',
          'cache-control': 'no-cache',
          'Accept': 'text/html',
        },
        processData: false,
      };

      if (!($(adRoot).attr('data-post-data-promise') === 'pending')) {
        $.ajax(reqJson)
          .done((postPage) => {
            // const adId = $(adRoot).attr('data-fb-intel-ad_id');   
            // if(!adId) return null;                             
            const regPostDate = new RegExp(`"creation_time":(\\d*),.*${adId}`);
            const post_date = postPage.match(regPostDate) ? postPage.match(regPostDate)[1] : 0;
            if (post_date === 0) return null;
            $(adRoot).attr('data-fb-intel-post_date', post_date);
            let actionSrc = getBetween(postPage, 'link_type', '__typename');
            actionSrc = getBetween(actionSrc, ':\"', '\"}');
            $(adRoot).attr('data-fb-intel-call_to_action', actionSrc);
            $(adRoot).attr('data-post-data-promise', 'fulfilled');
          })
          .fail(() => {
            $(adRoot).attr('data-post-data-promise', 'fulfilled');
          });
        $(adRoot).attr('data-post-data-promise', 'pending');
      }
    }
  } else {
    return Date.now();
  }
}

function hashCode(str) {
  return str
    .split('')
    .reduce(
      (prevHash, currVal) =>
        ((prevHash << 5) - prevHash + currVal.charCodeAt(0)) | 0,
      0,
    );
}

function random4DigitNumber() {
  return JSON.stringify(Math.floor(1000 + Math.random() * 9000));
}

function base64ToHex(str) {
  const raw = atob(str);
  let result = '';
  for (let i = 0; i < raw.length; i++) {
    const hex = raw.charCodeAt(i).toString(16);
    result += (hex.length === 2 ? hex : '0' + hex);
  }
  return result;
}

function getAdId(adRoot) {
  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    //enqueueGetAdURL(adRoot[0]);
    //return "";
  } else {
    let splitdata = null;
    let postId = '';
    let adTitle = $(adRoot).attr('data-fb-intel-ad_title');
    let destUrl = $(adRoot).attr('data-fb-intel-destination_url');
    let image = $(adRoot).attr('data-fb-intel-image_video_url');
    destUrl = decodeURIComponent(destUrl);
    if (destUrl.includes("undefined")) return null;
    if (destUrl) {
      splitdata = destUrl.split("?")[0];
    }
    if (image) {
      image = image.split("?")[0];
      image = image.split("/").pop();
    }
    if (adTitle && image) {
      var hashdata = b64_hmac_sha1(paskey, adTitle + splitdata + image);
      postId = base64ToHex(hashdata);
    } else if (splitdata) {
      var hashdata = b64_hmac_sha1(paskey, splitdata);
      postId = base64ToHex(hashdata);
    }
    return postId;
  }
}

function getType(adRoot) {
  if ($(adRoot).find('video').length > 0) {
    return 'VIDEO';
  } else if ($(adRoot).find('div[aria-label="Play video"]').length > 0) {
    return 'VIDEO';
  } else {
    return 'IMAGE';
  }
}

function getPosition(adRoot) {
  if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
    return 'FEED';
  } else if ($(adRoot).attr('data-fb-intel-ad-type') === 'side') {
    return 'SIDE'
  } else {
    return 'MARKETPLACE';
  }
}

function getUndefined() {
  return 'Not implemented yet';
}

//div.fb-intel-ad[data-fb-intel-triaged='no'], div.fb-intel-ad[data-fb-intel-triaged='not-sponsored']
// $("div.fb-intel-ad[data-fb-intel-triaged='no'], div.fb-intel-ad[data-fb-intel-triaged='not-sponsored']")
function hideOrShowAds() {
  if (scrollCounter % 10 === 0) {
    let hideTime = Date.now();
    try {
      chrome.storage.local.get({ issponsored: 'OFF' }, function (result) {
        if (result.issponsored == 'OFF') {
          //$('div[data-fb-intel-triaged="not-sponsored"]').show();
          $('div[data-fb-intel-triaged="not-sponsored"]').show();
        } else {
          // $('div[data-fb-intel-triaged="not-sponsored"]').hide();
          $('div[data-fb-intel-triaged="not-sponsored"]').hide();
          $('div[data-fb-intel-triaged="no"]').hide();
        }
        //  chrome.runtime.sendMessage(null, { "hideTime": Date.now() - hideTime });
      });
    } catch { }
  }
}

function getUserData() {
  if (user_ID) {
    return;
  }

  try {
    const data = document.getElementsByTagName('html')[0].innerHTML;
    user_ID = getBetween(data, 'USER_ID":"', '"');
  } catch (err) {
    if (enableDebugger) {
      debugger;
    }
  }

  if (user_ID !== undefined && user_ID !== '') {
    chrome.storage.local.get('userid', function (result) {
      const userid = result.userid;
      if (userid !== user_ID) {
        chrome.storage.local.set({ userid: user_ID });
      }
    });
  }
}

function buildUpGeoData() {
  if (isProcessingGeoData) {
    return;
  }
  isProcessingGeoData = true;

  if (!geoData.userIP || !geoData.userCity || !geoData.userState || !geoData.userCountry) {
    if (!geoData.userIP) {
      const ourIP = "https://geolocation.poweradspy.com/";
      $.ajax({
        url: ourIP,
        type: "GET",
        async: true,
        success: function (IpResponse) {
          const ourIpResponse = JSON.parse(IpResponse);
          geoData.userIP = ourIpResponse.ip;
          geoData.userCity = ourIpResponse.cityName;
          geoData.userState = ourIpResponse.regionName;
          geoData.userCountry = ourIpResponse.countryName;
          geoData.lastUpdated = Date.now();
          chrome.storage.local.set({ "geoData": geoData });
          isProcessingGeoData = false;
        }
      });
    }
  }
}

async function userDetails() {
  if (userDataProcessing) {
    return;
  }
  userDataProcessing = true;
  
  let userID = user_ID;
  let currentCity = '';
  let profileName = '';
  let otherPlace = '';
  let birthday = '';
  let gender = '';
  let relationshipStatus = '';

  if (userID === '') {
    const data = document.getElementsByTagName('html')[0].innerHTML;
    user_ID = getBetween(data, 'USER_ID":"', '"');
  }

  const adUser = {data: getObject({ facebook_id: user_ID })};
  var userResponse = await PostAPI(adUser, powerAdSpyApi + 'user-chk');
  const obj = JSON.parse(userResponse);
  if (obj.code == 400 || obj.code == 200) {
    const aboutUrl =
      'https://www.facebook.com/profile.php?id=' + userID + '&sk=about';
    const LivingUrl =
      'https://www.facebook.com/' +
      userID +
      '/about?section=living&pnref=about';
    const GenderPageURL =
      'https://www.facebook.com/profile.php?id=' +
      userID +
      '&sk=about&section=contact-info';
    const relationshipURL =
      'https://www.facebook.com/' +
      userID +
      '/about?section=relationship&pnref=about';

    var aboutResponse = await GetAPI(aboutUrl);
    profileName = getBetween(aboutResponse, 'id="pageTitle">', '<');
    if (profileName == '') {
      profileName = getBetween(
        aboutResponse,
        'fb-timeline-cover-name">',
        '<',
      ).replace('&#039;', '\'');
    }
    profileName = profileName.replace(',', '');
    if (profileName == '') {
      profileName = getBetween(
        aboutResponse,
        '"NAME":"',
        '","SHORT_NAME"',
      );
    }
    if (profileName == '') {
      profileName = 'NA';
    }

    birthday = getBetween(
      aboutResponse,
      'Birthday</span></div><div>',
      '</div>',
    ).replace(',', '');
    birthday = birthday.substr(birthday.length - 4, 4);
    const d = new Date();
    const n = d.getFullYear();
    birthday = n - birthday;
    if (isNaN(birthday) || birthday == n) {
      var birthdayResponse = await GetAPI('https://www.facebook.com/' + userID + '/about?section=contact-info');
      birthday = getBetween(
        birthdayResponse,
        '"year":',
        ',"limited_notice"',
      );
      const d = new Date();
      const n = d.getFullYear();
      birthday = n - birthday;
    }
    if (isNaN(birthday) || birthday == n) {
      birthday = 23;
    }

    var genderResponse = await GetAPI(GenderPageURL);
    const genderInfo = getBetween(
      genderResponse,
      'Gender</span>',
      '</span>',
    );
    if (genderInfo.indexOf('Male') != -1) {
      gender = 'Male';
    } else if (genderInfo.indexOf('Female') != -1) {
      gender = 'Female';
    } else if (gender == '') {
      gender = getBetween(
        genderResponse,
        '"gender":"',
        '","is_viewer_friend',
      );
    } else {
      gender = 'NA';
    }

    var relationshipResponse = await GetAPI(relationshipURL);
    relationshipStatus = $(relationshipResponse).find('.x1gan7if .x1iyjqo2 .x126k92a span.xzsf02u').first().text().toLowerCase();
    if (!relationshipStatus) {
      relationshipStatus = getBetween(
        relationshipResponse,
        'class="_vb- _50f5">',
        '<',
      );
      if (relationshipStatus == '') {
        let NewrelationshipStatus = getBetween(
          relationshipResponse,
          '"profile_fields"',
          '"list_item_groups":[],"privacy_scope":{"privacy_scope_renderer"',
        );
        let abc = NewrelationshipStatus.split(':');
        relationshipStatus = abc[abc.length - 1].replace(/[^a-zA-Z ]/g, '');
      }
    }
    if (relationshipStatus.includes("married")) {
      relationshipStatus = "Married";
    } else if (relationshipStatus.includes("single")) {
      relationshipStatus = "Single";
    } else {
      relationshipStatus = '';
    }

    var currentCityResponse = await GetAPI(LivingUrl);
    let NewcurrentCity = getBetween(
      currentCityResponse,
      '"verification_status":',
      '"current_city"',
    );
    currentCity = getBetween(
      NewcurrentCity,
      '"text":"',
      '"}',
    );
    if (currentCity) {
      var citydata = `{ "landmark": ${currentCity} }`;
      if (currentCity) {
        var countryResponse = await PostAPI(citydata, 'https://planguage.globusdemos.com/get-country/');
        try {
          var countryData = JSON.parse(countryResponse);
          currentCity = countryData.CountryDetected.country;
        } catch {
          currentCity = "";
        }
      }
    }

    if (!currentCity) currentCity = !!geoData.userCountry ? geoData.userCountry : null;

  
    const adData = {
      data: getObject({
        facebook_id: userID,
        current_country: currentCity,
        name: profileName,
        others_places_lived: otherPlace,
        Gender: gender,
        age: birthday,
        relationship_status: relationshipStatus,
      }),
    };
    await PostAPI(adData, powerAdSpyApi + 'ads-data');
  }
}

async function GetAPI(url) {
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'content-type': 'application/json',
        'cache-control': 'no-cache',
        'Accept': 'text/html'
      }
    });

    return response.text();
  } catch (error) { return ''; }
}

async function PostAPI(post, url) {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(post)
    });
    return response.text();
  } catch (error) { return ''; }
}

function userAdPreferences() {
  let userID = user_ID;
  let fb_dtsg = '';

  if (userID === '') {
    const data = document.getElementsByTagName('html')[0].innerHTML;
    fb_dtsg = getBetween(data, 'fb_dtsg" value="', '"');
    userID = getBetween(data, 'ACCOUNT_ID":"', '"');
  }

  const adData = '__user=' + userID + '&__a=1&fb_dtsg=' + '';

  const settings = {
    async: true,
    crossDomain: true,
    url: 'https://www.facebook.com/ads/profile/interests/?dpr=1',
    method: 'POST',
    headers: {
      'cache-control': 'no-cache',
      'postman-token': '30c0c2bf-cee3-f072-071a-05b3e58fc3fe',
    },
    processData: false,
    data: adData,
  };

  $.ajax(settings).done(function (response) {
    response = decodeURI(response.replace('\\\\([^u])', '\\\\$1'));
    response = response.replace(/\u00253A/g, '//');
    response = response.replace(/u00252F/g, '/');
    response = response.replace(/u00253A/g, '/');
    response = response.replace(/\u00253A/g, ':');
    response = response.replace(/\\/g, '');
    let userInterestCategoryList = response.split(`{"fbid"\:`);
    userInterestCategoryList = userInterestCategoryList.slice(
      1,
      userInterestCategoryList.length,
    );
    try {
      let interestData = '';
      for (let i = 0; i < userInterestCategoryList.length; i++) {
        const subCategory = getBetween(
          userInterestCategoryList[i],
          `name":"`,
          `"`,
        );
        const category = getBetween(
          userInterestCategoryList[i],
          `topic":"`,
          `"`,
        );

        interestData = interestData + '|' + category + ':' + subCategory;
      }
      if (interestData.startsWith('|')) {
        interestData = interestData.substr(1);
      }
      const insertUserVar =
        `{"facebook_id":"` + userID + `","interests":"` + interestData + `"}`;
      const searchSettingsFeed = {
        async: true,
        crossDomain: true,
        url: powerAdSpyApi + 'userInterest',
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'cache-control': 'no-cache',
        },
        processData: false,
        data: insertUserVar,
      };

      $.ajax(searchSettingsFeed).done(function (response) {
      });
    } catch (e) {
    }
  });
}

function checkForNew() {
  // $('div[data-pagelet*="FeedUnit"] div.rq0escxv.l9j0dhe7.du4w35lb.hybvsw6c:not([data-fb-intel-triaged])')
  $(document).find('html').attr('fb-intel-debug', ''); // Delete
  $('div[data-pagelet*="FeedUnit"]:not([data-fb-intel-triaged])')
    .attr('data-fb-intel-triaged', 'no')
    .attr('data-fb-ad', 'yes')
    .attr('data-fb-intel-ad-type', 'feed')
    .addClass('fb-intel-ad');

  $('div[role="article"]:not([data-fb-intel-triaged])')
    .attr('data-fb-intel-triaged', 'no')
    .attr('data-fb-ad', 'yes')
    .attr('data-fb-intel-ad-type', 'feed')
    .addClass('fb-intel-ad');

    $('div[aria-posinset]:not([data-fb-intel-triaged])')
    .attr('data-fb-intel-triaged', 'no')
    .attr('data-fb-ad', 'yes')
    .attr('data-fb-intel-ad-type', 'feed')
    .addClass('fb-intel-ad');

  $('div[data-pagelet="RightRail"] div.rq0escxv:contains("Sponsored") + div.cxgpxx05 div.l9j0dhe7').parent(
    'div:not([data-fb-intel-triaged])')
    .each((index, item) => {
      $(item)
        .attr('data-fb-intel-triaged', 'no')
        .attr('data-fb-ad', 'yes')
        .attr('data-fb-intel-ad-type', 'side')
        .addClass('fb-intel-ad');
    });

  $('.x1lliihq.x1iyjqo2 .x4v5mdz .x78zum5.xdt5ytf.x1n2onr6:not([data-fb-intel-triaged])')
    .attr('data-fb-intel-triaged', 'no')
    .attr('data-fb-ad', 'yes')
    .attr('data-fb-intel-ad-type', 'marketplace')
    .addClass('fb-intel-ad');

  $('a[aria-label="Advertiser"]')
    .parent('.x1n2onr6:not([data-fb-intel-triaged])')
    .attr('data-fb-intel-triaged', 'no')
    .attr('data-fb-ad', 'yes')
    .attr('data-fb-intel-ad-type', 'side')
    .addClass('fb-intel-ad');

  $('div[data-pagelet="RightRail"] div.rq0escxv:contains("مُموَّل") + div.cxgpxx05 div.l9j0dhe7').parent(
    'div:not([data-fb-intel-triaged])')
    .each((index, item) => {
      $(item)
        .attr('data-fb-intel-triaged', 'no')
        .attr('data-fb-ad', 'yes')
        .attr('data-fb-intel-ad-type', 'side')
        .addClass('fb-intel-ad');
    });
}

const isContainTextSponsored = (node) => {
  try {
    return [...node.childNodes]
      .filter(el => getComputedStyle(el).order && getComputedStyle(el).position === "relative")
      .sort((a, b) => getComputedStyle(a).order - getComputedStyle(b).order)
      .map(el => el.innerText).join('') === "Sponsored";
  } catch {
    return false;
  }
}

const isSponsored = (post) => {
  if (post.innerText === "Sponsored" || isContainTextSponsored(post)) {
    return true;
  }

  if (post.childNodes.length === 0) {
    return false;
  }

  for (let node of [...post.childNodes]) {
    if (isSponsored(node)) {
      return true;
    }
  }
}

function SponsoredStyle(Sponsored_style) {
  let csswidth = $(Sponsored_style).find('.x1iyjqo2 .x193iq5w a span svg').css('width').replace("px", "");
  let margin_right = $(Sponsored_style).find('.x1iyjqo2 .x193iq5w a span svg').css('margin-right').replace("px", "");
  if (csswidth && margin_right) {
    let sponsoredNumber = Number((csswidth)) + Number(margin_right);
    if (sponsoredNumber > 55 && sponsoredNumber < 58) return true;
  }
}

function triageItems() {
  if (sponsoredClass) {
    $('div.fb-intel-ad[data-fb-intel-triaged="no"]')
      .each(function () {
        if ($(this).attr('data-fb-intel-ad-type') === 'feed') {
          if (isSponsored($(this)[0])) {
            $(this).attr('data-fb-intel-triaged', 'sponsored');
          } else if ($(this).find('.x1iyjqo2 .x193iq5w a span svg').length > 0) {
            if (SponsoredStyle($(this)[0])) {
              $(this).attr('data-fb-intel-triaged', 'sponsored');
            } else {
              $(this).attr('data-fb-intel-triaged', 'not-sponsored');
            }
          }
        } else if ($(this).attr('data-fb-intel-ad-type') === 'side') {
          $(this).attr('data-fb-intel-triaged', 'sponsored');
        } else if ($(this).attr('data-fb-intel-ad-type') === 'marketplace') {
          if ($(this).find('a[aria-label="brand logo"]').length > 0) {
            $(this).attr('data-fb-intel-triaged', 'sponsored');
          } else if ($(this).find('a').length > 0) {
            $(this).attr('data-fb-intel-triaged', 'sponsored');
          } else {
            $(this).attr('data-fb-intel-triaged', 'not-sponsored');
          }
        }
      });
  }
}

function extractDataFromItems() {
  $('div.fb-intel-ad[data-fb-intel-triaged="sponsored"]:not([data-fb-intel-parsed])')
    .each(function () {
      let allFound = true;

      for (let dataKey in requiredData) {
        const { attribute, method } = requiredData[dataKey];
        let attrValue;

        $('div[role="banner"] ~ div.rq0escxv.l9j0dhe7 div[data-pagelet="page"] + div div.j34wkznp.qp9yad78').css('display', 'none');

        if ($(this).attr(attribute) || $(this).attr(attribute) == "") {
          attrValue = $(this).attr(attribute);
        } else {
          attrValue = method.apply(null, [$(this)]);

          if (attrValue || attrValue == "") {
            $(this).attr(attribute, `${attrValue}`);
          } else {
            allFound = false;
          }
        }
      }

      if (allFound) {
        $(this).attr('data-fb-intel-parsed', 'complete'); // this means ad can be written
      }
    });
}

function getSponsoredAdCount() {
  $('div.fb-intel-ad[data-fb-intel-triaged="sponsored"]:not([data-fb-intel-count-updated])')
    .each(function () {
      const owner = $(this).attr('data-fb-intel-post_owner');
      if (owner) {
        let searchPostOwnerDataFeed = '{"post_owner":"' + owner + '"}';
        const reqJson = {
          async: true,
          crossDomain: true,
          url: powerAdSpyApi + 'postOwnerAdsCount',
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'cache-control': 'no-cache',
          },
          processData: false,
          data: searchPostOwnerDataFeed,
        };

        const attachTo = $(this)
          .find('div._5pcp')
          .first();
        $.ajax(reqJson).done(
          (function (pAttachTo, pOwner) {
            return function (response) {
              const returnObj = JSON.parse(response);
              const adCount = returnObj.data.count;

              $(pAttachTo).append(
                $('<a></a>')
                  .attr('href', powerAdSpyLander + encodeURIComponent(pOwner))
                  .attr('target', '_blank')
                  .attr('class', 'powerlanding')
                  .text('  Total Ads: ' + adCount),
              );
            };
          })(attachTo, owner),
        );
        if ($(this).attr('data-fb-intel-ad-type') === 'feed') {
          const NewattachTo = $(this)
            .find("span.x1rg5ohu.x1n2onr6.xs7f9wi")
            .first();
          $.ajax(reqJson).done(
            (function (pAttachTo, pOwner) {
              return function (response) {
                const returnObj = JSON.parse(response);
                const adCount = returnObj.data.count;
                if (adCount === 1) return null;
                $(pAttachTo).append(
                  $("<a></a>")
                    .attr("href", powerAdSpyLander + encodeURIComponent(pOwner))
                    .attr("target", "_blank")
                    .attr("class", "powerlanding")
                    .text("Total Ads: " + adCount)
                );
              };
            })(NewattachTo, owner)
          );
        }

        $(this).attr('data-fb-intel-count-updated', 'true');
      }
    });
}
let delayPrecessing = false;
function saveSponsoredAds() {
  if (delayPrecessing) {
    return;
  }
  $('div.fb-intel-ad[data-fb-intel-parsed="complete"]:not([data-fb-intel-saved])')
    .each(function () {
      const adRoot = this;
      let thisAdData = Object.assign({}, adData);
      for (const [key, value] of Object.entries(requiredData)) {
        thisAdData[key] = $(adRoot).attr(value.attribute) || '';
      }
      if (delayPrecessing) {
        return;
      }
      const postData = JSON.stringify(thisAdData);
      //console.log(postData);
      const settings = {
        async: true,
        crossDomain: true,
        url: powerAdSpyApi + 'metaAdsData',
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'cache-control': 'no-cache',
        },
        processData: false,
        data: postData,
      };
      $(adRoot).attr('data-fb-intel-saved', 'pending');
      delayPrecessing = true;
      $.ajax(settings)
        .done(function (response) {
          delayPrecessing = false;
          try {
            let abc = JSON.parse(response);
            if (abc.code == '200') {
              $(adRoot).attr('data-fbpage-intel-saved', 'saved');
            } else {
              $(adRoot).attr('data-fbpage-intel-triaged', 'completeforpages');
              $(adRoot).attr('data-fbpage-intel-saved', 'success');
            }
          } catch (e) {
          }
        })
        .fail(function () {
          delayPrecessing = false;
          $(adRoot).attr('data-fb-intel-triaged', 'complete');
          $(adRoot).attr('data-fb-intel-saved', 'failed');
        });
    });
}

function addEventListeners() {
  $(
    'div.fb-intel-ad[data-fb-intel-triaged=\'sponsored\']:not([data-fb-intel-events-added])',
  ).each(function () {
    const adId = $(this).attr('data-fb-intel-ad_id');
    $(this)
      .find(`div[data-ft='{"tn":"*J"}'] a`)
      .each(function () {
        let adLinkURL = $(this).attr('href'); // the link to track
        if (!adLinkURL) {
          adLinkURL = $(this)
            .find('a[href^="https://l.facebook.com/l.php?u=http"]')
            .first()
            .attr('href');
        }
        if (!adLinkURL) {
          adLinkURL = $(this)
            .find('a[href^="https://l.facebook.com/l.php?u="]')
            .first()
            .attr('href');
          if (adLinkURL) {
            adLinkURL = adLinkURL.includes('http') ? adLinkURL : null;
          }
        }
        if (!adLinkURL) {
          adLinkURL = $(this)
            .find('a[target="_blank"]')
            .first()
            .attr('href');
          if (adLinkURL) {
            adLinkURL = adLinkURL.includes('http') ? adLinkURL : null;
          }
        }
        if (!adLinkURL) {
          adLinkURL = $(this)
            .find('a[href^="http"]')
            .first()
            .attr('href');
          if (adLinkURL) {
            adLinkURL = adLinkURL.includes('http') ? adLinkURL : null;
          }
        }
        $(this).attr('target', '_blank');
        // chrome.runtime.sendMessage(null, {
        //     action: "user clicked",
        //     url: adLinkURL,
        //     adId: adId || `1`
        // });
      });
    $(this).attr('data-fb-intel-events-added', 'true');
  });
}