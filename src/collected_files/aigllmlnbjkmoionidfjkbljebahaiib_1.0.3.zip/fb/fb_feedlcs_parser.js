function ProcessFeed() {
  const mainUrl = window.location.href;
  if (
    mainUrl.includes("posts") ||
    mainUrl.includes("permalink") ||
    mainUrl.includes("story_fbid")
  ) {
    let feedPostData;
    const scriptContainingPostId = Array.from(
      document.querySelectorAll("script")
    ).find((script) => {
      return script.innerHTML.includes("post_id");
    });

    if (scriptContainingPostId) {
      feedPostData = getBetween(
        scriptContainingPostId.innerHTML,
        '{"__bbox":{"complete":true,"result":',
        ',"extensions":{"prefetch_uris_v2"'
      );

      if (!feedPostData) {
        feedPostData = "";
        feedPostData = getBetween(
          scriptContainingPostId.innerHTML,
          '{"__bbox":{"complete":false,"result":',
          ',"extensions":{"prefetch_uris_v2"'
        );
      }
      feedPostData += "}";
    }
    var analyticsData = {};
    var comments_data = [];
    var user_detailsData = [];
    var lcsUserDetailsData = {
      analytics: [],
      user_details: null,
    };
    try {
      var comment_data = JSON.parse(feedPostData);

      analyticsData["likes_counts"] =
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.comet_feed_ufi_container?.story?.story_ufi_container?.story
          ?.feedback_context?.feedback_target_with_context
          ?.comet_ufi_summary_and_actions_renderer?.feedback?.reaction_count
          ?.count ||
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.comet_feed_ufi_container?.story?.feedback_context
          ?.feedback_target_with_context?.ufi_renderer?.feedback
          ?.comet_ufi_summary_and_actions_renderer?.feedback?.reaction_count
          ?.count ||
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.feedback_context?.feedback_target_with_context?.ufi_renderer
          ?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback
          ?.reaction_count?.count ||
        0;

      analyticsData["comments_count"] =
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.comet_feed_ufi_container?.story?.story_ufi_container?.story
          ?.feedback_context?.feedback_target_with_context
          ?.comet_ufi_summary_and_actions_renderer?.feedback
          ?.comments_count_summary_renderer?.feedback
          ?.comment_rendering_instance?.comments?.total_count ||
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.comet_feed_ufi_container?.story?.feedback_context
          ?.feedback_target_with_context?.ufi_renderer?.feedback
          ?.comet_ufi_summary_and_actions_renderer?.feedback
          ?.comments_count_summary_renderer?.feedback
          ?.comment_rendering_instance?.comments?.total_count ||
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.feedback_context?.feedback_target_with_context?.ufi_renderer
          ?.feedback?.comment_list_renderer?.feedback?.total_comment_count ||
        0;

      analyticsData["shares_count"] =
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.comet_feed_ufi_container?.story?.story_ufi_container?.story
          ?.feedback_context?.feedback_target_with_context
          ?.comet_ufi_summary_and_actions_renderer?.feedback?.share_count
          ?.count ||
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.comet_feed_ufi_container?.story?.feedback_context
          ?.feedback_target_with_context?.ufi_renderer?.feedback
          ?.comet_ufi_summary_and_actions_renderer?.feedback?.share_count
          ?.count ||
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.feedback_context?.feedback_target_with_context?.ufi_renderer
          ?.feedback?.comet_ufi_summary_and_actions_renderer?.feedback
          ?.share_count?.count ||
        0;

      analyticsData["facebook_id"] = comment_data?.data?.node?.post_id;
      analyticsData["call_to_action"] = "";
      analyticsData["destination_url"] = "";
      let display_comments;
      display_comments =
        comment_data?.data?.node?.comet_sections?.feedback?.story
          ?.comet_feed_ufi_container?.story?.story_ufi_container?.story
          ?.feedback_context?.feedback_target_with_context
          ?.comment_list_renderer?.feedback
          ?.comment_rendering_instance_for_feed_location?.comments?.edges;
      if (!display_comments) {
        display_comments =
          comment_data?.data?.node?.comet_sections?.feedback?.story
            ?.comet_feed_ufi_container?.story?.feedback_context
            ?.feedback_target_with_context?.ufi_renderer?.feedback
            ?.comment_list_renderer?.feedback
            ?.comment_rendering_instance_for_feed_location?.comments?.edges;
      }
      if (!display_comments) {
        display_comments =
          comment_data?.data?.node?.comet_sections?.feedback?.story
            ?.feedback_context?.feedback_target_with_context?.ufi_renderer
            ?.feedback?.comment_list_renderer?.feedback
            ?.comment_rendering_instance_for_feed_location?.comments?.edges;
      }
      if (!display_comments) {
        display_comments =
          comment_data?.data?.node?.comet_sections?.feedback?.story
            ?.comet_feed_ufi_container?.story?.story_ufi_container?.story
            ?.feedback_context?.feedback_target_with_context
            ?.comment_list_renderer?.feedback
            ?.comment_rendering_instance_for_feed_location?.comments?.edges;
      }
      if (Array.isArray(display_comments) && display_comments.length > 0) {
        display_comments.forEach((display_comment) => {
          if (display_comment?.node?.body?.text) {
            comments_data.push(display_comment.node.body.text);
            var user_detail = {};
            user_detail["facebook_id"] = analyticsData["facebook_id"];
            user_detail["type"] = "2";
            user_detail["name"] = display_comment.node.author.name;
            user_detail["user_id"] = display_comment.node.author.id;
            user_detail["gender"] = display_comment.node.author.gender;
            user_detail["country"] = "";
            user_detail["age"] = "";
            user_detail["relation_ship"] = "";
            user_detail["partial_details"] = "0";
            user_detailsData.push(user_detail);
          }
        });
      }
      analyticsData["comments_data"] = comments_data;
      lcsUserDetailsData.analytics.push(analyticsData);
      lcsUserDetailsData.user_details = user_detailsData;
      SaveUserLcsData(lcsUserDetailsData);
    } catch (error) {
      console.log(error);
    }
  }
}

function SaveUserLcsData(lcsData) {
  const lcsSettings = {
    async: true,
    crossDomain: true,
    url: powerAdSpyApi + "lcsUpdate",
    method: "POST",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
    },
    processData: false,
    data: JSON.stringify(lcsData),
  };

  $.ajax(lcsSettings)
    .done(function (response) {})
    .fail(function (error) {});
}

setTimeout(ProcessFeed, 5000);