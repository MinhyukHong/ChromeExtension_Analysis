// Declaration of required properties
let USER_IP;
let USER_CITY;
let USER_STATE;
let USER_COUNTRY;
let FACEBOOK_ID;
let LOWER_AGE;
let UPPER_AGE;
let VERSION;
let PLATFORM;
let FIRST_SEEN;
let LAST_SEEN;

// Initialization of required properties
setTimeout(function () {
  USER_IP = getUserIp();
  USER_CITY = getUserCity();
  USER_STATE = getUserState();
  USER_COUNTRY = getUserCountry();
  FACEBOOK_ID = user_ID;
  LOWER_AGE = getLowerAdAge();
  UPPER_AGE = getUpperAdAge();
  VERSION = getVersion();
  PLATFORM = getPlatform();
  FIRST_SEEN = getFirstSeen().toString();
  LAST_SEEN = getLastSeen().toString();
}, 4000);

//Home page side ads data extraction
function sideAds(ad) {
  // console.log(ad)
  let sideAdResult = {};
  sideAdResult["meta_ad_id"] = ad?.sponsored_data?.ad_id || "";
  sideAdResult["post_owner"] = ad?.rhc_ad?.actor?.name || "";
  sideAdResult["post_owner_image"] =
    ad?.rhc_ad?.actor?.profile_picture?.uri || "";
  sideAdResult["ad_text"] = ad?.rhc_ad?.subtitle || "";
  sideAdResult["ad_title"] = ad?.rhc_ad?.title || "";
  sideAdResult["destination_url"] = ad?.rhc_ad?.target_url || "";
  sideAdResult["image_video_url"] =
    ad?.rhc_ad?.image?.uri ||
    ad?.rhc_ad?.attachments[0]?.all_subattachments?.nodes[0]?.media?.image
      .uri ||
    "";
  sideAdResult["ad_position"] = "SIDE";
  sideAdResult["type"] = "IMAGE";
  sideAdResult["other_multimedia"] = "";
  sideAdResult["thumbnail_url"] = "";
  return commonProps(sideAdResult);
}

//Marketplace image and video ads data extraction
function marketplaceImageVideoAds(Ad) {
  // console.log(Ad);
  let marketAdResult = {};
  marketAdResult["meta_ad_id"] = Ad?.node?.story?.sponsored_data?.ad_id || "";
  marketAdResult["post_owner"] = Ad?.node?.story?.actors[0]?.name || "";
  marketAdResult["post_owner_image"] =
    Ad?.node?.story?.actors[0]?.logo.uri || "";
  marketAdResult["ad_text"] = "";
  marketAdResult["ad_title"] =
    Ad?.node?.story?.attachments[0]?.action_links[0]?.link_title ||
    Ad?.node?.story?.attachments[0]?.action_links[0]?.text ||
    "";
  marketAdResult["destination_url"] =
    transformFacebookUrl(
      Ad?.node?.story?.attachments[0]?.action_links[0]?.url ||
        Ad?.node?.story?.attachments[0]?.url
    ) || "";
  marketAdResult["thumbnail_url"] = "";
  if (Ad.node.story.attachments[0].media.__typename === "Video") {
    marketAdResult["image_video_url"] =
      Ad?.node?.story?.attachments[0]?.media?.browser_native_hd_url;
    marketAdResult["type"] = "VIDEO";
    marketAdResult["thumbnail_url"] = Ad?.node?.story?.attachments[0]?.media?.thumbnailImage?.uri || Ad?.node?.story?.attachments[0]?.media?.preferred_thumbnail?.image?.uri;
  }
  if (Ad.node.story.attachments[0].media.__typename !== "Video") {
    marketAdResult["image_video_url"] =
      Ad?.node?.story?.attachments[0]?.media?.media_image?.uri;
    marketAdResult["type"] = "IMAGE";
  }
  marketAdResult["ad_position"] = "MARKETPLACE";
  marketAdResult["other_multimedia"] = "";
  return commonProps(marketAdResult);
}

//Marketplace CarouselAds data extraction
function marketplaceCarouselAds(Ad) {
  // console.log(Ad);
  let temp = Ad.node.story.attachments[0].subattachments.some((element) => {
    return element.media.__typename === "Video";
  });
  if (!temp) {
    let carouselAdResult = {};
    carouselAdResult["meta_ad_id"] =
      Ad?.node?.story?.sponsored_data?.ad_id || "";
    carouselAdResult["post_owner"] = Ad?.node?.story?.actors[0]?.name;
    carouselAdResult["post_owner_image"] =
      Ad?.node?.story?.actors[0]?.logo?.uri || "";
    carouselAdResult["ad_text"] = "";
    let titleMediaDest = marketplaceCarouselTitleMedia(
      Ad?.node?.story?.attachments[0]?.subattachments,
      Ad,
      carouselAdResult
    );
    carouselAdResult["ad_title"] = titleMediaDest[0];
    carouselAdResult["destination_url"] =
      transformFacebookUrl(
        Ad?.node?.story?.attachments[0]?.action_links[0]?.url ||
          Ad?.node?.story?.attachments[0]?.url
      ) || "";
    carouselAdResult["type"] = "IMAGE";
    carouselAdResult["other_multimedia"] = titleMediaDest[1];
    carouselAdResult["ad_position"] = "MARKETPLACE";
    carouselAdResult["thumbnail_url"] = "";
    return commonProps(carouselAdResult);
  }
}

//Marketplace CarouselAds title, media extraction
function marketplaceCarouselTitleMedia(subattachment, Ad, obj) {
  let media = [];
  let title = [];
  subattachment.forEach((element) => {
    media.push(element?.media?.square_media_image?.uri);
    title.push(element?.title_with_entities?.text || "");
  });
  if (
    Ad?.node?.story?.attachments[0]?.style_list[0] !== "multi_share_no_end_card"
  ) {
    media.push(Ad?.node?.story?.actors[0]?.logo.uri || "");
    title.push(
      "See more at " +
        Ad?.node?.story?.attachments[0]?.action_links[0]?.link_display || ""
    );
  }
  obj["image_video_url"] = media[0];
  media.shift();
  media = media.join("||,");
  title = title.join("||,");
  return [title, media];
}

// Generation of  ad_id for marketplace image, video and carousel ads
function ad_id(obj) {
  let splitDestUrl = obj.destination_url;
  let splitImageUrl = obj.image_video_url;
  let splittitle = obj.ad_title;
  if (splitDestUrl) {
    splitDestUrl = decodeURIComponent(obj.destination_url).split("?")[0];
  } else {
    splitDestUrl = obj.destination_url;
  }
  if (splitImageUrl) {
    splitImageUrl = obj.image_video_url.split("?")[0];
    splitImageUrl = splitImageUrl.split("/").pop();
  }
  if (splittitle && splitImageUrl) {
    if (splittitle.includes("||,")) {
      let hashdata = b64_hmac_sha1(
        paskey,
        splittitle.split("||,")[0] + splitDestUrl + splitImageUrl
      );
      return base64ToHex(hashdata);
    } else {
      let hashdata = b64_hmac_sha1(
        paskey,
        obj.ad_title + splitDestUrl + splitImageUrl
      );
      return base64ToHex(hashdata);
    }
  } else if (splitDestUrl) {
    let hashdata = b64_hmac_sha1(paskey, splitDestUrl);
    return base64ToHex(hashdata);
  }
}

//common properties
function commonProps(obj) {
  obj["call_to_action"] = "";
  obj["comment"] = "0";
  obj["likes"] = "0";
  obj["share"] = "0";
  obj["ad_url"] = "";
  obj["news_feed_description"] = "";
  obj["page_verified"] = "";
  obj["side_url"] = "Not implemented yet";
  obj["category"] = "No category";
  obj["ad_id"] = ad_id(obj);
  obj["ip_address"] = USER_IP;
  obj["city"] = USER_CITY;
  obj["state"] = USER_STATE;
  obj["country"] = USER_COUNTRY;
  // obj["facebook_id"] = FACEBOOK_ID;
  obj["lower_age"] = LOWER_AGE;
  obj["upper_age"] = UPPER_AGE;
  obj["version"] = VERSION;
  obj["platform"] = PLATFORM;
  obj["first_seen"] = FIRST_SEEN;
  obj["last_seen"] = LAST_SEEN;
  obj["post_date"] = FIRST_SEEN;
  return obj;
}


function fbAdBudget(views) {
  if (views < 1600) {
      return [0, 1];
  }

  let reach;
  if (views >= 1000000) {
      reach = 1000000 + (Math.floor(views / 1000000) * 10);
  } else {
      reach = views;
  }

  // $1 = 1600 - 4600
  let budgetLowerRange = Math.round(reach / 4600);
  let budgetHigherRange = Math.round(reach / 1600);

  return [budgetLowerRange, budgetHigherRange];
}


function calculateViews(likes, shares, comments) {
  const avgLikeRate = 0.2;
  const shareMultiplier = 75;
  const commentMultiplier = 20;

  const views = (likes / avgLikeRate) + (shares * shareMultiplier) + (comments * commentMultiplier);
  return views;
}