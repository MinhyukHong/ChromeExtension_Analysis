let [userip, usercity, userstate, usercountry] = [null, null, null, null];

const interceptorScript = document.createElement("script");
// interceptorScript.src = chrome.runtime.getURL("library/xhr-interceptor.js");
//new inject code
const extensionId = chrome.runtime.id;
interceptorScript.src = "chrome-extension://" + extensionId + "/" + 'library/xhr-interceptor.js';

interceptorScript.onload = function () {
  this.remove();
};

(document.head || document.documentElement).appendChild(interceptorScript);

async function handleXhrIntercepted(event) {
  const { responseURL, response } = event.detail;
  if (responseURL.includes("UserHomefeedResource")) {
    get_pinterest_ads(response);
  }
}

//xhr event listener
document.addEventListener("XHR_INTERCEPTED", handleXhrIntercepted);


//Getting first 10 ads from pageSource when page loads, because xhr response not able to capture first 7-10 ads.
(() => {
  const retryDelay = 1000; // Adjust the delay as needed (in milliseconds)

  function fetchData() {
       userip = getUserIp();
       usercity = getUserCity();
       userstate = getUserState();
       usercountry = getUserCountry();

      if (userip === null || usercity === null || userstate === null || usercountry === null) {
          // If any of the values are null, retry after a delay
          setTimeout(fetchData, retryDelay);
      } else {
          // All values are available, proceed with the data
          // Do something with userip, usercity, userstate, usercountry
    userip = getUserIp();
    usercity = getUserCity();
    userstate =  getUserState();
    usercountry =  getUserCountry();
    let pagesourceobj = $('script[id="__PWS_DATA__"]').text(); //Taking page source object from calling this element
    let pinsdata = JSON.parse(pagesourceobj).props.initialReduxState.pins;
    Object.values(pinsdata).filter((pindata) => {
      //Using filter method to take promoted data and calling adsData
      if (pindata.is_promoted === true) {
        adsData(pindata);
      }
    });
    
      }
  }

  fetchData(); // Initial call to start fetching data
})();


//Getting ads from xhr
function get_pinterest_ads(responseText) {
  try {
    responseText = JSON.parse(responseText);
    if (
      responseText.hasOwnProperty("resource_response") &&
      responseText.resource_response.data != null
    ) {
      let datas = responseText.resource_response.data;
      datas.filter((data) => {
        if (data.is_promoted === true) {
          adsData(data);
        }
      });
    }
  } catch (error) {}
}

//Capturing ads data
function adsData(res) {
  try {
    const result = {
      post_owner: res?.promoter?.full_name || "",
      type: getadType(res),
      ad_video: getvideoUrl(getadType(res), res),
      ad_image: getimageUrl(getadType(res), res),
      ad_text: res?.domain || "",
      ad_title: res?.title || "",
      target_keyword: "",
      post_owner_image: res?.promoter?.image_medium_url,
      destination_url: res?.ad_destination_url || "",
      newsfeed_description:"",
      ad_position: "Feed",
      source: "desktop",
      ip_address: userip,
      city: usercity,
      state: userstate,
      country: usercountry,
      version: version,
      first_seen: getFirstSeen().toString(),
      last_seen: getLastSeen().toString(),
      platform: getPlatform(),
      post_date: getPostDate(res),
      network: "Pinterest",
      ad_id: getAdId(
        res?.title,
        getvideoUrl(getadType(res), res),
        getimageUrl(getadType(res), res),
        res
      ),
    };
    // console.log(result)
    if(result["city"]!=="" && result["country"]!=="" && result["state"]!=="") sendPost(result);
    
  } catch (error) {}
}

//Send json data to server
async function sendPost(post) {
  try {
    const response = await fetch(`${powerAdSpyPinterestApi}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(post),
    });
    const message = await response.text();
  } catch (error) {}
}

//Getting video url
function getBetween(source, firstline, secondline) {
  try {
    const [, result] = source.split(firstline); //It's saying "ignore the first element of the array and assign the second element to the variable result.
    //" The square brackets with the comma indicate that we're only interested in the second element of the array.
    const index = result.indexOf(secondline);
    return index !== -1 ? result.substring(0, index) : "";
  } catch (e) {
    return "";
  }
}

//Getting ad_id
function getAdId(title, video, image, res) {
  try {
    let source =
      video.length > 0 ? video : image.length > 0 ? res?.images?.orig.url : "";
    if (source !== "") {
      title = source + title;
      return base64ToHex(b64_hmac_sha1(paskey, title));
    }
  } catch (error) {}
}

//Getting post date from result data
function getPostDate(res) {
  return Date.parse(res?.created_at);
}

//Getting type of ads
function getadType(res) {
  return res?.videos ? "Video" : "Image";
}

//Getting video url
function getvideoUrl(type, res) {
  try {
    if (type === "Video") {
      const video = res?.videos?.video_list?.V_HLSV4?.url;
      // return (
      //   "https://v1.pinimg.com/videos/mc/720p" +
      //   getBetween(video, "https://v1.pinimg.com/videos/mc/hls", "m3u8") +
      //   "mp4"
      // );
      return video.replace('.m3u8',"_360w.cmfv")
    }
    return '';
  } catch (error) {}
}

//Getting image url
function getimageUrl(type, res) {
  try {
    const mulimg = res?.carousel_data?.carousel_slots;

    if (type === "Image") {
      if (mulimg) {
        return mulimg.map((img) => img.images["736x"].url).join("||,");
      } else {
        return res?.images?.orig.url || "";
      }
    }
    return "";
  } catch (error) {}
}
