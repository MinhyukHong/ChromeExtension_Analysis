let sponsoredClass = null;
let sponsoredClassShopping = null;
let birthday = '';
let user_ID, fb_dtsg, composerId;
let defaultGeoData = {
    serviceId: null,
    lastUpdated: null,
    userCity: null,
    userState: null,
    userCountry: null,
    userIP: ""
};
let geoData = {};
const geoFunctions = [db_ip_com];
const adData = {
    network: null,
    type: null,
    post_owner: null,
    post_owner_image: null,
    ad_title: null,
    ad_image: null,
    ad_video: null,
    newsfeed_description: null,
    platform: null,
    destination_url: null,
    ad_id: null,
    post_date: null,
    first_seen: null,
    last_seen: null,
    city: null,
    state: null,
    country: null,
    ad_position: null,
    ad_text: null,
    version: null,
    ip_address: null,
    target_keyword: null,
    source: null
};
const requiredData = {

    post_owner: {
        attribute: "data-pin-intel-post_owner",
        method: getOwner
    },

    type: {
        attribute: "data-pin-intel-type",
        method: getType
    }, 

    ad_title: {
        attribute: "data-pin-intel-ad_title",
        method: getTitle
    },
    target_keyword: {
        attribute: "data-pin-intel-target_keyword",
        method: gettargettext
    },

    ad_image: {
        attribute: "data-pin-intel-ad_image",
        method: getAdImage
    },

    source: {
        attribute: "data-pin-intel-source",
        method: getsource
    },
    network: {
        attribute: "data-pin-intel-network",
        method: getnetwork
    },
    post_owner_image: {
        attribute: "data-pin-intel-post_owner_image",
        method: getpostownerimage
    },
    newsfeed_description: {
        attribute: "data-pin-intel-newsfeed_description",
        method: getNewsfeedDescription
    },
    platform: {
        attribute: "data-pin-intel-platform",
        method: getPlatform
    },
    destination_url: {
        attribute: "data-pin-intel-destination_url",
        method: getDestinationUrl
    },
    ad_id: {
        attribute: "data-pin-intel-ad_id",
        method: getAdId
    },
    post_date: {
        attribute: "data-pin-intel-post_date",
        method: getPostDate
    },
    first_seen: {
        attribute: "data-pin-intel-first_seen",
        method: getFirstSeen
    },
    last_seen: {
        attribute: "data-pin-intel-last_seen",
        method: getLastSeen
    },
    city: {
        attribute: "data-pin-intel-city",
        method: getUserCity
    },
    state: {
        attribute: "data-pin-intel-state",
        method: getUserState
    },
    country: {
        attribute: "data-pin-intel-country",
        method: getUserCountry
    },
    ad_position: {
        attribute: "data-pin-intel-ad_position",
        method: getPosition
    },

    ad_text: {
        attribute: "data-pin-intel-ad_text",
        method: getAdText
    },
    version: {
        attribute: "data-pin-intel-version",
        method: getVersion
    },
    ip_address: {
        attribute: "data-pin-intel-ip_address",
        method: getUserIp
    }
};


let isProcessing = false;
let scrollCounter = 0;

let intervalTimer = null;
let scrollTimer = null;

function start() {
    if ((document.domain).includes("pinterest.")) {
        clearTimeout(scrollTimer);
        clearInterval(intervalTimer);
        scrollTimer = setTimeout(processScroll, 200);
        intervalTimer = setInterval(processScroll, 500);
    }
};

function processScroll() {

    if (isProcessing)
        return;


    isProcessing = true;
    scrollCounter += 1;
    const startTime = Date.now();

    try {
        if (!geoData.userCity) {
            buildUpGeoData();
            isProcessing = false;
            return;
        }

        // setTimeout(checkForNew, 100);
        // setTimeout(triageItems, 100);
        // setTimeout(extractDataFromItems, 100);
        // setTimeout(saveSponsoredAds, 100);
    } catch (e) {
    }
    isProcessing = false;
    const delta = Date.now() - startTime;
    // chrome.runtime.sendMessage(null, { "mainLoopTime": delta });
};

start();
