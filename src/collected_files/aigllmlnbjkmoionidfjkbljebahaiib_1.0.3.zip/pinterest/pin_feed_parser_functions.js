let isProcessingGeoData = false;

function getVersion() {
  return version;
}

function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}

function getsource() {
  return "desktop";
}

function getnetwork() {
  return "Pinterest";
}

function getOwner(adRoot) {
  let owner = null;
  if ($(adRoot).find(".zI7.iyn.Hsu .swG").length > 0) {
    owner = $(adRoot).find(".zI7.iyn.Hsu .swG")[0].innerText;
  }
  return owner;
}

function getpostownerimage(adRoot) {
  let ownerImage = null;
  if ($(adRoot).find("img.hCL.kVc.L4E.MIw").length > 0) {
    ownerImage = $(adRoot).find("img.hCL.kVc.L4E.MIw").eq(1).attr("src");
  }
  return ownerImage;
}

function getAdImage(adRoot) {
  let image = null;
  if ($(adRoot).attr("data-pin-intel-type") === "Image") {
    let scaledImages = $(adRoot).find("[data-test-id='carousel-slot-container']");
    if (scaledImages.length > 1) {
      let imagesArray = [];
      scaledImages.each(function () {
        imagesArray.push($(this).find('img').attr("src"));
      });
      $(adRoot).attr("data-pin-intel-ad_image", imagesArray.join("||,"));
      //return null;
    } else {
      image = $(adRoot).find("img").attr("src");
      if (!image) return null;
      return image;
    }
  }
  if (!image) return null;
}

function getTitle(adRoot) {
  let title = null;
  if ($(adRoot).find('.X6t.zI7.iyn.Hsu').length > 0) {
    title = $(adRoot).find('.X6t.zI7.iyn.Hsu').first().text();
    return title;
  }
  return "";
}

function getAdText(adRoot) {
  let adText = null;
  var text = $(adRoot).attr("data-pin-intel-destination_url");
  adText = getBetween(text, "//", "/");
  if (adText.includes("www")) {
    adText = adText.replace("www.", "");
    if (adText.includes("Promoted")) return '';
  }
  return adText;
}

function gettargettext(adRoot) {
  let trgettext = null;
  var search = $("[aria-label=Search]");
  if (search.length > 0) {
    var searchText = search[0].defaultValue;
    if (trgettext != "") {
      $(adRoot).attr("data-pin-intel-target_keyword", searchText);
    }
  }
  else{
    return '';
  }
  
}

function getNewsfeedDescription(adRoot) {
  return "";
}

function getPlatform() {
  return Platform;
}

function getDestinationUrl(adRoot) {
  let adLinkURL = null;
  if ($(adRoot).find("a").length > 0) {
    adLinkURL = $(adRoot).find("a").attr("href");
  }
  return adLinkURL;
}

function getType(adRoot) {
  if ($(adRoot).find('[data-test-id=pinrep-video]').length > 0) {
    return "Video";
  } else {
    return "Image";
  }
}

function base64ToHex(str) {
  const raw = atob(str);
  let result = '';
  for (let i = 0; i < raw.length; i++) {
    const hex = raw.charCodeAt(i).toString(16);
    result += (hex.length === 2 ? hex : '0' + hex);
  }
  return result;
}

function getAdId(adRoot) {
  let postId = null;
  let imageUrl = null;
  let title = null;
  imageUrl = $(adRoot).attr("data-pin-intel-ad_image");
  title = $(adRoot).attr("data-pin-intel-ad_title");
  if (imageUrl && title) {
    title = imageUrl + title;
    postId = base64ToHex(b64_hmac_sha1(paskey, title));
  } else if (imageUrl) {
    postId = base64ToHex(b64_hmac_sha1(paskey, imageUrl));
  }
  return postId;
}

function getPosition(adRoot) {
  return "FEED";
}

function getUserIp() {
  return !!geoData.userIP ? geoData.userIP : null;
}

function getUserCity() {
  return !!geoData.userCity ? geoData.userCity : null;
}

function getUserState() {
  return !!geoData.userState ? geoData.userState : null;
}

function getUserCountry() {
  return !!geoData.userCountry ? geoData.userCountry : null;
}

function getFirstSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}

function getLastSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}

function getPostDate(adRoot) {
  let adPostTime;
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  adPostTime = parseInt(myDate);
  return adPostTime;
}

function hashCode(str) {
  return str
    .split("")
    .reduce(
      (prevHash, currVal) =>
        ((prevHash << 5) - prevHash + currVal.charCodeAt(0)) | 0,
      0
    );
}

function buildUpGeoData() {
  if (isProcessingGeoData) {
    return;
  }
  isProcessingGeoData = true;

  if (!geoData.userIP || !geoData.userCity || !geoData.userState || !geoData.userCountry) {
    if (!geoData.userIP) {
      const ourIP = "https://geolocation.poweradspy.com/";
      $.ajax({
        url: ourIP,
        type: "GET",
        async: true,
        success: function (IpResponse) {
          const ourIpResponse = JSON.parse(IpResponse);
          geoData.userIP = ourIpResponse.ip;
          geoData.userCity = ourIpResponse.cityName;
          geoData.userState = ourIpResponse.regionName;
          geoData.userCountry = ourIpResponse.countryName;
          geoData.lastUpdated = Date.now();
          chrome.storage.local.set({ "geoData": geoData });
          isProcessingGeoData = false;
        }
      });
    }
  }
}

function checkForNew() {
  $("div.Yl-:not([data-pin-intel-triaged])")
    .attr("data-pin-intel-triaged", "no")
    .attr("data-pin-ad", "yes")
    .attr("data-pin-intel-ad-type", "feed")
    .addClass("pin-intel-ad");
}

function triageItems() {
  $("div.pin-intel-ad[data-pin-intel-triaged='no'], div.pin-intel-ad[data-pin-intel-triaged='not-sponsored']"
  ).each(function () {
    if ($(this).find(".zI7.iyn.Hsu .xuA .tBJ.dyH.iFc.j1A").length > 0) {
      let sponsoredLinkCount = $(this).find(".zI7.iyn.Hsu .xuA .tBJ.dyH.iFc.j1A");
      if (sponsoredLinkCount[0].childElementCount === 13) {
        $(this).attr("data-pin-intel-triaged", "sponsored");
      }
      else {
        $(this).attr("data-pin-intel-triaged", "not-sponsored");
      }
    }
  });
}

function extractDataFromItems() {
  const startTime = Date.now();

  $("div.pin-intel-ad[data-pin-intel-triaged='sponsored']:not([data-pin-intel-parsed])").each(function () {
    let allFound = true;
    let debugPanel = "";

    let attempts = $(this).attr("data-pin-intel-attempts");
    if (!attempts) {
      attempts = "1";
    } else {
      attempts = parseInt(attempts) + 1;
      if (attempts > 8) {
        $(this).attr("data-pin-intel-parsed", "incomplete");
      }
    }
    $(this).attr("data-pin-intel-attempts", attempts);
    debugPanel += `<p>attempts: ${attempts}</p>`;
    for (const [key, value] of Object.entries(requiredData)) {
      let attrValue = $(this).attr(value.attribute);
      if (attrValue === null || attrValue === undefined) {
        attrValue = value.method.apply(null, $(this));
      }
      if (attrValue !== null && attrValue !== undefined) {
        $(this).attr(value.attribute, `${attrValue}`);
        debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
      } else {
        debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
        allFound = false;
      }
    }
    if (allFound) {
      $(this).attr("data-pin-intel-parsed", "complete"); // this means ad can be written
    }

    // console.log('=====Panel===', debugPanel);
  });

}

function saveSponsoredAds() {
  //$("div.pin-intel-ad[data-pin-intel-triaged]:not([data-pin-intel-saved])").each(function () {
  $("div.pin-intel-ad[data-pin-intel-parsed='complete']:not([data-pin-intel-saved])").each(function () {
    const adRoot = this;
    let thisAdData = Object.assign({}, adData);
    for (const [key, value] of Object.entries(requiredData)) {
      thisAdData[key] = $(adRoot).attr(value.attribute) || "";
      if (thisAdData[key] === null) {
        //if (enableDebugger)
      }
    }
    const postData = JSON.stringify(thisAdData);
    const settings = {
      async: true,
      crossDomain: true,
      //url: powerAdSpyPintApi + "api/insert_ads",
      url:'https://gdnapi.poweradspy.com/api/insert-pinterest-ads',
      method: "POST",
      headers: {
        "content-type": "application/json",
        "cache-control": "no-cache",
      },
      processData: false,
      data: postData
    };
    $(adRoot).attr("data-pin-intel-saved", "pending");

    $.ajax(settings)
      .done(function (response) {
        try {
          if (response.code == 200) {
            $(adRoot).attr('data-pin-intel-saved', 'saved');
          } else {
            $(adRoot).attr('data-pin-intel-triaged', 'completeforpages');
            $(adRoot).attr('data-pin-intel-saved', 'success');
          }
        } catch (e) {
        }
      })
      .fail(function (failResponse) {
        $(adRoot).attr('data-pin-intel-triaged', 'complete');
        $(adRoot).attr('data-pin-intel-saved', 'failed');
      });

  });
}