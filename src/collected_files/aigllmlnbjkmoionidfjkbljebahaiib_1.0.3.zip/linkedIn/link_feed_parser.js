
let defaultGeoData = {
    serviceId: null,
    lastUpdated: null,
    userCity: null,
    userState: null,
    userCountry: null,
    userIP: ""
};
let user_ID;

let geoData = {};

// chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
//     geoData = Object.assign(geoData, result.geoData);
//     if (geoData.lastUpdated < (Date.now() - 2 * 60 * 60 * 1000)) {
//         geoData.userIP = null;
//         buildUpGeoData();
//     }
// });
chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
    geoData = Object.assign(geoData, result.geoData);
    const minDelay = 2 * 60 * 60 * 1000; // 2 hours in milliseconds
    const maxDelay = 3 * 60 * 60 * 1000; // 3 hours in milliseconds
    const randomDelay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;

    if (geoData.lastUpdated < (Date.now() - randomDelay)) {
        geoData.userIP = null;
        buildUpGeoData();
    }
});

const adData = {
    network: null,
    type: null,
    post_owner: null,
    post_owner_image: null,
    ad_title: null,
    image_video_url: null,
    followers: null,
    ad_url: null,
    news_feed_description: null,
    platform: null,
    destination_url: null,
    ad_id: null,
    likes: null,
    comment: null,
    other_multimedia: null,
    ad_category: null,
    post_date: null,
    call_to_action: null,
    first_seen: null,
    last_seen: null,
    city: null,
    state: null,
    profile_link: null,
    // linkedin_id: null,
    country: null,
    ad_position: null,
    ad_text: null,
    version: null,
    ip_address: null,
    source: null
};

const requiredData = {

    post_owner: {
        attribute: "data-link-intel-post_owner",
        method: getOwner
    },
    ad_title: {
        attribute: "data-link-intel-ad_title",
        method: getTitle
    },
    followers: {
        attribute: "data-link-intel-ad_followers",
        method: getFollowers
    },

    image_video_url: {
        attribute: "data-link-intel-image_video_url",
        method: getImageVideoUrl
    },
    likes: {
        attribute: "data-link-intel-likes",
        method: getLikesCount,
    },
    comment: {
        attribute: "data-link-intel-comment",
        method: getCommentsCount,
    },
    source: {
        attribute: "data-link-intel-source",
        method: getsource
    },
    network: {
        attribute: "data-link-intel-network",
        method: getnetwork
    },
    post_owner_image: {
        attribute: "data-link-intel-post_owner_image",
        method: getpostownerimage
    },
    news_feed_description: {
        attribute: "data-link-intel-newsfeed_description",
        method: getNewsfeedDescription
    },
    other_multimedia: {
        attribute: 'data-link-intel-other_multimedia_url',
        method: getOtherMultimedia,
    },
    platform: {
        attribute: "data-link-intel-platform",
        method: getPlatform
    },
    call_to_action: {
        attribute: "data-link-intel-call_to_action",
        method: getCallToAction
    },
    destination_url: {
        attribute: "data-link-intel-destination_url",
        method: getDestinationUrl
    },
    ad_category: {
        attribute: "data-link-intel-category",
        method: getCategory
    },
    ad_id: {
        attribute: "data-link-intel-ad_id",
        method: getAdId
    },
    ad_url: {
        attribute: "data-link-intel-ad_url",
        method: getadUrl
    },
    post_date: {
        attribute: "data-link-intel-post_date",
        method: getPostDate
    },
    first_seen: {
        attribute: "data-link-intel-first_seen",
        method: getFirstSeen
    },
    last_seen: {
        attribute: "data-link-intel-last_seen",
        method: getLastSeen
    },
    city: {
        attribute: "data-link-intel-city",
        method: getUserCity
    },
    state: {
        attribute: "data-link-intel-state",
        method: getUserState
    },
    country: {
        attribute: "data-link-intel-country",
        method: getUserCountry
    },
    ad_position: {
        attribute: "data-link-intel-ad_position",
        method: getPosition
    },

    profile_link: {
        attribute: "data-link-intel-user_id",
        method: getUserId
    },

    // linkedin_id: {
    //     attribute: "data-link-intel-linkedin_id",
    //     method: getLinkedinId
    // },

    ad_text: {
        attribute: "data-link-intel-ad_text",
        method: getAdText
    },
    version: {
        attribute: "data-link-intel-version",
        method: getVersion
    },
    ip_address: {
        attribute: "data-link-intel-ip_address",
        method: getUserIp
    },
    type: {
        attribute: "data-link-intel-type",
        method: getType
    }
};

let isProcessing = false;
let scrollCounter = 0;

let intervalTimer = null;
let scrollTimer = null;

setTimeout(UserDetails, 5000);

function start() {
    clearTimeout(scrollTimer);
    clearInterval(intervalTimer);
    scrollTimer = setTimeout(processScroll, 200);
    intervalTimer = setInterval(processScroll, 500);
};

function processScroll() {
    if (isProcessing) {
        return;
    }
    scrollCounter += 1;
    isProcessing = true;
    try {
        if (!geoData.userCity) {
            //buildUpGeoData();
            isProcessing = false;
            return;
        }
        // setTimeout(checkForNew, 100);
        // setTimeout(triageItems, 100);
        // setTimeout(extractDataFromItems, 100);
        // setTimeout(saveSponsoredAds, 100);
    }
    catch (e) {
    }
    isProcessing = false;
}

start();