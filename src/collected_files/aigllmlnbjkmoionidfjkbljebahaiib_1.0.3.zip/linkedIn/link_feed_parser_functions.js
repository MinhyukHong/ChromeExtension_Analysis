let isProcessingGeoData = false;
let UserDetailsProcessing = false;

function getVersion() {
  return version;
}

function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}

function getsource() {
  return "desktop";
}

function getnetwork() {
  return "LinkedIn";
}

function getPlatform() {
  return Platform;
}

function getUserId() {
  let userId = $("div.feed-identity-module__actor-meta").find("a").attr("href");
  return userId;
}

function getLinkedinId() {
  try {
    let linkedInProfile = $("div.feed-identity-module__actor-meta")
      .find("a")
      .attr("href");
    let linkedInProfileId = linkedInProfile.split("/")[2];
    return linkedInProfileId.split("-")[2];
  } catch {
    return null;
  }
}

function getPosition() {
  return "FEED";
}

function getFirstSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}

function getLastSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}

function getPostDate(adRoot) {
  let post_date = null;
  let image_video_url = $(adRoot).attr("data-link-intel-image_video_url");
  if (image_video_url) {
    let numbersArray = image_video_url.match(/\b\d{13}\b/);
    post_date = numbersArray[0];
  }
  return post_date;
  //let post_date = null;
  // var postUrl = $(adRoot).attr('data-link-intel-ad_url');
  // if (!postUrl)
  //     return;
  // const reqJson = {
  //     async: true,
  //     crossDomain: true,
  //     url: postUrl,
  //     method: 'GET',
  //     headers: {
  //         'content-type': 'application/json',
  //         'cache-control': 'no-cache',
  //         'Accept': 'text/html',
  //     },
  //     processData: false,
  // };
  // try {
  //     if (!($(adRoot).attr('data-post-date-promise') === 'pending')) {
  //         $.ajax(reqJson)
  //             .done((datePagesource) => {
  //                 console.log(datePagesource);
  //                 let Pagesource = getBetween(datePagesource, '•   &quot;,&quot;accessibilityText', '•   &quot;');
  //                 Pagesource = Pagesource + 'dateEnd';
  //                 Pagesource = getBetween(Pagesource, ':&quot;', 'dateEnd');
  //                 Pagesource = Pagesource.replace(/[^\w\s]/gi, '');
  //                 let arrdateSource = Pagesource.split(' ');
  //                 post_date = arrdateSource[0];
  //                 var convertDate = convertPostDate(post_date);
  //                 $(adRoot).attr('data-link-intel-post_date', convertDate);
  //                 $(adRoot).attr('data-post-date-promise', 'fulfilled');
  //             })
  //             .fail((e) => {
  //                 $(adRoot).attr('data-link-intel-post_date', '');
  //                 $(adRoot).attr('data-post-date-promise', 'fulfilled');
  //             });
  //         $(adRoot).attr('data-post-date-promise', 'pending');
  //     }
  // }
  // catch {
  //     $(adRoot).attr('data-post-date-promise', 'failed');
  // }
}

function convertPostDate(postDate) {
  var postNumber = postDate.replace(/[^0-9]/g, "");
  var currentTime = new Date();
  if (postDate.includes("h")) {
    return Date.now() - postNumber * 60 * 60 * 1000;
  } else if (postDate.includes("d")) {
    return currentTime.setDate(currentTime.getDate() - postNumber);
  } else if (postDate.includes("w")) {
    return currentTime.setDate(currentTime.getDate() - postNumber * 7);
  } else if (postDate.includes("m")) {
    return currentTime.setMonth(currentTime.getMonth() - postNumber);
  } else if (postDate.includes("y")) {
    return currentTime.setFullYear(currentTime.getFullYear() - postNumber);
  }
}

function hashCode(str) {
  return str
    .split("")
    .reduce(
      (prevHash, currVal) =>
        ((prevHash << 5) - prevHash + currVal.charCodeAt(0)) | 0,
      0
    );
}

function getadUrl(adRoot) {
  let adUrl=null;
  let ad_id=$(adRoot).attr('data-link-intel-ad_id');
  if(ad_id){

   adUrl=`https://www.linkedin.com/embed/feed/update/${ad_id}`;
    }
    return adUrl;
}

function getOwner(adRoot) {
  let owner = null;
  if ($(adRoot).find("span.update-components-actor__name").length > 0) {
    owner = $(adRoot)
      .find("span.update-components-actor__name span.visually-hidden")
      .first()
      .text()
      .trim();
  }
  return owner;
}

function getOtherMultimedia(adRoot) {
  let otherMultimedia = "";
  if ($(adRoot).find("ul.artdeco-carousel__slider").length > 0) {
    const imageElements = $(adRoot).find(
      "ul.artdeco-carousel__slider .ivm-image-view-model    img"
    );
    const urlsImage = [...imageElements].map((element) =>
      element.getAttribute("src")
    );
    urlsImage.splice(0, 1);
    return null;
    //otherMultimedia = urlsImage.join('||,');
  } else {
    otherMultimedia = "";
  }
  return otherMultimedia;
}

function getpostownerimage(adRoot) {
  let ownerImage = null;
  if ($(adRoot).find("img.update-components-actor__avatar-image").length > 0) {
    ownerImage = $(adRoot)
      .find("img.update-components-actor__avatar-image")
      .attr("src");
  }
  return ownerImage;
}

function getCategory(adRoot) {
  // let pageUrl = null;
  // let category = null;
  // if ($(adRoot).find("a.app-aware-link").length > 0) {
  //     pageUrl = $(adRoot).find("a.app-aware-link").attr("href");
  // }
  // if (pageUrl) {
  //     const reqJson = {
  //         async: true,
  //         crossDomain: true,
  //         url: pageUrl,
  //         method: 'GET',
  //         headers: {
  //             'content-type': 'application/json',
  //             'cache-control': 'no-cache',
  //             'Accept': 'text/html',
  //         },
  //         processData: false,
  //     };
  //     try {
  //         if (!($(adRoot).attr('data-category-promise') === 'pending')) {
  //             $.ajax(reqJson)
  //                 .done((categoryPage) => {
  //                     let catPagesource = getBetween(categoryPage, 'ImageViewModel&quot;},&quot;subtitle&quot;:{&quot;textDirection&quot;:&quot;', 'attributesV2');
  //                     catPagesource = catPagesource + 'catEnd';
  //                     catPagesource = getBetween(catPagesource, 'USER_LOCALE&quot', 'catEnd');
  //                     catPagesource = catPagesource.replace(/[^a-zA-Z ]/g, " ").replace('quot', '').replace('text', '');
  //                     let arrCategory = catPagesource.split('quot');
  //                     category = arrCategory[2];
  //                     if (!category) return null;
  //                     if (category.includes('amp')) {
  //                         category = category.replace('amp', '&');
  //                     }
  //                     $(adRoot).attr('data-link-intel-category', category);
  //                     $(adRoot).attr('data-category-promise', 'fulfilled');
  //                 })
  //                 .fail(() => {
  //                     $(adRoot).attr('data-link-intel-category', 'No category');
  //                     $(adRoot).attr('data-category-promise', 'fulfilled');
  //                 });
  //             $(adRoot).attr('data-category-promise', 'pending');
  //         }
  //     }
  //     catch {
  //         $(adRoot).attr('data-category-promise', 'failed');
  //     }
  // }
  // return;
  return "";
}

function getTitle(adRoot) {
  let adTitle = '';
  if ($(adRoot).find(".update-components-article__title").length > 0) {
    adTitle = $(adRoot).find(".update-components-article__title").text().trim();
    return adTitle.trim();
  } else if (
    $(adRoot).find(".update-components-linkedin-video__description-headline")
      .length > 0
  ) {
    adTitle = $(adRoot)
      .find(".update-components-linkedin-video__description-headline")
      .first()
      .text()
      .trim();
  } else {
    return "";
  }
  return adTitle;
}

function getAdText(adRoot) {
  let adText = null;
  if ($(adRoot).find("span.break-words").length > 0) {
    adText = $(adRoot).find("span.break-words")[0].innerText.trim();
    return adText.trim();
  } else {
    return "";
  }
}

function getNewsfeedDescription(adRoot) {
  let newsfeedDescription = null;
  if ($(adRoot).find(".update-components-article__subtitle").length > 0) {
    newsfeedDescription = $(adRoot)
      .find(".update-components-article__subtitle")
      .text();
    return newsfeedDescription.trim();
  } else {
    return "";
  }
}

function getCallToAction(adRoot) {
  let call_action = null;
  if ($(adRoot).find("button.feed-shared-button").length > 0) {
    call_action = $(adRoot).find("button.feed-shared-button")[0].innerText;
    call_action = call_action.split(".")[0];
    return call_action;
  } else {
    return "";
  }
}

function getDestinationUrl(adRoot) {
  let adLinkURL = null;
  if (
    $(adRoot).find("a.app-aware-link.update-components-article__meta").length >
    0
  ) {
    adLinkURL = $(adRoot)
      .find("a.app-aware-link.update-components-article__meta")
      .attr("href");
  } else if (
    $(adRoot).find("a.update-components-linkedin-video__description-link")
      .length > 0
  ) {
    adLinkURL = $(adRoot)
      .find("a.update-components-linkedin-video__description-link")
      .first()
      .attr("href");
  }
  if (!adLinkURL) {
    if ($(adRoot).find("span.break-words").length > 0) {
      try {
        const Urls = $(adRoot).find("span.break-words a");
        const desturls = [...Urls].map((element) =>
          element.getAttribute("href")
        );
        for (var i = 0; i < desturls.length; i++) {
          if (!desturls[i].includes("linkedin.com")) {
            return desturls[i];
          }
        }
      } catch {}
    }
  }
  if (!adLinkURL && $(adRoot).find("span.break-words a").length > 0) {
    adLinkURL = $(adRoot).find("span.break-words a").attr("href");
  }
  if (!adLinkURL && $(adRoot).find("a.feed-shared-creative__link").length > 0) {
    adLinkURL = $(adRoot).find("a.feed-shared-creative__link").attr("href");
  }
  if (!adLinkURL || adLinkURL.includes("leadGenForm")) {
    if ($(adRoot).find("h3.update-components-article__subtitle").length > 0) {
      adLinkURL = $(adRoot)
        .find("h3.update-components-article__subtitle")
        .text()
        .trim();
      adLinkURL = "https://" + adLinkURL;
    }
  }
  return adLinkURL;
}

function getType(adRoot) {
  let video_type = "VIDEO";
  let image_type = "IMAGE";
  if ($(adRoot).find("video[class='vjs-tech']").length > 0) {
    return video_type;
  } else {
    return image_type;
  }
}

function getLikesCount(adRoot) {
  let likesCount;
  if ($(adRoot).find("button[aria-label*='reactions']").length > 0) {
    try {
      likesCount = $(adRoot).find("button[aria-label*='reactions']")[1]
        .innerText;
        if(!likesCount){
           likesCount = $(adRoot).find('span.social-details-social-counts__reactions-count').text();
        }
      return likesCount.trim();
    } catch {
      // return "0";
    }
  }
  // } else {
  //   return "0";
  // }
}

function getUserIp() {
  return !!geoData.userIP ? geoData.userIP : null;
}

function getUserCity() {
  return !!geoData.userCity ? geoData.userCity : null;
}

function getUserState() {
  return !!geoData.userState ? geoData.userState : null;
}

function getUserCountry() {
  return !!geoData.userCountry ? geoData.userCountry : null;
}

function getCommentsCount(adRoot) {
  let commentsCount;
  if ($(adRoot).find("button[aria-label*='comment']").length > 0) {
    try {
      commentsCount = $(adRoot).find("button[aria-label*='comment']")[0]
        .innerText;
        if(commentsCount.includes("ommen")){
            commentsCount = commentsCount.split(' ')[0];
        }
      return commentsCount.trim();
      
    } catch {
      // return "0";
    }
  }
  // } else {
  //   return "0";
  // }
}

function getAdImage(adRoot) {
  let image = null;
  let ad_type = $(adRoot).attr("data-link-intel-type");
  if (!ad_type) return;
  if ($(adRoot).attr("data-link-intel-type") === "IMAGE") {
    if (
      $(adRoot).find(
        ".feed-shared-article--with-large-image .ivm-image-view-model    img"
      ).length > 0
    ) {
      image = $(adRoot)
        .find(
          ".feed-shared-article--with-large-image .ivm-image-view-model    img"
        )
        .attr("src");
    } else if (
      $(adRoot).find("ul.artdeco-carousel__slider .ivm-image-view-model    img")
    ) {
      image = $(adRoot)
        .find("ul.artdeco-carousel__slider .ivm-image-view-model    img")
        .first()
        .attr("src");
    } else if (
      $(adRoot).find(".update-components-image__container").length > 0
    ) {
      image = $(adRoot)
        .find(".update-components-image__container img")
        .attr("src");
    }
    return image;
  } else {
    return "";
  }
}

function getImageVideoUrl(adRoot) {
  let image_video_url = null;
  let ad_type = $(adRoot).attr("data-link-intel-type");
  if (!ad_type) return;
  if ($(adRoot).attr("data-link-intel-type") === "VIDEO") {
    if ($(adRoot).find("video[class='vjs-tech']").length > 0) {
      image_video_url = $(adRoot).find("video[class='vjs-tech']").attr("src");
    }
    return image_video_url;
  } else if ($(adRoot).attr("data-link-intel-type") === "IMAGE") {
    if ($(adRoot).find("img.update-components-article__image").length > 0) {
      image_video_url = $(adRoot)
        .find("img.update-components-article__image")
        .attr("src");
    } else if (
      $(adRoot).find(".feed-shared-image img.feed-shared-image__image").length >
      0
    ) {
      image_video_url = $(adRoot)
        .find(".feed-shared-image img.feed-shared-image__image")
        .attr("src");
    } else if (
      $(adRoot).find("ul.artdeco-carousel__slider .ivm-image-view-model    img")
    ) {
      image_video_url = $(adRoot)
        .find("ul.artdeco-carousel__slider .ivm-image-view-model    img")
        .first()
        .attr("src");
    } else if ($(adRoot).find('img[class*="centered"]').length > 0) {
      image_video_url = $(adRoot).find('img[class*="centered"]').attr("src");
    }
    return image_video_url;
  }
}

function getAdId(adRoot) {
  let postId = null;
  postId = $(adRoot).attr("data-urn");
  if (postId) return postId.split(":")[3];
}

function getFollowers(adRoot) {
  // let followers = null;
  // try {
  //     if ($(adRoot).find("span.update-components-actor__description").length > 0) {
  //         followers = $(adRoot).find("span.update-components-actor__description").first().text().trim();
  //     }
  //     followers = followers.split(" ")[0];
  // } catch {

  // }
  // return followers;
  return "";
}

function buildUpGeoData() {
  if (isProcessingGeoData) {
    return;
  }
  isProcessingGeoData = true;

  if (
    !geoData.userIP ||
    !geoData.userCity ||
    !geoData.userState ||
    !geoData.userCountry
  ) {
    if (!geoData.userIP) {
      const ourIP = "https://geolocation.poweradspy.com/";
      $.ajax({
        url: ourIP,
        type: "GET",
        async: true,
        success: function (IpResponse) {
          const ourIpResponse = JSON.parse(IpResponse);
          geoData.userIP = ourIpResponse.ip;
          geoData.userCity = ourIpResponse.cityName;
          geoData.userState = ourIpResponse.regionName;
          geoData.userCountry = ourIpResponse.countryName;
          geoData.lastUpdated = Date.now();
          chrome.storage.local.set({ geoData: geoData });
          isProcessingGeoData = false;
        },
      });
    }
  }
}

function UserDetails() {
  if (UserDetailsProcessing) return;
  UserDetailsProcessing = true;
  let age = "";
  let current_country = null;
  let gender = "";
  let linkedin_id = null;
  let name = null;
  let others_places_lived = null;
  let relationship_status = "";
  let profile_link = null;

  try {
    profile_link = $("div.feed-identity-module__actor-meta")
      .find("a")
      .attr("href");
    user_ID = profile_link.split("/")[2];
    user_ID = user_ID.split("-")[2];
  } catch {
    UserDetailsProcessing = false;
  }

  if (user_ID !== undefined && user_ID !== "") {
    chrome.storage.local.get("userid", function (result) {
      const userid = result.userid;
      if (userid !== user_ID) {
        chrome.storage.local.set({ userid: user_ID });
      }
    });
  }

  try {
    linkedin_id = user_ID;

    name = $("div.feed-identity-module__actor-meta")
      .find("a")
      .first()
      .text()
      .trim();
    let profileUrl = `https://www.linkedin.com/${profile_link}`;
    $.ajax({
      url: profileUrl,
      type: "GET",
      async: true,
      success: function (profileResponse) {
        let countrySrc = getBetween(
          profileResponse,
          "defaultLocalizedName&quot;:&quot;",
          "&quot;"
        );
        current_country = countrySrc.split(",")[2]||countrySrc
        others_places_lived = countrySrc.split(",")[0];
        const profilData = {
          data: getObject({
            age: "",
            current_country: current_country,
            gender: "",
            linkedin_id: linkedin_id,
            name: name,
            others_places_lived: others_places_lived,
            relationship_status: "",
            profile_link: profile_link,
          }),
        };

        const settings = {
          async: true,
          crossDomain: true,
          url: powerAdSpyLinkedInApi + "user-chk",
          method: "POST",
          headers: {
            "content-type": "application/json",
            "cache-control": "no-cache",
          },
          processData: false,
          data: JSON.stringify(profilData),
        };
        $.ajax(settings).done(function (response) {});
      },
    });
  } catch {
    UserDetailsProcessing = false;
  }
}

function checkForNew() {
  var mainUrl = window.location.href;
  if (!mainUrl.includes("posts")) {
    $("div.relative .feed-shared-update-v2:not([data-link-intel-triaged])")
      .attr("data-link-intel-triaged", "no")
      .attr("data-link-ad", "yes")
      .attr("data-link-intel-ad-type", "feed")
      .addClass("link-intel-ad");
  }
}

function triageItems() {
  $(".link-intel-ad[data-link-intel-triaged='no']").each(function () {
    try {
      if (
        $(this).find("a.update-components-actor__container-link")
          .length > 0 ||
        $(this).find("span.update-components-actor__sub-description")
          .length > 0
      ) {
        let sponsoredLinkCount = $(this)
          .find("a.update-components-actor__container-link")
          .text();
        let differentSponsoredLinkCount = $(this)
          .find("span.update-components-actor__sub-description")[0].innerText;
        if (
          sponsoredLinkCount.includes("Promoted") ||
          differentSponsoredLinkCount.includes("Promoted")
        ) {
          $(this).attr("data-link-intel-triaged", "sponsored");
        } else {
          $(this).attr("data-link-intel-triaged", "not-sponsored");
        }
      } else if (
        $(this).find(".update-components-actor__description").length > 0
      ) {
        let newsponsoredLinkCount = $(this)
          .find(".update-components-actor__description")
          .text();
        if (newsponsoredLinkCount.includes("Promoted")) {
          $(this).attr("data-link-intel-triaged", "sponsored");
        } else {
          $(this).attr("data-link-intel-triaged", "not-sponsored");
        }
      }
    } catch (e) {
      //console.log(e);
    }
  });
}

function extractDataFromItems() {
  const startTime = Date.now();

  $(
    "div.link-intel-ad[data-link-intel-triaged='sponsored']:not([data-link-intel-parsed])"
  ).each(function () {
    let allFound = true;
    let debugPanel = "";

    let attempts = $(this).attr("data-link-intel-attempts");
    if (!attempts) {
      attempts = "1";
    } else {
      attempts = parseInt(attempts) + 1;
      if (attempts > 10) {
        $(this).attr("data-link-intel-parsed", "incomplete");
      }
    }
    $(this).attr("data-link-intel-attempts", attempts);
    debugPanel += `<p>attempts: ${attempts}</p>`;
    for (const [key, value] of Object.entries(requiredData)) {
      let attrValue = $(this).attr(value.attribute);
      if (attrValue === null || attrValue === undefined) {
        attrValue = value.method.apply(null, $(this));
      }
      if (attrValue !== null && attrValue !== undefined) {
        $(this).attr(value.attribute, `${attrValue}`);
        debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
      } else {
        debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
        allFound = false;
      }
    }
    if (allFound) {
      $(this).attr("data-link-intel-parsed", "complete"); // this means ad can be written
    }

    // console.log('=====Panel===', debugPanel);
  });
}

function saveSponsoredAds() {
  $(
    "div.link-intel-ad[data-link-intel-parsed='complete']:not([data-link-intel-saved])"
  ).each(function () {
    const adRoot = this;
    // let thisAdData = Object.assign({}, adData);
    let thisAdData = $.extend({}, adData);
    for (const [key, value] of Object.entries(requiredData)) {
      thisAdData[key] = $(adRoot).attr(value.attribute) || "";
      if (thisAdData[key] === null) {
        //if (enableDebugger)
      }
    }
    // Stringifying before sending to the Server
    const postData = JSON.stringify(thisAdData);
    const settings = {
      async: true,
      crossDomain: true,
      url: powerAdSpyLinkedInApi + "lnAdsData",
      method: "POST",
      headers: {
        "content-type": "application/json",
        "cache-control": "no-cache",
      },
      processData: false,
      data: postData,
    };
    $(adRoot).attr("data-link-intel-saved", "pending");
    delayPrecessing = true;
    $.ajax(settings)
      .done(function (response) {
        delayPrecessing = false;
        try {
          let abc = JSON.parse(response);
          if (abc.code == "200") {
            $(adRoot).attr("data-link-intel-saved", "saved");
          } else {
            $(adRoot).attr("data-link-intel-triaged", "completeforpages");
            $(adRoot).attr("data-link-intel-saved", "success");
          }
        } catch (e) {}
      })
      .fail(function () {
        delayPrecessing = false;
        $(adRoot).attr("data-link-intel-triaged", "complete");
        $(adRoot).attr("data-link-intel-saved", "failed");
      });
  });
}
