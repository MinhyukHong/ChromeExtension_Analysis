// getting 10 advertiser ads from the pagesource
let currentUrl;
let final_obj;
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.url) {
    currentUrl = message.url;
  }

  (async () => {
    if (currentUrl.includes('feedView=ads')) {
      let res = await fetch(currentUrl);
      let result = await res.text();
      let object1 = getBetween(result, '(memberTabType:POSTS', ' {"request":"/voyager/api/organization/adsTransparencyUpdate?')
      let object2 = getBetween(object1, '<code', '</code>')
      let object3 = object2?.split('>')?.[1]?.replaceAll('&quot;', '"');
      let object4 = object3?.replaceAll('&#92;', "\\");
      let object5 = object4?.replaceAll('&#61;', '=');
      final_obj = object5?.replaceAll('amp;', '');
      handleXhrIntercepted({ detail: { response: final_obj } })
    }
  })();
})

//to get the userId for the Advertiser Ads
let codeElements = document.querySelectorAll('code');
let includesPlain = Array.from(codeElements).find(codeElement => codeElement.innerHTML.includes('plain'));
let codeContent = includesPlain.innerHTML;
let jsonData = JSON.parse(codeContent);
let userId = jsonData?.included[0].publicIdentifier;
let userId1 = userId.split('-').pop();

//to get CTA
function getCallToAction1(element, second_cta) {
  let storeCTA = [];
  let call_action = null;
  if ($(element).find("span.update-components-button__text").length > 0) {
    call_action = $(element).find("span.update-components-button__text")[0]
      .innerText;
    call_action = call_action.split(".")[0];
    return call_action;
  } else {
    let cTA =
      element?.content?.inlineCtaButton?.text ||
      element?.content?.inlineCta?.text ||
      element?.leadGenFormContentV2?.ctaButton?.text || element?.leadGenFormContent?.ctaButton?.text ||
      element?.leadGenFormContentV2?.carouselContent?.items?.[0]?.content || element?.content?.linkedInVideoComponent?.inlineCtaButton?.text
      || element?.content?.articleComponent?.inlineCta?.text ||
      element?.leadGenFormContentV2?.content?.inlineCtaButton?.text ||
      "";
    let inp = element?.content?.navigationContext?.accessibilityText;
    let spilt_cta = inp?.split(":")[0].trim();
    let check_event_cta = spilt_cta?.includes("event");
    let cTA1 = check_event_cta ? spilt_cta : inp || "";
    let cTA2 = cTA || cTA1;
    storeCTA.push(cTA2, second_cta?.[1]);
    const newArray = storeCTA.filter(
      (value) =>
        value !== undefined && !value.toLowerCase().includes("sponsored page")
    );

    return newArray.join("||,");
  }
}
function getOtherMultimedia1(element) {
  let url = [];
  for (
    let i = 1;
    i <
    (element?.carouselContent?.items?.length ||
      element?.leadGenFormContentV2?.carouselContent?.items?.length ||
      element?.leadGenFormContentV2?.content?.document?.coverPages
        ?.pagesPerResolution?.[0]?.imageUrls?.length);
    i++
  ) {
    let carousel =
      element?.leadGenFormContentV2?.carouselContent ||
      element?.carouselContent ||
      element?.leadGenFormContentV2?.content;
    const imageUrl =
      (carousel?.items?.[i]?.content?.image?.attributes[0]?.vectorImage
        ?.rootUrl || carousel?.items?.[i]?.content?.creativeComponent?.image?.attributes[0]?.detailData?.vectorImage?.rootUrl) +
      (carousel?.items?.[i]?.content?.image?.attributes[0]?.vectorImage
        ?.artifacts[0]?.fileIdentifyingUrlPathSegment || carousel?.items?.[i]?.content?.creativeComponent?.image?.attributes[0]?.detailData?.vectorImage?.artifacts[0]?.fileIdentifyingUrlPathSegment
        ||
        carousel?.document?.coverPages?.pagesPerResolution?.[0]?.imageUrls[i]);
    url.push(imageUrl);
  }
  return url.join("||,");
}

function getAdId1(element) {
  const ad_id = element["*socialDetail"] || "";
  let numericPart = ad_id.replace(/.*urn:li:[^:]+:(\d+).*/, '$1');
  return numericPart;
}

function getTitle1(element) {
  let adTitle;
  let adTitles = [];
  let adTitle1;
  let title = [];

  if ($(element).find(".update-components-article__title").length > 0) {
    adTitle = $(element)
      .find(".update-components-article__title")
      .text()
      .trim();
    return adTitle.trim();
  } else if (
    $(element).find(".update-components-linkedin-video__description-headline")
      .length > 0
  ) {
    adTitle = $(element)
      .find(".update-components-linkedin-video__description-headline")
      .first()
      .text()
      .trim();
  } else if (
    $(element).find(".update-components-creative__text-container").length > 0
  ) {
    $(element)
      .find(".update-components-creative__text-container")
      .each(function () {
        var adTitle = $(this).text().trim();
        adTitles.push(adTitle);
      });
  } else if (element?.content || element?.leadGenFormContentV2 || element?.leadGenFormContent) {
    adTitle1 =
      element?.content?.title?.text || element?.content?.articleComponent?.title?.text || element?.content?.linkedInVideoComponent?.title?.text || element?.leadGenFormContent?.content?.articleComponent?.title?.text ||
      element?.leadGenFormContentV2?.content?.title?.text;
  } else {
    for (
      let i = 0;
      i <
      (element?.carouselContent?.items?.length ||
        element?.leadGenFormContentV2?.carouselContent?.items?.length);
      i++
    ) {
      let carousel =
        element?.leadGenFormContentV2?.carouselContent ||
        element?.carouselContent;
      const adTitle = carousel?.items?.[i]?.content?.headline?.text || carousel?.items?.[i]?.content?.creativeComponent?.headline?.text
      title.push(adTitle);
    }
  }
  return adTitle || adTitles.join("||,") || adTitle1 || title.join("||,");
}

function getDestinationUrl1(element) {
  let adLinkURL = null;
  if (
    $(element).find(
      'a[class="app-aware-link  update-components-creative__text-link"]'
    ).length > 0
  ) {
    adLinkURL = $(element)
      .find('a[class="app-aware-link  update-components-creative__text-link"]')
      .attr("href");
  } else if (
    $(element).find("a.app-aware-link.update-components-article__meta").length >
    0
  ) {
    adLinkURL = $(element)
      .find("a.app-aware-link.update-components-article__meta")
      .attr("href");
  } else if (
    $(element).find("a.update-components-linkedin-video__description-link")
      .length > 0
  ) {
    adLinkURL = $(element)
      .find("a.update-components-linkedin-video__description-link")
      .first()
      .attr("href");
  }
  if (!adLinkURL) {
    if ($(element).find("span.break-words").length > 0) {
      try {
        const Urls = $(element).find("span.break-words a");
        const desturls = [...Urls].map((element) =>
          element.getAttribute("href")
        );
        for (var i = 0; i < desturls.length; i++) {
          if (!desturls[i].includes("linkedin.com")) {
            return desturls[i];
          }
        }
      } catch { }
    }
  }
  if (!adLinkURL && $(element).find("span.break-words a").length > 0) {
    adLinkURL = $(element).find("span.break-words a").attr("href");
  }
  if (
    !adLinkURL &&
    $(element).find("a.feed-shared-creative__link").length > 0
  ) {
    adLinkURL = $(element).find("a.feed-shared-creative__link").attr("href");
  }
  if (!adLinkURL || adLinkURL.includes("leadGenForm")) {
    if ($(element).find("h3.update-components-article__subtitle").length > 0) {
      adLinkURL = $(element)
        .find("h3.update-components-article__subtitle")
        .text()
        .trim();
      adLinkURL = "https://" + adLinkURL;
    }
  }
  let dest =
    element?.content?.navigationContext?.actionTarget ||
    element?.content?.linkedInVideoComponent?.navigationContext?.actionTarget ||
    element?.content?.articleComponent?.navigationContext?.actionTarget ||
    element?.content?.imageComponent?.navigationContext?.actionTarget ||
    element?.carouselContent?.items?.[0]?.content?.navigationContext
      ?.actionTarget ||
    element?.actor?.navigationContext?.actionTarget ||
    element?.leadGenFormContentV2?.content?.document?.transcribedDocumentUrl;
  ("");
  return dest || adLinkURL;
}

function getadUrl1(element) {
  let adUrl = null;
  let postId = null;
  postId = $(element).attr("data-urn");
  if (postId) {
    postId = postId.split(":")[3];
    adUrl = `https://www.linkedin.com/feed/update/urn:li:activity:${postId}`;
    return adUrl;
  }
}
function getImageVideoUrl1(element) {
  let image_video_url = null;
  let type = null;
  if ($(element).find("video[class='vjs-tech']").length > 0) {
    type = "VIDEO";
  } else {
    type = "IMAGE";
  }

  if (!type) return;
  if (type === "VIDEO") {
    if ($(element).find("video[class='vjs-tech']").length > 0) {
      image_video_url = $(element).find("video[class='vjs-tech']").attr("src");
    }
    return image_video_url;
  } else if (type === "IMAGE") {
    if ($(element).find("img.update-components-article__image").length > 0) {
      image_video_url = $(element)
        .find("img.update-components-article__image")
        .attr("src");
    } else if (
      $(element).find(".feed-shared-image img.feed-shared-image__image")
        .length > 0
    ) {
      image_video_url = $(element)
        .find(".feed-shared-image img.feed-shared-image__image")
        .attr("src");
    } else if (
      $(element).find("img.update-components-image__image")
        .length > 0
    ) {
      image_video_url = $(element)
        .find("img.update-components-image__image")
        .attr("src");
    }
    return image_video_url;
  }
}

function getPostDate1(element) {
  let post_date = null;
  let image_video_url = null;
  let type = null;
  if ($(element).find("video[class='vjs-tech']").length > 0) {
    type = "VIDEO";
  } else {
    type = "IMAGE";
  }

  if (!type) return;
  if (type === "VIDEO") {
    if ($(element).find("video[class='vjs-tech']").length > 0) {
      image_video_url = $(element).find("video[class='vjs-tech']").attr("src");
    }
  } else if (type === "IMAGE") {
    if ($(element).find("img.update-components-article__image").length > 0) {
      image_video_url = $(element)
        .find("img.update-components-article__image")
        .attr("src");
    } else if (
      $(element).find(".feed-shared-image img.feed-shared-image__image")
        .length > 0
    ) {
      image_video_url = $(element)
        .find(".feed-shared-image img.feed-shared-image__image")
        .attr("src");
    } else if ($(element).find('img[class*="centered"]').length > 0) {
      image_video_url = $(element).find('img[class*="centered"]').attr("src");
    }
  }

  if (image_video_url) {
    let numbersArray = image_video_url.match(/\b\d{13}\b/);
    post_date = numbersArray?.[0];
  }
  return post_date;
}

function getFollowers1(element) {
  let followers = null;
  try {
    if (
      $(element).find("span.update-components-actor__description").length > 0
    ) {
      followers = $(element)
        .find("span.update-components-actor__description")
        .first()
        .text()
        .trim();
    }
    followers = followers.split(" ")[0];
    if (/\d+/.test(followers)) {
      return followers;
    }
  } catch { }
  const followersString = element?.actor?.description?.text;
  const regex = /[\d,]+/;
  const match = followersString?.match(regex);
  if (match) {
    const followersNumber = match[0];
    return followersNumber;
  } else {
    return "";
  }
}
// For first 3 ads by class elements
let arr = [];
(function arraydata() {
  try {
    let data = document.querySelectorAll(".feed-shared-update-v2");

    data.forEach((element) => {
      if (element.innerHTML.includes("Promoted")) {
        arr.push(element);
      }
    });
    let newarr = new Set(arr);
    let uniqueArray = Array.from(newarr);

    if (uniqueArray.length < 3) {
      document.addEventListener("scroll", arraydata);
    }
    if (uniqueArray.length === 3) {
      uniqueArray.forEach((element) => {
        requiredData1(element);
      });
      document.removeEventListener("scroll", arraydata);
    }
  } catch (error) {
  }
})();
//class name end

const interceptorScript = document.createElement("script");
interceptorScript.src = chrome.runtime.getURL("library/xhr-interceptor.js");

interceptorScript.onload = function () {
  this.remove();
};

//xhr starts
(document.head || document.documentElement).appendChild(interceptorScript);
async function handleXhrIntercepted(event) {
  try {
    const { response } = event.detail;
    const res = response?.text ? await response?.text() : response;
    if (res.includes("Promoted")) {
      const parsedResponse = JSON.parse(res);
      const like = [];
      const url = [];
      const ImageVideourl = [];
      const destination_url = [];
      for (const e of parsedResponse?.included) {
        if (e?.numLikes != null || e?.numLikes != undefined) {
          like.push({
            likes: `${e?.numLikes}`,
            coment: `${e?.numComments}`,
            id: `${e?.urn}`,
          });
        }
        if (e?.postSubmissionContent?.landingPage.url) {
          destination_url.push({
            dest_url: `${e?.postSubmissionContent?.landingPage?.url}`,
            campaignId: `${e?.postSubmissionContent?.sponsoredUrlAttributes?.creativeId}`,
            second_cta: `${e?.postSubmissionContent?.ctaText}`,
          });
        }
      }
      parsedResponse.included.forEach((element) => {
        if (element.provider == "ADS") {
          ImageVideourl.push({
            url: `${element?.progressiveStreams?.[0]?.streamingLocations?.[0]?.url}`,
            id: `${element?.entityUrn}`,
          });
        }
        if (element?.logo || element?.picture) {
          url.push({
            postimage: `${element?.logo?.rootUrl +
              (element?.logo?.artifacts?.[1]?.fileIdentifyingUrlPathSegment ||
                "") ||
              element?.picture?.rootUrl +
              (element?.picture?.artifacts?.[0]
                ?.fileIdentifyingUrlPathSegment || "")
              }`,
            cd: `${element.objectUrn}`,
          });
        }
        let likes;
        let coment;
        const promoted =
          element?.actor?.subDescription?.text || element?.updateMetadata?.trackingData?.sponsoredTracking?.displayFormat || element?.actor?.description?.text;

        if (promoted === "Promoted") {
          if (like.length > 0) {
            try {
              for (const { id, likes, coment } of like) {
                if (element["*socialDetail"].includes(id)) {
                  requiredData1(
                    element,
                    likes,
                    coment,
                    getPostOwnerImage2(element, url),
                    ImageVideourl,
                    getDestination_url_popup_image(element, destination_url)
                  );
                }
              }
            } catch (error) {
            }
          }
          else {
            try {
              requiredData1(
                element,
                likes,
                coment,
                getPostOwnerImage2(element, url),
                ImageVideourl,
                getDestination_url_popup_image(element, destination_url)
              );

            } catch (error) {
            }
          }
        }
      });
    }
  } catch (error) {
  }
}

//to get postownwerimage
function getPostOwnerImage2(element, url) {
  for (const { postimage, cd } of url) {
    if (element.actor.urn == cd) {
      return postimage || "";
    }
  }
}

//to get destination url of popup
function getDestination_url_popup_image(element, destination_url) {
  for (const { dest_url, second_cta, campaignId } of destination_url) {
    let input = element?.metadata?.trackingData?.sponsoredTracking?.adUrn;
    let match = input.match(/\d+$/);
    let Uniquenumber = match ? match[0] : null;
    if (Uniquenumber == campaignId) {
      return [dest_url, second_cta] || "";
    }
  }
}
document.addEventListener("XHR_INTERCEPTED", handleXhrIntercepted);

//to get all the required data function first 3 by class and after xhr
function requiredData1(element, likes, coment, owner, ImageVideourl, destUrl) {
  let owner2 = element?.actor?.image?.attributes[0]?.detailData?.nonEntityCompanyLogo?.vectorImage?.rootUrl + element?.actor?.image?.attributes[0]?.detailData?.nonEntityCompanyLogo?.vectorImage?.artifacts[0]?.fileIdentifyingUrlPathSegment
  const adType2 = getType2(element);
  const key1 = getImageVideoUrl2(element, ImageVideourl, adType2);
  const key2 = getPostDate2(key1);

  try {
    const result = {
      post_owner: getOwner(element) || element?.actor?.name?.text || "",
      ad_title: getTitle1(element) || "",
      followers: getFollowers1(element),
      image_video_url: getImageVideoUrl1(element) || key1,
      likes: getLikesCount(element) || likes || "0",
      comment: getCommentsCount(element) || coment || "0",
      source: "desktop",
      network: "LinkedIn",
      post_owner_image: getpostownerimage(element) || owner2 || owner,
      news_feed_description:
        getNewsfeedDescription(element) ||
        element?.leadGenFormContentV2?.content?.subtitle?.text ||
        element?.content?.subtitle?.text || element?.content?.articleComponent?.subtitle?.text || element?.leadGenFormContent?.content?.articleComponent?.subtitle?.text ||
        "",
      other_multimedia: getOtherMultimedia1(element),
      platform: Platform,
      call_to_action: getCallToAction1(element, destUrl),
      destination_url: destUrl?.[0]
        ? destUrl?.[0]
        : getDestinationUrl1(element),
      ad_category: "",
      ad_id: getAdId(element) || getAdId1(element),
      ad_url: getadUrl1(element) || getadUrl2(element),
      post_date: getPostDate1(element) || key2,
      first_seen: getFirstSeen().toString(),
      last_seen: getLastSeen().toString(),
      city: getUserCity(),
      state: getUserState(),
      country: getUserCountry(),
      ad_position: getPosition(),
      profile_link: `https://www.linkedin.com/in/${userId}` || `https://www.linkedin.com/${getUserId()}`,
      // linkedin_id: userId1 || getLinkedinId(),
      ad_text:
        getAdText(element) ||
        element?.commentary?.text?.text ||
        element?.leadGenFormContentV2?.commentary?.text?.text || element?.leadGenFormContent?.commentary?.text?.text ||
        "",
      version: version,
      ip_address: getUserIp(),
      type: adType2 ? adType2 : getType(element),
    };
    if (
      result &&
      result?.destination_url &&
      result?.image_video_url &&
      result?.post_date &&
      result?.post_owner_image &&
      result?.post_owner &&
      // result?.linkedin_id &&
      result?.type &&
      !result.image_video_url.includes("blob") &&
      !result.destination_url.includes("leadGenForm") &&
      !result.destination_url.includes("posts") &&
      !result.call_to_action.includes("Unlock Full Document")
    ) {
      sendPost(result);
    } else {
    }
  } catch (error) {
  }
}
//sending to server
async function sendPost(post) {
  try {
    const response = await fetch(powerAdSpyLinkedInApi + 'lnAdsData', {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "cache-control": "no-cache",
      },
      body: JSON.stringify(post),
    });
    const message = await response.text();
  } catch (error) { }
}

// to get adURL
function getadUrl2(element) {
  let adUrl = null;
  let ad_id = element["*socialDetail"] || "";
  ad_id = ad_id.replace(/.*urn:li:[^:]+:(\d+).*/, '$1');

  if (ad_id) {
    adUrl = `https://www.linkedin.com/feed/update/urn:li:activity:${ad_id}`;
  }
  return adUrl;
}

//to get type of ad
function getType2(element) {
  const imageTypes = [
    element?.leadGenFormContentV2?.content?.largeImage?.attributes?.[0]
      ?.vectorImage?.rootUrl,
    element?.content?.largeImage?.$type,
    element?.content?.images?.[0]?.attributes?.[0]?.vectorImage?.rootUrl,
    element?.banner?.backgroundImage?.attributes?.[0]?.vectorImage?.rootUrl,
    element?.content?.banner?.attributes?.[0]?.vectorImage?.rootUrl,
    element?.leadGenFormContentV2?.carouselContent?.items?.[0]?.content?.image
      ?.attributes?.[0]?.vectorImage?.rootUrl,
    element?.content?.thumbnail?.attributes?.[0]?.vectorImage?.rootUrl,
    element?.leadGenFormContentV2?.content?.images?.[0]?.attributes?.[0]
      ?.vectorImage?.rootUrl,
    element?.carouselContent?.items?.[0]?.content?.image?.attributes?.[0]
      ?.vectorImage?.$type,
    element?.thumbnail?.artifacts?.[0]?.fileIdentifyingUrlPathSegment,
    element?.leadGenFormContentV2?.content?.document?.coverPages
      ?.pagesPerResolution?.[0]?.imageUrls[0],
    element?.leadGenFormContentV2?.content?.thumbnail?.attributes?.[0]
      ?.vectorImage?.rootUrl,
    element?.content?.largeImage?.attributes?.[0]?.vectorImage?.rootUrl,
    element?.content?.document?.coverPages?.pagesPerResolution?.[0]
      ?.imageUrls[0],
    element?.content?.articleComponent?.largeImage?.attributes[0].detailData?.vectorImage?.rootUrl,
    element?.content?.imageComponent?.images[0]?.attributes[0]?.detailData?.vectorImage?.rootUrl,
    element?.leadGenFormContent?.content?.articleComponent?.largeImage?.attributes[0]?.detailData?.vectorImage?.rootUrl,
    element?.leadGenFormContent?.content?.imageComponent?.images[0]?.attributes[0].detailData.vectorImage.rootUrl,
    element?.carouselContent?.items[0]?.content?.creativeComponent?.image?.attributes[0]?.detailData?.vectorImage?.rootUrl
  ];

  for (const image of imageTypes) {
    if (image && (image.includes("image") || image.includes("Image"))) {
      return "IMAGE";
    }
  }
  const videoType =
    element?.content?.$type || element?.leadGenFormContentV2?.content?.$type || element?.content?.linkedInVideoComponent?.$type || element?.leadGenFormContent?.content?.linkedInVideoComponent?.$type;
  if (videoType && videoType.includes("Video")) {
    return "VIDEO";
  }

  return "";
}
// to get ImagevideoUrl
function getImageVideoUrl2(element, ImageVideourl, adType2) {
  if (adType2 == "IMAGE") {
    try {
      const image_url_element =
        element?.leadGenFormContentV2?.content ||
        element?.content ||
        element?.banner ||
        element?.carouselContent?.items[0]?.content ||
        element?.leadGenFormContentV2?.carouselContent ||
        element?.leadGenFormContent ||
        element?.thumbnail;
      const rootUrl =
        image_url_element?.largeImage?.attributes[0]?.vectorImage?.rootUrl;


      const rootUrl1 =
        image_url_element?.banner?.attributes[0]?.vectorImage?.rootUrl;
      const rootUrl2 =
        element?.leadGenFormContentV2?.content?.thumbnail?.attributes?.[0]
          ?.vectorImage?.rootUrl;
      const rootUrl3 =
        image_url_element?.largeImage?.attributes?.[0]?.vectorImage?.rootUrl
        ;
      const rootUrl4 = element?.content?.articleComponent?.largeImage?.attributes[0].detailData?.vectorImage?.rootUrl;
      const rootUrl5 = element?.leadGenFormContent?.content?.articleComponent?.largeImage?.attributes[0]?.detailData?.vectorImage?.rootUrl
      const rootUrl6 = element?.content?.imageComponent?.images[0]?.attributes[0]?.detailData?.vectorImage?.rootUrl
      const rootUrl7 = element?.leadGenFormContent?.content?.imageComponent?.images[0]?.attributes[0].detailData.vectorImage.rootUrl
      const rootUrl8 = element?.carouselContent?.items[0]?.content?.creativeComponent?.image?.attributes[0]?.detailData?.vectorImage?.rootUrl
      const rootUrl9 = element?.leadGenFormContent?.carouselContent?.items?.[0]?.content?.creativeComponent?.image?.attributes?.[0]?.detailData?.vectorImage?.rootUrl
      const imgUrls = [
        rootUrl +
        image_url_element?.largeImage?.attributes[0].vectorImage.artifacts[0]
          ?.fileIdentifyingUrlPathSegment,
        rootUrl1 +
        image_url_element?.banner?.attributes[0]?.vectorImage?.artifacts[0]
          ?.fileIdentifyingUrlPathSegment,
        rootUrl2 +
        element?.leadGenFormContentV2?.content?.thumbnail?.attributes?.[0]
          ?.vectorImage?.artifacts?.[0]?.fileIdentifyingUrlPathSegment,
        rootUrl3 +
        image_url_element?.largeImage?.attributes?.[0]?.vectorImage
          ?.artifacts?.[0]?.fileIdentifyingUrlPathSegment,
        rootUrl4 + element?.content?.articleComponent?.largeImage?.attributes[0]?.detailData?.vectorImage?.artifacts[0]?.fileIdentifyingUrlPathSegment,
        rootUrl5 + element?.leadGenFormContent?.content?.articleComponent?.largeImage?.attributes[0]?.detailData?.vectorImage?.artifacts[0]?.fileIdentifyingUrlPathSegment,
        rootUrl6 + element?.content?.imageComponent?.images[0]?.attributes[0]?.detailData?.vectorImage?.artifacts[0]?.fileIdentifyingUrlPathSegment,
        rootUrl7 + element?.leadGenFormContent?.content?.imageComponent?.images[0]?.attributes[0].detailData?.vectorImage?.artifacts[0].fileIdentifyingUrlPathSegment,
        rootUrl8 + element?.carouselContent?.items[0]?.content?.creativeComponent?.image?.attributes[0]?.detailData?.vectorImage?.artifacts[0]?.fileIdentifyingUrlPathSegment,
        rootUrl9 + element?.leadGenFormContent?.carouselContent?.items?.[0]?.content?.creativeComponent?.image?.attributes?.[0]?.detailData?.vectorImage?.artifacts?.[0]?.fileIdentifyingUrlPathSegment,
        image_url_element?.document?.coverPages?.pagesPerResolution[0]
          ?.imageUrls[0],
        image_url_element?.thumbnail?.attributes[0]?.vectorImage?.rootUrl +
        image_url_element?.thumbnail?.attributes[0]?.vectorImage?.artifacts[1]
          ?.fileIdentifyingUrlPathSegment,
        image_url_element?.images?.[0]?.attributes?.[0]?.vectorImage?.rootUrl +
        image_url_element?.images?.[0]?.attributes?.[0]?.vectorImage
          ?.artifacts?.[0]?.fileIdentifyingUrlPathSegment,
        image_url_element?.images?.[0]?.attributes[0]?.vectorImage?.rootUrl +
        image_url_element?.images?.[0].attributes[0].vectorImage.artifacts[0]
          .fileIdentifyingUrlPathSegment,
        image_url_element?.items?.[0]?.content?.image?.attributes[0]
          ?.vectorImage?.rootUrl +
        image_url_element?.items?.[0]?.content?.image?.attributes[0]
          ?.vectorImage?.artifacts[0]?.fileIdentifyingUrlPathSegment,
        image_url_element?.backgroundImage?.attributes?.[0]?.vectorImage
          ?.rootUrl +
        image_url_element?.backgroundImage?.attributes?.[0]?.vectorImage
          ?.artifacts?.[0]?.fileIdentifyingUrlPathSegment,
        image_url_element?.image?.attributes[0]?.vectorImage?.rootUrl +
        image_url_element?.image?.attributes[0]?.vectorImage?.artifacts[0]
          ?.fileIdentifyingUrlPathSegment,
        image_url_element?.banner?.attributes[0]?.vectorImage?.rootUrl +
        image_url_element?.banner?.attributes[0]?.vectorImage?.artifacts[0]
          ?.fileIdentifyingUrlPathSegment,
        image_url_element?.thumbnail?.attributes?.[0]?.vectorImage?.rootUrl +
        image_url_element?.thumbnail?.attributes?.[0]?.vectorImage
          ?.artifacts[0]?.fileIdentifyingUrlPathSegment,
        image_url_element?.artifacts?.[0]?.fileIdentifyingUrlPathSegment,
        image_url_element?.document?.coverPages?.pagesPerResolution?.[0]
          ?.imageUrls[0],
        image_url_element?.document?.coverPages?.pagesPerResolution?.[0]
          ?.imageUrls[0],
      ];
      return imgUrls.find((url) => url);
    } catch (error) {
    }
  } else {
    if (adType2 == "VIDEO") {
      try {
        for (const { url, id } of ImageVideourl) {
          if (
            element?.content?.["*videoPlayMetadata"] === id || element?.content?.linkedInVideoComponent?.["*videoPlayMetadata"] === id ||
            element?.leadGenFormContentV2?.content?.["*videoPlayMetadata"] ===
            id || element?.leadGenFormContent?.content?.linkedInVideoComponent?.["*videoPlayMetadata"]
          ) {
            return url;
          }
        }
      } catch (error) {
      }
    }
  }
}
//to get postdate
function getPostDate2(url) {
  const regex2 = /\/(\d+)(\d)\//;
  const regex1 = /\/(\d+)\?/;
  const match2 = url?.match(regex2);
  const match1 = url?.match(regex1);
  const match = match1 || match2;
  let post_date = null;

  if (match1) {
    post_date = match[1];
  }

  if (match2) {
    post_date = match[1] + match[2];
  }

  return post_date || "";
}
//end
