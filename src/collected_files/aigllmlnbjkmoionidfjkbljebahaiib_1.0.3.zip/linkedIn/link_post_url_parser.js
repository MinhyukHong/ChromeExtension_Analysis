const state = {
  openedDialogNode: undefined,
  currentAd: undefined,
  styleElement: undefined,
};

const adsQueue = [];

function enqueueLinkedInGetAdURL(adRoot) {
  const isQueued = adsQueue.find(item => item === adRoot);
  if (isQueued || state.currentAd === adRoot) {
    return;
  }
  adsQueue.push(adRoot);
}

const linkedInHidePopups = () => {
  const styleEl = document.createElement("style");
  document.head.appendChild(styleEl);
  state.styleElement = styleEl;
  const styleSheet = styleEl.sheet;
  if (!styleSheet) {
    throw new Error("No stylesheet");
  }
  styleSheet.insertRule(".feed-shared-control-menu__content { height: 0 !important; padding: 0; border: none; opacity: 0;}", 0);
  styleSheet.insertRule(".artdeco-dropdown__content-inner { height: 0}", 0);
  //   artdeco-dropdown__content-inner
  //   artdeco-dropdown__content
  styleSheet.insertRule(".artdeco-toasts_toasts { visibility: hidden }", 0);
};

const linkedInUnhidePopups = () => {
  if (state.styleElement) {
    state.styleElement.remove();
  }
};

// Options for the observer (which mutations to observe)
const config = { attributes: false, childList: true, subtree: true };

const targetNode = document.getElementsByTagName("body")[0];

const callback = function (mutationsList, observer) {
  for (const mutation of mutationsList) {
    if (mutation.type === "childList") {
      // artdeco-dropdown__content-inner
      const contextMenuContent = [...mutation.addedNodes].find(node => {
        if (!(node instanceof Element)) {
          return;
        }
        if (node && node.attributes && node.attributes.class && node.attributes.class.nodeValue === "artdeco-dropdown__content-inner") {
          return node;
        }
      });

      //   artdeco-loader

      const toast = [...mutation.addedNodes].find(node => {
        if (!(node instanceof Element)) {
          return;
        }
        if (node && node.attributes && node.attributes.class && node.attributes.class.nodeValue === "artdeco-toast-item artdeco-toast-item--visible ember-view") {
          return node;
        }
      });

      if (toast && state.currentAd) {
        const postLinkNode = toast.querySelector(".artdeco-toast-item__cta");
        if (postLinkNode) {
          const adUrl = postLinkNode.getAttribute("href");
          state.currentAd.setAttribute("data-link-intel-ad_url", adUrl);
          const closeToastButtonNode = toast.querySelector(".artdeco-toast-item__dismiss");
          if (closeToastButtonNode) {
            closeToastButtonNode.click();
            state.currentAd = undefined;
            window.setTimeout(() => linkedInUnhidePopups(), 200)
          }
        }
      }

      if (contextMenuContent && state.currentAd) {
        // feed-shared-control-menu__itemoption-share-via
        const copyLinkMenuItemNode = contextMenuContent.querySelector(".option-share-via");
        if (copyLinkMenuItemNode) {
          const copyLinkButtonNode = copyLinkMenuItemNode.querySelector("[role='button']");
          if (copyLinkButtonNode) {
            copyLinkButtonNode.click();
          }
        }
      }
    }
  }
};

// Create an observer instance linked to the callback function
const observer = new MutationObserver(callback);

// Start observing the target node for configured mutations
observer.observe(targetNode, config);

window.setInterval(() => {
  if (adsQueue.length && !state.currentAd) {
    state.currentAd = adsQueue.shift();
    linkedInHidePopups();

    const postMenuButton = state.currentAd.querySelector(".feed-shared-control-menu__trigger");
    if (!postMenuButton) {
      throw new Error("No post menu button!");
    }
    postMenuButton.click();
  }
}, 500);
