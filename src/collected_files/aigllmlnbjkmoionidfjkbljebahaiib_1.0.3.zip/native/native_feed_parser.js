// Native-Intelligence Tool
// This script runs in its own scope
// It has only the configs and variables

let defaultGeoData = {
  serviceId: null,
  lastUpdated: null,
  userCity: null,
  userState: null,
  userCountry: null,
  userIP: ""
};
const geoFunctions = [db_ip_com];
let isProcessing = false;
let scrollCounter = 0;
let intervalTimer = null;
let scrollTimer = null;

let geoData = {};

// chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
//   geoData = Object.assign(geoData, result.geoData);
//   //console.log("geoData Result ", geoData);
//   if (geoData.lastUpdated < (Date.now() - 2 * 60 * 60 * 1000)) {
//     geoData.userIP = null;
//     buildUpGeoData();
//   }
// });
chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
  geoData = Object.assign(geoData, result.geoData);
  const minDelay = 2 * 60 * 60 * 1000; // 2 hours in milliseconds
  const maxDelay = 3 * 60 * 60 * 1000; // 3 hours in milliseconds
  const randomDelay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;

  if (geoData.lastUpdated < (Date.now() - randomDelay)) {
      geoData.userIP = null;
      buildUpGeoData();
  }
});

const adData = {
  // Ad's webpage related keys
  placement_url: null,
  target_site: null,
  // Ad-Post related keys
  post_owner_image: null,
  post_date: null,
  post_owner: null,
  network: null,
  first_seen: null,
  last_seen: null,
  // For user related keys
  ip_address: null,
  city: null,
  state: null,
  country: null,
  // For ad related keys
  ad_id: null,
  ad_text: null,
  ad_position: null,
  ad_sub_position: null,
  image_url_original: null,
  ad_image: null,
  ad_image_size: null,
  ad_title: null,
  ad_number_position: null,
  type: null,
  destination_url: null,
  newsfeed_description: null,
  redirect_url: null,
  // Our Platform related keys
  platform: null,
  version: null,
  source: null
};

const requiredData = {
  // Ad's webpage related keys
  placement_url: {
    attribute: "data-native-intel-placement_url",
    method: getPlacementUrl // web page Url from where the ad is being fetched
  },
  target_site: {
    attribute: "data-native-intel-target-site",
    method: getTargetSite //current web page domain name only "https://abc.com"
  },

  // Ad-Post related keys
  post_owner_image: {
    attribute: "data-native-intel-post_owner_image",
    method: getPostOwnerImage
  },
  post_date: {
    attribute: "data-native-intel-post_date",
    method: getPostDate
  },
  post_owner: {
    attribute: "data-native-intel-post_owner",
    method: getOwner
  },
  network: {
    attribute: "data-native-intel-network",
    method: getNetwork
  },
  first_seen: {
    attribute: "data-native-intel-first_seen",
    method: getFirstSeen
  },
  last_seen: {
    attribute: "data-native-intel-last_seen",
    method: getLastSeen
  },

  // For user related keys
  ip_address: {
    attribute: "data-native-intel-ip_address",
    method: getUserIp
  },
  city: {
    attribute: "data-native-intel-city",
    method: getUserCity
  },
  state: {
    attribute: "data-native-intel-state",
    method: getUserState
  },
  country: {
    attribute: "data-native-intel-country",
    method: getUserCountry
  },

  // For ad related keys
  ad_id: {
    attribute: "data-native-intel-ad_id",
    method: getAdId //adTitle + adImage -> hashcode
  },
  ad_text: {
    attribute: "data-native-intel-ad_text",
    method: getAdText
  },
  ad_position: {
    attribute: "data-native-intel-ad_position",
    method: getPosition
  },
  ad_sub_position: {
    attribute: "data-native-intel-ad_sub_position",
    method: getSubPosition
  },
  image_url_original: {
    attribute: "data-native-intel-image_url_original",
    method: getImageOriginalUrl
  },
  ad_image: {
    attribute: "data-native-intel-ad_image",
    method: getAdImage // base64 data of Image
  },
  ad_image_size: {
    attribute: "data-native-intel-ad_image_size",
    method: getAdImageSize
  },
  ad_title: {
    attribute: "data-native-intel-ad_title",
    method: getTitle //// Get -> Title , addId, Target KeyWord, Target Page, Positions
  },
  ad_number_position: {
    attribute: "data-native-intel-ad_number_position",
    method: getNumberPosition
  },
  type: {
    attribute: "data-native-intel-type",
    method: getType
  },
  destination_url: {
    attribute: "data-native-intel-destination_url",
    method: getDestinationUrl
  },
  newsfeed_description: {
    attribute: "data-native-intel-newsfeed_description",
    method: getNewsfeedDescription
  },

  redirect_url: {
    attribute: "data-native-intel-redirect_url",
    method: getRedirectUrl
  },
  // Our Platform related keys
  version: {
    attribute: "data-native-intel-version",
    method: getVersion
  },
  source: {
    attribute: "data-native-intel-source",
    method: getsource
  },
  platform: {
    attribute: "data-native-intel-platform",
    method: getPlatform
  }
};

function start() {
  clearTimeout(scrollTimer);
  clearInterval(intervalTimer);
  scrollTimer = setTimeout(processScroll, 200);
  intervalTimer = setInterval(processScroll, 500);
}

function processScroll() {
  if (isProcessing) return;

  isProcessing = true;
  scrollCounter += 1;
  const startTime = Date.now();

  try {
    // debugger;
    if (!geoData.userCity) {
      buildUpGeoData();
      isProcessing = false;
      return;
    }

    setTimeout(checkForNew, 100);
    setTimeout(triageItems, 100);
    setTimeout(extractDataFromItems, 100);
    if (!enableDebugger) setTimeout(saveSponsoredAds, 100);
  } catch (e) {
    //if (enableDebugger)
  }
  isProcessing = false;
}
start();
