/**
 * Only helping functions are in this file
 * Pluggin start from here
 * start function "Start()"
 */
let isProcessingGeoData = false;
//process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

function buildUpGeoData() {
  if (isProcessingGeoData) {
    return;
  }
  isProcessingGeoData = true;

  if (
    !geoData.userIP ||
    !geoData.userCity ||
    !geoData.userState ||
    !geoData.userCountry
  ) {
    if (!geoData.userIP) {
      const ourIP = "https://geolocation.poweradspy.com/";
      $.ajax({
        url: ourIP,
        type: "GET",
        async: true,
        success: function (IpResponse) {
          const ourIpResponse = JSON.parse(IpResponse);
          geoData.userIP = ourIpResponse.ip;
          geoData.userCity = ourIpResponse.cityName;
          geoData.userState = ourIpResponse.regionName;
          geoData.userCountry = ourIpResponse.countryName;
          geoData.lastUpdated = Date.now();
          chrome.storage.local.set({ geoData: geoData });
          isProcessingGeoData = false;
        },
      });
    }
  }
}
function hashCode(str) {
  return str
    .split("")
    .reduce(
      (prevHash, currVal) =>
        ((prevHash << 5) - prevHash + currVal.charCodeAt(0)) | 0,
      0
    );
}
function random4DigitNumber() {
  return JSON.stringify(Math.floor(1000 + Math.random() * 9000));
}
function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}
function iframeContentsAttacher(response, classname, wrapper){
  let div = document.createElement("div");
      div.className = `pas-${classname}`
      div.style.display = "none";
      div.innerHTML = response.innerHTML;
      let adbladeWrapper = div.querySelector(wrapper);
      if (adbladeWrapper) {
        div.innerHTML = adbladeWrapper.innerHTML;
      }
      document.body.append(div);
}
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.iframeContent && message.type && message.wrapper) {
    let tempDiv = document.createElement("div");
    tempDiv.innerHTML = message.iframeContent;
    iframeContentsAttacher(tempDiv, message.type, message.wrapper);
  }
});

function checkForNew() {
//   textAd()
  const networkSelectors = {
    taboola:
      'div[observeid^="tbl-observe"] .trc_spotlight_item:not([data-native-intel-triaged]), div.videoCube.trc_spotlight_item:not([data-native-intel-triaged])',
    outbrain:
      "li.ob-dynamic-rec-container:not([data-native-intel-triaged]), div.ob-dynamic-rec-container:not([data-native-intel-triaged])",
    plista: ".plistaList .itemLink:not([data-native-intel-triaged])",
    yahooGemini: ".native-ad-item:not([data-native-intel-triaged])",
    popin: "._popIn_recommend_article:not([data-native-intel-triaged])",
    jubna: ".jb-anchor:not([data-native-intel-triaged])",
    zergent: ".zergentity:not([data-native-intel-triaged])",
    logly: ".logly-lift-ad:not([data-native-intel-triaged])",
    adblade: ".ad:not([data-native-intel-triaged])",
    strossle: '.strossle div[class^="col-sm"]:not([data-native-intel-triaged])',
    speakol: ".article-box:not([data-native-intel-triaged])",
    yengegaya: ".eng_widget_href:not([data-native-intel-triaged])",
    twiago: ".tw-box:not([data-native-intel-triaged])",
    pubExchange: "li.pe-article:not([data-native-intel-triaged])",
    gdn: "iframe[id*=google]:not([data-native-intel-triaged])",
    revcontent: ".rc-item:not([data-native-intel-triaged])",
    mgid: "div.mgline:not([data-native-intel-triaged])",
    midas:
      ".midas-article:not([data-native-intel-triaged]), ul#midasfeeddata li:not([data-native-intel-triaged])",
    polarads:
      ".polarAds .mediavoice-native-ad:not([data-native-intel-triaged])",
    adgebra: "div.adg_native_nano:not([data-native-intel-triaged])",
    desipearl: "li.oidesiwrap:not([data-native-intel-triaged])",
    dianomi: 'div.hero:not([data-native-intel-triaged])',
    paxventure: "div.pas-paxventure div#ads div#ad:not([data-native-intel-triaged])",
    // Add more networks as needed
  };

  Object.entries(networkSelectors).forEach(([network, selector]) => {
    let elements;
    if (network === "mgid") {
      elements = $(shadowRoot()).find(selector);
    } else if (network === "outbrain") {
      elements = $(shadowRoot()).find(selector);
      if (!elements) elements = $(selector);
    } else {
      elements = $(selector);
    }

    elements
      .attr({
        "data-native-intel-triaged": "no",
        "data-native-ad": "yes",
        "data-native-intel-ad-network": network,
      })
      .addClass("native-intel-ad");
  });
  //for colombia
  $('div[id*="div-clmb-ctn"] iframe').each(
    function () {
      let iframeContents = $(this).contents();
      iframeContents
        .find("div.ctn-items:not([data-native-intel-triaged])")
        .each(function () {
          $(this).attr("data-native-intel-triaged", "no");
          $(this).attr("data-native-ad", "yes");
          $(this).attr("data-native-intel-ad-network", "colombia");
          $(this).addClass("native-intel-ad");
        });
    }
  );
}

function triageItems() {
  $(".native-intel-ad[data-native-intel-triaged='no']").each(function () {
    $(this).attr("data-native-intel-triaged", "sponsored");
  });

  $(shadowRoot())
    .find('.native-intel-ad[data-native-intel-triaged="no"]')
    .each(function () {
      $(this).attr("data-native-intel-triaged", "sponsored");
    });

  // colombia
  $('div[id*="div-clmb-ctn"] iframe').each(
    function () {
      let iframeContents = $(this).contents();
      iframeContents
        .find(".native-intel-ad[data-native-intel-triaged='no']")
        .each(function () {
          $(this).attr("data-native-intel-triaged", "sponsored");
        });
    }
  );
}

  function extractDataFromItems() {
  const processItems =  function (selector) {
    $(selector).each(async function () {
      let allFound = true;
      let debugPanel = "";

      let attempts = $(this).attr("data-native-intel-attempts") || "1";
      attempts = parseInt(attempts) + 1;
      if (attempts > 8) {
        $(this).attr("data-native-intel-parsed", "incomplete");
      }

      $(this).attr("data-native-intel-attempts", attempts);

      debugPanel += `<p>attempts: ${attempts}</p>`;
      for (const [key, value] of Object.entries(requiredData)) {
        let attrValue = $(this).attr(value.attribute);
        if (attrValue === null || attrValue === undefined) {
          attrValue = await value.method.apply(null, $(this));
        }
        if (attrValue !== null && attrValue !== undefined) {
          $(this).attr(value.attribute, `${attrValue}`);
          debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
        } else {
          debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
          allFound = false;
          if (enableDebugger) {
            break;
          }
        }
      }
      if (allFound) {
        $(this).attr("data-native-intel-parsed", "complete");
      }
      if (enableDebugger) {
        $(this).append(debugPanel);
        document
          .getElementsByTagName("HTML")[0]
          .setAttribute("native-intel-debug", "true");
      }
    });
  };

  // Process items within and outside shadow root
  //for colombia
  $('div[id*="div-clmb-ctn"] iframe').each(
    function () {
      let iframeContents = $(this).contents();
      processItems(
        iframeContents.find(
          ".native-intel-ad[data-native-intel-triaged='sponsored']:not([data-native-intel-parsed])"
        )
      );
    }
  );
  processItems(
    '.native-intel-ad[data-native-intel-triaged="sponsored"]:not([data-native-intel-parsed])'
  );
  processItems(
    $(shadowRoot()).find(
      '.native-intel-ad[data-native-intel-triaged="sponsored"]:not([data-native-intel-parsed])'
    )
  );
}
function saveSponsoredAds() {
  const processItems = function (selector) {
    $(selector).each(function () {
      const adRoot = this;
      const thisAdData = Object.assign({}, adData);

      for (const [key, value] of Object.entries(requiredData)) {
        thisAdData[key] = $(adRoot).attr(value.attribute) || "";
        if (thisAdData[key] === null && enableDebugger) debugger;
      }

      if (thisAdData.ad_id !== 0) {
        const postData = JSON.stringify(thisAdData);
        let url = powerAdSpyNativeApi + "adsData";
        if (thisAdData.network === "Gdn") {
          url = powerAdSpyGDNApi + "adsData";
        }

        const settings = {
          async: true,
          crossDomain: true,
          url: url,
          method: "POST",
          headers: {
            "content-type": "application/json",
            "cache-control": "no-cache",
          },
          processData: false,
          data: postData,
        };

        $(adRoot).attr("data-native-intel-saved", "pending");
        $.ajax(settings)
          .done(function (response) {
            if (response.code == "200") {
              $(adRoot).attr("data-native-intel-saved", "saved");
            } else {
              $(adRoot).attr("data-native-intel-triaged", "complete");
              $(adRoot).attr("data-native-intel-saved", "success");
            }
          })
          .fail(function () {
            $(adRoot).attr("data-native-intel-triaged", "complete");
            $(adRoot).attr("data-native-intel-saved", "failed");
          });
      }
    });
  };
 //for colombia
 $('div[id*="div-clmb-ctn"] iframe').each(
  function () {
    let iframeContents = $(this).contents();
    processItems(
      iframeContents.find(
        '.native-intel-ad[data-native-intel-parsed="complete"]:not([data-native-intel-saved])'
      )
    );
  }
);
  // Process items within and outside shadow root
  processItems(
    '.native-intel-ad[data-native-intel-parsed="complete"]:not([data-native-intel-saved])'
  );
  processItems(
    $(shadowRoot()).find(
      '.native-intel-ad[data-native-intel-parsed="complete"]:not([data-native-intel-saved])'
    )
  );
}

function getPlacementUrl() {
  return location.href;
}
function getTargetSite() {
  let targetSite = null;
  targetSite = location.href.split("/");
  targetSite = targetSite[0] + "//" + targetSite[2];
  return targetSite;
}
function getPostOwnerImage() {
  return "";
}
function getPostDate() {
  let adPostTime;
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  adPostTime = parseInt(myDate);
  return adPostTime;
}

function getOwner(adRoot) {
  const network = $(adRoot).attr("data-native-intel-ad-network");
  let owner = null;

  if (network === "taboola" || network === "outbrain") {
    const linkSelector = network === "taboola" ? "a" : "a.ob-dynamic-rec-link";
    const link = $(adRoot).find(linkSelector).first()[0];
    if (link) {
      owner = link.hostname.split(".").slice(-2, -1)[0] || null;
    }
  } else if (network === "gdn") {
    owner = "";
  } else if (
    network === "popin" ||
    network === "logly" ||
    network === "plista"
  ) {
    const destinationUrl = $(adRoot).attr("data-native-intel-destination_url");
    if (destinationUrl) {
      const hostname = new URL(destinationUrl).hostname;
      owner = extractOwner(hostname);
    }
  } else if (network === "yahooGemini") {
    owner =
    $(adRoot).find('a[class="Fz(12px) C(--dolphin) Ell Mb(4px) Td(n)"]').text() ||
      $(adRoot)
        .find('a[class="Fz(11px) Td(n) Fw(n) D(ib) C(#959595) Mstart(9px)"]')
        .text();
  } else if (network === "revcontent") {
    owner = $(adRoot).find("div.rc-provider").text();
  } else if (network === "mgid") {
    owner = $(adRoot).find("div.mcdomain a").first().text();
  } else if (
    network === "midas" ||
    network === "desipearl" ||
    network === "adgebra"
  ) {
    owner = "";
  } 
  else if (network === "polarads") {
    owner = $(adRoot).find("div[class*='disclosure']").text();
  }
  else if(network === 'colombia'){
    owner =adRoot.querySelector('.brand_ctn').innerText;
    owner = owner.split("Ad: ")[1] || owner;
  } else if(network === "dianomi"){
    owner = $(adRoot).find('div.dianomi_provider_short').text()
  } else if(network === "paxventure"){
    owner = $(adRoot).find('b').text()
  }

  if (
    owner === undefined ||
    owner === null ||
    owner.includes("doubleclick") ||
    owner === ""
  ) {
    return null;
  }

  return owner.trim();
}

function getNetwork(adRoot) {
  let networkType = null;
  let adNetwork = $(adRoot).attr("data-native-intel-ad-network");
  if (!adNetwork) return;
  switch (adNetwork) {
    case "taboola":
      networkType = "Taboola";
      break;
    case "outbrain":
      networkType = "Outbrain";
      break;
    case "gdn":
      networkType = "Gdn";
      break;
    case "yahooGemini":
      networkType = "yahooGemini";
      break;
    case "popin":
      networkType = "popin";
      break;
    case "logly":
      networkType = "logly";
      break;
    case "plista":
      networkType = "plista";
      break;
    case "adblade":
      networkType = "adblade";
      break;
    case "jubna":
      networkType = "jubna";
      break;
    case "zergent":
      networkType = "zergent";
      break;
    case "speakol":
      networkType = "speakol";
      break;
    case "strossle":
      networkType = "strossle";
      break;
    case "yengegaya":
      networkType = "yengegaya";
      break;
    case "twiago":
      networkType = "twiago";
      break;
    case "pubExchange":
      networkType = "pubExchange";
      break;
    case "revcontent":
      networkType = "Revcontent";
      break;
    case "mgid":
      networkType = "Mgid";
      break;
    case "midas":
      networkType = "Midas";
      break;
    case "polarads":
      networkType = "polarAds";
      break;
    case "adgebra":
      networkType = "adgebra";
      break;
    case "desipearl":
      networkType = "desipearl";
      break;
    case "colombia":
      networkType = "colombia";
      break;
    case 'dianomi':
      networkType = 'dianomi';
      break;
    case "paxventure":
      networkType = "paxventure";
      break;
    default:
      return null;
  }
  return networkType;
}
function getFirstSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}
function getLastSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}
function getUserIp() {
  return !!geoData.userIP ? geoData.userIP : null;
}
function getUserCity() {
  return !!geoData.userCity ? geoData.userCity : null;
}
function getUserState() {
  return !!geoData.userState ? geoData.userState : null;
}
function getUserCountry() {
  return !!geoData.userCountry ? geoData.userCountry : null;
}

async function getAdId(adRoot) {
  let adTitle = "";
  let adImage = "";
  let adId = null;

  const adNetwork = $(adRoot).attr("data-native-intel-ad-network");
  switch (adNetwork) {
    case "taboola":
      if ($(adRoot).find(".video-title").length > 0) {
        adTitle = $(adRoot).find(".video-title")[0].innerText;
        adImage = $(adRoot).find(".thumbBlock")[0].style.backgroundImage;
        if (adImage) {
          adImage = adImage.split('"')[1];
        }
      }
      break;

    case "outbrain":
      if ($(adRoot).attr("data-native-intel-type") === "IMAGE") {
        adTitle = $(adRoot).find(".ob-unit.ob-rec-text")[0]?.title;
        adImage = $(adRoot).attr("data-native-intel-image_url_original");
      } else if ($(adRoot).attr("data-native-intel-type") === "TEXT") {
        adTitle = $(adRoot).attr("data-native-intel-ad_title");
        if(!adTitle) return null;
        adId = await getAdIdGenerator(adTitle,adImage,"native");
      }
      break;

    case "gdn":
      adImage = $(adRoot).attr("data-native-intel-ad_image");
      if (adImage) adId = await getAdIdGenerator(adTitle,adImage,"gdn");
      break;

    case "popin":
    case "logly":
    case "adblade":
    case "plista":
    case "jubna":
    case "zergent":
    case "speakol":
    case "strossle":
    case "yengegaya":
    case "twiago":
    case "pubExchange":
    case "revcontent":
    case "yahooGemini":
    case "mgid":
    case "midas":
    case "polarads":
    case "desipearl":
    case "adgebra":
      adTitle = $(adRoot).attr("data-native-intel-ad_title");
      adImage = $(adRoot).attr("data-native-intel-ad_image");
      break;
    case 'colombia':
      adTitle = $(adRoot).find("h3").text() || $(adRoot).find("h4").text();
     adImage = $(adRoot).find("img")[0]?.src;
    //  if(adTitle==='')adTitle=$(adRoot).find("h4").text();
     break;
    case 'dianomi':
      if ($(adRoot).attr('data-native-intel-type') === "IMAGE") {
        adTitle = $(adRoot).find("div.maintext").text()
        adImage = $(adRoot).find("img")[0]?.src;
      } else if ($(adRoot).attr('data-native-intel-type') === "TEXT") {
        adTitle = $(adRoot).attr("data-native-intel-ad_title");
        if (!adTitle) return null;
        adId = await getAdIdGenerator(adTitle, adImage,"native");
      }
      break;
    case "paxventure":
      adTitle = $(adRoot).find("b").text();
      adImage = $(adRoot).find("img")[0]?.src;
      break;
    default:
      return null;
  }
  // if (!adTitle) return null;
  if (adTitle && adImage) adId = await getAdIdGenerator(adTitle,adImage,"native");
  if(adId === 0) adId = null;
  return adId;
}
function getAdText(adRoot) {
  return "";
}
function getPosition() {
  return "FEED";
}
function getSubPosition() {
  return "TOP";
}
function getImageOriginalUrl(adRoot) {
  const network = $(adRoot).attr("data-native-intel-ad-network");
  let adImage = null;

  if ($(adRoot).attr("data-native-intel-type") === "TEXT") return "";

  try {
    switch (network) {
      case "taboola":
        adImage = $(adRoot).find(".thumbBlock").css("background-image");
        if (adImage) adImage = adImage.match(/url\("(.+)"\)/)[1];
        break;
      case "outbrain":
        adImage = $(adRoot).find("img.ob-rec-image").attr("src");
        if(!adImage) adImage = $(adRoot).find("div.ob-rec-rtb-image").css('background-image').match(/url\("?(.*?)"?\)/)[1]
        break;
      case "gdn":
        adImage = $(adRoot).attr("data-native-intel-ad_image");
        if (adImage)
          $(adRoot).attr("data-native-intel-image_url_original", adImage);
        break;
      case "plista":
        adImage = $(adRoot).find("img").attr("src");
        break;
      case "popin":
        adImage = $(adRoot)
          .find("._popIn_recommend_art_img a, ._popIn_recommend_art_img div")
          .css("background-image");
        if (adImage) adImage = adImage.match(/url\("(.+)"\)/)[1];
        break;
      case "logly":
        const adImageSrc = $(adRoot)
          .find(".logly-lift-ad-img-inner")
          .css("background-image");
        adImage = adImageSrc.match(/url\("?(.*?)"?\)/)[1];
        if (!adImage.includes("https")) adImage = "https://" + adImage;
        break;
      case "adblade":
      case "jubna":
      case "zergent":
      case "speakol":
      case "strossle":
      case "twiago":
      case "pubExchange":
      case "yengegaya":
        adImage = $(adRoot).find("img").attr("src");
        if (network === "yengegaya" && adImage && !adImage.includes("http"))
          adImage = "https:" + adImage;
        break;
      case "yahooGemini":
        adImage = $(adRoot).find('.gemini-item-content img, img[class*="img-native"]').attr("src");
        break;
      case "revcontent":
        adImage = $(adRoot).find("img.rc-photo").attr("src");
        if(!adImage.startsWith('https:')) adImage="https:"+adImage
        break;
      case "mgid":
        adImage = $(adRoot).find("img.mcimg").attr("src");
        break;
      case "midas":
        adImage =
          $(adRoot).find(".midas-wgt-article-image img").attr("src") ||
          $(adRoot).find("img").attr("src");
        break;
      case "polarads":
        adImage = $(adRoot).find("img[class*='img']").attr("src");
        break;
      case "desipearl":
      case "adgebra":
      case 'colombia':
        adImage = $(adRoot).find("img")[0]?.src;
        break;
      case "dianomi":
      case "paxventure":
        if($(adRoot).find("img").length > 0){
          adImage = $(adRoot).find("img")[0]?.src
        }
        break;
    }
  } catch (error) {
    
  }

  if (!adImage) return null;
  return adImage;
}

function getAdImage(adRoot) {
  let adImage = null;
  const network = $(adRoot).attr("data-native-intel-ad-network");

  if ($(adRoot).attr("data-native-intel-type") === "TEXT") return "";

  switch (network) {
    case "taboola":
      adImage =
        $(adRoot).find(".thumbBlock").length > 0
          ? $(adRoot).find(".thumbBlock")[0].style.backgroundImage.split('"')[1]
          : null;
      break;
    case "outbrain":
      adImage = $(adRoot).find("img.ob-rec-image").attr("src");
      if (!adImage)
        adImage = $(adRoot)
          .find("div.ob-rec-rtb-image")
          .css("background-image")
          .match(/url\("?(.*?)"?\)/)[1];
      break;
    case "gdn":
      adImage =
        $(adRoot).contents().find("#ad_unit a img").attr("src") ||
        $(adRoot).contents().find("amp-img > img")[0]?.src ||
        $(adRoot).contents().find("img.img_ad").attr("src");
      break;
    case "yahooGemini":
      adImage = adImage = $(adRoot)
        .find('.gemini-item-content img, img[class*="img-native"]')
        .attr("src");
      break;
    case "plista":
      adImage = $(adRoot).find("img").attr("src");
      break;
    case "popin":
      adImage = $(adRoot)
        .find("._popIn_recommend_art_img a, ._popIn_recommend_art_img div")
        .attr("style");
      if (adImage) adImage = getBetween(adImage, 'url("', '");');
      if (!adImage && $(adRoot).find("img").length > 0)
        adImage = $(adRoot).find("img").attr("src");
      break;
    case "logly":
      const adImageSrc = $(adRoot)
        .find(".logly-lift-ad-img-inner")
        .attr("style");
      adImage =
        getBetween(adImageSrc, "url(//", ");") ||
        getBetween(adImageSrc, 'url("//', '");');
      if (adImage && !adImage.includes("https")) adImage = "https://" + adImage;
      break;
    case "adblade":
    case "jubna":
    case "zergent":
    case "speakol":
    case "strossle":
    case "twiago":
    case "pubExchange":
    case "yengegaya":
      adImage = $(adRoot).find("img").attr("src");
      if (network === "yengegaya" && adImage && !adImage.includes("http"))
        adImage = "https:" + adImage;
      break;
    case "revcontent":
      adImage = $(adRoot).find("img.rc-photo").attr("src");
      if (!adImage.startsWith("https:")) adImage = "https:" + adImage;
      break;
    case "mgid":
      adImage = $(adRoot).find("img.mcimg").attr("src");
      break;
    case "midas":
      adImage = $(adRoot).find(".midas-wgt-article-image img").attr("src");
      if (!adImage) adImage = $(adRoot).find("img").attr("src");
      break;
    case "polarads":
      adImage = $(adRoot).find("img[class*='img']").attr("src");
      break;
    case "desipearl":
    case "adgebra":
    case "colombia":
      adImage = $(adRoot).find("img")[0]?.src;
      break;
    case "dianomi":
    case "paxventure":
      if ($(adRoot).find("img").length > 0)
        adImage = $(adRoot).find("img")[0]?.src;
      break;
  }

  return adImage || null;
}

function getAdImageSize(adRoot) {
  if ($(adRoot).attr("data-native-intel-type") === "TEXT") {
    return "";
  } else if ($(adRoot).attr("data-native-intel-type") === "IMAGE") {
    let height = $(adRoot).height() || 300;
    let width = $(adRoot).width() || 500;
    return `${width} * ${height}`;
  }
}
function getTitle(adRoot) {
  const network = $(adRoot).attr("data-native-intel-ad-network");
  let title = null;

  switch (network) {
    case "taboola":
      title = $(adRoot).find(".video-title").text();
      break;
    case 'gdn':
      return '';
    case "outbrain":
      if ($(adRoot).attr("data-native-intel-type") === "IMAGE") {
        title = $(adRoot).find(".ob-unit.ob-rec-text").attr("title");
      } else if ($(adRoot).attr("data-native-intel-type") === "TEXT") {
        title = $(adRoot).find("span").attr("title");
      }
      break;
    case "adblade":
      title = $(adRoot).find(".description, span.blurb").first().text();
      break;
    case "yahooGemini":
      title = $(adRoot)
        .find(
          ".gemini-item-content h4 a, .cover-title a, h3"
        )
        .first()
        .text()
        .replace('Ad', '');
      break;
    case "popin":
      title = $(adRoot)
        .find("._popIn_recommend_art_title a, ._popIn_recommend_art_title")
        .first()
        .text();
      break;
    case "logly":
      title = $(adRoot).find(".logly-lift-ad-title").text();
      break;
    case "plista":
      title = $(adRoot).find(".itemTitle").text();
      break;
    case "jubna":
      title = $(adRoot).find("span.jb-title").text();
      break;
    case "zergent":
      title = $(adRoot).find(".zergheadline a").first().text().trim();
      break;
    case "speakol":
      title = $(adRoot).find("span.sp-title-container").text().trim();
      break;
    case "strossle":
      title = $(adRoot).find("div[class^='post-title']").text().trim();
      break;
    case "yengegaya":
      title = $(adRoot).find(".eng_widget_is").text().trim();
      break;
    case "twiago":
      title = $(adRoot).find("div[class^='twiago--title']").text().trim();
      break;
    case "pubExchange":
      title = $(adRoot).find(".pe-headline").text().trim();
      break;
    case "revcontent":
      title = $(adRoot).find("h4.rc-headline").text();
      break;
    case "mgid":
      title = $(adRoot).find("div.mctitle a").text();
      break;
    case "midas":
      title = $(adRoot).find(".midas-wgt-article-title, div a").first().text();
      break;
    case "polarads":
      title = $(adRoot).find("div[class*='headline']").text().trim();
      break;
    case "desipearl":
    case "adgebra":
      title = $(adRoot).find("a")[0]?.childNodes[1]?.textContent;
      break;
    case 'colombia':
      title = $(adRoot).find("h3").text() || $(adRoot).find("h4").text();
      break;
    case "dianomi":
      title = $(adRoot).find("div.maintext").text();
      break;
    case "paxventure":
      title = $(adRoot).find("b").text();
    break;
    default:
      break;
  }

  if (!title) return null;
  return title;
}

function getNumberPosition() {
  return 1;
}
function getType(adRoot) {
  if (
    ($(adRoot).attr("data-native-intel-ad-network") === "outbrain" ||
      $(adRoot).attr("data-native-intel-ad-network") === "dianomi") &&
    !$(adRoot).find("img").length > 0
  ) {
    return "TEXT";
  } else {
    return "IMAGE";
  }
}
function getDestinationUrl(adRoot) {
  const network = $(adRoot).attr("data-native-intel-ad-network");
  let redirectUrl = null;

  switch (network) {
    case "outbrain":
      redirectUrl = $(adRoot).find("a.ob-dynamic-rec-link").attr("onmousedown");
      if (redirectUrl) {
        redirectUrl = getBetween(redirectUrl, "this.href", ";").slice(2, -1);
      }
      else{
        redirectUrl = $(adRoot).find("a.ob-dynamic-rec-link").attr("href")
      }
      break;
    case "taboola":
      redirectUrl = $(adRoot).find("a").attr("href");
      break;
    case "plista":
    case "popin":
    case "logly":
    case "dianomi":
    case "paxventure":
      redirectUrl = $(adRoot).find("a").attr("href") || $(adRoot).attr("href");
      break;
    case "yahooGemini":
      redirectUrl = $(adRoot)
        .find(
          'a[class="Mend(20px) Fxs(0) W(268px) Bdrs(8px) Ov(h)"], a[class="Fz(11px) Td(n) Fw(n) D(ib) C(#959595) Mstart(9px)"]'
        )
        .attr("href");
      break;
    case "revcontent":
      redirectUrl = $(adRoot).find("a.rc-cta").attr("href");
      break;
    case "mgid":
      redirectUrl = $(adRoot).find(".mcimg a").attr("href");
      break;
    case "midas":
      redirectUrl =
        $(adRoot).find(".midas-wgt-article-anchor").attr("href") ||
        $(adRoot).find("div a").attr("href");
      break;
    case "polarads":
      redirectUrl = $(adRoot).find("a[class*='clearfix']").attr("href");
      break;
    case 'colombia':
      redirectUrl = $(adRoot).find("a").attr("href");
      break;
    default:
      break;
  }

  return redirectUrl;
}

function getRedirectUrl(adRoot) {
  const network = $(adRoot).attr("data-native-intel-ad-network");
  let adLinkURL = null;

  switch (network) {
    case "gdn":
      adLinkURL = $(adRoot).contents().find("a").eq(0).attr("href");
      if (!adLinkURL && $(adRoot).contents().find("#ad_unit").length > 0) {
        adLinkURL = $(adRoot).contents().find("#ad_unit a").attr("href");
      }
      if (adLinkURL) {
        finalUrl(adRoot, adLinkURL);
      }
      break;
    case "adblade":
    case "jubna":
    case "zergent":
    case "speakol":
    case "strossle":
    case "twiago":
    case "pubExchange":
    case "dianomi":
    case "paxventure":
      adLinkURL = $(adRoot).find("a").attr("href");
      break;
    case "yengegaya":
      adLinkURL = $(adRoot).attr("data-orig-url");
      break;
    case "revcontent":
    case "mgid":
      adLinkURL = $(adRoot).attr("data-native-intel-destination_url");
      break;
    case "midas":
      adLinkURL =
        $(adRoot).find(".midas-wgt-article-anchor").attr("href") ||
        $(adRoot).find("div a").attr("href");
      break;
    case "adgebra":
    case "desipearl":
      adLinkURL = $(adRoot).find("a").attr("href");
      break;
    default:
      return "";
  }
  if (adLinkURL && !adLinkURL.includes("#")) {
    finalUrl(adRoot, adLinkURL);
  }
  const dUrl = $(adRoot).attr("data-native-intel-destination_url");
  if (dUrl === adLinkURL) return "";
  return adLinkURL;
}

function finalUrl(adRoot, adLinkURL) {
  const destUrl = { url: adLinkURL };
  const reqJson = {
    async: true,
    crossDomain: true,
    url: "https://postowner.poweradspy.com/get-post-owner",
    method: "POST",
    rejectUnauthorized: false,
    requestCert: true,
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
    },
    processData: false,
    data: JSON.stringify(destUrl),
  };

  if (!($(adRoot).attr("data-desturl-promise") === "pending")) {
    $.ajax(reqJson)
      .done((destUrlSrc) => {
        if (destUrlSrc.code === 200) {
          $(adRoot).attr(
            "data-native-intel-destination_url",
            destUrlSrc.final_url
          );
          $(adRoot).attr("data-native-intel-post_owner", destUrlSrc.post_owner);
          $(adRoot).attr("data-desturl-promise", "fulfilled");
        }
      })
      .fail(() => {
        $(adRoot).attr("data-desturl-promise", "failed");
      });
    $(adRoot).attr("data-desturl-promise", "pending");
  }
}

function extractOwner(ownerUrl) {
  if (ownerUrl.includes(".")) {
    var tempstr = ownerUrl.split(".");
    if (tempstr.length > 2) {
      tempstr[0] = tempstr[0]
        .replace("https://", "")
        .replace("http://", "")
        .replace("www", "");
      tempstr[1] = tempstr[1]
        .replace("https://", "")
        .replace("http://", "")
        .replace("www", "");
      if (tempstr[0].length > tempstr[1].length) {
        ownerUrl = tempstr[0];
      } else {
        ownerUrl = tempstr[1];
      }
    } else if (tempstr.length == 2) {
      if (tempstr[0].includes("http")) {
        ownerUrl = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
      } else {
        ownerUrl = tempstr[0];
      }
    }
  }
  return ownerUrl;
}
function getNewsfeedDescription(adRoot) {
  let description = "";
  if ($(adRoot).attr("data-native-intel-ad-network") === "yahooGemini") {
    description = $(adRoot)
      .find(
        'p[class="Fz(14px) C(--batcave) Lh(1.43) M(0) Bxz(bb) LineClamp(2,42px)"]'
      )
      .text();
    if (!description) {
      description = $(adRoot)
        .find(
          'p[class="Fz(14px) Lh(19px) Fz(13px)--sm1024 Lh(17px)--sm1024 LineClamp(2,38px) LineClamp(2,34px)--sm1024 Mt(5px) M(0)"]'
        )
        .text();
      if (!description) description = "";
    }
  }
  return description;
}
function getVersion() {
  return version;
}
function getsource() {
  return "desktop";
}
function getPlatform() {
  return Platform;
}

function shadowRoot() {
  try {
    let allElements = $();
    
    // Define mapping for different providers
    const providers = [
      { selector: 'div[id*="ScriptRootC1"]', shadowSelector: 'div[id*="MarketGidComposite"]' },
      { selector: 'div.ob-cards div.OUTBRAIN', shadowSelector: '.ob-widget-items-container' }
    ];

    // Iterate over providers
    providers.forEach(provider => {
      let elements = document.querySelectorAll(provider.selector);
      elements.forEach(element => {
        let shadowContent = element.shadowRoot;
        if (shadowContent) {
          let elementsInShadowRoot = $(shadowContent).find(provider.shadowSelector);
          allElements = allElements.add(elementsInShadowRoot);
        }
      });
    });

    return allElements;
  } catch (error) {
  }
}

async function getAdIdGenerator(title,image,platform){
    const url = 'https://postowner.poweradspy.com/process_ad';
    const adData = {
        ad_title: title ,
        img_video_url: image ,
        platform: platform
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(adData)
        });

        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }

        const data = await response.json();
        return data
    } catch (error) {
    }
}

function delayLoadAds() {
  let attempt = ++delayLoadAds.attempt;

  if (attempt > 5) {
    clearInterval(delayLoadAds.interval);
    return;
  }

  const networks = ["desipearl", "adgebra"];

  networks.forEach((adNetwork) => {
    const selector = `.native-intel-ad[data-native-intel-ad-network="${adNetwork}"]`;
    $(selector)
      .not("[data-native-intel-saved]")
      .each(function () {
        const attributesToRemove = [];
        $.each(this.attributes, function (index, attribute) {
          if (attribute.name.includes("data-native-intel")) {
            attributesToRemove.push(attribute.name);
          }
        });
        attributesToRemove.forEach((attribute) =>
          $(this).removeAttr(attribute)
        );
      });
  });
}

delayLoadAds.attempt = 0;
delayLoadAds.interval = setInterval(delayLoadAds, 15000);
