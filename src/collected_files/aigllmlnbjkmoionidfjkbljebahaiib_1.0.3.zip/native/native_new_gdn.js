let [firstSeen, lastSeen, date] = [ null, null, null];
let previousAdData = null

//Get between function
function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}

//For geo location
(() => {
  const retryDelay = 1000; // Adjust the delay as needed (in milliseconds)

  function fetchData() {
       userip = getUserIp();
       usercity = getUserCity();
       userstate = getUserState();
       usercountry = getUserCountry();

      if (userip === null || usercity === null || userstate === null || usercountry === null) {
          // If any of the values are null, retry after a delay
          setTimeout(fetchData, retryDelay);
      } else {
          // All values are available, proceed with the data
          // Do something with userip, usercity, userstate, usercountry
   userip = getUserIp();
    usercity = getUserCity();
    userstate =  getUserState();
    usercountry =  getUserCountry();
    firstSeen = getFirstSeen()
    lastSeen = getLastSeen()
    date = getPostDate()
    
      }
  }

  fetchData(); // Initial call to start fetching data
})();

//Saving ads here
function saveAds(data) {
  const adData = {
    placement_url: window.location.href,
    target_site: window.location.href,
    post_owner_image: '',
    post_date: `${date}`,
    post_owner: data.postowner || window.location.href.split('.')[1],
    network: 'Gdn',
    first_seen: `${firstSeen}`,
    last_seen: `${lastSeen}`,
    ip_address: userip,
    city: usercity,
    state: usercity,
    country: usercountry,
    ad_id: `${ngetAdId(data)}`,
    ad_text: '',
    ad_position: 'FEED',
    ad_sub_position: "TOP",
    image_url_original: getBetween(data.image, "url(", ")").split("\"")[1] || data.image,
    ad_image: getBetween(data.image, "url(", ")").split("\"")[1] || data.image,
    ad_image_size: data.size,
    ad_title: data.title,
    ad_number_position: '1',
    type: 'IMAGE',
    destination_url: data.destUrl,
    newsfeed_description: data.newsfeed,
    redirect_url: data.destUrl,
    platform: '3',
    version: version,
    source: 'desktop'
  };

  if (!isEqual(previousAdData, adData) || previousAdData === null) {
    previousAdData = { ...adData };
    if (adData.ad_id.length > 0 && adData.ad_image.length > 0) {
// console.log(adData)
      // sendPost(adData)
    }
  }
}

//Send to the payload
async function sendPost(post) {
  try {
    const response = await fetch(`${powerAdSpyGDNApi}insert-ads`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(post),
    });
    const message = await response.text();
  } catch (error) { }
}

//Here extracting ads from element with textAd()
// .split('SPONSORED BY')[1] for chnages
let adsArray = []
let count = 0;
function textAd() {
  let ads = {}
  const iframes = document.querySelectorAll('iframe');
  iframes.forEach((element) => {
    try {
      const iframeDocument = element.contentDocument || element.contentWindow.document;
      const isIncomplete = $(element).attr("data-native-intel-parsed") === 'incomplete';
      if (isIncomplete) {
        if (element.id.includes('google_ad') && element.width == '728' && element.height == '90') {
          try {
            if (iframeDocument.querySelectorAll('div')[16].innerText.length > 0) {
              ads['destUrl'] = iframeDocument.querySelectorAll('a')[0].href;
              ads['image'] = iframeDocument.querySelectorAll('div')[18].style.backgroundImage
              ads['title'] = iframeDocument.querySelectorAll('div')[23].innerText
              ads['newsfeed'] = '';
              ads['size'] = '728 * 90'
              ads['postowner'] = iframeDocument.querySelectorAll('div')[25].innerText
              addAds(ads)
            }
            else if (iframeDocument.querySelectorAll('div')[11].innerText.length > 0) {
              ads['destUrl'] = iframeDocument.querySelectorAll('a')[0].href;
              ads['image'] = iframeDocument.querySelectorAll('div')[6].style.backgroundImage;
              ads['title'] = iframeDocument.querySelectorAll('div')[11].innerText;
              ads['newsfeed'] = '';
              ads['size'] = '728 * 90'
              ads['postowner'] = iframeDocument.querySelectorAll('div')[13].innerText;
              addAds(ads)
            }
            else {
              ads['destUrl'] = iframeDocument.querySelectorAll('a')[0].href;
              ads['image'] = iframeDocument.querySelectorAll('img')[0].src;
              ads['title'] = '';
              ads['newsfeed'] = '';
              ads['size'] = `${iframeDocument.querySelectorAll('img')[0].width}*${iframeDocument.querySelectorAll('img')[0].height}` || '728 * 90'
              ads['postowner'] = '';
              addAds(ads)
            }
          } catch (error) {

          }
        }
        else if (element.id.includes('google_ad') && element.width == '970' && element.height == '90') {

          try {
            ads['title'] = iframeDocument.querySelectorAll('div')[11].innerText;
            ads['newsfeed'] = iframeDocument.querySelectorAll('div')[12].innerText;
            ads['destUrl'] = iframeDocument.querySelectorAll('a')[3].href;
            ads['postowner'] = iframeDocument.querySelectorAll('div')[16].innerText;
            ads['image'] = iframeDocument.querySelectorAll('div')[6].style.backgroundImage;
            ads['size'] = '970 * 90'
            addAds(ads)
          } catch (error) {

          }
        }
        else if (element.id.includes('google_ad') && element.width == '300' && element.height == '250') {

          try {
            let div = iframeDocument.querySelectorAll('div')[11]
            if (div === undefined) {
              ads['title'] = "";
              ads['newsfeed'] = '';
              ads['destUrl'] = iframeDocument.querySelectorAll('a')[0].href;
              ads['postowner'] = '';
              ads['image'] = iframeDocument.querySelectorAll('img')[0].src;
              ads['size'] = `${iframeDocument.querySelectorAll('img')[0].width}*${iframeDocument.querySelectorAll('img')[0].height}` || '300 * 250'
              addAds(ads)
            }
            else if (iframeDocument.querySelectorAll('div')[11].innerText === '') {
              if (iframeDocument.querySelectorAll('div')[8].innerText === '') {
                ads['title'] = '';
                ads['newsfeed'] = '';
                ads['destUrl'] = iframeDocument.querySelectorAll('a')[0].href;
                ads['postowner'] = '';
                ads['image'] = iframeDocument.querySelectorAll('img')[0].src;
                ads['size'] = `${iframeDocument.querySelectorAll('img')[0].width}*${iframeDocument.querySelectorAll('img')[0].height}` || '300 * 250'
                addAds(ads)
              }
              else {

                if (iframeDocument.querySelectorAll('div')[12].innerText.includes('Ads by Stop seeing this adWhy')) {
                  ads['title'] = iframeDocument.querySelectorAll('div')[8].innerText;
                  ads['newsfeed'] = '';
                  ads['destUrl'] = iframeDocument.querySelectorAll('a')[1].href;
                  ads['postowner'] = iframeDocument.querySelectorAll('div')[12].innerText;
                  ads['image'] = '';
                  ads['size'] = '300 * 250'
                  addAds(ads)
                }
                else {
                  ads['title'] = iframeDocument.querySelectorAll('div')[8].innerText;
                  ads['newsfeed'] = '';
                  ads['destUrl'] = iframeDocument.querySelectorAll('a')[1].href;
                  ads['postowner'] = iframeDocument.querySelectorAll('div')[12].innerText;
                  ads['image'] = iframeDocument.querySelectorAll('img')[0].src;
                  ads['size'] = `${iframeDocument.querySelectorAll('img')[0].width}*${iframeDocument.querySelectorAll('img')[0].height}` || '300 * 250'
                  addAds(ads)
                }
              }

            }
            else {
              ads['title'] = iframeDocument.querySelectorAll('div')[11].innerText;
              ads['newsfeed'] = '';
              ads['destUrl'] = iframeDocument.querySelectorAll('a')[3].href;
              ads['postowner'] = iframeDocument.querySelectorAll('div')[13].innerText;
              ads['image'] = iframeDocument.querySelectorAll('div')[6].style.backgroundImage;
              ads['size'] = '300 * 250'
              addAds(ads)
            }

          } catch (error) {

          }
        }
        else if (element.id.includes('google_ad') && element.width == '1290' && element.height == '250') {
          try {
            ads['destUrl'] = iframeDocument.querySelectorAll('a')[3].href;
            ads['image'] = iframeDocument.querySelectorAll('img')[0].src;
            ads['title'] = '';
            ads['newsfeed'] = '';
            ads['size'] = `${iframeDocument.querySelectorAll('img')[0].width}*${iframeDocument.querySelectorAll('img')[0].height}` || '1290 * 250'
            ads['postowner'] = '';
            addAds(ads)
          } catch (error) {

          }
        }
        else if ($('div[class="_cm-video _cm-ad"]').length > 0) {
          // console.log($('div[class="_cm-video _cm-ad"]').find('video').find('source').attr('src'))
        }
        else if (element.id.includes('google_ad') && element.width == '100%' && element.height == '536') {
          try {
            ads['destUrl'] = iframeDocument.querySelectorAll('a')[4].href;
            ads['image'] = iframeDocument.querySelectorAll('img')[2].src;
            ads['title'] = iframeDocument.querySelectorAll('div')[10].innerText.split(iframeDocument.querySelectorAll('a')[3].innerText)[0];
            ads['newsfeed'] = iframeDocument.querySelectorAll('a')[3].innerText;
            ads['size'] = `${iframeDocument.querySelectorAll('img')[2].width}*${iframeDocument.querySelectorAll('img')[2].height}` || '536 * 100%'
            ads['postowner'] = '';
            addAds(ads)
          } catch (error) {

          }
        }
      }

    } catch (error) {
    }
  });
};

//In this function it will send the ad data only once in saveAds()
function addAds(ads) {
  adsArray.push(ads)
  let newArr = Array.from(new Set(adsArray.map(entry => JSON.stringify(entry)))).map(entry => JSON.parse(entry));
  let arr = []
  if (count >= newArr.length == false) {
    // saveAds(newArr[count]);
    newArr.map((data) => {
      const isDataPresent = arr.some(obj =>
        Object.entries(data).every(([key, value]) => obj[key] === value)
      );
      if (arr.length == 0 || !isDataPresent) {
        saveAds(data)
        arr.push(data)
      }
    })
    count++
  }
}
function isEqual(obj1, obj2) {
  return JSON.stringify(obj1) === JSON.stringify(obj2);
}

//Getting ad Id
function ngetAdId(data) {
  if (data.image.includes('url')) return hashCode(getBetween(data.image, "url(", ")"))
  else return hashCode(data.image)
}









