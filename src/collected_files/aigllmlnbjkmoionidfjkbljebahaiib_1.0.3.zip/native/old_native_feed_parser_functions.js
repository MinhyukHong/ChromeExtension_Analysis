/**
 * Only helping functions are in this file
 * Pluggin start from here
 * start function "Start()"
 */
let isProcessingGeoData = false;
//process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

function buildUpGeoData() {
  if (isProcessingGeoData) {
    return;
  }
  isProcessingGeoData = true;

  if (!geoData.userIP || !geoData.userCity || !geoData.userState || !geoData.userCountry) {
    if (!geoData.userIP) {
      const ourIP = "https://geolocation.poweradspy.com/";
      $.ajax({
        url: ourIP,
        type: "GET",
        async: true,
        success: function (IpResponse) {
          const ourIpResponse = JSON.parse(IpResponse);
          geoData.userIP = ourIpResponse.ip;
          geoData.userCity = ourIpResponse.cityName;
          geoData.userState = ourIpResponse.regionName;
          geoData.userCountry = ourIpResponse.countryName;
          geoData.lastUpdated = Date.now();
          chrome.storage.local.set({ "geoData": geoData });
          isProcessingGeoData = false;
        }
      });
    }
  }
}
function hashCode(str) {
  return str
    .split("")
    .reduce(
      (prevHash, currVal) =>
        ((prevHash << 5) - prevHash + currVal.charCodeAt(0)) | 0,
      0
    );
}
function random4DigitNumber() {
  return JSON.stringify(Math.floor(1000 + Math.random() * 9000));
}
function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}

function shadowroot() {
  if (
    document.querySelector("div.OUTBRAIN div.ob-cards div.OUTBRAIN")
  ) {
    const shadowRootParent = document.querySelector(
      "div.OUTBRAIN div.ob-cards div.OUTBRAIN"
    );
    return shadowRootParent.shadowRoot || "";
  }
  
}

function checkForNew() {
  //for taboola ads
  textAd()
  $(
    'div[observeid^="tbl-observe"] .trc_spotlight_item:not([data-native-intel-triaged])'
  )
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "taboola")
    .addClass("native-intel-ad");


  // For outbrain
  $("li.ob-dynamic-rec-container:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "outbrain")
    .addClass("native-intel-ad");

  // For outbrain
  $("div.ob-dynamic-rec-container:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "outbrain")
    .addClass("native-intel-ad");
  $(shadowroot())
    .find("div.ob-dynamic-rec-container:not([data-native-intel-triaged])")
    .each(function () {
      $(this).attr("data-native-intel-triaged", "no");
      $(this).attr("data-native-ad", "yes");
      $(this).attr("data-native-intel-ad-network", "outbrain");
      $(this).addClass("native-intel-ad");
    });
  // for plista
  $(".plistaList .itemLink:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "plista")
    .addClass("native-intel-ad");

  //yahooGemini
  $(".native-ad-item:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "yahooGemini")
    .addClass("native-intel-ad");

  //popin
  $("._popIn_recommend_article:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "popin")
    .addClass("native-intel-ad");

  //jubna
  $(".jb-anchor:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "jubna")
    .addClass("native-intel-ad");


  //Zergnet
  $(".zergentity:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "zergent")
    .addClass("native-intel-ad");


  //logly
  $(".logly-lift-ad:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "logly")
    .addClass("native-intel-ad");

  //adblade
  $(".ad:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "adblade")
    .addClass("native-intel-ad");

  //strossle
  $(".strossle div[class^='col-sm']:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "strossle")
    .addClass("native-intel-ad");

  //speakol
  $(".article-box:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "speakol")
    .addClass("native-intel-ad");

  //yengegaya
  $(".eng_widget_href:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "yengegaya")
    .addClass("native-intel-ad");

  //twiago
  $(".tw-box:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "twiago")
    .addClass("native-intel-ad");

  //pubExchange
  $("li.pe-article:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "pubExchange")
    .addClass("native-intel-ad");

  //for gdn ads
  $("iframe[id*=google]:not([data-native-intel-triaged])")
    .attr("data-native-intel-triaged", "no")
    .attr("data-native-ad", "yes")
    .attr("data-native-intel-ad-network", "gdn")
    .addClass("native-intel-ad");

  //for colombia
  $('div.ad-widget.wdgt.colombiatracked.alC.ctn-colombia iframe').each(function(){
    let iframeContents = $(this).contents()
    iframeContents.find('div.ctn-items:not([data-native-intel-triaged])').each(function(){
      $(this).attr("data-native-intel-triaged", "no");
      $(this).attr("data-native-ad", "yes");
      $(this).attr("data-native-intel-ad-network", "colombia");
      $(this).addClass("native-intel-ad");
    })
  })
  // adgebra
  $('div.adg_native_nano:not([data-native-intel-triaged])').each(function(){
    $(this).attr("data-native-intel-triaged", "no");
      $(this).attr("data-native-ad", "yes");
      $(this).attr("data-native-intel-ad-network", "adgebra");
      $(this).addClass("native-intel-ad");
  })
  //desipearl
  $("li.oidesiwrap:not([data-native-intel-triaged])").each(function () {
    $(this).attr("data-native-intel-triaged", "no");
    $(this).attr("data-native-ad", "yes");
    $(this).attr("data-native-intel-ad-network", "desipearl");
    $(this).addClass("native-intel-ad");
  });
}
function triageItems() {
  // for taboola
  $(".native-intel-ad[data-native-intel-triaged='no']").each(function () {
    $(this).attr("data-native-intel-triaged", "sponsored");
  });
  $(shadowroot())
    .find(".native-intel-ad[data-native-intel-triaged='no']")
    .each(function () {
      $(this).attr("data-native-intel-triaged", "sponsored");
    });
  $("div.ad-widget.wdgt.colombiatracked.alC.ctn-colombia iframe").each(
    function () {
      let iframeContents = $(this).contents();
      iframeContents
        .find(".native-intel-ad[data-native-intel-triaged='no']")
        .each(function () {
          $(this).attr("data-native-intel-triaged", "sponsored");
        });
    }
  );
}
async function extract(element) {
  let allFound = true;
  let debugPanel = "";
  let attempts = $(element).attr("data-native-intel-attempts");
  if (!attempts) attempts = "1";
  else {
    attempts = parseInt(attempts) + 1;
    if (attempts > 8)
      $(element).attr("data-native-intel-parsed", "incomplete");
  }
  $(element).attr("data-native-intel-attempts", attempts);
  debugPanel += `<p>attempts: ${attempts}</p>`;
  for (const [key, value] of Object.entries(requiredData)) {
    let attrValue = $(element).attr(value.attribute);
    if (attrValue === null || attrValue === undefined) {
      attrValue = await value.method.apply(null, $(element));
    }
    if (attrValue !== null && attrValue !== undefined) {
      $(element).attr(value.attribute, `${attrValue}`);
      debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
    } else {
      debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
      allFound = false;
      if (enableDebugger) {
        break;
      }
    }
  }
  if (allFound) {
    $(element).attr("data-native-intel-parsed", "complete"); // this means ad can be written
  }
  if (enableDebugger) {
    $(element).append(debugPanel);
    document
      .getElementsByTagName("HTML")[0]
      .setAttribute("native-intel-debug", "true");
  }
}

function extractDataFromItems() {
  // shadowroot
  $(shadowroot())
    .find(
      ".native-intel-ad[data-native-intel-triaged='sponsored']:not([data-native-intel-parsed])"
    )
    .each(function () {
      extract(this)
    });
  $(
    ".native-intel-ad[data-native-intel-triaged='sponsored']:not([data-native-intel-parsed])"
  ).each(function () {
    extract(this)
  });
  // colombia iframe document
  $("div.ad-widget.wdgt.colombiatracked.alC.ctn-colombia iframe").each(
    function () {
      let iframeContents = $(this).contents();
      iframeContents
        .find(
          ".native-intel-ad[data-native-intel-triaged='sponsored']:not([data-native-intel-parsed])"
        )
        .each(function () {
          extract(this);
        });
    }
  );
}

function save(element){
  const adRoot = element;
      let thisAdData = Object.assign({}, adData);
      for (const [key, value] of Object.entries(requiredData)) {
        thisAdData[key] = $(adRoot).attr(value.attribute) || "";
        if (thisAdData[key] === null) {
          if (enableDebugger) debugger;
        }
      }
      if (thisAdData['ad_id'] !== 0) {
        // Stringifying before sending to the Server
        const postData = JSON.stringify(thisAdData);
        let url = powerAdSpyNativeApi + "adsData";
        if (thisAdData.network === "Gdn") {
          url = powerAdSpyGDNApi + "adsData";
        }
        // Ajax setting
        const settings = {
          async: true,
          crossDomain: true,
          url: url,
          method: "POST",
          headers: {
            "content-type": "application/json",
            "cache-control": "no-cache",
          },
          processData: false,
          data: postData,
        };
        // Initially it will be in pending state if uploaded in saved else failed
        $(adRoot).attr("data-native-intel-saved", "pending");
        $.ajax(settings)
          .done(function (response) {
            if (response.code == "200") {
              $(adRoot).attr("data-native-intel-saved", "saved");
            } else {
              $(adRoot).attr("data-native-intel-triaged", "complete");
              $(adRoot).attr("data-native-intel-saved", "success");
            }
          })
          .fail(function () {
            // mark as done so we won't retry
            $(adRoot).attr("data-native-intel-triaged", "complete");
            $(adRoot).attr("data-native-intel-saved", "failed");
          });
      }
}

function saveSponsoredAds() {
  $(shadowroot())
    .find(
      ".native-intel-ad[data-native-intel-parsed='complete']:not([data-native-intel-saved])"
    )
    .each(function () {
      save(this);
    });
  $(
    ".native-intel-ad[data-native-intel-parsed='complete']:not([data-native-intel-saved])"
  ).each(function () {
    // Preparing post data from the scraped ads data
    save(this);
  });
  // colombia iframe document
  $("div.ad-widget.wdgt.colombiatracked.alC.ctn-colombia iframe").each(
    function () {
      let iframeContents = $(this).contents();
      iframeContents
        .find(
          ".native-intel-ad[data-native-intel-parsed='complete']:not([data-native-intel-saved])"
        )
        .each(function () {
          save(this);
        });
    }
  );
}

function getPlacementUrl() {
  return location.href;
}
function getTargetSite() {
  let targetSite = null;
  targetSite = location.href.split("/");
  targetSite = targetSite[0] + "://" + targetSite[2];
  return targetSite;
}
function getPostOwnerImage() {
  return "";
}
function getPostDate() {
  let adPostTime;
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  adPostTime = parseInt(myDate);
  return adPostTime;
}
async function getOwner(adRoot) {
  // From destination URL
  let owner = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find("a").length > 0
  ) {
    owner = $(adRoot).find("a")[0].hostname;

    if (owner) {
      owner = owner.split(".");

      if (owner.length > 2) owner = owner[1];
      else if (owner.length > 1) owner = owner[0];
      else owner = null;
    }
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find("a.ob-dynamic-rec-link").length > 0
  ) {
    owner = $(adRoot).find("a.ob-dynamic-rec-link")[0].hostname;
    if (owner) {
      owner = owner.split(".");
      if (owner.length > 2) owner = owner[1];
      else if (owner.length > 1) owner = owner[0];
      else owner = null;
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "gdn") {
    owner = "";
  }
  else if ($(adRoot).attr("data-native-intel-ad-network") === "popin" ||
    $(adRoot).attr("data-native-intel-ad-network") === "logly" ||
    $(adRoot).attr("data-native-intel-ad-network") === "plista") {
    let ownerUrl = null;
    owner = $(adRoot).attr("data-native-intel-destination_url");
    if (owner) {
      try {
        owner = $(adRoot).find("a")[0].hostname;
        if (owner) {
          owner = owner.split(".");
          if (owner.length > 2) owner = owner[1];
          else if (owner.length > 1) owner = owner[0];
          else owner = null;
        }
      }
      catch {
        ownerUrl = '';
      }
      if (ownerUrl === '') {
        owner = extractOwner(owner);
      }
    } else {
      return null;
    }
    if (owner === undefined || owner === null || owner.includes("popin") ||
      owner.includes("plista") || owner.includes("logly")) return null;
  }
  else if ($(adRoot).attr("data-native-intel-ad-network") === "yahooGemini") {
    owner = $(adRoot).find('a[class="Fz(12px) C(--dolphin) Ell Mb(4px) Td(n)"]').text()
    if (!owner) {
      return $(adRoot).find('a[class="Fz(11px) Td(n) Fw(n) D(ib) C(#959595) Mstart(9px)"]').text()
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "colombia") {
    owner = $(adRoot).find("p.brand_ctn").text();
    owner = owner.split("Ad: ")[1];
  } 
  else if (
    $(adRoot).attr("data-native-intel-ad-network") === "desipearl" ||
    $(adRoot).attr("data-native-intel-ad-network") === "adgebra"
  ) {
    let own = $(adRoot).find("a").attr("href");
    if (own && !own.includes('#')) {
      owner = await GetPostOwner(own)
      owner = JSON.parse(owner)
      owner = owner.post_owner
    }
  }
  if (owner === undefined || owner === null || owner.includes("doubleclick")) {
    return null;
  }

  return owner;
}
function getNetwork(adRoot) {
  let networkType = null;
  let adNetwork = $(adRoot).attr('data-native-intel-ad-network');
  if (!adNetwork) return;
  switch (adNetwork) {
    case 'taboola':
      networkType = "Taboola";
      break;
    case 'outbrain':
      networkType = "Outbrain";
      break;
    case 'gdn':
      networkType = "Gdn";
      break;
    case 'yahooGemini':
      networkType = "yahooGemini";
      break;
    case 'popin':
      networkType = "popin";
      break;
    case 'logly':
      networkType = "logly";
      break;
    case 'plista':
      networkType = "plista";
      break;
    case 'adblade':
      networkType = "adblade";
      break;
    case 'jubna':
      networkType = "jubna";
      break;
    case 'zergent':
      networkType = "zergent";
      break;
    case 'speakol':
      networkType = "speakol";
      break;
    case 'strossle':
      networkType = "strossle";
      break;
    case 'yengegaya':
      networkType = "yengegaya";
      break;
    case 'twiago':
      networkType = "twiago";
      break;
    case 'pubExchange':
      networkType = "pubExchange";
      break;
    case 'colombia':
      networkType = "colombia";
      break;
    case 'adgebra':
      networkType = "adgebra";
      break;
    case 'desipearl':
      networkType = "desipearl";
      break;
    default: return null;
  }
  return networkType;
}
function getFirstSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}
function getLastSeen() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}
function getUserIp() {
  return !!geoData.userIP ? geoData.userIP : null;
}
function getUserCity() {
  return !!geoData.userCity ? geoData.userCity : null;
}
function getUserState() {
  return !!geoData.userState ? geoData.userState : null;
}
function getUserCountry() {
  return !!geoData.userCountry ? geoData.userCountry : null;
}
function getAdId(adRoot) {
  let adTitle = null,
    adImage = null;
  let adId = adTitle + adImage;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".video-title").length > 0
  ) {
    adTitle = $(adRoot).find(".video-title")[0].innerText;
    adImage = $(adRoot).find(".thumbBlock")[0].style.backgroundImage;
    if (adImage) {
      adImage = adImage.split('"')[1];
    }

    if (adTitle && adImage) adId = hashCode(adId + adImage);
    if (adId == 0) adId = null;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain") {
    if ($(adRoot).attr('data-native-intel-type') === "IMAGE") {
      adTitle = $(adRoot).find(".ob-unit.ob-rec-text")[0].title;
      adImage = $(adRoot).find("img.ob-rec-image")[0]?.src  || getBetween($(adRoot).find("div.ob-rec-rtb-image").eq(0).attr("style"),"('","')");
      if (adTitle && adImage) adId = hashCode(adId + adImage);
    } else if ($(adRoot).attr('data-native-intel-type') === "TEXT") {
      adTitle = $(adRoot).attr("data-native-intel-ad_title");
      if (!adTitle) return null;
      adId = hashCode(adTitle);
    }
    if (adId == 0) adId = null;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "colombia" &&
    $(adRoot).find("h3").length > 0
  ) {
    adTitle = $(adRoot).find("h3").text();
    adImage = $(adRoot).find("img")[0]?.src;
    if (adTitle && adImage) adId = hashCode(adId + adImage);
    if (adId == 0) adId = null;
  } else if (
    ($(adRoot).attr("data-native-intel-ad-network") === "desipearl" ||
      $(adRoot).attr("data-native-intel-ad-network") === "adgebra") 
  ) {
    adTitle = $(adRoot).find("a")[0]?.childNodes[1]?.textContent;
    adImage = $(adRoot).find("img")[0]?.src;
    if (adTitle && adImage) adId = hashCode(adId + adImage);
    if (adId == 0) adId = null;
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "gdn") {
    adImage = $(adRoot).attr("data-native-intel-ad_image");
    if (adImage) adId = hashCode(adImage);
    if (adId == 0) adId = null;
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "popin" ||
    $(adRoot).attr("data-native-intel-ad-network") === "logly" ||
    $(adRoot).attr("data-native-intel-ad-network") === "adblade" ||
    $(adRoot).attr("data-native-intel-ad-network") === "plista" ||
    $(adRoot).attr("data-native-intel-ad-network") === "jubna" ||
    $(adRoot).attr("data-native-intel-ad-network") === "zergent" ||
    $(adRoot).attr("data-native-intel-ad-network") === "speakol" ||
    $(adRoot).attr("data-native-intel-ad-network") === "strossle" ||
    $(adRoot).attr("data-native-intel-ad-network") === "yengegaya" ||
    $(adRoot).attr("data-native-intel-ad-network") === "twiago" ||
    $(adRoot).attr("data-native-intel-ad-network") === "pubExchange") {
      adTitle = $(adRoot).attr("data-native-intel-ad_title");
      adImage = $(adImage).attr("data-native-intel-ad_image");
      if (!adTitle) return null;
      if (adTitle && adImage) adId = hashCode(adId + adImage);
  }
else if($(adRoot).attr("data-native-intel-ad-network") === "yahooGemini"){
  adTitle = $(adRoot).attr("data-native-intel-ad_title");
  adImage = $(adRoot).attr("data-native-intel-ad_image");
  if (!adTitle) return null;
  if (adTitle && adImage) {
    adId = hashCode(adId + adImage)
    if(adId===0) adId = null;
  }
}
  return adId;
}
function getAdText(adRoot) {
  return "";
}
function getPosition() {
  return "FEED";
}
function getSubPosition() {
  return "TOP";
}
function getImageOriginalUrl(adRoot) {
  let adImage = null;
  if ($(adRoot).attr('data-native-intel-type') === "TEXT") {
    return "";
  }
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".thumbBlock").length > 0
  ) {
    adImage = $(adRoot).find(".thumbBlock")[0].style.backgroundImage;
    if (adImage) {
      adImage = adImage.split('"')[1];
    }
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    ($(adRoot).find("img.ob-rec-image").length > 0 || $(adRoot).find("div.ob-rec-rtb-image").length > 0)
  ) {
    adImage = $(adRoot).find("img.ob-rec-image")[0]?.src || getBetween($(adRoot).find("div.ob-rec-rtb-image").eq(0).attr("style"),"('","')");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "gdn"
  ) {
    adImage = $(adRoot).attr("data-native-intel-ad_image");
    if (adImage) {
      $(adRoot).attr("data-native-intel-image_url_original", adImage);
    }
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "plista") {
    adImage = $(adRoot).find("img").attr("src");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "popin" &&
    $(adRoot).find("._popIn_recommend_art_img").length > 0
  ) {
    adImage = $(adRoot).find("._popIn_recommend_art_img a").attr("style");
    if (!adImage)
      adImage = $(adRoot).find("._popIn_recommend_art_img div").attr("style");
    if (adImage)
      adImage = getBetween(adImage, 'url("', '");');
    if (!adImage && $(adRoot).find("img").length > 0)
      adImage = $(adRoot).find("img").attr("src");
    if (adImage === "") return null;
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "logly") {
    let adImageSrc = $(adRoot).find(".logly-lift-ad-img-inner").attr("style");
    adImage = getBetween(adImageSrc, 'url(//', ');');
    if (adImage === "") adImage = getBetween(adImageSrc, 'url("//', '");');
    if (adImage === "") return null;
    if (!adImage.includes("https")) adImage = "https://" + adImage;
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "adblade" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "yahooGemini"
  ) {
    adImage = $(adRoot).find(".gemini-item-content img").attr("src");
    if (!adImage) {
      adImage = $(adRoot).find("a[class='Mend(20px) Fxs(0) W(268px) Bdrs(8px) Ov(h)'] div img").attr("src");
      if (!adImage) {
        adImage = $(adRoot).find("a[class='Fl(start) Mt(3px) Mend(25px) W(26.5%) Maw(220px)'] div img").attr("src")
        if (adImage.includes('.gif')) return null;
      }
      else if (adImage.includes('.gif')) return null;
    }
    else if (adImage.includes('.gif')) return null;

  } else if ($(adRoot).attr("data-native-intel-ad-network") === "jubna" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "zergent" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "speakol" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "strossle" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "twiago" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "pubExchange" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "yengegaya" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
    if (!adImage.includes("http"))
      adImage = 'https:' + adImage;
  }
  else if (
    $(adRoot).attr("data-native-intel-ad-network") === "colombia" &&
    $(adRoot).find("img").length > 0
  ) {
    adImage = $(adRoot).find("img")[0]?.src;
  } else if (
    ($(adRoot).attr("data-native-intel-ad-network") === "desipearl" ||
      $(adRoot).attr("data-native-intel-ad-network") === "adgebra") &&
    $(adRoot).find("img").length > 0
  ) {
    adImage = $(adRoot).find("img")[0]?.src;
  }
  if (!adImage) return null;
  return adImage;
}
function getAdImage(adRoot) {
  let adImage = null;
  if ($(adRoot).attr('data-native-intel-type') === "TEXT") {
    return "";
  }
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".thumbBlock").length > 0
  ) {
    adImage = $(adRoot).find(".thumbBlock")[0].style.backgroundImage;
    if (adImage) {
      adImage = adImage.split('"')[1];
    }
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    ($(adRoot).find("img.ob-rec-image").length > 0 || $(adRoot).find("div.ob-rec-rtb-image").length > 0)
  ) {
    adImage = $(adRoot).find("img.ob-rec-image")[0]?.src || getBetween($(adRoot).find("div.ob-rec-rtb-image").eq(0).attr("style"),"('","')");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "gdn" &&
    $(adRoot)
      .contents().find("#ad_unit")
      .length > 0
  ) {
    adImage = $(adRoot).contents().find("#ad_unit").find("a img").attr("src");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "gdn" &&
    $(adRoot)
      .contents()
      .find("amp-img > img").length > 0
  ) {
    adImage = $(adRoot)
      .contents()
      .find("amp-img > img")[0].src;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "gdn" &&
    $(adRoot)
      .contents()
      .find("img.img_ad").length > 0
  ) {
    adImage = $(adRoot).contents().find("img.img_ad").attr("src");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "gdn" &&
    $(adRoot)
      .contents()
      .find("img.img_ad").length > 0
  ) {
    adImage = $(adRoot).contents().find("img.img_ad").attr("src");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "yahooGemini"
  ) {
    adImage = $(adRoot).find(".gemini-item-content img").attr("src");
    if (!adImage) {
      adImage = $(adRoot).find("a[class='Mend(20px) Fxs(0) W(268px) Bdrs(8px) Ov(h)'] div img").attr("src");
      if (!adImage) {
        adImage = $(adRoot).find("a[class='Fl(start) Mt(3px) Mend(25px) W(26.5%) Maw(220px)'] div img").attr("src")
        if (adImage.includes('.gif')) return null;
      }
      else if (adImage.includes('.gif')) return null;
    }
    else if (adImage.includes('.gif')) return null;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "plista") {
    adImage = $(adRoot).find("img").attr("src");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "popin" &&
    $(adRoot).find("._popIn_recommend_art_img").length > 0
  ) {
    adImage = $(adRoot).find("._popIn_recommend_art_img a").attr("style");
    if (!adImage)
      adImage = $(adRoot).find("._popIn_recommend_art_img div").attr("style");
    if (adImage)
      adImage = getBetween(adImage, 'url("', '");');
    if (!adImage && $(adRoot).find("img").length > 0)
      adImage = $(adRoot).find("img").attr("src");
    if (adImage === "") return null;
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "logly") {
    let adImageSrc = $(adRoot).find(".logly-lift-ad-img-inner").attr("style");
    adImage = getBetween(adImageSrc, 'url(//', ');');
    if (adImage === "")
      adImage = getBetween(adImageSrc, 'url("//', '");');
    if (adImage === "") return null;
    if (!adImage.includes("https")) adImage = "https://" + adImage;
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "adblade" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "jubna" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "zergent" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "speakol" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "strossle" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "twiago" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "pubExchange" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "yengegaya" &&
    $(adRoot).find("img").length > 0) {
    adImage = $(adRoot).find("img").attr("src");
    if (!adImage.includes("http"))
      adImage = 'https:' + adImage;
  }
  else if (
    $(adRoot).attr("data-native-intel-ad-network") === "colombia" &&
    $(adRoot).find("img").length > 0
  ) {
    adImage = $(adRoot).find("img")[0]?.src;
  } else if (
    ($(adRoot).attr("data-native-intel-ad-network") === "desipearl" ||
      $(adRoot).attr("data-native-intel-ad-network") === "adgebra") &&
    $(adRoot).find("img").length > 0
  ) {
    adImage = $(adRoot).find("img")[0]?.src;
  }
  if (!adImage) return null;
  return adImage;
}
function getAdImageSize(adRoot) {
  if ($(adRoot).attr('data-native-intel-type') === "TEXT") {
    return "";
  } else if ($(adRoot).attr('data-native-intel-type') === "IMAGE") {
    let height = $(adRoot).height() || 300;
    let width = $(adRoot).width() || 500;
    return `${width} * ${height}`;
  }
}
function getTitle(adRoot) {
  let title = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find(".video-title").length > 0
  ) {
    title = $(adRoot).find(".video-title")[0].innerText;
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain") {
    if ($(adRoot).attr('data-native-intel-type') === "IMAGE") {
      title = $(adRoot).find(".ob-unit.ob-rec-text")[0].title;
    } else if ($(adRoot).attr('data-native-intel-type') === "TEXT") {
      title = $(adRoot).find("span").attr('title');
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "gdn") {
    title = "";
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "adblade") {
    title = $(adRoot).find(".description").first().text();
    if (!title)
      title = $(adRoot).find("span.blurb").first().text();
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "yahooGemini"
  ) {
    title = $(adRoot).find(".gemini-item-content h4 a").text();
    if (!title) {
      title = $(adRoot).find(".cover-title a").text();
      if (!title) {
        title = $(adRoot).find('h3[class="My(2px) Lh(1.33) Fz(18px) Fz(16px)--maw1024 Fw(b) LineClamp(1,1.6em)"]').text();
        if (!title) {
          title = $(adRoot).find('h3[class="M(0)"] a span').text()
        }
      }
    }

  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "popin" &&
    $(adRoot).find("._popIn_recommend_art_title").length > 0
  ) {
    title = $(adRoot).find("._popIn_recommend_art_title a").text();
    if (!title)
      title = $(adRoot).find("._popIn_recommend_art_title").text();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "logly") {
    title = $(adRoot).find(".logly-lift-ad-title").text();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "plista") {
    title = $(adRoot).find(".itemTitle").text();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "jubna") {
    title = $(adRoot).find("span.jb-title").text();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "zergent") {
    title = $(adRoot).find(".zergheadline a").first().text().trim();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "speakol") {
    title = $(adRoot).find("span.sp-title-container").text().trim();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "strossle") {
    title = $(adRoot).find("div[class^='post-title']").text().trim();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "yengegaya") {
    title = $(adRoot).find(".eng_widget_is").text().trim();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "twiago") {
    title = $(adRoot).find("div[class^='twiago--title']").text().trim();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "pubExchange") {
    title = $(adRoot).find(".pe-headline").text().trim();
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "colombia") {
    title = $(adRoot).find("h3").text();
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "adgebra" ||
    $(adRoot).attr("data-native-intel-ad-network") === "desipearl"
  ) {
    if ($(adRoot).find("a")[0]?.childNodes[1]?.textContent)
      title = $(adRoot).find("a")[0].childNodes[1].textContent;
  }
  return title;
}
function getNumberPosition() {
  return 1;
}
function getType(adRoot) {
  if ($(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    !$(adRoot).find('img').length > 0) {
    return "TEXT";
  } else {
    return "IMAGE";
  }
}
function getDestinationUrl(adRoot) {
  let redirectUrl = null;
  if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain" &&
    $(adRoot).find("a.ob-dynamic-rec-link").length > 0
  ) {
    redirectUrl = $(adRoot).find("a").attr("onmousedown");
    redirectUrl = getBetween(redirectUrl, "this.href", ";");
    redirectUrl = redirectUrl.slice(2, -1);
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "taboola" &&
    $(adRoot).find("a").length > 0
  ) {
    redirectUrl = $(adRoot).find("a").attr("href");
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "plista"
  ) {
    redirectUrl = $(adRoot).find('a').attr('href');
    if (!redirectUrl)
      redirectUrl = $(adRoot).attr('href');
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "popin") {
    redirectUrl = $(adRoot).find('a').attr('href');
    if (!redirectUrl)
      redirectUrl = $(adRoot).attr('href');
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "logly") {
    redirectUrl = $(adRoot).find('a').attr('href');
    if (!redirectUrl)
      redirectUrl = $(adRoot).attr('href');
  }
  else if (
    $(adRoot).attr("data-native-intel-ad-network") === "yahooGemini"
  ) {
    redirectUrl = $(adRoot).find('a[class="Mend(20px) Fxs(0) W(268px) Bdrs(8px) Ov(h)"]').attr('href');
    if(!redirectUrl){
      redirectUrl = $(adRoot).find('a[class="Fz(11px) Td(n) Fw(n) D(ib) C(#959595) Mstart(9px)"]').attr('href')
    }
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "colombia" &&
    $(adRoot).find("a").length > 0
  ) {
    redirectUrl = $(adRoot).find("a").attr("href");
  } else if (
    ($(adRoot).attr("data-native-intel-ad-network") === "desipearl" ||
      $(adRoot).attr("data-native-intel-ad-network") === "adgebra") &&
    $(adRoot).find("a").length > 0
  ) {
    redirectUrl = $(adRoot).find("a").attr("href");
    redirectUrl = !redirectUrl.includes('#') ? redirectUrl : null
  }
  return redirectUrl;
}
function getRedirectUrl(adRoot) {
  let adLinkURL = null;
  if ($(adRoot).attr("data-native-intel-ad-network") === "taboola") {
    return "";
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "outbrain") {
    return "";
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "gdn"
  ) {
    if ($(adRoot)
      .contents()
      .find("a").length > 0)
      adLinkURL = $(adRoot)
        .contents()
        .find("a")[0].href;
    if (!adLinkURL && $(adRoot)
      .contents()
      .find("#ad_unit").length > 0) {
      adLinkURL = $(adRoot).contents().find("#ad_unit").find("a").attr("src");
    }
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "adblade"
  ) {
    if ($(adRoot)
      .find("a").length > 0) {
      adLinkURL = $(adRoot).find("a").attr("href");
    }
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "jubna"
  ) {
    adLinkURL = $(adRoot).attr("href");
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "zergent"
  ) {
    adLinkURL = $(adRoot).find("a").attr("href");
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "speakol"
  ) {
    adLinkURL = $(adRoot).find("a").attr("href");
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "strossle"
  ) {
    adLinkURL = $(adRoot).find("a").attr("href");
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "yengegaya"
  ) {
    adLinkURL = $(adRoot).attr("data-orig-url");
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "twiago"
  ) {
    adLinkURL = $(adRoot).find("a").attr("href");
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "pubExchange"
  ) {
    adLinkURL = $(adRoot).find("a").attr("href");
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "yahooGemini") {
    adLinkURL = $(adRoot).attr('data-native-intel-destination_url')
    if (adLinkURL) {
      finalUrl(adRoot, adLinkURL);
    }
  } else if ($(adRoot).attr("data-native-intel-ad-network") === "colombia") {
    return "";
  } else if (
    $(adRoot).attr("data-native-intel-ad-network") === "adgebra" ||
    $(adRoot).attr("data-native-intel-ad-network") === "desipearl"
  ) {
    return "";
  } else {
    return "";
  }
  let dUrl = $(adRoot).attr("data-native-intel-destination_url");
  if (dUrl === adLinkURL) return "";
  return adLinkURL;
}
function finalUrl(adRoot, adLinkURL) {
  const destUrl = { "url": adLinkURL };
  const reqJson = {
    async: true,
    crossDomain: true,
    url: "https://postowner.poweradspy.com/get-post-owner",
    method: 'POST',
    rejectUnauthorized: false,
    requestCert: true,
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-cache'
    },
    processData: false,
    data: JSON.stringify(destUrl)
  };

  if (!($(adRoot).attr('data-desturl-promise') === 'pending')) {
    $.ajax(reqJson)
      .done((destUrlSrc) => {
        if (destUrlSrc.code === 200) {
          $(adRoot).attr('data-native-intel-destination_url', destUrlSrc.final_url);
          $(adRoot).attr('data-native-intel-post_owner', destUrlSrc.post_owner);
          $(adRoot).attr('data-desturl-promise', 'fulfilled');
        }
      })
      .fail(() => {
        $(adRoot).attr('data-desturl-promise', 'failed');
      });
    $(adRoot).attr('data-desturl-promise', 'pending');
  }
}

function extractOwner(ownerUrl) {
  if (ownerUrl.includes(".")) {
    var tempstr = ownerUrl.split(".");
    if (tempstr.length > 2) {
      tempstr[0] = tempstr[0]
        .replace("https://", "")
        .replace("http://", "")
        .replace("www", "");
      tempstr[1] = tempstr[1]
        .replace("https://", "")
        .replace("http://", "")
        .replace("www", "");
      if (tempstr[0].length > tempstr[1].length) {
        ownerUrl = tempstr[0];
      } else {
        ownerUrl = tempstr[1];
      }
    } else if (tempstr.length == 2) {
      if (tempstr[0].includes("http")) {
        ownerUrl = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
      } else {
        ownerUrl = tempstr[0];
      }
    }
  }
  return ownerUrl
}
function getNewsfeedDescription(adRoot) {
  let description=''
  if ($(adRoot).attr('data-native-intel-ad-network') === "yahooGemini") {
     description = $(adRoot).find('p[class="Fz(14px) C(--batcave) Lh(1.43) M(0) Bxz(bb) LineClamp(2,42px)"]').text()
    if(!description){
      description =  $(adRoot).find('p[class="Fz(14px) Lh(19px) Fz(13px)--sm1024 Lh(17px)--sm1024 LineClamp(2,38px) LineClamp(2,34px)--sm1024 Mt(5px) M(0)"]').text()
    }
  }
  return description;
}
function getVersion() {
  return version;
}
function getsource() {
  return "desktop";
}
function getPlatform() {
  return Platform;
}

async function GetPostOwner(redirectUrl) {
  const destUrldata = { url: redirectUrl };
  try {
    const response = await fetch(
      "https://postowner.poweradspy.com/get-post-owner",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(destUrldata),
      }
    );
    return response.text();
  } catch (error) {}
}