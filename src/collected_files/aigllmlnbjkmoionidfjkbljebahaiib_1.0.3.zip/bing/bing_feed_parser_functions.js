let toptextadcount = 0;
let bottomtextadcount = 0;
let topshoppingadcount = 0;
let bottomshoppingadcount = 0;
let sideshoppingadcount = 0;
let isProcessingGeoData = false;

function getOwner(adRoot) {
    let bingowner = null;
    try {
        if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
            $(adRoot).find(".pa_caption .b_attribution").length > 0) {
            bingowner = $(adRoot).find(".pa_caption .b_attribution")[0].innerText;
            if (bingowner.includes(".")) {
                var tempstr = bingowner.split(".");
                if (tempstr.length > 2) {
                    tempstr[0] = tempstr[0]
                        .replace("https://", "")
                        .replace("http://", "")
                        .replace("www", "");
                    tempstr[1] = tempstr[1]
                        .replace("https://", "")
                        .replace("http://", "")
                        .replace("www", "");
                    if (tempstr[0].length > tempstr[1].length) {
                        bingowner = tempstr[0];
                    } else {
                        bingowner = tempstr[1];
                    }
                } else if (tempstr.length == 2) {
                    if (tempstr[0].includes("http")) {
                        bingowner = tempstr[0]
                            .replace("https://", "")
                            .replace("http://", "")
                            .replace("www", "");
                    } else {
                        bingowner = tempstr[0];
                    }
                }
            }
        } else if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&   
        $(adRoot).find(".ra_ct_lnk .ra_seller").length > 0) {
        bingowner = $(adRoot).find(".ra_ct_lnk .ra_seller")[0].innerText;
        if (bingowner.includes(".")) {
            var tempstr = bingowner.split(".");
            if (tempstr.length > 2) {
                tempstr[0] = tempstr[0]
                    .replace("https://", "")
                    .replace("http://", "")
                    .replace("www", "");
                tempstr[1] = tempstr[1]
                    .replace("https://", "")
                    .replace("http://", "")
                    .replace("www", "");
                if (tempstr[0].length > tempstr[1].length) {
                    bingowner = tempstr[0];
                } else {
                    bingowner = tempstr[1];
                }
            } else if (tempstr.length == 2) {
                if (tempstr[0].includes("http")) {
                    bingowner = tempstr[0]
                        .replace("https://", "")
                        .replace("http://", "")
                        .replace("www", "");
                } else {
                    bingowner = tempstr[0];
                }
            }
        }
    }  else if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&   
        $(adRoot).find(".br-offInfo .br-offSlrTxt").length > 0) {
        bingowner = $(adRoot).find(".br-offInfo .br-offSlrTxt")[0].innerText;
        if (bingowner.includes(".")) {
            var tempstr = bingowner.split(".");
            if (tempstr.length > 2) {
                tempstr[0] = tempstr[0]
                    .replace("https://", "")
                    .replace("http://", "")
                    .replace("www", "");
                tempstr[1] = tempstr[1]
                    .replace("https://", "")
                    .replace("http://", "")
                    .replace("www", "");
                if (tempstr[0].length > tempstr[1].length) {
                    bingowner = tempstr[0];
                } else {
                    bingowner = tempstr[1];
                }
            } else if (tempstr.length == 2) {
                if (tempstr[0].includes("http")) {
                    bingowner = tempstr[0]
                        .replace("https://", "")
                        .replace("http://", "")
                        .replace("www", "");
                } else {
                    bingowner = tempstr[0];
                }
            }
        }
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "feed" &&
            $(adRoot).find(".b_adurl").length > 0) {
            bingowner = $(adRoot).find(".b_adurl")[0].innerText;
            if (!bingowner)
                bingowner = $(adRoot).find(".b_adurl cite").text();
            if (bingowner.includes(".")) {
                var tempstr = bingowner.split(".");
                if (tempstr.length > 2) {
                    tempstr[0] = tempstr[0]
                        .replace("https://", "")
                        .replace("http://", "")
                        .replace("www", "");
                    tempstr[1] = tempstr[1]
                        .replace("https://", "")
                        .replace("http://", "")
                        .replace("www", "");
                    if (tempstr[0].length > tempstr[1].length) {
                        bingowner = tempstr[0];
                    } else {
                        bingowner = tempstr[1];
                    }
                } else if (tempstr.length == 2) {
                    if (tempstr[0].includes("http")) {
                        bingowner = tempstr[0]
                            .replace("https://", "")
                            .replace("http://", "")
                            .replace("www", "");
                    } else {
                        bingowner = tempstr[0];
                    }
                }
            }
        } else if ($(adRoot).attr("data-bing-intel-ad-type") === "organic" &&
            $(adRoot).find(".b_attribution").length > 0) {
            bingowner = $(adRoot).find(".b_attribution").first().text();
            if (bingowner.includes(".")) {
                var tempstr = bingowner.split(".");
                if (tempstr.length > 2) {
                    tempstr[0] = tempstr[0]
                        .replace("https://", "")
                        .replace("http://", "")
                        .replace("www", "");
                    tempstr[1] = tempstr[1]
                        .replace("https://", "")
                        .replace("http://", "")
                        .replace("www", "");
                    if (tempstr[0].length > tempstr[1].length) {
                        bingowner = tempstr[0];
                    } else {
                        bingowner = tempstr[1];
                    }
                } else if (tempstr.length == 2) {
                    if (tempstr[0].includes("http")) {
                        bingowner = tempstr[0]
                            .replace("https://", "")
                            .replace("http://", "")
                            .replace("www", "");
                    } else {
                        bingowner = tempstr[0];
                    }
                }
            }
        }
    }
    catch {

    }
    return bingowner;
}

function gettargettext() {
    return null;
}

function getAdId(adRoot) {
    return null;
}

function gettargetpage() {
    let targetPage = '';
    if ($('li a.sb_pagS').length > 0) {
        targetPage = $('li a.sb_pagS').text();
    }
    return targetPage;
}

function getVersion() {
    return version;
}

function getFirstSeen() {
    const d = new Date();
    var myDate = d.getTime();
    myDate = myDate / 1000;
    return parseInt(myDate);
}

function getLastSeen() {
    const d = new Date();
    var myDate = d.getTime();
    myDate = myDate / 1000;
    return parseInt(myDate);
}

function getPostDate(adRoot) {
    let adPostTime;
    const d = new Date();
    var myDate = d.getTime();
    myDate = myDate / 1000;
    adPostTime = parseInt(myDate);
    return adPostTime;
}

function getAdGTempUrl(adRoot) {
    return '';
}

function getsource() {
    return "desktop";
}

function getUserIp() {
    return !!geoData.userIP ? geoData.userIP : null;
}

function getUserCity() {
    return !!geoData.userCity ? geoData.userCity : null;
}

function getUserState() {
    return !!geoData.userState ? geoData.userState : null;
}

function getUserCountry() {
    return !!geoData.userCountry ? geoData.userCountry : null;
}

function getnetwork() {
    return "BING";
}

function getpostownerimage() {
    return "";
}

function getPlatform() {
    return Platform;
}

function getNewsfeedDescription(adRoot) {
    let newsfeedDescription = null;
    if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
        $(adRoot).find(".pa_caption .b_attribution").length > 0) {
        newsfeedDescription = $(adRoot).find(".pa_caption .b_attribution")[0].innerText;                  
} else  if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
$(adRoot).find(".br-offInfo .br-offSlrTxt").length > 0) {
newsfeedDescription = $(adRoot).find(".br-offInfo .br-offSlrTxt")[0].innerText;              
}  else  if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
$(adRoot).find(".ra_ct_lnk .ra_seller").length > 0) {
newsfeedDescription = $(adRoot).find(".ra_ct_lnk .ra_seller")[0].innerText;               
}
else if ($(adRoot).attr("data-bing-intel-ad-type") === "feed" &&  $(adRoot).find("div.b_ad_description").length > 0) {
        $(adRoot).each(function () {
            newsfeedDescription = $(adRoot).find('div.b_ad_description').first().text().replace('Ad', '');
            newsfeedDescription += $(adRoot).find('p.b_secondaryText').first().text();
            newsfeedDescription += $(adRoot).find('div.b_secondaryText').first().text();
        });
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "organic" &&
        $(adRoot).find("p").length > 0) {
        newsfeedDescription = $(adRoot).find('p').first().text();
    }
    return newsfeedDescription||"";
}

function getBetween(pageSource, firstData, secondData) {
    try {
        const resSplit = pageSource.split(firstData);
        const indexSec = resSplit[1].indexOf(secondData);
        return resSplit[1].substring(0, indexSec);
    } catch (e) {
        return "";
    }
}

function getAdImage(adRoot) {
    let adImage = null;
    if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
        ($(adRoot).find("img").length > 0 || $(adRoot).find(".ra_img img").length > 0 || $(adRoot).find(".br-offImg img").length > 0 )) {
        adImage = $(adRoot)?.find(".br-offImg img")?.[0]?.currentSrc ? $(adRoot)?.find(".br-offImg img")?.[0]?.currentSrc : $(adRoot)?.find("img")?.[0]?.currentSrc || $(adRoot)?.find(".ra_img img")?.[0]?.currentSrc
        if (adImage) {
            adImage = adImage.replace('data:image/jpeg;base64,', '');
        } else {
            return null;
        }
    } else {
        return '';
    }
    if (adImage.includes("xmlns='http:") || adImage.includes("https://www.bing.com")) return null;
    return adImage;

}



function getAdText(adRoot) {
    let text = null;
    if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
        $(adRoot).find(".pa_caption .pa_price").length > 0) {
        text = $(adRoot).find(".pa_caption .pa_price strong")[0].innerText;
        let text1=$(adRoot)?.find(".pa_caption .pa_price .original_price ")?.[0]?.innerText;
        if(text && text1){
            text=`${text} ${text1}`
        }
        else{
            text=text;
        }
        
        text = text.replace(/<[^>]*>/g, "");    
    } else  if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&    
         $(adRoot).find(".br-offPrice.b_primtxt").length > 0) {
         text = $(adRoot).find(".br-offPrice.b_primtxt")[0].innerText;
         text = text.replace(/<[^>]*>/g, "");
    } else  if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&    
    $(adRoot).find(".ra_ct_lnk .ra_price").length > 0) {
    text = $(adRoot).find(".ra_ct_lnk .ra_price")[0].innerText;
    text = text.replace(/<[^>]*>/g, "");
} else if ($(adRoot).attr("data-bing-intel-ad-type") === "feed" &&
        $(adRoot).find(".b_adurl").length > 0) {
        text = $(adRoot).find(".b_adurl")[0].innerText;
        text = text.replace(/<[^>]*>/g, "");
        if (!text)
            text = $(adRoot).find(".b_adurl cite").text();
        text = text.replace(/<[^>]*>/g, "");
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "organic" &&
        $(adRoot).find(".b_attribution").length > 0) {
        text = $(adRoot).find(".b_attribution").first().text();
        text = text.replace(/<[^>]*>/g, "");
    }
    return text;
}

function hashCode(str) {
    return str
        .split("")
        .reduce(
            (prevHash, currVal) =>
                ((prevHash << 5) - prevHash + currVal.charCodeAt(0)) | 0,
            0
        );
}

function getDestinationUrl(adRoot) {
    let adLinkURL = null;
    if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
        $(adRoot).find("a").length > 0) {
        adLinkURL = $(adRoot).find("a").attr("href");
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "feed" &&
        $(adRoot).find("h2 a").length > 0) {
        adLinkURL = $(adRoot).find("h2 a").attr("href");
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "organic" &&
        $(adRoot).find("h2 a").length > 0) {
        adLinkURL = $(adRoot).find("h2 a").attr("href");
    }
    return adLinkURL||"";
}
function base64ToHex(str) {
    const raw = atob(str);
    let result = '';
    for (let i = 0; i < raw.length; i++) {
        const hex = raw.charCodeAt(i).toString(16);
        result += (hex.length === 2 ? hex : '0' + hex);
    }
    return result;
}

function getTitle(adRoot) {
    let title = null;
    let adPostId;
    let trgettext = null;
    if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
        $(adRoot).find(".pa_title").length > 0) {
        title = $(adRoot).find(".pa_title")[0].innerText;
        adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
        $(adRoot).attr("data-bing-intel-ad_id", adPostId);
        topshoppingadcount = topshoppingadcount + 1;
        $(adRoot).attr("data-bing-intel-ad_position", "FEED");
        $(adRoot).attr("data-bing-intel-ad_sub_position", "TOP");
        $(adRoot).attr("data-bing-intel-ad_number_position", topshoppingadcount);
    } else   if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
    $(adRoot).find(".ra_ct_lnk .ra_title").length > 0) {                            
    title = $(adRoot).find(".ra_ct_lnk .ra_title")[0].innerText;
    adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
    $(adRoot).attr("data-bing-intel-ad_id", adPostId);
    topshoppingadcount = topshoppingadcount + 1;
    $(adRoot).attr("data-bing-intel-ad_position", "FEED");
    $(adRoot).attr("data-bing-intel-ad_sub_position", "TOP");
    $(adRoot).attr("data-bing-intel-ad_number_position", topshoppingadcount);
    } else   if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping" &&
    $(adRoot).find(".br-offTtl.b_primtxt").length > 0) {                            
    title = $(adRoot).find(".br-offTtl.b_primtxt")[0].innerText;
    adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
    $(adRoot).attr("data-bing-intel-ad_id", adPostId);
    topshoppingadcount = topshoppingadcount + 1;
    $(adRoot).attr("data-bing-intel-ad_position", "FEED");
    $(adRoot).attr("data-bing-intel-ad_sub_position", "TOP");
    $(adRoot).attr("data-bing-intel-ad_number_position", topshoppingadcount);
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "feed" &&
        $(adRoot).find("h2").length > 0) {
        title = $(adRoot).find("h2").first().text();
        adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
        $(adRoot).attr("data-bing-intel-ad_id", adPostId);
        $(adRoot).attr("data-bing-intel-ad_position", "FEED");
        if ($(adRoot)[0].parentNode.parentNode.parentNode.className == "b_ad b_adBottom") {
            bottomtextadcount = bottomtextadcount + 1;
            $(adRoot).attr("data-bing-intel-ad_sub_position", "BOTTOM");
            $(adRoot).attr("data-bing-intel-ad_number_position", bottomtextadcount);
        } else {
            toptextadcount = toptextadcount + 1;
            $(adRoot).attr("data-bing-intel-ad_sub_position", "TOP");
            $(adRoot).attr("data-bing-intel-ad_number_position", toptextadcount);
        }
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "organic" &&
        $(adRoot).find("h2").length > 0) {
        title = $(adRoot).find("h2").first().text();
        adPostId = base64ToHex(b64_hmac_sha1(paskey, title));
        $(adRoot).attr("data-bing-intel-ad_id", adPostId);
        topshoppingadcount = topshoppingadcount + 1;
        $(adRoot).attr("data-bing-intel-ad_position", "FEED");
        $(adRoot).attr("data-bing-intel-ad_sub_position", "TOP");
        $(adRoot).attr("data-bing-intel-ad_number_position", topshoppingadcount);
    }
    var search = $("input[name=q]");
    if (search.length > 0) {
        var searchText = search[0].defaultValue;
        if (trgettext != "") {
            $(adRoot).attr("data-bing-intel-target_keyword", searchText);
        }
    }
    return title||"";
}
function getPosition(adRoot) {
    return null||"";
}
function getsubPosition(adRoot) {
    return null||"";
}
function getnumberPosition(adRoot) {
    return null||"";
}
function getType(adRoot) {
    if ($(adRoot).attr("data-bing-intel-ad-type") === "shopping") {
        return "IMAGE";
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "feed") {
        return "TEXT";
    } else if ($(adRoot).attr("data-bing-intel-ad-type") === "organic") {
        return "ORGANIC SEARCH";
    }
}

function buildUpGeoData() {
    if (isProcessingGeoData) {
        return;
    }
    isProcessingGeoData = true;

    if (!geoData.userIP || !geoData.userCity || !geoData.userState || !geoData.userCountry) {
        if (!geoData.userIP) {
            const ourIP = "https://geolocation.poweradspy.com/";
            $.ajax({
                url: ourIP,
                type: "GET",
                async: true,
                success: function (IpResponse) {
                    const ourIpResponse = JSON.parse(IpResponse);
                    geoData.userIP = ourIpResponse.ip;
                    geoData.userCity = ourIpResponse.cityName;
                    geoData.userState = ourIpResponse.regionName;
                    geoData.userCountry = ourIpResponse.countryName;
                    geoData.lastUpdated = Date.now();
                    chrome.storage.local.set({ "geoData": geoData });
                    isProcessingGeoData = false;
                }
            });
        }
    }
}
function checkForNew() {
    try {
        let imageAds = document.querySelector('div.pa_ml .b_slidesContainer .slide');
        let textAds = document.querySelector('.b_ad .sb_add');
        let shoppingAds=document.querySelector('div.br-productCarousel .br-pcContainer .b_slidesContainer .slide'); 
        let imageSectionAds = document.querySelector('div.ra_car_container .b_slidesContainer .slide');
         if (imageAds !== null || textAds !== null || shoppingAds !== null || imageSectionAds !== null) {
            //Image ads
            $("div.pa_ml .b_slidesContainer .slide:not([data-bing-intel-triaged])")
                .attr("data-bing-intel-triaged", "no")
                .attr("data-bing-ad", "yes")
                .attr("data-bing-intel-ad-type", "shopping")
                .addClass("bing-intel-ad");

            //Text ads
            $(".b_ad .sb_add:not([data-bing-intel-triaged])")
                .attr("data-bing-intel-triaged", "no")
                .attr("data-bing-ad", "yes")
                .attr("data-bing-intel-ad-type", "feed")
                .addClass("bing-intel-ad");

            //Organic ads
            $("li.b_algo:not([data-bing-intel-triaged])")
                .attr("data-bing-intel-triaged", "sponsored")
                .attr("data-bing-ad", "yes")
                .attr("data-bing-intel-ad-type", "organic")
                .addClass("bing-intel-ad");

           //shopping ADs
           $("div.br-productCarousel .br-pcContainer .b_slidesContainer .slide:not([data-bing-intel-triaged])")
           .attr("data-bing-intel-triaged", "no")
           .attr("data-bing-ad", "yes")
           .attr("data-bing-intel-ad-type", "shopping")
           .addClass("bing-intel-ad");

              //ImageSection ads
              $("div.ra_car_container .b_slidesContainer .slide:not([data-bing-intel-triaged])")
              .attr("data-bing-intel-triaged", "no")
              .attr("data-bing-ad", "yes")
              .attr("data-bing-intel-ad-type", "shopping")
              .addClass("bing-intel-ad");
        }
    }
    catch {

    }
}
function triageItems() {
    if (sponsoredClass) {
        $("div.bing-intel-ad[data-bing-intel-triaged='no'], div.bing-intel-ad[data-bing-intel-triaged='not-sponsored']"
        ).each(function () {
            if ($(this).find("span.b_adSlug").length > 0 || $(this).find("span.br_slugTxt").length > 0) {
                let sponsoredLinkCount = $(this).find("span.b_adSlug").first().text(); //span.br_slugTxt
            let sponsoredLinkCount1 = $(this).find("span.b_adSlug").first().text();
                 
                if (sponsoredLinkCount.includes(sponsoredClass) || sponsoredLinkCount1.includes(sponsoredClass)) {
                    $(this).attr("data-bing-intel-triaged", "sponsored");
                }
                else {
                    $(this).attr("data-bing-intel-triaged", "not-sponsored");
                }
            }
        });
    }
    if (sponsoredClassShopping) {
        $("div.bing-intel-ad[data-bing-intel-triaged='no'], div.bing-intel-ad[data-bing-intel-triaged='not-sponsored']")
            .each(function () {
                $(this).attr("data-bing-intel-ad-type", "shopping");
                $(this).attr("data-bing-intel-triaged", "sponsored");
            });
    }
}
function extractDataFromItems() {
    $("div.bing-intel-ad[data-bing-intel-triaged='sponsored']:not([data-bing-intel-parsed])").each(function () {
        let allFound = true;
        let debugPanel = "";
        let attempts = $(this).attr("data-bing-intel-attempts");
        if (!attempts) {
            attempts = "1";
        } else {
            attempts = parseInt(attempts) + 1;
            if (attempts > 8) {
                $(this).attr("data-bing-intel-parsed", "incomplete");
            }
        }
        $(this).attr("data-bing-intel-attempts", attempts);
        debugPanel += `<p>attempts: ${attempts}</p>`;
        for (const [key, value] of Object.entries(requiredData)) {
            let attrValue = $(this).attr(value.attribute);
            if (attrValue === null || attrValue === undefined) {
                attrValue = value.method.apply(null, $(this));
            }
            if (attrValue !== null && attrValue !== undefined) {
                $(this).attr(value.attribute, `${attrValue}`);
                debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
            } else {
                debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
                allFound = false;
            }
        }
        if (allFound) {
            $(this).attr("data-bing-intel-parsed", "complete"); // this means ad can be written
        }
    });


    $("li.bing-intel-ad[data-bing-intel-triaged='sponsored']:not([data-bing-intel-parsed])").each(function () {
        let allFound = true;
        let debugPanel = "";
        let attempts = $(this).attr("data-bing-intel-attempts");
        if (!attempts) {
            attempts = "1";
        } else {
            attempts = parseInt(attempts) + 1;
            if (attempts > 8) {
                $(this).attr("data-bing-intel-parsed", "incomplete");
            }
        }
        $(this).attr("data-bing-intel-attempts", attempts);
        debugPanel += `<p>attempts: ${attempts}</p>`;
        for (const [key, value] of Object.entries(requiredData)) {
            let attrValue = $(this).attr(value.attribute);
            if (attrValue === null || attrValue === undefined) {
                attrValue = value.method.apply(null, $(this));
            }
            if (attrValue !== null && attrValue !== undefined) {
                $(this).attr(value.attribute, `${attrValue}`);
                debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
            } else {
                debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
                allFound = false;
            }
        }
        if (allFound) {
            $(this).attr("data-bing-intel-parsed", "complete"); // this means ad can be written
        }
    });
}

function saveSponsoredAds() {
    $("div.bing-intel-ad[data-bing-intel-parsed='complete']:not([data-bing-intel-saved])").each(function () {
        const adRoot = this;
        let thisAdData = Object.assign({}, adData);
        for (const [key, value] of Object.entries(requiredData)) {
            thisAdData[key] = $(adRoot).attr(value.attribute) || "";
            if (thisAdData[key] === null) {
            }
        }
        const postData = JSON.stringify(thisAdData);
        const settings = {
            async: true,
            crossDomain: true,
            url: powerAdSpyBingApi + "api/bingAdsData",
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "cache-control": "no-cache",
            },
            processData: false,
            data: postData
        };
        $(adRoot).attr("data-bing-intel-saved", "pending");
        if ((thisAdData.type == "IMAGE") || (thisAdData.type == "ORGANIC SEARCH") || (thisAdData.type == "TEXT")) {
            $.ajax(settings)
                .done(function (response) {
                    if (response.code == "200") {
                        $(adRoot).attr("data-bing-intel-saved", "saved");
                    } else {
                        $(adRoot).attr("data-bing-intel-triaged", "complete");
                        $(adRoot).attr("data-bing-intel-saved", "success");
                    }
                })
                .fail(function () {
                    $(adRoot).attr("data-bing-intel-triaged", "complete");
                    $(adRoot).attr("data-bing-intel-saved", "failed");
                });
        } else {
            $(adRoot).attr("data-bing-intel-saved", "saved");
        }
    });

    $("li.bing-intel-ad[data-bing-intel-parsed='complete']:not([data-bing-intel-saved])").each(function () {
        const adRoot = this;
        let thisAdData = Object.assign({}, adData);
        for (const [key, value] of Object.entries(requiredData)) {
            thisAdData[key] = $(adRoot).attr(value.attribute) || "";
            if (thisAdData[key] === null) {
            }
        }
        const postData = JSON.stringify(thisAdData);
        const settings = {
            async: true,
            crossDomain: true,
            url: powerAdSpyBingApi + "api/bingAdsData",
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "cache-control": "no-cache"
            },
            processData: false,
            data: postData
        };
        $(adRoot).attr("data-bing-intel-saved", "pending");
        if ((thisAdData.type == "IMAGE") || (thisAdData.type == "ORGANIC SEARCH") || (thisAdData.type == "TEXT")) {
            $.ajax(settings)
                .done(function (response) {
                    if (response.code == "200") {
                        $(adRoot).attr("data-bing-intel-saved", "saved");
                    } else {
                        $(adRoot).attr("data-bing-intel-triaged", "complete");
                        $(adRoot).attr("data-bing-intel-saved", "success");
                    }
                })
                .fail(function () {
                    $(adRoot).attr("data-bing-intel-triaged", "complete");
                    $(adRoot).attr("data-bing-intel-saved", "failed");
                });
        } else {
            $(adRoot).attr("data-bing-intel-saved", "saved");
        }
    });
}