let redirectStore = {
  watchingForUrl: null,
  watchingTab: null,
  redirects: [],
  lastUpdated: null,
  adId: null,
  timer: null,
  addRedirect: function (url) {
    try {
      clearTimeout(this.timer);
      this.redirects.push(url);
      this.timer = setTimeout(redirectStore.pushToApi, 5000);
      this.lastUpdated = Date.now();
    } catch (e) {}
  },
  pushToApi: function () {
    let redirects = [];
    if (redirectStore.redirects.length > 1) {
      redirects = redirectStore.redirects.slice(
        0,
        redirectStore.redirects.length - 1
      );
    }

    const postData = {
      ad_id: `${redirectStore.adId}`,
      redirect_urls: redirects.join("|"),
      destination_url: redirectStore.redirects.pop(),
    };
    var temp_ad_id = `${redirectStore.adId}`;
    if (temp_ad_id != "null") {
      const settings = {
        async: true,
        crossDomain: true,
        url: powerAdSpyApi + "UpdateAllUrls",
        method: "POST",
        headers: {
          "content-type": "application/json",
          "cache-control": "no-cache",
        },
        processData: false,
        data: JSON.stringify(postData),
      };
      $.ajax(settings).done(function (response) {});
      redirectStore.watchingForUrl = null;
      redirectStore.watchingTab = null;
      redirectStore.redirects = [];
      redirectStore.lastUpdated = null;
      redirectStore.adId = null;
    }
  },
};

function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (
    request.mainLoopTime !== undefined ||
    request.extractTime !== undefined ||
    request.triageTime !== undefined ||
    request.hideTime !== undefined
  ) {
  } else {
  }

  if (request.action === "user clicked") {
    try {
      redirectStore.watchingForUrl = request.url;
      redirectStore.watchingTab = null;
      redirectStore.lastUpdated = Date.now();
      redirectStore.adId = request.adId;
      redirectStore.redirects = [];
    } catch (e) {}
  } else if (request.contentScriptQuery == "youtubeRequest") {
    $.ajax(request.settings)
      .done(function (response) {
        sendResponse(response);
      })
      .fail(function () {
        sendResponse({ error: true });
      });
    return true;
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  var { status } = changeInfo;
  var { url } = tab;
  if (status === "complete") {
    if (url.includes("www.youtube.com")) {
      chrome.tabs.sendMessage(tabId, { message: "inject-youtube" });
    }
    if (url.includes("quora.com")) {
      chrome.tabs.sendMessage(tabId, { message: "inject-quora" });
    }
    if (url.includes("reddit.com")) {
      chrome.tabs.sendMessage(tabId, { message: "inject-reddit" });
    }
  }
});

const requestRedirect = function (details) {
  if (redirectStore.watchingTab === null && details.url) {
    redirectStore.watchingTab = details.tabId;
  }
  redirectStore.redirects.push(details.url);
  redirectStore.lastUpdated = Date.now();
};

const requestCompleted = function (details) {};

const navigationCommitted = function (details) {};

chrome.webRequest.onBeforeRedirect.addListener(
  requestRedirect,
  {
    urls: ["<all_urls>"],
    types: ["main_frame"],
  },
  ["responseHeaders"]
);
chrome.webRequest.onCompleted.addListener(
  requestCompleted,
  {
    urls: ["<all_urls>"],
    types: ["main_frame"],
  },
  ["responseHeaders"]
);
chrome.webNavigation.onCommitted.addListener(navigationCommitted);

//LinkedIn advertiser Ads
function sendMessageToActiveTab(url) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    chrome.tabs.sendMessage(tabs[0].id, { url: url });
  });
}

chrome.webNavigation.onHistoryStateUpdated.addListener(function (details) {
  sendMessageToActiveTab(details.url);
});

chrome.webNavigation.onCompleted.addListener(function (details) {
  sendMessageToActiveTab(details.url);
});

// For user consent form
let createdWindowId = null;
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install" || details.reason === "update") {
    setTimeout(() => {
      chrome.windows.create(
        {
          type: "panel",
          url: "./Terms_Conditions/consent.html",
          width: 500,
          height: 150,
        },
        function (window) {
          createdWindowId = window.id;
        }
      );
    }, 1000);
  }
});

chrome.storage.onChanged.addListener(function (changes, areaName) {
  if (changes.userConsent?.newValue === true) {
    chrome.management.uninstallSelf(() => {
      if (chrome.runtime.lastError) {
        console.error("Failed to uninstall:", chrome.runtime.lastError);
      } else {
        console.log("Extension uninstalled successfully.");
      }
    });
    return true;
  }
});


// For native networks
chrome.webRequest.onCompleted.addListener(
  function (details) {
    if (
      details.type === "sub_frame" &&
      details.url.startsWith("https://my.paxventure.com")
    ) {
      fetchIframeContent(details.url, "paxventure", "ads");
    }
    if (
      details.type === "sub_frame" &&
      details.url.startsWith("https://www.dianomi.com")
    ) {
      fetchIframeContent(details.url, "dianomi", "div._dianomi_wrapper");
    }
    if (
      details.type === "sub_frame" &&
      details.url.startsWith("https://web.adblade.com")
    ) {
      fetchIframeContent(details.url, "adblade", "ul");
    }
  },
  { urls: ["<all_urls>"], types: ["sub_frame"] }
);

function fetchIframeContent(iframeUrl, type, wrapper) {
  fetch(iframeUrl)
    .then((response) => response.text())
    .then((iframeContent) => {
      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, { iframeContent, type, wrapper });
      });
    })
    .catch((error) => {});
}