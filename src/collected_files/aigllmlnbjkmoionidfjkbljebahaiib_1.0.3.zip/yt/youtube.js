let vdefaultGeoData = {
  vserviceId: null,
  vlastUpdated: null,
  vuserCity: null,
  vuserState: null,
  vuserCountry: null,
  vuserIP: null,
};

if (typeof origOpen == "undefined") {
  var origOpen = XMLHttpRequest.prototype.open;
}

XMLHttpRequest.prototype.open = function () {
  this.addEventListener("load", function () {
    try {
      let responseText = this.responseText;
      if (responseText && responseText.hasOwnProperty("adPlacements")) {
        // get_youtube_ads(responseText.adPlacements);
      }
    } catch (e) {}
  });
  origOpen.apply(this, arguments);
};

function onFetch(callback) {
  let logFetch = window.fetch;
  window.fetch = function (input, init) {
    return new Promise((resolve, reject) => {
      logFetch(input, init).then(function (response) {
        callback(response.clone());
        resolve(response);
      }, reject);
    });
  };
}

onFetch((response) => {
  response.json().then((res) => {
    document.dispatchEvent(
      new CustomEvent('YT_XHR', {
        detail: {
          res
        }
      })
    );
    if(res) identifySponsored(res)
  });
});

function identifySponsored(res) {
  try {
    if (res.hasOwnProperty("adPlacements")) {
      // get_youtube_ads(res.adPlacements);
    } else if (
      res.hasOwnProperty("contents") &
      JSON.stringify(res.contents).indexOf("displayAdRenderer")
    ) {
      res?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents?.forEach(
        (e1) => {
          e1?.itemSectionRenderer?.contents?.forEach((e2) => {
            // let video_ads = e2?.searchPyvRenderer?.ads;
            let display_ads = e2?.adSlotRenderer;
            // if (video_ads) get_youtube_ads(video_ads);
            if (display_ads) displayImageSearchAds(display_ads);
          });
        }
      );
    }
  } catch (e) {}
}
async function get_youtube_ads(youtube_ads) {
  let youtube_ad = youtube_ads.detail
    try {
      let ytAdResult = {};
      ytAdResult["network"] = "YouTube";
      ytAdResult["source"] = "desktop";
      ytAdResult["type"] = "VIDEO";
      ytAdResult["ad_url"] =
        "https://www.youtube.com/watch?v=" + youtube_ad.video_id;
      ytAdResult["category"] = "";
      ytAdResult["post_owner_image"] = "";
      ytAdResult["ad_title"] = youtube_ad.title ? youtube_ad.title : "";
      ytAdResult["ad_text"] = youtube_ad.body ? youtube_ad.body : "";
      ytAdResult["call_to_action"] = youtube_ad.cta_type
        ? youtube_ad.cta_type
        : "";
      ytAdResult["ad_image"] =
        "https://www.youtube.com/watch?v=" + youtube_ad.video_id;
      ytAdResult["newsfeed_description"] = "";
      ytAdResult["platform"] = "3";
      ytAdResult["ad_id"] = youtube_ad.video_id;
      ytAdResult["dislike"] = 0;
      ytAdResult["thumbnail"] = "";
      ytAdResult["tags"] = "";
      ytAdResult["display_link"] = "";
      ytAdResult["ad_position"] = "FEED";
      ytAdResult["target_keyword"] = "";
      ytAdResult["channelId"] = "";
      ytAdResult["source"] = "desktop";
      ytAdResult["target_keyword_id"] = 0;
      ytAdResult["adcrawled"] = 1;
      ytAdResult["othermedia"] = "";
      ytAdResult["lower_age"] = 0;
      ytAdResult["upper_age"] = 0;
      ytAdResult["target_video"] = "";
      ytAdResult["target_video_id"] = 0;
      ytAdResult["verified"] = 0;
      ytAdResult["ip_address"] = vdefaultGeoData.vuserIP
        ? vdefaultGeoData.vuserIP
        : "";
      ytAdResult["city"] = vdefaultGeoData.vuserCity
        ? vdefaultGeoData.vuserCity
        : "";
      ytAdResult["state"] = vdefaultGeoData.vuserState
        ? vdefaultGeoData.vuserState
        : "";
      ytAdResult["country"] = vdefaultGeoData.vuserCountry
        ? vdefaultGeoData.vuserCountry
        : "";
      ytAdResult["first_seen"] = getCurrentTime().toString();
      ytAdResult["last_seen"] = getCurrentTime().toString();
      ytAdResult["version"] = "3.1.9";
      let postOwnerResultSource = await GetPostOwner(youtube_ad.raw_cta_url);
      let postOwnerResult = JSON.parse(postOwnerResultSource);
      ytAdResult["destination_url"] = postOwnerResult.final_url;
      ytAdResult["post_owner"] = postOwnerResult.post_owner;
      var adSource = await GetAdUrlSource(ytAdResult.ad_url);
      if (!adSource) return;
      let ms = getBetween(adSource,'AUDIO_QUALITY_LOW","approxDurationMs":"','",')
      ytAdResult["ad_duration"] = formatMilliseconds(ms);
      ytAdResult["likes"] = parseInt(
        getBetween(
          adSource,
          'LIKE"},"defaultText":{"accessibility":{"accessibilityData":{"label":"',
          "likes"
        ).replaceAll(",", "")
      );
      if (!ytAdResult["likes"]) ytAdResult["likes"] = 0;
      ytAdResult["comment"] = parseInt(
        getBetween(adSource, '"commentCount":{"simpleText":"', '"}').replaceAll(
          ",",
          ""
        )
      );
      if (!ytAdResult["comment"]) ytAdResult["comment"] = 0;
      ytAdResult["channelurl"] = getBetween(
        adSource,
        '"ownerChannelName":"',
        '",'
      );
      var dateSource = getBetween(adSource, '"uploadDate":"', '"');
      ytAdResult["post_date"] = (new Date(dateSource).getTime() / 1000).toFixed(
        0
      );
      ytAdResult["views"] = parseInt(
        getBetween(adSource, 'viewCount":{"simpleText":"', "views").replaceAll(
          ",",
          ""
        )
      );
      document.dispatchEvent(
        new CustomEvent('ADS', {
          detail: {
            ytAdResult
          }
        })
      );
      // sendPost(ytAdResult);
    } catch (e) { }
  }

async function displayImageSearchAds(imageAd) {
  let ytImageAdResult = {
    network: "YouTube",
    type: "DISPLAY",
    category: "",
    likes: "0",
    dislike: "0",
    views: "",
    comment: "0",
    platform: "3",
    lower_age: "18",
    upper_age: "65",
    tags: "",
    thumbnail: "",
    othermedia: "",
    verified: "0",
    source: "Desktop",
    post_owner_image: "",
    ad_position: "FEED",
  };
  try {
    const post =
      imageAd.fulfillmentContent.fulfilledLayout.inFeedAdLayoutRenderer
        .renderingContent.promotedSparklesWebRenderer;
    ytImageAdResult["ad_title"] = post.title.simpleText;
    ytImageAdResult["newsfeed_description"] = post.description.simpleText;
    ytImageAdResult["ad_text"] = post.websiteText.simpleText;
    ytImageAdResult["call_to_action"] =
      post.mediaHoverOverlay.buttonRenderer.text.simpleText;
    ytImageAdResult["destination_url"] =
      post.thumbnailNavigationEndpoint.urlEndpoint.url;
    ytImageAdResult["ad_image"] = post.thumbnail.thumbnails[0].url;
    ytImageAdResult["ad_url"] = ytImageAdResult.ad_image;
    let imageOwnerSource = await GetPostOwner(ytImageAdResult.destination_url);
    let imageOwner = JSON.parse(imageOwnerSource);
    ytImageAdResult["destination_url"] = imageOwner.final_url;
    ytImageAdResult["post_owner"] = imageOwner.post_owner;
    ytImageAdResult["ad_id"] = (hashCode(ytImageAdResult.ad_image)).toString();
    ytImageAdResult["ip_address"] = vdefaultGeoData.vuserIP
      ? vdefaultGeoData.vuserIP
      : "";
    ytImageAdResult["city"] = vdefaultGeoData.vuserCity
      ? vdefaultGeoData.vuserCity
      : "";
    ytImageAdResult["state"] = vdefaultGeoData.vuserState
      ? vdefaultGeoData.vuserState
      : "";
    ytImageAdResult["country"] = vdefaultGeoData.vuserCountry
      ? vdefaultGeoData.vuserCountry
      : "";
    ytImageAdResult["first_seen"] = getCurrentTime().toString();
    ytImageAdResult["last_seen"] = getCurrentTime().toString();
    ytImageAdResult["post_date"] = getCurrentTime().toString();
    ytImageAdResult["version"] = "3.1.9";
    document.dispatchEvent(
      new CustomEvent('ADS', {
        detail: {
          ytImageAdResult
        }
      })
    );
    // sendPost(ytImageAdResult);
  } catch {}
}


function getCurrentTime() {
  const d = new Date();
  var myDate = d.getTime();
  myDate = myDate / 1000;
  return parseInt(myDate);
}

async function GetAdUrlSource(url) {
  const response = await fetch(url, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      "cache-control": "no-cache",
      Accept: "text/html",
    },
  });
  const pageSource = response.text();
  return pageSource;
}

async function GetPostOwner(redirectUrl) {
  const destUrldata = { url: redirectUrl };
  try {
    const response = await fetch(
      "https://postowner.poweradspy.com/get-post-owner",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(destUrldata),
      }
    );
    return response.text();
  } catch (error) {}
}


function GetOwner(adText) {
  if (adText.includes("/")) adText = adText.split("/")[0];
  if (adText.includes(".")) {
    var tempstr = adText.split(".");
    if (tempstr.length > 2) {
      tempstr[0] = tempstr[0]
        .replace("https://", "")
        .replace("http://", "")
        .replace("www", "");
      tempstr[1] = tempstr[1]
        .replace("https://", "")
        .replace("http://", "")
        .replace("www", "");
      if (tempstr[0].length > tempstr[1].length) {
        adText = tempstr[0];
      } else {
        adText = tempstr[1];
      }
    } else if (tempstr.length == 2) {
      if (tempstr[0].includes("http")) {
        adText = tempstr[0]
          .replace("https://", "")
          .replace("http://", "")
          .replace("www", "");
      } else {
        adText = tempstr[0];
      }
    }
  }
  return adText;
}

function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}

function hashCode(str) {
  return str.split('').reduce((prevHash, currVal) =>
      (((prevHash << 5) - prevHash) + currVal.charCodeAt(0)) | 0, 0);
}

setTimeout(GetIpDetails, 1000);

let visProcessingGeoData = false;

function GetIpDetails() {
  if (visProcessingGeoData) {
    return;
  }
  visProcessingGeoData = true;

  if (
    !vdefaultGeoData.vuserIP ||
    !vdefaultGeoData.vuserCity ||
    !vdefaultGeoData.vuserState ||
    !vdefaultGeoData.vuserCountry
  ) {
    if (!vdefaultGeoData.vuserIP) {
      const ourIP = "https://geolocation.poweradspy.com/";
      var xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          const ourIpResponse = JSON.parse(xhttp.responseText);
          vdefaultGeoData.vuserIP = ourIpResponse.ip;
          vdefaultGeoData.vuserCity = ourIpResponse.cityName;
          vdefaultGeoData.vuserState = ourIpResponse.regionName;
          vdefaultGeoData.vuserCountry = ourIpResponse.countryName;
          vdefaultGeoData.vlastUpdated = Date.now();
        }
      };
      xhttp.open("GET", ourIP, true);
      xhttp.send();
    }
  }
}

setTimeout(function () {
  try {
    let tempElement = document.createElement("div");
    tempElement.innerHTML = document.documentElement.outerHTML;
    let scriptTags = Array.from(tempElement.getElementsByTagName("script"));
    scriptTags.forEach((script) => {
      if (script.innerHTML.includes("Sponsored")) {
        let res = JSON.parse(script.textContent.slice(20, -1));
        if (res) identifySponsored(res);
      }
    });
  } catch (error) {}
}, 5000);

document.addEventListener("YT_Playing_Ad", get_youtube_ads);

function formatMilliseconds(ms) {
  console.log(ms)
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}