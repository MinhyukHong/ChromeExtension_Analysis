/*global birthday */

function getVersion() {
    return version;
}
const sendDefaultAttempts = 7; // change this to < 9 to give up and send "" for not found items

function getBetween(pageSource, firstData, secondData) {
    try {
        const resSplit = pageSource.split(firstData);
        const indexSec = resSplit[1].indexOf(secondData);
        return resSplit[1].substring(0, indexSec);
    } catch (e) {
        return "";
    }
}
function getUserIp() {
    //debugger;
    return !!geoData.userIP ? geoData.userIP : null;
}
function getUserCity() {
    //debugger;
    return !!geoData.userCity ? geoData.userCity : null;
}
function getSource() {
    return 'Desktop';
}

function getVerified() {
    return 0;
}

function getNetwork() {
    return 'YouTube';
}

function getUserState() {
    //debugger;
    return !!geoData.userState ? geoData.userState : null;
}

function getUserCountry() {
    //debugger;
    return !!geoData.userCountry ? geoData.userCountry : null;
}
function getplatform() {
    //debugger;
    //server=1,user=3
    return Platform;
}

function getCategory(adRoot) {
    if ($(adRoot).attr('data-fb-intel-ad-type') === 'display-feed') {
        try {
            var display_newsfeed = $(adRoot).find('#body-text').text();
            $(adRoot).attr('data-fb-intel-newsfeed_description', display_newsfeed);
            var display_callToAction = $(adRoot).find('button.yt-spec-button-shape-next').attr('aria-label');
            $(adRoot).attr('data-fb-intel-call_to_action', display_callToAction);
            var display_adtitle = $(adRoot).find('.title').text().trim();
            $(adRoot).attr('data-fb-intel-ad_title', display_adtitle);
            $(adRoot).attr('data-fb-intel-ad_id', hashCode(display_adtitle));
            var display_adtext = $(adRoot).find('#secondary-text').text().trim();
            $(adRoot).attr('data-fb-intel-ad_text', display_adtext);
            $(adRoot).attr('data-fb-intel-post_owner', display_adtext);
            var display_newsfeed = $(adRoot).find('#body-text').text().trim();
            $(adRoot).attr('data-fb-intel-newsfeed_description', display_newsfeed);
            var display_adLink = $(adRoot).find('a.title-link').attr('href');
            $(adRoot).attr('data-fb-intel-destination_url', display_adLink);
            var display_image = $(adRoot).find('#img').attr('src');
            $(adRoot).attr('data-fb-intel-ad_url', display_image);
            $(adRoot).attr('data-fb-intel-type', 'DISPLAY');
            $(adRoot).attr('data-fb-intel-ad_position', 'FEED');
            //$(adRoot).attr('data-fb-intel-ad_url', '');
            $(adRoot).attr('data-fb-intel-platform', '3');
            try {
                const d = new Date();
                var myDate = d.getTime()
                myDate = myDate / 1000;
                var postd = parseInt(myDate);
                $(adRoot).attr('data-fb-intel-post_date', postd);
            }
            catch (e) {
            }
            add_remaining_parameters_for_displayonly(adRoot);
        } catch { }
    }
    else if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
        if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed' ||
            $(adRoot).find('#root-container').length > 0 ||
            $(adRoot).find('#sparkles-container').length > 0) {
            try {
                var newsfeed = $(adRoot).find('#description').text();
                $(adRoot).attr('data-fb-intel-newsfeed_description', newsfeed);
                var callToAction = $(adRoot).find('#call-to-action').text();
                if (!callToAction) callToAction = $(adRoot).find('#button').attr("aria-label");
                $(adRoot).attr('data-fb-intel-call_to_action', callToAction);
                var adtitle = $(adRoot).find('#title').text().trim();
                $(adRoot).attr('data-fb-intel-ad_title', adtitle);
                $(adRoot).attr('data-fb-intel-ad_id', hashCode(adtitle));
                var adtext = $(adRoot).find('#display-url').text().trim();
                if (!adtext) adtext = $(adRoot).find('#website-text').text().trim();
                $(adRoot).attr('data-fb-intel-ad_text', adtext);
                var adLink = $(adRoot).find('a').attr('href');
                if (!adLink) adLink = $(adRoot).find('#website-text').text().trim();
                if (!adLink.includes('http')) return null;
                $(adRoot).attr('data-fb-intel-destination_url', adLink);
                var bannerOwner = $(adRoot).find('#display-url').text().trim();
                if (!bannerOwner) bannerOwner = $(adRoot).find('#website-text').text().trim();
                if (bannerOwner.includes(".")) {
                    var tempstr = bannerOwner.split(".");
                    if (tempstr.length > 2) {
                        tempstr[0] = tempstr[0]
                            .replace("https://", "")
                            .replace("http://", "")
                            .replace("www", "");
                        tempstr[1] = tempstr[1]
                            .replace("https://", "")
                            .replace("http://", "")
                            .replace("www", "");
                        if (tempstr[0].length > tempstr[1].length) {
                            bannerOwner = tempstr[0];
                        } else {
                            bannerOwner = tempstr[1];
                        }
                    } else if (tempstr.length == 2) {
                        if (tempstr[0].includes("http")) {
                            bannerOwner = tempstr[0]
                                .replace("https://", "")
                                .replace("http://", "")
                                .replace("www", "");
                        } else {
                            bannerOwner = tempstr[0];
                        }
                    }
                }
                $(adRoot).attr('data-fb-intel-post_owner', bannerOwner);
                var image = $(adRoot).find('img').attr('src');
                if (!image.includes('encrypted')) {
                    $(adRoot).attr('data-fb-intel-type', 'DISPLAY');
                    $(adRoot).attr('data-fb-intel-ad_url', image);
                } else {
                    $(adRoot).attr('data-fb-intel-ad_url', '');
                    $(adRoot).attr('data-fb-intel-type', 'BANNER');
                }
                $(adRoot).attr('data-fb-intel-platform', '3');
                try {
                    const d = new Date();
                    var myDate = d.getTime()
                    myDate = myDate / 1000;
                    var postd = parseInt(myDate);
                    $(adRoot).attr('data-fb-intel-post_date', postd);
                }
                catch (e) {
                }
                add_remaining_parameters_for_Textonly(adRoot);
            } catch {

            }
        }
    }
    else if ($(adRoot).attr('data-fb-intel-ad-type') === 'side')  // && ($(adRoot).find('div').find('#tooltip').length)>0
    {
        // debugger;
        //side ads with multiple video
        if ($(adRoot).attr('data-fb-intel-ad-type') === 'side' && ($(adRoot).find('ytd-iframe-companion-renderer').length > 0)) {
            let adownerside2images = null;
            var check = $(adRoot).find('iframe').attr('src');
            if ($(adRoot).find('iframe').attr('src') != "" && typeof check != 'undefined') {
                var url = $(adRoot).find('iframe').attr('src')
                url = url.replace(/&amp;/g, "&");
                if (url.includes("https://www.youtube.com/ad_companion")) {
                    const reqJson = {
                        async: false,
                        crossDomain: true,
                        url: url,
                        method: "GET",
                        headers: {
                            "content-type": "application/json",
                            "cache-control": "no-cache"
                        },
                        processData: false
                    };
                    $.ajax(reqJson).done(function (imgurlpagesource) {
                        $(adRoot).attr('data-fb-intel-newsfeed_description', "");
                        $(adRoot).attr('data-fb-intel-call_to_action', "");
                        var videocontainer = imgurlpagesource.split('video-wall-thumbs-v2');
                        videocontainer = videocontainer.slice(1, videocontainer.length);
                        var multivideocontainer = videocontainer[0].split('all-thumbs-v2 thumb');
                        multivideocontainer = multivideocontainer.slice(1, multivideocontainer.length);

                        var posownimg = imgurlpagesource.split("video-wall-top-bar-v2");
                        posownimg = posownimg.slice(1, posownimg.length);
                        var postownerimage = getBetween(posownimg[0], "<img class", "alt=");
                        adownerside2images = getBetween(postownerimage, "src=\"", "\"");
                        if (adownerside2images != "") {
                            $(adRoot).attr('data-fb-intel-post_owner_img', adownerside2images);
                        }

                        var videoid = "";
                        var arrvideo = "";
                        if (multivideocontainer.length > 1) {
                            multivideocontainer.forEach(function (multivideo) {
                                var video = getBetween(multivideo, "href=\"", "\"");
                                if (videoid == "") {
                                    videoid = getBetween(video, "/watch?v=", "&amp;");
                                }
                                video = video.replace(/&amp;/g, "&");
                                video = 'https://www.youtube.com' + video;
                                arrvideo = arrvideo + '||' + video;
                            });
                        }
                        else if (multivideocontainer.length == 1) {
                            var videoid = getBetween(videocontainer[0], "<a", "</a>");
                            videoid = getBetween(videoid, "href=\"/watch?v=", "\"");
                            videoid = videoid.replace(/&amp;/g, "&");
                        }
                        if (arrvideo != "") {
                            arrvideo = arrvideo.replace("||", "");
                            $(adRoot).attr('data-fb-intel-othermedia', arrvideo);
                        }
                        else {
                            $(adRoot).attr('data-fb-intel-othermedia', "");
                        }
                        $(adRoot).attr('data-fb-intel-type', "VIDEO");
                        getdetailbyvideoid($(adRoot), videoid, imgurlpagesource);


                    });
                }

            }

        }

        //side ads with only image
        else if ($(adRoot).attr('data-fb-intel-ad-type') === 'side' && ($(adRoot).find('ytd-image-companion-renderer').length > 0)) {
            try {
                $(adRoot).attr('data-fb-intel-call_to_action', "");
                $(adRoot).attr('data-fb-intel-newsfeed_description', "");
                var adlink = $(adRoot).find('ytd-image-companion-renderer').find('a')[1].href;
                if (adlink != "" && typeof adlink != 'undefined') {
                    var addesturl = adlink + '<a>';
                    addesturl = getBetween(addesturl, "adurl=", "<a>");
                    if (addesturl != "") {
                        $(adRoot).attr('data-fb-intel-destination_url', addesturl);
                        try {
                            var postowner = decodeURIComponent(decodeURIComponent(addesturl));
                            if (postowner.includes("url=")) {
                                postowner = postowner + '<a>';
                                postowner = getBetween(postowner, "url=", "<a>");
                                if (postowner.includes(".")) {
                                    var trmpurlchek = postowner.replace("www.youtube.com", "");
                                    if (!trmpurlchek.includes("www")) {
                                        trmpurlchek = trmpurlchek.replace('http://', '').replace('https://', '').split(/[/?#]/)[0]
                                        var tempstr = trmpurlchek.split(".");
                                        if (tempstr.length == 2) {
                                            if (tempstr[0].includes("http")) {
                                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            }
                                            else {
                                                postowner = tempstr[0];
                                            }
                                        }
                                        else {
                                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                                            if (tempstr[0].length > tempstr[1].length) {
                                                postowner = tempstr[0];
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }
                                    }
                                    else {
                                        var tempstr = postowner.split(".");
                                        if (tempstr.length > 2) {
                                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                                            if (tempstr[0].length > tempstr[1].length) {
                                                postowner = tempstr[0];
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }
                                        else if (tempstr.length == 2) {
                                            if (tempstr[0].includes("http")) {
                                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            }
                                            else {
                                                postowner = tempstr[0];
                                            }
                                        }

                                    }

                                }
                                if (postowner != "" && typeof postowner != 'undefined') {
                                    $(adRoot).attr('data-fb-intel-post_owner', postowner);
                                }
                            }
                            else {
                                //postowner = postowner.replace('https://','').replace('http://','').replace('www.','');
                                if (postowner.includes(".")) {
                                    var trmpurlchek = postowner.replace("www.youtube.com", "");
                                    if (!trmpurlchek.includes("www")) {
                                        trmpurlchek = trmpurlchek.replace('http://', '').replace('https://', '').split(/[/?#]/)[0]
                                        var tempstr = trmpurlchek.split(".");
                                        if (tempstr.length == 2) {
                                            if (tempstr[0].includes("http")) {
                                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }
                                        else {
                                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                                            if (tempstr[0].length > tempstr[1].length) {
                                                postowner = tempstr[0];
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }
                                    }
                                    else {
                                        var tempstr = postowner.split(".");
                                        if (tempstr.length > 2) {
                                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                                            if (tempstr[0].length > tempstr[1].length) {
                                                postowner = tempstr[0];
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }
                                        else if (tempstr.length == 2) {
                                            if (tempstr[0].includes("http")) {
                                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            }
                                            else {
                                                postowner = tempstr[0];
                                            }
                                        }

                                    }

                                }
                                if (postowner != "" && typeof postowner != 'undefined') {
                                    $(adRoot).attr('data-fb-intel-post_owner', postowner);
                                }
                            }

                        }
                        catch (e) {

                        }
                    }
                    else {
                        $(adRoot).attr('data-fb-intel-destination_url', adlink);
                    }
                }
            }
            catch (e) {

            }
            try {
                var adimage = $(adRoot).find('ytd-image-companion-renderer').find('img')[0].currentSrc;
                if (adimage != "" && typeof adimage != 'undefined') {
                    $(adRoot).attr('data-fb-intel-ad_url', adimage);
                    $(adRoot).attr('data-fb-intel-type', "IMAGE");
                    var str = hashCode(adimage);
                    if (str != "") {
                        $(adRoot).attr('data-fb-intel-ad_id', str);
                    }
                }
            }
            catch (e) {

            }
            try {
                const d = new Date();
                var myDate = d.getTime()
                myDate = myDate / 1000;
                var postd = parseInt(myDate);
                $(adRoot).attr('data-fb-intel-post_date', postd);
            }
            catch (e) {

            }
            add_remaining_parameters_for_imageonly($(adRoot));
        }

        //side ads with without ad id
        else if ($(adRoot).attr('data-fb-intel-ad-type') === 'side' && ($(adRoot).find('ytd-companion-slot-renderer').length > 0)) {
            let adownersideimages = null;
            var tempimg = "";
            try {
                var adimage = $(adRoot).find('#banner').find('img').attr('src');
                if (adimage != "" && typeof adimage != 'undefined') {
                    if(adimage === "https://yt3.ggpht.com/jVxsz7lpatakQ2_tY38jm-zxEmmR7GfzPZbdxz8yNwGlHm8tncEzbddatDBSxj_S1cyygUO9=w1060-fcrop64=1,00005a57ffffa5a8-k-c0xffffffff-no-nd-rj") return null;
                    tempimg = adimage;
                    $(adRoot).attr('data-fb-intel-ad_url', adimage);
                    $(adRoot).attr('data-fb-intel-type', "IMAGE");
                    var str = hashCode(adimage);
                    if (str != "") {
                        $(adRoot).attr('data-fb-intel-ad_id', str);
                    }
                }
            }
            catch (e) {

            }
            if (adimage != "" && typeof adimage != 'undefined') {
                try {
                    adownersideimages = $(adRoot).find('#icon').find('img').attr('src');
                    if (adownersideimages != "" && typeof adownersideimages != 'undefined') {
                        $(adRoot).attr('data-fb-intel-post_owner_img', adownersideimages);
                    }
                }
                catch (e) {

                }
                try {
                    var adtitle = $(adRoot).find('#header')[0].innerText;
                    if (adtitle != "" && typeof adtitle != 'undefined') {
                        $(adRoot).attr('data-fb-intel-ad_title', adtitle);
                    }
                }
                catch (e) {

                }
                try {
                    var desturl = $(adRoot).find('#domain').text();
                    if (desturl != "" && typeof desturl != 'undefined') {
                        var addesturl = desturl + '<a>';
                        addesturl = getBetween(addesturl, "adurl=", "<a>");
                        if (addesturl != "" && typeof addesturl != 'undefined') {
                            addesturl = 'https://' + addesturl;
                            $(adRoot).attr('data-fb-intel-destination_url', addesturl);
                        }
                        else {
                            desturl = $(adRoot).find('#domain').text();
                            if (desturl != "" && typeof desturl != 'undefined') {
                                desturl = 'https://' + desturl;
                                $(adRoot).attr('data-fb-intel-destination_url', desturl);
                            }
                        }
                    }
                    else {
                        desturl = $(adRoot).find('#domain').text();
                        if (desturl != "" && typeof desturl != 'undefined') {
                            desturl = 'https://' + desturl;
                            $(adRoot).attr('data-fb-intel-destination_url', desturl);
                        }
                    }

                }
                catch (e) {

                }
                try {
                    var postowner = $(adRoot).find('#domain')[0].innerText;
                    //postowner = postowner.replace('http://','').replace('https://','').replace('www.','');
                    if (postowner.includes(".")) {
                        var tempstr = postowner.split(".");
                        if (tempstr.length > 2) {
                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                            if (tempstr[0].length > tempstr[1].length) {
                                postowner = tempstr[0];
                            }
                            else {
                                postowner = tempstr[1];
                            }
                        }
                        else if (tempstr.length == 2) {
                            if (tempstr[0].includes("http")) {
                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                            }
                            else {
                                postowner = tempstr[0];
                            }
                        }

                    }

                    if (postowner != "" && typeof postowner != 'undefined') {
                        $(adRoot).attr('data-fb-intel-post_owner', postowner);
                    }
                }
                catch (e) {

                }
                try {
                    const d = new Date();
                    var myDate = d.getTime()
                    myDate = myDate / 1000;
                    var postd = parseInt(myDate);
                    $(adRoot).attr('data-fb-intel-post_date', postd);
                }
                catch (e) {

                }
                try {
                    var calltoaction = $(adRoot).find('#action')[0].innerText;
                    if (calltoaction != "" && typeof calltoaction != 'undefined') {
                        calltoaction = calltoaction.replace("\n", "");
                        //  console.log("Call_to_action " + calltoaction)
                        $(adRoot).attr('data-fb-intel-call_to_action', calltoaction);
                    }
                }
                catch (e) {

                }
                try {
                    var addescrption = $(adRoot).find('#domain')[0].innerText;
                    if (addescrption != "" && typeof addescrption != 'undefined') {
                        $(adRoot).attr('data-fb-intel-newsfeed_description', addescrption);
                    }
                    else {
                        $(adRoot).attr('data-fb-intel-newsfeed_description', "");
                    }
                }
                catch (e) {

                }
                add_remaining_parameters_withoutadid($(adRoot));
            }
        }
    }

    else if ($(adRoot).attr('data-fb-intel-ad-type') === 'middle') {
        if ($(adRoot).attr('data-fb-intel-ad-type') === 'middle' && ($(adRoot).find('.image-container').length > 0)) {
            try {
                $(adRoot).attr('data-fb-intel-newsfeed_description', "");
                $(adRoot).attr('data-fb-intel-call_to_action', "");
                var adlink = $(adRoot).find('.adDisplay').find('a').attr('href');
                if (adlink != "" && typeof adlink != 'undefined') {
                    var addesturl = adlink + '<a>';
                    addesturl = getBetween(addesturl, "adurl=", "<a>");
                    if (addesturl != "") {
                        $(adRoot).attr('data-fb-intel-destination_url', addesturl);
                        try {
                            var postowner = decodeURIComponent(decodeURIComponent(addesturl));
                            if (postowner.includes("url=")) {
                                postowner = postowner + '<a>';
                                postowner = getBetween(postowner, "url=", "<a>");
                                //postowner = postowner.replace('https://','').replace('http://','').replace('www.','');
                                if (postowner.includes(".")) {
                                    var trmpurlchek = postowner.replace("www.youtube.com", "");
                                    if (!trmpurlchek.includes("www")) {
                                        trmpurlchek = trmpurlchek.replace('http://', '').replace('https://', '').split(/[/?#]/)[0]
                                        var tempstr = trmpurlchek.split(".");
                                        if (tempstr.length == 2) {
                                            if (tempstr[0].includes("http")) {
                                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            }
                                            else {
                                                postowner = tempstr[0];
                                            }
                                        }
                                        else {
                                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                                            if (tempstr[0].length > tempstr[1].length) {
                                                postowner = tempstr[0];
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }
                                    }
                                    else {
                                        var tempstr = postowner.split(".");
                                        if (tempstr.length > 2) {
                                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                                            if (tempstr[0].length > tempstr[1].length) {
                                                postowner = tempstr[0];
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }
                                        else if (tempstr.length == 2) {
                                            if (tempstr[0].includes("http")) {
                                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            }
                                            else {
                                                postowner = tempstr[0];
                                            }
                                        }

                                    }

                                }
                                if (postowner != "" && typeof postowner != 'undefined') {
                                    $(adRoot).attr('data-fb-intel-post_owner', postowner);
                                }
                            }
                            else {
                                //postowner = postowner.replace('https://','').replace('http://','').replace('www.','');
                                if (postowner.includes(".")) {
                                    var trmpurlchek = postowner.replace("www.youtube.com", "");
                                    if (!trmpurlchek.includes("www")) {
                                        trmpurlchek = trmpurlchek.replace('http://', '').replace('https://', '').split(/[/?#]/)[0]
                                        var tempstr = trmpurlchek.split(".");
                                        if (tempstr.length == 2) {
                                            if (tempstr[0].includes("http")) {
                                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            }
                                            else {
                                                postowner = tempstr[0];
                                            }
                                        }
                                        else {
                                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                                            if (tempstr[0].length > tempstr[1].length) {
                                                postowner = tempstr[0];
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }

                                    }
                                    else {
                                        var tempstr = postowner.split(".");
                                        if (tempstr.length > 2) {
                                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                                            if (tempstr[0].length > tempstr[1].length) {
                                                postowner = tempstr[0];
                                            }
                                            else {
                                                postowner = tempstr[1];
                                            }
                                        }
                                        else if (tempstr.length == 2) {
                                            if (tempstr[0].includes("http")) {
                                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                                            }
                                            else {
                                                postowner = tempstr[0];
                                            }
                                        }
                                    }

                                }
                                if (postowner != "" && typeof postowner != 'undefined') {
                                    $(adRoot).attr('data-fb-intel-post_owner', postowner);
                                }
                            }

                        }
                        catch (e) {

                        }
                    }
                    else {
                        $(adRoot).attr('data-fb-intel-destination_url', adlink);
                    }
                }
            }
            catch (e) {

            }
            try {
                var adimage = $(adRoot).find('.adDisplay').find('img')[0].currentSrc;
                if (adimage != "" && typeof adimage != 'undefined') {
                    $(adRoot).attr('data-fb-intel-ad_url', adimage);
                    $(adRoot).attr('data-fb-intel-type', "IMAGE");
                    var str = hashCode(adimage);
                    if (str != "") {
                        $(adRoot).attr('data-fb-intel-ad_id', str);
                    }
                }
            }
            catch (e) {

            }
            try {
                const d = new Date();
                var myDate = d.getTime()
                myDate = myDate / 1000;
                var postd = parseInt(myDate);
                $(adRoot).attr('data-fb-intel-post_date', postd);
            }
            catch (e) {

            }
            add_remaining_parameters_for_imageonly($(adRoot));
        }
        //Main player Middle ads Only Text type ads
        else if ($(adRoot).attr('data-fb-intel-ad-type') === 'middle' && ($(adRoot).find('.text-container').length > 0)) {
            var adurlid = "";
            $(adRoot).attr('data-fb-intel-call_to_action', "");
            try {
                var adlink = $(adRoot).find('.text-title').attr('href');
                if (adlink != "" && typeof adlink != 'undefined') {
                    var addesturl = adlink + '<a>';
                    addesturl = getBetween(addesturl, "adurl=", "<a>");
                    if (addesturl != "") {
                        $(adRoot).attr('data-fb-intel-destination_url', addesturl);
                    }
                    else {
                        $(adRoot).attr('data-fb-intel-destination_url', adlink);
                    }
                }
            }
            catch (e) {

            }
            try {
                var adtitle = $(adRoot).find('.text-title')[0].innerText;
                if (adtitle != "" && typeof adtitle != 'undefined') {
                    $(adRoot).attr('data-fb-intel-ad_title', adtitle);
                    $(adRoot).attr('data-fb-intel-type', "TEXT");
                    var str = hashCode(adtitle);
                    if (str != "") {
                        adurlid = str;
                        $(adRoot).attr('data-fb-intel-ad_id', str);
                    }
                }
            }
            catch (e) {

            }
            try {
                var adtext = $(adRoot).find('.text-description')[0].innerText;
                if (adtext != "" && typeof adtext != 'undefined') {
                    $(adRoot).attr('data-fb-intel-ad_text', adtext);
                }
            }
            catch (e) {

            }
            try {
                var addescrption = $(adRoot).find('.text-ad-channel')[0].innerText;
                if (addescrption != "" && typeof addescrption != 'undefined') {
                    $(adRoot).attr('data-fb-intel-newsfeed_description', addescrption);
                    if (!addescrption.includes("http")) {
                        var adurl = 'https://' + addescrption + "/" + adurlid;
                        $(adRoot).attr('data-fb-intel-ad_url', adurl);
                    }
                    else {
                        var adurl = addescrption + "/" + adurlid;
                        $(adRoot).attr('data-fb-intel-ad_url', adurl);
                    }

                    var postowner = addescrption;
                    //postowner = postowner.replace('http://','').replace('https://','').replace('www.','');
                    if (postowner.includes(".")) {
                        var tempstr = postowner.split(".");
                        if (tempstr.length > 2) {
                            tempstr[0] = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                            tempstr[1] = tempstr[1].replace("https://", "").replace("http://", "").replace("www", "");
                            if (tempstr[0].length > tempstr[1].length) {
                                postowner = tempstr[0];
                            }
                            else {
                                postowner = tempstr[1];
                            }
                        }
                        else if (tempstr.length == 2) {
                            if (tempstr[0].includes("http")) {
                                postowner = tempstr[0].replace("https://", "").replace("http://", "").replace("www", "");
                            }
                            else {
                                postowner = tempstr[0];
                            }

                        }
                    }
                    if (postowner != "" && typeof postowner != 'undefined') {
                        $(adRoot).attr('data-fb-intel-post_owner', postowner);
                    }
                }
                else {
                    $(adRoot).attr('data-fb-intel-newsfeed_description', "");
                }
            }
            catch (e) {

            }
            try {
                const d = new Date();
                var myDate = d.getTime()
                myDate = myDate / 1000;
                var postd = parseInt(myDate);
                $(adRoot).attr('data-fb-intel-post_date', postd);
            }
            catch (e) {

            }
            add_remaining_parameters_for_Textonly($(adRoot));
        }

    }
    return null;
}

function getOwner(adRoot) {
    return null;
}

function getdescription(adRoot) {
    return null;
}

function getcall_to_action(adRoot) {
    return null;
}

function getothermedia(adRoot) {
    return null;;
}

function getPostOwnerImage(adRoot) {
    return null;
}

function getchannnelurl(adRoot) {
    return null;
}

function getPosition(adRoot) {
    if ($(adRoot).attr('data-fb-intel-ad-type') === 'feed') {
        return "FEED";
    } else if ($(adRoot).attr('data-fb-intel-ad-type') === 'side') {
        return "SIDE";
    }
    else if ($(adRoot).attr('data-fb-intel-ad-type') === 'middle') {
        return "FEED";
    }
}
function getpost_date(adRoot) {
    return null;
}
function gettype(adRoot) {
    return null;
}
function getTags(adRoot) {
    return null;
}
function getthumbnail(adRoot) {
    return null;
}
function getAdText(adRoot) {
    return null;
}
function getLikesCount(adRoot) {
    return null;
}
function getdislikeCount(adRoot) {
    return null;
}
function getviewsCount(adRoot) {
    return null;
}
function getCommentsCount(adRoot) {
    return null;
}

function getDestinationUrl(adRoot) {
    return null;
}

function getTitle(adRoot) {
    return null;
}

function getAdId(adRoot) {
    return null;
}

function getAdUrl(adRoot) {
    return null;
}

function getAdImage(adRoot) {
    return null;
}

function getFirstSeen() {
    //debugger;
    const d = new Date();
    var myDate = d.getTime()
    myDate = myDate / 1000;
    return parseInt(myDate);
    //return new Date();
}

function getLastSeen() {
    //debugger;
    const d = new Date();
    var myDate = d.getTime()
    myDate = myDate / 1000;
    return parseInt(myDate);
    //return new Date();
}
function getLowerAdAge() {
    //debugger;
    //return birthday.toString();
    return "18";
}

function getUpperAdAge() {
    //debugger;
    return "65";
}
function getLinkedInId() {
    //debugger;
    return user_ID;
}

function getUserData() {
    let data = document.getElementsByTagName("html")[0].innerHTML;
    var tempUserId = data.split("publicIdentifier");
    user_ID = tempUserId[1];
    user_ID = getBetween(user_ID, ":\"", "\",");

}

function buildUpGeoData() {
    if (isProcessingGeoData) {
        return;
    }
    isProcessingGeoData = true;

    if (!geoData.userIP || !geoData.userCity || !geoData.userState || !geoData.userCountry) {
        if (!geoData.userIP) {
            const ourIP = "https://geolocation.poweradspy.com/";
            $.ajax({
                url: ourIP,
                type: "GET",
                async: true,
                success: function (IpResponse) {
                    const ourIpResponse = JSON.parse(IpResponse);
                    geoData.userIP = ourIpResponse.ip;
                    geoData.userCity = ourIpResponse.cityName;
                    geoData.userState = ourIpResponse.regionName;
                    geoData.userCountry = ourIpResponse.countryName;
                    geoData.lastUpdated = Date.now();
                    chrome.storage.local.set({ "geoData": geoData });
                    isProcessingGeoData = false;
                }
            });
        }
    }
}

function getdetailbyvideoid(adRoot, videoid, imgurlpages) {
    //debugger;
    var myArray = ['AIzaSyAN9CEiGS5M5__TfMXSCpfej31WzUAe9oI', 'AIzaSyAPKS6pAEm3GDDIPQ6iJWyD6MrKo7eWWPk', 'AIzaSyATgFNuIFT6L5BMrFWDrkbkYOS8Iy0nTko', 'AIzaSyAiJyjXaLnBjds1Jk5mStU77ZWIAKTQlo8', 'AIzaSyBlfWJe7algPMWO8EbYYkiB0kBdqWgVhEo'];
    var randKey = myArray[Math.floor(Math.random() * myArray.length)];
    let adPostId = videoid;
    let adUrl = null;
    const categoryUrl = "https://www.googleapis.com/youtube/v3/videos?part=statistics,snippet&id=" + videoid + "&key=" + randKey;
    // console.log(categoryUrl);
    if (adPostId) {
        const reqJson = {
            async: false,
            crossDomain: true,
            url: categoryUrl,
            method: "GET",
            headers: {
                "content-type": "application/json",
                "cache-control": "no-cache"
            },
            processData: false
        };
        $.ajax(reqJson).done(function (imgurlpagesource) {
            //console.log("imgurlpagesource ",imgurlpagesource);
            //debugger;
            let likescount = null;
            let dislikecount = null;
            let viewcount = null;
            let commentcount = null;
            let categoryId = null;
            let description = null;
            let Title = null;
            let channelUrl = null;
            let postdate = null;
            let Tags = [];
            let thumbnail = null;
            let adurl = null;
            let destURL = null;
            let postowner = null;

            try {
                var adId = imgurlpagesource.items[0].id;
                if (adId != "" && typeof adId != 'undefined') {
                    adPostId = adId;
                    $(adRoot).attr('data-fb-intel-ad_id', adPostId);
                }
                else {
                    $(adRoot).attr('data-fb-intel-ad_id', adPostId);
                }
            }
            catch (e) {
                //$(adRoot).attr('data-fb-intel-ad_id',adPostId);
            }
            try {
                postowner = imgurlpagesource.items[0].snippet.channelTitle;
                if (postowner != "" && typeof Title != 'undefined') {
                    $(adRoot).attr('data-fb-intel-post_owner', postowner);
                }
            }
            catch (e) {
                // $(adRoot).attr('data-fb-intel-ad_title',"");
            }
            try {
                Title = imgurlpagesource.items[0].snippet.localized.title;
                if (Title != "" && typeof Title != 'undefined') {
                    $(adRoot).attr('data-fb-intel-ad_title', Title);
                }
                else {
                    $(adRoot).attr('data-fb-intel-ad_title', "");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-ad_title', "");
            }
            try {
                adurl = "https://www.youtube.com/watch?v=" + adPostId;
                if (adurl != "" && typeof adurl != 'undefined') {
                    $(adRoot).attr('data-fb-intel-ad_url', adurl);
                }
            }
            catch (e) {

            }
            try {
                description = imgurlpagesource.items[0].snippet.localized.description;
                description = description.replace(/\n/g, " ");
                if (description != "" && typeof description != 'undefined') {
                    $(adRoot).attr('data-fb-intel-ad_text', description);
                }
                else {
                    $(adRoot).attr('data-fb-intel-ad_text', "");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-ad_text', "");
            }

            try {
                if ((description != "" && typeof description != 'undefined') && (description.includes("http://") || description.includes("https://") || description.includes("www"))) {
                    description = description + ' ';
                    if (description.includes("http")) {
                        destURL = getBetween(description, "http", " ");
                        destURL = "http" + destURL;
                        if (destURL == "http") {
                            destURL = "";
                        }
                    }
                    else if (description.includes("www")) {
                        destURL = getBetween(description, "www", " ");
                        destURL = "www" + destURL;
                        if (destURL == "www") {
                            destURL = "";
                        }
                    }
                }
                else {
                    var AdLink = imgurlpages.split('video-wall-cta-container');
                    AdLink = AdLink.slice(1, AdLink.length);
                    destURL = getBetween(AdLink[0], "<a", "</a>");
                    destURL = getBetween(destURL, "href=\"", "\"");
                    if (destURL != "") {
                        $(adRoot).attr('data-fb-intel-destination_url', destURL);
                    }
                    else {
                        $(adRoot).attr('data-fb-intel-destination_url', adurl);
                    }
                }
                if (destURL != "" && typeof destURL != 'undefined') {
                    $(adRoot).attr('data-fb-intel-destination_url', destURL);
                }
                else {
                    $(adRoot).attr('data-fb-intel-destination_url', adurl);
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-destination_url', adurl);
            }
            try {
                categoryId = imgurlpagesource.items[0].snippet.categoryId;
                if (categoryId != "" && typeof categoryId != 'undefined') {
                    $(adRoot).attr('data-fb-intel-category', categoryId);
                }
                else {
                    $(adRoot).attr('data-fb-intel-category', "0");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-category', "0");
            }
            try {
                channelUrl = imgurlpagesource.items[0].snippet.channelId;
                channelUrl = "https://www.youtube.com/channel/" + channelUrl;
                if (channelUrl != "" && typeof channelUrl != 'undefined') {
                    $(adRoot).attr('data-fb-intel-channel_url', channelUrl);
                }
                else {
                    $(adRoot).attr('data-fb-intel-channel_url', "");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-channel_url', "");
            }
            try {
                postdate = imgurlpagesource.items[0].snippet.publishedAt;
                var myDate = Date.parse(postdate) / 1000;
                ///postdate=parseInt(myDate);
                if (postdate != "" && typeof postdate != 'undefined') {
                    $(adRoot).attr('data-fb-intel-post_date', parseInt(myDate));
                }
                else {
                    $(adRoot).attr('data-fb-intel-post_date', "");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-post_date', "");
            }
            try {
                Tags = imgurlpagesource.items[0].snippet.tags;
                if (Tags != "" && typeof Tags != 'undefined') {
                    $(adRoot).attr('data-fb-intel-tags', Tags);
                }
                else {
                    $(adRoot).attr('data-fb-intel-tags', "");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-tags', "");
            }
            try {
                thumbnail = imgurlpagesource.items[0].snippet.thumbnails.medium.url;
                if (thumbnail != "" && typeof thumbnail != 'undefined') {
                    $(adRoot).attr('data-fb-intel-thumbnail', thumbnail);
                }
                else {
                    $(adRoot).attr('data-fb-intel-thumbnail', "");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-thumbnail', "");
            }

            try {
                likescount = imgurlpagesource.items[0].statistics.likeCount;
                if (likescount != "" && typeof likescount != 'undefined') {
                    $(adRoot).attr('data-fb-intel-likes', likescount);
                }
                else {
                    $(adRoot).attr('data-fb-intel-likes', "0");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-likes', "0");
            }

            try {
                dislikecount = imgurlpagesource.items[0].statistics.dislikeCount;
                if (dislikecount != "" && typeof dislikecount != 'undefined') {
                    $(adRoot).attr('data-fb-intel-dislike', dislikecount);
                }
                else {
                    $(adRoot).attr('data-fb-intel-dislike', "0");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-dislike', "0");
            }

            try {
                viewcount = imgurlpagesource.items[0].statistics.viewCount;
                if (viewcount != "" && typeof viewcount != 'undefined') {
                    $(adRoot).attr('data-fb-intel-views', viewcount);
                }
                else {
                    $(adRoot).attr('data-fb-intel-views', "0");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-views', "0");
            }

            try {
                commentcount = imgurlpagesource.items[0].statistics.commentCount;
                if (commentcount != "" && typeof commentcount != 'undefined') {
                    $(adRoot).attr('data-fb-intel-comment', commentcount);
                }
                else {
                    $(adRoot).attr('data-fb-intel-comment', "0");
                }
            }
            catch (e) {
                $(adRoot).attr('data-fb-intel-comment', "0");
            }

        }).fail(function (error) {
            debugger;
            //if (enableDebugger) //debugger;
        });
    }
}

function add_remaining_parameters_for_displayonly(adRoot) {
    $(adRoot).attr('data-fb-intel-category', "");
    $(adRoot).attr('data-fb-intel-othermedia', "");
    $(adRoot).attr('data-fb-intel-channel_url', "");
    $(adRoot).attr('data-fb-intel-post_owner_img', "");
    $(adRoot).attr('data-fb-intel-tags', "");
    $(adRoot).attr('data-fb-intel-thumbnail', "");
    $(adRoot).attr('data-fb-intel-likes', "0");
    $(adRoot).attr('data-fb-intel-dislike', "0");
    $(adRoot).attr('data-fb-intel-views', "0");
    $(adRoot).attr('data-fb-intel-comment', "0");
}

function add_remaining_parameters_for_imageonly(adRoot) {
    $(adRoot).attr('data-fb-intel-category', "");
    $(adRoot).attr('data-fb-intel-othermedia', "");
    $(adRoot).attr('data-fb-intel-channel_url', "");
    //$(adRoot).attr('data-fb-intel-post_owner',"");
    $(adRoot).attr('data-fb-intel-post_owner_img', "");
    $(adRoot).attr('data-fb-intel-ad_text', "");
    $(adRoot).attr('data-fb-intel-tags', "");
    $(adRoot).attr('data-fb-intel-thumbnail', "");
    $(adRoot).attr('data-fb-intel-likes', "0");
    $(adRoot).attr('data-fb-intel-dislike', "0");
    $(adRoot).attr('data-fb-intel-views', "0");
    $(adRoot).attr('data-fb-intel-comment', "0");
    $(adRoot).attr('data-fb-intel-ad_title', "");
}

function add_remaining_parameters_for_Textonly(adRoot) {
    //$(adRoot).attr('data-fb-intel-ad_url',"");
    $(adRoot).attr('data-fb-intel-category', "");
    $(adRoot).attr('data-fb-intel-othermedia', "");
    $(adRoot).attr('data-fb-intel-channel_url', "");
    //$(adRoot).attr('data-fb-intel-post_owner',"");
    $(adRoot).attr('data-fb-intel-post_owner_img', "");
    $(adRoot).attr('data-fb-intel-tags', "");
    $(adRoot).attr('data-fb-intel-thumbnail', "");
    $(adRoot).attr('data-fb-intel-likes', "0");
    $(adRoot).attr('data-fb-intel-dislike', "0");
    $(adRoot).attr('data-fb-intel-views', "0");
    $(adRoot).attr('data-fb-intel-comment', "0");
}

function add_remaining_parameters_withoutadid(adRoot) {
    $(adRoot).attr('data-fb-intel-othermedia', "");
    $(adRoot).attr('data-fb-intel-ad_text', "");
    $(adRoot).attr('data-fb-intel-category', "");
    $(adRoot).attr('data-fb-intel-channel_url', "");
    $(adRoot).attr('data-fb-intel-tags', "");
    $(adRoot).attr('data-fb-intel-thumbnail', "");
    $(adRoot).attr('data-fb-intel-likes', "0");
    $(adRoot).attr('data-fb-intel-dislike', "0");
    $(adRoot).attr('data-fb-intel-views', "0");
    $(adRoot).attr('data-fb-intel-comment', "0");
}

function RemovecheckForNew() {
    //debugger;
    // document.getElementById('player-container').removeAttribute("data-fb-intel-triaged");
    var element = document.getElementById("player-container");

    if (!element)
        return;

    var elementcls = element;
    element = element.outerHTML;
    $(element).removeAttr("data-fb-intel-type");
    // $(element).removeAttr("data-fb-intel-parsed");
    $(element).removeAttr("data-fb-intel-triaged");
    $(element).removeAttr("data-fb-intel-attempts");
    $(element).removeAttr("data-fb-intel-events-added");
    $(element).removeAttr("data-fb-intel-saved");
    $(element).removeAttr("data-fb-intel-category");
    $(element).removeAttr("data-fb-intel-ad_url");
    $(element).removeAttr("data-fb-intel-call_to_action");
    $(element).removeAttr("data-fb-intel-ad_id");
    $(element).removeAttr("data-fb-intel-channel_url");
    $(element).removeAttr("data-fb-intel-post_date");
    $(element).removeAttr("data-fb-intel-post_owner");
    $(element).removeAttr("data-fb-intel-post_owner_img");
    $(element).removeAttr("data-fb-intel-ad_position");
    $(element).removeAttr("data-fb-intel-ad_text");
    $(element).removeAttr("data-fb-intel-destination_url");
    $(element).removeAttr("data-fb-intel-likes");
    $(element).removeAttr("data-fb-intel-dislike");
    $(element).removeAttr("data-fb-intel-views");
    $(element).removeAttr("data-fb-intel-comment");
    $(element).removeAttr("data-fb-intel-ad_title");
    $(element).removeAttr("data-fb-intel-platform");
    $(element).removeAttr("data-fb-intel-first_seen");
    $(element).removeAttr("data-fb-intel-last_seen");
    $(element).removeAttr("data-fb-intel-lower_age");
    $(element).removeAttr("data-fb-intel-upper_age");
    $(element).removeAttr("data-fb-intel-newsfeed_description");
    $(element).removeAttr("data-fb-ad");
    elementcls.classList.remove("fb-intel-ad");
    $(element).removeClass("fb-intel-ad");

}

function RemovecheckForNewForSideads() {
    // debugger;
    // document.getElementById('player-container').removeAttribute("data-fb-intel-triaged");
    var element = document.getElementById("player-ads");

    if (!element)
        return;


    var elementcls = element;
    element = element.outerHTML;
    $(element).removeAttr("data-fb-intel-type");
    $(element).removeAttr("data-fb-intel-triaged");
    // $(element).removeAttr("data-fb-intel-parsed");
    $(element).removeAttr("data-fb-intel-attempts");
    $(element).removeAttr("data-fb-intel-events-added");
    $(element).removeAttr("data-fb-intel-saved");
    $(element).removeAttr("data-fb-intel-category");
    $(element).removeAttr("data-fb-intel-ad_url");
    $(element).removeAttr("data-fb-intel-call_to_action");
    $(element).removeAttr("data-fb-intel-ad_id");
    $(element).removeAttr("data-fb-intel-channel_url");
    $(element).removeAttr("data-fb-intel-post_date");
    $(element).removeAttr("data-fb-intel-post_owner");
    $(element).removeAttr("data-fb-intel-post_owner_img");
    $(element).removeAttr("data-fb-intel-ad_position");
    $(element).removeAttr("data-fb-intel-ad_text");
    $(element).removeAttr("data-fb-intel-destination_url");
    $(element).removeAttr("data-fb-intel-likes");
    $(element).removeAttr("data-fb-intel-dislike");
    $(element).removeAttr("data-fb-intel-views");
    $(element).removeAttr("data-fb-intel-comment");
    $(element).removeAttr("data-fb-intel-ad_title");
    $(element).removeAttr("data-fb-intel-platform");
    $(element).removeAttr("data-fb-intel-first_seen");
    $(element).removeAttr("data-fb-intel-last_seen");
    $(element).removeAttr("data-fb-intel-lower_age");
    $(element).removeAttr("data-fb-intel-upper_age");
    $(element).removeAttr("data-fb-intel-newsfeed_description");
    $(element).removeAttr("data-fb-ad");
    elementcls.classList.remove("fb-intel-ad");
    $(element).removeClass("fb-intel-ad");

}

function clear_check_For_New_Feed_ads() {
    // debugger;
    // document.getElementById('player-container').removeAttribute("data-fb-intel-triaged");
    var element = document.getElementById("player-container");
    element = element.outerHTML;
    $(element).removeAttr("data-fb-intel-type");
    $(element).removeAttr("data-fb-intel-category");
    $(element).removeAttr("data-fb-intel-ad_url");
    $(element).removeAttr("data-fb-intel-call_to_action");
    $(element).removeAttr("data-fb-intel-ad_id");
    $(element).removeAttr("data-fb-intel-channel_url");
    $(element).removeAttr("data-fb-intel-post_date");
    $(element).removeAttr("data-fb-intel-post_owner");
    $(element).removeAttr("data-fb-intel-post_owner_img");
    $(element).removeAttr("data-fb-intel-ad_position");
    $(element).removeAttr("data-fb-intel-ad_text");
    $(element).removeAttr("data-fb-intel-destination_url");
    $(element).removeAttr("data-fb-intel-likes");
    $(element).removeAttr("data-fb-intel-dislike");
    $(element).removeAttr("data-fb-intel-views");
    $(element).removeAttr("data-fb-intel-comment");
    $(element).removeAttr("data-fb-intel-ad_title");
    $(element).removeAttr("data-fb-intel-platform");
    $(element).removeAttr("data-fb-intel-first_seen");
    $(element).removeAttr("data-fb-intel-last_seen");
    $(element).removeAttr("data-fb-intel-lower_age");
    $(element).removeAttr("data-fb-intel-upper_age");
    $(element).removeAttr("data-fb-intel-newsfeed_description");
}
function clear_check_For_New_Side_ads() {
    //debugger;
    // document.getElementById('player-container').removeAttribute("data-fb-intel-triaged");
    var element = document.getElementById("player-ads");
    element = element.outerHTML;
    $(element).removeAttr("data-fb-intel-type");
    $(element).removeAttr("data-fb-intel-category");
    $(element).removeAttr("data-fb-intel-ad_url");
    $(element).removeAttr("data-fb-intel-call_to_action");
    $(element).removeAttr("data-fb-intel-ad_id");
    $(element).removeAttr("data-fb-intel-channel_url");
    $(element).removeAttr("data-fb-intel-post_date");
    $(element).removeAttr("data-fb-intel-post_owner");
    $(element).removeAttr("data-fb-intel-post_owner_img");
    $(element).removeAttr("data-fb-intel-ad_position");
    $(element).removeAttr("data-fb-intel-ad_text");
    $(element).removeAttr("data-fb-intel-destination_url");
    $(element).removeAttr("data-fb-intel-likes");
    $(element).removeAttr("data-fb-intel-dislike");
    $(element).removeAttr("data-fb-intel-views");
    $(element).removeAttr("data-fb-intel-comment");
    $(element).removeAttr("data-fb-intel-ad_title");
    $(element).removeAttr("data-fb-intel-platform");
    $(element).removeAttr("data-fb-intel-first_seen");
    $(element).removeAttr("data-fb-intel-last_seen");
    $(element).removeAttr("data-fb-intel-lower_age");
    $(element).removeAttr("data-fb-intel-upper_age");
    $(element).removeAttr("data-fb-intel-newsfeed_description");

}

function clear_check_For_New_Banner_ads1() {
    var element = document.getElementById("root-container");
    element = element.outerHTML;
    $(element).removeAttr("data-fb-intel-type");
    $(element).removeAttr("data-fb-intel-category");
    $(element).removeAttr("data-fb-intel-ad_url");
    $(element).removeAttr("data-fb-intel-call_to_action");
    $(element).removeAttr("data-fb-intel-ad_id");
    $(element).removeAttr("data-fb-intel-channel_url");
    $(element).removeAttr("data-fb-intel-post_date");
    $(element).removeAttr("data-fb-intel-post_owner");
    $(element).removeAttr("data-fb-intel-post_owner_img");
    $(element).removeAttr("data-fb-intel-ad_position");
    $(element).removeAttr("data-fb-intel-ad_text");
    $(element).removeAttr("data-fb-intel-destination_url");
    $(element).removeAttr("data-fb-intel-likes");
    $(element).removeAttr("data-fb-intel-dislike");
    $(element).removeAttr("data-fb-intel-views");
    $(element).removeAttr("data-fb-intel-comment");
    $(element).removeAttr("data-fb-intel-ad_title");
    $(element).removeAttr("data-fb-intel-platform");
    $(element).removeAttr("data-fb-intel-first_seen");
    $(element).removeAttr("data-fb-intel-last_seen");
    $(element).removeAttr("data-fb-intel-lower_age");
    $(element).removeAttr("data-fb-intel-upper_age");
    $(element).removeAttr("data-fb-intel-newsfeed_description");
}

function clear_check_For_New_Banner_ads() {
    //var element = document.getElementById("root-container");
    var elements = document.querySelectorAll('#root-container');
    if (!elements)
        elements = document.querySelectorAll('div#sparkles-container');
    elements.forEach(element => {
        if (element) {
            for (var i = element.attributes.length - 1; i >= 0; i--) {
                if (element.attributes[i].name != "id") {
                    if (element.attributes[i].name != "role") {
                        if (element.attributes[i].name != "class") {
                            element.removeAttribute(element.attributes[i].name);
                        }
                        else if (element.attributes[i].name == "class") {
                            $(element).removeClass("fb-intel-ad");
                        }
                    }

                }

            }
        }
    });
}

//Start Main Loop to get all ads
function checkForNew() {

    $("div#player-container:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "feed")
        .addClass('fb-intel-ad');

    $("div#player-ads:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "side")
        .addClass('fb-intel-ad')
        .attr("data-fb-intel-triaged", "sponsored");

    $("div#sparkles-container:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "feed")
        .addClass('fb-intel-ad');

    // //banner ads
    $("div#root-container:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "feed")
        .addClass('fb-intel-ad');

    //display ads
    $("#root:not([data-fb-intel-triaged])")
        .attr("data-fb-intel-triaged", "no")
        .attr("data-fb-ad", "yes")
        .attr("data-fb-intel-ad-type", "display-feed")
        .addClass('fb-intel-ad');
}

function triageItems() {
    // debugger;
    const startTime = Date.now();
    if (sponsoredClass) {
        $("div.fb-intel-ad[data-fb-intel-triaged='no'], div.fb-intel-ad[data-fb-intel-triaged='not-sponsored']").each(function () {
            const sponsoredLinkCount = $(this).find(sponsoredClass).length
            const hiddensponsoredLinkCount = $(this).find(hiddensponsoredClass).length;
            const middlesponsoredLinkCount = $(this).find(middlesponsoredClass).length;
            //console.log("Length",sponsoredLinkCount,hiddensponsoredLinkCount,middlesponsoredLinkCount);
            if (middlesponsoredLinkCount) {
                $(this).attr("data-fb-intel-triaged", "sponsored");
                $(this).attr("data-fb-intel-ad-type", "middle");
            }
            if (!sponsoredLinkCount && !middlesponsoredLinkCount) {
                $(this).attr("data-fb-intel-triaged", "not-sponsored");
                //const winLoc = window.location.href;
            }
            if (sponsoredLinkCount && !hiddensponsoredLinkCount && !middlesponsoredLinkCount) {
                $(this).attr("data-fb-intel-triaged", "sponsored");
            }

            if ($(this).find('.badge').length > 0) {
                var bannerAd = $(this).find('.badge').text().trim();
                if (bannerAd.includes(bannersponsoredClass)) {
                    $(this).attr("data-fb-intel-triaged", "sponsored");
                }
            }

            var foundAd = false;

            for (let index = 0; index < adClasses.length; index++) {
                const adClass = adClasses[index];
                if ($(this).attr('class').includes(adClass) && !foundAd) {
                    foundAd = true;
                }
            }

            if (foundAd) {
                $(this).attr("data-fb-intel-triaged", "sponsored");
            }

        });

        $("ytd-search-pyv-renderer.fb-intel-ad[data-fb-intel-triaged='no'], div.fb-intel-ad[data-fb-intel-triaged='not-sponsored']").each(function () {
            // debugger;
            if ($(this)[0].tagName === 'YTD-SEARCH-PYV-RENDERER') {
                $(this).attr("data-fb-intel-triaged", "sponsored");
            }
            else {
                $(this).attr("data-fb-intel-triaged", "not-sponsored");
            }
        });


    }
    const delta = Date.now() - startTime;
    // chrome.runtime.sendMessage(null, {"triageTime": delta});
}


function extractDataFromItems() {
    // debugger;
    const startTime = Date.now();
    $("div.fb-intel-ad[data-fb-intel-triaged='sponsored']:not([data-fb-intel-parsed])").each(function () {
        let allFound = true;
        let debugPanel = "";

        let attempts = $(this).attr("data-fb-intel-attempts");
        if (!attempts) {
            attempts = "1";
        } else {
            attempts = parseInt(attempts) + 1;
            if (attempts > 12) {
                $(this).attr("data-fb-intel-parsed", "incomplete");
            }
        }
        //if(attempts=="1")
        //{
        //    clear_check_For_New_Feed_ads();
        //    clear_check_For_New_Side_ads();
        //}
        $(this).attr("data-fb-intel-attempts", attempts);
        debugPanel += `<p>attempts: ${attempts}</p>`;
        for (const [key, value] of Object.entries(requiredData)) {
            let attrValue = $(this).attr(value.attribute);
            if (attrValue === null || attrValue === undefined) {
                attrValue = value.method.apply(null, $(this));
            }
            if (attrValue !== null && attrValue !== undefined) {
                $(this).attr(value.attribute, `${attrValue}`);
                debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
                //console.log(debugPanel)
            } else {
                debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
                allFound = false;
            }
        }
        if (allFound) {
            $(this).attr("data-fb-intel-parsed", "complete"); // this means ad can be written
        }
        //if (debugParsing || $("html").attr('fb-intel-debug')) {
        if ($(this).find("div.fb-intel-debug").length === 0) {
            $(this).append($('<div class="fb-intel-debug" style="display:none"></div>'));
        }
        debugPanel += `<p>sponsoredClass: ${sponsoredClass}</p>`;
        //console.log(debugPanel);
        $(this).find("div.fb-intel-debug").first().html(debugPanel);
        //}
    });
    //const delta = Date.now() - startTime;
    //chrome.runtime.sendMessage(null, {"extractTime": delta});

    $("ytd-search-pyv-renderer.fb-intel-ad[data-fb-intel-triaged='sponsored']:not([data-fb-intel-parsed])").each(function () {
        let allFound = true;
        let debugPanel = "";

        let attempts = $(this).attr("data-fb-intel-attempts");
        if (!attempts) {
            attempts = "1";
        } else {
            attempts = parseInt(attempts) + 1;
            if (attempts > 8) {
                $(this).attr("data-fb-intel-parsed", "incomplete");
            }
        }
        //if(attempts=="1")
        //{
        //    clear_check_For_New_Feed_ads();
        //    clear_check_For_New_Side_ads();
        //}
        $(this).attr("data-fb-intel-attempts", attempts);
        debugPanel += `<p>attempts: ${attempts}</p>`;
        for (const [key, value] of Object.entries(requiredData)) {
            let attrValue = $(this).attr(value.attribute);
            if (attrValue === null || attrValue === undefined) {
                attrValue = value.method.apply(null, $(this));
            }
            if (attrValue !== null && attrValue !== undefined) {
                $(this).attr(value.attribute, `${attrValue}`);
                debugPanel += `<p><strong>${key}:</strong> ${attrValue}</p>`;
            } else {
                debugPanel += `<p><strong>${key}:</strong> <span class="missing"> not found</span></p>`;
                allFound = false;
            }
        }
        if (allFound) {
            $(this).attr("data-fb-intel-parsed", "complete"); // this means ad can be written
        }
        //if (debugParsing || $("html").attr('fb-intel-debug')) {
        if ($(this).find("div.fb-intel-debug").length === 0) {
            $(this).append($('<div class="fb-intel-debug" style="display:none"></div>'));
        }
        debugPanel += `<p>sponsoredClass: ${sponsoredClass}</p>`;
        //console.log(debugPanel);
        $(this).find("div.fb-intel-debug").first().html(debugPanel);
        //}
    });

}

function saveSponsoredAds() {

    $("div.fb-intel-ad[data-fb-intel-parsed='complete']:not([data-fb-intel-saved])").each(function () {
        const adRoot = this;
        let thisAdData = Object.assign({}, adData);
        for (const [key, value] of Object.entries(requiredData)) {
            thisAdData[key] = $(adRoot).attr(value.attribute) || "";
            if (thisAdData[key] === null) {
            }
        }

        const postData = JSON.stringify(thisAdData);
        const settings = {
            "async": true,
            "crossDomain": true,
            "url": powerAdSpyYTApi + "ytAdsData",
            "method": "POST",
            "headers": {
                "content-type": "application/json",
                "cache-control": "no-cache"
            },
            "processData": false,
            "data": postData
        };
        $(adRoot).attr("data-fb-intel-triaged", "complete");
        $(adRoot).attr("data-fb-intel-saved", "pending");

        // debugger;
        $.ajax(settings).done(function (response) {
            $(adRoot).attr("data-fb-intel-saved", "success");
        }).fail(function () {
            $(adRoot).attr("data-fb-intel-saved", "failed");
        });
    });



    $("ytd-search-pyv-renderer.fb-intel-ad[data-fb-intel-parsed='complete']:not([data-fb-intel-saved])").each(function () {
        const adRoot = this;
        let thisAdData = Object.assign({}, adData);
        for (const [key, value] of Object.entries(requiredData)) {
            thisAdData[key] = $(adRoot).attr(value.attribute) || "";
            if (thisAdData[key] === null) {
            }
        }
        const postData = JSON.stringify(thisAdData);
        const settings = {
            "async": true,
            "crossDomain": true,
            "url": powerAdSpyYTApi + "ytAdsData",
            "method": "POST",
            "headers": {
                "content-type": "application/json",
                "cache-control": "no-cache"
            },
            "processData": false,
            "data": postData
        };
        $(adRoot).attr("data-fb-intel-triaged", "complete");
        $(adRoot).attr("data-fb-intel-saved", "pending");
        $.ajax(settings).done(function (response) {
            $(adRoot).attr("data-fb-intel-saved", "success");
        }).fail(function () {
            $(adRoot).attr("data-fb-intel-saved", "failed");
        });
    });
}


function removeallfeedouterattr() {

    var element = document.getElementById("player-container");
    if (element) {
        element = element.outerHTML;
        for (var i = $(element)[0].attributes.length - 1; i >= 0; i--) {
            if ($(element)[0].attributes[i].name != "id") {
                if ($(element)[0].attributes[i].name != "role") {
                    if ($(element)[0].attributes[i].name != "class") {
                        $(element)[0].removeAttribute(element.attributes[i].name);
                    }
                    else if ($(element)[0].attributes[i].name == "class") {
                        $(element).removeClass("fb-intel-ad");
                    }
                }

            }
        }
    }

}
function removeallsideouterattr() {
    var element = document.getElementById("player-ads");
    if (element) {
        element = element.outerHTML;
        for (var i = $(element)[0].attributes.length - 1; i >= 0; i--) {
            if ($(element)[0].attributes[i].name != "id") {
                if ($(element)[0].attributes[i].name != "role") {
                    if ($(element)[0].attributes[i].name != "class") {
                        $(element)[0].removeAttribute(element.attributes[i].name);
                    }
                    else if ($(element)[0].attributes[i].name == "class") {
                        $(element).removeClass("fb-intel-ad");
                    }
                }

            }
        }
    }

}

function removeallfeedattr() {
    var element = document.getElementById("player-container");
    if (element) {
        for (var i = element.attributes.length - 1; i >= 0; i--) {
            if (element.attributes[i].name != "id") {
                if (element.attributes[i].name != "role") {
                    if (element.attributes[i].name != "class") {
                        element.removeAttribute(element.attributes[i].name);
                    }
                    else if (element.attributes[i].name == "class") {
                        $(element).removeClass("fb-intel-ad");
                    }
                }

            }

        }
    }

}
function removeallsideattr() {
    var element = document.getElementById("player-ads");
    if (element) {
        for (var i = element.attributes.length - 1; i >= 0; i--) {
            if (element.attributes[i].name != "id") {
                if (element.attributes[i].name != "role") {
                    if (element.attributes[i].name != "class") {
                        element.removeAttribute(element.attributes[i].name);
                    }
                    else if (element.attributes[i].name == "class") {
                        $(element).removeClass("fb-intel-ad");
                    }
                }

            }
        }
    }
}

function hashCode(str) {
    return str.split('').reduce((prevHash, currVal) =>
        (((prevHash << 5) - prevHash) + currVal.charCodeAt(0)) | 0, 0);
}