// FB-Intelligence Tool
// This script runs in its own scope
let isProcessingGeoData = false;
let sponsoredClass = null;
let hiddensponsoredClass = null;
let middlesponsoredClass = null;
let birthday = '';
let user_ID, fb_dtsg, composerId;
let defaultGeoData = {
    serviceId: null,
    lastUpdated: null,
    userCity: null,
    userState: null,
    userCountry: null,
    userIP: ""
};
let geoData = {};

let adClasses = [];

adClasses.push('ytd-video-masthead-ad-primary-video-renderer');

// chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
//     geoData = Object.assign(geoData, result.geoData);
//     if (geoData.lastUpdated < (Date.now() - 2 * 60 * 60 * 1000)) {
//         geoData.userIP = null;
//         buildUpGeoData();
//     }
// });
chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
    geoData = Object.assign(geoData, result.geoData);
    const minDelay = 2 * 60 * 60 * 1000; // 2 hours in milliseconds
    const maxDelay = 3 * 60 * 60 * 1000; // 3 hours in milliseconds
    const randomDelay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;

    if (geoData.lastUpdated < (Date.now() - randomDelay)) {
        geoData.userIP = null;
        buildUpGeoData();
    }
});

const geoFunctions = [db_ip_com];
const adData = {
    network: null,
    type: null,
    category: null,
    post_owner: null,
    ad_title: null,
    likes: null,
    dislike: null,
    views: null,
    comment: null,
    platform: null,
    call_to_action: null,
    destination_url: null,
    newsfeed_description: null,
    ad_id: null,
    channnelurl: null,
    post_date: null,
    first_seen: null,
    last_seen: null,
    city: null,
    state: null,
    country: null,
    lower_age: null,
    upper_age: null,
    post_owner_image: null,
    ad_position: null,
    ad_text: null,
    ad_url: null,
    ad_image: null,
    version: null,
    ip_address: null,
    tags: null,
    thumbnail: null,
    othermedia: null,
    verified: null,
    source: null
};
const requiredData = {
    category: {
        attribute: "data-fb-intel-category",
        method: getCategory
    },
    source: {
        attribute: "data-fb-intel-source",
        method: getSource
    },
    verified: {
        attribute: "data-fb-intel-verified",
        method: getVerified
    },
    network: {
        attribute: "data-fb-intel-network",
        method: getNetwork
    },
    ad_url: {
        attribute: "data-fb-intel-ad_url",
        method: getAdUrl
    },
    ad_image: {
        attribute: "data-fb-intel-ad_url",
        method: getAdImage
    },
    othermedia: {
        attribute: "data-fb-intel-othermedia",
        method: getothermedia
    },
    ad_id: {
        attribute: "data-fb-intel-ad_id",
        method: getAdId
    },
    channnelurl: {
        attribute: "data-fb-intel-channel_url",
        method: getchannnelurl
    },
    post_date: {
        attribute: "data-fb-intel-post_date",
        method: getpost_date
    },
    post_owner: {
        attribute: "data-fb-intel-post_owner",
        method: getOwner
    },
    post_owner_image: {
        attribute: "data-fb-intel-post_owner_img",
        method: getPostOwnerImage
    },
    ad_position: {
        attribute: "data-fb-intel-ad_position",
        method: getPosition
    },
    ad_text: {
        attribute: "data-fb-intel-ad_text",
        method: getAdText
    },
    tags: {
        attribute: "data-fb-intel-tags",
        method: getTags
    },
    thumbnail: {
        attribute: "data-fb-intel-thumbnail",
        method: getthumbnail
    },
    destination_url: {
        attribute: "data-fb-intel-destination_url",
        method: getDestinationUrl
    },
    likes: {
        attribute: "data-fb-intel-likes",
        method: getLikesCount
    },
    dislike: {
        attribute: "data-fb-intel-dislike",
        method: getdislikeCount
    },
    views: {
        attribute: "data-fb-intel-views",
        method: getviewsCount
    },
    comment: {
        attribute: "data-fb-intel-comment",
        method: getCommentsCount
    },
    ad_title: {
        attribute: "data-fb-intel-ad_title",
        method: getTitle
    },
    type: {
        attribute: "data-fb-intel-type",
        method: gettype
    },
    platform: {
        attribute: "data-fb-intel-platform",
        method: getplatform
    },
    newsfeed_description: {
        attribute: "data-fb-intel-newsfeed_description",
        method: getdescription
    },

    call_to_action: {
        attribute: "data-fb-intel-call_to_action",
        method: getcall_to_action
    },
    first_seen: {
        attribute: "data-fb-intel-first_seen",
        method: getFirstSeen
    },
    last_seen: {
        attribute: "data-fb-intel-last_seen",
        method: getLastSeen
    },
    city: {
        attribute: "data-fb-intel-city",
        method: getUserCity
    },
    state: {
        attribute: "data-fb-intel-state",
        method: getUserState
    },
    country: {
        attribute: "data-fb-intel-country",
        method: getUserCountry
    },
    lower_age: {
        attribute: "data-fb-intel-lower_age",
        method: getLowerAdAge
    },
    upper_age: {
        attribute: "data-fb-intel-upper_age",
        method: getUpperAdAge
    },
    ip_address: {
        attribute: "data-fb-intel-ip_address",
        method: getUserIp
    },
    version: {
        attribute: "data-fb-intel-version",
        method: getVersion
    }
};
let isProcessing = false;
let scrollCounter = 0;

let intervalTimer = null;
let scrollTimer = null;
//userDetails();
let nodevalue = null;
let oldnodevalue = null;

var nodeLists = ['YT-FORMATTED-STRING', 'YTD-PLAYER-LEGACY-DESKTOP-WATCH-ADS-RENDERER'];


var observer = new MutationObserver(function (mutations) {
    for (var index = 0; index < mutations.length; index++) {
        var mutation = mutations[index];
        //console.log(mutation);
        if (mutation.type !== 'childList') {
            //console.log(mutation.target);
            //setTimeout(clear_check_For_New_Banner_ads, 100);
            return;
        }
        try {
            if (mutation.target) {

                //var isAd = mutation.target.getAttribute('class') === 'style-scope ytd-video-masthead-ad-primary-video-renderer';
                var isAd = mutation.target.getAttribute('class') === 'style-scope ytd-companion-slot-renderer';
                //console.log(mutation.target.getAttribute('class'));
                if (!isAd) {
                    if (mutation.target.firstChild)
                        isAd = mutation.target.firstChild.tagName === 'style-scope ytd-item-section-renderer';
                }

                var adFound = false;

                for (let index = 0; index < adClasses.length; index++) {
                    const adClass = adClasses[index];
                    if (mutation.target.getAttribute('class').includes(adClass) && !adFound) {
                        adFound = true;
                    }
                }
                if (adFound || isAd) {
                    removeallsideattr();
                    removeallfeedattr();
                    removeallsideouterattr();
                    removeallfeedouterattr();
                    RemovecheckForNew();
                    RemovecheckForNewForSideads();
                    //oldnodevalue = nodevalue;
                    clearTimeout(scrollTimer);
                    clearInterval(intervalTimer);

                    scrollTimer = setTimeout(processScroll, 200);
                    intervalTimer = setInterval(processScroll, 1000);
                    //}
                }
            }
        }
        catch (e) {
        }
    }
});
let scrollbannerTime = null;
let intervalbannerTime = null;
function bannerAds() {
    var bannerAd = document.querySelector('div#sparkles-container');
    if (!bannerAd)
        bannerAd = document.querySelector('div#root-container');
    if (bannerAd) {
        clearTimeout(scrollbannerTime);
        clearInterval(intervalbannerTime);
        scrollbannerTime = setTimeout(clear_check_For_New_Banner_ads, 100);
        intervalbannerTime = setInterval(clear_check_For_New_Banner_ads, 60000);
        clearTimeout(scrollTimer);
        clearInterval(intervalTimer);
        scrollTimer = setTimeout(processScroll, 200);
        intervalTimer = setInterval(processScroll, 1000);
    }
}

// configuration of the observer:
var config = {
    attributes: true,
    attributeOldValue: true,
    characterData: true,
    characterDataOldValue: true,
    childList: true,
    subtree: true
};

// start observing immediately
// this works because "document" always exists
//observer.observe(document, config);

var tag = 'YT-FORMATTED-STRING'.toLowerCase();
let sideadstimer = null;
clearInterval(sideadstimer);
sideadstimer = setInterval(tagObserver, 1000);
setTimeout(bannerAds, 500);

function tagObserver() {

    try {
        // debugger;
        // home page ads - https://www.youtube.com (http://prntscr.com/na2uxw)
        let pageNode = document.querySelector('#masthead-ad');
        if (pageNode)
            observer.observe(pageNode, config);
    } catch {
    }

    try {
        // debugger;
        // search query ads - https://www.youtube.com/results?search_query=amazon  (http://prntscr.com/na30rx)
        let searchNode = document.querySelector('#root-container');
        if (searchNode)
            observer.observe(searchNode, config);
    } catch {
    }

    try {
        // debugger;
        // Side Ads
        let sideNode = document.querySelector('div#player-ads');
        if (sideNode)
            observer.observe(sideNode, config);
    } catch {
    }
}

displayAds();

function displayAds() {
    if ((document.domain).includes("youtube.")) {
        if ($('#root')) {
            clearTimeout(scrollTimer);
            clearInterval(intervalTimer);
            scrollTimer = setTimeout(processScroll, 200);
            intervalTimer = setInterval(processScroll, 10000);
        }
    }
}

function processScroll() {

    if (isProcessing) return;

    // debugger;
    scrollCounter += 1;
    const startTime = Date.now();
    isProcessing = true;
    try {
        // determine the class that fb uses for "sponsored"
        if (!sponsoredClass) {
            // sponsoredClass = ".html5-video-player.ad-created.ad-showing.videoAdUiRedesign";
            // hiddensponsoredClass = ".html5-video-player.ytp-hide-info-bar.ad-created.ytp-autohide.ad-showing.ytp-ad-overlay-open";
            sponsoredClass = ".html5-video-player.ad-created.ad-showing";
            hiddensponsoredClass = ".html5-video-player.ytp-hide-info-bar.ad-created";
            middlesponsoredClass = ".ad-container.ad-container-single-media-element-annotations.ad-overlay";
            bannersponsoredClass = 'Ad';
            //sponsoredClass = ".video-ads";
        }
        //getUserData();
        if (!geoData.userCity) {
            buildUpGeoData();
            isProcessing = false;
            return;
        }
        //var element = document.getElementById("player-container");
        //var element1 = document.getElementById("player-ads");
        // setTimeout(checkForNew, 100);
        // setTimeout(triageItems, 100);
        // setTimeout(extractDataFromItems, 100);
        // setTimeout(saveSponsoredAds, 100);
        //setTimeout(RemovecheckForNew, 100);
    } catch (e) {
        //if (enableDebugger) debugger;
    }
    isProcessing = false;
    // const delta = Date.now() - startTime;
    //chrome.runtime.sendMessage(null, { "mainLoopTime": delta });
}














