// To handle xhr response
async function handleXhrIntercepted(event) {
  try {
    const { res } = event.detail;
    //First side ad object identification
    // console.log(res);
    let adPlacement = res?.adPlacements || res?.playerAds;
    // console.log(adPlacement);
    if (adPlacement && Array.isArray(adPlacement)) {
      //Filtering unique ads(Eliminating duplicate ads)
      const uniqueArray = adPlacement.filter((obj, index, self) => {
        if (
          obj.adPlacementRenderer?.renderer?.hasOwnProperty(
            "actionCompanionAdRenderer"
          )
        ) {
          return (
            index ===
            self.findIndex(
              (t) =>
                t?.adPlacementRenderer?.renderer?.actionCompanionAdRenderer
                  ?.adVideoId ===
                obj.adPlacementRenderer?.renderer?.actionCompanionAdRenderer
                  ?.adVideoId
            )
          );
        }
        if (
          obj.adPlacementRenderer?.renderer?.hasOwnProperty(
            "topBannerImageTextIconButtonedLayoutViewModel"
          )
        ) {
          sideAds1(obj);
        }
      });

      // Sending unique ads to function sideAds1 for data extraction
      if (uniqueArray.length > 0) {
        uniqueArray.forEach((element) => {
          if (
            element.adPlacementRenderer?.renderer?.actionCompanionAdRenderer
              ?.adBadge?.metadataBadgeRenderer?.label === "Sponsored"
          )
            sideAds1(element);
        });
      }
    }
    displayAds(res);
  } catch (error) {}
}

// Listening the fired event
document.addEventListener("YT_XHR", handleXhrIntercepted);

// Data extraction of 1st side ads(Image ads)
async function sideAds1(Ad) {
  // console.log(Ad);
  try {
    Ad =
      Ad.adPlacementRenderer.renderer.actionCompanionAdRenderer ||
      Ad.adPlacementRenderer.renderer
        .topBannerImageTextIconButtonedLayoutViewModel;
    // console.log(Ad);
    let ytAdsData = {};
    ytAdsData["call_to_action"] =
      Ad?.actionButton?.buttonRenderer?.text?.simpleText ||
      Ad.adButton.adButtonViewModel.label.content ||
      "";
    ytAdsData["ad_image"] =
      Ad?.bannerImage?.thumbnail?.thumbnails[0]?.url ||
      Ad.adImage.adImageViewModel.imageSources[0].url ||
      "";
    ytAdsData["post_owner_image"] =
      Ad?.iconImage?.thumbnail?.thumbnails[0]?.url ||
      Ad.adAvatarLockup.adAvatarLockupViewModel.adAvatar.adAvatarViewModel.image
        .sources[0].url ||
      "";
    ytAdsData["ad_title"] =
      Ad?.headline?.text ||
      Ad.adAvatarLockup.adAvatarLockupViewModel.headline.content ||
      "";
    ytAdsData["destination_url"] =
      Ad?.navigationEndpoint?.urlEndpoint?.url ||
      Ad.adButton.adButtonViewModel.interaction.onTap.innertubeCommand
        .urlEndpoint.url ||
      "";
    ytAdsData["newsfeed_description"] =
      Ad?.description?.text ||
      Ad.adAvatarLockup.adAvatarLockupViewModel.primaryDetailsLine
        .adDetailsLineViewModel.attributes[0].text.content ||
      "";
    ytAdsData["channnelurl"] = "";
    let owner = JSON.parse(await GetPostOwner(ytAdsData.destination_url));
    ytAdsData["post_owner"] = owner.post_owner;
    ytAdsData["destination_url"] = owner.final_url;
    ytAdsData["ad_id"] = hashCode(ytAdsData.ad_image).toString();
    ytAdsData["ad_text"] = "";
    ytAdsData["ad_url"] = ytAdsData.ad_image;
    ytAdsData["ad_position"] = "SIDE";
    ytAdsData["type"] = "IMAGE";
    ytAdsData["thumbnail"] = "";
    sendPost1(commonProperties(ytAdsData));
    // console.log(commonProperties(ytAdsData));
    document.dispatchEvent(
      new CustomEvent("YT_Playing_Ad", {
        detail: {
          title: ytAdsData.ad_title,
          body: ytAdsData.newsfeed_description,
          raw_cta_url: ytAdsData.destination_url,
          raw_creative_url: "",
          video_id: Ad?.adVideoId,
          cta_type: ytAdsData.call_to_action,
          type: "",
        },
      })
    );
  } catch (error) {}
}

// Data extraction of 2nd side ad(Display ad)
async function sideAds2(Ad) {
  try {
    Ad =
      Ad?.adSlotRenderer?.fulfillmentContent?.fulfilledLayout
        ?.inFeedAdLayoutRenderer?.renderingContent
        ?.promotedSparklesWebRenderer ||
      Ad?.itemSectionRenderer?.contents[0]?.adSlotRenderer?.fulfillmentContent
        ?.fulfilledLayout?.inFeedAdLayoutRenderer?.renderingContent
        ?.promotedSparklesWebRenderer;
    // console.log(Ad);
    if (Ad) {
      let ytAdsData = {};
      ytAdsData["call_to_action"] =
        Ad?.actionButton?.buttonRenderer?.text?.simpleText || "";
      ytAdsData["ad_image"] = Ad?.thumbnail?.thumbnails[0]?.url || "";
      ytAdsData["post_owner_image"] = "";
      ytAdsData["ad_title"] = Ad?.title?.simpleText || "";
      ytAdsData["destination_url"] =
        Ad?.navigationEndpoint?.urlEndpoint?.url || "";
      ytAdsData["newsfeed_description"] = Ad?.description?.simpleText || "";
      ytAdsData["channnelurl"] = "";
      let owner = JSON.parse(await GetPostOwner(ytAdsData.destination_url));
      ytAdsData["post_owner"] = owner.post_owner;
      ytAdsData["destination_url"] = owner.final_url;
      ytAdsData["ad_id"] = hashCode(ytAdsData.ad_title).toString();
      ytAdsData["ad_text"] = Ad?.websiteText?.simpleText;
      ytAdsData["ad_url"] = "";
      ytAdsData["ad_position"] = "SIDE";
      ytAdsData["type"] = "DISPLAY";
      ytAdsData["thumbnail"] = ytAdsData.ad_image;
      sendPost1(commonProperties(ytAdsData));
      // console.log(commonProperties(ytAdsData));
    }
  } catch (error) {}
}

// For home feed first ad(Display Ad)
async function homeFeedAd(Ad) {
  try {
    let ytAdsData = {};
    ytAdsData["call_to_action"] =
      Ad?.ctaButton?.buttonRenderer?.text?.simpleText ||
      Ad?.adCtaButton?.buttonRenderer?.text?.simpleText ||
      "";
    ytAdsData["ad_image"] =
      Ad?.image?.thumbnail?.thumbnails[3]?.url ||
      "https://www.youtube.com/watch?v=" + Ad?.videoId ||
      "";
    ytAdsData["post_owner_image"] = "";
    ytAdsData["ad_title"] =
      Ad?.titleText?.simpleText ||
      Ad?.title?.simpleText ||
      Ad?.title?.runs[0]?.text ||
      "";
    ytAdsData["destination_url"] =
      Ad?.clickCommand?.urlEndpoint?.url ||
      Ad?.adCtaButton?.buttonRenderer?.command?.urlEndpoint?.url ||
      Ad?.navigationEndpoint?.loggingUrls[0]?.baseUrl ||
      "";
    ytAdsData["channnelurl"] = "";
    ytAdsData["ad_id"] = Ad?.videoId || hashCode(ytAdsData.ad_title).toString();
    ytAdsData["ad_text"] =
      Ad?.secondaryText?.simpleText || Ad?.shortBylineText?.runs[0]?.text;
    ytAdsData["newsfeed_description"] =
      Ad?.bodyText?.simpleText || ytAdsData.ad_text || "";
    let owner = JSON.parse(await GetPostOwner(ytAdsData.destination_url));
    ytAdsData["post_owner"] = owner.post_owner;
    ytAdsData["destination_url"] = owner.final_url;
    ytAdsData["ad_url"] = "";
    ytAdsData["ad_position"] = "FEED";
    ytAdsData["type"] = "DISPLAY";
    ytAdsData["thumbnail"] = ytAdsData.ad_image;
    sendPost1(commonProperties(ytAdsData));
    // console.log(commonProperties(ytAdsData));
  } catch (error) {}
}

// First ad identification from page sourece
function firstAd() {
  let res = document.documentElement.outerHTML;
  let response = JSON.parse(
    getBetween(res, "var ytInitialData = ", ";</script>")
  );
  if (response) displayAds(response);
}
setTimeout(firstAd, 3000);

// Display ads
function displayAds(response) {
  try {
    // For home feed 1st display ad
    response?.contents?.twoColumnBrowseResultsRenderer?.tabs[0]?.tabRenderer?.content.richGridRenderer.contents.forEach(
      (Ad) => {
        Ad =
          Ad?.richItemRenderer?.content?.adSlotRenderer?.fulfillmentContent
            ?.fulfilledLayout?.inFeedAdLayoutRenderer?.renderingContent;
        Ad = Ad?.displayAdRenderer || Ad?.videoDisplayFullButtonedRenderer;
        if (Ad && Ad?.badge?.metadataBadgeRenderer?.label === "Sponsored") {
          homeFeedAd(Ad);
        }
      }
    );
    // For Side display ads
    let contents1 =
      response?.contents?.twoColumnWatchNextResults?.secondaryResults;
    if (contents1) {
      contents1.secondaryResults.results.forEach((element) => {
        if (
          element?.adSlotRenderer?.fulfillmentContent?.fulfilledLayout
            ?.inFeedAdLayoutRenderer?.renderingContent
            ?.promotedSparklesWebRenderer?.adBadge?.metadataBadgeRenderer
            ?.label === "Sponsored"
        ) {
          sideAds2(element);
        }
        if (
          element?.itemSectionRenderer?.contents[0]?.adSlotRenderer
            ?.fulfillmentContent?.fulfilledLayout?.inFeedAdLayoutRenderer
            ?.renderingContent?.promotedSparklesWebRenderer?.adBadge
            ?.metadataBadgeRenderer?.label === "Sponsored"
        ) {
          sideAds2(element);
        }
      });
    }
    // For home feed display ads (Not first ad)
    let contents2 =
      response?.onResponseReceivedActions[0]?.appendContinuationItemsAction
        ?.continuationItems;
    if (contents2) {
      contents2.forEach((element) => {
        if (
          element?.richItemRenderer?.content?.adSlotRenderer?.fulfillmentContent
            ?.fulfilledLayout?.inFeedAdLayoutRenderer?.renderingContent
            ?.displayAdRenderer?.badge?.metadataBadgeRenderer?.label ===
          "Sponsored"
        ) {
          homeFeedAd(
            element?.richItemRenderer?.content?.adSlotRenderer
              ?.fulfillmentContent?.fulfilledLayout?.inFeedAdLayoutRenderer
              ?.renderingContent?.displayAdRenderer
          );
        }
      });
    }
  } catch (error) {}
}
//Common properties
function commonProperties(obj) {
  obj["network"] = "YouTube";
  obj["category"] = "";
  obj["likes"] = "0";
  obj["dislike"] = "0";
  obj["views"] = "0";
  obj["comment"] = "0";
  obj["platform"] = "3";
  obj["lower_age"] = "18";
  obj["upper_age"] = "65";
  obj["tags"] = "";
  obj["othermedia"] = "";
  obj["verified"] = "0";
  obj["source"] = "Desktop";
  obj["post_date"] = getCurrentTime().toString();
  obj["first_seen"] = obj["post_date"];
  obj["last_seen"] = obj["post_date"];
  obj["ip_address"] = getUserIp();
  obj["city"] = getUserCity();
  obj["state"] = getUserState();
  obj["country"] = getUserCountry();
  obj["version"] = getVersion();
  return obj;
}

async function sendPost1(post) {
  try {
    const response = await fetch(`${powerAdSpyYTApi}ytAdsData`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(post),
    });
  } catch (error) {}
}
document.addEventListener("ADS", async function (event) {
  let ad1 = event?.detail?.ytAdResult;
  let ad2 = event?.detail?.ytImageAdResult;
  if (ad1) sendPost1(ad1);
  if (ad2) sendPost1(ad2);
});
