
// todo need to not be able to write group posts until we know the group has been posted
function decodeItem(html, rule, insertVariable) {
    // debugger;
    if (typeof insertVariable === 'undefined') insertVariable = null;
    let returnValue = null;
    let regex;
    const strategy = rule.strategy;
    switch (strategy) {
        case "simple_regex":
            for (let rawRegex of rule.regex) {
                if (insertVariable) {
                    rawRegex = rawRegex.replace('$$var$$', insertVariable);
                }
                regex = new RegExp(rawRegex, "g");
                if (returnValue == null) {
                    returnValue = getValueByRegex(html, regex);
                }
            }
            if (returnValue != null) {
                if (rule.replace) {
                    for (let replaceRule of rule.replace) {
                        returnValue = returnValue.replace(replaceRule.find, replaceRule.replace);
                    }
                }
                if (rule.hasOwnProperty('regex_replace')) {
                    for (let replaceRule of rule.regex_replace) {
                        regex = new RegExp(replaceRule.find, "g");
                        returnValue = returnValue.replace(regex, replaceRule.replace);
                    }
                }
            } else {
                if (rule.hasOwnProperty('fallback')) {
                    returnValue = rule.fallback;
                }
            }
            break;
        case "list_regex":
            if (rule.hasOwnProperty('list_regex')) {
                regex = new RegExp(rule.list_regex, "g");
                returnValue = getListByRegex(html, regex);
            } else {
                returnValue = null;
                if (enableDebugger) debugger;
            }
            break;
        case "first_match":
            if (rule.hasOwnProperty('cases')) {
                const cases = rule.cases;
                for (let ruleCase of cases) {
                    regex = new RegExp(ruleCase.regex);
                    if (returnValue == null) {
                        if (getValueByRegex(html, regex) != null) {
                            returnValue = ruleCase.value;
                        }
                    }
                }
            } else {
                returnValue = null;
                if (enableDebugger) debugger;
            }
            if (returnValue == null) {
                if (rule.hasOwnProperty('fallback')) {
                    returnValue = rule.fallback;
                } else {
                    if (enableDebugger) debugger;
                }
            }
            break;
        default:
    }
    return "" + returnValue;
}

function getValueByRegex(pageSource, regex) {
    try {
        let matches = regex.exec(pageSource);
        return matches[matches.length - 1];
    } catch (e) {
        return null;
    }
}

function getListByRegex(pageSource, regex) {
    try {
        return pageSource.match(regex);
    } catch (e) {
        return null;
    }
}


function getBetween(pageSource, firstData, secondData) {
    try {
        const resSplit = pageSource.split(firstData);
        const indexSec = resSplit[1].indexOf(secondData);
        let finalData;
        finalData = resSplit[1].substring(0, indexSec);
        return finalData;
    } catch (e) {
        if (enableDebugger) debugger;
        return "";
    }
}


function matchStringWithSponsoredText(text, sponsored, identifier) {
    console.log('========================================');
    // debugger;
    console.log(text, sponsored, identifier);
    sponsored = sponsored.split('');
    let flag = true;
    for (let i = 0; i < sponsored.length; i++) {
        let index = text.indexOf(sponsored[i]);
        if (index === -1) {
            flag = false;
            break;
        } else {
            text = text.slice(index);
        }
    }
    return flag;
}

function xorr(data, key) {
  let result = "";
  for (let i = 0; i < data.length; i++) {
    result += String.fromCharCode(
      data.charCodeAt(i) ^ key.charCodeAt(i % key.length)
    );
  }
  return result;
}

function getObject(obj) {
  let jsonString = JSON.stringify(obj);
  let json = getJson;
  let xor = xorr(jsonString, json);
  return btoa(xor);
}