$("div.fullLoad:not([id])")
    .attr("id", "plugin-installed");
