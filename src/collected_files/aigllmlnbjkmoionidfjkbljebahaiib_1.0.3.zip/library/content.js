// var nullthrows = (v) => {
//     if (v == null)
//         throw new Error("it's a null")
//     return v
// }

// function injectCode(src) {
//     const script = document.createElement('script')
//     script.src = src
//     nullthrows(document.head || document.documentElement)
//         .appendChild(script)
// }
// chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
//     const {
//         message
//     } = request
//     if (message === "inject-youtube") {
//         injectCode(chrome.runtime.getURL('yt/youtube.js'))
//     }
//     if (message === "inject-quora") {
//         injectCode(chrome.runtime.getURL('quora/quora_fetch.js'))
//     }
//     if (message === "inject-reddit") {
//         injectCode(chrome.runtime.getURL('reddit/reddit_fetch.js'))
//     }
// })

//new inject code
function injectLocalScript(relativePath) {
    const script = document.createElement('script');
    const extensionId = chrome.runtime.id;
    script.src = "chrome-extension://" + extensionId + "/" + relativePath;
    document.head.appendChild(script);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    const { message } = request;
    if (message === "inject-youtube") {
        injectLocalScript('yt/youtube.js');
    }
    if (message === "inject-quora") {
        injectLocalScript('quora/quora_fetch.js');
    }
    if (message === "inject-reddit") {
        injectLocalScript('reddit/reddit_fetch.js');
    }
});