let rules_facebook = {
    userInfo: {
        user_id: {
            item: "user_id",
            strategy: "simple_regex",
            regex: [
                'USER_ID":"(.+?)(?=")',
                'ACCOUNT_ID":"(.+?)(?=")'
            ],
            replace: [],
            comments: "Its works for facebook main page"
        },
        user_name: {
            item: "user_name",
            strategy: "simple_regex",
            regex: [
                'NAME":"(.+?)(?=")',
                'profileName:"(.+?)(?=")'
            ],
            replace: [],
            comments: "Its works for facebook main page"
        },
        fb_dtsg: {
            item: "fb_dtsg",
            strategy: "simple_regex",
            regex: [
                'fb_dtsg"\\svalue="(.+?)(?=")',
            ],
            replace: [],
            comments: "Its works for facebook main page"
        },
        composer_id: {
            item: "composer_id",
            strategy: "simple_regex",
            regex: [
                'composerID":"(.+?)(?=")',
                'composerID:"(.+?)(?=")',
                'xhpc_composerid"\\svalue="(.+?)(?=")'
            ],
            replace: [],
            comments: "Its works for facebook main page"
        },
        user_email: {
            item: "user_email",
            strategy: "simple_regex",
            regex: [
                'Primary: <strong>(.+?)(?=<)'
            ],
            replace: [
                {
                    find: "&#064;",
                    replace: "@"
                }
            ]
        }
    },
    posts: {
        likes: {
            item: "postLikes",
            strategy: "simple_regex",
            regex: [
                'UFI2ReactionsCount\/root[^>]*>(.+?)(?=<\/span>)',
                'UFI2ReactionsCount\\/root[^>]*>(.+?)(?=<\\/span>)'
            ],
            replace: []
        },
        comments: {
            item: "postComments",
            strategy: "simple_regex",
            regex: [
                'comment_tracking[^>]*>(.+?)(?=<\/a>)',
                'comment_tracking[^>]*>(.+?)(?=<\\/a>)',
                'UFI2CommentsCount\/root[^>]*>(.+?)(?=<\/a>)'
            ],
            replace: []
        },
        shares: {
            item: "postShares",
            strategy: "simple_regex",
            regex: [
                'shares\/view[^>]*>(.+?)(?=<\/a>)',
                'shares\\/view[^>]*>(.+?)(?=<\\/a>)'
            ],
            replace: []
        },
        postOwnerImage: {
            item: "postOwnderImage",
            strategy: "simple_regex",
            regex: [
                '_5xib((?!src).)*src="(.+?)(?=")',
            ],
            replace: []
        }
    }
};