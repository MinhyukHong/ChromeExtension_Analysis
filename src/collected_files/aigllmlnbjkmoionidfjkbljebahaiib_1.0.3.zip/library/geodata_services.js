
function ipinfo_io(ip) {
    try {
        $.ajax({
            url: "//freegeoip.net/json/?callback=?",
            async: true,
            success: function (data) {
                try {
                    // if (enableDebugger) debugger;
                    data = data.replace("?(", "");
                    data = data.replace(");", "");
                    data = JSON.parse(data);
                    /** @namespace data.city */
                    /** @namespace data.region_name */
                    /** @namespace data.country_name */
                    geoData.userCity = geoData.userCity || data.city;
                    geoData.userState = geoData.userState || data.region_name;
                    geoData.userCountry = geoData.userCountry || data.country_name;
                    geoData.lastUpdated = Date.now();
                    chrome.storage.local.set({ "geoData": geoData });
                    // userIP = geoData.userIP;
                    // userCity = geoData.userCity;
                    // userState = geoData.userState;
                    // userCountry = geoData.userCountry;
                } catch (e) {

                }
            }
        });
    } catch (e) {

    }
}

function db_ip_com(ip) {
 
    // // debugger;
    // //const url = "https://api.db-ip.com/v2/eb79c26170d0e9921e5b8372b2e212f86afa399c/" + ip;
    // const url = "https://plugin.poweradspy.com/";

    // // if (enableDebugger) debugger;
    // try {
    //     $.ajax({
    //         url: url,
    //         type: "POST",
    //         async: true,
    //         success: function (result) {
    //             try {
    //                 // debugger;
    //                 // if (enableDebugger) debugger;
    //                 /** @namespace result.city */
    //                 /** @namespace result.stateProv */
    //                 /** @namespace result.countryName */
    //                 geoData.userCity = geoData.userCity || result.city;
    //                 geoData.userState = geoData.userState || result.stateProv;
    //                 geoData.userCountry = geoData.userCountry || result.countryName;
    //                 geoData.lastUpdated = Date.now();
    //                 chrome.storage.local.set({ "geoData": geoData });
    //                 // userIP = geoData.userIP;
    //                 // userCity = geoData.userCity;
    //                 // userState = geoData.userState;
    //                 // userCountry = geoData.userCountry;
    //             } catch (e) {
    //                 debugger;
    //             }
    //         }
    //     });
    // } catch (e) {

    // }
}

