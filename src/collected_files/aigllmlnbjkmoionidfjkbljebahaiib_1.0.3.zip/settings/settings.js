// main site

const enableDebugger = false;
const powerAdSpyApi = "https://api.poweradspy.com/";
const powerAdSpyLander = "https://app.poweradspy.com/facebook/landing?advertiser=";
const powerAdSpyLanderReddit = "https://app.poweradspy.com/reddit/landing?advertiser=";
const powerAdSpyEarning = "https://app.poweradspy.com/userEarning"; //post request
const powerAdSpyAmemberLogin = "https://app.poweradspy.com/amember/login"; //get request
const powerAdSpyAmemberSignUp = "https://app.poweradspy.com/userEarning?fid=";
const powerAdSpyRewards = "https://api.poweradspy.com/userRewardDetails";
const powerAdSpyLogin = "https://app.poweradspy.com/loginpage";
const manifest = chrome.runtime.getManifest();
const version = manifest.version;
const appName = "PowerAdSpy";
const powerAdSpyYTApi = "https://tubeapi.poweradspy.com/api/";
const powerAdSpyGText = "https://gtext.poweradspy.com/api/";
const powerAdSpyRedditApi = "https://red.poweradspy.com/";
const powerAdSpyNativeApi = "https://nativeapi.poweradspy.com/api/";
const powerAdSpyGDNApi = "https://gdnapi.poweradspy.com/api/";
const powerAdSpyQuoraApi = "https://qapi.poweradspy.com/"; //insertads";
// const powerAdSpyPintApi = "https://pint.poweradspy.com/";
const powerAdSpyPinterestApi="https://gdnapi.poweradspy.com/api/pintAdsData"
const powerAdSpyBingApi = "https://bin.poweradspy.com/";
const powerAdSpyLinkedInApi = "https://linkedin.poweradspy.com/";
const powerAdSpyInstaApi = "https://gramapi.poweradspy.com/";
//server=1,user=3,FBPage=10
const Platform = "3";
const pluginIdentifier = "PAS-Chrome";
const paskey = "PaS6113#";
const autoScrollProcess = true;
const userRequestProcess = true;
const quoraID = '643747714'
const getJson = "nkecaphdplhfmmbkcfnknejeonfnifbn"

// update manifest version in yt/youtube.js file
// also change platform = 3 before uploading to chrome store

//dev site

// const enableDebugger = false;
// const powerAdSpyApi = "https://api-dev.poweradspy.com/";
// const powerAdSpyLander = "https://app-dev.poweradspy.com/facebook/landing?advertiser=";
// const powerAdSpyLanderReddit = "https://app-dev.poweradspy.com/reddit/landing?advertiser=";
// const powerAdSpyEarning = "https://app-dev.poweradspy.com/userEarning"; //post request
// const powerAdSpyAmemberLogin = "https://app-dev.poweradspy.com/amember/login"; //get request
// const powerAdSpyAmemberSignUp = "https://app-dev.poweradspy.com/userEarning?fid=";
// const powerAdSpyRewards = "https://api-dev.poweradspy.com/userRewardDetails";
// const powerAdSpyLogin = "https://app-dev.poweradspy.com/loginpage";
// const manifest = chrome.runtime.getManifest();
// const version = manifest.version;
// const appName = "PowerAdSpy";
// const powerAdSpyYTApi = "https://youtube-dev.poweradspy.com/api/";
// //const powerAdSpyYTApi = "https://api.youtube-newes.poweradspy.com/api/";
// const powerAdSpyGText = "https://gtext-dev.poweradspy.com/api/";
// const powerAdSpyRedditApi = "https://reddit-dev.poweradspy.com/";
// const powerAdSpyNativeApi = "https://native-dev.poweradspy.com/api/";
// const powerAdSpyGDNApi = "https://gdn-dev.poweradspy.com/api/";
// const powerAdSpyQuoraApi = "https://quora-dev.poweradspy.com/"; //insertads";
// // const powerAdSpyPintApi = "https://pinterest-dev.poweradspy.com/";
// const powerAdSpyPinterestApi="https://pinterest-dev.poweradspy.com/api/pintAdsData"
// const powerAdSpyBingApi = "https://bing-dev.poweradspy.com/";
// const powerAdSpyLinkedInApi = "https://linkedin-dev.poweradspy.com/";
// const powerAdSpyInstaApi = "https://instagram-dev.poweradspy.com/";
// //server=1,user=3,FBPage=10
// const Platform = "3";
// const pluginIdentifier = "PAS-Chrome";
// const paskey = "PaS6113#";
// const autoScrollProcess = true;
// const userRequestProcess = true;
// const quoraID = '707851794';
// const getJson = "nkecaphdplhfmmbkcfnknejeonfnifbn"