// Creating options elements
let accept = document.createElement("button");
let reject = document.createElement("button");
let options = document.querySelector(".options");
let warning = document.querySelector(".warning");
let terms = document.querySelector(".terms");

let logobox = document.querySelector(".logobox");
let img = document.createElement("img");

accept.setAttribute("id", "accept");
reject.setAttribute("id", "reject");
img.setAttribute("src", "./../images/powerAdSpy_logo.png");

let yes = document.getElementById("yes");
let no = document.getElementById("no");

// Function to fetch terms and conditions and add it dynamically to the elements
const ApiData = async () => {
  let description = document.getElementById("description");
  let title = document.getElementById("title");
  let response = await fetch("https://api.poweradspy.com/user-plugin-consent");
  response = await response.json();
  // console.log(response)
  if (response.code === 200) {
    logobox.append(img);
    if (description) description.innerText = response.data.Form_Description;
    if (title) title.innerText = response.data.Form_Title;
    accept.innerText = response.data.Form_OptionA;
    reject.innerText = response.data.Form_OptionB;
    options.append(accept, reject);
    let contentHeight = document.querySelector("body").offsetHeight;
    let windowHeight = contentHeight + 35;
    chrome.windows.getCurrent(function (window) {
      chrome.windows.update(window.id, { height: windowHeight });
    });
  }
};
ApiData();

// When accept is clicked
accept.addEventListener("click", () => {
  userConsentCount(1)
    .then(() => {
      setTimeout(() => {
        window.close();
      }, 500);
    })
    .catch((error) => {
      console.log(error);
    });
});

// When reject is clicked
reject.addEventListener("click", () => {
  let contentHeight = document.querySelector("body").offsetHeight;
  let windowHeight = contentHeight - 100;
  chrome.windows.getCurrent(function (window) {
    chrome.windows.update(window.id, { height: windowHeight });
  });
  terms.style.display = "none";
  warning.style.display = "flex";
  yes.addEventListener("click", () => {
    userConsentCount(1)
      .then(() => {
        setTimeout(() => {
          window.close();
        }, 500);
      })
      .catch((error) => {
        console.log(error);
      });
  });
  no.addEventListener("click", () => {
    userConsentCount(0)
      .then(() => {
        setTimeout(() => {
          chrome.storage.local.set({ userConsent: true }, function () {
            window.close();
          });
        }, 500);
      })
      .catch((error) => {
        console.log(error);
      });
  });
});

function userConsentCount(descision) {
  return new Promise(async (resolve, reject) => {
    const response = await fetch(
      " https://user-activity-dev.poweradspy.com/user-consent-count",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ user_response: descision }),
      }
    );
    if (response.status === 200) return resolve();
    return reject();
  });
}
