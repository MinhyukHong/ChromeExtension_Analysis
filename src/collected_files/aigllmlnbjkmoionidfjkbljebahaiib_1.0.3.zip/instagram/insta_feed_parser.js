let isProcessingGeoData = false;
let user_ID = null;
let user_Name = null;
let instagram_username = null;
let defaultGeoData = {
  serviceId: null,
  lastUpdated: null,
  userCity: null,
  userState: null,
  userCountry: null,
  userIP: "",
};

let geoData = {};

chrome.storage.local.get({ "geoData": defaultGeoData }, function (result) {
  geoData = Object.assign(geoData, result.geoData);
  const minDelay = 2 * 60 * 60 * 1000; // 2 hours in milliseconds
  const maxDelay = 3 * 60 * 60 * 1000; // 3 hours in milliseconds
  const randomDelay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;

  if (geoData.lastUpdated < (Date.now() - randomDelay)) {
      geoData.userIP = null;
      buildUpGeoData();
  }
});

const interceptorScript = document.createElement("script");
interceptorScript.src = chrome.runtime.getURL("library/xhr-interceptor.js");

interceptorScript.onload = function () {
  this.remove();
};

(document.head || document.documentElement).appendChild(interceptorScript);

async function handleXhrIntercepted(event) {
  const { responseURL, response } = event.detail;
  const INSTA_GQL_URL = "https://www.instagram.com/api/v1/feed/timeline";
  const Graphql_Url = "https://www.instagram.com/api/graphql";
  const Graphql_Url_2 = "https://www.instagram.com/graphql/query";
  const STORY_URL = "https://www.instagram.com/api/v1/injected_story_units/";
  const STORY_URL_2 = "https://www.instagram.com/graphql/query";
  // Story ads
  if (
    (responseURL.includes(STORY_URL) || responseURL.includes(STORY_URL_2)) &&
    response.includes("Sponsored")
  ) {
    let rawData = JSON.parse(response);
    rawData =
      rawData?.ad_media_items ||
      rawData?.data?.xdt_injected_story_units?.ad_media_items;
    if (rawData) {
      rawData.forEach((story) => {
        if (story.label === "Sponsored") {
          if (story.items.length > 1) {
            carouselStoryData(story);
          } else {
            storyData(story);
          }
        }
      });
    }
  }
  // Feed ads
  if (
    responseURL.includes(INSTA_GQL_URL) ||
    responseURL.includes(Graphql_Url) ||
    responseURL.includes(Graphql_Url_2) ||
    response.indexOf("Sponsored") !== -1
  ) {
    //console.log(response);
    try {
      const rawposts = JSON.parse(response);
      let posts = rawposts.feed_items;
      if (!posts) {
        posts = rawposts.data.xdt_api__v1__feed__timeline__connection.edges;
      }
      let sponsoredPosts = posts.filter(
        (post) => post?.media_or_ad?.label === "Sponsored"
      );
      if (sponsoredPosts.length === 0) {
        sponsoredPosts = posts.filter(
          (post) => post?.node?.ad?.label === "Sponsored"
        );
      }
      for (const post of sponsoredPosts) {
        let adResult = {};
        adResult["ad_title"] = post?.media_or_ad?.ad_title || post?.node?.ad?.ad_title || '';
        adResult["ad_id"] =
          post?.media_or_ad?.items[0]?.code ?? post.node.ad.items[0].code;
        adResult["ad_url"] = "https://www.instagram.com/p/" + adResult.ad_id;
        adResult["call_to_action"] =
          post?.media_or_ad?.items[0]?.link_text ??
          post.node.ad.items[0].link_text;
        adResult["news_feed_description"] =
          post?.media_or_ad?.items[0]?.caption.text ??
          post?.node.ad.items[0].caption.text;
        adResult["image_video_url"] =
          post?.media_or_ad?.items[0]?.image_versions2?.candidates[3]?.url ??
          post.node.ad.items[0].image_versions2.candidates[0].url;
        adResult["post_owner_image"] =
          post?.media_or_ad?.items[0]?.caption?.user?.profile_pic_url ??
          post.node.ad.items[0].user.profile_pic_url;
        adResult["post_owner"] =
          post?.media_or_ad?.items[0]?.caption?.user?.username ??
          post.node.ad.items[0].user.full_name;
        if (!adResult["post_owner"])
          adResult["post_owner"] = post.node.ad.items[0].user.username;
        adResult["post_date"] =
          post?.media_or_ad?.items[0]?.taken_at?.toString() ??
          post.node.ad.items[0].taken_at.toString();
        adResult["destination_url"] =
          post?.media_or_ad?.items[0]?.link ?? post.node.ad.items[0].link;
        adResult["comment"] =
          post?.media_or_ad?.items[0]?.comment_count ??
          post.node.ad.items[0].comment_count;
        adResult["likes"] =
          post?.media_or_ad?.items[0]?.like_count ??
          post.node.ad.items[0].like_count;
        adResult["thumbnail_url"] = "";
        if (
          post?.media_or_ad?.items[0]?.media_type === 1 ||
          post?.node?.ad?.items[0]?.media_type === 1
        ) {
          adResult["type"] = "IMAGE";
        } else if (
          post.media_or_ad?.items[0]?.media_type === 2 ||
          post?.node?.ad?.items[0]?.media_type === 2
        ) {
          adResult["type"] = "VIDEO";
          adResult["image_video_url"] =
            post?.media_or_ad?.items[0]?.video_versions[0]?.url ??
            post.node.ad.items[0].video_versions[0].url;
          adResult["thumbnail_url"] = post?.node?.ad?.items[0]?.image_versions2?.candidates[0]?.url;
        }
        (adResult["share"] = 0), (adResult["ad_position"] = "FEED");
        (adResult["ad_type"] = 0), (adResult["category"] = "");
        adResult["ad_text"] = "";
        adResult["other_multimedia"] = "";
        adResult["side_url"] = "Not implemented yet";
        adResult["first_seen"] = Date.now().toString();
        adResult["last_seen"] = Date.now().toString();
        adResult["lower_age"] = "18";
        adResult["upper_age"] = "30";
        adResult["version"] = version;
        adResult["platform"] = Platform;
        adResult["source"] = "desktop";
        adResult["country"] = geoData.userCountry;
        adResult["city"] = geoData.userCity;
        adResult["state"] = geoData.userState;
        // adResult["instagram_id"] = user_ID;
        adResult["meta_ad_id"] = post?.node?.ad?.ad_id || ''
        adResult["views"] = post?.node?.ad?.items[0]?.view_count || "";
        await sendPost(adResult, `${powerAdSpyInstaApi}gramAdsData`);
      }
    } catch (error) {}
  }
}

document.addEventListener("XHR_INTERCEPTED", handleXhrIntercepted);

function AnalysePostdata(post_raw_data) {
  try {
    return checkPostData(post_raw_data);
  } catch (error) {
    return null;
  }
}

function userID() {
  const pageSource = document.documentElement.outerHTML;
  user_ID = getBetween(pageSource, "appScopedIdentity", "claim");
  user_ID = user_ID.replace(/[^a-zA-Z0-9\s]/g, "");

  const userIdSource = getBetween(
    pageSource,
    "should_show_category",
    "badge_count_at_ms"
  );
  instagram_username = getBetween(userIdSource, "username", "badge_count");
  instagram_username = instagram_username.replace(/[^a-zA-Z0-9\s]/g, "");

  const userNameSource = getBetween(
    pageSource,
    "category_name",
    "has_profile_pic"
  );
  user_Name = getBetween(userNameSource, "full_name", "has_phone_number");
  user_Name = user_Name.replace(/[^a-zA-Z0-9\s]/g, "");
}

async function userDetails() {
  let userData = {};
  userData["age"] = "";
  userData["current_country"] = geoData.userCountry;
  userData["instagram_username"] = instagram_username;
  userData["instagram_id"] = user_ID;
  userData["name"] = user_Name;
  userData["other_places_lived"] = "";
  userData["relationship_status"] = "";
  let x = {data: getObject(userData)}
  await sendUserData(x, `${powerAdSpyInstaApi}user-chk`);
}

setTimeout(userID, 1000);
setTimeout(userDetails, 1100);

async function sendPost(post, url) {
  if (!post.ad_id) return;

  if (post?.type === "VIDEO" && !post?.views){
    const likes = post?.likes;
    const shares = post?.share;
    const comments = post?.comment;
    const views = calculateViews(likes, shares, comments);
    post.views = views;
  }
  
  if(post.views) {
    let adbudget = instaAdBudget(post.views);
    post["lowerBudget"] = adbudget[0];
    post["upperBudget"] = adbudget[1];
  }
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(post),
    });
  } catch (error) {}
}
async function sendUserData(post, url) {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(post),
    });
  } catch (error) {}
}

function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}

function buildUpGeoData() {
  if (isProcessingGeoData) {
    return;
  }
  isProcessingGeoData = true;

  if (
    !geoData.userIP ||
    !geoData.userCity ||
    !geoData.userState ||
    !geoData.userCountry
  ) {
    if (!geoData.userIP) {
      const ourIP = "https://geolocation.poweradspy.com/";
      $.ajax({
        url: ourIP,
        type: "GET",
        async: true,
        success: function (IpResponse) {
          const ourIpResponse = JSON.parse(IpResponse);
          geoData.userIP = ourIpResponse.ip;
          geoData.userCity = ourIpResponse.cityName;
          geoData.userState = ourIpResponse.regionName;
          geoData.userCountry = ourIpResponse.countryName;
          geoData.lastUpdated = Date.now();
          chrome.storage.local.set({ geoData: geoData });
          isProcessingGeoData = false;
        },
      });
    }
  }
}
