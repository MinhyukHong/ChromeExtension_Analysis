// Stories image and video ads data extraction
async function storyData(Ad) {
  // console.log(Ad);
  let adData = {};
  adData["ad_title"] = Ad?.ad_title || "";
  adData["ad_id"] = Ad?.items[0]?.code;
  adData["ad_url"] = `https://www.instagram.com/p/${adData.ad_id}`;
  adData["call_to_action"] = Ad?.link_text;
  adData["news_feed_description"] = Ad?.items[0]?.caption?.text || "";
  adData["image_video_url"] =
    Ad?.items[0]?.media_type === 2
      ? Ad?.items[0].video_versions[0].url
      : Ad?.items[0].image_versions2.candidates[0].url;
  adData["post_owner_image"] =
    Ad?.items[0]?.caption?.user?.profile_pic_url ??
    Ad?.items[0]?.user?.profile_pic_url;
  adData["post_owner"] =
    Ad?.items[0].caption?.user?.username || Ad?.items[0]?.user?.username;
  adData["post_date"] = Ad?.items[0].taken_at?.toString();
  adData["destination_url"] = Ad?.items[0]?.link || "";
  adData["comment"] = Ad?.items[0]?.comment_count || 0;
  adData["likes"] = Ad?.items[0]?.like_count || 0;
  adData["other_multimedia"] = "";
  adData["story_type"] = Ad?.items[0]?.media_type === 2 ? "VIDEO" : "IMAGE";
  adData["meta_ad_id"] = Ad?.ad_id || "";
  adData["views"] = Ad?.items[0]?.view_count || "";
  // console.log(commponProps(adData));
  await sendPost(commponProps(adData), `${powerAdSpyInstaApi}gramAdsData`);
}

// Stories multiple image ads data extraction
async function carouselStoryData(Ad) {
  // console.log(Ad);
  let [imageVideo, other, title, description, destUrl, storyType] =
    carouselProcess(Ad.items);
  storyType = Array.from(new Set(storyType));
  if (storyType.length === 1) {
    other.shift();
    other = other.join("||,");
    let adData = {};
    adData["ad_title"] = title || "";
    adData["ad_id"] = Ad?.items[0]?.code;
    adData["ad_url"] = `https://www.instagram.com/p/${adData.ad_id}`;
    adData["call_to_action"] = Ad?.link_text;
    adData["news_feed_description"] = description || "";
    adData["image_video_url"] = imageVideo;
    adData["post_owner_image"] =
      Ad?.items[0]?.caption?.user?.profile_pic_url ??
      Ad?.items[0]?.user?.profile_pic_url;
    adData["post_owner"] =
      Ad?.items[0].caption?.user?.username || Ad?.items[0]?.user?.username;
    adData["post_date"] = Ad?.items[0].taken_at?.toString();
    adData["destination_url"] = destUrl || "";
    adData["comment"] = Ad?.items[0]?.comment_count || 0;
    adData["likes"] = Ad?.items[0]?.like_count || 0;
    adData["other_multimedia"] = other;
    adData["story_type"] = storyType[0];
    adData["meta_ad_id"] = Ad?.ad_id || "";
    adData["views"] = Ad?.items[0]?.view_count || "";
    // console.log(commponProps(adData));
    await sendPost(commponProps(adData), `${powerAdSpyInstaApi}gramAdsData`);
  }
}

// Combining all the data of multiple image ads
function carouselProcess(Ad) {
  let imageVideo = [];
  let title = [];
  let description = [];
  let destUrl = [];
  let storyType = [];
  Ad.forEach((ad) => {
    ad.media_type === 2
      ? imageVideo.push(ad.video_versions[0].url)
      : imageVideo.push(ad.image_versions2.candidates[3].url);
    ad.media_type === 2 ? storyType.push("VIDEO") : storyType.push("IMAGE");
    title.push(ad.overlay_title);
    description.push(ad.caption.text);
    destUrl.push(ad.story_cta[0].links[0].webUri);
  });
  title = title.join("||,");
  return [
    imageVideo[0],
    imageVideo,
    title,
    description[0],
    destUrl[0],
    storyType,
  ];
}

// Common properties for the payload
function commponProps(Ad) {
  Ad["type"] = "STORIES";
  Ad["share"] = 0;
  Ad["ad_position"] = "FEED";
  Ad["ad_type"] = 1;
  Ad["category"] = "";
  Ad["ad_text"] = "";
  Ad["side_url"] = "Not implemented yet";
  Ad["first_seen"] = Date.now().toString();
  Ad["last_seen"] = Date.now().toString();
  Ad["lower_age"] = "18";
  Ad["upper_age"] = "30";
  Ad["version"] = version;
  Ad["platform"] = Platform;
  Ad["source"] = "desktop";
  Ad["country"] = geoData.userCountry;
  Ad["city"] = geoData.userCity;
  Ad["state"] = geoData.userState;
  // Ad["instagram_id"] = user_ID;
  return Ad;
}

function instaAdBudget(views) {
  if (views < 1600) {
      return [0, 1];
  }

  let reach;
  if (views >= 1000000) {
      reach = 1000000 + (Math.floor(views / 1000000) * 10);
  } else {
      reach = views;
  }

  // $1 = 1600 - 4600
  let budgetLowerRange = Math.round(reach / 4600);
  let budgetHigherRange = Math.round(reach / 1600);

  return [budgetLowerRange, budgetHigherRange];
}


function calculateViews(likes, shares, comments) {
  const avgLikeRate = 0.2;
  const shareMultiplier = 75;
  const commentMultiplier = 20;

  const views = (likes / avgLikeRate) + (shares * shareMultiplier) + (comments * commentMultiplier);
  return views;
}