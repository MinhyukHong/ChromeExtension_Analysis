'use strict';
let userFbId = 0;
const fbIdKey = "F%20%30u%%#30";
const CheckInterval = 0.5;

let CheckLocalStorageOfPowerAdSpy = () => {

    chrome.storage.local.get('userid', function (result) {
        userFbId = result.userid;

        if (userFbId === null || userFbId == 0 || userFbId === undefined) {
            localStorage.removeItem(btoa(fbIdKey));
            setTimeout(() => {
                CheckLocalStorageOfPowerAdSpy();
            }, CheckInterval * 60 * 1000);
        } else {
            localStorage.setItem(btoa(fbIdKey), btoa(userFbId));
        }
    });
};

CheckLocalStorageOfPowerAdSpy();