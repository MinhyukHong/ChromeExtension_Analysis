async function sendPost(post) {
  try {
    const response = await fetch(`${powerAdSpyQuoraApi}qapiAdsData`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(post),
    });
  } catch (error) {}
}

function getSeen() {
  const d = new Date();
  return d.getTime();
}

function CalculateMD5Hash(title, owner) {
  const combinedText = title + owner;
  return md5(combinedText);
}

function getBetween(pageSource, firstData, secondData) {
  try {
    const resSplit = pageSource.split(firstData);
    const indexSec = resSplit[1].indexOf(secondData);
    return resSplit[1].substring(0, indexSec);
  } catch (e) {
    return "";
  }
}


let actionTypes = [
    "Learn More", "Sign Up", "Shop Now", "Interested", "Send Message", "Book Now", "Play Now", "Download",
    "Get Offer", "Make Reservation", "Donate", "Use App", "Play Game", "Watch Video", "See Offers", "Book Appointment",
    "Listen", "Send Email", "Request Time", "Read articles", "Video Call Room", "Start Order", "Get Directions",
    "Get Tickets", "WhatsApp", "Play Music", "Visit group", "Apply Now", "Buy", "Buy Now", "Buy Tickets",
    "Call Now", "Contact Us", "Donate Now", "Download", "Get Deal", "Get Offer", "Get Quote", "Get Your Code",
    "Install App", "Install Now", "Learn Page", "Like Page", "Liked", "Listen Now", "Listen on Apple Music",
    "Listen On Deezer", "Listen on Whooshkaa", "Open Link", "Order Now", "Play Game", "Play", "Save Offer",
    "Save", "SaveSaved", "See Details", "See Menu", "Sell Now", "Spotify Icon", "Spotify IconAdd to Spotify",
    "Use Now", "View Event", "Visit Website", "Vote Now", "Watch More", "Free Trial",
    "Read More"
];