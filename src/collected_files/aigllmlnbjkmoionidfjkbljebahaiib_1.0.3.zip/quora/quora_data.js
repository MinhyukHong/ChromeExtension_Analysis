// Location variables
let [userip, usercity, userstate, usercountry] = [null, null, null, null];

// Extracting data of "Sponsored" type of ads
document.addEventListener("sponsored", async function (event) {
  try {
    let Ad = event.detail.Ad;
    // console.log(Ad);
    let quoraAdsData = {
      ad_type: 1,
      comment: 0,
      share: 0,
      ad_text: "",
      ad_url: "",
      likes: Ad?.numUpvotes || 0,
      type: Ad.adType === "image_ad" ? "IMAGE" : "VIDEO",
      post_owner_image: Ad?.logo?.imageUrl || "",
      image_url_original: Ad?.imageUrl,
      image_video_url: Ad?.imageUrl,
      ad_title: Ad?.title || "",
      post_owner: Ad?.businessName,
      news_feed_description: Ad?.contentText || "",
      call_to_action: Ad?.ctaString || "",
      destination_url: Ad?.urlTemplate.includes("campaign.id")
        ? Ad.urlTemplate.replace("&utm_campaign={{campaign.id}}", "")
        : Ad?.urlTemplate,
      post_date: getSeen().toString(),
    };
    if (quoraAdsData.destination_url.length > 8) {
      // console.log(await commonProperties(quoraAdsData));
      sendPost(await commonProperties(quoraAdsData));
    }
  } catch (error) {
    // console.log(error);
  }
});

// Extracting data of "Promoted by" type of ads
document.addEventListener("promotedBy", async function (event) {
  try {
    let Ad = event.detail.Ad;
    // console.log(Ad);
    if (
      !Ad?.answer?.contents?.includes("yt-embed") ||
      !Ad?.answer?.content?.includes("youtu")
    ) {
      let title = JSON.parse(Ad?.answer?.question?.title);
      let descriptionImageCtaDest = promotedDescription(
        JSON.parse(Ad?.answer?.content)
      );
      let [description, dest, image] = descriptionImageCtaDest;
      let quoraAdsData = {
        ad_type: 2,
        comment: Ad?.answer?.numDisplayComments || 0,
        share: Ad?.answer?.numShares || 0,
        ad_text: "",
        ad_url: "https://www.quora.com" + Ad?.answer?.commentsPageUrl || "",
        likes: Ad?.answer?.numUpvotes || 0,
        type: image ? "IMAGE" : "TEXT",
        post_owner_image: Ad?.answer?.author?.profileImageUrl || "",
        image_url_original: image || "",
        image_video_url: image || "",
        ad_title: title.sections[0]?.spans[0]?.text || "",
        post_owner: Ad?.businessName,
        news_feed_description: description || "",
        destination_url: dest || "",
        call_to_action: dest ? actionTypes[Math.floor(Math.random() * 67)] : "",
        post_date: `${Ad?.answer?.updatedTime || Ad?.answer?.creationTime}`,
      };
      // console.log(await commonProperties(quoraAdsData));
      sendPost(await commonProperties(quoraAdsData));
    }
  } catch (error) {
    // console.log(error);
  }
});

// To get description, Image, destination URL of "Promoted by" type of ad
function promotedDescription(contents) {
  let description = "";
  let image = [];
  let dest = [];
  let count = 0;
  contents.sections.forEach((element) => {
    if (element.type === "plain") {
      let plain = "";
      element.spans.forEach((span) => {
        plain += span.text;
        if (Object.keys(span).length > 0) {
          if (span?.modifiers?.link?.url) dest.push(span.modifiers.link.url);
        }
      });
      description += plain;
      description += "\n";
    }
    if (element.type === "ordered-list") {
      let ol = "";
      element.spans.forEach((span) => (ol += `${++count}. ${span.text}`));
      description += ol;
      description += "\n";
    }
    if (element.type === "unordered-list") {
      let ul = "";
      element.spans.forEach((span) => (ul += `${span.text}`));
      description += ul;
      description += "\n";
    }
    if (element.type === "hyperlink_embed") {
      element.spans.forEach(
        (span) =>
          (description += `${span.modifiers.embed.title}\n${span.modifiers.embed.snippet}\n${span.modifiers.embed.url}\n`)
      );
    }
    if (element.type === "image") {
      element.spans.forEach((span) => image.push(span.modifiers.image));
    }
  });
  return [description, dest[0], image[0]];
}

// Extracting data of "Sponsored By" and "Ad by" type of ads
document.addEventListener("sponsoredByAdBy", async function (event) {
  try {
    let Ad = event.detail.Ad;
    // console.log(Ad);
    let quoraAdsData = {
      ad_type: 1,
      comment: 0,
      share: 0,
      ad_text: "",
      ad_url: "",
      likes: Ad?.numUpvotes || 0,
      type: "TEXT",
      post_owner_image: Ad?.logo?.imageUrl || "",
      image_url_original: "",
      image_video_url: "",
      ad_title: Ad?.title || "",
      post_owner: Ad?.businessName,
      news_feed_description: Ad?.contentText || "",
      call_to_action: Ad?.ctaString || "",
      destination_url: Ad?.urlTemplate,
      post_date: getSeen().toString(),
    };
    // console.log(await commonProperties(quoraAdsData));
    sendPost(await commonProperties(quoraAdsData));
  } catch (error) {
    // console.log(error);
  }
});

// Common properties for the payload
async function commonProperties(Ad) {
  if (!userip || !userstate || !usercountry || !usercity) {
    let geoData = await fetch("https://geolocation.poweradspy.com/");
    let jsongeoData = await geoData.json();
    userip = jsongeoData.ip;
    usercity = jsongeoData.cityName;
    userstate = jsongeoData.regionName;
    usercountry = jsongeoData.countryName;
  }
  Ad["ad_id"] = CalculateMD5Hash(Ad.ad_title, Ad.post_owner);
  Ad["platform"] = Platform;
  Ad["country"] = usercountry;
  Ad["side_url"] = "Not implemented yet";
  Ad["category"] = "No category";
  Ad["lower_age"] = "";
  Ad["upper_age"] = "65";
  Ad["ad_position"] = "FEED";
  Ad["city"] = usercity;
  Ad["ip_address"] = userip;
  Ad["state"] = userstate;
  Ad["quora_id"] = quoraID;
  Ad["source"] = "desktop";
  Ad["first_seen"] = getSeen().toString();
  Ad["last_seen"] = getSeen().toString();
  Ad["version"] = version;
  return Ad;
}
