// This function gives response from fetch method. To get response from fetch method we have inject this script.
function onFetch(callback) {
  try {
    let logFetch = window.fetch;
    window.fetch = function (input, init) {
      try {
        return new Promise((resolve, reject) => {
          logFetch(input, init).then(function (response) {
            try {
              callback(response.clone());
              resolve(response);
            } catch (error) {}
          }, reject);
        });
      } catch (error) {}
    };
  } catch (error) {}
}

// To check if the response is an AD and send it to data extraction
function responseProcess(res) {
  res?.data?.multifeedObject?.multifeedConnection?.edges.forEach((element) => {
    let ele = element?.node?.stories;
    if (
      ele &&
      (ele[0].ad?.contentType === "ad" ||
        ele[0].ad?.answer?.contentType === "answer")
    ) {
      let type = element?.node?.stories[0]?.ad?.adType;
      let Ad = element?.node?.stories[0]?.ad;
      // "Sponsored" Image ad
      if (type === "image_ad" || type === "video_ad")
        document.dispatchEvent(
          new CustomEvent("sponsored", {
            detail: {
              Ad,
            },
          })
        );
      // "Promoted by" ad
      if (type === "promoted_answer")
        document.dispatchEvent(
          new CustomEvent("promotedBy", {
            detail: {
              Ad,
            },
          })
        );
      // "Sponsored By" and "Ad By"  ad
      if (type === "text_ad")
        document.dispatchEvent(
          new CustomEvent("sponsoredByAdBy", {
            detail: {
              Ad,
            },
          })
        );
    }
  });
}

// call the onFetch and pass an callback function to get the response.
onFetch((response) => {
  response.json().then((res) => {
    // console.log(res);
    try {
      if (JSON.stringify(res).includes("multifeedObject")) {
        responseProcess(res);
        // console.log(res);
      }
      if (JSON.stringify(res).includes("pagedListDataConnection")) {
        res?.data?.question?.pagedListDataConnection?.edges?.forEach((Ad) => {
          if (Ad?.node?.ad) {
            let type = Ad.node.ad.contentType;
            Ad = Ad.node.ad;
            if (Ad && type === "ad") {
              document.dispatchEvent(
                new CustomEvent("sponsoredByAdBy", {
                  detail: {
                    Ad,
                  },
                })
              );
            }
          }
        });
      }
    } catch (error) {
      // console.log(error);
    }
  });
});

// To get first sponsored ad and also to get Ad By, Sponsored by type of ads.
// Because we will not get it in xhr response.
// So we git it via pagesource
setTimeout(function () {
  try {
    // Ads will be available in script tags, so fetch all the script tags
    let tempElement = document.createElement("div");
    tempElement.innerHTML = document.documentElement.outerHTML;
    let scriptTags = Array.from(tempElement.getElementsByTagName("script"));

    // To find first few "Sponsored" ads that will miss in xhr
    let res1 = scriptTags.find((element) =>
      element.textContent.includes("multifeedObject")
    );
    if (res1) {
      res1 = JSON.parse(
        JSON.parse(`${res1.textContent.split("push(")[1].split(");window")[0]}`)
      );
      responseProcess(res1);
    }
    // To find first few "Sponsored By" and "Ad By" type of ads that will miss in xhr
    let res2 = scriptTags.find((element) =>
      element.textContent.includes("top_slot_question")
    );
    if (res2) {
      res2 = JSON.parse(
        JSON.parse(`${res2.textContent.split("push(")[1].split(");window")[0]}`)
      );
      // console.log(res2);
      res2?.data?.question?.pagedListDataConnection?.edges?.forEach((Ad) => {
        if (Ad?.node?.ad) {
          let type = Ad.node.ad.contentType;
          Ad = Ad.node.ad;
          if (Ad && type === "ad") {
            document.dispatchEvent(
              new CustomEvent("sponsoredByAdBy", {
                detail: {
                  Ad,
                },
              })
            );
          }
        }
      });
      res2?.data?.question?.ads?.forEach((Ad) => {
        let type = Ad?.ad?.contentType;
        if (Ad && type === "ad") {
          Ad = Ad.ad;
          document.dispatchEvent(
            new CustomEvent("sponsoredByAdBy", {
              detail: {
                Ad,
              },
            })
          );
        }
      });
    }
  } catch (error) {
    // console.log(error);
  }
}, 7000);
