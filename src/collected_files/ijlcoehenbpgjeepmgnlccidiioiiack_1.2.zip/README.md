# uniqtab
Chrome extension to automatically delete already opened tabs when the same URL is opened.

# install
[Chrome web store](https://chrome.google.com/webstore/detail/uniqtab/ijlcoehenbpgjeepmgnlccidiioiiack?hl=en)