const useAddres = {
    address_line1: '1622 E Ayre Street',
    zip_code: '19804',
    phone_number: '+1 3026608398',
    city: 'WILMINGTON',
    country: 'USA',
    state: 'DE'
}
let selectedData;
let dataOne;
var ss;


chrome.storage.sync.get(['address_array'], function (result) {
    ss = result
    if (!result.address_array) {
        document.getElementById('worning').classList.add('show_flex')
    } else {
        chrome.storage.sync.set({ 'userArm': result.address_array[0] }, function (response) {
        })
        document.getElementById('select').classList.add('show');
        document.getElementById('worning').classList.remove('show_flex');
        let getSelectorDiv = document.getElementById('selector')
        for (let i = 0; i < result.address_array.length; i++) {
            var option = document.createElement("option");
            option.value = result.address_array[i].address2;
            option.text = result.address_array[i].full_name;
            getSelectorDiv.appendChild(option);
        }
    }
});

$('#selector').change(function () {
    for (let i = 0; i < ss.address_array.length; i++) {
        if (ss.address_array[i].address2 === $(this).val()) {
            selectedData = ss.address_array[i];
        }
    }
    chrome.storage.sync.set({ 'userArm': selectedData }, function (response) {
    });
})
document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('#put-address').addEventListener('click', function (e) {
        chrome.tabs.query({}, function (tabs) {
            let allowOpen = true;
            for (let i = 0; i < tabs.length; i++) {
                if (/https:\/\/www\.amazon\.com\/a\/addresses\/add.*/gm.test(tabs[i].url)) {
                    allowOpen = false;
                    chrome.tabs.sendMessage(tabs[i].id, { activeChanges: tabs[i].url.match(/http(s?)\:\/\/[^\/]*/)[0], clicked: true }, function (response) {

                    });
                    break;
                }

            }
            if (document.getElementById("cbx").checked && allowOpen) {
                window.open('https://www.amazon.com/a/addresses/add?oped_from_popup=true', '_blank');
            }
            if (document.getElementById("carters").checked) {
                window.open('https://www.carters.com/address-book', '_blank');
            }
            if (document.getElementById("sixpm").checked) {
                window.open('https://www.shopdisney.com/account', '_blank');
            }
            if(document.getElementById("bh").checked){
                window.open('https://www.bhphotovideo.com/find/MyAccount.jsp')
            }

            if(document.getElementById("rockauto").checked){
                window.open('https://www.rockauto.com/en/profile')
            }
        })
        setTimeout(() => {
            document.getElementById('good_resulte').classList.add("show");
            var animationData = {
                "v": "5.5.7",
                "meta": {
                    "g": "LottieFiles AE 0.1.20",
                    "a": "",
                    "k": "",
                    "d": "",
                    "tc": ""
                },
                "fr": 29.9700012207031,
                "ip": 0,
                "op": 60.0000024438501,
                "w": 500,
                "h": 500,
                "nm": "Comp 2",
                "ddd": 0,
                "assets": [
                    {
                        "id": "comp_0",
                        "layers": [
                            {
                                "ddd": 0,
                                "ind": 1,
                                "ty": 4,
                                "nm": "Shape Layer 3",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    188
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    -84.167,
                                                    -170.667,
                                                    0
                                                ],
                                                "ti": [
                                                    -134.833,
                                                    -161.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    672,
                                                    243,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            40,
                                            40,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "sr",
                                        "sy": 1,
                                        "d": 1,
                                        "pt": {
                                            "a": 0,
                                            "k": 5,
                                            "ix": 3
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 4
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 5
                                        },
                                        "ir": {
                                            "a": 0,
                                            "k": 50,
                                            "ix": 6
                                        },
                                        "is": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 8
                                        },
                                        "or": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 7
                                        },
                                        "os": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 9
                                        },
                                        "ix": 1,
                                        "nm": "Polystar Path 1",
                                        "mn": "ADBE Vector Shape - Star",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.96862745285,
                                                0.807843148708,
                                                0.082352943718,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 60.0000024438501,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 2,
                                "ty": 4,
                                "nm": "Shape Layer 2",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    273
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    183.833,
                                                    67.333,
                                                    0
                                                ],
                                                "ti": [
                                                    27.167,
                                                    -153.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    579,
                                                    742,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            40,
                                            40,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "sr",
                                        "sy": 1,
                                        "d": 1,
                                        "pt": {
                                            "a": 0,
                                            "k": 5,
                                            "ix": 3
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 4
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 5
                                        },
                                        "ir": {
                                            "a": 0,
                                            "k": 50,
                                            "ix": 6
                                        },
                                        "is": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 8
                                        },
                                        "or": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 7
                                        },
                                        "os": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 9
                                        },
                                        "ix": 1,
                                        "nm": "Polystar Path 1",
                                        "mn": "ADBE Vector Shape - Star",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.96862745285,
                                                0.807843148708,
                                                0.082352943718,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 60.0000024438501,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 3,
                                "ty": 4,
                                "nm": "Shape Layer 1",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    -292
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    1.833,
                                                    -220.667,
                                                    0
                                                ],
                                                "ti": [
                                                    85.167,
                                                    -23.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    71,
                                                    152,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            40,
                                            40,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "sr",
                                        "sy": 1,
                                        "d": 1,
                                        "pt": {
                                            "a": 0,
                                            "k": 5,
                                            "ix": 3
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 4
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 5
                                        },
                                        "ir": {
                                            "a": 0,
                                            "k": 50,
                                            "ix": 6
                                        },
                                        "is": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 8
                                        },
                                        "or": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 7
                                        },
                                        "os": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 9
                                        },
                                        "ix": 1,
                                        "nm": "Polystar Path 1",
                                        "mn": "ADBE Vector Shape - Star",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.96862745285,
                                                0.807843148708,
                                                0.082352943718,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 60.0000024438501,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 4,
                                "ty": 4,
                                "nm": "Shape Layer 9",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    264
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    31.833,
                                                    -98.667,
                                                    0
                                                ],
                                                "ti": [
                                                    83.167,
                                                    -235.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    661,
                                                    546,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                40,
                                                40
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.152941176471,
                                                0.682352941176,
                                                0.376470588235,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 5,
                                "ty": 4,
                                "nm": "Shape Layer 8",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    264
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    165.833,
                                                    -82.667,
                                                    0
                                                ],
                                                "ti": [
                                                    301.167,
                                                    -47.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    249,
                                                    72,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                40,
                                                40
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.152941176471,
                                                0.682352941176,
                                                0.376470588235,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 6,
                                "ty": 4,
                                "nm": "Shape Layer 7",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    -249
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    -190.167,
                                                    -64.667,
                                                    0
                                                ],
                                                "ti": [
                                                    -230.833,
                                                    -141.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    277,
                                                    728,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                40,
                                                40
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.152941176471,
                                                0.682352941176,
                                                0.376470588235,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 7,
                                "ty": 4,
                                "nm": "Shape Layer 12",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    -249
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    11.833,
                                                    -130.667,
                                                    0
                                                ],
                                                "ti": [
                                                    89.167,
                                                    -117.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    207,
                                                    340,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                20,
                                                20
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.023529411765,
                                                0.458823529412,
                                                0.733333333333,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 8,
                                "ty": 4,
                                "nm": "Shape Layer 11",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    264
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    29.833,
                                                    131.333,
                                                    0
                                                ],
                                                "ti": [
                                                    127.167,
                                                    80.667,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    531,
                                                    332,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                20,
                                                20
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.023529411765,
                                                0.458823529412,
                                                0.733333333333,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 9,
                                "ty": 4,
                                "nm": "Shape Layer 10",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    264
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    81.833,
                                                    71.333,
                                                    0
                                                ],
                                                "ti": [
                                                    97.167,
                                                    80.667,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    259,
                                                    534,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                20,
                                                20
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.023529411765,
                                                0.458823529412,
                                                0.733333333333,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 10,
                                "ty": 4,
                                "nm": "Shape Layer 6",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    264
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    149.833,
                                                    41.333,
                                                    0
                                                ],
                                                "ti": [
                                                    143.167,
                                                    -43.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    407,
                                                    682,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                20,
                                                20
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.117647059262,
                                                0.690196096897,
                                                0.901960790157,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 11,
                                "ty": 4,
                                "nm": "Shape Layer 5",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    264
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    187.833,
                                                    -16.667,
                                                    0
                                                ],
                                                "ti": [
                                                    207.167,
                                                    58.667,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    413,
                                                    164,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                20,
                                                20
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.117647059262,
                                                0.690196096897,
                                                0.901960790157,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            },
                            {
                                "ddd": 0,
                                "ind": 12,
                                "ty": 4,
                                "nm": "Shape Layer 4",
                                "sr": 1,
                                "ks": {
                                    "o": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        1
                                                    ],
                                                    "y": [
                                                        1
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.01
                                                    ],
                                                    "y": [
                                                        0
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    100
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 11
                                    },
                                    "r": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": [
                                                        0.833
                                                    ],
                                                    "y": [
                                                        0.833
                                                    ]
                                                },
                                                "o": {
                                                    "x": [
                                                        0.167
                                                    ],
                                                    "y": [
                                                        0.167
                                                    ]
                                                },
                                                "t": 0,
                                                "s": [
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    -249
                                                ]
                                            }
                                        ],
                                        "ix": 10
                                    },
                                    "p": {
                                        "a": 1,
                                        "k": [
                                            {
                                                "i": {
                                                    "x": 0,
                                                    "y": 1
                                                },
                                                "o": {
                                                    "x": 0.01,
                                                    "y": 0
                                                },
                                                "t": 0,
                                                "s": [
                                                    400,
                                                    400,
                                                    0
                                                ],
                                                "to": [
                                                    -110.167,
                                                    -134.667,
                                                    0
                                                ],
                                                "ti": [
                                                    -14.833,
                                                    -199.333,
                                                    0
                                                ]
                                            },
                                            {
                                                "t": 39.0000015885026,
                                                "s": [
                                                    91,
                                                    556,
                                                    0
                                                ]
                                            }
                                        ],
                                        "ix": 2
                                    },
                                    "a": {
                                        "a": 0,
                                        "k": [
                                            0,
                                            0,
                                            0
                                        ],
                                        "ix": 1
                                    },
                                    "s": {
                                        "a": 0,
                                        "k": [
                                            100,
                                            100,
                                            100
                                        ],
                                        "ix": 6
                                    }
                                },
                                "ao": 0,
                                "shapes": [
                                    {
                                        "ty": "rc",
                                        "d": 1,
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                20,
                                                20
                                            ],
                                            "ix": 2
                                        },
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                0,
                                                0
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "nm": "Rectangle Path 1",
                                        "mn": "ADBE Vector Shape - Rect",
                                        "hd": false
                                    },
                                    {
                                        "ty": "fl",
                                        "c": {
                                            "a": 0,
                                            "k": [
                                                0.117647059262,
                                                0.690196096897,
                                                0.901960790157,
                                                1
                                            ],
                                            "ix": 4
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 5
                                        },
                                        "r": 1,
                                        "bm": 0,
                                        "nm": "Fill 1",
                                        "mn": "ADBE Vector Graphic - Fill",
                                        "hd": false
                                    }
                                ],
                                "ip": 0,
                                "op": 150.000006109625,
                                "st": 0,
                                "bm": 0
                            }
                        ]
                    }
                ],
                "layers": [
                    {
                        "ddd": 0,
                        "ind": 1,
                        "ty": 4,
                        "nm": "done button Outlines",
                        "sr": 1,
                        "ks": {
                            "o": {
                                "a": 0,
                                "k": 100,
                                "ix": 11
                            },
                            "r": {
                                "a": 1,
                                "k": [
                                    {
                                        "i": {
                                            "x": [
                                                0.833
                                            ],
                                            "y": [
                                                0.833
                                            ]
                                        },
                                        "o": {
                                            "x": [
                                                0.167
                                            ],
                                            "y": [
                                                0.167
                                            ]
                                        },
                                        "t": 0,
                                        "s": [
                                            0
                                        ]
                                    },
                                    {
                                        "i": {
                                            "x": [
                                                0.833
                                            ],
                                            "y": [
                                                0.833
                                            ]
                                        },
                                        "o": {
                                            "x": [
                                                0.167
                                            ],
                                            "y": [
                                                0.167
                                            ]
                                        },
                                        "t": 8,
                                        "s": [
                                            -33
                                        ]
                                    },
                                    {
                                        "t": 15.0000006109625,
                                        "s": [
                                            0
                                        ]
                                    }
                                ],
                                "ix": 10
                            },
                            "p": {
                                "a": 0,
                                "k": [
                                    250,
                                    250,
                                    0
                                ],
                                "ix": 2
                            },
                            "a": {
                                "a": 0,
                                "k": [
                                    256,
                                    256,
                                    0
                                ],
                                "ix": 1
                            },
                            "s": {
                                "a": 1,
                                "k": [
                                    {
                                        "i": {
                                            "x": [
                                                0.833,
                                                0.833,
                                                0.833
                                            ],
                                            "y": [
                                                0.833,
                                                0.833,
                                                0.833
                                            ]
                                        },
                                        "o": {
                                            "x": [
                                                0.167,
                                                0.167,
                                                0.167
                                            ],
                                            "y": [
                                                0.167,
                                                0.167,
                                                0.167
                                            ]
                                        },
                                        "t": 0,
                                        "s": [
                                            0,
                                            0,
                                            100
                                        ]
                                    },
                                    {
                                        "i": {
                                            "x": [
                                                0.833,
                                                0.833,
                                                0.833
                                            ],
                                            "y": [
                                                0.833,
                                                0.833,
                                                0.833
                                            ]
                                        },
                                        "o": {
                                            "x": [
                                                0.167,
                                                0.167,
                                                0.167
                                            ],
                                            "y": [
                                                0.167,
                                                0.167,
                                                0.167
                                            ]
                                        },
                                        "t": 10,
                                        "s": [
                                            100,
                                            100,
                                            100
                                        ]
                                    },
                                    {
                                        "t": 15.0000006109625,
                                        "s": [
                                            75,
                                            75,
                                            100
                                        ]
                                    }
                                ],
                                "ix": 6
                            }
                        },
                        "ao": 0,
                        "shapes": [
                            {
                                "ty": "gr",
                                "it": [
                                    {
                                        "ty": "gr",
                                        "it": [
                                            {
                                                "ind": 0,
                                                "ty": "sh",
                                                "ix": 1,
                                                "ks": {
                                                    "a": 0,
                                                    "k": {
                                                        "i": [
                                                            [
                                                                3.694,
                                                                -1.67
                                                            ],
                                                            [
                                                                15.064,
                                                                2.812
                                                            ],
                                                            [
                                                                8.969,
                                                                5.292
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                -7.438,
                                                                7.439
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ]
                                                        ],
                                                        "o": [
                                                            [
                                                                -13.577,
                                                                6.137
                                                            ],
                                                            [
                                                                -10.287,
                                                                -1.92
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                7.438,
                                                                7.439
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                -3.486,
                                                                2.006
                                                            ]
                                                        ],
                                                        "v": [
                                                            [
                                                                30.437,
                                                                -12.293
                                                            ],
                                                            [
                                                                -13.069,
                                                                -3.639
                                                            ],
                                                            [
                                                                -41.19,
                                                                -16.698
                                                            ],
                                                            [
                                                                -14.093,
                                                                10.398
                                                            ],
                                                            [
                                                                12.954,
                                                                10.398
                                                            ],
                                                            [
                                                                41.19,
                                                                -17.837
                                                            ]
                                                        ],
                                                        "c": true
                                                    },
                                                    "ix": 2
                                                },
                                                "nm": "Path 1",
                                                "mn": "ADBE Vector Shape - Group",
                                                "hd": false
                                            },
                                            {
                                                "ty": "fl",
                                                "c": {
                                                    "a": 0,
                                                    "k": [
                                                        0.827000038297,
                                                        0.917999985639,
                                                        0.851000019148,
                                                        1
                                                    ],
                                                    "ix": 4
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 5
                                                },
                                                "r": 1,
                                                "bm": 0,
                                                "nm": "Fill 1",
                                                "mn": "ADBE Vector Graphic - Fill",
                                                "hd": false
                                            },
                                            {
                                                "ty": "tr",
                                                "p": {
                                                    "a": 0,
                                                    "k": [
                                                        229.522,
                                                        306.324
                                                    ],
                                                    "ix": 2
                                                },
                                                "a": {
                                                    "a": 0,
                                                    "k": [
                                                        0,
                                                        0
                                                    ],
                                                    "ix": 1
                                                },
                                                "s": {
                                                    "a": 0,
                                                    "k": [
                                                        100,
                                                        100
                                                    ],
                                                    "ix": 3
                                                },
                                                "r": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 6
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 7
                                                },
                                                "sk": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 4
                                                },
                                                "sa": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 5
                                                },
                                                "nm": "Transform"
                                            }
                                        ],
                                        "nm": "Group 1",
                                        "np": 2,
                                        "cix": 2,
                                        "bm": 0,
                                        "ix": 1,
                                        "mn": "ADBE Vector Group",
                                        "hd": false
                                    },
                                    {
                                        "ty": "gr",
                                        "it": [
                                            {
                                                "ind": 0,
                                                "ty": "sh",
                                                "ix": 1,
                                                "ks": {
                                                    "a": 0,
                                                    "k": {
                                                        "i": [
                                                            [
                                                                -9.391,
                                                                -4.208
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                7.482,
                                                                -5.727
                                                            ]
                                                        ],
                                                        "o": [
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                -6.835,
                                                                -6.835
                                                            ],
                                                            [
                                                                10.243,
                                                                0.324
                                                            ]
                                                        ],
                                                        "v": [
                                                            [
                                                                15.056,
                                                                6.169
                                                            ],
                                                            [
                                                                10.072,
                                                                1.185
                                                            ],
                                                            [
                                                                -15.056,
                                                                -0.442
                                                            ]
                                                        ],
                                                        "c": true
                                                    },
                                                    "ix": 2
                                                },
                                                "nm": "Path 1",
                                                "mn": "ADBE Vector Shape - Group",
                                                "hd": false
                                            },
                                            {
                                                "ty": "fl",
                                                "c": {
                                                    "a": 0,
                                                    "k": [
                                                        1,
                                                        1,
                                                        1,
                                                        1
                                                    ],
                                                    "ix": 4
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 5
                                                },
                                                "r": 1,
                                                "bm": 0,
                                                "nm": "Fill 1",
                                                "mn": "ADBE Vector Graphic - Fill",
                                                "hd": false
                                            },
                                            {
                                                "ty": "tr",
                                                "p": {
                                                    "a": 0,
                                                    "k": [
                                                        191.834,
                                                        247.92
                                                    ],
                                                    "ix": 2
                                                },
                                                "a": {
                                                    "a": 0,
                                                    "k": [
                                                        0,
                                                        0
                                                    ],
                                                    "ix": 1
                                                },
                                                "s": {
                                                    "a": 0,
                                                    "k": [
                                                        100,
                                                        100
                                                    ],
                                                    "ix": 3
                                                },
                                                "r": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 6
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 7
                                                },
                                                "sk": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 4
                                                },
                                                "sa": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 5
                                                },
                                                "nm": "Transform"
                                            }
                                        ],
                                        "nm": "Group 2",
                                        "np": 2,
                                        "cix": 2,
                                        "bm": 0,
                                        "ix": 2,
                                        "mn": "ADBE Vector Group",
                                        "hd": false
                                    },
                                    {
                                        "ty": "gr",
                                        "it": [
                                            {
                                                "ind": 0,
                                                "ty": "sh",
                                                "ix": 1,
                                                "ks": {
                                                    "a": 0,
                                                    "k": {
                                                        "i": [
                                                            [
                                                                -16.443,
                                                                -1.661
                                                            ],
                                                            [
                                                                -0.313,
                                                                0.336
                                                            ],
                                                            [
                                                                1.295,
                                                                0.958
                                                            ],
                                                            [
                                                                6.404,
                                                                -6.405
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ]
                                                        ],
                                                        "o": [
                                                            [
                                                                0.327,
                                                                -0.317
                                                            ],
                                                            [
                                                                -0.973,
                                                                -1.171
                                                            ],
                                                            [
                                                                -7.283,
                                                                -5.386
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                13.474,
                                                                -9.127
                                                            ]
                                                        ],
                                                        "v": [
                                                            [
                                                                22.713,
                                                                -3.631
                                                            ],
                                                            [
                                                                23.676,
                                                                -4.605
                                                            ],
                                                            [
                                                                20.288,
                                                                -7.821
                                                            ],
                                                            [
                                                                -4.854,
                                                                -5.613
                                                            ],
                                                            [
                                                                -23.676,
                                                                13.208
                                                            ]
                                                        ],
                                                        "c": true
                                                    },
                                                    "ix": 2
                                                },
                                                "nm": "Path 1",
                                                "mn": "ADBE Vector Shape - Group",
                                                "hd": false
                                            },
                                            {
                                                "ty": "fl",
                                                "c": {
                                                    "a": 0,
                                                    "k": [
                                                        1,
                                                        1,
                                                        1,
                                                        1
                                                    ],
                                                    "ix": 4
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 5
                                                },
                                                "r": 1,
                                                "bm": 0,
                                                "nm": "Fill 1",
                                                "mn": "ADBE Vector Graphic - Fill",
                                                "hd": false
                                            },
                                            {
                                                "ty": "tr",
                                                "p": {
                                                    "a": 0,
                                                    "k": [
                                                        314.643,
                                                        200.928
                                                    ],
                                                    "ix": 2
                                                },
                                                "a": {
                                                    "a": 0,
                                                    "k": [
                                                        0,
                                                        0
                                                    ],
                                                    "ix": 1
                                                },
                                                "s": {
                                                    "a": 0,
                                                    "k": [
                                                        100,
                                                        100
                                                    ],
                                                    "ix": 3
                                                },
                                                "r": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 6
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 7
                                                },
                                                "sk": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 4
                                                },
                                                "sa": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 5
                                                },
                                                "nm": "Transform"
                                            }
                                        ],
                                        "nm": "Group 3",
                                        "np": 2,
                                        "cix": 2,
                                        "bm": 0,
                                        "ix": 3,
                                        "mn": "ADBE Vector Group",
                                        "hd": false
                                    },
                                    {
                                        "ty": "gr",
                                        "it": [
                                            {
                                                "ind": 0,
                                                "ty": "sh",
                                                "ix": 1,
                                                "ks": {
                                                    "a": 0,
                                                    "k": {
                                                        "i": [
                                                            [
                                                                9.588,
                                                                7.091
                                                            ],
                                                            [
                                                                6.406,
                                                                -6.405
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                1.994,
                                                                1.993
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                7.438,
                                                                -7.438
                                                            ],
                                                            [
                                                                -7.438,
                                                                -7.437
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                -7.438,
                                                                7.438
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ]
                                                        ],
                                                        "o": [
                                                            [
                                                                -7.282,
                                                                -5.386
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                -1.994,
                                                                1.993
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                -7.439,
                                                                -7.438
                                                            ],
                                                            [
                                                                -7.438,
                                                                7.438
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                7.438,
                                                                7.438
                                                            ],
                                                            [
                                                                0,
                                                                0
                                                            ],
                                                            [
                                                                8.113,
                                                                -8.114
                                                            ]
                                                        ],
                                                        "v": [
                                                            [
                                                                78.594,
                                                                -62.834
                                                            ],
                                                            [
                                                                53.45,
                                                                -60.625
                                                            ],
                                                            [
                                                                -23.775,
                                                                16.601
                                                            ],
                                                            [
                                                                -30.995,
                                                                16.601
                                                            ],
                                                            [
                                                                -54.432,
                                                                -6.836
                                                            ],
                                                            [
                                                                -81.48,
                                                                -6.836
                                                            ],
                                                            [
                                                                -81.48,
                                                                20.21
                                                            ],
                                                            [
                                                                -40.909,
                                                                60.782
                                                            ],
                                                            [
                                                                -13.862,
                                                                60.782
                                                            ],
                                                            [
                                                                80.805,
                                                                -33.884
                                                            ]
                                                        ],
                                                        "c": true
                                                    },
                                                    "ix": 2
                                                },
                                                "nm": "Path 1",
                                                "mn": "ADBE Vector Shape - Group",
                                                "hd": false
                                            },
                                            {
                                                "ty": "fl",
                                                "c": {
                                                    "a": 0,
                                                    "k": [
                                                        0.941000007181,
                                                        0.969000004787,
                                                        0.948999980852,
                                                        1
                                                    ],
                                                    "ix": 4
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 5
                                                },
                                                "r": 1,
                                                "bm": 0,
                                                "nm": "Fill 1",
                                                "mn": "ADBE Vector Graphic - Fill",
                                                "hd": false
                                            },
                                            {
                                                "ty": "tr",
                                                "p": {
                                                    "a": 0,
                                                    "k": [
                                                        256.338,
                                                        255.941
                                                    ],
                                                    "ix": 2
                                                },
                                                "a": {
                                                    "a": 0,
                                                    "k": [
                                                        0,
                                                        0
                                                    ],
                                                    "ix": 1
                                                },
                                                "s": {
                                                    "a": 0,
                                                    "k": [
                                                        100,
                                                        100
                                                    ],
                                                    "ix": 3
                                                },
                                                "r": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 6
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 7
                                                },
                                                "sk": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 4
                                                },
                                                "sa": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 5
                                                },
                                                "nm": "Transform"
                                            }
                                        ],
                                        "nm": "Group 4",
                                        "np": 2,
                                        "cix": 2,
                                        "bm": 0,
                                        "ix": 4,
                                        "mn": "ADBE Vector Group",
                                        "hd": false
                                    },
                                    {
                                        "ty": "tr",
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                256,
                                                256
                                            ],
                                            "ix": 2
                                        },
                                        "a": {
                                            "a": 0,
                                            "k": [
                                                256,
                                                256
                                            ],
                                            "ix": 1
                                        },
                                        "s": {
                                            "a": 1,
                                            "k": [
                                                {
                                                    "i": {
                                                        "x": [
                                                            0.833,
                                                            0.833
                                                        ],
                                                        "y": [
                                                            0.833,
                                                            0.833
                                                        ]
                                                    },
                                                    "o": {
                                                        "x": [
                                                            0.167,
                                                            0.167
                                                        ],
                                                        "y": [
                                                            0.167,
                                                            0.167
                                                        ]
                                                    },
                                                    "t": 18,
                                                    "s": [
                                                        100,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "i": {
                                                        "x": [
                                                            0.833,
                                                            0.833
                                                        ],
                                                        "y": [
                                                            0.833,
                                                            0.833
                                                        ]
                                                    },
                                                    "o": {
                                                        "x": [
                                                            0.167,
                                                            0.167
                                                        ],
                                                        "y": [
                                                            0.167,
                                                            0.167
                                                        ]
                                                    },
                                                    "t": 21,
                                                    "s": [
                                                        110,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "i": {
                                                        "x": [
                                                            0.833,
                                                            0.833
                                                        ],
                                                        "y": [
                                                            0.833,
                                                            0.833
                                                        ]
                                                    },
                                                    "o": {
                                                        "x": [
                                                            0.167,
                                                            0.167
                                                        ],
                                                        "y": [
                                                            0.167,
                                                            0.167
                                                        ]
                                                    },
                                                    "t": 24,
                                                    "s": [
                                                        100,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "i": {
                                                        "x": [
                                                            0.833,
                                                            0.833
                                                        ],
                                                        "y": [
                                                            0.833,
                                                            0.833
                                                        ]
                                                    },
                                                    "o": {
                                                        "x": [
                                                            0.167,
                                                            0.167
                                                        ],
                                                        "y": [
                                                            0.167,
                                                            0.167
                                                        ]
                                                    },
                                                    "t": 29,
                                                    "s": [
                                                        100,
                                                        100
                                                    ]
                                                },
                                                {
                                                    "i": {
                                                        "x": [
                                                            0.833,
                                                            0.833
                                                        ],
                                                        "y": [
                                                            0.833,
                                                            0.833
                                                        ]
                                                    },
                                                    "o": {
                                                        "x": [
                                                            0.167,
                                                            0.167
                                                        ],
                                                        "y": [
                                                            0.167,
                                                            0.167
                                                        ]
                                                    },
                                                    "t": 32,
                                                    "s": [
                                                        110,
                                                        110
                                                    ]
                                                },
                                                {
                                                    "t": 35.0000014255792,
                                                    "s": [
                                                        100,
                                                        100
                                                    ]
                                                }
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 6
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 7
                                        },
                                        "sk": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "sa": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 5
                                        },
                                        "nm": "Transform"
                                    }
                                ],
                                "nm": "Group 8",
                                "np": 4,
                                "cix": 2,
                                "bm": 0,
                                "ix": 1,
                                "mn": "ADBE Vector Group",
                                "hd": false
                            },
                            {
                                "ty": "gr",
                                "it": [
                                    {
                                        "ty": "gr",
                                        "it": [
                                            {
                                                "ind": 0,
                                                "ty": "sh",
                                                "ix": 1,
                                                "ks": {
                                                    "a": 0,
                                                    "k": {
                                                        "i": [
                                                            [
                                                                0.133,
                                                                5.479
                                                            ],
                                                            [
                                                                -1.358,
                                                                9.199
                                                            ],
                                                            [
                                                                -7.938,
                                                                12.606
                                                            ],
                                                            [
                                                                -53.77,
                                                                -6.535
                                                            ],
                                                            [
                                                                -7.744,
                                                                -1.454
                                                            ],
                                                            [
                                                                29.459,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                -66.275
                                                            ],
                                                            [
                                                                -6.771,
                                                                -15.025
                                                            ]
                                                        ],
                                                        "o": [
                                                            [
                                                                -0.227,
                                                                -9.304
                                                            ],
                                                            [
                                                                2.172,
                                                                -14.72
                                                            ],
                                                            [
                                                                30.259,
                                                                -48.052
                                                            ],
                                                            [
                                                                7.867,
                                                                0.956
                                                            ],
                                                            [
                                                                -20.883,
                                                                -17.615
                                                            ],
                                                            [
                                                                -66.275,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                17.549
                                                            ],
                                                            [
                                                                -0.723,
                                                                -5.424
                                                            ]
                                                        ],
                                                        "v": [
                                                            [
                                                                -89.563,
                                                                68.28
                                                            ],
                                                            [
                                                                -87.253,
                                                                40.663
                                                            ],
                                                            [
                                                                -71.874,
                                                                -1.463
                                                            ],
                                                            [
                                                                75.237,
                                                                -59.898
                                                            ],
                                                            [
                                                                98.656,
                                                                -56.382
                                                            ],
                                                            [
                                                                21.344,
                                                                -84.619
                                                            ],
                                                            [
                                                                -98.656,
                                                                35.381
                                                            ],
                                                            [
                                                                -88.109,
                                                                84.619
                                                            ]
                                                        ],
                                                        "c": true
                                                    },
                                                    "ix": 2
                                                },
                                                "nm": "Path 1",
                                                "mn": "ADBE Vector Shape - Group",
                                                "hd": false
                                            },
                                            {
                                                "ty": "fl",
                                                "c": {
                                                    "a": 0,
                                                    "k": [
                                                        0.231000010173,
                                                        0.736999990426,
                                                        0.411999990426,
                                                        1
                                                    ],
                                                    "ix": 4
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 5
                                                },
                                                "r": 1,
                                                "bm": 0,
                                                "nm": "Fill 1",
                                                "mn": "ADBE Vector Graphic - Fill",
                                                "hd": false
                                            },
                                            {
                                                "ty": "tr",
                                                "p": {
                                                    "a": 0,
                                                    "k": [
                                                        234.657,
                                                        220.62
                                                    ],
                                                    "ix": 2
                                                },
                                                "a": {
                                                    "a": 0,
                                                    "k": [
                                                        0,
                                                        0
                                                    ],
                                                    "ix": 1
                                                },
                                                "s": {
                                                    "a": 0,
                                                    "k": [
                                                        100,
                                                        100
                                                    ],
                                                    "ix": 3
                                                },
                                                "r": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 6
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 7
                                                },
                                                "sk": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 4
                                                },
                                                "sa": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 5
                                                },
                                                "nm": "Transform"
                                            }
                                        ],
                                        "nm": "Group 5",
                                        "np": 2,
                                        "cix": 2,
                                        "bm": 0,
                                        "ix": 1,
                                        "mn": "ADBE Vector Group",
                                        "hd": false
                                    },
                                    {
                                        "ty": "gr",
                                        "it": [
                                            {
                                                "ind": 0,
                                                "ty": "sh",
                                                "ix": 1,
                                                "ks": {
                                                    "a": 0,
                                                    "k": {
                                                        "i": [
                                                            [
                                                                0,
                                                                -41.145
                                                            ],
                                                            [
                                                                41.146,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                41.146
                                                            ],
                                                            [
                                                                -41.145,
                                                                0
                                                            ]
                                                        ],
                                                        "o": [
                                                            [
                                                                0,
                                                                41.146
                                                            ],
                                                            [
                                                                -41.145,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                -41.145
                                                            ],
                                                            [
                                                                41.146,
                                                                0
                                                            ]
                                                        ],
                                                        "v": [
                                                            [
                                                                74.5,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                74.5
                                                            ],
                                                            [
                                                                -74.5,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                -74.5
                                                            ]
                                                        ],
                                                        "c": true
                                                    },
                                                    "ix": 2
                                                },
                                                "nm": "Path 1",
                                                "mn": "ADBE Vector Shape - Group",
                                                "hd": false
                                            },
                                            {
                                                "ty": "fl",
                                                "c": {
                                                    "a": 0,
                                                    "k": [
                                                        0.149000010771,
                                                        0.638999968884,
                                                        0.344999994016,
                                                        1
                                                    ],
                                                    "ix": 4
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 5
                                                },
                                                "r": 1,
                                                "bm": 0,
                                                "nm": "Fill 1",
                                                "mn": "ADBE Vector Graphic - Fill",
                                                "hd": false
                                            },
                                            {
                                                "ty": "tr",
                                                "p": {
                                                    "a": 0,
                                                    "k": [
                                                        277.5,
                                                        292.5
                                                    ],
                                                    "ix": 2
                                                },
                                                "a": {
                                                    "a": 0,
                                                    "k": [
                                                        0,
                                                        0
                                                    ],
                                                    "ix": 1
                                                },
                                                "s": {
                                                    "a": 0,
                                                    "k": [
                                                        100,
                                                        100
                                                    ],
                                                    "ix": 3
                                                },
                                                "r": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 6
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 7
                                                },
                                                "sk": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 4
                                                },
                                                "sa": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 5
                                                },
                                                "nm": "Transform"
                                            }
                                        ],
                                        "nm": "Group 6",
                                        "np": 2,
                                        "cix": 2,
                                        "bm": 0,
                                        "ix": 2,
                                        "mn": "ADBE Vector Group",
                                        "hd": false
                                    },
                                    {
                                        "ty": "gr",
                                        "it": [
                                            {
                                                "ind": 0,
                                                "ty": "sh",
                                                "ix": 1,
                                                "ks": {
                                                    "a": 0,
                                                    "k": {
                                                        "i": [
                                                            [
                                                                0,
                                                                -66.274
                                                            ],
                                                            [
                                                                66.274,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                66.274
                                                            ],
                                                            [
                                                                -66.274,
                                                                0
                                                            ]
                                                        ],
                                                        "o": [
                                                            [
                                                                0,
                                                                66.274
                                                            ],
                                                            [
                                                                -66.274,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                -66.274
                                                            ],
                                                            [
                                                                66.274,
                                                                0
                                                            ]
                                                        ],
                                                        "v": [
                                                            [
                                                                120,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                120
                                                            ],
                                                            [
                                                                -120,
                                                                0
                                                            ],
                                                            [
                                                                0,
                                                                -120
                                                            ]
                                                        ],
                                                        "c": true
                                                    },
                                                    "ix": 2
                                                },
                                                "nm": "Path 1",
                                                "mn": "ADBE Vector Shape - Group",
                                                "hd": false
                                            },
                                            {
                                                "ty": "fl",
                                                "c": {
                                                    "a": 0,
                                                    "k": [
                                                        0.152999997606,
                                                        0.681999954523,
                                                        0.375999989229,
                                                        1
                                                    ],
                                                    "ix": 4
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 5
                                                },
                                                "r": 1,
                                                "bm": 0,
                                                "nm": "Fill 1",
                                                "mn": "ADBE Vector Graphic - Fill",
                                                "hd": false
                                            },
                                            {
                                                "ty": "tr",
                                                "p": {
                                                    "a": 0,
                                                    "k": [
                                                        256,
                                                        256
                                                    ],
                                                    "ix": 2
                                                },
                                                "a": {
                                                    "a": 0,
                                                    "k": [
                                                        0,
                                                        0
                                                    ],
                                                    "ix": 1
                                                },
                                                "s": {
                                                    "a": 0,
                                                    "k": [
                                                        100,
                                                        100
                                                    ],
                                                    "ix": 3
                                                },
                                                "r": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 6
                                                },
                                                "o": {
                                                    "a": 0,
                                                    "k": 100,
                                                    "ix": 7
                                                },
                                                "sk": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 4
                                                },
                                                "sa": {
                                                    "a": 0,
                                                    "k": 0,
                                                    "ix": 5
                                                },
                                                "nm": "Transform"
                                            }
                                        ],
                                        "nm": "Group 7",
                                        "np": 2,
                                        "cix": 2,
                                        "bm": 0,
                                        "ix": 3,
                                        "mn": "ADBE Vector Group",
                                        "hd": false
                                    },
                                    {
                                        "ty": "tr",
                                        "p": {
                                            "a": 0,
                                            "k": [
                                                256,
                                                256
                                            ],
                                            "ix": 2
                                        },
                                        "a": {
                                            "a": 0,
                                            "k": [
                                                256,
                                                256
                                            ],
                                            "ix": 1
                                        },
                                        "s": {
                                            "a": 0,
                                            "k": [
                                                100,
                                                100
                                            ],
                                            "ix": 3
                                        },
                                        "r": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 6
                                        },
                                        "o": {
                                            "a": 0,
                                            "k": 100,
                                            "ix": 7
                                        },
                                        "sk": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 4
                                        },
                                        "sa": {
                                            "a": 0,
                                            "k": 0,
                                            "ix": 5
                                        },
                                        "nm": "Transform"
                                    }
                                ],
                                "nm": "Group 9",
                                "np": 3,
                                "cix": 2,
                                "bm": 0,
                                "ix": 2,
                                "mn": "ADBE Vector Group",
                                "hd": false
                            }
                        ],
                        "ip": 0,
                        "op": 60.0000024438501,
                        "st": 0,
                        "bm": 0
                    },
                    {
                        "ddd": 0,
                        "ind": 4,
                        "ty": 0,
                        "nm": "Comp 3",
                        "refId": "comp_0",
                        "sr": 1,
                        "ks": {
                            "o": {
                                "a": 0,
                                "k": 100,
                                "ix": 11
                            },
                            "r": {
                                "a": 0,
                                "k": 90,
                                "ix": 10
                            },
                            "p": {
                                "a": 0,
                                "k": [
                                    250,
                                    250,
                                    0
                                ],
                                "ix": 2
                            },
                            "a": {
                                "a": 0,
                                "k": [
                                    400,
                                    400,
                                    0
                                ],
                                "ix": 1
                            },
                            "s": {
                                "a": 0,
                                "k": [
                                    61,
                                    61,
                                    100
                                ],
                                "ix": 6
                            }
                        },
                        "ao": 0,
                        "w": 800,
                        "h": 800,
                        "ip": 5.00000020365417,
                        "op": 155.000006313279,
                        "st": 5.00000020365417,
                        "bm": 0
                    },
                    {
                        "ddd": 0,
                        "ind": 5,
                        "ty": 0,
                        "nm": "Comp 3",
                        "refId": "comp_0",
                        "sr": 1,
                        "ks": {
                            "o": {
                                "a": 0,
                                "k": 100,
                                "ix": 11
                            },
                            "r": {
                                "a": 0,
                                "k": 0,
                                "ix": 10
                            },
                            "p": {
                                "a": 0,
                                "k": [
                                    250,
                                    250,
                                    0
                                ],
                                "ix": 2
                            },
                            "a": {
                                "a": 0,
                                "k": [
                                    400,
                                    400,
                                    0
                                ],
                                "ix": 1
                            },
                            "s": {
                                "a": 0,
                                "k": [
                                    61,
                                    61,
                                    100
                                ],
                                "ix": 6
                            }
                        },
                        "ao": 0,
                        "w": 800,
                        "h": 800,
                        "ip": 0,
                        "op": 150.000006109625,
                        "st": 0,
                        "bm": 0
                    }
                ],
                "markers": [

                ]
            }
            var params = {
                container: document.getElementById('lottie'),
                renderer: 'svg',
                loop: true,
                autoplay: true,
                animationData: animationData
            };
            var anim;
            anim = lottie.loadAnimation(params);
            if (selectedData == undefined) {
                document.getElementById('data_full_name').innerText = ss.address_array[0].full_name.split(' ')[0] + " " + ss.address_array[0].full_name.split(' ')[1];
                document.getElementById('data_address_line_one').innerText = useAddres.address_line1;
                document.getElementById('data_address_line_two').innerText = ss.address_array[0].full_name.split(' ')[2];
                document.getElementById('data_city').innerText = useAddres.city;
                document.getElementById('data_state').innerText = 'Delaware';
                document.getElementById('data_zip_code').innerText = useAddres.zip_code;
                document.getElementById('data_zip_country').innerText = useAddres.country;
                document.getElementById('data_zip_phone').innerText = useAddres.phone_number;
            } else {
                document.getElementById('data_full_name').innerText = selectedData.full_name.split(' ')[0] + " " + selectedData.full_name.split(' ')[1];
                document.getElementById('data_address_line_one').innerText = useAddres.address_line1;
                document.getElementById('data_address_line_two').innerText = selectedData.full_name.split(' ')[2];
                document.getElementById('data_city').innerText = useAddres.city;
                document.getElementById('data_state').innerText = 'Delaware';
                document.getElementById('data_zip_code').innerText = useAddres.zip_code;
                document.getElementById('data_zip_country').innerText = useAddres.country;
                document.getElementById('data_zip_phone').innerText = useAddres.phone_number;
            }

        }, 2000)



    });

    document.getElementById("cbx").addEventListener('change', (event) => {
        if (document.getElementById("cbx").checked) {
            document.querySelector('#put-address').disabled = false
            document.getElementById("carters").checked = false;
            document.getElementById("bh").checked = false;
            document.getElementById("rockauto").checked = false;
            document.getElementById("sixpm").checked = false;
            document.querySelector('#put-address').classList.add("mystyle");
            document.getElementById("cbx").checked = true;
        } else {
            document.querySelector('#put-address').disabled = true;
            document.querySelector('#put-address').classList.remove("mystyle");
        }
    });

    document.getElementById("carters").addEventListener('change', (event) => {
        if (document.getElementById("carters").checked) {
            document.getElementById("cbx").checked = false;
            document.getElementById("bh").checked = false;
            document.getElementById("rockauto").checked= false;
            document.getElementById("sixpm").checked = false;
            document.querySelector('#put-address').disabled = false
            document.querySelector('#put-address').classList.add("mystyle");
        } else {
            document.querySelector('#put-address').disabled = true;
            document.querySelector('#put-address').classList.remove("mystyle");
        }
    });

    document.getElementById("sixpm").addEventListener('change', (event) => {
        if (document.getElementById("sixpm").checked) {
            document.getElementById("cbx").checked = false;
            document.getElementById("carters").checked = false;
            document.getElementById("rockauto").checked = false;
            document.getElementById("bh").checked = false;
            document.querySelector('#put-address').disabled = false
            document.querySelector('#put-address').classList.add("mystyle");
        } else {
            document.querySelector('#put-address').disabled = true;
            document.querySelector('#put-address').classList.remove("mystyle");
        }
    });
    document.getElementById("bh").addEventListener('change', (event) => {
        if (document.getElementById("bh").checked) {
            document.getElementById("cbx").checked = false;
            document.getElementById("rockauto").checked= false;
            document.getElementById("carters").checked = false;
            document.getElementById("sixpm").checked = false;
            document.querySelector('#put-address').disabled = false
            document.querySelector('#put-address').classList.add("mystyle");
        } else {
            document.querySelector('#put-address').disabled = true;
            document.querySelector('#put-address').classList.remove("mystyle");
        }
    });

    document.getElementById("rockauto").addEventListener('change', (event) => {
        if (document.getElementById("rockauto").checked) {
            document.getElementById("bh").checked= false;
            document.getElementById("cbx").checked = false;
            document.getElementById("carters").checked = false;
            document.getElementById("sixpm").checked = false;
            document.querySelector('#put-address').disabled = false
            document.querySelector('#put-address').classList.add("mystyle");
        } else {
            document.querySelector('#put-address').disabled = true;
            document.querySelector('#put-address').classList.remove("mystyle");
        }
    });

}, false)



$('.rew_slider').slick({
    dots: true,
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    adaptiveHeight: true,
})


chrome.storage.local.get(['active'], (res) => {
    $('#closeSlider').on('click', () => {
        chrome.storage.local.set({ 'active': true }, (req) => {

        })
        $('#wrapper_slider').css("display", "none");
        $('#wrapper').css("display", "block");
    })

    if (res.active) {
        $('#wrapper_slider').css("display", "none");
        $('#wrapper').css("display", "block");
    }
})

chrome.storage.sync.get(['cartersEdite'], (res) => {
})








