chrome.tabs.onActivated.addListener((message)=>{
  chrome.tabs.query({'active': true}, function (tabs) {
    console.log(tabs[0].url)
    if(tabs[0]){
      if(tabs[0].url.match(/onex.*/) || tabs[0].url.match(/amazon.*/) || tabs[0].url.match(/carters.*/) ||  tabs[0].url.match(/shopdisney.*/) || tabs[0].url.match(/rockauto.*/)|| tabs[0].url.match(/bhphotovideo.*/)){
        chrome.tabs.sendMessage(tabs[0].id, {
          activeChanges: tabs[0].url.match(/http(s?)\:\/\/[^\/]*/)[0]}, function(response) {var error = chrome.runtime.lastError;}); 
        }
      }
    });
  })
