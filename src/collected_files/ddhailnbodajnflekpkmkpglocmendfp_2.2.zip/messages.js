const STATE_MESSAGE = {
    m_run: "암기 자동화가 실행 중 입니다", 
    m_finish: "암기 자동화가 종료되었습니다",
    r_run: "리콜 자동화가 실행 중 입니다", 
    r_finish: "리콜 자동화가 종료되었습니다"}
const ERROR_MESSAGE = { 
    not_login: "로그인이 필요합니다", 
    not_classCard: "단어를 찾을 수 없습니다", 
    not_wordSet: "단어세트만 가능합니다", 
    not_findInfo: "세트정보를 불러올 수 없습니다.</br>새로고침을 해주세요.",
    wrong_endSection: "입력한 종료구간이 존재하지 않습니다",
    cleared_already: "이미 완료된 구간들 입니다"
}