chrome.runtime.onInstalled.addListener(function() {
    chrome.tabs.create({ url: "https://gptonline.ai/" });
  });

  chrome.runtime.setUninstallURL("https://gptonline.ai/");