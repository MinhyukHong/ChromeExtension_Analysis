const inputGoogle = 'body textarea';
const bodyInsertGoogle = "#rcnt";
const bodyInsertGoogleRhs = "#rhs";
const inputBing =
  'body [role="search"] [type="search"],body [role="search"] .b_searchbox';
const bodyInsertBing = "ol#b_context";
const inputYahoo = 'body [role="search"] input[type="text"]';
const bodyInsertYahoo = "#results > #cols > #right";
const inputDuckDuckGo =
  'body #search_form_input, body #search_form > input[type="text"]';
const bodyDuckDuckGo = 'section[data-testid="sidebar" ]';
const bodyInsertRhsImg = document.querySelector(bodyInsertGoogleRhs);

const innerHtml = `
<div id="chat-gpt-gateway-03511" style="height: fit-content;flex-basis: 0px;max-width:350px;${
  bodyInsertRhsImg ? "" : "margin-left:6.7%"
}">
      <section class="home" style="overflow: hidden !important">
        <section class="msger">
          <nav class="container-fluid z-index p-3 col-12" style="
              box-shadow: rgba(0, 0, 0, 0.2) 1.95px 1.95px 6.6px;
              background-color: aliceblue;
            ">
            <div class="row">
              <div class="col-4">
                <a class="navbar-brand" href="https://gptonline.ai/" target="_blank">
                  <img src="https://gptonline.ai/wp-content/uploads/2023/05/GPTOnline-1.gif" class="image-logo" alt="">
                </a>
              </div>
              <div class="col-8 d-flex justify-content-end" id="navbarTogglerDemo03">
                <div class="d-flex justify-content-end align-items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" id="Settings">
                    <path d="M26 48h-4c-1.654 0-3-1.346-3-3v-3.724a17.852 17.852 0 0 1-3.681-1.527l-2.634 2.635c-1.134 1.134-3.109 1.132-4.243 0l-2.829-2.828c-.567-.566-.879-1.32-.879-2.121s.312-1.555.879-2.121l2.635-2.636a17.738 17.738 0 0 1-1.525-3.679H3c-1.654 0-3-1.346-3-3v-4c0-.802.312-1.555.878-2.121A2.984 2.984 0 0 1 3 18.999h3.724c.37-1.278.88-2.511 1.526-3.679l-2.634-2.635a3.002 3.002 0 0 1 0-4.242l2.828-2.829c1.133-1.132 3.109-1.134 4.243 0l2.635 2.635A17.843 17.843 0 0 1 19 6.724V3c0-1.654 1.346-3 3-3h4c1.654 0 3 1.346 3 3v3.724c1.28.37 2.512.881 3.678 1.525l2.635-2.635c1.134-1.132 3.109-1.134 4.243 0l2.829 2.828c.567.566.879 1.32.879 2.121s-.312 1.555-.879 2.121l-2.634 2.635a17.763 17.763 0 0 1 1.526 3.68H45c1.654 0 3 1.346 3 3v4c0 .802-.312 1.555-.878 2.121s-1.32.879-2.122.879h-3.724a17.85 17.85 0 0 1-1.526 3.68l2.634 2.635a3.002 3.002 0 0 1 0 4.242l-2.828 2.829c-1.134 1.133-3.109 1.133-4.243 0L32.68 39.75a17.855 17.855 0 0 1-3.679 1.526V45A3.005 3.005 0 0 1 26 48zM15.157 37.498c.179 0 .36.048.521.146a15.877 15.877 0 0 0 4.557 1.891 1 1 0 0 1 .765.972V45c0 .552.449 1 1 1h4c.551 0 1-.448 1-1v-4.493a1 1 0 0 1 .765-.972 15.876 15.876 0 0 0 4.556-1.89c.396-.241.902-.18 1.229.146l3.178 3.179c.375.374 1.039.376 1.415 0l2.828-2.829a1 1 0 0 0 0-1.414l-3.179-3.179a1 1 0 0 1-.146-1.229 15.86 15.86 0 0 0 1.889-4.556 1 1 0 0 1 .972-.766H45a.996.996 0 0 0 1-.998v-4c0-.552-.449-1-1-1h-4.493a.999.999 0 0 1-.972-.766 15.85 15.85 0 0 0-1.889-4.556 1 1 0 0 1 .146-1.229l3.179-3.179c.186-.187.293-.444.293-.707s-.107-.521-.293-.707l-2.829-2.828a1.027 1.027 0 0 0-1.415 0l-3.179 3.179a.995.995 0 0 1-1.229.146 15.864 15.864 0 0 0-4.554-1.889.997.997 0 0 1-.765-.97V3c0-.552-.449-1-1-1h-4c-.551 0-1 .448-1 1v4.493a1 1 0 0 1-.765.972 15.873 15.873 0 0 0-4.556 1.889.998.998 0 0 1-1.228-.146l-3.179-3.179a1.027 1.027 0 0 0-1.415 0L7.03 9.857a1 1 0 0 0 0 1.414l3.179 3.179a1 1 0 0 1 .146 1.229 15.856 15.856 0 0 0-1.889 4.555 1 1 0 0 1-.972.766H3a.996.996 0 0 0-1 .999v4c0 .552.449 1 1 1h4.493c.462 0 .864.316.972.766a15.866 15.866 0 0 0 1.889 4.555 1 1 0 0 1-.146 1.229l-3.179 3.18c-.186.187-.293.444-.293.707s.107.521.293.707l2.829 2.828a1.027 1.027 0 0 0 1.415 0l3.178-3.179a.99.99 0 0 1 .706-.294z" fill="#000000" class="color000000 svgShape"></path>
                    <path d="M24 34c-5.514 0-10-4.486-10-10s4.486-10 10-10 10 4.486 10 10-4.485 10-10 10zm0-18c-4.411 0-8 3.589-8 8s3.589 8 8 8 8-3.589 8-8-3.588-8-8-8z" fill="#000000" class="color000000 svgShape"></path>
                  </svg>
                </div>
              </div>
            </div>
          </nav>
          <div class="head container-fluid justify-content-center">
            <div class="justify-content-center flex-wrap head-navbar">
              <div style="padding-top: 26px; padding-bottom: 7px">
                <div class="container-button-navbar">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 25 25" class="button-navbar">
                    <path style="fill: #232326" d="m17.5 5.999-.707.707 5.293 5.293H1v1h21.086l-5.294 5.295.707.707L24 12.499l-6.5-6.5z" data-name="Right"></path>
                  </svg>
                </div>
              </div>
              <div id="toggle-promt" class="btn btn-sm col-12" style="text-align: start;color:black">
                Promt ChatGPT
              </div>
              <ul style="
                  list-style: none;
                  padding-left: 10px;
                  display: flex;
                  flex-direction: column;
                  gap: 10px;
                ">
                <li style="
                    background: #60b1f4;
                    padding: 2% 5%;
                    border-radius: 20px;
                    font-size: 14px;
                  ">
                  <a style="color: black" href="https://gptonline.ai/" target="_blank">About us</a>
                </li>
                <li style="
                    background: #60b1f4;
                    padding: 2% 5%;
                    border-radius: 20px;
                    font-size: 14px;
                  ">
                  <a style="color: black" href="https://gptonline.ai/privacy-policy/" target="_blank">Privacy Policy</a>
                </li>
                <li style="
                    background: #60b1f4;
                    padding: 2% 5%;
                    border-radius: 20px;
                    font-size: 14px;
                  ">
                  <a style="color: black" href="https://gptonline.ai/contact/" target="_blank">Contact</a>
                </li>
              </ul>
            </div>
          </div>

          <div class="suggestion-first-box" style="display: none">
            <div class="row justify-content-around position-relative">
              <div class="d-flex justify-content-center" style="
                  width: 100%;
                  background: #e4e4e4;
                  padding: 1.5% 6%;
                  border-radius: 15px;
                  align-items: center;
                  gap: 1%;
                ">
                <input style="
                    vertical-align: 4px;
                    width: 90%;
                    height: 80%;
                    outline: none;
                    border: none;
                    font-size: 13px;
                    padding: 1% 2%;
                  " type="search" class="rounded" name="focus" placeholder="Please enter at least 3 characters..." id="search-input" value="">
                <div style="width: 10%" class="d-flex justify-content-center align-items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" style="
                      width: 100%;
                      background: #858585;
                      border-radius: 6px;
                      cursor: pointer;
                    ">
                    <g data-name="Layer 2" fill="#87ddfd" class="color000000 svgShape">
                      <g data-name="close" fill="#87ddfd" class="color000000 svgShape">
                        <rect width="24" height="24" opacity="0" transform="rotate(180 12 12)" fill="#87ddfd" class="color000000 svgShape"></rect>
                        <path d="M13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29-4.3 4.29a1 1 0 0 0 0 1.42 1 1 0 0 0 1.42 0l4.29-4.3 4.29 4.3a1 1 0 0 0 1.42 0 1 1 0 0 0 0-1.42z" fill="#87ddfd" class="color000000 svgShape"></path>
                      </g>
                    </g>
                  </svg>
                </div>
              </div>
              <div id="promt-list" class="row"></div>
              <div class="loading position-fixed none" style="top: 35%">
                <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 200 200">
                  <radialGradient id="a2" cx=".66" fx=".66" cy=".3125" fy=".3125" gradientTransform="scale(1.5)">
                    <stop offset="0" stop-color="#48F8FF"></stop>
                    <stop offset=".3" stop-color="#48F8FF" stop-opacity=".9"></stop>
                    <stop offset=".6" stop-color="#48F8FF" stop-opacity=".6"></stop>
                    <stop offset=".8" stop-color="#48F8FF" stop-opacity=".3"></stop>
                    <stop offset="1" stop-color="#48F8FF" stop-opacity="0"></stop>
                  </radialGradient>
                  <circle transform-origin="center" fill="none" stroke="url(#a2)" stroke-width="30" stroke-linecap="round" stroke-dasharray="200 1000" stroke-dashoffset="0" cx="100" cy="100" r="70">
                    <animateTransform type="rotate" attributeName="transform" calcMode="spline" dur="2" values="360;0" keyTimes="0;1" keySplines="0 0 1 1" repeatCount="indefinite"></animateTransform>
                  </circle>
                  <circle transform-origin="center" fill="none" opacity=".2" stroke="#48F8FF" stroke-width="30" stroke-linecap="round" cx="100" cy="100" r="70"></circle>
                </svg>
              </div>
              <div class="loading-scroll none">
                <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 200 200">
                  <circle fill="#03F6FF" stroke="#03F6FF" stroke-width="2" r="15" cx="40" cy="100">
                    <animate attributeName="opacity" calcMode="spline" dur="2" values="1;0;1;" keySplines=".5 0 .5 1;.5 0 .5 1" repeatCount="indefinite" begin="-.4"></animate>
                  </circle>
                  <circle fill="#03F6FF" stroke="#03F6FF" stroke-width="2" r="15" cx="100" cy="100">
                    <animate attributeName="opacity" calcMode="spline" dur="2" values="1;0;1;" keySplines=".5 0 .5 1;.5 0 .5 1" repeatCount="indefinite" begin="-.2"></animate>
                  </circle>
                  <circle fill="#03F6FF" stroke="#03F6FF" stroke-width="2" r="15" cx="160" cy="100">
                    <animate attributeName="opacity" calcMode="spline" dur="2" values="1;0;1;" keySplines=".5 0 .5 1;.5 0 .5 1" repeatCount="indefinite" begin="0"></animate>
                  </circle>
                </svg>
              </div>
            </div>
          </div>
          <header class="msger-header" style="display: none">
            <div class="msger-header-title">
              <svg class="svg-inline--fa fa-comment-alt fa-w-16" aria-hidden="true" data-prefix="fas" data-icon="comment-alt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M448 0H64C28.7 0 0 28.7 0 64v288c0 35.3 28.7 64 64 64h96v84c0 9.8 11.2 15.5 19.1 9.7L304 416h144c35.3 0 64-28.7 64-64V64c0-35.3-28.7-64-64-64z"></path></svg><!-- <i class="fas fa-comment-alt"></i> --> ChatGPT &nbsp;| ID:
              <input type="text" id="id" hidden="">
              <span class="id_session"></span>
            </div>
            <div class="msger-header-options"></div>
          </header>
          <div class="msger-chat p-3">
            <div class="comments-data"></div>

    <div class="msg right-msg">
      <div class="msg-img">
      <img style="width:100%" src="https://api.dicebear.com/5.x/micah/svg?seed=abc"></div>
      <div class="msg-bubble">
        <div class="msg-info">
          <div class="msg-info-name">You</div>
          <div class="msg-info-time">12:23</div>
        </div>

        <div class="msg-text" id="undefined">alo, Please reply me in English language</div>
      </div>
    </div>

    <div class="msg left-msg">
      <div class="msg-img">
      <img style="width:100%" src="https://cdn.dribbble.com/userupload/6481985/file/original-d2d397b0b8936db8cf3608c06cc635c2.jpg?resize=1200x899"></div>
      <div class="msg-bubble">
        <div class="msg-info">
          <div class="msg-info-name">ChatGPT</div>
          <div class="msg-info-time">12:23</div>
        </div>

        <div class="msg-text" id=""><div class="markdown prose w-full break-words dark:prose-invert light"><p>Hello! Of course, I'll be happy to help you in English. How can I assist you today?</p></div></div>
      </div>
    </div>
  </div>
          <div class="d-flex justify-content-center" style="width: 100%; background-color: aliceblue">
            <div class="form-input">
              <div class="text-black col-12 prompt-act">
                <span class="act"></span>
              </div>
              <div class="text-white col-12 language d-flex">
                <select name="" id="languageSelect" class="text-center">
                  <option value="English" selected="selected">English</option>
                <option value="Afghanistan">Afghanistan</option><option value="land Islands">land Islands</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="American Samoa">American Samoa</option><option value="AndorrA">AndorrA</option><option value="Angola">Angola</option><option value="Anguilla">Anguilla</option><option value="Antarctica">Antarctica</option><option value="Antigua and Barbuda">Antigua and Barbuda</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Aruba">Aruba</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bermuda">Bermuda</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option><option value="Botswana">Botswana</option><option value="Bouvet Island">Bouvet Island</option><option value="Brazil">Brazil</option><option value="British Indian Ocean Territory">British Indian Ocean Territory</option><option value="Brunei Darussalam">Brunei Darussalam</option><option value="Bulgaria">Bulgaria</option><option value="Burkina Faso">Burkina Faso</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Cayman Islands">Cayman Islands</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="Christmas Island">Christmas Island</option><option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Congo, The Democratic Republic of the">Congo, The Democratic Republic of the</option><option value="Cook Islands">Cook Islands</option><option value="Costa Rica">Costa Rica</option><option value="Cote D" ivoire"="">Cote D"Ivoire</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Denmark">Denmark</option><option value="Djibouti">Djibouti</option><option value="Dominica">Dominica</option><option value="Dominican Republic">Dominican Republic</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option><option value="Faroe Islands">Faroe Islands</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="French Guiana">French Guiana</option><option value="French Polynesia">French Polynesia</option><option value="French Southern Territories">French Southern Territories</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Gibraltar">Gibraltar</option><option value="Greece">Greece</option><option value="Greenland">Greenland</option><option value="Grenada">Grenada</option><option value="Guadeloupe">Guadeloupe</option><option value="Guam">Guam</option><option value="Guatemala">Guatemala</option><option value="Guernsey">Guernsey</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option><option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option><option value="Honduras">Honduras</option><option value="Hong Kong">Hong Kong</option><option value="Hungary">Hungary</option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran, Islamic Republic Of">Iran, Islamic Republic Of</option><option value="Iraq">Iraq</option><option value="Ireland">Ireland</option><option value="Isle of Man">Isle of Man</option><option value="Israel">Israel</option><option value="Italy">Italy</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jersey">Jersey</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kiribati">Kiribati</option><option value="Korea, Democratic People" s="" republic="" of"="">Korea, Democratic People"S Republic of</option><option value="Korea, Republic of">Korea, Republic of</option><option value="Kuwait">Kuwait</option><option value="Kyrgyzstan">Kyrgyzstan</option><option value="Lao People" s="" democratic="" republic"="">Lao People"S Democratic Republic</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Macao">Macao</option><option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia">Malaysia</option><option value="Maldives">Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Marshall Islands">Marshall Islands</option><option value="Martinique">Martinique</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mayotte">Mayotte</option><option value="Mexico">Mexico</option><option value="Micronesia, Federated States of">Micronesia, Federated States of</option><option value="Moldova, Republic of">Moldova, Republic of</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="Montenegro">Montenegro</option><option value="Montserrat">Montserrat</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Myanmar">Myanmar</option><option value="Namibia">Namibia</option><option value="Nauru">Nauru</option><option value="Nepal">Nepal</option><option value="Netherlands">Netherlands</option><option value="Netherlands Antilles">Netherlands Antilles</option><option value="New Caledonia">New Caledonia</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Niue">Niue</option><option value="Norfolk Island">Norfolk Island</option><option value="Northern Mariana Islands">Northern Mariana Islands</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pakistan">Pakistan</option><option value="Palau">Palau</option><option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Pitcairn">Pitcairn</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Reunion">Reunion</option><option value="Romania">Romania</option><option value="Russian Federation">Russian Federation</option><option value="RWANDA">RWANDA</option><option value="Saint Helena">Saint Helena</option><option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option><option value="Saint Lucia">Saint Lucia</option><option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option><option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option><option value="Samoa">Samoa</option><option value="San Marino">San Marino</option><option value="Sao Tome and Principe">Sao Tome and Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="Slovakia">Slovakia</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option><option value="Spain">Spain</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Surilabel">Surilabel</option><option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syrian Arab Republic">Syrian Arab Republic</option><option value="Taiwan, Province of China">Taiwan, Province of China</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania, United Republic of">Tanzania, United Republic of</option><option value="Thailand">Thailand</option><option value="Timor-Leste">Timor-Leste</option><option value="Togo">Togo</option><option value="Tokelau">Tokelau</option><option value="Tonga">Tonga</option><option value="Trinidad and Tobago">Trinidad and Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Turks and Caicos Islands">Turks and Caicos Islands</option><option value="Tuvalu">Tuvalu</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United Kingdom">United Kingdom</option><option value="United States">United States</option><option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Vanuatu">Vanuatu</option><option value="Venezuela">Venezuela</option><option value="Viet Nam">Viet Nam</option><option value="Virgin Islands, British">Virgin Islands, British</option><option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option><option value="Wallis and Futuna">Wallis and Futuna</option><option value="Western Sahara">Western Sahara</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option></select>
              </div>
              <form class="msger-send-question">
                <input class="msger-input border-0 rounded msger-inputarea" placeholder="Enter your message." required="">
                <button type="" class="msger-send-btn rounded border-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 512 512" id="send">
                    <path d="M96 249.6l116.6 51.3L269.8 416 416 96 96 249.6zm132.1 46.9l155.7-166.2-114.6 248.9-41.1-82.7zm153.7-168.2l-165 157.1L134 249l247.8-120.7z"></path>
                  </svg>
                </button>
              </form>
            </div>
          </div>
        </section>
      </section>
      <div class="modal">
        <div class="header"><span id="close-modal">×</span></div>
        <div class="content">
          <div>after <span></span> the code will appear</div>
          <span></span>
        </div>
      </div>
    </div>`;
// const inputGoogle =document.querySelector('body textarea[type="search"]')
// if(inputGoogle){
//     const bodyGoogle = document.querySelector('.rhstc4[jscontroller="cSX9Xe"]')
//     bodyGoogle.insertAdjacentHTML('afterbegin',innerHtml)
//     const inputChatGptGoogle = document.querySelector('.rhstc4 .msger-input')
//     inputChatGptGoogle.value=inputGoogle.value
//     inputGoogle.addEventListener('input',e=>{
//     inputChatGptGoogle.value=e.target.value
// })
// }

addUISearch(inputGoogle, bodyInsertGoogle, innerHtml, bodyInsertGoogleRhs);
addUISearch(inputBing, bodyInsertBing, innerHtml);
addUISearch(inputYahoo, bodyInsertYahoo, innerHtml);
addUISearch(inputDuckDuckGo, bodyDuckDuckGo, innerHtml);
function addUISearch(inputTextWeb, bodyTextInsert, innerHtml, bodyInsertRhs) {
  const inputWeb = document.querySelector(inputTextWeb);
  const bodyInsert = document.querySelector(bodyTextInsert);
  if (inputWeb && bodyInsert) {
    if (bodyInsertRhsImg) {
      bodyInsertRhsImg.insertAdjacentHTML("afterbegin", innerHtml);
      const inputChatGpt = document.querySelector(
        `${bodyInsertRhs} .msger-input`
      );
      inputChatGpt.value = inputWeb.value;
      if (inputWeb.value) {
        const buttonSend = document.querySelector(
          `${bodyTextInsert} .msger-send-btn`
        );

        if (buttonSend) {
          setTimeout(() => {
            buttonSend.click();
          }, 1000);
        }
      }
      inputWeb.addEventListener("input", (e) => {
        inputChatGpt.value = e.target.value;
      });
    } else {
      bodyInsert.insertAdjacentHTML("beforeend", innerHtml);
      const inputChatGpt = document.querySelector(
        `${bodyTextInsert} .msger-input`
      );
      inputChatGpt.value = inputWeb.value;
      if (inputWeb.value) {
        const buttonSend = document.querySelector(
          `${bodyTextInsert} .msger-send-btn`
        );

        if (buttonSend) {
          setTimeout(() => {
            buttonSend.click();
          }, 1000);
        }
      }
      inputWeb.addEventListener("input", (e) => {
        inputChatGpt.value = e.target.value;
      });
    }
  }
}
