$(document).ready(async function () {
  var x;
  $(".container button").click(function () {
    $(".container").css({ display: "none" });
    $(".form").css({ display: "" });
  });
  $(" .form  .button .GET-OTP").click(async function () {
    $(".form .OTP").css({ display: "" });
    $(".form .button  .Login").css({ display: "" });
    const data = {
      username: $(".form  .email #email").val(),
    };
    await PostOTP(data);
    if ($(".form  .email #email").val()) {
      x = demThoiGian1Phut();
    }
  });
  $(".form .button .Login").click(async function () {
    const data = {
      username: $(".form  .email #email").val(),
      otp: $(".form  .OTP #OTP").val(),
    };
    console.log(x);
    const Login = await PostLogin(data);

    if (Login.accessToken) {
      setCookie("accessToken", Login.accessToken);
      setCookie("refreshToken", Login.refreshToken);
      setCookie("uuid", Login.uuid);
      setCookie("username", Login.username);
      $(".form").css({ display: "none" });
      $(".home").removeClass("none");
      if ($(".home").attr("class").includes("none") == false) {
        const accessTok = await chrome.cookies.get({
          url: "https://google.com/",
          name: "accessToken",
        });
        const refreshTok = await chrome.cookies.get({
          url: "https://google.com/",
          name: "accessToken",
        });
        await isTokenExpired(accessTok.value, refreshTok.value);
      }
      $(".form  .email #email").val("");
      $(".form  .OTP #OTP").val("");
      clearInterval(x);
      document.querySelector(" .form  .button .GET-OTP span").innerHTML = "";
      console.log(await getCookies("accessToken"));
    }
  });

  async function PostOTP(data) {
    const rawResponse = await fetch(
      "https://chatt.gptonline.ai/auth/request-otp",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      }
    );
    const dataJson = await rawResponse.json();
    return dataJson;
  }
  async function PostLogin(data) {
    const rawResponse = await fetch("https://chatt.gptonline.ai/auth/login", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
    const dataJson = await rawResponse.json();
    return dataJson;
  }
  async function refreshToken(accessTok, refreshTok) {
    const refreshToke = await fetch(
      "https://chatt.gptonline.ai/auth/refresh   ",
      {
        method: "POST",
        headers: { Authorization: accessTok },
      },
      refreshTok
    );
    const data = await refreshToke.json();
    setCookie("accessToken", data.accessTok);
    return data;
  }
  function setCookie(name, value) {
    var cookieDetails = {
      url: `https://google.com/`,
      name: name,
      value: value,
      expirationDate: new Date().getTime() / 1000 + 3600 * 24,
      path: "/",
    };
    chrome.cookies.set(cookieDetails, function (cookie) {});
  }
  async function isTokenExpired(accessTok, refreshTok) {
    if (!accessTok) {
      const refresh = await refreshToken(accessTok, refreshTok);
      return refresh;
    } else {
      console.log("refresh failed. ");
    }
  }
  function demThoiGian1Phut() {
    var thoiGianBatDau = new Date().getTime();
    var thoiGianKetThuc = thoiGianBatDau + 60000; // 60000 milliseconds là 1 phút

    var x = setInterval(function () {
      var thoiGianHienTai = new Date().getTime();
      var thoiGianConLai = thoiGianKetThuc - thoiGianHienTai;

      var phut = Math.floor((thoiGianConLai % (1000 * 60 * 60)) / (1000 * 60));
      var giay = Math.floor((thoiGianConLai % (1000 * 60)) / 1000);

      document.querySelector(" .form  .button .GET-OTP span").innerHTML =
        "(" + phut + ":" + (giay < 10 ? "0" : "") + giay + ")";

      if (thoiGianConLai <= 0) {
        clearInterval(x);
        document.querySelector(" .form  .button .GET-OTP span").innerHTML =
          "(0:00)";
      }
    }, 1000);
    return x;
  }
  async function getCookies(name) {
    const cookie = await chrome.cookies.get({
      url: "https://google.com/",
      name: name,
    });
    // const data = await cookie.value
    return cookie.value;
  }
});
