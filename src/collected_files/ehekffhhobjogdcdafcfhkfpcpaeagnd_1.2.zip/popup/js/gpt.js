const dataLanguage = [
  "Afghanistan",
  "land Islands",
  "Albania",
  "Algeria",
  "American Samoa",
  "AndorrA",
  "Angola",
  "Anguilla",
  "Antarctica",
  "Antigua and Barbuda",
  "Argentina",
  "Armenia",
  "Aruba",
  "Australia",
  "Austria",
  "Azerbaijan",
  "Bahamas",
  "Bahrain",
  "Bangladesh",
  "Barbados",
  "Belarus",
  "Belgium",
  "Belize",
  "Benin",
  "Bermuda",
  "Bhutan",
  "Bolivia",
  "Bosnia and Herzegovina",
  "Botswana",
  "Bouvet Island",
  "Brazil",
  "British Indian Ocean Territory",
  "Brunei Darussalam",
  "Bulgaria",
  "Burkina Faso",
  "Burundi",
  "Cambodia",
  "Cameroon",
  "Canada",
  "Cape Verde",
  "Cayman Islands",
  "Central African Republic",
  "Chad",
  "Chile",
  "China",
  "Christmas Island",
  "Cocos (Keeling) Islands",
  "Colombia",
  "Comoros",
  "Congo",
  "Congo, The Democratic Republic of the",
  "Cook Islands",
  "Costa Rica",
  'Cote D"Ivoire',
  "Croatia",
  "Cuba",
  "Cyprus",
  "Czech Republic",
  "Denmark",
  "Djibouti",
  "Dominica",
  "Dominican Republic",
  "Ecuador",
  "Egypt",
  "El Salvador",
  "Equatorial Guinea",
  "Eritrea",
  "Estonia",
  "Ethiopia",
  "Falkland Islands (Malvinas)",
  "Faroe Islands",
  "Fiji",
  "Finland",
  "France",
  "French Guiana",
  "French Polynesia",
  "French Southern Territories",
  "Gabon",
  "Gambia",
  "Georgia",
  "Germany",
  "Ghana",
  "Gibraltar",
  "Greece",
  "Greenland",
  "Grenada",
  "Guadeloupe",
  "Guam",
  "Guatemala",
  "Guernsey",
  "Guinea",
  "Guinea-Bissau",
  "Guyana",
  "Haiti",
  "Heard Island and Mcdonald Islands",
  "Holy See (Vatican City State)",
  "Honduras",
  "Hong Kong",
  "Hungary",
  "Iceland",
  "India",
  "Indonesia",
  "Iran, Islamic Republic Of",
  "Iraq",
  "Ireland",
  "Isle of Man",
  "Israel",
  "Italy",
  "Jamaica",
  "Japan",
  "Jersey",
  "Jordan",
  "Kazakhstan",
  "Kenya",
  "Kiribati",
  'Korea, Democratic People"S Republic of',
  "Korea, Republic of",
  "Kuwait",
  "Kyrgyzstan",
  'Lao People"S Democratic Republic',
  "Latvia",
  "Lebanon",
  "Lesotho",
  "Liberia",
  "Libyan Arab Jamahiriya",
  "Liechtenstein",
  "Lithuania",
  "Luxembourg",
  "Macao",
  "Macedonia, The Former Yugoslav Republic of",
  "Madagascar",
  "Malawi",
  "Malaysia",
  "Maldives",
  "Mali",
  "Malta",
  "Marshall Islands",
  "Martinique",
  "Mauritania",
  "Mauritius",
  "Mayotte",
  "Mexico",
  "Micronesia, Federated States of",
  "Moldova, Republic of",
  "Monaco",
  "Mongolia",
  "Montenegro",
  "Montserrat",
  "Morocco",
  "Mozambique",
  "Myanmar",
  "Namibia",
  "Nauru",
  "Nepal",
  "Netherlands",
  "Netherlands Antilles",
  "New Caledonia",
  "New Zealand",
  "Nicaragua",
  "Niger",
  "Nigeria",
  "Niue",
  "Norfolk Island",
  "Northern Mariana Islands",
  "Norway",
  "Oman",
  "Pakistan",
  "Palau",
  "Palestinian Territory, Occupied",
  "Panama",
  "Papua New Guinea",
  "Paraguay",
  "Peru",
  "Philippines",
  "Pitcairn",
  "Poland",
  "Portugal",
  "Puerto Rico",
  "Qatar",
  "Reunion",
  "Romania",
  "Russian Federation",
  "RWANDA",
  "Saint Helena",
  "Saint Kitts and Nevis",
  "Saint Lucia",
  "Saint Pierre and Miquelon",
  "Saint Vincent and the Grenadines",
  "Samoa",
  "San Marino",
  "Sao Tome and Principe",
  "Saudi Arabia",
  "Senegal",
  "Serbia",
  "Seychelles",
  "Sierra Leone",
  "Singapore",
  "Slovakia",
  "Slovenia",
  "Solomon Islands",
  "Somalia",
  "South Africa",
  "South Georgia and the South Sandwich Islands",
  "Spain",
  "Sri Lanka",
  "Sudan",
  "Surilabel",
  "Svalbard and Jan Mayen",
  "Swaziland",
  "Sweden",
  "Switzerland",
  "Syrian Arab Republic",
  "Taiwan, Province of China",
  "Tajikistan",
  "Tanzania, United Republic of",
  "Thailand",
  "Timor-Leste",
  "Togo",
  "Tokelau",
  "Tonga",
  "Trinidad and Tobago",
  "Tunisia",
  "Turkey",
  "Turkmenistan",
  "Turks and Caicos Islands",
  "Tuvalu",
  "Uganda",
  "Ukraine",
  "United Arab Emirates",
  "United Kingdom",
  "United States",
  "United States Minor Outlying Islands",
  "Uruguay",
  "Uzbekistan",
  "Vanuatu",
  "Venezuela",
  "Viet Nam",
  "Virgin Islands, British",
  "Virgin Islands, U.S.",
  "Wallis and Futuna",
  "Western Sahara",
  "Yemen",
  "Zambia",
  "Zimbabwe",
];

$(document).ready(function () {
  const msgerForm = get(".msger-send-question");
  const msgerInput = get(".msger-input");
  const msgerChat = get(".msger-chat");
  const msgerSendBtn = get(".msger-send-btn");

  const BOT_IMG =
    "https://cdn.dribbble.com/userupload/6481985/file/original-d2d397b0b8936db8cf3608c06cc635c2.jpg?resize=25x25";
  const PERSON_IMG = "https://api.dicebear.com/5.x/micah/svg?seed=abc";
  const BOT_NAME = "ChatGPT";
  const PERSON_NAME = "You";

  let isClickItemPromt = true;

  let uuid;
  let countPrompt = 1;
  let countPromptSearch = 1;
  var socket = io("https://chatt.gptonline.ai", {
    path: "/socket.io",
    transports: ["websocket"],
  });
  let check = false;
  window.mobileCheck = function () {
    (function (a) {
      if (
        /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(
          a
        ) ||
        /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(
          a.substr(0, 4)
        )
      )
        check = true;
    })(navigator.userAgent || navigator.vendor || window.opera);
    return check;
  };
  if (window.innerWidth < 576) {
    $(".sidebar").addClass("close");
  }
  async function getPromt(page) {
    fetch(`https://access.gptonline.ai/GPTPrompt?page=${page}`)
      .then((res) => res.json())
      .then((data) => {
        for (let index = 0; index < data.length; index++) {
          let promtFix = data[index].prompts.replace(/<[^>]+>/g, "");
          var divCon = document.createElement("div");
          divCon.classList.add("col-12", "btn");
          divCon.innerHTML = `
          <div class="promt-item h-100" data-prompt-hint="${data[index].prompt_hint}" 
          data-value-act="${data[index].title}" data-value='${promtFix}'>
          <span style="font-size: 14px;white-space: break-spaces;">${data[index].title}</span>
          <span class="none" id=""></span>
      </div>
        `;
          divCon
            .querySelector(".promt-item")
            .addEventListener("click", function () {
              isClickItemPromt = false;
              countPrompt = 1;
              countPromptSearch = 1;
              document.querySelector("#promt-list").innerHTML = "";
              $(".suggestion-first-box").toggle("show");
              $(".msger-input").attr(
                "placeholder",
                $(this).attr("data-prompt-hint")
              );
              $(".prompt-act .act").addClass("p-1");
              const modelClose =
                '<svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 64 64"  viewBox="0 0 64 64" id="Close"><g transform="translate(378 278)" fill="#000000" class="color000000 svgShape"><path fill="#000000" d="m-356.3-233.8-1.9-1.9 22.6-22.6 1.9 1.9-22.6 22.6" class="color134563 svgShape"></path><path fill="#000000" d="m-335.6-233.8-22.6-22.6 1.9-1.9 22.6 22.6-1.9 1.9" class="color134563 svgShape"></path></g></svg>';
              $(".prompt-act .act").html(
                `<span style="color:black" class="suggest" data-value='${$(
                  this
                ).attr("data-value")}'   >${$(this).attr(
                  "data-value-act"
                )}</span> ${modelClose} `
              );
              $(".prompt-act .hello").addClass("none");
              $(".prompt-act .act svg").click(function () {
                msgerInput.value = "";
                msgerInput.placeholder = "";
                $(".prompt-act .act").html("");
                $(".prompt-act .hello").removeClass("none");
                $(".prompt-act .act").removeClass("p-1");
              });
            });
          document.getElementById("promt-list").appendChild(divCon);
        }
        $(".suggestion-first-box").on("scroll", functionCallPromt);
      });
  }
  getLanguage();
  async function noneLoadingBottom() {
    $(".loading-scroll").addClass("none");
  }
  const togglePromt = document.querySelector("#toggle-promt");
  togglePromt &&
    togglePromt.addEventListener("click", async () => {
      isClickItemPromt = true;
      $(".suggestion-first-box").toggle("show");
      await getPromt(1);
    });

  var isLoading = false;
  let functionCallPromt = async function () {
    if (!isLoading) {
      let HeightContentScroll = $(".suggestion-first-box")[0].scrollHeight;
      let HeightContent = $(".suggestion-first-box").height();
      let ScrollTop = $(".suggestion-first-box").scrollTop();
      let paddingTopModal = document.getElementsByClassName(
        "suggestion-first-box"
      )[0];
      let computedStyleModal = window.getComputedStyle(paddingTopModal);
      let padding = Math.ceil(parseFloat(computedStyleModal.paddingBottom));
      if (
        HeightContentScroll - ScrollTop - HeightContent <=
        2 * padding + 0.8
      ) {
        $(".suggestion-first-box").off("scroll");
        if ($(".suggestion-first-box input").val() === "") {
          $(".loading-scroll").removeClass("none");
          await sleep(1);
          if (isClickItemPromt) {
            countPrompt++;
            await getPromt(countPrompt);
          }
          await noneLoadingBottom();
        } else {
          isLoading = true;
          let inputValue = $(".suggestion-first-box input").val();
          if (isClickItemPromt) {
            countPromptSearch++;
            await searchPrompt(inputValue, countPromptSearch);
          }
          isLoading = false;
        }
      }
    } else {
      return;
    }
  };
  $(".suggestion-first-box").scroll(functionCallPromt);

  $(".suggestion-first-box svg").click(function () {
    isClickItemPromt = false;
    countPrompt = 1;
    countPromptSearch = 1;
    document.querySelector("#promt-list").innerHTML = "";
    $(".suggestion-first-box input").val("");
    $(".suggestion-first-box").toggle("show");
  });

  $(".suggestion-first-box input").on("input", async function () {
    const inputValue = $(this).val();
    $(".loading").removeClass("none");
    document.querySelector("#promt-list").innerHTML = "";
    countPromptSearch = 1;
    await sleep(2);
    if (inputValue) {
      await searchPrompt(inputValue.toLowerCase(), countPromptSearch);
    } else {
      countPrompt = 1;
      $(".loading").addClass("none");
      document.querySelector("#promt-list").innerHTML = "";
      getPromt(1);
    }
  });
  var USER_ID = "";
  $("body").on("click", ".chat-exam", function () {
    $(".msger-input").val(
      $(this).text().trim().replace(" →", "").replaceAll('"', "")
    );
    $(".msger-input").focus();
  });
  $("#clear-all").click(function () {
    document.cookie = "ids=";
    window.location.href = "/";
  });
  if (getCookie("ids") == "") {
    var ids = [];
    uuid = uuidv4();
    ids.push({ id: uuid, name: "New chat" });
    document.cookie = "ids=" + JSON.stringify(ids);
    $("input#id").val(uuid);
    $(".id_session").text(uuid);
    USER_ID = uuid;
    $("#list-chat").html(genliTabs(uuid, "New chat"));
    $(".nav-link").attr("chat-id", uuid).find("a").addClass("active");
  } else {
    ids = JSON.parse(getCookie("ids"));
    let id = document.getElementById("id");
    if (id) {
      document.getElementById("id").value = ids[0].id;
      USER_ID = ids[0].id;
      $("#list-chat").html("");
      ids.forEach((id) => {
        $("#list-chat").append(genliTabs(id.id, id.name));
      });
      $(".id-tabs:first").addClass("active");
      getHistory();
    }
  }
  $("#add-chat").click(function () {
    if ($(".suggestion-first-box").length > 0) {
      $(".msger-input").focus();
    } else {
      var newEl;
      $("#list-chat li").map((ix, el) => {
        if ($(el).find("span.text").html() == "New chat") {
          newEl = el;
        }
      });
      if (newEl == undefined) {
        uuid = uuidv4();
        ids.push({ id: uuid, name: "New chat" });
        document.cookie = "ids=" + JSON.stringify(ids);
        $("#list-chat li a").removeClass("active");
        $("#list-chat").append(genliTabs(uuid, "New chat", true));
        document.getElementById("id").value = uuid;
        USER_ID = uuid;
        $(".id_session").text(uuid);
      } else {
        $("#promt-list").hide();
      }
    }
  });
  $("body").on("click", "#list-chat li", function () {
    $("#list-chat li a").removeClass("active");
    $(this).find("a").addClass("active");
    document.getElementById("id").value = $(this).attr("chat-id");
    USER_ID = $(this).attr("chat-id");
    $(".id_session").text(USER_ID);
    getHistory();
  });
  $("body").on("click", ".remove-chat-item", function () {
    var id = $(this).parents("li").attr("chat-id");
    var ids = JSON.parse(getCookie("ids"));
    ids = ids.filter((el, ix) => {
      return el.id != id;
    });
    if (ids.length == 0) {
      document.cookie = "ids=";
    } else {
      document.cookie = "ids=" + JSON.stringify(ids);
    }
    window.location.href = "/";
    $(this).parents("li").remove();
  });
  $("#sign-out").click(function () {
    $(".form").css({ display: "" });
    $(".home").addClass("none");
    clearCookie("accessToken");
    clearCookie("refreshToken");
    clearCookie("uuid");
    clearCookie("username");
  });
  function genliTabs(id, name, active = false) {
    return (
      '<li class="nav-link" chat-id=' +
      id +
      ">" +
      '<a href="#" class="id-tabs ' +
      (active ? "active" : "") +
      '">' +
      "<i class='bx bx-chat icon'></i>" +
      '<span class="text nav-text">' +
      name +
      "</span>" +
      "<i class='remove-chat-item bx bx-trash icon'></i>" +
      "</a>" +
      "</li>"
    );
  }
  function genFirstBox() {
    var promtList = '<div id="promt-list" class="row">';
    suggestions.forEach((el) => {
      promtList +=
        '<div class="col-lg-4 col-md-6  btn" style="white-space: break-spaces;"><div class="promt-item h-100" data-value="' +
        el.prompt +
        '"><span>' +
        el.act +
        "</span></div></div>";
    });
    promtList += "</div>";
    return '<div class="suggestion-first-box">' + promtList + "</div>";
  }
  function getHistory() {
    var page = 0;
    fetch(
      "https://chatt.gptonline.ai/api/chat-gpt-history?uid=" +
        USER_ID +
        "&page=" +
        page
    )
      .then((response) => response.json())
      .then((chatHistory) => {
        if (chatHistory.length > 0) {
          $("main.comments-data").html("");
          for (const row of chatHistory) {
            appendMessage(PERSON_NAME, PERSON_IMG, "right", row.question);
            appendMessage(BOT_NAME, BOT_IMG, "left", row.answer, "");
          }
          $("main .suggestion-first-box").hide();
        } else {
        }
      })
      .catch((error) => console.error(error));
  }

  msgerForm &&
    msgerForm.addEventListener("submit", (e) => {
      e.preventDefault();
      var targetLanguege = $("#languageSelect").val()
        ? $("#languageSelect").val()
        : "England";
      let msgText = "";
      let prompt = $(".prompt-act .act .suggest").attr("data-value");
      if (prompt !== undefined) {
        const index = prompt.indexOf(`_\"\n---\n`);
        const result = prompt.substring(index + '_"\n---\n'.length);
        prompt = result.trim();
        prompt = prompt.replace(/\[PROMPT\]/g, msgerInput.value);
        prompt = prompt.replace(/\[TARGETLANGUAGE\]/g, targetLanguege);
        prompt = prompt.replace(/<[^>]+>/g, "");
        msgText = prompt;
      } else {
        msgText =
          msgerInput.value + `, Please reply me in ${targetLanguege} language`;
      }
      if (!msgText) return;
      appendMessage(PERSON_NAME, PERSON_IMG, "right", msgerInput.value);
      msgerInput.value = "";
      sendMsg(msgText);
      $(".prompt-act .hello").removeClass("none");
    });

  function appendMessage(name, img, side, text, id) {
    const msgHTML = `
    <div class="msg ${side}-msg">
      <div class="msg-img">
      <img src='${img}'/></div>
      <div class="msg-bubble">
        <div class="msg-info">
          <div class="msg-info-name">${name}</div>
          <div class="msg-info-time">${formatDate(new Date())}</div>
        </div>

        <div class="msg-text" id=${id}>${text}</div>
      </div>
    </div>
  `;

    msgerChat.insertAdjacentHTML("beforeend", msgHTML);
    msgerChat.scrollTop += 500;
  }
  function appendGptBox(name, img, side, text, id) {
    const msgHTML = `
        <div class="msg ${side}-msg">
          <div class="msg-img">
          <img src='${img}'/></div>
          <div class="msg-bubble">
            <div class="msg-info">
              <div class="msg-info-name">${name}</div>
              <div class="msg-info-time">${formatDate(new Date())}</div>
            </div>
            <div class="msg-text" id=${id}>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 10%" aria-valuenow="0"
                    aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
          </div>
        </div>
      `;

    msgerChat.insertAdjacentHTML("beforeend", msgHTML);
    msgerChat.scrollTop += 500;
  }

  var progressingIntervalInt = 0;
  var progressingInterval;
  function sendMsg(msg) {
    var newEl = undefined;
    $(".suggestion-first-box").hide();
    msgerSendBtn.disabled = true;
    let uuid = uuidv4();
    socket.emit("send", {
      user_id: USER_ID,
      msg: msg,
      uid: uuid,
      device: check,
      agent: navigator.userAgent,
      lang: document.documentElement.lang,
    });
    appendGptBox(BOT_NAME, BOT_IMG, "left", "", uuid);
    progressingInterval = setInterval(() => {
      if (progressingIntervalInt == 100) {
        clearInterval(progressingInterval);
        return;
      }
      progressingIntervalInt += 10;
      $(".progress-bar").attr("aria-valuenow", progressingIntervalInt);
      $(".progress-bar").css("width", progressingIntervalInt + "%");
    }, 1500);
  }
  var guide = "";
  socket.on("answer", function (data) {
    const div = document.getElementById(data.uid);
    if (!data.success) {
      msgerSendBtn.disabled = false;
    } else {
      msgerSendBtn.disabled = false;
      let txt = data.message;
      if (txt !== undefined) {
        clearInterval(progressingInterval);
        $(".progress-bar").css("width", "100%");
        div.innerHTML = txt.replace(/(?:\r\n|\r|\n)/g, "<br>");
      }
      if (data.guide) {
        guide = data.guide;
      }
    }
  });
  $("body").on("click", ".get-code", function () {
    $(".modal").show();
    $(".modal .content").html(guide);
  });
  $("#close-modal").click(function () {
    $(".modal").hide();
  });
  // Utils
  function get(selector, root = document) {
    return root.querySelector(selector);
  }

  function formatDate(date) {
    const h = "0" + date.getHours();
    const m = "0" + date.getMinutes();

    return `${h.slice(-2)}:${m.slice(-2)}`;
  }
  function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(";");
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) == " ") {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
  function getCookies(name) {
    const cookie = chrome.cookies.get({
      url: "https://google.com/",
      name: name,
    });
    const data = cookie.value;
    return data;
  }
  function uuidv4() {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c) =>
      (
        c ^
        (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))
      ).toString(16)
    );
  }
  function clearCookie(name) {
    chrome.cookies.remove({ url: "https://google.com/", name: name });
  }
  async function searchPrompt(searchString, page) {
    if (searchString.length > 2) {
      const data = await fetch(
        `https://access.gptonline.ai/GPTPrompt/search?word=${searchString}&page=${page}`
      );
      const dataSearch = await data.json();
      if (page == 1) {
        document.querySelector("#promt-list").innerHTML = "";
      }
      $(".loading").addClass("none");

      for (let index = 0; index < dataSearch.length; index++) {
        let promtFix = dataSearch[index].prompts.replace(/<[^>]+>/g, "");
        var divCon = document.createElement("div");
        divCon.classList.add("col-12", "btn");
        divCon.innerHTML = `
          <div class="promt-item h-100" data-prompt-hint="${dataSearch[index].prompt_hint}" 
              data-value-act="${dataSearch[index].title}" data-value='${promtFix}'>
              <span style="font-size: 14px;white-space: break-spaces;">${dataSearch[index].title}</span>
              <span class="none" id=""></span>
          </div>
      `;
        divCon
          .querySelector(".promt-item")
          .addEventListener("click", function () {
            isClickItemPromt = false;
            countPrompt = 1;
            countPromptSearch = 1;
            $(".suggestion-first-box").toggle("show");
            document.querySelector("#promt-list").innerHTML = "";
            $(".suggestion-first-box input").val("");
            $(".msger-input").attr(
              "placeholder",
              $(this).attr("data-prompt-hint")
            );
            $(".prompt-act .act").addClass("p-1");
            const modelClose =
              '<svg xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 64 64"  viewBox="0 0 64 64" id="Close"><g transform="translate(378 278)" fill="#000000" class="color000000 svgShape"><path fill="#000000" d="m-356.3-233.8-1.9-1.9 22.6-22.6 1.9 1.9-22.6 22.6" class="color134563 svgShape"></path><path fill="#000000" d="m-335.6-233.8-22.6-22.6 1.9-1.9 22.6 22.6-1.9 1.9" class="color134563 svgShape"></path></g></svg>';
            $(".prompt-act .act").html(
              `<span style="color:black" class="suggest" data-value='${$(
                this
              ).attr("data-value")}'   >${$(this).attr(
                "data-value-act"
              )}</span> ${modelClose} `
            );
            $(".prompt-act .hello").addClass("none");
            $(".prompt-act .act svg").click(function () {
              document.querySelector("#promt-list").innerHTML = "";
              $(".prompt-act .act").html("");
              $(".prompt-act .hello").removeClass("none");
              $(".prompt-act .act").removeClass("p-1");
            });
          });
        document.getElementById("promt-list").appendChild(divCon);
      }
      $(".suggestion-first-box").on("scroll", functionCallPromt);
    }
  }
  async function clearPromptList() {
    document.querySelector("#prompt-list").innerHTML = "";
  }
  function getLanguage() {
    dataLanguage.map((el) => {
      $("#languageSelect").append(`<option value="${el}">${el}</option>`);
    });
  }
  function sleep(time, log = false) {
    // second
    return new Promise(function (resolve, reject) {
      setTimeout(function () {
        resolve("");
      }, time * 1000);
    });
  }
});
