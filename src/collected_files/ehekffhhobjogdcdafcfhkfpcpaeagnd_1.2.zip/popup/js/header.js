const navbar = document.querySelector("#Settings");
const headNavbar = document.querySelector(".head-navbar");
const open = document.querySelector(".head");
const menuInSidebar = document.querySelector(".button-navbar");
const clickPrompt = document.querySelector("#toggle-promt");

clickPrompt &&
  clickPrompt.addEventListener("click", () => {
    headNavbar.classList.remove("toggle-navbar");
  });
menuInSidebar &&
  menuInSidebar.addEventListener("click", () => {
    headNavbar.classList.remove("toggle-navbar");
  });
menuInSidebar &&
  navbar.addEventListener("click", () => {
    headNavbar.classList.add("toggle-navbar");
  });
