document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('img1').classList.add('active');
    setTimeout(donutAnimation, 1500);
});

function resetAnimation(el) {
    var newone = el.cloneNode(true);
    el.parentNode.replaceChild(newone, el);
    return newone;
}

function donutAnimation(callback, delay) {
    var i = 1;
    const frameIds = ["img1", "img2", "img3", "img4", "img5",];
    const framenames = ["donut1", "donut2", "donut3", "donut4", "broccoli",];
    const classes = [
        "image-container-img",
        "image-container-img-anchored",
        "image-container-img-anchored",
        "image-container-img-anchored",
        "image-container-img-anchored",
    ]
    var intervalID = window.setInterval(function () {
        const donutEl = document.getElementById(frameIds[i]);
        const donutElPrev = document.getElementById(frameIds[i - 1]);
        donutEl.classList.add('active');
        const elClass = classes[i];
        donutEl.classList.remove(elClass);
        donutEl.offsetWidth;
        donutEl.classList.add(elClass);
        donutElPrev.classList.remove('active');
        if (++i === frameIds.length) {
            clearInterval(intervalID);
        }
    }, 300);
}