import { extract_domain } from "./url_util.js";
import { is_tracked } from "./tracking.js";

document.addEventListener('DOMContentLoaded', function() {
    const iconButton = document.querySelector('#icon-button');
    const icon = document.querySelector('#icon');
    const overlay = document.getElementById("overlay");
    const countdown = document.getElementById("countdown-number");

    updateCountdown();

    // Update the countdown timer every second
    setInterval(updateCountdown, 1000);
});

function updateCountdown() {
    const countdown = document.getElementById("countdown-number");
    chrome.storage.local.get(["tabData", "timeout"], function(data) {
        const urls = data.tabData || {"__all__": 0};
        const timeSpent = urls["__all__"] || 0;
        const timeout = data.timeout || 10 * 60;
        // Set the countdown time to 10 minutes
        const timeLeft = timeout - timeSpent;
        const timestep_px = 360 / timeout;
        const new_offset = timeSpent * timestep_px;
        const offset_value = parseInt(
            getComputedStyle(document.documentElement)
                .getPropertyValue('--stroke-dashoffset')
                .replace('px', '')
        );
        document.documentElement.style.setProperty(
            '--stroke-dashoffset',
             new_offset.toString() + 'px'
        );
        // Calculate the minutes, seconds and hours left
        const minutesLeft = Math.floor(timeLeft / 60);
        const secondsLeft = timeLeft % 60;
        // const hoursLeft = Math.floor(timeLeft / 3600);

        // Format the time left as mm:hh:ss
        const formattedTimeLeft = `${String(minutesLeft).padStart(2, '0')}:${String(secondsLeft).padStart(2, '0')}`;
        // Update the countdown timer element
        countdown.textContent = formattedTimeLeft;
    });
}

document.getElementById('settings-icon').onclick = function() {chrome.tabs.create({ url: "./settings.html" });}