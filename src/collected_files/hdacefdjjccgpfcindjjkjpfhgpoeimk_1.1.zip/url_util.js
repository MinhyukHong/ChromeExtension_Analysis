import "./psl.js";

function extract_domain(url) {
    try {
        const domain = psl.parse(new URL(url).host).domain;
        return domain;
    }
    catch(error) {
        logger.warning(error);
        return;
    }
}

export {extract_domain};