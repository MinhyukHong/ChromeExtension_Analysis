import "./psl.js";
import { is_tracked } from "./tracking.js";
import { extract_domain } from "./url_util.js";

let tabData = {"__all__": 0};
let tabCache = {};

chrome.storage.local.get(['urls', 'defaultUrlsChanged'], function(data) {
    if (!data.urls) {
        if (!data.defaultUrlsChanged) {
            data.urls = [
                'youtube.com',
                'twitter.com',
                'reddit.com',
                'tiktok.com',
                'facebook.com',
                'instagram.com',
                'linkedin.com',
            ];
            chrome.storage.local.set({'defaultUrlsChanged': true});
            chrome.storage.local.set({'urls': data.urls});
        }
    }
});

chrome.storage.local.get(['days'], function(data) {
    if (!data.days) {
        chrome.storage.local.set({days: ['1', '2', '3', '4', '5', '6', '7']});
    }
});

chrome.storage.local.get(['beginHour', 'endHour'], function(data) {
    if (!data.beginHour) {
        chrome.storage.local.set({beginHour: 0});
    }
    if (!data.endHour) {
        chrome.storage.local.set({endHour: 24});
    }
});

chrome.storage.local.get(['lastCheckedHour'], function(data) {
    if (!data.lastCheckedHour) {
        chrome.storage.local.set({lastCheckedHour: new Date().getHours()});
        return;
    }
    if (data.lastCheckedHour != new Date().getHours()) {
        resetTabData();
    }
});

// Initialize the dict from local storage, if available
chrome.storage.local.get(["tabData", "tabCache"], function(data) {
    tabData = data.tabData || {"__all__": 0};
    tabCache = data.Cache || {};
});

function checkTimeSpent() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (tabs.length == 0) {
            return;
        }
        for (let domain in ["edge", "chrome", "about"]) {
            if (tabs[0].url.startsWith(domain)) {
                return;
            }
        }

        try {
            const current_url = new URL(tabs[0].url);
            if (["chrome:", "edge:"].includes(current_url.protocol)) {
                return;
            }
            const domain = extract_domain(tabs[0].url);
            const now = new Date();
            chrome.storage.local.get("lastCheckedHour").then(
                (x) => { if (x.lastCheckedHour != now.getHours()) {resetTabData()} }
            );
            is_tracked(domain, new Date()).then((x) => {
                if (x) {
                    updateCounters(tabs[0]);
                } else if (
                    tabs[0].url != chrome.runtime.getURL("cheat.html")
                     && Object.keys(tabCache).includes(tabs[0].id.toString())) {
                    delete tabCache[tabs[0].id];
                }
            });
            chrome.storage.local.set({ tabData: tabData, tabCache: tabCache });
            chrome.storage.local.set({ lastCheckedHour: now.getHours() });
        } catch(error) {
            console.log(error);
            return;
        }
    });
}

function updateCounters(tab) {
    const tabId = tab.id;
    tabData["__all__"] += 1;
    chrome.storage.local.get("timeout", function(data) {
        const timeout = data.timeout || 10;
        if (tabData["__all__"] >= timeout * 60 && !Object.keys(tabCache).includes(tabId)) {
            tabCache[tabId] = tab.url;
            chrome.tabs.update(tabId, { url: chrome.runtime.getURL("cheat.html") });
        }
    });
    chrome.storage.local.set({ tabData: tabData });
}

function resetTabData() {
    for (const key of Object.keys(tabCache)) {
        chrome.tabs.update(parseInt(key), { url: tabCache[key] });
    }
    tabData = {"__all__": 0};
    tabCache = {};
    chrome.storage.local.set({ tabData: tabData, tabCache: tabCache });
}

setInterval(checkTimeSpent, 1000);

chrome.tabs.onActivated.addListener(function(activeInfo) {
    checkTimeSpent();
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.status === "complete") {
        checkTimeSpent();
    }
});