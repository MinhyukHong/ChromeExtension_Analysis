import { extract_domain } from "./url_util.js"

document.addEventListener('DOMContentLoaded', function() {
  var ul = document.getElementById('urlList');
  var input = document.getElementById('urlInput');
  var addButton = document.getElementById('addButton');

    // Get the days checkboxes and time inputs
    const daysCheckboxes = document.querySelectorAll('input[name="days"]');
    const beginHourInput = document.getElementById('beginHour');
    const endHourInput = document.getElementById('endHour');

  chrome.storage.local.get('days', function(data) {
    const days = data.days || [];
    setDays(days, daysCheckboxes);
  });

  chrome.storage.local.get(['beginHour', 'endHour'], function(data) {
    beginHourInput.value = data.beginHour;
    endHourInput.value = data.endHour;
  });

  // Retrieve the list of URLs from Chrome local storage
  chrome.storage.local.get('urls', function(data) {
    if (data.urls) {
      data.urls.forEach(function(url) {
        var li = document.createElement('li');
        var a = document.createElement('a');
        var deleteButton = document.createElement('button');
        a.href = url;
        a.textContent = url;
        a.target = '_blank';
        deleteButton.textContent = 'X';
        li.appendChild(a);
        li.appendChild(deleteButton);
        ul.appendChild(li);
      });
    }
  });
  
  // Handle form submission
  addButton.addEventListener('click', function(event) {
    event.preventDefault();
    var url = input.value.trim();
    
    // Validate URL
    if (url) {
      var protocol = /^(https?|ftp):\/\//i;
      if (!protocol.test(url)) {
        url = 'https://' + url;
      }
      const domain = extract_domain(url);
      if(!domain) {
        return;
      }

      // Retrieve the list of URLs from Chrome local storage and add the new URL
      chrome.storage.local.get('urls', function(data) {
        if (!data.urls) {
          data.urls = [];
        }
        if (data.urls.includes(domain)) {
            return;
        }
        data.urls.push(domain);
        chrome.storage.local.set({urls: data.urls}, function() {
          var li = document.createElement('li');
          var a = document.createElement('a');
          var deleteButton = document.createElement('button');
          a.href = domain;
          a.textContent = domain;
          a.target = '_blank';
          deleteButton.textContent = 'X';
          li.appendChild(a);
          li.appendChild(deleteButton);
          ul.appendChild(li);
          input.value = '';
        });
      });
    }
  });
  
  // Handle delete button click
  ul.addEventListener('click', function(event) {
    if (event.target.nodeName === 'BUTTON') {
      var li = event.target.parentNode;
      var url = li.firstChild.textContent;
      
      // Retrieve the list of URLs from Chrome local storage and remove the URL
      chrome.storage.local.get('urls', function(data) {
        var index = data.urls.indexOf(url);
        if (index > -1) {
          // Remove the URL from the list
          data.urls.splice(index, 1);
        }
      // Update the list in Chrome local storage and remove the list item from the DOM
      chrome.storage.local.set({urls: data.urls}, function() {
        li.remove();
      });
    });
    }
  });

  daysCheckboxes.forEach((checkbox) => {
      checkbox.addEventListener('change', () => {
        // Get the URL from the input field
        const url = urlInput.value;

        // Get the selected days of the week
        const days = Array.from(daysCheckboxes)
          .filter((checkbox) => checkbox.checked)
          .map((checkbox) => checkbox.value);

        // Update the days settings in the storage
        chrome.storage.local.set({ days: days });
      });
  });

  beginHourInput.addEventListener('change', () => {
      chrome.storage.local.set({ beginHour: beginHourInput.value });
  });

  endHourInput.addEventListener('change', () => {
      chrome.storage.local.set({ endHour: endHourInput.value });
  });
});

function setDays(days, daysCheckboxes) {
  daysCheckboxes.forEach((checkbox) => {
    checkbox.checked = days.includes(checkbox.value);
  });
}