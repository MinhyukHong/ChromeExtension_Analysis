function is_tracked(domain, datetime) {
    return chrome.storage.local.get(['days', 'beginHour', 'endHour', 'urls']).then((data) => {
        const urls = data.urls || [];

        const within_timerange = (datetime === undefined) || (
            data.days.includes(datetime.getDay().toString())
            && (data.beginHour <= datetime.getHours())
            && (datetime.getHours() < data.endHour)
        );
        return urls.includes(domain) && within_timerange;
    })
}

export {is_tracked};