// Convert Image to base64 string

function toDataUrl(urls) {
    var imageURIs = [];
    urls.map(url => {
        var xhr = new XMLHttpRequest();
        xhr.onload = function() {
            var reader = new FileReader();
            reader.onloadend = function() {
                imageURIs.push(reader.result)
                decodeImg(imageURIs)
            }
            reader.readAsDataURL(xhr.response);
        };
        xhr.open('GET', url);
        xhr.responseType = 'blob';
        xhr.send();
    })
}

function decodeImg(imgURIs){
    var imageData;
    var imageDataArr = [];
    imgURIs.map((imgURI, index) => {
        var image = new Image();
        var canvas = document.createElement('canvas');
        var ctx = canvas.getContext("2d");
        image.onload = function() {
            canvas.width = image.naturalWidth;
            canvas.height = image.naturalHeight;
            ctx.drawImage(image, 0, 0)
            if(index > 0){
                imageDataArr.push(canvas.toDataURL('image/png').replace('data:image/png;base64,', ''));
                kango.storage.setItem('thumbnailArr', imageDataArr);
            }
            else {
                imageData = canvas.toDataURL('image/png').replace('data:image/png;base64,', '');
                kango.storage.setItem('thumbnail', imageData);
            }
        };  
        image.src = imgURI;
    })
}



// Twigano custom message, EMOJIS x1000

function twigAlert(message, status, timeOut, callback) {
    $('#message').fadeIn(400, function() {
        setTimeout(function() {
            $('#message').fadeOut(400);
            if(callback){
                callback()
            }
        }, timeOut);
    });
    if (status == 'fail') {
        $('#message').text(message + ' ⚠️');

    } else if (status == 'success') {
        $('#message').text(message + ' 🎉');
    } else if (status == 'welcome') {
        $('#message').text(message + ' 👋');
    } else if (status == 'wait') {
        $('#message').text(message + ' ⏳');
    }
    
}

