// ==UserScript==
// @name TwiganoCollector
// @include http://*
// @include https://*
// @require jquery-1.9.1.min.js
// @require HelperMethods.js
// ==/UserScript==


// Include main css 
function addStyle(cssCode, id) {
    if (id && document.getElementById(id))
        return;
    var styleElement = document.createElement("style");
    styleElement.type = "text/css";
    if (id)
        styleElement.id = id;
    if (styleElement.styleSheet) {
        styleElement.styleSheet.cssText = cssCode;
    } else {
        styleElement.appendChild(document.createTextNode(cssCode));
    }
    var father = null;
    var heads = document.getElementsByTagName("head");
    if (heads.length > 0) {
        father = heads[0];
    } else {
        if (typeof document.documentElement != 'undefined') {
            father = document.documentElement
        } else {
            var bodies = document.getElementsByTagName("body");
            if (bodies.length > 0) {
                father = bodies[0];
            }
        }
    }
    if (father != null)
        father.appendChild(styleElement);
}

var details = {
    url: 'main.css',
    method: 'GET',
    async: true,
    contentType: 'text'
};
kango.xhr.send(details, function(data) {
    var content = data.response;
    addStyle(content);
});

// Global variables
var counter = 0;
var imgURIs = [];
var titlesArr = [];
var categoriesArr = [];
var selectedImgs = [];
var title;
var description;
var thumbnail;
var currencies = [];
var collectionsArr = [];
var userLocalCurrency;
var iconsArr = [];
var userLocationInfo;
var localURL = 'https://twigano.com/';
var isContainerVisible;


var fetchUserInfo = {
    init: function() {
        fetchUserInfo.getUserInfo();
    },

    getUserInfo: function() {
        $.get('https://api.ipdata.co', (response) => {
            userLocationInfo = response;
        })
    }
}

function generateRandomString(length){
    var result = '';
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (var i = length; i > 0; --i) result += chars[Math.floor(Math.random() * chars.length)];
    return result;
}

function createSession(userId){
    $.ajax({
        url: `${localURL}api/v1/users/${userId}/sessions`,
        type: 'POST',
        data: {
            reg_id: generateRandomString(36),
            device_id: kango.storage.getItem('device_id')
        },
    })
    .done(function(response) {
        console.log(response)
    });
}

var fetchHandler = {
    init: function() {
        fetchHandler.getContent();
    },

    // Get content from DOM
    getContent: function() {

        // Loads images from meta tag.
        var metas = document.getElementsByTagName('meta');
        $.each(metas, function(index, metaVal) {
            if (metaVal.getAttribute('property') == 'og:image') {
                imgURIs.push(metaVal.getAttribute('content'));
            } else if (metaVal.getAttribute('property') == 'og:title' || metaVal.getAttribute('name') == 'title') {
                title = metaVal.getAttribute('content');
            } else if (metaVal.getAttribute('property') == 'og:description' || metaVal.getAttribute('name') == 'description') {
                description = metaVal.getAttribute('content');
            }
            else {
                twigAlert("We don't support this vendor :(", 'fail', 10000);    
            }
        });

        // Loads images from image tag.
        var domImgs = document.getElementsByTagName('img');
        $.each(domImgs, function(index, imgValue) {
            if (imgValue.hasAttribute('src')) {
                var fileExtension = imgValue.getAttribute('src').split('.').pop();
                var imgnaturalWidth = imgValue.naturalWidth;
                var imgnaturalHeight = imgValue.naturalHeight;
                if (fileExtension != 'gif') {
                    if (imgnaturalWidth > 100 && imgnaturalHeight > 100) {
                        imgURIs.push(imgValue.getAttribute('src'));
                    }
                }
            }
            else {
                twigAlert("We don't support this vendor :(", 'fail', 10000);
            }
        });


        // Get current User collections
        $.ajax({
                url: localURL + 'api/v1/users/' + kango.storage.getItem('user_id') + '/collections',
                headers: {
                    'Authorization': 'Bearer ' + kango.storage.getItem('token')
                }
            })
            .done(function(response) {
                $.each(response.data, function(index, collection) {
                    collectionsArr.push(collection);
                });
            });

        $.ajax({
                url: localURL + 'api/v1/icons',
                headers: {
                    'Authorization': 'Bearer ' + kango.storage.getItem('token')
                }
            })
            .done(function(response) {
                $.each(response.data, function(index, icon) {
                    iconsArr.push(icon);
                });
            })
            .fail(function() {
            });

        // Fetch all categories 
        $.ajax({
            url: localURL + 'api/v1/categories',
            headers: {
                'Authorization': 'Bearer ' + kango.storage.getItem('token')
            }
        }).done(function(response){
            $.each(response.data, function(index, cat) {
                categoriesArr.push(cat);
            });
        }).fail(function(err){
            console.log(err)
        })
    },

    // Request content from the API

    requestContent: function() {
        $.ajax({
                url: localURL + 'api/v1/products/parse',
                type: 'POST',
                data: {
                    url: window.location.href
                },
                headers: {
                    'Authorization': 'Bearer ' + kango.storage.getItem('token')
                }
            })
            .done(function(response) {
                title = response.title;
                description = response.description;
                $.each(response.images, function(index, imgValue) {
                    var fileExtension = imgValue.split('.').pop();
                    if (fileExtension != 'gif') {
                        imgURIs.push(imgValue);
                    }
                });
            })
            .fail(function() {
            })
            .always(function() {
            });
    }
}

// Show Login screen

kango.addMessageListener('showLogin', function(event) {
    counter++;
    if (counter === 1) {

        fetchUserInfo.init();
        if(!kango.storage.getItem('device_id')){
            kango.storage.setItem('device_id', generateRandomString(16))
        }
        var container = $('<div></div>').attr('id', 'twiganoContainer');
        var loader = $("<div id='twig-loader'><i class='fa fa-circle-o-notch fa-spin fa-3x fa-fw'></i></div>");
        var form = $("<form id='twiganoform'></i><img src='https://s3.us-east-2.amazonaws.com/twigano/meta/icon128.png' alt='logo' /></form>");
        var nameInput = $("<input id='twig-name' type='text' placeholder='Name'/>");
        var emailInput = $("<input id='email' type='email' placeholder='Email'/>");
        var passwordInput = $("<input id='password' type='password' placeholder='Password'/>");
        var invitationInput = $("<input id='invitation' type='text' placeholder='Invitation code '/>");
        var actionsContainer = $("<div id='actions'></div>");
        actionsContainer.append("<button class='twig-button' id='twig-loginBtn'>Login <i class='fa fa-spinner fa-spin fa-fw' id='twigbtn-loader'></i></button>");
        actionsContainer.append("<span id='twig-signup'>Don't have an account? Sign up</span>");
        actionsContainer.append("<span id='twig-signin'>Already have an account? Sign up</span>")
        form.append(nameInput);
        form.append(emailInput);
        form.append(passwordInput);
        form.append(invitationInput);
        form.append(actionsContainer);
        container.append(form);
        container.append('<i class="fa fa-times" id="twig-close" aria-hidden="true"></i>');
        $('body').append('<div id="message"></div>');
        $('body').append(container);

        $('#twig-loginBtn').click(function(event) {
            event.preventDefault();
            $('#twigbtn-loader').css('display', 'inline-block');
            $.ajax({
                    url: localURL + 'api/v1/login',
                    type: 'POST',
                    data: {
                        email: $('#email').val(),
                        password: $('#password').val(),
                        grant_type: 'password',
                        client_id: 1,
                        client_secret: 'bXxKzPBRQdvCD16g3M3AMFj81Wl74dzGCAg1jPH2',
                    },
                })
                .done(function(response) {
                    kango.storage.setItem('token', response.access_token);
                    kango.storage.setItem('name', response.user.name);
                    kango.storage.setItem('avatar', response.user.avatar);
                    kango.storage.setItem('user_id', response.user.id);
                    kango.storage.setItem('user_currency', response.user.currency_code);                    
                    twigAlert('Welcome ' + kango.storage.getItem('name'), 'welcome', 4000);
                    kango.dispatchMessage('loggedIn');
                    counter = 0;
                    $('#twigbtn-loader').hide();
                    createSession(kango.storage.getItem('user_id'))
                })
                .fail(function(response) {
                    $('#twigbtn-loader').hide();
                    twigAlert(JSON.parse(response.responseText).email, 'fail', 500)
                })
                .always(function() {
                    $('#twigbtn-loader').hide();
                });
        });

        $('#twig-signup').click(function(){
            $('#twig-name').css('display', 'block').addClass('fadeInDown animated');
            $('#invitation').css('display', 'block').addClass('fadeInDown animated');
            $('#twig-username').css('display', 'block').addClass('fadeInDown animated');
            $('#twig-loginBtn').attr('id', 'twig-signupBtn').text("Sign up").css('background', '#ed1846');
            $('#twig-signupBtn').append("<i class='fa fa-spinner fa-spin fa-fw' id='twigbtn-loader'></i>");
            $('#twig-signin').show();
            $(this).hide();
            $('#twig-signupBtn').click(function(event) {
                event.preventDefault();
                $('#twigbtn-loader').css('display', 'inline-block');
                $.ajax({
                        url: localURL + 'api/v1/register',
                        type: 'POST',
                        data: {
                            name: $('#twig-name').val(),
                            email: $('#email').val(),
                            password: $('#password').val(),
                            invitation_code: $('#invitation').val(),
                            latitude: userLocationInfo.latitude,
                            longitude: userLocationInfo.longitude,
                            currency_code: userLocationInfo.currency
                        },
                    })
                    .done(function(response) {
                        twigAlert('Signed up successfully', 'success', 1000);
                    })
                    .fail(function(response) {
                        $('#twigbtn-loader').hide();
                        twigAlert(JSON.parse(response.responseText).email, 'fail', 500)
                    })
                    .always(function() {
                        $('#twigbtn-loader').hide();
                    });
                
            });
        });

        $('#twig-signin').click(function(){
            $('#twig-name').hide();
            $('#twig-username').hide();
            $('#invitation').hide();
            $('#twig-signup').show();
            $(this).hide();
            $('#twig-signupBtn').attr('id', 'twig-loginBtn').text("Login").css('background', '#ed1846');
        });
    }

    $(document).keyup(function(e) {
        if (e.keyCode == 27) {
            $('#twiganoContainer').hide();
            counter++;
        }
    });

    $('#twig-close').click(function() {
        $('#twiganoContainer').hide();
        counter++;
    });

    if (counter % 2 == 0) {
        $('#twiganoContainer').hide();
    } else {
        $('#twiganoContainer').show();
    }

});

// Show Extension screens

kango.addMessageListener('showExtension', function(event) {

    if (counter === 0) {
        $('#twiganoContainer').remove();
    }
    counter++;
    if (counter === 1) {

        var currentScreen;

        // Call data fetching handler
        fetchHandler.init();
        if(!kango.storage.getItem('device_id')){
            kango.storage.setItem('device_id', generateRandomString(16))
        }
        // Show Welcome message 
        twigAlert('Welcome ' + kango.storage.getItem('name'), 'welcome', 1000);
        kango.storage.removeItem('thumbnailArr')
        kango.storage.removeItem('thumbnail')
        // Create elements

        // Common elements
        var container = $('<div></div>').attr('id', 'twiganoContainer');
        var twigMain = $('<div></div>').attr('id', 'twig-main');
        var actionbarContainer = $('<div></div>').attr('id', 'twig-bar');
        var actionButtonLeft = $('<button>Back</button>').attr('id', 'leftBtn');
        var userName = $('<p></p>').attr('id', 'twig-username').text(kango.storage.getItem('name'));
        var userAvatar = $('<img/>').attr('id', 'twig-avatar');
        var actionButtonRight = $('<button>Next</button>').attr('id', 'rightBtn');
        var actionButtonAdd = $('<button>Add </button>').attr('id', 'addBtn');
        var alterLogoContainer = $('<div></div').attr('id', 'twig-alterLogo');
        var alterLogo = $('<img/>').attr('src', 'https://s3.us-east-2.amazonaws.com/twigano/meta/scr+2e.png').attr('alt', 'alter-logo');
        var resetButton = $('<i id="twig-reset" class="fa fa-refresh fa-2x" aria-hidden="true"></i>');
        var secondaryActionBar = $('<div class="twig-secondarybar"></div>').attr('id', currentScreen);
        var selectedImgsCounter = $('<p></p>');
        var clearButton = $('<button>Clear</button>');
        var resetButton = $('<button>Reset</button>');
        var secActionButtons = $('<div id="buttons-container"></div>');
        var userMenu = $('<ul id="user-menu"></ul>');
        var barLeftContainer = $('<div id="bar-left-section"></div>');
        var hint = $('<div id="twig-hint"></div>');
        var hintText = $('<p></p>').text('Choose one or more images of the product you want to collect and click next')

        // Screen 1 elements
        var imgsContainer = $('<div id="twigimgsContainer" class="twig-cols"></div>');

        // Screen 2 elements 
        var formContainer = $('<div id="twigformContainer"></div>');
        var leftPanel = $('<div></div>').attr('id', 'twig-leftPanel');
        var thumbnail = $('<img/>').attr('id', 'twig-thumbnail');
        var secondaryImgsContainer = $('<div></div>').attr('id', 'twig-secondaryImages');
        var rightPanel = $('<div></div>').attr('id', 'twig-rightPanel');
        var insertionForm = $('<form></form>').attr('id', 'twig-productForm');
        var titleInput = $('<input required>').attr('type', 'text').val(title).attr('placeholder', 'Product Name').attr('id', 'twig-title');
        var descriptionInput = $('<input required>').attr('type', 'text').val(description).attr('placeholder', 'Description').attr('id', 'twig-desc');
        var priceInput = $('<input min="0" max="9999" required>').attr('type', 'number').attr('placeholder', 'Price').attr('id', 'twig-price');
        var currencyInput = $('<select id="twig-currencies"></select>');
        var storyInput = $('<textarea id="twig-story"></textarea>').attr('placeholder', 'Write a story');
        var collectionsList = $('<select multiple size="3" id="twig-collections"></select>');
        var categories = $('<select required id="twig-categories"><option disabled selected>Select a category</option></select>');
        var barsContainer = $('<div id="twig-bars"></div>')
        // Append elements to the screen

        container.append(twigMain);
        barsContainer.append(actionbarContainer);
        barsContainer.append(secondaryActionBar);
        twigMain.append(barsContainer);
        twigMain.append(imgsContainer);
        twigMain.append(formContainer);
        formContainer.append(leftPanel);
        formContainer.append('<span></span>');
        formContainer.append(rightPanel);
        leftPanel.append(thumbnail);
        leftPanel.append(secondaryImgsContainer);
        rightPanel.append(insertionForm);
        alterLogoContainer.append(alterLogo);
        insertionForm.append(titleInput);
        insertionForm.append(descriptionInput);
        insertionForm.append(priceInput);
        insertionForm.append(currencyInput);
        insertionForm.append(categories);
        insertionForm.append('<label>Add to group</label>');
        insertionForm.append(collectionsList);
        insertionForm.append('<p id="newCollection">Create new group</p>')
        insertionForm.append(storyInput);
        barLeftContainer.append(actionButtonLeft);
        barLeftContainer.append(userAvatar);
        barLeftContainer.append(userName);
        hint.append(hintText)
        actionbarContainer.append(barLeftContainer);
        actionbarContainer.append(alterLogoContainer);
        actionbarContainer.append(resetButton);
        actionbarContainer.append(actionButtonRight);
        actionbarContainer.append(actionButtonAdd);
        actionbarContainer.append(hint);
        secondaryActionBar.append(selectedImgsCounter);
        secondaryActionBar.append(secActionButtons);
        secActionButtons.append(clearButton);
        secActionButtons.append(resetButton);
        userMenu.append('<li id="logout-button">Logout <i class="fa fa-sign-out" aria-hidden="true"></i></li>');
        actionbarContainer.append(userMenu);
        actionButtonAdd.append('<i class="fa fa-spinner fa-spin fa-fw" id="twigbtn-loader"></i>');
        container.append('<i class="fa fa-times" id="twig-close" aria-hidden="true"></i>');
        $('body').append(container);
        $('body').append('<div id="message"></div>');

        barsContainer.css('width', twigMain.width());

        if (selectedImgs.length == 0) {selectedImgsCounter.hide();secActionButtons.hide();}

        isContainerVisible = imgsContainer.is(':visible');

        if (isContainerVisible) {actionButtonLeft.prop('disabled', true);}

        if (kango.storage.getItem('avatar') == null) {
            userAvatar.attr('src', 'http://via.placeholder.com/100x100');
        }
        else {
            userAvatar.attr('src', kango.storage.getItem('avatar'));
        }

        userAvatar.click(function() {
            $('#user-menu').toggle();
            $('#logout-button').click(function(event) {
                $(this).find('i').removeClass('fa-sign-out').addClass('fa-spinner fa-spin fa-fw');
                var deviceId = kango.storage.getItem('device_id');
                kango.storage.clear();
                kango.storage.setItem('device_id', deviceId);
                setTimeout(() => {
                    $('#twiganoContainer').remove();
                }, 400)
                $.ajax({
                    url: localURL + 'api/v1/logout',
                    type: 'POST',
                    data: {device_id: kango.storage.getItem('device_id')},
                    headers: {
                        'Authorization': 'Bearer ' + kango.storage.getItem('token')
                    }
                })
                .done(function() {
                    counter = 0;
                    window.location.reload();
                })
                .fail(function() {
                })
                .always(function() {
                });
                
            });
        });


        $.each(imgURIs, function(index, uri) {
            var productImageContainer = $('<div><div/>').attr('class', 'twig-imgContainer');
            var productImage = $('<img/>').attr('src', uri);
            productImageContainer.append(productImage);
            imgsContainer.append(productImageContainer);
        });

        // handle images addition and deletion

        $('.twig-imgContainer').click(function(event) {
            event.preventDefault();
            $('.twig-secondarybar').append();
            $('#twigimgsContainer').addClass('active');
            var selectedImg = $(this).find('img').attr('src');
            if ($(this).hasClass('selected')) {
                $(this).removeClass('selected');
                if (selectedImgs.indexOf(selectedImg) > -1) {
                    selectedImgs.splice(selectedImgs.indexOf(selectedImg), 1);
                }
            } else {
                $(this).addClass('selected');
                selectedImgs.push(selectedImg);
            }
            $('.twig-secondarybar').addClass('show');
            $('#buttons-container').show();
            $('.twig-secondarybar p').show().text('You have selected ' + selectedImgs.length + ' images');
        });

        $('#rightBtn').click(function() {
            if (selectedImgs.length > 0 && categoriesArr.length > 0) {
                $('#twig-hint p').text('Enter the data of the product you want to collect and click add.')
                $('#leftBtn').removeProp('disabled');
                $('#twigimgsContainer').hide('fast');
                $('#twigformContainer').show('fast');
                $(this).hide();
                $('#addBtn').show();
                $('#twig-thumbnail').attr('src', selectedImgs[0]);
                $.each(selectedImgs, function(index, uri) {
                    if (index > 0) {
                        var secondaryImg = $('<img/>').attr('src', uri);
                        $('#twig-secondaryImages').append(secondaryImg);
                    }
                });

                
                $("#twig-currencies option").val(function(idx, val) {
                    $(this).siblings("[value='"+ val +"']").remove();
                });
                // Add all currencies to currency input field
                currencies = [kango.storage.getItem('user_currency'),'USD', 'EUR', 'GBP', 'JPY', 'CNY'];
                var uniqueCurrencies = currencies.filter((v, i, a) => a.indexOf(v) === i);
                $.each(uniqueCurrencies, function(index, curr) {
                    var currOption = $('<option></option>').text(curr).val(curr);
                    $('#twig-currencies').append(currOption);
                });

                if ($('#twig-collections option').length < collectionsArr.length) {
                    $.each(collectionsArr, function(index, coll) {
                        if (index < collectionsArr.length) {
                            var collectionName = $('<option>' + coll.name + '</option>').attr('value', coll.id);
                            $('#twig-collections').append(collectionName);
                        }
                    });
                }

                if(categoriesArr){
                    $.each(categoriesArr, function(index, category){
                        var parentOptions = $('<optgroup></optgroup>').attr('label',category.name);
                        $('#twig-categories').append(parentOptions);
                        $.each(category.children, function(index, child) {
                            if(child.parent_id == category.id){
                                childCategories = $('<option></option>').text(child.name).val(child.id);
                                parentOptions.append(childCategories);
                            }
                        })
                    });
                }

                toDataUrl(selectedImgs);
            } else if(selectedImgs.length == 0) {
                twigAlert('You should select images', 'fail', 1000);
            }
            else if(categoriesArr.length == 0){
                twigAlert('Categories are being loaded, hang on!', 'wait', 3000, () =>{
                    $('#rightBtn').trigger('click');
                });
            }
        });

        $('#leftBtn').click(function() {
            $('#twig-hint p').text('Choose one or more images of the product you want to collect and click next.')
            var currentImgs = $('#twig-secondaryImages img');
            currentImgs.remove();
            $(this).attr('disabled', 'disabled');
            $('#twigimgsContainer').show('fast');
            $('#twigformContainer').hide('fast');
            $('#rightBtn').show();
            $('#addBtn').hide();
        });

        $('#newCollection').click(function() {
            var collectionForm = $('<form></form>');
            var iconsList = $('<ul id="icons-list"></ul>');
            var listTrigger = $('<div id="list-trigger"></div>');
            listTrigger.append('<img src="' + iconsArr[0].asset + '"/>');
            listTrigger.append('<span>' + iconsArr[0].name + '</span>');
            listTrigger.attr('data-id', iconsArr[0].id);
            $.each(iconsArr, function(index, icon) {
                let iconWrapper = $('<li></li>').attr('data-id', icon.id);
                let iconAsset = $('<img/>').attr('src', icon.asset);
                let singleIcon = $('<span>' + icon.name + '</span>');
                iconWrapper.append(iconAsset);
                iconWrapper.append(singleIcon);
                iconsList.append(iconWrapper);
            });
            collectionForm.append('<i class="fa fa-times" id="twig-closeCard" aria-hidden="true"></i>');
            collectionForm.append(listTrigger);
            collectionForm.append(iconsList);
            collectionForm.append('<input id="coll-name" type="text" placeholder="Group Name">');
            collectionForm.append('<button id="addCollection"><i class="fa fa-arrow-right" aria-hidden="true"></i></button>');
            $('body').append('<div id="twig-overlay"></div>');
            $('#twig-overlay').append(collectionForm);
            $('#twig-overlay form #twig-closeCard').click(function() {
                $('#twig-overlay').remove();
            });
            $('#list-trigger').click(function() {
                $('#icons-list').toggleClass('show');
            });
            $('#icons-list li').click(function(event) {
                let currrentID = $(this).data('id');
                let currentAsset = $(this).find('img').attr('src');
                let currentName = $(this).find('span').text();
                $('#list-trigger').attr('data-id', currrentID).find('span').text(currentName);
                $('#list-trigger img').attr('src', currentAsset);
                $('#icons-list').removeClass('show');
            });

            $('#addCollection').click(function(event) {
                event.preventDefault();
                $(this).find('i').attr('class')
                $.ajax({
                        url: localURL + 'api/v1/users/' + kango.storage.getItem('user_id') + '/collections',
                        type: 'POST',
                        data: {
                            name: $('#coll-name').val(),
                            icon: $('#list-trigger').attr('data-id')
                        },
                        headers: {
                            'Authorization': 'Bearer ' + kango.storage.getItem('token')
                        }
                    })
                    .done(function(response) {
                        twigAlert('New group added successfully', 'success');
                        var newOption = $('<option></option>').val(response.id).text(response.name);
                        $('#twig-collections').append(newOption);
                    })
                    .fail(function() {
                        twigAlert('Failed to add a new group', 'fail', 2000);
                    });

            });
        });

        clearButton.click(function(event) {
            if($('#twigimgsContainer').is(':visible')){
                $('.twig-imgContainer').removeClass('selected');
                selectedImgs = [];
                $('.twig-secondarybar p').text('You have selected ' + selectedImgs.length + ' images');
            }
            else if($('#twigformContainer').is(':visible')){
                document.getElementById('twig-productForm').reset();
            }
        });

        resetButton.click(function(event) {
            $('#leftBtn').trigger('click');
            $('.twig-imgContainer').removeClass('selected');
            selectedImgs = [];
            $('.twig-secondarybar p').text('You have selected ' + selectedImgs.length + ' images');
            document.getElementById('twig-productForm').reset();
        });

        userName.click(function(event) {
            twigAlert("It's you, " + userName.text(), 'welcome', 1000);
        });

        actionButtonAdd.click(function() {
            $('#twigbtn-loader').css('display', 'inline-block');
            $(this).prop('disabled', true);
            $.ajax({
                    url: localURL + 'api/v1/users/' + kango.storage.getItem('user_id') + '/products',
                    type: 'POST',
                    data: {
                        name: $('#twig-title').val(),
                        url: window.location.href,
                        thumbnail: kango.storage.getItem('thumbnail'),
                        price: $('#twig-price').val(),
                        currency_code: currencyInput.val(),
                        description: $('#twig-desc').val(),
                        category: $('#twig-categories').val(),
                        images: kango.storage.getItem('thumbnailArr') 
                        ? kango.storage.getItem('thumbnailArr') : []
                    },
                    headers: {
                        'Authorization': 'Bearer ' + kango.storage.getItem('token')
                    }
                })
                .done(function(response) {
                    kango.storage.removeItem('thumbnail')
                    kango.storage.removeItem('thumbnailArr')
                    $('#twigbtn-loader').hide();
                    var selectedCollection = $('#twig-collections').val();
                    var products = [];
                    var storyBody = $('#twig-story').val();
                    products[0] = response.id
                    $.ajax({
                            url: localURL + 'api/v1/users/' + kango.storage.getItem('user_id') + '/collections/' + selectedCollection + '/products',
                            type: 'POST',
                            data: { products: products },
                            headers: {
                                'Authorization': 'Bearer ' + kango.storage.getItem('token')
                            }
                        })
                        .done(function(response) {
                            $('#twigbtn-loader').hide();
                        })
                        .fail(function() {
                            $('#twigbtn-loader').hide();
                        });
                    $.ajax({
                            url: localURL + 'api/v1/users/' + kango.storage.getItem('user_id') + '/stories',
                            type: 'POST',
                            data: {
                                product: response.id,
                                body: storyBody,
                            },
                            headers: {
                                'Authorization': 'Bearer ' + kango.storage.getItem('token')
                            }
                        })
                        .done(function(response) {
                            $('#twigbtn-loader').hide();
                        })
                        .fail(function() {
                            $('#twigbtn-loader').hide();
                        });
                    twigAlert('Successfully added a product!', 'success', 4000, () => {
                        window.location.reload();
                    });
                    $('#twiganoContainer').hide();
                })
                .fail(function(response) {
                    $('#addBtn').prop('disabled', false);            
                    $('#twigbtn-loader').hide();
                    if(JSON.parse(response.responseText).url){
                        twigAlert('This product already exists', 'fail', 1000);
                    }
                    else if(JSON.parse(response.responseText).category) {
                        twigAlert('You should select a category', 'fail', 1000);  
                    }
                    else if(JSON.parse(response.responseText).price) {
                        twigAlert('You should specify product price', 'fail', 1000);
                    }
                    else if(JSON.parse(response.responseText).currency_code) {
                        twigAlert('Invalid currency code', 'fail', 1000);
                    }
                });

        });
    }

    // Hide / Show extension

    $(document).keyup(function(e) {
        if (e.keyCode == 27) {
            $('#twiganoContainer').hide();
            counter++;
        }
    });

    $('#twig-close').click(function() {
        $('#twiganoContainer').hide();
        counter++;
    });

    if (counter % 2 == 0) {
        $('#twiganoContainer').hide();
    } else {
        $('#twiganoContainer').show();
    }

});