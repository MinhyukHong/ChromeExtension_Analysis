﻿kango.ui.browserButton.addEventListener(kango.ui.browserButton.event.COMMAND, function() {
    kango.browser.tabs.getCurrent(function(tab) {

	    var token = kango.storage.getItem('token');

	    if (!token) {
	    	tab.dispatchMessage('showLogin', 'you need to login');
	    }
	    else {
	    	tab.dispatchMessage('showExtension', 'Welcome to twigano');
	    }

	});
});

kango.addMessageListener('loggedIn', function(){
	kango.browser.tabs.getCurrent(function(tab){
		tab.dispatchMessage('showExtension', 'Welcome to twigano');
	});
});