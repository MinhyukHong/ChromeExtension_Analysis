const n={all:"All JA",shown:"Shown JA",hidden:"Hidden JA",notFound:"Not Found JA"},o={filters:n};export{o as default,n as filters};
