const e=document.createElement("script");e.src=chrome.runtime.getURL("src/pages/imgSlider/index.js");(document.head||document.documentElement).appendChild(e);
