/*! anotes - v0.9.0 - 2014-03-18
 /**Copyright (C) 2013-2014 Alex Joseph Clavelle aclav3113@gmail.com Licensed  */


//############################
// Source:app/src/model/Note.js
/**
    Copyright (C) 2013-2014 Alex Joseph Clavelle aclav3113@gmail.com
*/
/* jshint undef: false, debug:true*/
    var observerconfig = {
        childList: true,
        attributes: true,
        characterData: true,
        subtree: true,
        attributeOldValue: true,
        characterDataOldValue: true
    };

    var eventProxy = _.clone(Backbone.Events);

    var observer = new MutationObserver(_.debounce(function(mutations) {
        eventProxy.trigger("modelSync", "The models and views need to sync");
    }, 250));

var Note = Backbone.Model.extend({
    height: "",
    width: "",
    id: "",
    title: "",
    x: "",
    y: "",
    cstyle: "",
    contents: "",
    del: false,
    created: new Date(),
    modified: new Date(),
    defaults: {
        height: "120px",
        width: "180px",
        id: new Date().getTime(),
        title: "untitled",
        x: "0px",
        y: "0px",
        cstyle: "anote-contents default",
        contents: "Type a note",
        className: "Anote",
        del: false,
    },
    toJSON: function() {
        var n = {};
        for (var k in this.attributes) {
            n[k] = this.attributes[k];
        }
        return n;
    },
});

var NoteView = Backbone.View.extend({
    offY: 0,
    offX: 0,
    events: {
        'mousedown .anote-contents.default': 'contentAreaClicked',
        'mousedown': 'mouseDown',
        'mouseup': 'mouseUp',
        'click': 'click'

    },
    styles: {
        ".Anote": {},
        ".anote-contents": {},
        ".options-shown": {},
        ".options-menu": {},
        ".btn": {},

    },
    tagName: 'div',
    className: "Anote",
    initialize: function() {
        if (this.events) {
            this.events = _.defaults(this.events, NoteView.prototype.events);
            this.delegateEvents(this.events);
        }
        observer.observe(this.el, observerconfig);
        this.listenTo(eventProxy, "modelSync", this.modelSync);
        //need to post this message less often.
        if(!this.model) {this.model = new Note();}
        this.model.on("change", _.debounce(function(model) {
            console.log("model changed");
        }, 1000));

        //end initialize
    },
    template: function(attr) {
        var htm = '<div contenteditable="true">'+attr.contents+'</div>';
        return htm;
    },
    render: function() {
        /* jshint -W075 */

        this.el.id = this.model.attributes.id;
        this.el.innerHTML = this.template(this.model.attributes);
        this.el.style.top = this.model.attributes.y;
        this.el.style.left = this.model.attributes.x;
        this.el.style.width = this.model.attributes.width;
        this.el.style.height = this.model.attributes.height;
        this.el.className = this.model.attributes.className;
        this.el.firstChild.className = this.model.attributes.cstyle;
        this.el.firstChild.style.background = "#fcfcfc";
        this.el.style.zIndex = 10;
        var isElOnPage = document.getElementById(this.el.id);
        if(isElOnPage){
            isElOnPage.innerHTML = this.el.innerHTML;
        }
        else{
            document.body.appendChild(this.el);

        }
        observer.observe(this.el, observerconfig);
    },

    modelSync: function() {
        this.model.set({
            "contents": _.escape(this.el.innerText),
            "x": this.el.style.left,
            "y": this.el.style.top,
            "className": this.el.className,
            "cstyle": this.el.firstChild.className,
            "modified": new Date().getTime(),
            "height": this.el.style.height,
            "width": this.el.style.width,
        });
    },
    //use this to add certain styles to the view
    applyStyles: function(view, style) {
        if (view === "options") {

        }
    },
    contentAreaClicked: function(e) {
        e.stopPropagation();
    },
    click: function(e) {
        e.stopPropagation();
        var $thisel = this.$el;
        var that = this;
        //makes sure there wasn't an options menu here before.
        $(".options-menu").remove();
        this.$el.addClass("options-shown").mouseleave(function() {
            $(".options-shown > .anote-contents").css("height", "100%");
            $thisel.removeClass("options-shown");
            $(".options-menu").remove();
        });
        //makes sure any remnants from the last click are gone
        $(".options-shown > .anote-contents").css("height", "100%");
        //keeps the note the same size and just shrinks the white.
        $(".options-shown > .anote-contents").css("height", "-=25px");
        this.$el.append("<ul id=\"options-menu-ul\" class=\"options-menu\"><button class=\"options-button\" id=\"deletebtn\"name=\"delete\">Delete</button> <button class=\"options-button\"id=\"sizeresetbtn\"name=\"sizeresetbtn\">Size</button></ul>");
        $('#deletebtn').click(function() {
            $thisel.remove();
            that.model.attributes.del = true;
        });
        $('#sizeresetbtn').click(function() {
            $('.options-shown').css({
                'height': '6em',
                'width': '10em',
            });
        });
    },
    mouseUp: function() {
        this.el.removeEventListener("mousedown", this.mouseDown);
        window.removeEventListener('mousemove', this.boundMove);
        this.el.style.zIndex = 10;
    },
    mouseDown: function(e) {
        e.stopPropagation();
        var that = this;
        this.el.offY = e.clientY - parseInt(this.el.offsetTop);
        this.el.offX = e.clientX - parseInt(this.el.offsetLeft);
        // this.$el.addClass("options-menu");
        // this.$el.mouseout(function(){
        // $(".options-menu").removeClass("options-menu");
        // });
        //this.on("mousemove", move, this);
        this.el.style.zIndex = 100;
        var thisel = this.el;
        window.addEventListener('mouseup', function() {
            that.mouseUp.call(that);
        });
        this.boundMove = this.move.bind(this.el);
        window.addEventListener('mousemove',this.boundMove);
        // this.el.addEventListener("mousemove", this.move);



    },
    move: function(e) {
        this.style.postition = "absolute";
        this.style.top = (e.clientY - this.offY) + "px";
        this.style.left = (e.clientX - this.offX) + "px";
    },
});

    var PopupNoteView = Backbone.View.extend({
        tagName: 'li',
        className: "note",
        initialize:function(){
            if (this.events) {
                this.events = _.defaults(this.events, PopupNoteView.prototype.events);
                this.delegateEvents(this.events);
            }
            observer.observe(this.el, observerconfig);
            this.listenTo(eventProxy, "modelSync", this.modelSync);
            //need to post this message less often.
            this.model.on("change", _.debounce(function(model) {
                console.log("model changed");
            }, 1000));
        },
        render:function(){
            this.el.innerHTML = '<p contenteditable="true" class="notecontents">' + this.model.attributes.contents + '</p>';
            return this.el;
        }
    },NoteView);


;

//############################
// Source:app/src/model/Page.js
/**
    Copyright (C) 2013-2014 Alex Joseph Clavelle aclav3113@gmail.com
*/
var Page = Backbone.Model.extend({
	that:this,
	url : "",
	initialize : function() {
		var args = arguments,
		arg = args[0];
		this.notes = new NoteCollection();

		if(arg && !(arg instanceof Backbone.Model) && arg.notes && arg.url ){

			this.url = arg.url;

			_.each(arg.notes,function(note){
				this.notes.add(note);
			},this);

		}
		return this;

	},
	toJSON : function() {
		var page = {};
		page.notes = [];
		page.url = this.get("url");
		for (var k in this.notes.models) {
			page.notes.push(this.notes.models[k].toJSON());
		}
		return page;
	},
	//
	syncWithBg : function() {
		var pg = this;
		this.notes.on("change", _.debounce(function() {
			//delete any notes flagged as delete
			var del = pg.notes.where({
				del : true
			});
			pg.notes.remove(del);
			extPort.postMessage({
				status : "collection-changes",
				page : pg,
				url : window.location.href
			});
		}, 500));
	}
});

var NoteCollection = Backbone.Collection.extend({
	model : Note,
	toJSON : function() {
		var notes = [];
		for (var i in this.models) {
			notes.push(this.models[i]);
		}
		return notes;
	},
	comparator : 'id',
});
;

//############################
// Source:app/src/model/anotes.js
var anotes = Backbone.Model.extend({
    name : "Anotes",
    version : "0.0.1",
    initialize : function() {
        this.pages = new PageCollection();
    },

    settings : {},
    defaults : {
        name : "Anotes",
        version : "0.0.1",
    },
    toJSON : function() {
        var AN = {};
        AN.pages = [];
        AN.settings = this.attributes.settings;
        AN.version = this.attributes.version;
        AN.name = this.attributes.name;
        _.each(this.pages.models, function(page) {
            AN.pages.push(page.toJSON());
        }, this);
        return AN;
    },
    //used to parse json and recreate the app from it. "add"'s notes so that existing data isn't wiped.
    parse : function() {
        //this should accept the function, or an object.
        var json = (typeof arguments[0] === 'string') ? JSON.parse(arguments[0]) : arguments[0];
        this.name = json.name;
        this.version = json.version;
        _.each(json.pages, function(page) {
            var p = new Page();
            p.set(page);
            _.each(page.notes, function(note) {
                var n = new Note();
                n.set(note);
                p.notes.add(n);
            });
            this.pages.add(p);
        }, this);
    },
    serialize : function() {
        return JSON.stringify(this.toJSON());
    },
    //end anotes model
});
var Anotes = anotes;
var PageCollection = Backbone.Collection.extend({
    model : Page,
    events : {
        "add" : "pageAdded",
        "change" : "pageChanged",
        "remove" : "pageRemoved",
    },
    pageAdded : function() {
    },
    pageChanged : function() {
    },
    pageRemoved : function() {
    },

    toJSON : function() {
        var json = [];
        for (var page in this) {
            json.push(page);
        }
        return json;
    },
});

