/**

 function which keeps an array of objects, and makes sure they are all equal.
 Used for checking consistency between many objects easily.


    for example:
    create a bunch of objects that should be exactly the same.

    var data1 = object.serialize();
    var data2 = object2.parse(data1).toJSON();
    var data3 = JSON.parse(JSON.stringify(object2));

    var eq = new EqualityStack( data1,data2,data3);
    OR
    var eq = new EqualityStack( [data1,data2,data3]);
    OR
    var eq = new EqualityStack( [data1], data2, data3, [data5,data6,data7,] );

    The constructor and the add method can take any number of comma separated arrays of objects, and objects,

    add objects to your equality stack with EqualityStack.add();

    var data = {
        time:"4:00",
        nestedObject = {
            innerproperties:{
                url:'https://google.com'
            }
        }
    };

    eq.add(data);
 */

var EqualityStack = function() {
    var that = this;
    var objects = [];
    var args = Array.prototype.slice.call(arguments, 0);
    for (var i in args) {
        if (args[i].push) {
            for (var k in args[i]) {
                objects.push(args[i][k]);
            }
        } else {
            objects.push(args[i]);
        }
    }
    var equals = function(ob1, ob2) {
        for (var k in ob1) {
            if (typeof ob1[k] === 'object') {
                equals(ob1[k], ob2[k]);
            } else {
                if (ob1[k] !== ob2[k]) {
                    return false;
                }
            }
        }
        for (var j in ob2) {
            if (typeof ob2[j] === 'object') {
                equals(ob1[j], ob2[j]);
            } else {
                if (ob1[j] !== ob2[j]) {
                    return false;
                }
            }
        }
        return true;
    };

    this.add = function() {
        var args = Array.prototype.slice.call(arguments, 0);
        for (var i in args) {
            if (args[i].push) {
                for (var k in args[i]) {
                    objects.push(args[i][k]);
                }
            } else {
                objects.push(args[i]);
            }
        }
    };

    this.clear = function() {
        objects = [];
    };
    this.compareStack = function() {
        var comparator = objects[0];
        if (objects.length > 1) {
            for (var i = 1; i < objects.length; i++) {
                if (!equals(comparator, objects[i])) {
                    return false;
                }
            }
        }
        return true;
    };
    this.getObjects = function() {
        return objects;
    };

};