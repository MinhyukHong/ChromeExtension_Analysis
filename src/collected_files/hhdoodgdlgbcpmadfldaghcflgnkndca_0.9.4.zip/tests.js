//Jquery wraps their tests in an IIFE, and this fixed my issue with running all tests within the getBackgroundPage callback.
(function() {
    var TIMERSTART, TIMERSTOP, TIMEELAPSED, ID;
    TIMERSTART = new Date().getTime();
    ID = document.getElementById;

    // pass an instance of anotes, and the background page, and fill it with p
    // number of pages, each of which has n number of notes, so p*n notes total
    /***************************************************************************
     * ***********************************************************************************
     * Helper functions
     **************************************************************************/
    window.addTestData = function(anWindow, anInstance, p, n, callback) {
        var notetotal = 0;
        for (var i = 0; i < p; i++) {
            var page = new anWindow.Page({
                url: "page" + i,
                name: 'page' + i
            });
            for (var j = 0; j < n; j++) {
                var note = new anWindow.Note({
                    contents: "Test note contents number " + j,
                    id: notetotal
                });
                notetotal++;
                page.notes.add(note);
            }
            anInstance.pages.add(page);
        }
        // console.log(p + " Pages and " + notetotal+ " notes added to this instance.");
        return callback ? callback(anInstance) : anInstance;
    };

    chrome.runtime
        .getBackgroundPage(function(bg) {
            // get the amount of time it took to get our background page.
            (function() {
                TIMERSTOP = new Date().getTime();
                TIMEELAPSED = TIMERSTOP - TIMERSTART;
                var timeToGetBackgroundPage = document
                    .getElementById('bgPageTime');
                timeToGetBackgroundPage.innerText = TIMEELAPSED + "ms";
            })();
            var Anotes = bg.anotes;
            var Page = bg.Page;
            var Note = bg.Note;
            var Backbone = bg.Backbone;
            var _ = bg._;
            var StorageDriver = bg.StorageDriver;
            var $ = bg.$;

            /***************************************************************
             * Begin Qunit Tests
             * ************************************************************************************
             */

            test("Anotes Serialization", function() {
                var an = new Anotes();
                var an2 = new Anotes();
                addTestData(bg, an2, 2, 10);
                var an2json = an2.toJSON();
                //Parsing should produce an identical object.
                an.parse(an2json);
                var anjson = an.toJSON();
                deepEqual(anjson, an2json, "Serialization and deserialization should be 1:1.");
                var an3 = new Anotes();
                var jsonstring = JSON.stringify(anjson);
                an3.parse(jsonstring);
                var an3json = an3.toJSON();
                deepEqual(an3json, anjson, "Parsing a json string should behave the same as parsing an object.");
            });
            asyncTest("Storage Upload tests", function() {
                stop();
                expect(3);
                var an = new Anotes();
                var an2 = new Anotes();
                var idToUpdate;
                addTestData(bg, an2, 2, 10);
                var storage = new StorageDriver({}, function(sto) {
                    ok(sto.token, "Storage driver should have an access token.");
                    start();
                });
                stop();
                storage.Appdata.insert(an2,
                    function(success) {
                        var successobj = JSON.parse(success);
                        idToUpdate = successobj.id;
                        ok(success, "Successfully uploaded to google drive appdata.");
                        start();
                        an2.pages.at(0).notes.at(0).set({
                            contents: "UPDATED CONTENTS!!!!!!"
                        });
                        storage.Appdata.replace(idToUpdate, an2,
                            function(success) {
                                ok(success, "Updating file in drive succeeded.");
                                start();
                            }, function(error) {
                                ok(false, "Updating file in drive failed.");
                            });
                    }, function(error) {
                        ok(false, "There was an error in the upload process.");
                    });
            });
            /*
             * ***********************************************************************************
             * End Qunit Tests
             * ************************************************************************************
             */

        });


})();


chrome.runtime.getBackgroundPage(function(bg) {

    /*
     * Begin Timing Tests
     * ************************************************************************************
     * ************************************************************************************
     * ************************************************************************************
     * ************************************************************************************
     */

    var start, end, elapsed, Anotes = bg.anotes;
    var atest = new Anotes();

    // adding 10,000 notes
    (function() {
        start = new Date().getTime();
        addTestData(bg, atest, 100, 100, function(res) {
            end = new Date().getTime();
        });
        elapsed = end - start;
        var el = document.getElementById("add-notes");
        el.innerText = elapsed;

    })();

    // natively stringify
    (function() {
        start = new Date().getTime();
        JSON.stringify(atest);
        end = new Date().getTime();
        elapsed = end - start;
        var el = document.getElementById("native-stringify");
        el.innerText = elapsed;
    })();
    // custom toJSON
    (function() {
        start = new Date().getTime();
        var st = atest.toJSON();
        end = new Date().getTime();
        elapsed = end - start;
        var el = document.getElementById("anotes-toJSON");
        el.innerText = elapsed;
    })();
    // custom parsing 10,000 notes
    (function() {
        var an2 = new bg.anotes();
        start = new Date().getTime();
        an2.parse(atest.toJSON());
        end = new Date().getTime();
        elapsed = end - start;
        var el = document.getElementById("anotes-parse");
        el.innerText = elapsed;
    })();

    //Noteview stresstest(no sync)
    (function() {
        var _,n,nv,an2,anjson;
        _ = bg._;
        an2 = new bg.anotes();
        addTestData(bg, an2, 100, 100);
        anjson = an2.toJSON();
        _.each(anjson.pages[0].notes,function(note){


        });



        start = new Date().getTime();
        end = new Date().getTime();
        elapsed = end - start;
        var el = document.getElementById("noteview-stresstest");
        el.innerText = elapsed;



    })();

});

/***************************************************************************
 * ***********************************************************************************
 * ************************************************************************************
 * End Timing Tests
 * ************************************************************************************
 **************************************************************************/