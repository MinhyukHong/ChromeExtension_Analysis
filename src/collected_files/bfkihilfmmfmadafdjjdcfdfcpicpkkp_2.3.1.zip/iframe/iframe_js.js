window.addEventListener('message', handleMemberApprovalMessage, false);

/**
 * Converts the provided Facebook user profile URL or name slug to that user's Facebook ID
 *
 * @param {string} userIdentifyingUrlOrSlug - Either the profile URL or the name slug for the Facebook user
 *
 * @return {Promise<string>} the numeric Facebook ID of the matching user in the form of a string
 */
async function convertNameSlugToID (userIdentifyingUrlOrSlug) {
    let userId;
    if (userIdentifyingUrlOrSlug.indexOf('/user/') > 0 && userIdentifyingUrlOrSlug.indexOf('groups/') >= 0) {
        userId = userIdentifyingUrlOrSlug.split('/user/')[1].split('/')[0];
    } else {
        let retryAttempts = 0;
        do {
            userId = await returnUserUniqueID(userIdentifyingUrlOrSlug);
            retryAttempts++;
        } while (userId === userIdentifyingUrlOrSlug && retryAttempts < 5);
    }
    return userId;
}

/**
 * Handles the results of approving a single member or all members from the Facebook member requests page
 *
 * @param {Object} approvalResultsMessage - contains the information regarding the success of failure of the approval
 * @param {number} facebookTabId - The ID of the open Facebook tab where the approve button was clicked
 *
 * @return {Promise<void>} which resolves after the new member data has been sent to the cloud
 */
async function handleMemberApprovalMessage(approvalResultsMessage, facebookTabId) {

    // We only support approval messages, otherwise, the message should be ignored
    if (![MESSAGE_TYPE['approve_all'], MESSAGE_TYPE['approve_one']].includes(approvalResultsMessage.type)) {
        return;
    }

    for (let i = 0; i < approvalResultsMessage.users.length; i++) {
        if (isNaN(approvalResultsMessage.users[i].userID)) { // !Number.isInteger reports that all strings like "2903832839293" are not integers
            approvalResultsMessage.users[i].userID = await convertNameSlugToID(approvalResultsMessage.users[i].userID.trim());
        }
        if (approvalResultsMessage.users[i].invitedBy
            && approvalResultsMessage.users[i].invitedBy.hasOwnProperty('fbId')
            && isNaN(approvalResultsMessage.users[i].invitedBy.fbId)) {
            approvalResultsMessage.users[i].invitedBy.fbId = await convertNameSlugToID(approvalResultsMessage.users[i].invitedBy.fbId.trim());
        }
    }

    normalizeScrapedGroupMembersData(approvalResultsMessage, facebookTabId);
}

// this function returns Facebook memberID.
function returnUserUniqueID(memberID) {
    return new Promise(function (resolve) {
        $.ajax({
            url: "https://mbasic.facebook.com/" + memberID,
            type: "GET",
            processData: false,
            contentType: false,
            dataType: "text",
            success: function (data) {
                let links = $("a[href]", data);
                if (links) {
                    for (let i = 0, l = parseInt(links.length); i < l; i++) {
                        let element = new URLSearchParams(
                            "&" + links[i].getAttribute("href").toLowerCase().substring(links[i].getAttribute("href").toLowerCase().indexOf('?') + 1)
                        );
                        if (element.get("profile_id")) {
                            memberID = element.get("profile_id").trim();
                            break;
                        } else if (element.get("bid")) {
                            memberID = element.get("bid").trim();
                            break;
                        } else if (element.get("owner_id")) {
                            memberID = element.get("owner_id").trim();
                            break;
                        } else if (element.get("subjectid")) {
                            memberID = element.get("subjectid").trim();
                            break;
                        }
                    }
                }
                resolve(memberID);
                return false;
            },
            error: function () {
                resolve(memberID);
                return false;
            }
        });
    });
}

/**
 * Normalizes the Facebook group members data, and then sends it to the cloud.
 *
 * @param {object} facebookGroupMembersData - The Facebook groups and group members data to be updated to the cloud
 * @param {Number} facebookTabId - The browser tab ID for the scraped Facebook page
 *
 * @return {Promise<boolean>} - true if the normalized data was sent and accepted at the cloud without issue,
 *                              otherwise false
 *
 * @todo: separate the normalization from the sending to the cloud
 */
async function normalizeScrapedGroupMembersData(facebookGroupMembersData, facebookTabId) {

    let groupMembersData = {};
    let approvalResultsMessage = {};
    groupMembersData.group = facebookGroupMembersData.groupinfo
    groupMembersData.user_details = [];

    /** if check a userID is empty,then this record is not saved. */
    if (!facebookGroupMembersData.users.length) {
        approvalResultsMessage.type = MESSAGE_TYPE['update_facebook_ui'];
        approvalResultsMessage.memberWasAdded = false;
        approvalResultsMessage.approvalType = facebookGroupMembersData.type;
        chrome.tabs.sendMessage(facebookTabId, approvalResultsMessage);
        return false;
    }

    for (let i = 0; i < facebookGroupMembersData.users.length; i++) {
        let member = {};
        if (facebookGroupMembersData.users[i].userID == null || facebookGroupMembersData.users[i].userID === "ERROR") {
            member.user_id = "";
        } else {
            member.user_id = facebookGroupMembersData.users[i].userID;
        }

        if (facebookGroupMembersData.users[i].userName == null || facebookGroupMembersData.users[i].userName === "ERROR") {
            member.f_name = "";
            member.l_name = "";
        } else {
            member.name = facebookGroupMembersData.users[i].userName;
            if (member.name) {
                let array = member.name.replace(/\s+/, "|#GK*.!#|").split("|#GK*.!#|");
                member.f_name = array[0] || '';
                member.l_name = array[1] || '';
            } else {
                member.f_name = "";
                member.l_name = "";
            }
        }

        if (facebookGroupMembersData.users[i].questions.length) {
            let memberQuestions = facebookGroupMembersData.users[i].questions;
            if (memberQuestions[0]) {
                member.q1 = memberQuestions[0].question ?? '';
                member.a1 = memberQuestions[0].answer ?? '';
            }
            if (memberQuestions[1]) {
                member.q2 = memberQuestions[1].question ?? '';
                member.a2 = memberQuestions[1].answer ?? '';
            }
            if (memberQuestions[2]) {
                member.q3 = memberQuestions[2].question ?? '';
                member.a3 = memberQuestions[2].answer ?? '';
            }
        } else {
            member.q1 = member.q2 = member.q3 = member.a1 = member.a2 = member.a3 = "";
        }

        if (!facebookGroupMembersData.users[i].img || facebookGroupMembersData.users[i].img === "ERROR") {
            member.img = "";
        } else {
            member.img = facebookGroupMembersData.users[i].img;
        }

        member.date_add_time = parseInt(new Date().getTime()) + Math.floor(Math.random() * 10000) + 1;
        member.email = facebookGroupMembersData.users[i].questions.length
            ? extractEmail(facebookGroupMembersData.users[i].questions)
            : ''
        ;
        member.respond_status = "Processing";
        member.invited_by_name = facebookGroupMembersData.users[i].invitedBy.name;
        member.invited_by_id = facebookGroupMembersData.users[i].invitedBy.fbId;
        member.lives_in = facebookGroupMembersData.users[i].livesIn;
        member.agreed_group_rules = facebookGroupMembersData.users[i].agreedGroupRules;
        groupMembersData.user_details.push(member);
    }

    const response = await saveGroupMembersToCloud([groupMembersData]);
    if (response.limit === true) {
        const return_client_data = {
            type: MESSAGE_TYPE['limit_reached'],
            content: response,
        };
        chrome.tabs.sendMessage(facebookTabId, return_client_data);
        return false;
    }

    refreshWepAppPage(response.data);

    approvalResultsMessage = {};
    approvalResultsMessage.type = MESSAGE_TYPE['update_facebook_ui'];
    approvalResultsMessage.memberWasAdded = true;
    approvalResultsMessage.approvalType = facebookGroupMembersData.type;
    chrome.tabs.sendMessage(facebookTabId, approvalResultsMessage);

    return true;
}

/** Check if the WebApp tab is opened in browser, if not first open the WebApp */
function checkWebAppOpen() {
    return new Promise(function (resolve) {
        const appURL = conf.app_url;
        chrome.tabs.query({}, function (extensionTabs) {
            let found = false;
            for (let i = 0; i < extensionTabs.length; i++) {
                if (extensionTabs[i].url.indexOf(appURL) > -1) {
                    found = true;
                }
            }
            if (found === false) {
                chrome.tabs.create({url: appURL});
                resolve(false);
            } else {
                resolve(true);
            }
        });
    });
}
