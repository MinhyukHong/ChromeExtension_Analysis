/**
 *
 */

const LIMIT_PER_REQ = 500;
const ORDER_TYPE = "default";

let allScrapedMembers = [];
let scrapeCount = 0;
let GROUP_ID_INFO = 0;
let GROUP_NAME_INFO = "";
let LAST_LINK_PASS = "";
let GLOBAL_AJAX_DATA = null;
let SCRAPING_STOPPED = false;

/**
 * Identifies the current tab which is currently sending a message to be processed
 * @type {number}
 */
let tabId;

/** stop the facebook group member scraping */
function stopORDone() {
    SCRAPING_STOPPED = true;
    GROUP_ID_INFO = 0;
    LAST_LINK_PASS = "";
    allScrapedMembers = [];
    scrapeCount = 0;
    let obj = {
        'message': 'stop scraping.',
        'data': {"stop": 1}
    }
    sendMessageToCloud(obj)
    return false;
}

/** add the facebook group member and send to cloud  */
function saveScrapedMembersToCloud() {
    return new Promise(async function (resolve) {
        if (Array.isArray(allScrapedMembers) && !allScrapedMembers.length) {
            let groups = {'groupid': GROUP_ID_INFO, 'groupname': GROUP_NAME_INFO, 'img': ''}
            let obj = {
                'message': 'Success.',
                'data': [{'group': groups, 'user_details': []}]
            }
            sendMessageToCloud(obj)
            resolve("false");
        }

        let groupMemberData = [];
        let t = Math.round(new Date().getTime() / 1000);
        let facebookMemberID = "";
        for (let i = 0, l = parseInt(allScrapedMembers.length); i < l; i++) {
            facebookMemberID = "";
            try {
                facebookMemberID = parseInt(allScrapedMembers[i].id).toString().trim();
            } catch (e) {
                Bugsnag.notify(e);
            }
            if (
                allScrapedMembers[i] != null &&
                allScrapedMembers[i].id != null &&
                allScrapedMembers[i].fn != null &&
                allScrapedMembers[i].ln != null &&
                parseInt(allScrapedMembers[i].id) > 0 &&
                facebookMemberID.trim() != null
            ) {
                try {
                    groupMemberData.push({
                        fb_id: GROUP_ID_INFO.toString().trim(),
                        f_name: allScrapedMembers[i].fn.trim(),
                        l_name: allScrapedMembers[i].ln.trim(),
                        img: allScrapedMembers[i].img,
                        email: "",
                        user_id: facebookMemberID,
                        a1: "",
                        a2: "",
                        a3: "",
                        respond_status: "Processing",
                        date_add_time: t,
                    });
                } catch (e) {
                    Bugsnag.notify(e);
                }
            }
        }
        if (groupMemberData != null && parseInt(groupMemberData.length) > 0) {
            let groups = {'groupid': GROUP_ID_INFO, 'groupname': GROUP_NAME_INFO, 'img': ''}
            let obj = {
                'message': 'Success.',
                'data': [{'group': groups, 'user_details': groupMemberData}]
            }
            sendMessageToCloud(obj)
        }
        allScrapedMembers = [];
        resolve("true");
    });
}

/**
 * Filters provided scrapped HTML to get group details (id, name)
 *
 * @param {object} message containing scrapped group data
 * @param {number} facebookGroupID containing the numeric id of the facebook group
 *
 * @returns {boolean} false if we can't get group details, otherwise true
 */
function getGroupDetails(message, facebookGroupID) {
    const scrappedGroup = message.scrappedData;
    let messageData = {};

    let name = $(scrappedGroup).filter("title:first").text();

    try {
        if (name === "" || !facebookGroupID || isNaN(facebookGroupID)) {
            messageData = {
                'message': 'Unable to fetch data..',
                'data': {'stop': 1},
            }
            sendMessageToCloud(messageData);
            return false;
        }
    } catch (e) {
        Bugsnag.notify(e);
    }

    // scrape the data
    if (facebookGroupID) {
        GROUP_ID_INFO = facebookGroupID;
        GROUP_NAME_INFO = name.toString().trim();
        SCRAPING_STOPPED = false;
        LAST_LINK_PASS = "";

        return true;
    } else {
        messageData = {
            'message': 'Invalid data.',
            'data': {'stop': 1},
        }
        sendMessageToCloud(messageData);
        return false;
    }
}

/**
 * Prepares url for scraping group members
 * Sends prepared url to the service worker for scraping members via that url
 *
 * @param limit of how many group members we will scrape in the request
 * @param groupId of the group which members will be scraped
 * @param urlParams for modifying url for scraping members
 *
 * @returns {boolean} false if scraping is done, otherwise true
 */
function requestScrapingFbMembers(limit, groupId, urlParams) {
    if (SCRAPING_STOPPED) {
        return false;
    }

    let groupMemberURL = "https://www.facebook.com/ajax/browser/list/group_confirmed_members/" +
        "?gid=" + groupId + "&order=" + ORDER_TYPE + "&view=list&sectiontype=all_members" + "&limit=" + limit + "&start=0" + "";

    if (urlParams != null && urlParams !== "" && urlParams.trim() !== "") {
        let paramsData = new URLSearchParams(urlParams);
        if (
            paramsData.get("limit").trim() !== "" &&
            paramsData.get("av").trim() !== "" &&
            paramsData.get("start").trim() !== "" &&
            paramsData.get("cursor").trim() !== "" &&
            parseInt(paramsData.get("start").trim()) > 0 &&
            parseInt(paramsData.get("limit").trim()) > 0
        ) {
            let start = parseInt(paramsData.get("start").trim());
            let limit = parseInt(paramsData.get("limit").trim());
            let av = paramsData.get("av").trim();
            let cursor = paramsData.get("cursor").trim();
            groupMemberURL =
                "https://www.facebook.com/ajax/browser/list/group_confirmed_members/" +
                "?gid=" +
                groupId +
                "&order=" +
                ORDER_TYPE +
                "&view=list&sectiontype=all_members" +
                "&limit=" +
                limit +
                "&start=" +
                start +
                "&cursor=" +
                cursor +
                "&av=" +
                av;
        }
    }
    GLOBAL_AJAX_DATA = null;

    chrome.runtime.sendMessage({
        type: MESSAGE_TYPE['scrapeFbMembers'],
        url: groupMemberURL,
        tabId: tabId,
    });

    return true;
}

/**
 * Filters provided scrapped HTML to get group members included (id, first name, last name, image)
 *
 * @param groupMembers represents scrapped HTML that includes group members
 *
 * @returns {boolean} true if filtered successfully, otherwise false
 */
function getGroupMembers(groupMembers) {
    if (SCRAPING_STOPPED) {
        return false;
    }

    GLOBAL_AJAX_DATA = groupMembers;

    let data = GLOBAL_AJAX_DATA.replace("for (;;);", "");
    (async function () {
        let json = "";
        try {
            if (data != null && data !== "") {
                json = JSON.parse(data);
            }
            if (json != null && json !== "") {
                if (
                    json != null &&
                    json.domops != null &&
                    json.domops.length != null &&
                    parseInt(json.domops.length) > 0 &&
                    Array.isArray(json.domops) &&
                    json.domops[0] != null &&
                    json.domops[0].length != null &&
                    parseInt(json.domops[0].length) > 0 &&
                    Array.isArray(json.domops[0])
                ) {
                    for (let i = 0, l = parseInt(json.domops[0].length); i < l; i++) {
                        if (json.domops[0][i] != null && json.domops[0][i].__html != null && json.domops[0][i].__html !== "" && json.domops[0][i].__html.trim() !== "") {
                            let next_ajax_link_load = $(json.domops[0][i].__html.trim()).find("div.clearfix.uiMorePager.morePager>div>a");
                            if (
                                next_ajax_link_load != null &&
                                next_ajax_link_load[0] != null &&
                                next_ajax_link_load[0].getAttribute("href") != null &&
                                next_ajax_link_load[0].getAttribute("href") !== "" &&
                                next_ajax_link_load[0].getAttribute("href").trim() !== ""
                            ) {
                                LAST_LINK_PASS = next_ajax_link_load[0].getAttribute("href").trim();
                            } else {
                                LAST_LINK_PASS = "abort";
                            }
                            const usersImage = $(json.domops[0][i].__html.trim()).find(
                                "div.clearfix._60rh._gse img._s0._4ooo.img"
                            );
                            let users_data = $(json.domops[0][i].__html.trim()).find("div.clearfix._60rh._gse>div.clearfix._8u._42ef>div.uiProfileBlockContent._61ce>div._6a>div._6a._6b>div._60ri>a");
                            if (users_data != null && users_data.length != null && parseInt(users_data.length) > 0) {
                                let fullname = "";
                                let fname = "";
                                let lname = "";
                                let mid = "";

                                for (let i1 = 0, l1 = parseInt(users_data.length); i1 < l1; i1++) {
                                    if (
                                        users_data[i1] != null &&
                                        users_data[i1].getAttribute("title") != null &&
                                        users_data[i1].getAttribute("title") !== "" &&
                                        users_data[i1].getAttribute("title").trim() !== ""
                                        && (
                                            users_data[i1].getAttribute("ajaxify")?.trim()
                                            || users_data[i1].getAttribute("data-hovercard")?.trim()
                                        )
                                    ) {
                                        fullname = "";
                                        fname = "";
                                        lname = "";
                                        mid = 0;

                                        fullname = users_data[i1].getAttribute("title").trim();

                                        const params = new URLSearchParams(
                                            users_data[i1].getAttribute("ajaxify")?.trim()
                                            ?? users_data[i1].getAttribute("data-hovercard")?.trim()?.replace('/ajax/hovercard/user.php?', '')
                                        );

                                        mid = parseInt(params.get('member_id') ?? params.get('id'));

                                        /** middle initial let's include in the last name field. */
                                        if (fullname) {
                                            let array = fullname.replace(/\s+/, "|#GK*.!#|").split("|#GK*.!#|");
                                            fname = array[0] || '';
                                            lname = array[1] || '';
                                        } else {
                                            fname = "";
                                            lname = "";
                                        }

                                        const imageURL = usersImage.map(function (index, image) {
                                            if (fullname === image.getAttribute('aria-label')) {
                                                return image.getAttribute('src')
                                            }
                                        }).filter(function (data) {
                                            return data !== undefined
                                        });

                                        if (mid !== 0 && fullname !== "") {
                                            allScrapedMembers.push({
                                                id: mid,
                                                fn: fname,
                                                ln: lname,
                                                full: fullname,
                                                img: imageURL[0] ?? null,
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (SCRAPING_STOPPED) {
                    return false;
                }
                scrapeCount = scrapeCount + allScrapedMembers.length;
                $("#num_mem_scrapped").html(scrapeCount);

                await saveScrapedMembersToCloud();

                if (LAST_LINK_PASS === "abort") {
                    setTimeout(function () {
                        stopORDone();
                    }, 2000);
                    SCRAPING_STOPPED = true;
                    GROUP_ID_INFO = 0;
                    LAST_LINK_PASS = "";
                    allScrapedMembers = [];
                    scrapeCount = 0;
                    return false;
                }

                if (LAST_LINK_PASS !== "") {
                    if (LAST_LINK_PASS !== "abort") {
                        requestScrapingFbMembers(LIMIT_PER_REQ, GROUP_ID_INFO, LAST_LINK_PASS);
                    }
                } else {
                    requestScrapingFbMembers(LIMIT_PER_REQ, GROUP_ID_INFO);
                }
            }
        } catch (e) {
            if (LAST_LINK_PASS !== "") {
                if (LAST_LINK_PASS !== "abort") {
                    requestScrapingFbMembers(LIMIT_PER_REQ, GROUP_ID_INFO, LAST_LINK_PASS);
                }
            } else {
                requestScrapingFbMembers(LIMIT_PER_REQ, GROUP_ID_INFO);
            }

            Bugsnag.notify(e);
        }
    })();
}

chrome.runtime.onMessage.addListener(
    /**
     * Listeners events surrounding sending scraped Facebook group member data to the cloud
     * Only messages sent by this extension will be honored.
     *
     * @param {*} message - information sent by this extension to be further processed
     * @param {MessageSender} sender - the entity that sent the message.
     *                                  Messages from senders that are not this extension will be ignored
     *
     * @return {Promise<boolean|void>} wrapping various responses indicating the outcome of the message processing
     */
    async function (message, sender) {
        const messageIsFromThisExtension = sender.id === chrome.runtime.id;

        if (messageIsFromThisExtension) {
            switch (message.type) {
                case MESSAGE_TYPE['scrapedFacebookGroup']:
                    if (!getGroupDetails(message, message.facebookGroupId)) {
                        return;
                    }

                    tabId = message.tabId;
                    if (message.shouldScrapeMembers) {
                        return requestScrapingFbMembers(LIMIT_PER_REQ, GROUP_ID_INFO);
                    }

                    sendMessageToCloud({
                        type: MESSAGE_TYPE['send_facebook_group_details'],
                        groupid: GROUP_ID_INFO,
                        groupname: GROUP_NAME_INFO,
                    });
                    break;
                case MESSAGE_TYPE['send_member_scraping_stop']:
                    tabId = sender.tab.id;
                    return stopORDone();

                case MESSAGE_TYPE['groupMembersScraped']:
                    getGroupMembers(message.groupMembers)
                    break;
                default:
                    break;
            }
        }
    }
);

function sendMessageToCloud(messageObject) {
    messageObject.type = messageObject.type ?? MESSAGE_TYPE['send_scraped_member_data'];
    window.postMessage(messageObject, "*")
}
