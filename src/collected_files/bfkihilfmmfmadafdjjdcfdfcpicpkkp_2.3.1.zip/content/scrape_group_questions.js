/**
 * The script injected into a new tab in membership page(https://www.facebook.com/groups/xxxx/membership_questions),
 * which is used for scrapping membership question: questionOne, questionTwo, questionThree.
 */

/**
 * Selectors for the group first question
 *
 * @type {string[]}
 */
const QUESTION_ONE_SELECTORS = [
    'div.x9f619.x2lah0s.x1n2onr6.x78zum5.x1iyjqo2.x1t2pt76.x1lspesw > div > div > div > div > div:nth-child(2) > div > div > div > div:nth-child(2) > div > span',
    'div.x9f619.x2lah0s.x1n2onr6.x78zum5.x1iyjqo2.x1t2pt76.x1lspesw > div > div > div > div > div > div > div:nth-child(2) > div > div > div > div:nth-child(2) > div > span',
    'div.x9f619.x1n2onr6.x1ja2u2z.xdt5ytf.x193iq5w.xeuugli.x1r8uery.x1iyjqo2.xs83m0k.x78zum5.x1t2pt76 > div > div > div > div > div:nth-child(2) > div > div > div > div:nth-child(2) > div > span',
];

/**
 * Selectors for the group second question
 *
 * @type {string[]}
 */
const QUESTION_TWO_SELECTORS = [
    'div.x9f619.x2lah0s.x1n2onr6.x78zum5.x1iyjqo2.x1t2pt76.x1lspesw > div > div > div > div > div:nth-child(3) > div > div > div > div:nth-child(2) > div > span',
    'div.x9f619.x2lah0s.x1n2onr6.x78zum5.x1iyjqo2.x1t2pt76.x1lspesw > div > div > div > div > div > div > div:nth-child(3) > div > div > div > div:nth-child(2) > div > span',
    'div.x9f619.x1n2onr6.x1ja2u2z.xdt5ytf.x193iq5w.xeuugli.x1r8uery.x1iyjqo2.xs83m0k.x78zum5.x1t2pt76 > div > div > div > div > div:nth-child(3) > div > div > div > div:nth-child(2) > div > span',
];

/**
 * Selectors for the group third question
 *
 * @type {string[]}
 */
const QUESTION_THREE_SELECTORS = [
    'div.x9f619.x2lah0s.x1n2onr6.x78zum5.x1iyjqo2.x1t2pt76.x1lspesw > div > div > div > div > div:nth-child(4) > div > div > div > div:nth-child(2) > div > span',
    'div.x9f619.x2lah0s.x1n2onr6.x78zum5.x1iyjqo2.x1t2pt76.x1lspesw > div > div > div > div > div > div > div:nth-child(4) > div > div > div > div:nth-child(2) > div > span',
    'div.x9f619.x1n2onr6.x1ja2u2z.xdt5ytf.x193iq5w.xeuugli.x1r8uery.x1iyjqo2.xs83m0k.x78zum5.x1t2pt76 > div > div > div > div > div:nth-child(4) > div > div > div > div:nth-child(2) > div > span',
];

/**
 * Async function for scraping group questions
 */
new Promise(async (resolve) => {
    await sleep(2000); // wait for DOM load

    const questionOne = document.querySelector(QUESTION_ONE_SELECTORS.join(','))
        ? document.querySelector(QUESTION_ONE_SELECTORS.join(',')).innerText
        : ''
    ;

    const questionTwo = document.querySelector(QUESTION_TWO_SELECTORS.join(','))
        ? document.querySelector(QUESTION_TWO_SELECTORS.join(',')).innerText
        : ''
    ;

    const questionThree = document.querySelector(QUESTION_THREE_SELECTORS.join(','))
        ? document.querySelector(QUESTION_THREE_SELECTORS.join(',')).innerText
        : ''
    ;

    if (!questionOne) {
        resolve({}); // if there is no questions we are sending empty questions back
    }

    resolve({
        question_1: questionOne,
        question_2: questionTwo,
        question_3: questionThree,
    });
});