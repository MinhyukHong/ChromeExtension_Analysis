/** different types of event send to the web App page. */
chrome.runtime.onMessage.addListener(async function (message) {
    switch (message.type) {
        case MESSAGE_TYPE['send_group_data']:
            return window.postMessage({
                type: "refresh_data",
                response: message.value,
            }, "*");
        case MESSAGE_TYPE['send_aweber_token']:
            return window.postMessage(message.data, "*");
        case MESSAGE_TYPE['send_scraped_member_data']:
            return window.postMessage(message, "*");
        case MESSAGE_TYPE['postCreationstatus']:
            return window.postMessage({
                response: message.data,
            }, "*");
    }
})

/** this function used to Listen to the different types of webPage event. */
window.addEventListener("message",
    function (event) {
        switch (event.data.type) {
            case MESSAGE_TYPE['send_member_scraping_details']:
            case MESSAGE_TYPE['send_member_scraping_stop']:
            case MESSAGE_TYPE['getFacebookGroupDetails']:
            case MESSAGE_TYPE['createNewPostByExtension']:
                chrome.runtime.sendMessage(event.data);

                return true;
            case 'update_cloud_ui':
                window.postMessage(
                    {
                        type: "refresh_data",
                        response: event.data.response,
                    },
                    "*"
                );
                break;
            default:
                // unsupported message type
        }
    }
);

/** create new element in body tag */
let groupKitElement = document.createElement("groupkit");
groupKitElement.setAttribute('id', 'groupkit_cloud_store');
document.body.appendChild(groupKitElement);
