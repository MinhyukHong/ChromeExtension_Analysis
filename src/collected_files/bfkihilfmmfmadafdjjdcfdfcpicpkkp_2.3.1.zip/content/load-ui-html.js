/**
 * Inject HTML in the Facebook page needed for the extension's UI.
 */

/** @constant {string} */
const CLAP_IMAGE_URL = chrome.runtime.getURL("images/clapsmall.png");

/** @constant {string} */
const FIST_IMAGE_URL = chrome.runtime.getURL("images/fistsmall.png");

/** @constant {string} */
const GROUPKIT_LOGO_IMAGE_URL = chrome.runtime.getURL("images/logo.png");

/** inject Ui/Html in facebook page  */
const loadUiHtml = () => {
    try {
        const head = document.head || document.getElementsByTagName('head')[0];
        const body = document.body || document.getElementsByTagName('body')[0];
        const alink = document.createElement('link');
        alink.rel = "stylesheet";
        alink.href = chrome.runtime.getURL("lib/css/all.css");
        head.appendChild(alink);
        const htmlData =
            `
            <!-- Successfully added single member modal start -->
            <div 
                id="members_complete_one"
                style="all: unset;display: none;z-index: 2147483647;background: #fbfbfd;text-align: center;height: 180px;width: 350px;border-width: 5px;border-style: solid;border-color: #3a69b2;border-radius: 5px;color:#2f2f2f;font-family: \'Source Sans Pro\', Helvetica, sans-serif !important;user-select: none;position: fixed;top: 0px;right: 0px;bottom: 0px;left: auto;float: right;padding-top: 15px;padding-bottom: 0px;padding-left: 0px;padding-right: 10px;margin-top: 60px;margin-left: 0px;margin-bottom: 0px;margin-right: 40px;"
            >
                <div style="all: unset;display: block;word-wrap: break-word;text-align: center;">
                    <img style="width:225px;height:auto;display:inline-block;" width="225" src="${GROUPKIT_LOGO_IMAGE_URL}">
                </div>
                <div style="all: unset;display: block;word-wrap: break-word;line-height: 1.42;text-align: center;font-size: 18px;">
                    <br/>
                    <span id="members_complete_one_wahoo_message">Wahooo! Your group is growing&nbsp;</span>
                    <img src="${FIST_IMAGE_URL}">
                    <br>
                    <span id="gk_memberappmessage"></span>
                </div>
            </div>
            <!-- Successfully added single member modal end -->

            <!-- Successfully approve all the members modal start -->
            <div
                id="members_complete"
                style="display:none;position: fixed;top: 0px;bottom: 0px;left: 0px;right: 0px;width: 100%;height: 100%;z-index: 2147483647;" class="mainc"
            >
                <div class="wrapperc">
                    <div style="all: unset;display: block;z-index: 2147483647;background: #fbfbfd;display: block;margin: 0 auto;text-align: center;height: 300px;width: 550px;border-width: 5px;border-style: solid;border-color: #3a69b2;border-radius: 5px;padding-top: 47px;padding-bottom: 0px;padding-left: 25px;padding-right: 25px;color:#2f2f2f;font-family: \'Source Sans Pro\', Helvetica, sans-serif !important;">
                        <div style="all: unset;display: block;word-wrap: break-word;text-align: center;">
                            <img style="width:225px;height:auto;display:inline-block;" width="225" src="${GROUPKIT_LOGO_IMAGE_URL}">
                        </div>
                        <div style="all: unset;display: block;word-wrap: break-word;line-height: 1.42;text-align: center;font-size: 22px;">
                            <br/>
                            <span id="members_complete_one_wahoo_message">Wahooo! Your group is growing&nbsp;</span>
                            <img src="${FIST_IMAGE_URL}"/>
                            <br/>
                            <b id="complete_mem_sats_gk">999</b>
                                new members were approved.
                        </div>
                        <div style="text-align: center;font-size: 12px;margin-top: 15px;">
                            Note: GroupKit cannot control the speed at which Facebook™ approves your new members.
                            It may take a few moments before they show as approved, and you may need to refresh the approvals page.
                        </div>
                        <div style="all: unset;display: block;word-wrap: break-word;text-align: center;">
                            <button 
                                id="all_members_finished_gk"
                                type="button"
                                style="all: unset;display: block;padding-left: 25px !important;padding-right: 25px !important;padding-top: 10px !important;padding-bottom: 10px !important;margin-right: auto;margin-left: auto;font-weight: bold;display: inline-block;text-align: center !important;text-decoration: none !important;margin-top:10px;border-radius: 3px;border: 1px solid #00000033;color: #ffffff;font-weight: 600;background-color: #72c743;font-size: 20px;cursor: pointer;"
                            >
                                Done
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Successfully approve all the members modal end -->

            <!-- Approving single member modal start -->
            <div 
                id="member_waiting_screen"
                style="display:none;position: fixed;top: 0px;bottom: 0px;left: 0px;right: 0px;width: 100%;height: 100%;z-index: 2147483647;" 
            >
                <div>
                    <div style="all: unset;z-index: 2147483647;background: #fbfbfd;display: block;margin-top: 60px;margin-left: 0px;margin-bottom: 0px;margin-right: 40px;text-align: center;height: 180px;width: 350px;border-width: 5px;border-style: solid;border-color: #3a69b2;border-radius: 5px;padding-top: 15px;padding-bottom: 0px;padding-left: 0px;padding-right: 10px;color:#2f2f2f;font-family: \'Source Sans Pro\', Helvetica, sans-serif !important;float: right;"
                    >
                        <div style="all: unset;display: block;user-select: none;word-wrap: break-word;text-align: center;">
                            <img style="width:225px;height:auto;display:inline-block;" width="225" src="${GROUPKIT_LOGO_IMAGE_URL}">
                        </div>
                        <div style="all: unset;display: block;text-align: center;padding-top: 20px;word-wrap: break-word;font-size: 22px;line-height: 1.42;"
                        >
                            <span id="member_waiting_screen_is_approving">Is Approving</span>
                            <span class="loading"></span>
                        </div>
                        <div style="all: unset;display: block;word-wrap: break-word;line-height: 1.42;text-align: center;font-size: 25px;"
                        >
                            <b><span id="member_waiting_screen_new_member">New member</span></b>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Approving single member modal end -->

            <!-- Approving all members modal start -->
            <div 
                id="members_waiting_screen"
                style="display:none;position: fixed;top: 0px;bottom: 0px;left: 0px;right: 0px;width: 100%;height: 100%;z-index: 2147483647;" 
                class="mainc"
            >
                <div class="wrapperc">
                    <div style="all: unset;display: block;z-index: 2147483647;background: #fbfbfd;display: block;margin: 0 auto;text-align: center;height: 300px;width: 550px;border-width: 5px;border-style: solid;border-color: #3a69b2;border-radius: 5px;padding-top: 47px;padding-bottom: 0px;padding-left: 25px;padding-right: 25px;color:#2f2f2f;font-family: \'Source Sans Pro\', Helvetica, sans-serif !important;"
                    >
                        <div style="all: unset;display: block;word-wrap: break-word;text-align: center;">
                            <img style="width:225px;height:auto;display:inline-block;" width="225" src="${GROUPKIT_LOGO_IMAGE_URL}">
                        </div>
                        <div style="all: unset;display: block;text-align: center;padding-top: 20px;word-wrap: break-word;font-size: 22px;line-height: 1.42;"
                        >
                            Is Approving
                            <span class="loading"></span>
                        </div>
                        <div style="all: unset;display: block;word-wrap: break-word;line-height: 1.42;text-align: center;font-size: 40px;">
                            <b id="all_start_num_gk">1</b> of <b id="all_end_num_gk">999</b>
                        </div>
                        <div 
                            id="approve_all_message"
                            style="
                                font-size: 16px;
                                display: none;
                            "
                        >
                            Please remain on this page while we process your new members.
                        </div>
                        <div style="all: unset;display: block;word-wrap: break-word;text-align: center;">
                            <button id="all_button_stop_gk" type="button" style="all: unset;display: block;padding-left: 25px !important;padding-right: 25px !important;padding-top: 10px !important;padding-bottom: 10px !important;margin-right: auto;margin-left: auto;font-weight: bold;display: inline-block;text-align: center !important;text-decoration: none !important;margin-top:20px;border-radius: 3px;border: 1px solid #00000033;color: #ffffff;font-weight: 600;background-color: #e43b2c;font-size: 20px;cursor: pointer;"
                            >
                                Stop
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Approving all members modal end -->

            <!-- Member successfully approved modal start -->                
            <div 
                id="alert_message1"
                style="user-select: none;width:240px;position: fixed; top: 0px; right: 0px; margin-top: 78px; margin-right: 20px; color: rgb(255, 255, 255); background-color: rgb(2, 90, 165); padding: 15px; margin-bottom: 20px; border: 1px solid; border-radius: 4px; font-size: 15px; display: none; flex-wrap: wrap; z-index: 2147483647;"
            >
                <div style="width: 88%;display: inline-block;">
                    Your member has been approved and saved to the cloud.
                    &nbsp;&nbsp;
                    <img src="${FIST_IMAGE_URL}"/>
                </div>
                <div 
                    id="groupkit_alert_btn_1"
                    style="text-align: right;width: 9%;display: inline-block;padding-left: 2px;padding-right: 2px;cursor: pointer;"
                >
                    X
                </div>
            </div>
            <!-- Member successfully approved modal end -->

            <!-- Modal for successfully approved members on Approve All button start -->
            <div 
                id="alert_message2"
                style="user-select: none;width:240px;position: fixed; top: 0px; right: 0px; margin-top: 78px; margin-right: 20px; color: rgb(255, 255, 255); background-color: rgb(2, 90, 165); padding: 15px; margin-bottom: 20px; border: 1px solid; border-radius: 4px; font-size: 15px; display: none; flex-wrap: wrap; z-index: 2147483647;"
            >
                <div style="width: 88%;display: inline-block;">
                    Success! All 
                    <span id="users_num">
                        <b id="numaproved"></b>
                    </span>
                    of your members were approved and their data was saved.&nbsp;&nbsp;
                    <img src="${CLAP_IMAGE_URL}"/>
                </div>
                <div 
                    id="groupkit_alert_btn_2" 
                    style="text-align: right;width: 9%;display: inline-block;padding-left: 2px;padding-right: 2px;cursor: pointer;"
                >
                    X
                </div>
            </div>
            <!-- Modal for successfully approved members on Approve All button end -->

            <!-- Modal error message for unsuccesfull Approve All specifying approve one by one start -->
            <div 
                id="approve_all_error"
                style="display:none;position: fixed;top: 0px;bottom: 0px;left: 0px;right: 0px;width: 100%;height: 100%;z-index: 2147483647;" 
                class="mainc"
            >
                <div class="wrapperc">
                    <div style="all: unset;display: block;z-index: 2147483647;background: #fbfbfd;display: block;
                    margin: 0 auto;text-align: center;height: 450px;width: 550px;border-width: 5px;border-style: solid;
                    border-color: #3a69b2;border-radius: 5px;padding: 47px 25px 0px;color:#2f2f2f;
                    font-family: \'Source Sans Pro\', Helvetica, sans-serif !important;">
                        <div style="all: unset;display: block;word-wrap: break-word;text-align: center;">
                            <img style="width:225px;height:auto;display:inline-block;" width="225" src="${GROUPKIT_LOGO_IMAGE_URL}">
                        </div>
                        <div style="font-size: 20px; padding-top: 15px;">
                        Yikes! Unfortunately while approving your group members we have detected some group members 
                        we cannot sync. As a safety precaution we have stopped approving all of your group members 
                        and recommend switching to individual group member approval. Note: Our development team has 
                        been notified and will investigate further.
                        </div>
                        <div style="all: unset;display: block;text-align: center;padding-top: 20px;word-wrap: break-word;font-size: 22px;line-height: 1.42;"
                        >
                            Approved
                            <span class="loading"></span>
                        </div>
                        <div style="all: unset;display: block;word-wrap: break-word;line-height: 1.42;text-align: center;font-size: 40px;">
                            <b class="approved">0</b> of <b class="total-to-approve" ">999</b>
                        </div>
                        <div 
                            id="approve_all_message"
                            style="
                                font-size: 16px;
                                display: none;
                            "
                        >
                            Please remain on this page while we process your new members.
                        </div>
                        <div style="all: unset;display: block;word-wrap: break-word;text-align: center;">
                            <button id="all_button_stop_gk" type="button" style="all: unset;display: block;padding-left: 25px !important;padding-right: 25px !important;padding-top: 10px !important;padding-bottom: 10px !important;margin-right: auto;margin-left: auto;font-weight: bold;display: inline-block;text-align: center !important;text-decoration: none !important;margin-top:20px;border-radius: 3px;border: 1px solid #00000033;color: #ffffff;font-weight: 600;background-color: #e43b2c;font-size: 20px;cursor: pointer;"
                            >
                                Stop
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal error message for unsuccesfull Approve All specifying approve one by one end -->                

            <!-- todo: check is this modal is unused start -->                
            <div 
                id="alert_message3"
                style="user-select: none;width:240px;position: fixed; top: 0px; right: 0px; margin-top: 78px; margin-right: 20px; color: rgb(255, 255, 255); background-color: rgb(2, 90, 165); padding: 15px; margin-bottom: 20px; border: 1px solid; border-radius: 4px; font-size: 15px; display: none; flex-wrap: wrap; z-index: 2147483647;"
            >
                <div style="width: 88%;display: flex;">
                    <i class="fa fa-3x fa-spinner fa-spin"></i>
                    <div style="padding-top: 8px;font-size: 22px;margin: 0 auto;">
                        Working
                        <span class="loadingff"></span>
                    </div>
                </div>
            </div>
            <!-- todo: check is this modal is unused end -->
            
            <div 
                id="back_droup_modal"
                style="display:none;opacity: 0.8;position: fixed;top: 0;right: 0;bottom: 0;left: 0;z-index: 999999;background-color: #000000;width: 100%;height: 100%;"
            >
            </div>
            <div
                style="display:none;position: fixed;top: 0;right: 0;bottom: 0;left: 0;z-index: 1040;"
                id="back_droup_modal_1"
            >
            </div>
            <style type="text/css">
                div._51xa {
                    padding-bottom:3px;
                }
                .fa-spin {
                    animation-duration: 4s;
                }
                .loading:after {
                    content: \' .\';
                    animation: dots 1s steps(5, end) infinite;
                }
                
                @keyframes dots {
                    0%, 20% {
                        color: rgba(0,0,0,0);
                        text-shadow:.25em 0 0 rgba(0,0,0,0),.5em 0 0 rgba(0,0,0,0);
                    }
                    40% {
                        color: #000000;
                        text-shadow:.25em 0 0 rgba(0,0,0,0),.5em 0 0 rgba(0,0,0,0);
                    }
                    60% {
                        text-shadow:.25em 0 0 #000000,.5em 0 0 rgba(0,0,0,0);
                    }
                    80%, 100% {
                        text-shadow:.25em 0 0 #000000,.5em 0 0 #000000;
                    }
                }
                
                .mainc, div.mainc {
                    height: 100%;
                    width: 100%;
                    display: table;
                } 
                .wrapperc, div.wrapperc {
                    display: table-cell;
                    height: 100%;
                    vertical-align: middle;
                }
                div.jconfirm-holder,
                .jconfirm-holder,
                div.jc-bs3-container.container,
                div.jc-bs3-container,
                .jc-bs3-container,
                .jc-bs3-container.container {
                    width: 300px;
                    margin: 0 auto;
                }
            </style>`;
        const messageElement = document.createElement("div");
        messageElement.innerHTML = htmlData;
        body.appendChild(messageElement);
        document.getElementById("groupkit_alert_btn_1").addEventListener("click", groupKitAlertHide);
        document.getElementById("groupkit_alert_btn_2").addEventListener("click", groupKitAlertHide);
        document.getElementById("all_button_stop_gk").addEventListener("click", () => {
            stopButton = true;
            return false;
        });
        document.getElementById("all_members_finished_gk").addEventListener("click", () => {
            $("#members_complete").hide();
            $("#back_droup_modal").hide();

            //fire facebooks modal Confirm button click event
            document.querySelector(FACEBOOK_APPROVE_ALL_MEMBERS_CONFIRM_BUTTON_SELECTOR)?.click();

            return false;
        });
    } catch (e) {
        Bugsnag.notify(e);
    }
}
