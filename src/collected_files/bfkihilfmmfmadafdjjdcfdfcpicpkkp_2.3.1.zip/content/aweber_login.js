/** when the user can authenticate Aweber after that we have sent Token in webApp */
// todo: move aweber authentication to the cloud
if (new URL(window.location.href).searchParams.get("code") != null) {
    const message = {
        code: new URL(window.location.href).searchParams.get("code"),
        type: MESSAGE_TYPE['aweber_login'],
    }
    chrome.runtime.sendMessage(message);
}