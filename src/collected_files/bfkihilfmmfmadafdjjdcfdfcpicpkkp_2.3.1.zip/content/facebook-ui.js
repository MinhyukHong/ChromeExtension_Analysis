/**
 * Logic for adding and manipulating GroupKit components within the Facebook UI
 */

/**
 * Determines whether directives like approvals should be saved to Facebook.  This could
 * be set to true for debugging purposes.
 *
 * @type {boolean}
 */
let preventPersistingOnFacebook = conf.approvals_debug_mode;

/** @constant {string} */
const APPROVE_ALL_IMAGE_URL = chrome.runtime.getURL("images/img_btn.png");

/** @constant {string} */
const APPROVE_ONE_IMAGE_URL = chrome.runtime.getURL("images/img_btn_2.png");

/** @constant {string} */
const ENABLE_IMAGE_URL = chrome.runtime.getURL('images/enable.png');

/** @constant {string} */
const DISABLE_IMAGE_URL = chrome.runtime.getURL('images/disable.png');

/**
 * The id of the enable GroupKit image
 *
 * @type {string}
 */
const ENABLE_IMAGE_ID = 'enable_gk_image';

/**
 * The id of the disable GroupKit image
 *
 * @type {string}
 */
const DISABLE_IMAGE_ID = 'disable_gk_image';

/**
 * The class selectors for the containers for each group member on the member-requests page
 *
 * @type {string[]}
 */
const FACEBOOK_GROUP_MEMBER_CONTAINER_SELECTORS = [
    '.dhix69tm.wkznzc2l.sjgh65i0',
    '.l9j0dhe7.stjgntxs.ni8dbmo4.ap1mbyyd.dhix69tm.wkznzc2l.ibutc8p7.l82x9zwi.uo3d90p7.cwj9ozl2 .a8nywdso.f10w8fjw.rz4wbd8a.pybr56ya',
    '.nch0832m.rj2hsocd.oxkhqvkx.s1m0hq7j',  // Facebook updated UI August 2022.
    '.nch0832m.r5g9zsuq.oxkhqvkx.q46jt4gp',  // Facebook updated UI October 2022.
    '.xkhd6sd.xwib8y2.x4uap5.x1y1aw1k', // Facebook updated UI October 2022. second time
    '.xkhd6sd.xsag5q8.x4uap5.xz9dl7a', // Facebook updated UI October 2022. second time
];

/**
 * The filter selector determines if a group member agreed to the Facebook group rules if rules exist
 *
 * @type {object}
 */
const FACEBOOK_GROUP_MEMBER_RULES = {
    QUESTION_SELECTOR: "Do you agree to the group rules from the admin?",
    ANSWER_TO_AGREED_RULES: "I agree",
};

/**
 * List of Facebook Approve All button selectors for replacing that button with GroupKit Approve All button
 *
 * @type {array} containing the 'approve all' button selectors for English and French
 */
const FACEBOOK_APPROVE_ALL_BUTTON_SELECTORS = [
    "div[aria-label='Approve All']",
    "div[aria-label='Approve all']",
    "button[name='approve_all']",
    "div[aria-label='Tout approuver']",
    "div[aria-label='Tout Approuver']",
    "div[aria-label='Aprobar Todas']",
    "div[aria-label='Aprobar todas']",
];

/**
 * List of Facebook Approve button selectors for replacing that button with GroupKit Approve button
 *
 * @type {array} containing the approve button selectors for English and French
 */
const FACEBOOK_APPROVE_BUTTON_SELECTORS = [
    "div[aria-label='Approve']",
    "button[name='approve']",
    "div[aria-label='Approuver']",
    "button[name='approuver']",
    "div[aria-label='Aprobar']",
    "button[name='aprobar']",
    "div[aria-label^='Approve']",
    "button[name^='approve']",
    "div[aria-label^='Approuver']",
    "button[name^='approuver']",
    "div[aria-label^='Aprobar']",
    "button[name^='aprobar']",
];

/**
 * List for number of matching group member requests
 *
 * @type {string[]}
 */
const NUMBER_OF_MEMBER_REQUEST_SELECTORS = [
    'div._ohe.lfloat>div._4k1_._8o._8r>span._50f9._50f7',
    '.d2edcug0.hpfvmrgz.qv66sw1b.c1et5uql.b0tq1wua.o0t2es00.f530mmz5.hnhda86s.m9osqain > span:nth-child(2)',
    '.d2edcug0.hpfvmrgz.qv66sw1b.c1et5uql.lr9zc1uh.o0t2es00.f530mmz5.hnhda86s.m9osqain > span:nth-child(2)',
    '.d2edcug0.hpfvmrgz.qv66sw1b.c1et5uql.oi732d6d.ik7dh3pa.ht8s03o8.o0t2es00.f530mmz5.hnhda86s.m9osqain > span:nth-child(2)',
    '.d2edcug0.hpfvmrgz.qv66sw1b.c1et5uql.o0t2es00.f530mmz5.hnhda86s.m9osqain > span:nth-child(2)',
    '.gvxzyvdx.aeinzg81.t7p7dqev.gh25dzvf.tb6i94ri.gupuyl1y.i2onq4tn.qntmu8s7.tq4zoyjo.o48pnaf2.rtxb060y > span:nth-child(2)',
    '.gvxzyvdx.aeinzg81.t7p7dqev.gh25dzvf.exr7barw.qntmu8s7.tq4zoyjo.o48pnaf2.rtxb060y > span:nth-child(2)',
    '.x193iq5w.xeuugli.x13faqbe.x1vvkbs.xlh3980.xvmahel.x1n0sxbx.xngnso2.x1qb5hxa.x1xlr1w8.xi81zsa > span:nth-child(2)',
    '.x193iq5w.xeuugli.x13faqbe.x1vvkbs.x1xmvt09.xngnso2.x1qb5hxa.x1xlr1w8.xi81zsa > span:nth-child(2)',
    '.x1heor9g.x1qlqyl8.x1pd3egz.x1a2a7pz .x193iq5w.xeuugli.x13faqbe.x1vvkbs.x1quz6wq.xngnso2.x1qb5hxa.x1xlr1w8.xi81zsa',
];

/**
 * Facebook Approve all member requests modal confirm button selector
 *
 * @type {string}
 */
 const FACEBOOK_APPROVE_ALL_MEMBERS_CONFIRM_BUTTON_SELECTOR =
    "[aria-label='Approve all member requests?'] [aria-label='Confirm']";

/**
 * Facebook Member Request text div selectors
 * Represents parent div of the "Member/Participant requests  · number of group member"
 * after which we will inject GroupKit Disable button
 *
 * @type {Array}
 */
const FACEBOOK_MEMBER_REQUEST_TEXT_SELECTORS = [
    'div.gderk4og div.rq0escxv.l9j0dhe7.du4w35lb.j83agx80.cbu4d94t.pfnyh3mw.d2edcug0.hpfvmrgz.p8fzw8mz.pcp91wgn.iuny7tx3.ipjc6fyt',
    'div.exbtdzjn.dhod7fyx.ir39z7dx.mfclru0v .bdao358l.om3e55n1.g4tp4svg.alzwoclg.cqf1kptm.jez8cy9q.gvxzyvdx.aeinzg81.i5oewl5a.nnzkd6d7.bmgto6uh.f9xcifuu',
    'div.x1srbbgq.xqmdsaz.x1xfsgkm.xh8yej3 div.x9f619.x1n2onr6.x1ja2u2z.x78zum5.x2lah0s.x1qughib.x6s0dn4.x1a02dak.x1q0g3np.xwib8y2.x1y1aw1k.xykv574.xbmpl8g.x4cne27.xifccgj div.x9f619.x1n2onr6.x1ja2u2z.x78zum5.xdt5ytf.x2lah0s.x193iq5w.xeuugli.xsyo7zv.x16hj40l.x10b6aqq.x1yrsyyn', // Facebook updated UI October 2022. second time
];

/**
 * Represents parent div of the "Private Group . number of group member"
 * after which we will inject GroupKit Disable button
 *
 * @type {Array}
 */
const FACEBOOK_DISABLE_BUTTON_LOCATION_SELECTORS = [
    "[aria-label='Group navigation'] div.x9f619.x1n2onr6.x1ja2u2z.x78zum5.x2lah0s.x1qughib.x1qjc9v5.xozqiw3.x1q0g3np.xn6708d.x1ye3gou.xjkvuk6.x1iorvi4.xykv574.xbmpl8g.x4cne27.xifccgj",
    "[aria-label='Group navigation'] div.x6s0dn4.x1q0q8m5.x1qhh985.xu3j5b3.xcfux6l.x26u7qi.xm0m39n.x13fuv20.x972fbf.x9f619.x78zum5.x1q0g3np.x1iyjqo2.xs83m0k.x1qughib.xat24cr.x11i5rnm.x1mh8g0r.xdj266r.xeuugli.x18d9i69.x1sxyh0.xurb0ha.xexx8yu.x1n2onr6.x1ja2u2z.x1gg8mnh",
];

/**
 * Facebook Group Name text div selectors
 *
 * @type {Array}
 */
const FACEBOOK_GROUP_NAME_TEXT_SELECTORS = [
    "[aria-label='Group navigation'] span.x193iq5w.xeuugli.x13faqbe.x1vvkbs.xlh3980.xvmahel.x1n0sxbx.x1lliihq.x1s928wv.xhkezso.x1gmr53x.x1cpjm7i.x1fgarty.x1943h6x.x4zkp8e.x3x7a5m.x1lkfr7t.x1lbecb7.x1s688f.xzsf02u.x1yc453h",
    "[aria-label='Group navigation'] span.x193iq5w.xeuugli.x13faqbe.x1vvkbs.x1xmvt09.x1lkfr7t.x1lbecb7.x1s688f.xzsf02u",
    "[aria-label='Group navigation'] span.x193iq5w.xeuugli.x13faqbe.x1vvkbs.x1xmvt09.x1lliihq.x1s928wv.xhkezso.x1gmr53x.x1cpjm7i.x1fgarty.x1943h6x.xudqn12.x676frb.x1jchvi3.x1lbecb7.x1s688f.xzsf02u.x1yc453h",
];

/**
 * GroupKit support email
 *
 * @type {string}
 */
const SUPPORT_EMAIL = 'support@groupkit.com';

/**
 * Load more group members' class name.
 * It is presented on the member request page if all group members have not shown on the page.
 * @type {string}
 */
const FACEBOOK_LOAD_MORE_MEMBERS_CLASS_NAME = 'e6o9e13o';

/**
 * Represents number of tries to script scrape members in {@see approveAllMembers} method
 * @type {number}
 */
const MAX_NUMBER_OF_TRIES_TO_SCRAPE_MEMBERS = 30;

/**
 * The most recent approve button that was clicked by the end-user
 * @type {jQuery}
 */
let $clickedGroupkitApproveButton = null;

let bulkApproveIncrement = 0;
let stopButton = false;
let facebookGroupAccess = "";
let startInt = 0;
let endInt = 1;
let groupDetails = {
    groupname: '',
    groupid: 0
};
let getGroupDetailsPromiseResolve;
let globalInterval;

/**
 * Determines if the Facebook tab is active where the extension running.
 * True if active, otherwise false
 * @type {boolean}
 */
let facebookTabIsActive;

const NotAllowContent = /photo|aria-label/;

/**
 * Handles updating the Facebook member requests page after a new member has been added to the cloud.
 * This is achieved by clicking the native Facebook approval buttons
 *
 * @param {Object} updateUiForNewApprovalMessage -
 *                      the original directive signifying that a user has been added to the cloud
 *                      and should be approved on Facebook
 */
function handleApprovalUiUpdates(updateUiForNewApprovalMessage) {
    Bugsnag.leaveBreadcrumb('Handling approval update', updateUiForNewApprovalMessage);
    switch (updateUiForNewApprovalMessage.type) {
        case MESSAGE_TYPE['limit_reached']:
            $.alert(
                {
                    title: updateUiForNewApprovalMessage.content.message,
                    content: '',
                    draggable: false,
                    dragWindowBorder: false,
                    theme: "white",
                    backgroundDismiss: false,
                    backgroundDismissAnimation: ""
                }
            );
            hideApproveButton();
            return;

        case MESSAGE_TYPE['update_facebook_ui']:
        default:
            if (!updateUiForNewApprovalMessage.memberWasAdded) {
                // It was not confirmed that the members were sent to the cloud,
                // so, we won't click the Facebook Approve Button.
                return;
            }

            if (updateUiForNewApprovalMessage.approvalType === MESSAGE_TYPE['approve_all']) {
                $("#members_waiting_screen").hide();
                $("#all_end_num_gk").text(999);
                $("#all_start_num_gk").text(1);
                $("#members_complete").show();
                $("#complete_mem_sats_gk").text(bulkApproveIncrement);
                $("#approve_all_message").hide();
            }

            if (!preventPersistingOnFacebook) {
                try {
                    const $nativeFacebookApproveButton = (updateUiForNewApprovalMessage.approvalType === MESSAGE_TYPE['approve_one'])
                        ? $clickedGroupkitApproveButton.next()
                        : $("#groupkit-approve-all-button").next()

                    $nativeFacebookApproveButton.click();
                } catch (err) {
                    Bugsnag.notify(err, event => event.addMetadata('UI', 'clickedGroupkitApproveButton', $clickedGroupkitApproveButton));
                }
            }

            // Wait one second after the native Facebook click before updating our custom UI
            setTimeout(
                (updateUiForNewApprovalMessage.approvalType === MESSAGE_TYPE['approve_one'])
                    ? doPostApproveOneUiUpdates
                    : doPostApproveAllUiUpdates,
                1000
            );
    }
}

/**
 * Updates the Facebook UI to show that a single member has been added to the cloud and approved on Facebook
 */
function doPostApproveOneUiUpdates() {
    /* since the member has been approved, we remove that member from the Facebook member requests page  */
    $(FACEBOOK_GROUP_MEMBER_CONTAINER_SELECTORS.join(',')).has($clickedGroupkitApproveButton).remove();

    $("#member_waiting_screen").hide();
    $("#members_complete_one").show();

    $("#gk_memberappmessage").html("<b>1</b> new member was approved.");

    setTimeout(
        function () {
            $("#members_complete_one").hide();
        },
        5000
    );
}

/**
 * Updates the Facebook UI to show members are being added to the cloud and approved on Facebook
 *
 * @param {jQuery} $focusGroupkitApproveButton - The current button being scraped in the approval process
 */
async function doPostApproveAllUiUpdates($focusGroupkitApproveButton) {
    /* since the member has been approved, we hide that member on the Facebook member requests page  */
    $focusGroupkitApproveButton?.addClass('processed');
    let $hiddenElement = $(FACEBOOK_GROUP_MEMBER_CONTAINER_SELECTORS.join(',')).has($focusGroupkitApproveButton).hide();

    if ($hiddenElement.length) {
        bulkApproveIncrement += $hiddenElement.length;
        $("#all_start_num_gk").text(bulkApproveIncrement);
    } else {
        /* Simulate a "slow", repeated scroll to force new elements to appear */
        window.scrollTo(window.scrollX, Math.floor(document.body.scrollHeight*.8));
        await sleep(25);
        window.scrollTo(window.scrollX, document.body.scrollHeight);
        await sleep(50);
    }
}

/** remove approve button in facebook group page */
function hideApproveButton() {
    clearInterval(globalInterval);
    $("#members_complete").hide();
    $("#member_waiting_screen").hide();
    $("#members_waiting_screen").hide();
    $("#back_droup_modal").hide();
    $("#members_complete_one").hide();
    $(".groupkit-button").remove();
    stopButton = true;
    $("div[data-button-was-replaced-by-groupkit='true']").show();
}

/**
 * Toggles Disable and Enable GroupKit button on facebook member request page
 *
 * @param {Event} event which takes place in the DOM.
 *
 * @return {Promise<void>}
 */
async function toggleDisableButton(event) {
    const disableButton  = document.getElementById('groupkit-disable-button');
    const toBeEnabled = disableButton.firstChild.id !== DISABLE_IMAGE_ID;

    toBeEnabled ? globalInterval = setInterval(initHooks, 1200) : clearInterval(globalInterval);

    $("#members_complete").hide();
    $("#member_waiting_screen").hide();
    $("#members_waiting_screen").hide();
    $("#back_droup_modal").hide();
    $("#members_complete_one").hide();
    stopButton = true;

    sendManageFacebookGroupMessage(toBeEnabled);
    //to prevent event bubbling phases
    event.stopPropagation();
}

/**
 * Send the manage disable/enable facebook group message to background script.
 *
 * @param {boolean} enableGroup flag true if the message type is for enabling disabled group,
 *                                otherwise false for disabling group.
 */
 function sendManageFacebookGroupMessage(enableGroup = false) {
    const facebookGroupId = getFacebookGroupId();
    const executionMessage = {
        type: enableGroup ? MESSAGE_TYPE['enable_group'] : MESSAGE_TYPE['disable_group'],
        facebookUrlIdentifier: facebookGroupId,
    };

    chrome.runtime.sendMessage(executionMessage);
}

/**
 * Gets the formatted Facebook group details
 *
 * @returns {{img: string, groupid: Number, groupname: string}}
 */
function getGroupsDetails() {
    const facebookGroupId = getFacebookGroupId();

    return {
        groupid: facebookGroupId,
        groupname: getFacebookGroupName(),
        img: '',
    };
}

/**
 * Return current Facebook group name
 *
 * @returns {string}
 */
function getFacebookGroupName() {
    let facebookGroupName;

    const $facebookGroupNameText = $(FACEBOOK_GROUP_NAME_TEXT_SELECTORS.join(',')).first();

    try {
        try {
            // First we'll try to get Facebook group name from selectors
            if ($facebookGroupNameText.length) {
                facebookGroupName = $facebookGroupNameText.text();
            } else {
                throw new Error('Did not find the Facebook Group name in the expected position/state.');
            }
        } catch (groupNameSelectorError) {
            Bugsnag.notify(groupNameSelectorError);

            try {
                // Since we couldn't do scrape group name from a sidebar, we are attempting to scrape it from document title tag
                facebookGroupName = document.title.replace(/^\(\d+\+?\)\s+/, '');  // exclude notification number

                if (facebookGroupName.includes(' | Facebook')) {
                    facebookGroupName = facebookGroupName.split(' | Facebook')[0];
                }
            } catch {
                throw new Error('Did not find the Facebook group name in the title tag.');
            }
        }
    } catch (groupNameTitleSelectorError) {
        Bugsnag.notify(groupNameTitleSelectorError);
    }

    return facebookGroupName;
}

/** chrome eventListener */
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    let extensionId = chrome.runtime.id;
    if (extensionId === sender.id) {
        const disableButton  = document.getElementById('groupkit-disable-button');
        switch (message.type) {
            case (MESSAGE_TYPE['settings_message_enable_groupkit']):
                stopButton = false;
                globalInterval = setInterval(initHooks, 1200);
                const removeAttrButton = [
                    "div[aria-label='Approve']",
                    "button[name='approve']",
                    "div[aria-label='Approve All']",
                    "button[name='approve_all']",
                    "div.oajrlxb2.s1i5eluu.gcieejh5.bn081pho.humdl8nn.izx4hr6d.rq0escxv.nhd2j8a9.j83agx80.p7hjln8o[aria-label][role='button']",
                ];
                jQuery(removeAttrButton.join(',')).removeAttr("data-button-was-replaced-by-groupkit");
                break;
            case MESSAGE_TYPE['testing_dev_mode_enable']:
                preventPersistingOnFacebook = true;
                break;
            case MESSAGE_TYPE['testing_dev_mode_disable']:
                preventPersistingOnFacebook = false;
                break;
            case MESSAGE_TYPE['settings_message_disable_groupkit']:
                try {
                    hideApproveButton();
                } catch (e) {
                    Bugsnag.notify(e);
                }
                break;
            /** it's receive the group details. */
            case MESSAGE_TYPE['send_facebook_group_details']:
                chrome.storage.local.get(
                    [message.storageKey],
                    function(result) {
                        getGroupDetailsPromiseResolve(result[message.storageKey]);
                    }
                );
                break;
            case MESSAGE_TYPE['group_enabled']:
                disableButton.firstChild.setAttribute('src', DISABLE_IMAGE_URL);
                disableButton.firstChild.setAttribute('id', DISABLE_IMAGE_ID);
                $(".groupkit-button").show();
                $("div[data-button-was-replaced-by-groupkit='true']").hide();
                break;
            case MESSAGE_TYPE['group_disabled']:
                disableButton.firstChild.setAttribute('src', ENABLE_IMAGE_URL);
                disableButton.firstChild.setAttribute('id', ENABLE_IMAGE_ID);
                $(".groupkit-button").hide();
                $("div[data-button-was-replaced-by-groupkit='true']").show();
                break;
            default:
                handleApprovalUiUpdates(message);
                break;
        }
    }
});

/**
 * Initiates the scraping of data for an individual member while updating the global counters
 *
 * @param {jQuery} $groupkitApproveButton - The groupkit approve button of the member whose data is to be scraped
 * @param {object} saveToCloudAllApprovedUsersMessage - a collection of all members that will be added to the cloud
 *
 * @return {Promise<void>} ignored.
 *
 * @todo: Investigate if global counters are needed.  If not, remove them
 */
async function handleApproveAllDataScraping($groupkitApproveButton, saveToCloudAllApprovedUsersMessage) {
    endInt = parseInt($("#all_end_num_gk").text());
    startInt = parseInt($("#all_start_num_gk").text());

    saveToCloudAllApprovedUsersMessage.users.push(await facebookGroupMembers($groupkitApproveButton));
}

/** hide alert message */
function groupKitAlertHide() {
    document.getElementById("alert_message1").style.display = "none";
    document.getElementById("alert_message2").style.display = "none";
}

/**
 * handle single member approve click event
 *
 * @param {jQuery} $approveButton Groupkit added button jQuery DOM node next to member to be approved
 * @param {boolean} showWaitingScreen whether to show waiting screen
 *
 * @return void
 */
async function approveSingleMember($approveButton, showWaitingScreen = true) {
    $clickedGroupkitApproveButton = $approveButton;
    if (showWaitingScreen) {
        $("#member_waiting_screen").show();
    }

    let messageData = {};
    messageData.users = [];
    messageData.groupinfo = getFacebookGroupWithLatestImage();
    messageData.users.push(await facebookGroupMembers($approveButton));

    messageData.lastUrlPart = urlLastSegment();
    messageData.type = MESSAGE_TYPE['approve_one'];

    /** check group access */
    let scrapedGroupId = messageData.groupinfo.groupid
    if (scrapedGroupId !== '' && scrapedGroupId !== 0) {
        if (facebookGroupAccess === 'all' || facebookGroupAccess.indexOf(scrapedGroupId) !== -1) {
            chrome.runtime.sendMessage(messageData);
        } else {
            accessMessage();
        }
    }
}

/** handle the access message */
function accessMessage() {
    errorMessage('You do not have access to approve members from this group.');
    hideApproveButton();
}

/**
 * Shows error message on the page
 *
 * @param message to be displayed
 */
function errorMessage(message) {
    $.alert({
        title: message,
        content: '',
        draggable: false,
        dragWindowBorder: false,
        theme: 'white',
        backgroundDismiss: false,
        backgroundDismissAnimation: '',
    });
}

/*
 * Returns the last segment of the window location.
 *
 * @returns {string | undefined}
 */
function urlLastSegment() {
    return window.location.pathname.split('/').at(-1);
}

/**
 * Selector for buttons inserted by the extension
 * @type {string}
 */
const GROUPKIT_APPROVE_BUTTON_SELECTOR = ".groupkit-approve-one-button";

/**
 * Starting point for approving all members.
 *
 * @return {Promise<void>} ignored
 */
async function approveAllMembers() {
    Bugsnag.leaveBreadcrumb('Clicked Approve All members button');
    startInt = 0;
    endInt = 1;
    bulkApproveIncrement = 0;
    stopButton = false;

    let pendingRequestCount;
    try {
        pendingRequestCount = parseInt(
            document.querySelector(NUMBER_OF_MEMBER_REQUEST_SELECTORS.join(',')).textContent
        );

        if (!pendingRequestCount) {
            throw new Error('Did not find the number of pending member requests in expected state/position.');
        }
    } catch (pendingRequestCountError) {
        Bugsnag.notify(pendingRequestCountError);

        return errorMessage(
            `We're sorry to hear that you're having trouble using GroupKit Approve All.
             It looks like there was a recent change on Facebook's end that is affecting your ability to use this feature.
             We're working to resolve the issue as quickly as possible,
             but in the meantime you can try manually approving each item
             or sending us an email at ${SUPPORT_EMAIL} and we'll be happy to assist you further.
             Thank you for your patience and understanding.`
        );
    }

    let $currentGroupkitApproveButton = jQuery(GROUPKIT_APPROVE_BUTTON_SELECTOR).first();

    if ($currentGroupkitApproveButton.length) {
        $("#back_droup_modal").show();
        $("#members_waiting_screen").show();
        $("#all_end_num_gk").text(pendingRequestCount);
        $("#approve_all_message").show();

        let saveToCloudAllApprovedUsersMessage = {
            groupinfo: getFacebookGroupWithLatestImage(),
            users: [],
            type: MESSAGE_TYPE['approve_all'],
            lastUrlPart: urlLastSegment(),
        };

        let attempts = 0;
        let $previousGroupkitApproveButton, thereIsMoreToScroll;
        do {
            //check if the stopButton is true
            if (stopButton) {
                break;
            }

            thereIsMoreToScroll = document.getElementsByClassName(FACEBOOK_LOAD_MORE_MEMBERS_CLASS_NAME).length;
            chrome.runtime.sendMessage(
                { type: MESSAGE_TYPE['facebook_tab_active'] },
                function(tab) { facebookTabIsActive = tab.status; }
            );

            if ($currentGroupkitApproveButton.length) {
                handleApproveAllDataScraping($currentGroupkitApproveButton, saveToCloudAllApprovedUsersMessage);
            } else if (facebookTabIsActive) {
                // If the Facebook tab is active, we increase attempts in every loop cycle
                attempts++;
            }

            await doPostApproveAllUiUpdates($currentGroupkitApproveButton);
            $previousGroupkitApproveButton = $currentGroupkitApproveButton;
            $currentGroupkitApproveButton = jQuery('.groupkit-approve-one-button:not(.processed)').first();

            if ($previousGroupkitApproveButton.attr('id') !== $currentGroupkitApproveButton.attr('id')) {
                attempts = 0;
            }
        } while (
            thereIsMoreToScroll
            ||
            (
                bulkApproveIncrement < pendingRequestCount
                && attempts < MAX_NUMBER_OF_TRIES_TO_SCRAPE_MEMBERS
            )
        )

        if (saveToCloudAllApprovedUsersMessage.users.length == pendingRequestCount) {
            chrome.runtime.sendMessage(saveToCloudAllApprovedUsersMessage);
        } else {
            chrome.runtime.sendMessage({
                type: MESSAGE_TYPE['collect_and_store_html'],
                html: $('html').html(),
                metadata: {}
            });

            $("#approve_all_error .total-to-approve").html(pendingRequestCount);
            //we failed the scrap, we should go one by one
            $("#members_waiting_screen").hide();
            $("#approve_all_error").show();

            for (let i = 0, failed = 0; i < pendingRequestCount; i++) {
                if (stopButton) {
                    failed = pendingRequestCount - i;
                }
                try {
                    let button = $(GROUPKIT_APPROVE_BUTTON_SELECTOR).eq(failed);
                    if (!button.length) {
                        // noinspection ExceptionCaughtLocallyJS
                        throw 'Approve button not found for the request';
                    }

                    approveSingleMember(button);
                    $("#approve_all_error .approved").html(parseInt($("#approve_all_error .approved").html())+1);
                    await sleep(5000);
                } catch (e) {
                    failed++;
                }
            }
            $("#approve_all_error,#member_waiting_screen,#back_droup_modal").hide();
            $("#alert_message2").show();
        }
    }
}

/**
 * Retrieves the Facebook Group with the latest public image
 *
 * @returns {Object} groupDetails with img, groupid and groupname
 */
function getFacebookGroupWithLatestImage() {
    groupDetails = getGroupsDetails();

    /* Add latest group image */
    groupDetails.img = (document.querySelector('[alt*="cover photo"]') != null)
        ? document.querySelector('[alt*="cover photo"]').src
        : ''
    ;

    return groupDetails;
}

/**
 * Scrapes Facebook group member's first name, last name, invited by, lives in, and answers for group questions.
 *
 * @param {jQuery} $groupkitApproveButton - The groupkit approve button of the member whose data is to be scraped
 *
 * @returns {Promise<object>}
 */
function facebookGroupMembers($groupkitApproveButton) {
    return new Promise(async function (resolve) {
        /**
         * @type {{invitedBy: {fbId: ?string, name: ?string}, questions: *[], userName: string, userID: string, img: string, livesIn: string, agreedGroupRules: boolean}}
         */
        let facebookMemberData = {
            userID: '',
            userName: '',
            questions: [],
            invitedBy: {},
            livesIn: '',
            isAgreedGroupRules: false,
        };

        try {
            let infos = $groupkitApproveButton.parents("li");
            if (infos.length != null && infos.length > 0) {
                facebookMemberData.userID = infos.find("a._z_3[uid]").attr("uid") || "ERROR";
                facebookMemberData.userName = infos.find("a._z_3[uid]").text() || "ERROR";
                facebookMemberData.questions = [];
                infos.find("div._4wsr>ul.uiList>li").each(function () {
                    facebookMemberData.questions.push({
                        question: "",
                        answer: $(this).find("text").text()
                    });
                });
            }
        } catch (e) {
            Bugsnag.notify(e);
        }

        try {
            let rootElement = $($groupkitApproveButton).parents("div.a8nywdso.f10w8fjw.rz4wbd8a.pybr56ya:first");
            let $imageElem = rootElement.find('image');
            facebookMemberData.img = $imageElem.attr('xlink:href') ?? '';

            if (rootElement.length) {
                /**
                 * @type {HTMLAnchorElement[]}
                 */
                const profileLinks = Array.prototype.slice.call(rootElement[0].querySelectorAll('span span a'))
                                .filter(item => NotAllowContent.test(item.outerHTML) === false && item.href != null);

                /**
                 * Extract "Lives in" value for the members that have that info.
                 */
                facebookMemberData.livesIn = extractLivesIn(rootElement);

                if (profileLinks.length > 0) {
                    const user = profileLinks[0];

                    //get member name
                    if (user && user.text) {
                        facebookMemberData.userName = user.text.trim();
                    }

                    //get member id
                    if (user && user.href) {
                        try {
                            const hrefURl = user.href.toString();
                            let user_id = hrefURl.toLowerCase().replace('https://www.facebook.com/', '');
                            user_id = user_id.replace('https://www.beta.facebook.com/', '');
                            facebookMemberData.userID = user_id;
                        } catch (ex) {
                            Bugsnag.notify(ex);
                        }
                    }

                    //get member invited by
                    if (profileLinks.length > 1) {
                        facebookMemberData.invitedBy = getInvitedBy(profileLinks[1]);
                    }
                } else {
                    // deactivated member, collect ID from image
                    let $imageHref = $imageElem.closest('a');
                    facebookMemberData = { ...facebookMemberData, ...getMemberIdFromDeactivatedAccount($imageHref)};
                }

                //get member questions
                facebookMemberData.questions = [];
                let questionsWrapper = rootElement.find("ul li div.aahdfvyu span");
                if (questionsWrapper != null &&
                    questionsWrapper.length != null &&
                    parseInt(questionsWrapper.length) > 0) {
                    for (let i = 0, l = parseInt(questionsWrapper.length); i < l; i++) {
                        facebookMemberData.questions.push({
                            question: "",
                            answer: questionsWrapper.eq(i).text()
                        });
                    }
                }

                facebookMemberData.agreedGroupRules = isMemberAgreedWithGroupRules(rootElement);
            }
        } catch (e) {
            Bugsnag.notify(e);
        }

        if (facebookMemberData.userID === '') { // Facebook updated UI August 2022.
            let memberWrapper;
            let disabledRoleLink;

            FACEBOOK_GROUP_MEMBER_CONTAINER_SELECTORS.every(function (facebookGroupMemberContainerSelector) {
                memberWrapper = $groupkitApproveButton.parents(facebookGroupMemberContainerSelector);

                return !memberWrapper.length;
            });

            const roleLink = memberWrapper.find('[role="link"]:not(:has(div))')[0] ?? null;
            if (roleLink) {
                facebookMemberData.userName = roleLink.innerHTML || '';
                const hrefWithUserId = roleLink.getAttribute('href').split('/').filter(Boolean);
                facebookMemberData.userID = parseInt(hrefWithUserId[hrefWithUserId.length - 1]) || '';

                if (!facebookMemberData.userID && facebookMemberData.userName) {
                    // if user id is not scraped in the first attempt we will try to scrape it from different place
                    const hrefWithNumericId = memberWrapper
                        .find('[aria-label="' + facebookMemberData.userName + '"]')[0]
                        ?.getAttribute('href')
                        ?.split('/')
                        ?.filter(Boolean);

                    facebookMemberData.userID = Array.isArray(hrefWithNumericId)
                        ? parseInt(hrefWithNumericId[hrefWithNumericId.length - 2])
                        : ''
                    ;
                }
            } else  {
                disabledRoleLink = memberWrapper.find('[role="link"]:has(div)')[0] ?? null;
                if (disabledRoleLink) {
                    facebookMemberData.userName = disabledRoleLink.ariaLabel;
                    facebookMemberData.userID = disabledRoleLink.pathname.split('/').filter(segment => segment !== '').at(-1);
                }
            }

            facebookMemberData.questions = [];
            memberWrapper.find("ul > li").each(function () {
                facebookMemberData.questions.push({
                    question: $(this).find("span:first").prop("innerText"),
                    answer: $(this).find("div > span").text()
                });
            });
            facebookMemberData.livesIn = extractLivesIn(memberWrapper);

            let imageElement = memberWrapper.find('image');
            facebookMemberData.img = imageElement.attr('xlink:href') ?? '';

            const profileLinks = Array.prototype.slice.call(memberWrapper.find('span span a'))
                .filter(item => NotAllowContent.test(item.outerHTML) === false && item.href != null);

            if (profileLinks.length > 0) {
                const user = profileLinks[0];

                if (facebookMemberData.userName === '' && user && user.text) {
                    facebookMemberData.userName = user.text.trim();
                }

                //get member invited by
                if (profileLinks.length > 1) {
                    facebookMemberData.invitedBy = getInvitedBy(profileLinks[1]);
                }
            }

            facebookMemberData.agreedGroupRules = isMemberAgreedWithGroupRules(memberWrapper);
        }

        resolve(facebookMemberData);
    });
}

/**
 * Gets id and name from deactivated group member via provided image element
 *
 * @param imageElement
 *
 * @returns {{name, id}}
 */
function getMemberIdFromDeactivatedAccount(imageElement) {
    let userName, userID;

    userName = imageElement.attr('aria-label');
    let href = imageElement.attr('href');
    if (href?.indexOf('/user/') > 0) {
        userID = href.split('/user/')[1].split('/')[0];
    }

    return { userName: userName, userID: userID };
}

/**
 * Gets invited by member from the profile link element
 *
 * @param profileLink
 *
 * @returns {{}} containing name and fbId
 */
function getInvitedBy(profileLink) {
    let invitedBy = {};

    const invitedByLink = profileLink.href;
    const match = invitedByLink.match(/.*\/user\/(?<fb_id>\d+)\//);
    invitedBy.name = profileLink.text;
    if (match) {
        invitedBy.fbId = match.groups.fb_id;
    } else {
        const linkParts = invitedByLink.split('/');
        invitedBy.fbId = linkParts[linkParts.length - 1];
    }

    return invitedBy;
}

/**
 * If a member has "Lives in" information, it will be scrapped and send
 * along with other details.
 *
 * @param {object} $rootElement - The main DOM element of the user list.
 *
 * @returns {string} from "Lives in" line wrapper if exist, otherwise empty string.
 */
const extractLivesIn = $rootElement => {
    const userInfoText = $rootElement[0].innerText;
    const userInfoArray = userInfoText.replace(/\r\n/g, '|||').replace(/[\r\n]/g, '|||').split('|||');
    const livesIn = userInfoArray.filter(str =>
        {
            return str.trim().includes('Lives in')
                || str.trim().includes('Habite à')
                || str.trim().includes('Vive en')
            ;
        }
    );

    if (!livesIn.length) {
        return '';
    }

    // todo add collecting selectors via BugSnag
    return livesIn[0].replace(/Lives in |Habite à |Vive en /, '');
}

/**
 * Determines if the member agreed with the group rules.
 *
 * @param {object} $rootElement - The main DOM element of the user list.
 *
 * @returns {boolean} true if group rules question exist and agreed, otherwise false.
 */
const isMemberAgreedWithGroupRules = $rootElement => {
    let agreed = false;
    const rulesQuestionWrapper = $rootElement.find(
        "div > span:contains('" + FACEBOOK_GROUP_MEMBER_RULES["QUESTION_SELECTOR"] + "')"
    );

    if (rulesQuestionWrapper && rulesQuestionWrapper.length) {
        const scrapedAnswer = rulesQuestionWrapper.parent().find('div span').text();

        agreed = scrapedAnswer && (scrapedAnswer === FACEBOOK_GROUP_MEMBER_RULES["ANSWER_TO_AGREED_RULES"]);
    }

    return agreed;
}

/**
 * Replaces the Facebook 'Approve' and 'Approve All' buttons with
 * the Groupkit 'Approve' and 'Approve All' buttons, respectively, on the Facebook
 * member requests page
 */
function injectGroupkitApproveButtons(disabledGroups) {
    if (!groupDetails.groupid) { //if current groups is not loaded yet we need to load the group
        getFacebookGroupWithLatestImage();
    }
    const currentUrl = window.location.href;

    if (
        currentUrl.includes('/groups/')
        && isMemberRequestPage(currentUrl.toLowerCase())
        && groupDetails.groupid
    ) {
        if (!$("body").attr("groupkit_ui_loaded")) {
            loadUiHtml();
            $("body").attr("groupkit_ui_loaded", "true");
        }

        if (disabledGroups && disabledGroups.includes(groupDetails.groupid)) {
            return;
        }

        const facebookApproveAllButton = document.querySelector(
            FACEBOOK_APPROVE_ALL_BUTTON_SELECTORS.join(',')
        );

        const facebookApproveButtons = document.querySelectorAll(
            FACEBOOK_APPROVE_BUTTON_SELECTORS.join(',')
        );

        let groupkitApproveButton = undefined;
        let groupkitApproveAllButton = undefined;

        if (facebookApproveAllButton) {
            if (!facebookApproveAllButton.getAttribute("data-button-was-replaced-by-groupkit")) {
                groupkitApproveAllButton = document.createElement("span");
                groupkitApproveAllButton.setAttribute('id', 'groupkit-approve-all-button');
                groupkitApproveAllButton.setAttribute('class', 'groupkit-button groupkit-approve-all-button');
                groupkitApproveAllButton.innerHTML = "<img src='" + APPROVE_ALL_IMAGE_URL + "' style='cursor: pointer;border: none;color: white;height: 36px;width: auto;padding: 0px;vertical-align: middle;'/>&nbsp;&nbsp;&nbsp;";

                facebookApproveAllButton.style.display = "none";
                facebookApproveAllButton.parentNode.insertBefore(groupkitApproveAllButton, facebookApproveAllButton);
                facebookApproveAllButton.setAttribute("data-button-was-replaced-by-groupkit", "true");
                document.getElementById("groupkit-approve-all-button").addEventListener("click", approveAllMembers);
            }
        } else {
            $('.groupkit-approve-all-button').remove();
        }

        for (let i = 0; i < facebookApproveButtons.length; i++) {
            if (!facebookApproveButtons[i].getAttribute("data-button-was-replaced-by-groupkit")) {
                groupkitApproveButton = document.createElement("span");
                groupkitApproveButton.setAttribute('id', 'groupkit-approve-one-button_' + i);
                groupkitApproveButton.setAttribute('class', 'groupkit-button groupkit-approve-one-button');
                groupkitApproveButton.innerHTML = "<img  src='" + APPROVE_ONE_IMAGE_URL + "' style='cursor: pointer;border: none;color: white;height: 36px;width: auto;padding: 0px;vertical-align: middle;'/>&nbsp;&nbsp;&nbsp;";

                facebookApproveButtons[i].style.display = "none";
                facebookApproveButtons[i].parentNode.insertBefore(groupkitApproveButton, facebookApproveButtons[i]);

                document.getElementById("groupkit-approve-one-button_" + i).addEventListener(
                    "click",
                    function () {
                        approveSingleMember(jQuery(this));
                    }
                );
                facebookApproveButtons[i].setAttribute("data-button-was-replaced-by-groupkit", "true");

                if (facebookApproveButtons[i].parentNode.parentNode.childNodes.length > 3) {
                    // if there is more elements in the parent node expand current node
                    facebookApproveButtons[i].parentNode.style.marginRight = '30px';
                }
            }
        }
    }
}

/**
 * Injects Groupkit Disable/Enable button to UI on Facebooks member request page on page load
 *
 * @param {Array} disabledGroups with ids of groups where we will not show GroupKit buttons
 */
function injectGroupkitDisableButton(disabledGroups) {
    const currentUrl = window.location.href;
    const facebookApproveAllButton = document.querySelector(FACEBOOK_APPROVE_ALL_BUTTON_SELECTORS.join(','));
    const $memberRequestText = $(FACEBOOK_MEMBER_REQUEST_TEXT_SELECTORS.join(',')).first();
    const $facebookGroupNameText = $(FACEBOOK_DISABLE_BUTTON_LOCATION_SELECTORS.join(',')).first();
    let groupkitDisableButton = document.getElementById('groupkit-disable-button');

    if (
        !currentUrl.includes('/groups/')
        || !isMemberRequestPage(window.location.href.toLowerCase())
        || groupkitDisableButton
    ) {
        // We're either on the wrong page or the disable button has already been injected
        return;
    }

    const facebookGroupId = getFacebookGroupId();

    groupkitDisableButton = document.createElement('span');
    groupkitDisableButton.setAttribute('id', 'groupkit-disable-button');
    groupkitDisableButton.setAttribute('class', 'groupkit-disable-toggle');
    groupkitDisableButton.setAttribute('style', 'display:flex;justify-content: space-evenly;');

    // set disable button inner html dynamically
    groupkitDisableButton.innerHTML = disabledGroups && disabledGroups.includes(facebookGroupId.toString())
        ? "<img id='" + ENABLE_IMAGE_ID + "' src='" + ENABLE_IMAGE_URL + "' style='cursor: pointer;border: none;color: white;height: 36px;width: auto;padding: 6px;vertical-align: middle;'/>&nbsp;&nbsp;&nbsp;"
        : "<img id='" + DISABLE_IMAGE_ID + "' src='" + DISABLE_IMAGE_URL + "' style='cursor: pointer;border: none;color: white;height: 36px;width: auto;padding: 6px;vertical-align: middle;'/>&nbsp;&nbsp;&nbsp;";

    try {
        // We'll try to inject and initialize the enable/disable button
        try {
            // First we'll try to do it in the Facebook group name area
            if ($facebookGroupNameText.length) {
                $facebookGroupNameText[0].parentNode.style.display = 'flex';
                $facebookGroupNameText[0].parentNode.style['flex-direction'] = 'column';
                $facebookGroupNameText.after(groupkitDisableButton);
            } else {
                throw new Error("Did not find the Facebook Group name in the expected position/state to inject enable/disable button.");
            }
        } catch (injectByGroupNameError) {
            Bugsnag.notify(injectByGroupNameError);

            try {
                // Since we couldn't do it in the group name area, we'll try the legacy location strategy
                if(facebookApproveAllButton) {
                    facebookApproveAllButton.parentNode.parentNode.prepend(groupkitDisableButton);
                } else if($memberRequestText) {
                    $memberRequestText.after(groupkitDisableButton);
                }
            } catch {
                throw new Error("Did not find the legacy position and state to inject enable/disable button.");
            }
        }

        groupkitDisableButton.addEventListener('click', toggleDisableButton);
    } catch (initializingDisableButtonError) {
        // Something went wrong with injecting and intializing the enable/disable button
        // We'll notify bugsnag that we couldn't inject it, and continue without it
        Bugsnag.notify(initializingDisableButtonError);
    }
}

/**
 * Returns Facebook Group id for getting group details
 */
function getFacebookGroupId() {
    let facebookGroupId = undefined;

    try {
        const hrefWithGroupId = jQuery("a[href*='overview']").first().attr('href');
        const groupIdMatch = hrefWithGroupId ? hrefWithGroupId.match("groups/(.*)/.+") : [];

        if (groupIdMatch.length >= 2 && groupIdMatch[1]) {
            facebookGroupId = groupIdMatch[1];
        }
    } catch (e) {
        Bugsnag.notify(e);
    }

    if (!facebookGroupId) {
        const metaImageWithGroupId = jQuery("meta[property='og:image']")[0];

        if (metaImageWithGroupId) {
            facebookGroupId = parseInt(jQuery(metaImageWithGroupId).attr('content').split('media_id=')[1]);
        }

        if (!facebookGroupId) {
            // if group id is not collected from the first selector, we are attempting next selector
            const androidUrlWithGroupId = jQuery("meta[property='al:android:url']")[0];
            if (androidUrlWithGroupId) {
                facebookGroupId = parseInt(jQuery(androidUrlWithGroupId).attr('content').split('group/')[1]);
            }
        }
    }

    if (!facebookGroupId) { // if we don't found facebook group id from first attempt, this is a backup
        // todo: update this alphanumeric group id search to use only numeric values
        const facebookPageURL = window.location.href.toLowerCase();

        if (
            facebookPageURL.indexOf("facebook.com") !== -1
            && facebookPageURL.match(/\/groups\/([\w.]*)\//).length >= 2
        ) {
            facebookGroupId = facebookPageURL.match(/\/groups\/([\w.]*)\//)[1].toLowerCase();
        }
    }

    chrome.storage.sync.set({ facebookGroupId, questionsGroup: {}}).then(() => {});

    return facebookGroupId;
}

function initHooks() {
     if (
        window.location.href
        && typeof isMemberRequestPage === 'function'
        && isMemberRequestPage(window.location.href.toLowerCase())
    ) {
        try {
            chrome.storage.local.get(
                ['disable_groupkit', 'current_session', 'testing_dev_mode', 'disabled_fb_groups'],
                function (result) {
                    if (result.current_session) {
                        if (result.disable_groupkit == null) {
                            result.disable_groupkit = false;
                        }

                        if (result.disable_groupkit === false && result) {
                            injectGroupkitApproveButtons(result.disabled_fb_groups);
                            injectGroupkitDisableButton(result.disabled_fb_groups);
                        }

                        facebookGroupAccess = 'all';
                    }
                    if (result.testing_dev_mode != null && (result.testing_dev_mode === true || result.testing_dev_mode === false)) {
                        if (preventPersistingOnFacebook === false) {
                            preventPersistingOnFacebook = result.testing_dev_mode;
                        }
                    }
                }
            );

        } catch (e) {
            Bugsnag.notify(e);
        }
    }
}

initHooks()
globalInterval = setInterval(initHooks, 1200);
