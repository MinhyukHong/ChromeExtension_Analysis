//=================== GENERATE FACEBOOK TAGS START ==============================//

/**
 * Creates the structure for mapped entities as a part of the post request body
 * as url encoded form data. The structure is as following:
 * {
 *    "0": {
 *              id: number, // FB ID
 *              type: 0, // it's not clear what is the purpose of this key
 *          },
 *    "1": {
 *              id: number,
 *              type: 0,
 *          },
 *    "2": ...
 * }
 *
 * @param {Array<{full_name: string, fb_id: number}>} members
 *
 * @returns {{id: number, type: number}} mapped entities for members.
 */
const createEntityMap = (members) => {
    const entityMap = {};
    members.forEach((member, index) => {
        entityMap[index] = {
            id: member.fb_id,
            type: 0,
        };
    });

    return entityMap;
}

/**
 * Parse the logged in user ID form the cookies.
 *
 * @returns {Number} of the logged in user.
 */
const getUserId = () => {
    let userId;
    document.cookie.split(';').forEach(cookie => {
        if (cookie.includes('c_user')) {
            userId = cookie.split('=')[1];
        }
    });
    return userId;
};

/**
 * Extracts 'fb_dtsg' token from the DOM for the given values in matches array.
 *
 * @returns {String} extracted 'fb_dtsg' token from the DOM.
 */
const extractToken = () => {
    const matches = ['"DTSGInitialData",[]', '"DTSGInitData",[]'];
    for (const match of matches) {
        const bodyText = document.body.textContent;
        const startIndex = bodyText.indexOf(match);
        if (startIndex === -1) {
            continue;
        }
        const stringContainsToken = bodyText.slice(startIndex, startIndex + 200);
        const firstBracket = stringContainsToken.indexOf('{');
        const secondBracket = stringContainsToken.indexOf('}');
        const extractedTokenPart = stringContainsToken.slice(firstBracket, secondBracket + 1);

        return JSON.parse(extractedTokenPart);
    }
    return '';
}

/**
 * Parse data from the clipboard, and tries to find FB group ID.
 *
 * @param {string} post taken from the local storage.
 *
 * @returns {Number | null} FB group ID if it exists in the clipboard, otherwise null.
 */
const getGroupIdFromPostData = post => JSON.parse(post).fbGroupId;

/**
 * Check if a user is on the right group page.
 * 
 * @param {string} post taken from the local storage.
 *
 * @returns {boolean} true if user is on the right group page, otherwise false.
 */
const userIsOnTheRightGroupPage = post => {
    // If the URL pattern is not '/groups/[groupID or groupAlias]',
    // so only 3 segments, the user is on the non appropriate page.
    return window.location.pathname.split('/').length === 3
        && (
            window.location.pathname.includes(`groups/${getGroupIdFromPostData(post)}`)
            || window.location.pathname.includes(`groups/${extractGroupAliasFromDOM()}`)
        )
}

/**
 * Extract a group alias from the DOM if group ID is not present in the URL.
 *
 * @returns {string} alias of the group or empty string if not found.
 */
const extractGroupAliasFromDOM = () => {
    const bodyText = document.body.textContent;
    const groupAliasPattern = '"group_address":"';
    const startIndex = bodyText.indexOf(groupAliasPattern);
    if (startIndex === -1) {
        return '';
    }
    const stringContainsGroupAlias = bodyText.slice(startIndex, startIndex + 100);
    const firstQuote = stringContainsGroupAlias.indexOf(':"');
    const secondQuote = stringContainsGroupAlias.indexOf('","');

    return stringContainsGroupAlias.slice(firstQuote + 2, secondQuote);
}

/**
 * Validate post data from the storage. Checks if the necessary keys exist in the string.
 *
 * @param {string} post that contains the post data.
 *
 * @returns {boolean} true if the data are valid, false otherwise.
 */
const validatePost = post => {
    return post.includes('postTitle')
        && post.includes('members')
        && post.includes('postText')
        && post.includes('fbGroupId')
        ;
}

/**
 * Creating a new post with the given data from the local storage
 * by calling the FB endpoint if the data from the local storage
 * are valid, and deleting the data for a certain post by the key.
 *
 * @returns {Number | null} FB group ID if it exists in the clipboard, otherwise null.
 */
const tryCreatingNewPostFromLocalStorage = () => {
    try {
        chrome.storage.local.get(null, items => {
            const allKeys = Object.keys(items);
            const postsKeys = allKeys.filter(key => key.includes(CREATE_GK_POST));
            if (postsKeys.length) {
                postsKeys.forEach((key, index) => {
                    const post = items[key];
                    if (
                        validatePost(post)
                        && userIsOnTheRightGroupPage(post)
                    ) {
                        setTimeout(() => {
                            createPost(post);
                            chrome.storage.local.remove(key);
                        }, 20000 * index);
                    }
                })
            }
        });
    } catch (e) {
        Bugsnag.notify(e);
    }
}

/**
 * Returns randomly doc_id as a parameter for the request from the list
 * of valid (at least for now) doc_ids. It can be expanded with more numbers
 * from the valid post creation request's payload, from the browser.
 *
 * @returns {string} doc_id for the request
 */
const getDocId = () => {
    const docIds = ['5519934481452795', '5961636673901979'];
    return docIds[Math.floor(Math.random() * docIds.length)];
}

/**
 * Creates ranges and entities that do the mapping of the data about members
 * that are tagged in the post, together with the corresponding messages.
 *
 * Ranges are used as a part of the post request body via url encoded form.
 * The structure is as following:
 * [
 *     {
 *         entity: {
 *             id: number // member FB ID
 *         },
 *         length: number // current length of members' full names
 *         offset: number // length of member's full name
 *     },
 *     ...
 * ]
 *
 * Entities as a part of the post request body
 * as url encoded form data. The structure is as following:
 * [
 *     {
 *         offset: number, // start of the first char in member's name
 *         length: number, // length of member's name
 *         key: number, // index of array item
 *     },
 *     ...
 * ]
 *
 * @param {array} members that should be tagged in the FB group's post.
 * @param {string} postText contains everything entered by user in the modal in web portal.
 * 
 *
 * @returns {object} containing array of ranges and and array of entities.
 */
const createRangesAndEntities = (members, postText) => {
    const memberNames = members.map(member => member.full_name);
    const ranges = [];
    const entities = [];
    memberNames.forEach((name, index) => {
        if (postText.includes(name)) {
            ranges.push({
                entity: {
                    id: members.find(m => m.full_name === name).fb_id,
                },
                length: name.length,
                offset: postText.indexOf(name),
            });

            entities.push({
                offset: postText.indexOf(name),
                length: name.length,
                key: index
            });
        }
    });

    return { ranges, entities };
}

/**
 * Messages used to notify the BE (web portal) about the status of post creation.
 *
 * @type {object}
 */
const MESSAGES = {
    postCreationSuccess: 'Your post has been successfully published in your group. Congrats!',
    postCreationError: 'Oh no! There was a problem publishing your post. Please make sure that \
                        you are logged into your Facebook account and try again. If the problem \
                        persists please contact support@groupkit.com',
}

/**
 * Create a new post on the FB group page.
 *
 * @param {string} post taken from the local storage.
 *
 * @returns {void}
 */
const createPost = async (post) => {
    try {
        const fbGraphQLURL = 'https://www.facebook.com/api/graphql/';
        const parsedPostData = JSON.parse(post);
        const members = JSON.parse(parsedPostData.members);
        const postTitle = parsedPostData.postTitle;
        const postMessage = parsedPostData.postText;
        const title = postTitle ? `${postTitle}\n` : '';
        const message = postMessage ? `${postMessage}\n` : '';

        /** @constant {Object} input used as variable for the request to the FB GraphQL endpoint. */
        const input = {
            input: {
                source: 'WWW',
                message: {
                    ranges: createRangesAndEntities(members, postMessage).ranges,
                    text: `${title}${message}`,
                },
                composed_text: {
                    block_data: [
                        '{}'
                    ],
                    block_depths: [
                        0
                    ],
                    block_types: [
                        0
                    ],
                    blocks: [message],
                    entities: JSON.stringify(createRangesAndEntities(members, postMessage).entities),
                    entity_map: JSON.stringify(createEntityMap(members)),
                    inline_styles: [
                        '[]'
                    ]
                },
                post_message_title: {
                    text: postTitle
                },
                audience: {
                    to_id: getGroupIdFromPostData(post),
                },
                actor_id: getUserId(),
                client_mutation_id: 1,
            },
        };

        const postHeaders = new Headers();
        postHeaders.append('Content-Type', 'application/x-www-form-urlencoded');
        postHeaders.append('Cookie', document.cookie);

        const urlEncoded = new URLSearchParams();
        urlEncoded.append('fb_dtsg', extractToken().token);
        urlEncoded.append('variables', JSON.stringify(input));
        urlEncoded.append('doc_id', getDocId()); // TODO: this is always the same on my side - 5519934481452795, and this works. Someone else should double check this on his side.

        const requestOptions = {
            method: 'POST',
            headers: postHeaders,
            body: urlEncoded,
            redirect: 'follow'
        };

        // Post message for the Web Portal to know the status of the post creation.
        const executionMessage = {
            type: MESSAGE_TYPE.postCreationstatus,
            message: MESSAGES.postCreationSuccess,
            code: 200,
        }


        fetch(fbGraphQLURL, requestOptions)
            .then(response => response.text())
            .then(result => {
                if (
                    !result.includes('story_create')
                    && !result.includes('post_id')
                    && !result.includes(getGroupIdFromPostData(post))
                ) {
                    throw new Error(MESSAGES.postCreationError)
                }

                // Send message to the extension's background script.
                chrome.runtime.sendMessage(executionMessage);

                // Send message to close the Facebook group opened tab by the extension.
                chrome.runtime.sendMessage({ type: 'closeFacebookGroupTab' });
            })
            .catch(error => {
                executionMessage.message = error.message;
                executionMessage.code = 500;
                chrome.runtime.sendMessage(executionMessage);
                chrome.runtime.sendMessage({ type: 'closeFacebookGroupTab' });
                Bugsnag.notify(error);
            });
    } catch (e) {
        const executionMessage = {
            type: MESSAGE_TYPE.postCreationstatus,
            message: MESSAGES.postCreationError,
            code: 500,
        }
        chrome.runtime.sendMessage(executionMessage);
        Bugsnag.notify(e);
    }
}

/* Call this function every 10 seconds because of the FB reaction. */
setInterval(() => {
    tryCreatingNewPostFromLocalStorage();
}, 10000);

//=================== GENERATE FACEBOOK TAGS END ==============================//
