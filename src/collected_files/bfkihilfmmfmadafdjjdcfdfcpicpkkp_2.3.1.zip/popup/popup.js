let wheel_hex_colours = ["#3369e8", "#d50f25", "#eeb211", "#009925"];
let graph_array = [];
let wheel_limit = false;
let ticker_sound_global = false;
let slices = [];
const tick = new Audio('../lib/audio/tick.mp3');
const win_new_audio = new Audio('../lib/audio/winner.mp3');
const waiting_for_spinining = new Audio('../lib/audio/drum.mp3');
let wheelObject = {
    slices: [
        {
            text: "",
            value: 0,
            background: "#3369e8",
        },
        {
            text: "",
            value: 0,
            background: "#d50f25",
        },
        {
            text: "",
            value: 0,
            background: "#eeb211",
        },
        {
            text: "",
            value: 0,
            background: "#009925",
        }
    ],
    width: 390,
    frame: 20,
    type: "spin",
    text: {
        color: "#ccc",
        offset: 14,
        letterSpacing: 8,
        orientation: 'h',
        arc: true
    },
    line: {
        width: 1,
        color: "#ffffff"
    },
    outer: {
        width: 2,
        color: "#ffffff"
    },
    inner: {
        width: 0,
        color: "#ffffff"
    }
};

$(document).ready(function () {
    document.getElementById("seting_gklogout").addEventListener("click", function () {
        $.confirm({
            title: "Are you sure?",
            content: "",
            draggable: false,
            dragWindowBorder: false,
            theme: "white",
            backgroundDismiss: true,
            backgroundDismissAnimation: "",
            buttons: {
                confirm: function () {
                    logout();
                },
                cancel: function () {
                },
            }
        });
    });

    initScreen();
    $("#firststep").click(function () {
        try {
            document.getElementById("error_msg").style.display = "none";
            let params = {
                email: document.getElementById("user_email").value,
                password: document.getElementById("user_pass").value
            }
            cloudAppRequest(CLOUD_API_ENDPOINTS.login, METHOD.post, undefined, params, CALL_MODE.api, ((res) => {
                if (res && res.code === 200) {
                    const currentSession = btoa(JSON.stringify(res.data));
                    chrome.storage.local.set({current_session: currentSession});

                    $(".hideall").hide();
                    $("#step3").show();
                    webAppLogin(currentSession);
                } else {
                    document.getElementById("error_msg").innerHTML = 'Invalid Request'
                    document.getElementById("error_msg").style.display = "block";
                    setTimeout(function () {
                        document.getElementById("error_msg").style.display = "none";
                    }, 4000)
                }
            }));
        } catch (e) {
            document.getElementById("error_msg").innerHTML = 'invalid Request'
            document.getElementById("error_msg").style.display = "block";
            setTimeout(function () {
                document.getElementById("error_msg").style.display = "none";
            }, 4000);
            Bugsnag.notify(e);
        }
    });
    $('#login_with_facebook_button').click(function () {
        chrome.runtime.sendMessage({
            type: 'openLoginWithFacebookPopup',
            screen: {
                width: window.screen.width,
                height: window.screen.height,
            },
        });
    });
    $("#disable_groupkit").on("change", function () {
        if (document.getElementById("disable_groupkit") == null || document.getElementById("disable_groupkit").checked == null) {
            return false;
        }
        if (document.getElementById("disable_groupkit").checked) {
            chrome.tabs.query({url: "https://www.facebook.com/groups/*"}, function (tabs) {
                let messageData = {};
                messageData.type = MESSAGE_TYPE['settings_message_disable_groupkit'];
                for (let i = 0; i < tabs.length; ++i) {
                    chrome.tabs.sendMessage(tabs[i].id, messageData);
                }
            });
        } else {
            chrome.tabs.query({url: "https://www.facebook.com/groups/*"}, function (tabs) {
                let messageData = {};
                messageData.type = MESSAGE_TYPE['settings_message_enable_groupkit'];
                for (let i = 0; i < tabs.length; ++i) {
                    chrome.tabs.sendMessage(tabs[i].id, messageData);
                }
            });
        }
        chrome.storage.local.set({
            "disable_groupkit": document.getElementById("disable_groupkit").checked
        });
    });
    $("#testing_dev_mode").on("change", function () {
        if (document.getElementById("testing_dev_mode") == null || document.getElementById("testing_dev_mode").checked == null) {
            return false;
        }
        if (document.getElementById("testing_dev_mode").checked) {
            chrome.tabs.query({url: "https://www.facebook.com/groups/*"}, function (tabs) {
                let messageData = {};
                messageData.type = MESSAGE_TYPE['testing_dev_mode_enable'];
                for (let i = 0; i < tabs.length; ++i) {
                    chrome.tabs.sendMessage(tabs[i].id, messageData);
                }
            });
        } else {
            chrome.tabs.query({url: "https://www.facebook.com/groups/*"}, function (tabs) {
                let messageData = {};
                messageData.type = MESSAGE_TYPE['testing_dev_mode_disable'];
                for (let i = 0; i < tabs.length; ++i) {
                    chrome.tabs.sendMessage(tabs[i].id, messageData);
                }
            });
        }
        chrome.storage.local.set({
            "testing_dev_mode": document.getElementById("testing_dev_mode").checked
        });
    });
    $("#ticker_sound").on("change", function () {
        if (document.getElementById("ticker_sound") == null || document.getElementById("ticker_sound").checked == null) {
            return false;
        }
        chrome.storage.local.set({
            "ticker_sound": document.getElementById("ticker_sound").checked
        });
        ticker_sound_global = document.getElementById("ticker_sound").checked;
    });
    $("#raffle_sepparate_window").click(function (event) {
        event.preventDefault();
        openSpinningWheel();
    });
    $("#createquestios_btn").click(function (event) {
        event.preventDefault();
        event.stopPropagation();
        openWebAppPage();
        return false;
    });
    $("#video_page").click(function () {
        openWebAppPage();
    });
    $("#auth_function").click(function (event) {
        event.preventDefault();
        openWebAppPage();
    });
    $("#wrapper_start_it").click(function () {
        if (!wheel_limit) {
            if (graph_array != null && graph_array.length != null && Array.isArray(graph_array) && parseInt(graph_array.length) > 1) {
                if (!ticker_sound_global) {
                    if (waiting_for_spinining != null && waiting_for_spinining.currentTime != null) {
                        waiting_for_spinining.currentTime = 0;
                    }
                    waiting_for_spinining.play().catch(function (error) {
                        Bugsnag.notify(error);
                    });
                }
                if (!ticker_sound_global) {
                    setTimeout(function () {
                        waiting_for_spinining.pause();
                        if (waiting_for_spinining != null && waiting_for_spinining.currentTime != null) {
                            waiting_for_spinining.currentTime = 0;
                        }
                        $(".wheel").superWheel("start", "value", 0);
                    }, 3180);
                } else {
                    $(".wheel").superWheel("start", "value", 0);
                }
                let wheelSelector = $('.wheel');
                wheelSelector.superWheel('onComplete', function (results) {
                    if (!ticker_sound_global) {
                        win_new_audio.play().catch(function (error) {
                            Bugsnag.notify(error);
                        });
                    }
                    if (results != null && results.text != null && results.text !== "") {
                        $("#text_wrapper").html("The winner is: <b>" + results.text + "</b>");
                    }
                });
                wheelSelector.superWheel('onStep', function () {
                    tick.play().catch(function (error) {
                        Bugsnag.notify(error);
                    });
                });
            }
        }
    });
    let inputChange = true;
    $("#wheel_input_data").on("change paste keyup input propertychange", function () {
        if (inputChange) {
            inputChange = false;
            wheelInputSpinning();
            inputChange = true;
        }
    });
    $("a.back_to_welcome").click(function () {
        $("#wheel_input_data").val("");
        $("#text_wrapper").html("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
        initScreen();
    });
    $("#settings_btn").click(function () {
        $(".hideall").hide();
        $("#step5").show();
    });
    $("#my_plan_btn").click(function () {
        let optionsUrl = conf.app_url + '/setting?plans'
        chrome.tabs.query({}, function (extensionTabs) {
            let found = false;
            for (let i = 0; i < extensionTabs.length; i++) {
                if (extensionTabs[i].url.indexOf(optionsUrl) > -1) {
                    found = true;
                    chrome.tabs.update(extensionTabs[i].id, {
                        "selected": true
                    }, function () {
                        if (!chrome.runtime.lastError) {
                        }
                    });
                    chrome.windows.update(extensionTabs[i].windowId, {
                        "focused": true
                    }, function () {
                        if (!chrome.runtime.lastError) {
                        }
                    });
                    setTimeout(function () {
                        window.close();
                    }, 700);
                }
            }
            if (found === false) {
                chrome.tabs.create({
                    url: optionsUrl
                });
                setTimeout(function () {
                    window.close();
                }, 700);
            }
        });
    });
    $("#host_raffle").click(function () {
        $("#wheel_input_data").val("");
        $("#text_wrapper").html("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
        wheelObject.slices = [
            {
                text: "",
                value: 0,
                background: "#3369e8",
            },
            {
                text: "",
                value: 0,
                background: "#d50f25",
            },
            {
                text: "",
                value: 0,
                background: "#eeb211",
            },
            {
                text: "",
                value: 0,
                background: "#009925",
            }
        ];
        $('.wheel').superWheel(wheelObject);
        $(".hideall").hide();
        $("#step9").show();
    });
    $("[data-toggle='tooltip']").tooltip();

    chrome.storage.local.get(["testing_dev_mode", "disable_groupkit", "ticker_sound"], function (result) {
        try {
            if (result.disable_groupkit != null && (result.disable_groupkit === true || result.disable_groupkit === false)) {
                document.getElementById("disable_groupkit").checked = result.disable_groupkit;
            }
        } catch (e) {
            Bugsnag.notify(e);
        }
        try {
            if (result.testing_dev_mode != null && (result.testing_dev_mode === true || result.testing_dev_mode === false)) {
                document.getElementById("testing_dev_mode").checked = result.testing_dev_mode;
            }
        } catch (e) {
            Bugsnag.notify(e);
        }
        try {
            if (result.ticker_sound != null && (result.ticker_sound === true || result.ticker_sound === false)) {
                document.getElementById("ticker_sound").checked = result.ticker_sound;
                ticker_sound_global = result.ticker_sound;
            }
        } catch (e) {
            Bugsnag.notify(e);
        }
    });
});

/** logout the chrome extension */
async function logout() {
    await groupkitLogout();
    initScreen();
}

/** handle logout message */
function logoutErrorHandle() {
    $(".setting_msg").hide();
    $("#green_msg_1").show();
    setTimeout(function () {
        $("#green_msg_1").hide();
    }, 6000);
}

/** this function used to open the giveaway page. */
function openSpinningWheel() {
    let optionsUrl = conf.app_url + '/giveaway'
    chrome.tabs.query({}, function (extensionTabs) {
        let found = false;
        for (let i = 0; i < extensionTabs.length; i++) {
            if (extensionTabs[i].url.indexOf(optionsUrl) > -1) {
                found = true;
                chrome.tabs.update(extensionTabs[i].id, {
                    "selected": true
                }, function () {
                    if (!chrome.runtime.lastError) {
                    }
                });
                chrome.windows.update(extensionTabs[i].windowId, {
                    "focused": true
                }, function () {
                    if (!chrome.runtime.lastError) {
                    }
                });
                setTimeout(function () {
                    window.close();
                }, 700);
            }
        }
        if (found === false) {
            chrome.tabs.create({
                url: optionsUrl
            });
            setTimeout(function () {
                window.close();
            }, 700);
        }
    });
}

/** This function used to wheel array filter. */
function inputDataToArray(datatext) {
    let tempArray = datatext.replace(/\r\n|\n\r|\n|\r/g, "\n").split("\n");
    if (tempArray == null || tempArray.length == null || tempArray.length < 1) {
        return [];
    }
    let realArray = [];
    for (let i = 0, l = tempArray.length; i < l; i++) {
        if (tempArray[i] != null && tempArray[i] !== "" && tempArray[i].trim() !== "") {
            realArray.push(tempArray[i].trim());
        }
    }
    if (realArray == null || realArray.length == null || realArray.length < 1) {
        return [];
    }
    return realArray;
}

/** this function used to open the WebApp page. */
function openWebAppPage() {
    let optionsUrl = conf.app_url
    chrome.tabs.query({}, function (extensionTabs) {
        if (chrome.runtime.lastError) {
            return false;
        }
        let found = false;
        for (let i = 0; i < extensionTabs.length; i++) {
            if (extensionTabs[i].url.indexOf(optionsUrl) > -1) {
                found = true;
                chrome.tabs.update(extensionTabs[i].id, {
                    "selected": true
                }, function () {
                    if (!chrome.runtime.lastError) {
                    }
                });
                chrome.windows.update(extensionTabs[i].windowId, {
                    "focused": true
                }, function () {
                    if (!chrome.runtime.lastError) {
                    }
                });
            }
        }
        if (found === false) {
            chrome.tabs.create({
                url: optionsUrl
            }, function () {
                if (!chrome.runtime.lastError) {
                }
            });
        }
    });
}

/** wheel spinning */
function wheelInputSpinning() {
    if (!wheel_limit) {
        graph_array = inputDataToArray($("#wheel_input_data").val());
        if (graph_array != null && graph_array.length != null && graph_array.length > 1) {
            slices = [];
            let incr_ = 0;
            let operator_ = 0;
            let colour_ = "#3369e8";
            let text_col = "#ffffff";
            let randomNumber = 0;
            if (parseInt(graph_array.length) > 90) {
                while (parseInt(graph_array.length) > 90) {
                    randomNumber = getRandomInt(parseInt(graph_array.length));
                    graph_array.splice(randomNumber, 1);
                }
            }
            for (let i = 0, l = graph_array.length; i < l; i++) {
                try {
                    operator_ = incr_ % 4;
                    colour_ = wheel_hex_colours[operator_];
                    if (operator_ < 2) {
                        text_col = "#ffffff";
                    } else {
                        text_col = "#000000";
                    }
                } catch (ex) {
                }
                incr_++;
                slices.push({
                    text: graph_array[i],
                    background: colour_,
                    color: text_col,
                    value: 0,
                });
            }
            wheelObject.slices = slices;
            $(".wheel").superWheel(wheelObject);
        }
    }
}

/** get random int value */
function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

/** initScreen */
function initScreen() {
    chrome.storage.local.get(["current_session"], function (result) {
        if (!result.current_session) {
            $(".hideall").hide();
            $("#step1").show();
            document.getElementById('plans-link').href = conf.app_url + '/plans';
        } else {
            let name = JSON.parse(atob(result.current_session)).user.name;

            if (name.indexOf(' ') >= 0) {
                name = name.split(' ')[0]
            }

            $('#user_name').text(name)
            $(".hideall").hide();
            $("#host_raffle").show();
            $("#step4").show();
        }
    });
}
