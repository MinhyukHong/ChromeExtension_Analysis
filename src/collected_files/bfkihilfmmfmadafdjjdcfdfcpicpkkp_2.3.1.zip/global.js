/** Array used throughout the application for message passing */
const MESSAGE_TYPE = {
    tab_reload: "tabReload",
    send_facebook_group_details: "sendFbGroupDetails",
    aweber_login: "aweberlogin",
    refresh_web_app: "refreshWebApp",
    open_login_with_facebook_popup: "openLoginWithFacebookPopup",
    send_group_data: "sendGroupData",
    send_aweber_token: "sendAweberToken",
    send_scraped_member_data: "SendMemberScrape",
    send_member_scraping_details: "sendMembersScrapingDetails",
    send_member_scraping_stop: "sendMembersScrapingStop",
    testing_dev_mode_enable: "testingDevModeEnable",
    testing_dev_mode_disable: "testingDevModeDisable",
    settings_message_disable_groupkit: "settingsMessageDisableGroupKit",
    settings_message_enable_groupkit: "settingsMessageEnableGroupKit",
    limit_reached: "limitReached",
    update_facebook_ui: "fbClientSide",
    approve_one: "approveOne",
    approve_all: "approveAll",
    install: "install",
    update: "update",
    facebook_tab_active: "facebookTabActive",
    disable_group: 'disableGroup',
    enable_group: 'enableGroup',
    group_enabled: 'groupEnabled',
    group_disabled: 'groupDisabled',
    scrapeFbMembers: 'scrapeFbMembers',
    groupMembersScraped: 'groupMembersScraped',
    scrapedFacebookGroup: 'scrapedFacebookGroup',
    getFacebookGroupDetails: 'getFbGroupDetails',
    createNewPostByExtension: 'createNewPostByExtension',
    postCreationstatus: 'postCreationStatus',
    closeFacebookGroupTab: 'closeFacebookGroupTab',
    collect_and_store_html: 'collect_and_send_html',
};

/**
 * The ID of the FB popup window created by extension.
 *
 * @type {string}
 */
const FACEBOOK_GROUP_TEMP_TAB_ID = 'facebookPopupWindowDataId';

/**
 * Url part for private group's member requests page
 *
 * @type {string}
 */
const LAST_PART_OF_PRIVATE_GROUP_URL = 'member-requests';

/**
 * The Cloud API URL paths used by this extension
 *
 * @type {{
 *          webAppLogout: string,
 *          getDisabledGroups: string,
 *          getUser: string,
 *          login: string,
 *          addGroupMember: string,
 *          storeHtml: string,
 *          disableGroup: string,
 *          enableGroup: string,
 *          webAppLogin: string
 *       }}
 */
const CLOUD_API_ENDPOINTS = {
    login: "login",
    getUser: "getUser",
    addGroupMember: "recordSave",
    storeHtml: "storeHtml",
    webAppLogout: "appLogout",
    webAppLogin: "auto_login",
    disableGroup: 'disabled-groups',
    enableGroup: 'disabled-groups/destroy',
    getDisabledGroups: 'disabled-groups',
};

/**
 * Specifies whether the cloud app is to be called via the standard web or the API
 * @type {{web: string, api: string}}
 */
const CALL_MODE = {
    web: "web",
    api: "api",
};

/**
 * Supported HTTP methods for the cloud endpoint calls
 *
 * @type {{post: string, get: string}}
 */
const METHOD = {
    get: "GET",
    post: "POST",
};

/**
 * A keyword to create a key for posts before storing them to the local storage.
 *
 * @const {string} CREATE_GK_POST 
 */
const CREATE_GK_POST = 'create-gk-post';

/**
 * Utility function for asynchronously sleeping a thread of execution
 *
 * @param {Number} ms - the number of milliseconds to sleep
 *
 * @return {Promise<void>} that gets resolved after the provided time in ms has elapsed
 */
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Determine if the current page is one of the member request pages
 *
 * @return {boolean} true if page is member request page, otherwise false
 */
function isMemberRequestPage(url) {
    return url.includes('/requests')
        || url.includes(LAST_PART_OF_PRIVATE_GROUP_URL)
        || url.includes('/admin_activities')
        || url.includes('/participant_requests');
}

/**
 * Makes calls to the cloud app
 *
 * @param {string} endpoint - The URL path to a cloud resource
 * @param {string} method - HTTP method to use on the endpoint
 * @param {?string} params - Any addtional parameters to be appended to the endpoint
 * @param {string|Object|ArrayBuffer|ArrayBufferView|URLSearchParams|FormData|File|Blob} payload - the body of the request
 * @param callMode - Defines whether the request should be request to the public web front app or to the API
 * @param onCompletion - callback function to be executed after the request.  It is used for both success and error
 */
function cloudAppRequest(endpoint, method, params, payload, callMode, onCompletion) {
    chrome.storage.local.get(
        ["current_session"],
        function (result) {
            const accessToken = result.current_session ? JSON.parse(atob(result.current_session)).access_token: '';
            const url = ((callMode === "web") ? APP_URL : API_URL) + "/" + endpoint + (params ? '&' + params : '');

            const fetchOptions = {
                method: method,
                credentials: 'include',
                headers: {
                    Accept: 'application/json',
                    Authorization: 'Bearer ' + accessToken,
                    'Content-Type': 'application/json',
                },
            };

            if (method !== METHOD.get) {
                fetchOptions.body = JSON.stringify(payload);
            }

            fetch(
                url,
                fetchOptions
            )
                .then((response) => {
                    // if (!response.ok) {
                    //     throw new Error(`HTTP error! Status: ${response.status}`);
                    // }
                    if (response.ok) {
                        return response.json();
                    }

                    throw new Error(response.statusText);
                })
                .then((response) => {
                    onCompletion(response);
                })
                .catch((error) => {
                    // Bugsnag.notify(error);
                    onCompletion(error.response ?? error);
                });
        }
    );
}

/**
 * Validates email
 *
 * @param {String} email that will be validated
 *
 * @returns {boolean} true if email is valid, otherwise false
 */
function emailValidate(email) {
    const regExp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regExp.test(String(email).toLowerCase());
}

/**
 * Tests provided text if contains email address
 *
 * @param {string} text for getting an email address from it.
 *
 * @returns {string} email address if contains in the provided text, otherwise empty string
 */
function getEmailFromText(text) {
    const hasEmail = text.toLowerCase().trim().match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);

    if (hasEmail?.length) {
        const email = hasEmail[0].trim();

        // if last character of founded email is "." remove the last character
        return email.charAt(email.length - 1) === '.' ? email.slice(0, -1) : email;
    }

    return '';
}

/**
 * Extracts email from the provided answers
 *
 * @param {array} memberQuestionsAnswers with object including answers and questions
 *
 * @returns {string} email if is found in the provided answers, otherwise empty string
 */
function extractEmail(memberQuestionsAnswers) {
    let email = '';

    const questionWithEmailAndAnswer = memberQuestionsAnswers.find(function (questionAnswerChunk) {
        return questionAnswerChunk.question.toLowerCase().includes('email');
    });

    // first search in answer where question asks for email
    if (questionWithEmailAndAnswer?.answer && questionWithEmailAndAnswer.answer.includes('@')) {
        email = getEmailFromText(questionWithEmailAndAnswer.answer);

        if (email.length) {
            return email;
        }
    }

    memberQuestionsAnswers.some(function (questionAnswer) {
        email = getEmailFromText(questionAnswer.answer);

        if (email.length) {
            return true;
        }
    });

    return email;
}

/**
 * Logs the user out of the extension and the cloud web application
 *
 * @param {boolean} [shouldRefreshCloudApp=true]
 *                  will log the user out of the cloud app with a page refresh if true, otherwise will only logout
 *
 * @param {boolean} serviceWorker
 *                  determines if function is called from service worker, true if is, otherwise false
 *
 * @return {Promise<null>} Only used to signify completion of process.  No return value is needed in resolution
 */
async function groupkitLogout(shouldRefreshCloudApp = true, serviceWorker = false) {
    return new Promise( (resolve) => {
        chrome.storage.local.get(
            ["current_session"],
            function (result) {
                let currentUser = result.current_session ? JSON.parse(atob(result.current_session)).user : {};

                chrome.storage.local.remove(
                    ["disable_groupkit", "current_session", "testing_dev_mode"],
                    function (result) {
                        const messageData = {
                            type: MESSAGE_TYPE['tab_reload'],
                            shouldIncludeCloudApp: shouldRefreshCloudApp,
                        };

                        if (serviceWorker) {
                            //
                        } else {
                            localStorage.removeItem('current_session');
                        }

                        cloudAppRequest(
                            CLOUD_API_ENDPOINTS.webAppLogout + '/' + btoa(JSON.stringify(currentUser)),
                            METHOD.get,
                            undefined,
                            undefined,
                            CALL_MODE.web,
                            (response) => {
                                chrome.runtime.sendMessage(messageData);
                                resolve();
                            }
                        );
                    }
                );
            }
        );
        }
    );
}
