const start_with_extension = window.location.href.startsWith('chrome-extension://');

Bugsnag.start({
    apiKey: conf.bugsnag.api_key,
    /**
     * For content scripts, we don't want automatic notifications of all errors
     * since they would most likely come from Facebook itself
     */
    autoNotify: !start_with_extension,
    releaseStage: conf.bugsnag.release_stage,
    appVersion: chrome.runtime.getManifest().version,
    onError: function (report) {
        report.stacktrace = report.errors.map(function (error) {
            error.stacktrace = error.stacktrace.map(function (stacktrace) {
                /**
                 * Bugsnag will by default ignore any errors coming from
                 * extensions, we circumwent this by replacing the schema
                 * https://github.com/bugsnag/bugsnag-js/issues/94
                 */
                stacktrace.file = stacktrace.file.replace(
                    'chrome-extension://' + chrome.runtime.id + '/',
                    'groupkit_chrome_extension://'
                );
                return stacktrace;
            });
            return error;
        });
    }
});
chrome.storage.local.get(["current_session"], function (result) {
    if (result.current_session) {
        const user = JSON.parse(atob(result.current_session)).user;
        Bugsnag.setUser(user.id, user.email, user.name);
    }
});
