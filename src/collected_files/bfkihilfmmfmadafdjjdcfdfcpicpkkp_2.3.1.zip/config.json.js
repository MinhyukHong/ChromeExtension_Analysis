/* PRODUCTION, STAGING, and DEVELOPER  */
const BUILD_MODE = 'PRODUCTION';
switch (BUILD_MODE) {
    case 'DEVELOPER':
        APP_URL = "http://127.0.0.1:8000";
        BUGSNAG_RELEASE_STAGE = "development";
        break;
    case 'STAGING':
        APP_URL = "https://cloud-staging.groupkit.com";
        BUGSNAG_RELEASE_STAGE = "staging";
        break;
    case 'PRODUCTION':
    default:
        APP_URL = "https://cloud.groupkit.com";
        BUGSNAG_RELEASE_STAGE = "production";
}

const API_URL = APP_URL + '/api';

let conf = {
    "versionpath": "v2",
    "approvals_debug_mode": false,
    "app_url": APP_URL,
    "api_url": API_URL,
    "bugsnag": {
        "api_key": "f92057651078f9de2b00614e526439be",
        "release_stage": BUGSNAG_RELEASE_STAGE,
    },
    "installURL": "https://groupkit.com/getstarted",
    "unInstallURL": "https://lstewart53x3.typeform.com/to/vGp9a5",
};
