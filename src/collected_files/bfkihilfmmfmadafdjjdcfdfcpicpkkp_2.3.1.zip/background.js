importScripts('config.json.js');
importScripts('global.js');

/**
 * Local cache for group's questions
 *
 * @type {null|Object}
 */
let GROUP_QUESTIONS = null;

/** this function used to Listen to the different types of event. */
chrome.runtime.onMessage.addListener(async function (message, sender, sendResponse) {
    let extensionId = chrome.runtime.id;
    if (extensionId === sender.id) {
        switch (message.type) {
            case MESSAGE_TYPE.postCreationstatus:
                chrome.tabs.query(
                    {},
                    extensionTabs => {
                        for (let i = 0; i < extensionTabs.length; i++) {
                            if (extensionTabs[i].url.indexOf(conf.app_url) > -1) {
                                chrome.tabs.sendMessage(
                                    parseInt(extensionTabs[i].id),
                                    {
                                        type: MESSAGE_TYPE.postCreationstatus,
                                        data: message,
                                    }
                                );
                            }
                        }
                    }
                );
                break;
            case MESSAGE_TYPE['tab_reload']:
                refreshFbAndWebpage(message.shouldIncludeCloudApp);
                break;
            case MESSAGE_TYPE['aweber_login']:
                return chrome.tabs.query(
                    {},
                    function (extensionTabs) {
                        for (let i = 0; i < extensionTabs.length; i++) {
                            if (extensionTabs[i].url.indexOf(conf.app_url) > -1) {
                                chrome.tabs.sendMessage(
                                    parseInt(extensionTabs[i].id),
                                    {
                                        type: MESSAGE_TYPE['send_aweber_token'],
                                        data: message
                                    }
                                );
                                setTimeout(
                                    () => {
                                        chrome.tabs.remove(parseInt(sender.tab.id));
                                    },
                                    500
                                );
                            }
                        }
                    }
                );
            case MESSAGE_TYPE['refresh_web_app']:
                refreshWepAppPage(message.data);
                break;
            case MESSAGE_TYPE['open_login_with_facebook_popup']:
                const WIDTH = 520;
                const HEIGHT = 552;
                chrome.windows.create({
                    url:    APP_URL + '/login/facebook?fromExtension=true',
                    type:   'popup',
                    width:  WIDTH,
                    height: HEIGHT,
                    left:   (message.screen.width / 2) - (WIDTH / 2),
                    top:    (message.screen.height / 2) - (HEIGHT / 2),
                }, function (popupWindowData) {
                    chrome.storage.onChanged.addListener(
                        function listener (changes, areaName) {
                            if (
                                areaName === 'local'
                                && changes.hasOwnProperty('current_session')
                                && changes.current_session.hasOwnProperty('newValue')
                            ) {
                                chrome.storage.onChanged.removeListener(listener);
                                chrome.windows.remove(popupWindowData.id);
                                chrome.notifications.create({
                                    type: 'basic',
                                    iconUrl: '../icons/icon128.png',
                                    title: 'GroupKit Login Success',
                                    message: 'You have been successfully logged in',
                                });
                            }
                        });
                });
                break;
            case MESSAGE_TYPE['facebook_tab_active']:
                sendResponse({ status: sender.tab.active });
                break;
            case MESSAGE_TYPE['disable_group']:
                disableGroup(message.facebookUrlIdentifier);
                break;
            case MESSAGE_TYPE['enable_group']:
                enableGroup(message.facebookUrlIdentifier);
                break;
            case MESSAGE_TYPE['send_member_scraping_details']:
            case MESSAGE_TYPE['getFacebookGroupDetails']:
                getScrapingGroupsByUrl(
                    message.url ?? message.facebookUrlIdentifier,
                    message.numericGroupId,
                    sender.tab.id,
                    message.type === MESSAGE_TYPE['send_member_scraping_details']
                );
                break;
            case MESSAGE_TYPE['scrapeFbMembers']:
                scrapeGroupMembers(message.url, message.tabId);
                break;

            case MESSAGE_TYPE['createNewPostByExtension']:
                const fbGroupId = JSON.parse(message.post).fbGroupId;
                const facebookGroupTab = await chrome.tabs.create({
                    url: `https://www.facebook.com/groups/${fbGroupId}`,
                    active: false,
                });
            
                if (facebookGroupTab) {
                    const key = Math.random().toString(36).slice(2, 15);
                        chrome.storage.local.set({ [`${CREATE_GK_POST}-${key}`]: message.post })
                            .then(() => chrome.storage.local.set({[FACEBOOK_GROUP_TEMP_TAB_ID]: facebookGroupTab.id}))
                            .catch(err => console.log(err));
                }

                break;

            case MESSAGE_TYPE['closeFacebookGroupTab']:
                chrome.storage.local.get(FACEBOOK_GROUP_TEMP_TAB_ID, items => {
                    if (items?.[FACEBOOK_GROUP_TEMP_TAB_ID]) {
                        chrome.tabs .remove(items[FACEBOOK_GROUP_TEMP_TAB_ID])
                            .then(() => chrome.storage.local.remove(FACEBOOK_GROUP_TEMP_TAB_ID))
                            .catch(error => console.log(error));
                    }
                });
                break;

            case MESSAGE_TYPE['collect_and_store_html']:
                cloudAppRequest(
                    CLOUD_API_ENDPOINTS.storeHtml,
                    METHOD.post,
                    null,
                    {
                        html: message.html,
                        metadata: message.metadata
                    },
                    CALL_MODE.api,
                    (response) => {
                        sendResponse(response);
                    }
                );
                break;
            default:
                handleMemberApprovalMessage(message, sender.tab.id);
        }
    }
});

/** this function used to refresh APP && Facebook page after install extension. */
chrome.runtime.onInstalled.addListener(function (details) {
    refreshFbAndWebpage();

    if (details.reason === MESSAGE_TYPE['install']) {
        onInstallOpenTab();
    } else if (details.reason === MESSAGE_TYPE['update']) {
        clearCachedGroupData();
    }
});

/** this function used to refresh the webapp data. */
function refreshWepAppPage(response) {
    chrome.windows.getAll(
        {populate: true},
        function (window_list) {
            for (let i = 0; i < window_list.length; i++) {
                let tabs = window_list[i].tabs;
                for (let j = 0; j < tabs.length; j++) {
                    let tbaURL = tabs[j].url;
                    if (tbaURL.indexOf(conf.app_url) !== -1) {
                        chrome.tabs.sendMessage(tabs[j].id, {type: MESSAGE_TYPE['send_group_data'], value: response});
                    }
                }
            }
        }
    );
}

/**
 * Refreshes all Facebook and cloud application pages to reflect new state
 *
 * @param {boolean} [shouldIncludeCloudApp=true]
 *                  will refresh all cloud pages if true, otherwise will ignore them
 */
function refreshFbAndWebpage(shouldIncludeCloudApp = true) {
    chrome.windows.getAll({populate: true}, function (window_list) {
        for (let i = 0; i < window_list.length; i++) {
            let tabs = window_list[i].tabs;

            for (let j = 0; j < tabs.length; j++) {
                let tbaURL = tabs[j].url;
                let isFacebookPage = tbaURL.indexOf('facebook.com') !== -1;
                let isGroupkitCloudPage = (tbaURL.indexOf(conf.app_url) !== -1);

                if (
                    isFacebookPage
                    || (shouldIncludeCloudApp && isGroupkitCloudPage)
                ) {
                    chrome.tabs.reload(tabs[j].id);
                }
            }
        }
    });
}

/** when extension installed then open this URL. */
function onInstallOpenTab() {
    chrome.tabs.create({url: conf.installURL}, function () {
        if (!chrome.runtime.lastError) {
        }
    });
}

/** when extension uninstalled then open this URL. */
chrome.runtime.setUninstallURL(conf.unInstallURL, function () {
});

/** every 5 minutes set Interval */
setInterval(function () {
    /** Update chrome extension to latest version available on store */
    chrome.runtime.requestUpdateCheck(function (status) {
        if (status === "update_available") {
            chrome.runtime.reload();
        }
    });
}, 300 * 1000);

/**
 * Clears all cached items which keys contain '_facebook_group_' to keep memory clean
 */
function clearCachedGroupData() {
    getAllStorageData().then(cachedItems => {
        let items = [];

        for (const [key, value] of Object.entries(cachedItems)) {
            if (key.includes('facebook_group_')) {
                items.push(key);
            }
        }

        removeItemsFromCache(items);
    });
}


/**
 * Reads all data out of storage.local and exposes it via a promise.
 * Note: Once the Storage API gains promise support, this function can be greatly simplified.
 *
 * @return {Promise} with all storage items if there is no any error,
 *                   otherwise returns {Promise} with last error
 */
function getAllStorageData() {
  // Immediately return a promise and start asynchronous work
  return new Promise((resolve, reject) => {
    // Asynchronously fetch all data from storage.sync.
    chrome.storage.local.get(null, (items) => {
      // Pass any observed errors down the promise chain.
      if (chrome.runtime.lastError) {
        return reject(chrome.runtime.lastError);
      }
      // Pass the data retrieved from storage down the promise chain.
      resolve(items);
    });
  });
}

/**
 * Removes one or more items from the cache
 *
 * @param {String[]} keys one or more items to be deleted from storage
 */
function removeItemsFromCache(keys) {
    if (keys.length) {
        chrome.storage.local.remove(keys);
    }
}

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (
        changeInfo
        && changeInfo.hasOwnProperty('status')
        && changeInfo.status === 'complete'
        && tab.hasOwnProperty('url')
        && isMemberRequestPage(tab.url)
    ) {
        GROUP_QUESTIONS = null; // resets group's cached questions
        getDisabledGroupIds().then(r => {
            //r.facebook_groups_ids is an array
            chrome.storage.local.set({ disabled_fb_groups: r.facebook_groups_ids });
        }).catch((error) => {
            groupkitLogout(true, true);
        });
    }
});

/**
 * Handles the results of approving a single member or all members from the Facebook member requests page
 *
 * @param {Object} approvalResultsMessage - contains the information regarding the success of failure of the approval
 * @param {number} facebookTabId - The ID of the open Facebook tab where the approve button was clicked
 *
 * @return {Promise<void>} which resolves after the new member data has been sent to the cloud
 */
async function handleMemberApprovalMessage(approvalResultsMessage, facebookTabId) {
    // We only support approval messages, otherwise, the message should be ignored
    if (![MESSAGE_TYPE['approve_all'], MESSAGE_TYPE['approve_one']].includes(approvalResultsMessage.type)) {
        return;
    }

    if (!GROUP_QUESTIONS) {
        GROUP_QUESTIONS = await getMembershipQuestions(
            approvalResultsMessage.lastUrlPart,
            approvalResultsMessage.groupinfo.groupid
        );
    }

    approvalResultsMessage.groupinfo = {
        ...approvalResultsMessage.groupinfo,
        ...GROUP_QUESTIONS, //adds group questions to the group info if they exist
    }

    for (let i = 0; i < approvalResultsMessage.users.length; i++) {
        if (isNaN(approvalResultsMessage.users[i].userID)) { // !Number.isInteger reports that all strings like "2903832839293" are not integers
            // Try parsing the user's ID from a URL, otherwise leave it undefined.
            approvalResultsMessage.users[i].userID = approvalResultsMessage.users[i].userID?.trim().split('/user/')[1]?.split('/')[0];
        }
        if (
            approvalResultsMessage.users[i].invitedBy
            && approvalResultsMessage.users[i].invitedBy.hasOwnProperty('fbId')
            && isNaN(approvalResultsMessage.users[i].invitedBy.fbId)
        ) {
            approvalResultsMessage.users[i].invitedBy.fbId = approvalResultsMessage.users[i].invitedBy.fbId.trim().split('/user/')[1].split('/')[0];
        }
    }

    normalizeScrapedGroupMembersData(approvalResultsMessage, facebookTabId);
}

/**
 * Gets membership question from the membership question page
 *
 * @param {String} lastUrlPart of the Facebook group to determine from which page
 *                 questions should be scraped.
 * @param {Number} groupId of the Facebook group which questions will be scrapped
 *
 * @returns {Promise<*>} including membership question if they found, otherwise null
 */
async function getMembershipQuestions(lastUrlPart, groupId) {
    const groupQuestionTab = await chrome.tabs.create({
        url: lastUrlPart === LAST_PART_OF_PRIVATE_GROUP_URL
            ? `https://www.facebook.com/groups/${groupId}/membership_questions`
            : `https://www.facebook.com/groups/${groupId}/participation_questions`,
        active: false,
    });

    const groupQuestionTabId = groupQuestionTab.id;

    if (!groupQuestionTab.url) {
        await onTabUrlUpdated(groupQuestionTabId);
    }

    const scrapeQuestionsResponse = await chrome.scripting.executeScript({
        target: { tabId: groupQuestionTabId },
        files: ['/content/scrape_group_questions.js'],
    });

    chrome.tabs.remove(groupQuestionTabId);

    return scrapeQuestionsResponse?.[0]?.result;
}

/**
 * Normalizes the Facebook group members data, and then sends it to the cloud.
 *
 * @param {object} facebookGroupMembersData - The Facebook groups and group members data to be updated to the cloud
 * @param {number} facebookTabId - The browser tab ID for the scraped Facebook page
 *
 * @return {Promise<boolean>} - true if the normalized data was sent and accepted at the cloud without issue,
 *                              otherwise false
 *
 * @todo: separate the normalization from the sending to the cloud
 */
async function normalizeScrapedGroupMembersData(facebookGroupMembersData, facebookTabId) {

    let groupMembersData = {};
    let approvalResultsMessage = {};
    groupMembersData.group = facebookGroupMembersData.groupinfo
    groupMembersData.user_details = [];

    /** if check a userID is empty,then this record is not saved. */
    if (!facebookGroupMembersData.users.length) {
        approvalResultsMessage.type = MESSAGE_TYPE['update_facebook_ui'];
        approvalResultsMessage.memberWasAdded = false;
        approvalResultsMessage.approvalType = facebookGroupMembersData.type;
        chrome.tabs.sendMessage(facebookTabId, approvalResultsMessage);
        return false;
    }

    for (let i = 0; i < facebookGroupMembersData.users.length; i++) {
        let member = {};
        if (facebookGroupMembersData.users[i].userID == null || facebookGroupMembersData.users[i].userID === "ERROR") {
            member.user_id = "";
        } else {
            member.user_id = facebookGroupMembersData.users[i].userID;
        }

        if (facebookGroupMembersData.users[i].userName == null || facebookGroupMembersData.users[i].userName === "ERROR") {
            member.f_name = "";
            member.l_name = "";
        } else {
            member.name = facebookGroupMembersData.users[i].userName;
            if (member.name) {
                let array = member.name.replace(/\s+/, "|#GK*.!#|").split("|#GK*.!#|");
                member.f_name = array[0] || '';
                member.l_name = array[1] || '';
            } else {
                member.f_name = "";
                member.l_name = "";
            }
        }

        if (facebookGroupMembersData.users[i].questions.length) {
            let memberQuestions = facebookGroupMembersData.users[i].questions;
            if (memberQuestions[0]) {
                member.q1 = memberQuestions[0].question ?? '';
                member.a1 = memberQuestions[0].answer ?? '';
            }
            if (memberQuestions[1]) {
                member.q2 = memberQuestions[1].question ?? '';
                member.a2 = memberQuestions[1].answer ?? '';
            }
            if (memberQuestions[2]) {
                member.q3 = memberQuestions[2].question ?? '';
                member.a3 = memberQuestions[2].answer ?? '';
            }
        } else {
            member.q1 = member.q2 = member.q3 = member.a1 = member.a2 = member.a3 = "";
        }

        if (!facebookGroupMembersData.users[i].img || facebookGroupMembersData.users[i].img === "ERROR") {
            member.img = "";
        } else {
            member.img = facebookGroupMembersData.users[i].img;
        }

        member.date_add_time = parseInt(new Date().getTime()) + Math.floor(Math.random() * 10000) + 1;
        member.email = facebookGroupMembersData.users[i].questions.length
            ? extractEmail(facebookGroupMembersData.users[i].questions)
            : ''
        ;
        member.respond_status = "Processing";
        member.invited_by_name = facebookGroupMembersData.users[i].invitedBy.name;
        member.invited_by_id = facebookGroupMembersData.users[i].invitedBy.fbId;
        member.lives_in = facebookGroupMembersData.users[i].livesIn;
        member.agreed_group_rules = facebookGroupMembersData.users[i].agreedGroupRules;
        groupMembersData.user_details.push(member);
    }

    chrome.storage.local.get(
        ["current_session"],
        function (result) {
            const accessToken = result.current_session ? JSON.parse(atob(result.current_session)).access_token : '';

            fetch(
                API_URL + '/recordSave',
                {
                    method: 'post',
                    credentials: 'include',
                    body: JSON.stringify({ json: [groupMembersData] }),
                    headers: {
                        Accept: 'application/json',
                        Authorization: 'Bearer ' + accessToken,
                        'Content-Type': 'application/json',
                    },
                }
            )
                .then((response) => {
                    if (response.ok) {
                        return response.clone().json();
                    }

                    throw new Error(response.statusText);
                })
                .then((response) => {
                    if (response.limit === true) {
                        const return_client_data = {
                            type: MESSAGE_TYPE['limit_reached'],
                            content: response,
                        };
                        chrome.tabs.sendMessage(facebookTabId, return_client_data);
                        return false;
                    }

                    refreshWepAppPage(response.data);

                    approvalResultsMessage = {};
                    approvalResultsMessage.type = MESSAGE_TYPE['update_facebook_ui'];
                    approvalResultsMessage.memberWasAdded = true;
                    approvalResultsMessage.approvalType = facebookGroupMembersData.type;
                    chrome.tabs.sendMessage(facebookTabId, approvalResultsMessage);
                })
        });

    return true;
}

/**
 * Sends disable group API request and adds the disabled group in the disabled_fb_groups storage
 *
 * @param {String} facebookGroupId of the group that will be disabled
 */
function disableGroup(facebookGroupId) {
    manageFacebookGroupStatusInCloud(facebookGroupId, false).then((res) => {
        if (['This Facebook group already has the disabled status', 'Group disabled'].includes(res.message)) {
            chrome.storage.local.get(['disabled_fb_groups'], function (storage) {
                if (!storage.disabled_fb_groups.hasOwnProperty(facebookGroupId)) {
                    storage.disabled_fb_groups.push(facebookGroupId);

                    chrome.storage.local.set({ disabled_fb_groups: storage.disabled_fb_groups });
                }
            });

            //send response back to content script facebook_ui.js initHook()
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, { type: MESSAGE_TYPE['group_disabled'] });
            });
        }
    });
}

/**
 * Sends enable group API request and removes the disabled group from the disabled_fb_groups storage
 *
 * @param {String} facebookGroupId of the group that will be enabled
 */
function enableGroup(facebookGroupId) {
    manageFacebookGroupStatusInCloud(facebookGroupId, true).then((res) => {
        if (['This Facebook group does not have the disabled status', 'Group enabled'].includes(res.message)) {
            chrome.storage.local.get(['disabled_fb_groups'], function (storage) {
                chrome.storage.local.set({
                    disabled_fb_groups: storage.disabled_fb_groups.filter(g => g !== facebookGroupId),
                });
            });

            //send response back to content script facebook_ui.js initHook()
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, { type: MESSAGE_TYPE['group_enabled'] });
            });
        }
    });
}

/**
 * Gets disabled groups from the cloud API
 */
function getDisabledGroupIds() {
    return new Promise(
        function (resolve) {
            cloudAppRequest(
                CLOUD_API_ENDPOINTS['getDisabledGroups'],
                METHOD.get,
                undefined,
                {},
                CALL_MODE.api,
                (response) => {
                    resolve(response);
                }
            );
        }
    );
}

/**
 * Disables/Enables provided Facebook group in the cloud
 *
 * @param {String} facebookId Facebook numeric group ID.
 * @param {boolean} isEnableRequest true if request is to enable group, otherwise false.
 *
 * @returns {Promise<Object>} data verifying a successful save, or an object with {limit: true} on save failure
 */
 async function manageFacebookGroupStatusInCloud(facebookId, isEnableRequest = false) {
    return new Promise(
        function (resolve) {
            cloudAppRequest(
                CLOUD_API_ENDPOINTS[isEnableRequest ? 'enableGroup' : 'disableGroup'],
                METHOD.post,
                undefined,
                { facebook_group_id: facebookId },
                CALL_MODE.api,
                (response) => {
                    resolve(response);
                }
            );
        }
    );
}

/**
 * Gets HTML with group details for provided facebookGroupId
 * Sends that HTML to the content script {@see MESSAGE_TYPE.scrapedFacebookGroup} message type
 *
 * @param {string|number} facebookGroupIdentifier for getting group details, it could be numeric facebook group id or alpha-numeric
 * @param {number} facebookGroupId for getting group details
 * @param {number} tabId for sending message to that tab id
 * @param {boolean} shouldScrapeMembers indicator if script should scrape members in the scraper.js message listener
 */
function getScrapingGroupsByUrl(
    facebookGroupIdentifier,
    facebookGroupId,
    tabId,
    shouldScrapeMembers = true
) {
    fetch(`https://m.facebook.com/groups/${facebookGroupIdentifier}`,
        {
            method: 'get',
            headers: {
                Accept: 'text/html',
                'Content-Type': 'application/x-www-form-urlencoded',
            },
        }).then((res) => res.text())
        .then(res => {
            chrome.tabs.sendMessage(
                tabId,
                {
                    type: MESSAGE_TYPE['scrapedFacebookGroup'],
                    facebookGroupId: facebookGroupId,
                    scrappedData: res,
                    tabId: tabId,
                    shouldScrapeMembers: shouldScrapeMembers,
                });
        });
}

/**
 * To update the tab url while waiting
 *
 * @param {number} tabId for the url
 * @return {Promise} 
 */
function onTabUrlUpdated(tabId) {
    return new Promise((resolve, reject) => {
      const onUpdated = (id, info) => id === tabId && info.url && done(true);
      const onRemoved = id => id === tabId && done(false);
      chrome.tabs.onUpdated.addListener(onUpdated);
      chrome.tabs.onRemoved.addListener(onRemoved);
      function done(ok) {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        chrome.tabs.onRemoved.removeListener(onRemoved);
        (ok ? resolve : reject)();
      }
    });
  }

/**
 * Gets HTML with group members for provided url
 * Sends that HTML to the content script {@see MESSAGE_TYPE.scrapedFacebookGroup} message type
 *
 * @param {string} url for getting group members HTML
 * @param {number} tabId for sending message to that tab id
 */
function scrapeGroupMembers(url, tabId) {
    fetch(
        url,
        {
            method: 'get',
            headers: {
                Accept: 'text/html',
                'Content-Type': 'multipart/form-data',
                'X-Requested-With': 'XMLHttpRequest',
            },
        }
    ).then(res => {
        return res.text();
    }).then(res => {
        chrome.tabs.sendMessage(
            tabId,
            {
                type: MESSAGE_TYPE['groupMembersScraped'],
                groupMembers: res,
            });
    })
}