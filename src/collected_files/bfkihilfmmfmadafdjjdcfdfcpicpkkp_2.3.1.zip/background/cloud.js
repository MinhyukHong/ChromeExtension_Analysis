/**
 * Interface used by this extension to communicate with the Groupkit Cloud Web Application
 */

let current_session = null;

/**
 * Saves a set of group members to the cloud
 *
 * @param payload Facebook group member data
 *
 * @returns {Promise<Object>} data verifying a successful save, or an object with {limit: true} on save failure
 */
function saveGroupMembersToCloud(payload) {
    return new Promise(
        function (resolve)
        {
            const payloadObject = {json: payload};
            cloudAppRequest(
                CLOUD_API_ENDPOINTS.addGroupMember,
                METHOD.post,
                undefined,
                payloadObject,
                CALL_MODE.api,
                (response) =>
                {
                    resolve(response.data);
                }
            );
        }
    )
}

/**
 * Logs the user into the cloud web application
 *
 * @param {string|Object|ArrayBuffer|ArrayBufferView|URLSearchParams|FormData|File|Blob} userData - of the user to login
 */
function webAppLogin(userData) {
    cloudAppRequest(
        CLOUD_API_ENDPOINTS.webAppLogin + '/' + userData,
        METHOD.get,
        undefined,
        undefined,
        CALL_MODE.web,
        (response) => {
            if (response.status === 200) {
                const messageData = {type: MESSAGE_TYPE['tab_reload']};
                chrome.runtime.sendMessage(messageData);
                if (typeof chrome.extension.getBackgroundPage().reloadGroupkitCloudApp === "function") {
                    chrome.extension.getBackgroundPage().reloadGroupkitCloudApp();
                }
            }
        }
    );
}

/**
 * We need to monitor the sessions of the cloud app to determine the login state of the extension.
 *
 * In the event that no extension session exists, we set it to the existing cloud app session.
 *
 * In the event that the extension session exists, and it does not match the cloud app session,
 * we force a logout of both.
 */
function resolveSessionMismatches() {
    chrome.storage.local.get(
        "current_session",
        function (result) {
            let cloudAppSession = localStorage.getItem('current_session');
            let extensionSession = result.current_session;
            let isloginPage = window.location.href.toLowerCase().indexOf(APP_URL + '/login') != -1;

            if (isloginPage && extensionSession) {
                groupkitLogout(false);
            } else if (cloudAppSession != extensionSession) {
                chrome.storage.local.set({current_session: cloudAppSession});
            }
        }
    );
}

if (!window.location.href.startsWith('chrome-extension://')) {
    window.onstorage = () => {
        resolveSessionMismatches();
    }

    window.onload = () => {
        resolveSessionMismatches();
    }
}
