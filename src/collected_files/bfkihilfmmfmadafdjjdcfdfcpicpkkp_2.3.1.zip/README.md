## installation Guide

	*Step_1 - Change the respective config.json.js file.
	
	*Step_2 - go to chrome settings and load the extension.

