// Create context menu item
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "pickColor",
    title: "Pick Colour",
    contexts: ["all"]
  });
});

// Handle context menu clicks with proper error handling
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "pickColor") {
    try {
      // Check if the tab exists and is ready
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tabs.length > 0) {
        await chrome.tabs.sendMessage(tabs[0].id, { 
          action: "getHexCode"
        });
      }
    } catch (error) {
      console.log('Could not activate color picker:', error);
    }
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "copyToClipboard") {
    // Store the hex code in storage for later use
    chrome.storage.local.set({ lastHexCode: request.hexCode });
  }
}); 