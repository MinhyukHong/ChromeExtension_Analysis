// Minimal, efficient tooltip styles
const style = document.createElement('style');
style.textContent = `
  .color-picker-tooltip {
    position: fixed;
    background: #333;
    color: white;
    padding: 6px 10px;
    border-radius: 3px;
    font-size: 12px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    z-index: 999999;
    opacity: 0;
    transition: opacity 0.2s ease;
    pointer-events: none;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    max-width: 200px;
    white-space: nowrap;
  }
  .color-picker-tooltip.show {
    opacity: 1;
  }
  .color-picker-tooltip.success {
    background: #4CAF50;
  }
  .color-picker-tooltip.error {
    background: #F44336;
  }
`;
document.head.appendChild(style);

// Create tooltip element
const tooltip = document.createElement('div');
tooltip.className = 'color-picker-tooltip';
document.body.appendChild(tooltip);

// Efficient tooltip positioning with bounds checking
function showTooltip(message, isError = false) {
  tooltip.textContent = message;
  tooltip.className = `color-picker-tooltip ${isError ? 'error' : 'success'}`;
  
  // Calculate bounds
  const bounds = {
    right: window.innerWidth - tooltip.offsetWidth - 10,
    bottom: window.innerHeight - tooltip.offsetHeight - 10
  };

  const left = Math.min(lastMouseX + 10, bounds.right);
  const top = Math.min(lastMouseY + 10, bounds.bottom);
  
  tooltip.style.left = `${left}px`;
  tooltip.style.top = `${top}px`;
  
  tooltip.classList.add('show');
  setTimeout(() => tooltip.classList.remove('show'), 2000);
}

// Optimized mouse position tracking
let lastMouseX = 0;
let lastMouseY = 0;
let mouseMoveTimeout;

document.addEventListener('mousemove', (e) => {
  if (mouseMoveTimeout) return; // Skip if we're already waiting
  mouseMoveTimeout = setTimeout(() => {
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
    mouseMoveTimeout = null;
  }, 16);
});

// Main color picking function with proper cleanup
async function pickColor() {
  try {
    if (window.EyeDropper) {
      const eyeDropper = new EyeDropper();
      const result = await eyeDropper.open();
      return result.sRGBHex;
    } else {
      return new Promise((resolve, reject) => {
        enableFallbackColorPicker(resolve, reject);
      });
    }
  } catch {
    throw new Error('Cancelled');
  }
}

// Optimized fallback picker
function enableFallbackColorPicker(resolve, reject) {
  const pickerOverlay = document.createElement('div');
  pickerOverlay.style.cssText = 
    'position:fixed;top:0;left:0;width:100%;height:100%;cursor:crosshair;z-index:999999;';
  
  const previewBox = document.createElement('div');
  previewBox.style.cssText = 
    'position:fixed;width:80px;height:20px;background:#fff;border:1px solid #000;' +
    'pointer-events:none;z-index:1000000;font-size:12px;padding:2px;text-align:center;';

  document.body.appendChild(pickerOverlay);
  document.body.appendChild(previewBox);

  function cleanup() {
    pickerOverlay.remove();
    previewBox.remove();
  }

  function handleMove(e) {
    const color = getColorAtPoint(e.clientX, e.clientY);
    previewBox.textContent = color;
    previewBox.style.backgroundColor = color;
    previewBox.style.color = getBestContrastColor(color);
    previewBox.style.left = `${e.clientX + 10}px`;
    previewBox.style.top = `${e.clientY + 10}px`;
  }

  pickerOverlay.addEventListener('mousemove', handleMove);
  pickerOverlay.addEventListener('click', (e) => {
    e.preventDefault();
    const color = getColorAtPoint(e.clientX, e.clientY);
    cleanup();
    resolve(color);
  });
  pickerOverlay.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    cleanup();
    reject(new Error('Cancelled'));
  });
}

// Efficient color sampling
function getColorAtPoint(x, y) {
  const element = document.elementFromPoint(x, y);
  if (!element) return '#000000';

  const style = window.getComputedStyle(element);
  const color = style.backgroundColor !== 'transparent' ? 
    style.backgroundColor : style.color;
  
  return rgbToHex(color);
}

// Optimized color conversion
function rgbToHex(color) {
  const rgb = color.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
  if (!rgb) return color;
  
  return '#' + rgb.slice(1,4)
    .map(n => parseInt(n, 10).toString(16).padStart(2, '0'))
    .join('');
}

// Efficient contrast calculation
function getBestContrastColor(hexcolor) {
  const rgb = hexcolor.match(/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i);
  if (!rgb) return '#000000';
  
  const luminance = (parseInt(rgb[1], 16) * 0.299 + 
                    parseInt(rgb[2], 16) * 0.587 + 
                    parseInt(rgb[3], 16) * 0.114) / 255;
  return luminance > 0.5 ? '#000000' : '#ffffff';
}

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getHexCode") {
    pickColor()
      .then(color => {
        navigator.clipboard.writeText(color)
          .then(() => showTooltip(`Copied: ${color}`))
          .catch(() => showTooltip('Copy failed', true));
      })
      .catch(() => showTooltip('Cancelled', true));
  }
}); 