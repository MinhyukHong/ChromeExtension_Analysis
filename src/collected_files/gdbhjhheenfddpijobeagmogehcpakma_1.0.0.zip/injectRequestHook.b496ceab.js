var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,o,n,i,a){var r="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},l="function"==typeof r[i]&&r[i],d=l.cache||{},s="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function c(e,o){if(!d[e]){if(!t[e]){var n="function"==typeof r[i]&&r[i];if(!o&&n)return n(e,!0);if(l)return l(e,!0);if(s&&"string"==typeof e)return s(e);var a=Error("Cannot find module '"+e+"'");throw a.code="MODULE_NOT_FOUND",a}p.resolve=function(o){var n=t[e][1][o];return null!=n?n:o},p.cache={};var g=d[e]=new c.Module(e);t[e][0].call(g.exports,p,g,g.exports,this)}return d[e].exports;function p(e){var t=p.resolve(e);return!1===t?{}:c(t)}}c.isParcelRequire=!0,c.Module=function(e){this.id=e,this.bundle=c,this.exports={}},c.modules=t,c.cache=d,c.parent=l,c.register=function(e,o){t[e]=[function(e,t){t.exports=o},{}]},Object.defineProperty(c,"root",{get:function(){return r[i]}}),r[i]=c;for(var g=0;g<o.length;g++)c(o[g]);if(n){var p=c(n);"object"==typeof exports&&"undefined"!=typeof module?module.exports=p:"function"==typeof e&&e.amd?e(function(){return p}):a&&(this[a]=p)}}({jeyoU:[function(e,t,o){e("348cf1fca8ccafce").register(JSON.parse('{"90vTI":"injectRequestHook.b496ceab.js","cNahO":"main.62c55b61.js"}'))},{"348cf1fca8ccafce":"2PZ3M"}],"2PZ3M":[function(e,t,o){var n={};t.exports.register=function(e){for(var t=Object.keys(e),o=0;o<t.length;o++)n[t[o]]=e[t[o]]},t.exports.resolve=function(e){var t=n[e];if(null==t)throw Error("Could not resolve bundle with id "+e);return t}},{}],"3gkI2":[function(e,t,o){let n,i;var a=e("@parcel/transformer-js/src/esmodule-helpers.js");a.defineInteropFlag(o),a.export(o,"config",()=>d);var r=e("url:~pageScripts/main"),l=a.interopDefault(r);let d={matches:["https://www.tiktok.com/@*"],all_frames:!1,run_at:"document_end"},s=[],c=!1,g=!1,p="results ready to download",u=" results scraped";if(document.getElementById("ext-tiktok-profile-extractor")){let e=document.getElementById("ext-tiktok-profile-extractor");e.parentNode.removeChild(e)}let m=document.createElement("script");m.setAttribute("type","text/javascript"),m.setAttribute("src",l.default),m.setAttribute("id","ext-tiktok-profile-extractor"),document.documentElement.appendChild(m),m.addEventListener("load",()=>{chrome.storage.local.get(["ajaxInterceptor_switchOn","ajaxInterceptor_rules"],e=>{e.ajaxInterceptor_rules&&postMessage({type:"ajaxInterceptor",to:"pageScript",key:"ajaxInterceptor_rules",value:e.ajaxInterceptor_rules})}),postMessage({type:"ajaxInterceptor",to:"pageScript",key:"ajaxInterceptor_switchOn",value:!0})});let x=document.createElement("style"),b=`
    :root {
        --dark: rgba(40, 48, 58, 1);
        --dark-light: rgba(40, 48, 58, 0.85);
        --white: rgba(255, 255, 255, 0.9);
        --background: rgba(255, 255, 255, 1);
        --foreground: rgba(235, 235, 235, 1);
        --disabled: rgba(240, 240, 240, 1);
        --silver: rgba(208, 210, 222, 1);
        --color: rgba(255, 192, 5, 1);
        --color-light: rgba(255, 192, 5, 0.7);
        --highlight: rgb(210, 42, 76);
        --border-radius: 4px;
    }

    @keyframes celebrateShow {
        100% {
            opacity: 1;
            transform: translate(-50%, -50%) scale3d(1, 1, 1);
        }
    }

    @keyframes ocrloaderFadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }
    
    @keyframes ocrloaderMove {
        0%, 100% {
            transform: translateY(6vh);
        }
        50% {
            transform: translateY(85vh);
        }
    }

    @keyframes ocrloaderBlinker {
        50% {
            box-shadow: 0 0 8px 1px var(--yellow), 0 0 2px 1px var(--yellow);
        }
    }

    .ext-entry-button {
        color: var(--dark);
        border: 2px solid var(--dark);
        background: linear-gradient(var(--color-light), var(--color));
        font-size: 12px;
        font-weight: 600;
        text-align: center;
        padding: 5px 5px;
        margin: 0;
        margin-top: 0px;
        margin-bottom: 2px;
        position: relative;
        cursor: pointer;
        box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 0px;
        border-radius: var(--border-radius);
    }
    .ext-entry-button:hover {
        box-shadow: 0 0 0 rgba(0, 0, 0, 0.4);
    }
    .ext-entry-button:active {
        margin-top: 2px;
        margin-bottom: 0;
        box-shadow: 0 0 0 rgba(0, 0, 0, 0.4);
    }
    .extBtnDisable {
        display: inline;
        opacity: 0.4;
        disabled: true;
        cursor: not-allowed;
    }

    .ext-finished-dialog {
        background-color: rgba(0, 0, 0, 0.7);
        --yellow: rgba(250, 189, 14, 0.95);
        --red: #EA4335;
        --grey: rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(5px);
        font-family: Arial, Helvetica, sans-serif;
        position: fixed;
        top: 0px;
        left: 0px;
        width: 100%;
        height: 100%;
        backface-visibility: hidden;
        animation-timeline: auto;
        animation-range-start: normal;
        animation-range-end: normal;
        z-index: 99999;
        animation: 1s ease-out 0s 1 normal none running ocrloaderFadeIn;
        border-radius: 6px;
    }

    .ext-finished-dialog-div {
        z-index: 2;
        position: fixed;
        background-color: rgb(246, 244, 239);
        box-shadow: rgba(0, 0, 0, 0.25) 0px 0px 10px 2px;
        opacity: 0;
        width: 400px;
        height: fit-content;
        top: 50%;
        left: 50%;
        animation-timeline: auto;
        animation-range-start: normal;
        animation-range-end: normal;
        transform: translate(-50%, -50%) scale3d(0.5, 0.4, 1);
        border-radius: 5px;
        padding: 30px;
        animation: 0.1s ease-out 0s 1 normal forwards running celebrateShow;
    }

    .ext-finished-dialog-close {
        position: absolute;
        top: 20px;
        right: 20px;
        font-size: 32px;
        color: var(--dark);
        background-color: transparent;
        cursor: pointer;
        opacity: 0.7;
        border-width: 0px;
        border-style: initial;
        border-color: initial;
        border-image: initial;
    }

    .ext-emoji {
        display: inline-block;
        line-height: 96px;
        margin-top: -86px;
        margin-bottom: 20px;
        font-size: 96px;
        font-style: normal;
        filter: drop-shadow(rgba(0, 0, 0, 0.4) 0px 0px 5px);
    }

    .ext-finished-dialog-content {
        text-align: center;
    }

    .ext-finished-dialog-content h1 {
        font-size: 32px;
        font-weight: bold;
        color: rgb(0, 0, 0);
        margin: 0px 0px 40px;
    }

    .ext-finished-dialog-content label {
        margin-bottom: 40px;
        font-size: 18px;
        color: rgb(0, 0, 0);
        opacity: 0.8;
    }

    .ext-finished-dialog-upgrade {
        font-weight: bold;
        width: 100%;
        color: var(--dark);
        border: 2px solid var(--dark);
        background: linear-gradient(var(--color-light), var(--color));
        font-size: 14px;
        text-align: center;
        padding: 10px 30px;
        margin: 0;
        margin-top: 0px;
        margin-bottom: 2px;
        position: relative;
        cursor: pointer;
        box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 0px;
        border-radius: var(--border-radius);
    }

    .ext-finished-dialog-upgrade:hover {
        box-shadow: 0 0 0 rgba(0, 0, 0, 0.4);
    }

    .ext-finished-dialog-upgrade:active {
        margin-top: 2px;
        margin-bottom: 0;
        box-shadow: 0 0 0 rgba(0, 0, 0, 0.4);
    }

    .ext-finished-dialog-download-xls {
        color: var(--dark);
        width: 166px;
        border: 2px solid var(--dark-light);
        background: var(--white));
        font-size: 11px;
        font-weight: 600;
        text-align: center;
        padding: 10px 8px;
        margin: 0;
        margin-top: 0px;
        margin-bottom: 2px;
        position: relative;
        cursor: pointer;
        box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 0px;
        border-radius: var(--border-radius);
    }

    .ext-finished-dialog-download-xls:hover {
        box-shadow: 0 0 0 rgba(0, 0, 0, 0.4);
    }
    .ext-finished-dialog-download-xls:active {
        margin-top: 2px;
        margin-bottom: 0;
        box-shadow: 0 0 0 rgba(0, 0, 0, 0.4);
    }

    .ext-finished-dialog-download-csv {
        color: var(--dark);
        width: 167px;
        border: 2px solid var(--dark-light);
        background: var(--white));
        font-size: 11px;
        font-weight: 600;
        text-align: center;
        padding: 10px 8px;
        margin: 0;
        margin-left: 3px;
        margin-top: 0px;
        margin-bottom: 2px;
        position: relative;
        cursor: pointer;
        box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 0px;
        border-radius: var(--border-radius);
    }

    .ext-finished-dialog-download-csv:hover {
        box-shadow: 0 0 0 rgba(0, 0, 0, 0.4);
    }
    .ext-finished-dialog-download-csv:active {
        margin-top: 2px;
        margin-bottom: 0;
        box-shadow: 0 0 0 rgba(0, 0, 0, 0.4);
    }
`;x.innerHTML=b,document.head.appendChild(x);let f=document.createElement("div");f.innerHTML=`<div id="ext-scan-layer" style="display: none;">
    <div id="ext-scan-layer-loader" style="background-color: rgba(0, 0, 0, 0.7); --yellow: rgba(250, 189, 14, 0.95);
            --red: #EA4335;
            --grey: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            font-family: Arial, Helvetica, sans-serif;
            position: fixed;
            top: 0px;
            left: 0px;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            animation-timeline: auto;
            animation-range-start: normal;
            animation-range-end: normal;
            z-index: 99999;
            animation: 1s ease-out 0s 1 normal none running ocrloaderFadeIn;
            border-radius: 6px;">
        <label id="ext-scan-layer-count" style="display: unset; background-color: var(--yellow);
            color: rgb(68, 68, 68);
            position: absolute;
            top: 2vw;
            left: 50%;
            transform: translateX(-50%);
            font-size: 22px;
            font-weight: 600;
            animation-timeline: auto;
            animation-range-start: normal;
            animation-range-end: normal;
            box-shadow: rgba(0, 0, 0, 0.25) 0px 0px 10px 0px;
            z-index: 10;
            padding: 10px 30px;
            border-radius: 40px;
            animation: 1s ease-out 0s 1 normal none running ocrloaderFadeIn;">
                scraping...
        </label>
        <span class="always-enable-animations" style="position: absolute;
            top: 0px;
            width: 94vw;
            height: 8px;
            background-color: var(--yellow);
            box-shadow: 0 0 10px 0 var(--yellow), 0 0 1px 0 var(--yellow);
            z-index: 1;
            transform: translateY(95px);
            animation-timeline: auto;
            animation-range-start: normal;
            animation-range-end: normal;
            margin: 0px 3vw;
            animation: 3s cubic-bezier(0.8, 0.5, 0.5, 0.8) 0s infinite normal none running ocrloaderMove, 1.5s ease-in-out 0s normal none running ocrloaderBlinker !important;
            border-radius: 60%;">
    </span>
    </div>
    <div style="animation-delay: 1s;    
            position: fixed;
            display: inline-block;
            background-color: transparent;
            z-index: 99999999;
            bottom: 50px;
            left: 50%;
            margin-left: -180px;">
        <button id="ext-scan-layer-stop-btn" style="width: 360px;
                color: var(--color);
                border: 2px solid var(--background);
                background: linear-gradient(var(--dark-light), var(--dark));
                font-size: 13px;
                text-align: center;
                padding: 12px 30px;
                margin-top: 0px;
                margin-bottom: 2px;
                text-align: center;
                margin: 0;    
                position: relative;
                cursor: pointer;
                box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 0px;
                border-radius: var(--border-radius);">
                <svg style="vertical-align: middle;" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24">
                    <g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="2">
                      <path stroke-dasharray="2 4" stroke-dashoffset="6"
                        d="M12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21">
                        <animate attributeName="stroke-dashoffset" dur="0.6s" repeatCount="indefinite" values="6;0" />
                      </path>
                      <path stroke-dasharray="30" stroke-dashoffset="30"
                        d="M12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3">
                        <animate fill="freeze" attributeName="stroke-dashoffset" begin="0.1s" dur="0.3s" values="30;0" />
                      </path>
                      <path stroke-dasharray="10" stroke-dashoffset="10" d="M12 8v7.5">
                        <animate fill="freeze" attributeName="stroke-dashoffset" begin="0.5s" dur="0.2s" values="10;0" />
                      </path>
                      <path stroke-dasharray="6" stroke-dashoffset="6" d="M12 15.5l3.5 -3.5M12 15.5l-3.5 -3.5">
                        <animate fill="freeze" attributeName="stroke-dashoffset" begin="0.7s" dur="0.2s" values="6;0" />
                      </path>
                    </g>
                  </svg>
            <b>Stop</b> 
            <!-- TODO -->
            Extract Results
        </button>
    </div>
</div>    
`;let h=document.createElement("div");h.innerHTML=`<div id="ext-finished-dialog" style="display: none; position: fixed; z-index: 9999999;">
    <div class="ext-finished-dialog">
        <div class="always-enable-animations ext-finished-dialog-div">
            <button id="ext-finished-dialog-close" class="ext-finished-dialog-close">
                \xd7
            </button>
            <div class="ext-finished-dialog-content">
                <em class="ext-emoji">
                    &#x1F389
                </em>
                <h1>
                    Congratulations!
                </h1>
                <label>
                    <b id="ext-finished-dialog-countNum" style="font-weight: bold;">
                        0
                    </b>
                    ${p}
                </label>
            </div>
            <div style="margin-top: 30px;text-align: center;">
                <button id="ext-finished-dialog-upgrade" class="ext-finished-dialog-upgrade">Upgrade to PRO download all</button>
            </div>
            <div style="margin-top: 10px;">
                <button id="ext-finished-dialog-download-xls" class="ext-finished-dialog-download-xls">
                    FREE Download As XLS(30)
                </button>
                <button id="ext-finished-dialog-download-csv" class="ext-finished-dialog-download-csv">
                    FREE Download As CSV(30)
                </button>
            </div>
            <div style="margin-top: 30px;">
                <div style="text-align: center !important; color: #b5b5b5 !important;ont-size: .75rem;"> 
                    Powered by 
                    <a href="https://tiktokprofileleextractor.letsfaster.com" target="_blank" 
                        style="color: #0a0a0a !important; cursor: pointer; text-decoration: none; opacity: 0.5;">
                        LetsFaster
                    </a><br>
                </div>
            </div>
        </div>
    </div>
</div>
`;let y=document.createElement("div");y.innerHTML=`<div id="ext-finished-pro-dialog" style="display: none; position: fixed; z-index: 9999999;">
    <div style="background-color: rgba(0, 0, 0, 0.7);
                --yellow: rgba(250, 189, 14, 0.95);
                --red: #EA4335;
                --grey: rgba(0, 0, 0, 0.5);
                backdrop-filter: blur(5px);
                font-family: Arial, Helvetica, sans-serif;
                position: fixed;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                backface-visibility: hidden;
                animation-timeline: auto;
                animation-range-start: normal;
                animation-range-end: normal;
                z-index: 99999;
                animation: 1s ease-out 0s 1 normal none running ocrloaderFadeIn;
                border-radius: 6px;">
        <div class="always-enable-animations" style="z-index: 2;
                    position: fixed;
                    background-color: rgb(246, 244, 239);
                    box-shadow: rgba(0, 0, 0, 0.25) 0px 0px 10px 2px;
                    opacity: 0;
                    width: 400px;
                    height: fit-content;
                    top: 50%;
                    left: 50%;
                    animation-timeline: auto;
                    animation-range-start: normal;
                    animation-range-end: normal;
                    transform: translate(-50%, -50%) scale3d(0.5, 0.4, 1);
                    border-radius: 5px;
                    padding: 30px;
                    animation: 0.1s ease-out 0s 1 normal forwards running celebrateShow;">
            <button id="ext-finished-pro-dialog-close" style="position: absolute;
                        top: 20px;
                        right: 20px;
                        font-size: 32px;
                        color: var(--dark);
                        background-color: transparent;
                        cursor: pointer;
                        opacity: 0.7;
                        border-width: 0px;
                        border-style: initial;
                        border-color: initial;
                        border-image: initial;"
            >
                \xd7
            </button>
            <div style="text-align: center;">
                <em style="display: inline-block;
                        line-height: 96px;
                        margin-top: -86px;
                        margin-bottom: 20px;
                        font-size: 96px;
                        font-style: normal;
                        filter: drop-shadow(rgba(0, 0, 0, 0.4) 0px 0px 5px);">
                    &#x1F389
                </em>
                <h1 style="font-size: 32px;
                        font-weight: bold;
                        color: rgb(0, 0, 0);
                        margin: 0px 0px 40px;">
                    Congratulations!
                </h1>
                <label style="margin-bottom: 40px;
                            font-size: 18px;
                            color: rgb(0, 0, 0);
                            opacity: 0.8;">
                    <b id="ext-finished-pro-dialog-countNum" style="font-weight: bold;">
                        0
                    </b>
                    <!-- TODO -->
                    ${p}
                </label>
            </div>
            <div style="margin-top: 30px;">
                <button id="ext-finished-pro-dialog-download-xls" style="color: var(--dark);
                            width: 166px;
                            border: 2px solid var(--dark);
                            background: linear-gradient(var(--color-light), var(--color));
                            font-size: 11px;
                            font-weight: 600;
                            text-align: center;
                            padding: 10px 8px;
                            margin: 0;
                            margin-top: 0px;
                            margin-bottom: 2px;
                            position: relative;
                            cursor: pointer;
                            box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 0px;
                            border-radius: var(--border-radius);">
                    Download As XLS
                </button>
                <button id="ext-finished-pro-dialog-download-csv" style="color: var(--dark);
                            width: 167px;
                            border: 2px solid var(--dark);
                            background: linear-gradient(var(--color-light), var(--color));
                            font-size: 11px;
                            font-weight: 600;
                            text-align: center;
                            padding: 10px 8px;
                            margin: 0;
                            margin-left: 3px;
                            margin-top: 0px;
                            margin-bottom: 2px;
                            position: relative;
                            cursor: pointer;
                            box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 0px;
                            border-radius: var(--border-radius);">
                    Download As CSV
                </button>
            </div>
            <div style="margin-top: 30px;">
                <div style="text-align: center !important; color: #b5b5b5 !important;ont-size: .75rem;"> 
                    Powered by 
                    <a href="https://tiktokprofileextractor.letsfaster.com" target="_blank" 
                        style="color: #0a0a0a !important; cursor: pointer; text-decoration: none; opacity: 0.5;">
                        LetsFaster
                    </a><br>
                </div>
            </div>
        </div>
    </div>
</div>
`;let v=document.createElement("div");v.innerHTML=`<div id="ext-login-dialog" style="display: none; position: fixed; z-index: 9999999;">
    <div style="background-color: rgba(0, 0, 0, 0.7);
                --yellow: rgba(250, 189, 14, 0.95);
                --red: #EA4335;
                --grey: rgba(0, 0, 0, 0.5);
                backdrop-filter: blur(5px);
                font-family: Arial, Helvetica, sans-serif;
                position: fixed;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                backface-visibility: hidden;
                animation-timeline: auto;
                animation-range-start: normal;
                animation-range-end: normal;
                z-index: 99999;
                animation: 1s ease-out 0s 1 normal none running ocrloaderFadeIn;
                border-radius: 6px;">
        <div class="always-enable-animations" style="z-index: 2;
                    position: fixed;
                    background-color: rgb(246, 244, 239);
                    box-shadow: rgba(0, 0, 0, 0.25) 0px 0px 10px 2px;
                    opacity: 0;
                    width: 360px;
                    height: fit-content;
                    top: 50%;
                    left: 50%;
                    animation-timeline: auto;
                    animation-range-start: normal;
                    animation-range-end: normal;
                    transform: translate(-50%, -50%) scale3d(0.5, 0.4, 1);
                    border-radius: 5px;
                    padding: 30px;
                    animation: 0.1s ease-out 0s 1 normal forwards running celebrateShow;">
            <button id="ext-login-dialog-close" style="position: absolute;
                        top: 20px;
                        right: 20px;
                        font-size: 32px;
                        color: var(--dark);
                        background-color: transparent;
                        cursor: pointer;
                        opacity: 0.7;
                        border-width: 0px;
                        border-style: initial;
                        border-color: initial;
                        border-image: initial;"
            >
                \xd7
            </button>
            <div style="text-align: center;">
                <em style="display: inline-block;
                        line-height: 96px;
                        margin-top: -86px;
                        margin-bottom: 20px;
                        font-size: 96px;
                        font-style: normal;
                        filter: drop-shadow(rgba(0, 0, 0, 0.4) 0px 0px 5px);">
                    &#x1F60A
                </em>
                <h1 style="font-size: 32px;
                        font-weight: bold;
                        color: rgb(0, 0, 0);
                        margin: 0px 0px 40px;">
                    Start Now!
                </h1>
                <label style="margin-bottom: 40px;
                            font-size: 18px;
                            color: rgb(0, 0, 0);
                            opacity: 0.8;">
                    <b id="ext-login-dialog-countNum" style="font-weight: bold;">
                        
                    </b>
                    Please log in to access the full functionality
                </label>
            </div>
            <div style="margin-top: 30px; text-align: center;">
                <button id="ext-login-dialog-with-google" style="color: var(--dark);
                            border: 2px solid var(--dark);
                            background: linear-gradient(var(--color-light), var(--color));
                            font-size: 12px;
                            text-align: center;
                            padding: 10px 30px;
                            margin: 0;
                            margin-top: 0px;
                            margin-bottom: 2px;
                            position: relative;
                            cursor: pointer;
                            box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 0px;
                            border-radius: var(--border-radius);">
                    <span id="ext-login-dialog-loading-svg" style="display: none;">
                        <svg xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle;" width="16" height="16" viewBox="0 0 24 24"><circle cx="18" cy="12" r="0" fill="currentColor"><animate attributeName="r" begin=".67" calcMode="spline" dur="1.5s" keySplines="0.2 0.2 0.4 0.8;0.2 0.2 0.4 0.8;0.2 0.2 0.4 0.8" repeatCount="indefinite" values="0;2;0;0"/></circle><circle cx="12" cy="12" r="0" fill="currentColor"><animate attributeName="r" begin=".33" calcMode="spline" dur="1.5s" keySplines="0.2 0.2 0.4 0.8;0.2 0.2 0.4 0.8;0.2 0.2 0.4 0.8" repeatCount="indefinite" values="0;2;0;0"/></circle><circle cx="6" cy="12" r="0" fill="currentColor"><animate attributeName="r" begin="0" calcMode="spline" dur="1.5s" keySplines="0.2 0.2 0.4 0.8;0.2 0.2 0.4 0.8;0.2 0.2 0.4 0.8" repeatCount="indefinite" values="0;2;0;0"/></circle></svg>
                    </span>
                    <span>Login with Google</span>
                </button>
            </div>
            <div style="margin-top: 30px;">
                <div style="text-align: center !important; color: #b5b5b5 !important;ont-size: .75rem;"> 
                    Powered by 
                    <a href="https://tiktokprofileextractor.letsfaster.com" target="_blank" 
                        style="color: #0a0a0a !important; cursor: pointer; text-decoration: none; opacity: 0.5;">
                        LetsFaster
                    </a><br>
                </div>
            </div>
        </div>
    </div>
</div>
`;let w=document.getElementById("ext-scan-layer"),k=document.getElementById("ext-finished-dialog"),E=document.getElementById("ext-finished-pro-dialog"),I=document.getElementById("ext-login-dialog");async function L(e){return new Promise(e=>{let t=setInterval(()=>{document.getElementById("ext-scan-layer")?.style?.display!="block"||c?(clearInterval(t),e(!0)):(console.log(s.length),window.scrollBy(0,2e3))},2e3)})}w&&w.parentElement.removeChild(w),k&&k.parentElement.removeChild(k),E&&E.parentElement.removeChild(E),I&&I.parentElement.removeChild(I),document.body.appendChild(f),document.body.appendChild(h),document.body.appendChild(y),document.body.appendChild(v),document.getElementById("ext-finished-dialog-close").addEventListener("click",function(){document.getElementById("ext-finished-dialog").style.display="none",z({"ext-isDownloadClicked":!1})}),document.getElementById("ext-finished-pro-dialog-close").addEventListener("click",function(){document.getElementById("ext-finished-pro-dialog").style.display="none",z({"ext-isDownloadClicked":!1})}),document.getElementById("ext-login-dialog-close").addEventListener("click",function(){document.getElementById("ext-login-dialog").style.display="none",document.getElementById("ext-login-dialog-loading-svg").style.display="none",document.getElementById("ext-login-dialog-with-google").style.opacity="1",document.getElementById("ext-login-dialog-with-google").disabled=!1,document.getElementById("ext-login-dialog-with-google").style.cursor="pointer",document.querySelector("button.ext-entry-button").classList.toggle("extBtnDisable"),document.querySelector("button.ext-entry-button").removeAttribute("disabled")}),document.getElementById("ext-finished-dialog-download-xls").addEventListener("click",function(){try{chrome.runtime.sendMessage({name:"downlaodListings",body:{allListings:s,fileType:"xls"}})}catch(e){console.error("download csv error:",e)}}),document.getElementById("ext-finished-dialog-download-csv").addEventListener("click",function(){try{chrome.runtime.sendMessage({name:"downlaodListings",body:{allListings:s,fileType:"csv"}})}catch(e){console.error("download csv error:",e)}}),document.getElementById("ext-finished-pro-dialog-download-xls").addEventListener("click",function(){try{chrome.runtime.sendMessage({name:"downlaodListings",body:{allListings:s,fileType:"xls"}})}catch(e){console.error("download csv error:",e)}}),document.getElementById("ext-finished-pro-dialog-download-csv").addEventListener("click",function(){try{chrome.runtime.sendMessage({name:"downlaodListings",body:{allListings:s,fileType:"csv"}})}catch(e){console.error("download csv error:",e)}}),document.getElementById("ext-login-dialog-with-google").addEventListener("click",function(){chrome.runtime.sendMessage({from:"popup",action:"loginWithGoogle",data:{}}),document.getElementById("ext-login-dialog-loading-svg").style.display="inline",document.getElementById("ext-login-dialog-with-google").style.opacity="0.4",document.getElementById("ext-login-dialog-with-google").disabled=!0,document.getElementById("ext-login-dialog-with-google").style.cursor="not-allowed"}),document.getElementById("ext-finished-dialog-upgrade").addEventListener("click",function(){chrome.runtime.sendMessage({from:"inject",action:"generatePayUrl",data:{}})}),setInterval(async function(){let e=document?.querySelector('div[data-e2e="user-more"]');if(!e)return;let t=document?.querySelector("button.ext-entry-button"),o=document.createElement("div");o.style.marginTop="-5px",o.innerHTML=`<div style="text-align: center;">
            <!-- TODO -->
            <button class="ext-entry-button" style="">
                <span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" style="vertical-align: middle;"><g fill="none"><path d="M24 0v24H0V0zM12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035c-.01-.004-.019-.001-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427c-.002-.01-.009-.017-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093c.012.004.023 0 .029-.008l.004-.014l-.034-.614c-.003-.012-.01-.02-.02-.022m-.715.002a.023.023 0 0 0-.027.006l-.006.014l-.034.614c0 .012.007.02.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M20 14.5a1.5 1.5 0 0 1 1.5 1.5v4a2.5 2.5 0 0 1-2.5 2.5H5A2.5 2.5 0 0 1 2.5 20v-4a1.5 1.5 0 0 1 3 0v3.5h13V16a1.5 1.5 0 0 1 1.5-1.5m-8-13A1.5 1.5 0 0 1 13.5 3v9.036l1.682-1.682a1.5 1.5 0 0 1 2.121 2.12l-4.066 4.067a1.75 1.75 0 0 1-2.474 0l-4.066-4.066a1.5 1.5 0 0 1 2.121-2.121l1.682 1.682V3A1.5 1.5 0 0 1 12 1.5"/></g></svg>       
                </span>
                <span class="ext-entry-button-text">Extract Profile</span>
            </button>
        </div>
        `,o.addEventListener("click",async function(){if(this.querySelector("button.ext-entry-button").classList.toggle("extBtnDisable"),this.querySelector("button.ext-entry-button").setAttribute("disabled","true"),i=this,!g&&!(n=await l()).user){document.getElementById("ext-login-dialog").style.display="block";return}g=!1,document.getElementById("ext-scan-layer-count").innerText="scraping...",document.getElementById("ext-finished-dialog-countNum").innerText="0",document.getElementById("ext-finished-pro-dialog-countNum").innerText="0",document.getElementById("ext-scan-layer").style.display="block",await C("ext-isDownloadClicked")||(await z({"ext-isDownloadClicked":!0}),location.reload()),await r(1e3);let e=this.querySelector("button.ext-entry-button");function t(){document.hasFocus()&&s.length===t.previousLength?(c=!0,clearInterval(o)):(c=!1,t.previousLength=s.length)}document.getElementById("ext-scan-layer-stop-btn").addEventListener("click",function(){a(e)}),chrome.runtime.sendMessage({from:"popup",action:"startScrapeListings",data:{tabId:"",taskId:location.href,tiktokListingInfo:s,isPro:!1,page:1}}),await r(1e3),t.previousLength=0;let o=setInterval(t,1e4);function a(e){z({"ext-isDownloadClicked":!1}),document.getElementById("ext-scan-layer").style.display="none",e.classList.remove("extBtnDisable"),e.removeAttribute("disabled"),n.isPro?document.getElementById("ext-finished-pro-dialog").style.display="block":document.getElementById("ext-finished-dialog").style.display="block",document.querySelector('div[aria-label="Close"]')?.click(),chrome.runtime.sendMessage({from:"popup",action:"stopScrapeListings",data:{tabId:"",taskId:location.href,tiktokListingInfo:""}})}function r(e){return new Promise(t=>setTimeout(t,e))}async function l(){let e=0,t={user:void 0,isPro:!1},o=!1;for(chrome.runtime.sendMessage({from:"inject",action:"getLoginStatus",data:{}}),chrome.runtime.onMessage.addListener(function(e,n,i){if("background"===e.from&&"sendLoginStatus"===e.action)return o=!0,t.user=e.data.user,t.isPro=e.data.isPro,i(),!0});;){if(e++,o||e>100)return t;await r(50)}}await L(e)&&a(e)}),t||(e.parentElement.insertBefore(o,e.nextSibling),await C("ext-isDownloadClicked")&&(document.getElementById("ext-scan-layer-count").innerText="scraping...",document.getElementById("ext-finished-dialog-countNum").innerText="0",document.getElementById("ext-finished-pro-dialog-countNum").innerText="0",document.getElementById("ext-scan-layer").style.display="block",o.click()))},1e3);var B=[];function T(){for(;B.length>0;){var e=B.shift();"background"===e.from&&"currentTask"===e.action?!n.isPro&&parseInt(document.getElementById("ext-finished-dialog-countNum").innerText)<=e.data.currentTask.listingData.listingList.length?(document.getElementById("ext-scan-layer-count").innerText="+"+e.data.currentTask.listingData.listingList.length+u,document.getElementById("ext-finished-dialog-countNum").innerText=e.data.currentTask.listingData.listingList.length,document.getElementById("ext-finished-dialog-download-xls").innerText="FREE Download As XLS("+(e.data.currentTask.listingData.listingList.length>30?30:e.data.currentTask.listingData.listingList.length)+")",document.getElementById("ext-finished-dialog-download-csv").innerText="FREE Download As CSV("+(e.data.currentTask.listingData.listingList.length>30?30:e.data.currentTask.listingData.listingList.length)+")",s=e.data.currentTask.listingData.listingList):n.isPro&&parseInt(document.getElementById("ext-finished-pro-dialog-countNum").innerText)<=e.data.currentTask.listingData.listingList.length&&(document.getElementById("ext-scan-layer-count").innerText="+"+e.data.currentTask.listingData.listingList.length+u,document.getElementById("ext-finished-pro-dialog-countNum").innerText=e.data.currentTask.listingData.listingList.length,document.getElementById("ext-finished-pro-dialog-download-xls").innerText="Download As XLS("+e.data.currentTask.listingData.listingList.length+")",document.getElementById("ext-finished-pro-dialog-download-csv").innerText="Download As CSV("+e.data.currentTask.listingData.listingList.length+")",s=e.data.currentTask.listingData.listingList):"background"===e.from&&"googleLoginSuccess"===e.action?"none"!==document.getElementById("ext-login-dialog").style.display&&(document.getElementById("ext-login-dialog-close").click(),g=!0,i.click()):"background"===e.from&&"generatePayUrlSuccess"===e.action&&window.open(e.data.payUrl)}}function C(e){return new Promise((t,o)=>{chrome.storage.local.get(e,n=>{chrome.runtime.lastError?o(chrome.runtime.lastError):t(n[e])})})}function z(e){return new Promise((t,o)=>{chrome.storage.local.set(e,()=>{chrome.runtime.lastError?o(chrome.runtime.lastError):t()})})}chrome.runtime.onMessage.addListener((e,t,o)=>{B.push(e),document.hasFocus()&&T(),o()}),window.addEventListener("focus",function(){T()}),chrome.runtime.onMessage.addListener(e=>{"ajaxInterceptor"===e.type&&"content"===e.to&&postMessage({...e,to:"pageScript"})}),window.addEventListener("pageScript",function(e){if(chrome.runtime.sendMessage({type:"ajaxInterceptor",to:"popup",data:e.detail}),0===s.length){let t=e?.detail?.data;t?.itemList?.forEach(e=>{let t={author_id:e?.author?.id,author_avatarThumb:e?.author?.avatarThumb,author_nickname:e?.author?.nickname,author_uniqueId:e?.author?.uniqueId,author_verified:e?.author?.verified,author_signature:e?.author?.signature,video_id:e?.video?.id,video_cover:e?.video?.cover,video_url:"https://www.tiktok.com/@"+e?.author?.uniqueId+"/video/"+e?.video?.id,video_duration:e?.video?.duration,video_ratio:e?.video?.ratio,video_createtime:function(e){let t=new Date(1e3*e),o=t.getFullYear(),n=("0"+(t.getMonth()+1)).slice(-2),i=("0"+t.getDate()).slice(-2),a=("0"+t.getHours()).slice(-2),r=("0"+t.getMinutes()).slice(-2),l=("0"+t.getSeconds()).slice(-2),d=`${o}-${n}-${i} ${a}:${r}:${l}`;return d}(e?.createTime),video_desc:e?.desc,video_collectCount:e?.stats?.collectCount,video_commentCount:e?.stats?.commentCount,video_diggCount:e?.stats?.diggCount,video_playCount:e?.stats?.playCount,video_shareCount:e?.stats?.shareCount,video_isPinnedItem:e?.isPinnedItem,music_id:e?.music?.id,music_title:e?.music?.title,music_coverThumb:e?.music?.coverThumb,music_duration:e?.music?.duration,music_authorName:e?.music?.authorName,originSearchUrl:location.href};s.push(t)})}},!1)},{"url:~pageScripts/main":"kQpXN","@parcel/transformer-js/src/esmodule-helpers.js":"2Hwfy"}],kQpXN:[function(e,t,o){t.exports=e("ccb2bb6900470edb").getBundleURL("90vTI")+e("d5026bea8c818979").resolve("cNahO")},{ccb2bb6900470edb:"lDqJ4",d5026bea8c818979:"2PZ3M"}],lDqJ4:[function(e,t,o){var n={};function i(e){return(""+e).replace(/^((?:https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/.+)\/[^/]+$/,"$1")+"/"}o.getBundleURL=function(e){var t=n[e];return t||(t=function(){try{throw Error()}catch(t){var e=(""+t.stack).match(/(https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/[^)\n]+/g);if(e)return i(e[2])}return"/"}(),n[e]=t),t},o.getBaseURL=i,o.getOrigin=function(e){var t=(""+e).match(/(https?|file|ftp|(chrome|moz|safari-web)-extension):\/\/[^/]+/);if(!t)throw Error("Origin not found");return t[0]}},{}],"2Hwfy":[function(e,t,o){o.interopDefault=function(e){return e&&e.__esModule?e:{default:e}},o.defineInteropFlag=function(e){Object.defineProperty(e,"__esModule",{value:!0})},o.exportAll=function(e,t){return Object.keys(e).forEach(function(o){"default"===o||"__esModule"===o||t.hasOwnProperty(o)||Object.defineProperty(t,o,{enumerable:!0,get:function(){return e[o]}})}),t},o.export=function(e,t,o){Object.defineProperty(e,t,{enumerable:!0,get:o})}},{}]},["jeyoU","3gkI2"],"3gkI2","parcelRequire08c6"),globalThis.define=t;