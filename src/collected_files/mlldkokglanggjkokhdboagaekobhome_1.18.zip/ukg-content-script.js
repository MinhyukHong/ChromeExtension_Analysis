function extractApplicationIdFromCurrentURL() {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get("candidateId");
}

function injectButton() {
  let actionsContainer = document.querySelector(".application-actions");

  // Check if currentApplicationId is different from the one in storage
  if (actionsContainer) {
    let columns = actionsContainer.querySelectorAll(".column.col-md-24");
    columns.forEach((column) => {
      // Check if the button already exists
      if (!column.querySelector("#candidate-fyi-open-side-panel")) {
        let newButton = document.createElement("button");
        newButton.innerText = "Schedule in candidate.fyi";
        newButton.className = "btn btn-primary";
        newButton.id = "candidate-fyi-open-side-panel";
        newButton.href = "#";

        column.appendChild(newButton);

        newButton.addEventListener("click", function (e) {
          e.preventDefault();
          const currentApplicationId = extractApplicationIdFromCurrentURL();
          if (currentApplicationId) {
            chrome.runtime.sendMessage({
              type: "openSidePanel",
              isCandidateId: true,
              applicationId: currentApplicationId,
            });
          } else {
            console.error("No application ID found in URL");
          }
        });
      }
    });
  } else {
    console.error("No actions container found");
  }
}

function checkAndInjectButton() {
  // This function checks if the button has already been injected
  if (!document.getElementById("candidate-fyi-open-side-panel")) {
    injectButton(); // Call injectButton if the custom button does not exist
  }
}

// Setup the MutationObserver to monitor changes in the DOM
const observer = new MutationObserver((mutations) => {
  checkAndInjectButton();
});

// Define what element should be observed by the observer and what types of mutations trigger the callback
observer.observe(document.body, {
  childList: true, // Observe direct children additions or removals
  subtree: true, // Observe all descendants (not just children)
  attributes: false, // Set to `true` if you also want to observe attribute changes
});

// It's also wise to ensure the initial check on page load
checkAndInjectButton();
