// Function to extract the people ID from the current URL
function extractApplicationIdFromCurrentURL() {
  const url = new URL(window.location.href);
  const urlParams = new URLSearchParams(url.search);

  // First, attempt to get the application ID from the URL parameters
  const appIdFromParams = urlParams.get("application_id");
  if (appIdFromParams) {
    return appIdFromParams;
  }

  // If not found in URL parameters, look for it in the URL path
  const pathSegments = url.pathname
    .split("/")
    .filter((segment) => segment.trim() !== "");
  const appIndex = pathSegments.indexOf("applications");
  if (appIndex !== -1 && pathSegments.length > appIndex + 1) {
    return pathSegments[appIndex + 1];
  } else {
    console.error("Application ID not found in URL path.");
    return null;
  }
}

function injectButton() {
  // Greenhouse keeps changing their UI so this is how we are handling...
  let rejectButtons = document.querySelectorAll(
    '[data-provides="open-reject-modal"]'
  );
  let controlsContainers = document.querySelectorAll(
    '[data-provides="move-stage-modal"]'
  );

  const candidateButtonCount = document.querySelectorAll(
    "#candidate-fyi-open-side-panel"
  );
  if (
    rejectButtons.length > 0 &&
    controlsContainers.length > 0 &&
    candidateButtonCount.length === 2
  ) {
    return;
  } else if (candidateButtonCount.length === 1) {
    return;
  }

  let rejectButton = document.getElementById("reject_button");
  let controlsContainer = document.getElementById("advance_reject_controls");

  if (rejectButtons.length > 0 && controlsContainers.length > 0) {
    // Process each controls container
    controlsContainers.forEach((container) => {
      // Create new button
      let button = document.createElement("button");
      button.innerText = "Schedule in candidate.fyi";
      button.id = "candidate-fyi-open-side-panel";
      button.className = "large-button hover-button";
      button.style.marginLeft = "8px";

      // Add click event listener
      button.addEventListener("click", function () {
        const currentApplicationId = extractApplicationIdFromCurrentURL();
        if (currentApplicationId) {
          chrome.runtime.sendMessage({
            type: "openSidePanel",
            applicationId: currentApplicationId,
          });
        } else {
          console.warn("No application ID found in URL");
        }
      });

      // Insert the button next to the container in its parent element
      container.parentNode.insertBefore(button, container.nextSibling);
    });
  } else if (rejectButton && controlsContainer) {
    // Clone the button, its classes, and styles
    let button = document.createElement("button");
    button.innerText = "Schedule in candidate.fyi";
    button.id = "candidate-fyi-open-side-panel";
    button.className = "large-button hover-button";

    // Append the new button next to the reject button
    controlsContainer.insertBefore(button, rejectButton.nextSibling);

    // Add click event to update and send the application ID
    button.addEventListener("click", function () {
      const currentApplicationId = extractApplicationIdFromCurrentURL();
      if (currentApplicationId) {
        chrome.runtime.sendMessage({
          type: "openSidePanel",
          applicationId: currentApplicationId,
        });
      } else {
        console.warn("No application ID found in URL");
      }
    });
  } else {
    // If reject button or container is not found, use the alternative logic
    let buttons = document.querySelectorAll("button");
    let moveStageButton = Array.from(buttons).find((button) =>
      button.innerText.includes("Move Stage")
    );
    if (moveStageButton) {
      let outerContainer = moveStageButton.closest(".MuiGrid-root");
      if (outerContainer) {
        let newContainer = outerContainer.cloneNode(true);
        let newButton = newContainer.querySelector("button");
        newButton.innerText = "Schedule in candidate.fyi";
        newButton.id = "candidate-fyi-open-side-panel";
        newButton.className = moveStageButton.className;

        newButton.addEventListener("click", function () {
          const currentApplicationId = extractApplicationIdFromCurrentURL();
          if (currentApplicationId) {
            chrome.runtime.sendMessage({
              type: "openSidePanel",
              applicationId: currentApplicationId,
            });
          } else {
            console.error("No application ID found in URL");
          }
        });

        outerContainer.parentNode.insertBefore(
          newContainer,
          outerContainer.nextSibling
        );
      }
    } else {
      console.warn(
        "Neither reject button nor Move Stage button found. No action taken."
      );
    }
  }
}

// Inject the button when the DOM is fully loaded
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", injectButton);
} else {
  // `DOMContentLoaded` already fired
  injectButton();
}

function checkAndInjectButton() {
  // This function checks if the button has already been injected
  injectButton(); // Call injectButton if the custom button does not exist
}

// Setup the MutationObserver to monitor changes in the DOM
const observer = new MutationObserver((mutations) => {
  checkAndInjectButton();
});

// Define what element should be observed by the observer and what types of mutations trigger the callback
observer.observe(document.body, {
  childList: true, // Observe direct children additions or removals
  subtree: true, // Observe all descendants (not just children)
  attributes: false, // Set to `true` if you also want to observe attribute changes
});

// It's also wise to ensure the initial check on page load
checkAndInjectButton();

// Workaround: Capture mousedown event
window.addEventListener(
  "mousedown",
  function (event) {
    if (event.target.id === "candidate-fyi-open-side-panel") {
      const currentApplicationId = extractApplicationIdFromCurrentURL();
      if (currentApplicationId) {
        chrome.runtime.sendMessage({
          type: "openSidePanel",
          applicationId: currentApplicationId,
        });
      } else {
        console.warn("No application ID found in URL");
      }
    }
  },
  true
); // Use capture phase
