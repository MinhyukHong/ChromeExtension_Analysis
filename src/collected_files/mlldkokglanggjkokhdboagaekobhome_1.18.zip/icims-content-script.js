const DEBUG = true;

const debug = (...args) => {
  if (DEBUG) console.log("CFYI >>", ...args);
};

debug("Content script loaded");

let isOpen = false;
let currentCandidateId = null;

function extractApplicationIdFromIframe(iframe) {
  const profileCardElement = iframe.contentDocument.querySelector(
    '[class$="IcimsProfileCard-captionText"]'
  );
  if (profileCardElement) {
    return profileCardElement.textContent.trim();
  }
  return null;
}

function injectButton(iframe) {
  const button = iframe.contentDocument.createElement("button");
  button.id = "candidate-fyi-open-side-panel";
  button.innerHTML = "Schedule in candidate.fyi";
  button.style.backgroundColor = "#0A2647";
  button.style.color = "white";
  button.style.border = "none";
  button.style.borderRadius = "4px";
  button.style.padding = "8px 16px";
  button.style.fontSize = "14px";
  button.style.fontWeight = "600";
  button.style.cursor = "pointer";
  button.style.height = "fit-content";
  button.style.width = "fit-content";
  button.style.boxShadow =
    "0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)";

  button.addEventListener(
    "mouseover",
    () => (button.style.backgroundColor = "#0D3A6E")
  );
  button.addEventListener(
    "mouseout",
    () => (button.style.backgroundColor = "#0A2647")
  );

  button.addEventListener("click", (e) => {
    e.preventDefault();
    const applicationId = extractApplicationIdFromIframe(iframe);
    if (applicationId) {
      chrome.runtime.sendMessage({
        type: "openSidePanel",
        isCandidateId: true,
        applicationId: applicationId,
      });
    }
  });

  return button;
}

function checkAndInjectButtonIfNeeded() {
  const mainBodyIframe = document.getElementById("main_body");
  if (!mainBodyIframe?.contentDocument) {
    debug("Main body iframe not found");
    return;
  }

  const targetIframe = mainBodyIframe.contentDocument.getElementById(
    "candidate-profile-spa"
  );
  if (!targetIframe?.contentDocument) {
    debug("Target iframe not found");
    if (isOpen) {
      debug("Closing side panel");
      isOpen = false;
      chrome.runtime.sendMessage({
        type: "closeSidePanel",
      });
    }
    return;
  }

  const existingButton = targetIframe.contentDocument.getElementById(
    "candidate-fyi-open-side-panel"
  );
  const candidateInfoContainer = targetIframe.contentDocument.querySelector(
    '[class*="candidateInfoContainer"]'
  );

  if (!candidateInfoContainer) {
    debug("Candidate info container not found");
    if (isOpen) {
      debug("Closing side panel");
      isOpen = false;
      chrome.runtime.sendMessage({
        type: "closeSidePanel",
      });
    }
    return;
  }

  if (existingButton) {
    debug("Button already exists");
    return;
  } else if (isOpen) {
    isOpen = false;
    debug("Closing side panel");
    chrome.runtime.sendMessage({
      type: "closeSidePanel",
    });
  }

  debug("Injecting button");
  isOpen = true;
  const wrapper = document.createElement("div");
  wrapper.style.padding = "16px";
  wrapper.appendChild(injectButton(targetIframe));
  candidateInfoContainer.appendChild(wrapper);
}

// Check every second
setInterval(checkAndInjectButtonIfNeeded, 1000);

debug("Initial setup complete");
