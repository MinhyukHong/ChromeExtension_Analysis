// Function to extract the application ID from the current URL for Lever
function extractApplicationIdFromCurrentURL() {
  const urlParts = window.location.pathname.split("/");
  const applicationIdIndex =
    urlParts.findIndex((part) => part === "candidates") + 1;
  return urlParts[applicationIdIndex];
}

function checkAndUpdateApplicationId(currentApplicationId) {
  chrome.runtime.sendMessage({
    type: "setApplicationId",
    applicationId: currentApplicationId,
  });
}

// Call this function whenever you need to check and update the application ID

function injectButton() {
  let actionsContainer = document.querySelector(".profile-call-to-actions");
  // check if currentApplicationId is different from the one in storage
  if (
    actionsContainer &&
    !document.getElementById("candidate-fyi-open-side-panel")
  ) {
    let button = document.createElement("a");
    button.innerText = "Schedule in candidate.fyi";
    button.className = "button button-blue-light width-full mb1";
    button.id = "candidate-fyi-open-side-panel";
    button.href = "#";

    actionsContainer.appendChild(button);

    button.addEventListener("click", function (e) {
      e.preventDefault();
      const currentApplicationId = extractApplicationIdFromCurrentURL();
      if (currentApplicationId) {
        chrome.runtime.sendMessage({
          type: "openSidePanel",
          applicationId: currentApplicationId,
        });
      } else {
        console.error("No application ID found in URL");
      }
    });
  } else if (!actionsContainer) {
    console.error("No actions container found");
  }
}

// Function to handle URL changes
function handleURLChange() {
  // Check if the current URL matches the pattern
  if (urlPattern.test(window.location.href)) {
    const currentApplicationId = extractApplicationIdFromCurrentURL();
    if (currentApplicationId) {
      checkAndUpdateApplicationId(currentApplicationId);
      injectButton(); // Call this to setup or update UI
    }
  }
}

// Define URL pattern
const urlPattern =
  /^https:\/\/hire\.lever\.co\/candidates\/[a-zA-Z0-9-]+\/?(?:\?.*)?$/;

// MutationObserver to watch for DOM changes
const observer = new MutationObserver((mutations) => {
  handleURLChange();
});

observer.observe(document.body, { childList: true, subtree: true });
