// Function to update iframe src with new application ID
function updateIframeSrc(applicationId) {
  const iframe = document.getElementById("schedulingIframe");
  const newSrc = `https://app.candidate.fyi/scheduling-extension?&applicationId=${applicationId}`;

  // Update iframe src only if it has changed
  if (iframe.src !== newSrc) {
    iframe.src = newSrc;
  }
}

// Function to update iframe for a specific tab
function updateIframeForTab(tabId) {
  let tabKey = `applicationId-${tabId}`;

  chrome.storage.session.get([tabKey], (data) => {
    if (data[tabKey]) {
      updateIframeSrc(data[tabKey]);
    }
  });
}

// Listen for changes in the storage
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "session") {
    for (let [key, { newValue }] of Object.entries(changes)) {
      if (key.startsWith("applicationId-")) {
        let tabId = key.split("-")[1];
        chrome.tabs.get(parseInt(tabId), (tab) => {
          if (chrome.runtime.lastError) {
            console.error(
              `Error finding tab: ${chrome.runtime.lastError.message}`
            );
          } else if (tab && tab.active) {
            updateIframeSrc(newValue);
          }
        });
      }
    }
  }
});

// Update iframe when a tab is activated
chrome.tabs.onActivated.addListener((activeInfo) => {
  updateIframeForTab(activeInfo.tabId);
});

// Update iframe when a tab URL is updated
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    updateIframeForTab(tabId);
  }
});

// Initial load for the current active tab
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs.length === 0) return; // Exit if no active tab is found
  updateIframeForTab(tabs[0].id);
});
