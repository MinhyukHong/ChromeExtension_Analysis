// Function to extract the application ID from the current URL
function extractApplicationIdFromCurrentURL() {
  const url = new URL(window.location.href);
  const pathSegments = url.pathname.split("/");
  const appIndex = pathSegments.indexOf("applications");
  if (appIndex !== -1 && pathSegments.length > appIndex + 1) {
    return pathSegments[appIndex + 1];
  }
  console.error("Application ID not found in URL path.");
  return null;
}

function injectButton() {
  const existingButton = document.getElementById(
    "candidate-fyi-open-side-panel"
  );
  const currentApplicationId = extractApplicationIdFromCurrentURL();
  console.log("currentApplicationId", currentApplicationId);
  if (!currentApplicationId && existingButton) {
    observer.disconnect();
    existingButton.remove();
    observer.observe(document.body, { childList: true, subtree: true });
    return;
  }

  if (!currentApplicationId) return;

  const actionsContainer = document.querySelector('[class*="ia_actions"]');
  if (!actionsContainer || existingButton) return;

  const buttons = actionsContainer.querySelectorAll("button");
  const lastButton = buttons[buttons.length - 1];
  if (!lastButton) return;

  const button = document.createElement("button");
  button.innerText = "Schedule in candidate.fyi";
  button.id = "candidate-fyi-open-side-panel";
  button.className = lastButton.className;

  button.addEventListener("click", function () {
    console.log("currentApplicationId", currentApplicationId);
    chrome.runtime.sendMessage({
      type: "openSidePanel",
      applicationId: currentApplicationId,
    });
  });

  observer.disconnect();
  lastButton.parentNode.insertBefore(button, lastButton.nextSibling);
  observer.observe(document.body, { childList: true, subtree: true });
}

// Setup URL change detection using MutationObserver
const observer = new MutationObserver(() => {
  injectButton();
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
});

// Initial injection
injectButton();
