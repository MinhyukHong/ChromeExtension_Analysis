const DEBUG = true;

const debug = (...args) => {
  if (DEBUG) console.log("CFYI >>", ...args);
};

debug("Content script loaded");

let isOpen = false;

function getCurrentCandidateId() {
  const headerElement = document.querySelector(".kioskPanelSubHeader");
  if (!headerElement) return null;

  const match = headerElement.textContent.match(/\((\d+)\)/);
  return match ? match[1] : null;
}

function injectButton() {
  const button = document.createElement("button");
  button.id = "candidate-fyi-open-side-panel";
  button.innerHTML = "Schedule in candidate.fyi";

  // Copy styles from the Job Application Actions button
  const actionButton = document.querySelector(
    '[title="Job Application Actions"]'
  );
  if (actionButton) {
    // Apply the same classes
    button.className = actionButton.className;
    // Ensure our button text is styled the same way
    button.style.cssText = window.getComputedStyle(actionButton).cssText;
  }

  button.addEventListener("click", (e) => {
    e.preventDefault();
    // TODO: Extract candidateId from the dom
    const candidateId = getCurrentCandidateId();
    if (!candidateId) {
      debug("No candidate ID found");
      return;
    }
    chrome.runtime.sendMessage({
      type: "openSidePanel",
      isCandidateId: true,
      applicationId: candidateId,
    });
  });

  return button;
}

function checkAndInjectButtonIfNeeded() {
  const actionsTitleElement = document.querySelector(
    '[title="Job Application Actions"]'
  );
  const existingButton = document.getElementById(
    "candidate-fyi-open-side-panel"
  );

  if (!actionsTitleElement) {
    if (isOpen) {
      debug("Actions element not found, closing side panel");
      isOpen = false;
      chrome.runtime.sendMessage({
        type: "closeSidePanel",
      });
    }
    return;
  }

  if (existingButton) {
    debug("Button already exists");
    return;
  }
  // kioskPanelSubHeader

  debug("Injecting button");
  isOpen = true;
  const wrapper = document.createElement("td");
  wrapper.appendChild(injectButton());
  actionsTitleElement.parentElement.insertAdjacentElement("afterend", wrapper);
}

// Check every second
setInterval(checkAndInjectButtonIfNeeded, 1000);

debug("Initial setup complete");
