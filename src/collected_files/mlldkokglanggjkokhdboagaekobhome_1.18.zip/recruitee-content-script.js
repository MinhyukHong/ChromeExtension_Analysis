// Function to extract the application ID from the current URL for Lever
function extractApplicationIdFromCurrentURL() {
  const url = new URL(window.location.href.replace("/#/", "/"));
  const urlParams = new URLSearchParams(url.search);

  // First, attempt to get the application ID from the URL parameters
  const appIdFromParams = urlParams.get("candidate");
  if (appIdFromParams) {
    return appIdFromParams;
  }
}

function checkAndUpdateApplicationId(currentApplicationId) {
  chrome.runtime.sendMessage({
    type: "setApplicationId",
    applicationId: currentApplicationId,
  });
}

// Call this function whenever you need to check and update the application ID

function injectButton() {
  // Create a MutationObserver to observe changes in the DOM
  const observer = new MutationObserver((mutations, observer) => {
    // Select the container for the "Schedule" button
    let scheduleButtonContainer = document.querySelector(".schedule-button");

    // Check if the container exists and the button is not already injected
    if (
      scheduleButtonContainer &&
      !document.getElementById("candidate-fyi-open-side-panel")
    ) {
      // Create the new button element
      let button = document.createElement("rt-button");
      button.innerText = "Schedule in candidate.fyi";
      button.id = "candidate-fyi-open-side-panel";
      button.href = "#";

      // Copy classes from the "Schedule" button
      button.className = scheduleButtonContainer.className;

      // Insert the new button next to the "Schedule" button
      scheduleButtonContainer.parentNode.insertBefore(
        button,
        scheduleButtonContainer
      );

      // Add click event listener to the new button
      button.addEventListener("click", function (e) {
        e.preventDefault();
        const currentApplicationId = extractApplicationIdFromCurrentURL();
        if (currentApplicationId) {
          chrome.runtime.sendMessage({
            type: "openSidePanel",
            isCandidateId: true,
            applicationId: currentApplicationId,
          });
        } else {
          console.error("No application ID found in URL");
        }
      });

      // Once the button is injected, stop observing
      observer.disconnect();
    }
  });

  // Start observing the document body for changes
  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
}

// Call the function to inject the button
injectButton();

const urlPattern = /^https:\/\/app\.recruitee\.com\/.*[?&]candidate=\d+.*$/;

// Function to handle URL changes
function handleURLChange() {
  // Check if the current URL matches the pattern
  if (urlPattern.test(window.location.href)) {
    const currentApplicationId = extractApplicationIdFromCurrentURL();
    if (currentApplicationId) {
      checkAndUpdateApplicationId(currentApplicationId);
      injectButton(); // Call this to setup or update UI
    }
  }
}

// MutationObserver to watch for DOM changes
const observer = new MutationObserver((mutations) => {
  handleURLChange();
});

observer.observe(document.body, { childList: true, subtree: true });
