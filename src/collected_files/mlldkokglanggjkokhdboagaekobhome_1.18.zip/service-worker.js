const GREENHOUSE_ORIGIN = "greenhouse.io/people/";
const LEVER_ORIGIN = "hire.lever.co/candidates/";

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (!tab.url) return;
  const url = new URL(tab.url);
  const recruiteeUrl = new URL(tab.url.replace("/#/", "/"));

  // Check if the URL belongs to Greenhouse or Lever
  const isGreenhouse =
    url.host.includes("greenhouse.io") && url.pathname.startsWith("/people/");
  const isLever =
    url.host.includes("lever.co") && url.pathname.startsWith("/candidates/");
  const isAshby =
    url.host.includes("ashbyhq.com") &&
    url.pathname.includes("applications") &&
    url.pathname.includes("candidates");
  const isRecruitee =
    url.host.includes("recruitee.com") &&
    new URLSearchParams(recruiteeUrl.search).has("candidate");
  const isIcims = url.host.includes("icims.com");
  const isUkg = url.host.includes("ultipro.com");
  const isWorkday = url.host.includes("myworkday.com");
  const isOrc = url.host.includes("oraclecloud.com");

  // Use a tab-specific key for storage
  const tabKey = `applicationId-${tabId}`;

  if (isGreenhouse) {
    // Handle Greenhouse URLs
    const applicationId = extractApplicationIdFromURL(url);

    // Store the application ID with a tab-specific key
    let obj = {};
    obj[tabKey] = applicationId;
    chrome.storage.session.set(obj);

    // Enable the side panel with the correct path
    await enableSidePanel(tabId);
  } else if (isAshby) {
    // Handle Recruitee URLs
    const applicationId = extractApplicationIdFromAshbyURL(url);

    // Store the application ID with a tab-specific key
    let obj = {};
    obj[tabKey] = applicationId;
    chrome.storage.session.set(obj);

    await enableSidePanel(tabId);
  } else if (isLever) {
    // Handle Lever URLs
    const applicationId = extractApplicationIdFromLeverURL(url);

    // Store the application ID with a tab-specific key
    let obj = {};
    obj[tabKey] = applicationId;
    chrome.storage.session.set(obj);

    // Enable the side panel with the correct path
    await enableSidePanel(tabId);
  } else if (isRecruitee) {
    // Handle Recruitee URLs
    const applicationId = extractApplicationIdFromRecruiteeURL(recruiteeUrl);

    // Store the application ID with a tab-specific key
    let obj = {};
    obj[tabKey] = applicationId;
    chrome.storage.session.set(obj);

    // Enable the side panel with the correct path
    await enableSidePanel(tabId);
  } else if (isIcims) {
    // Enable the side panel with the correct path
    await enableSidePanel(tabId);
  } else if (isOrc) {
    // Enable the side panel with the correct path
    await enableSidePanel(tabId);
  } else if (isUkg) {
    // Handle Recruitee URLs
    const applicationId = extractApplicationIdFromUkgURL(url);
    // Store the application ID with a tab-specific key
    let obj = {};
    obj[tabKey] = applicationId;
    chrome.storage.session.set(obj);

    // Enable the side panel with the correct path
    await enableSidePanel(tabId);
  } else if (isWorkday) {
    // Enable the side panel with the correct path
    await enableSidePanel(tabId);
  } else {
    // Disable the side panel for non-Greenhouse and non-Lever tabs
    await chrome.sidePanel.setOptions({
      tabId,
      enabled: false,
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.type === "openSidePanel") {
    (async () => {
      try {
        if (message.applicationId) {
          // Store the application ID with a tab-specific key
          let obj = {};
          obj[`applicationId-${sender.tab.id}`] = message.applicationId;
          chrome.storage.session.set(obj);
        }
        // Open the side panel and set its options
        await chrome.sidePanel.open({ tabId: sender.tab.id });
        if (message.isCandidateId) {
          await chrome.sidePanel.setOptions({
            tabId: sender.tab.id,
            path: "side-panel-candidate.html",
            enabled: true,
          });
        } else {
          await chrome.sidePanel.setOptions({
            tabId: sender.tab.id,
            path: "side-panel.html",
            enabled: true,
          });
        }
      } catch (error) {
        console.error("Error opening side panel:", error);
      }
    })();
  }
});
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.type === "setApplicationId") {
    (async () => {
      try {
        if (message.applicationId) {
          const key = `applicationId-${sender.tab.id}`;

          // Retrieve the existing application ID
          chrome.storage.session.get([key], (data) => {
            if (data[key] !== message.applicationId) {
              // Update the application ID only if it's different
              let obj = {};
              obj[key] = message.applicationId;
              chrome.storage.session.set(obj, () => {
                if (chrome.runtime.lastError) {
                  console.error(
                    "Error setting application ID:",
                    chrome.runtime.lastError
                  );
                }
              });
            }
          });
        }
      } catch (error) {
        console.error("Error handling 'setApplicationId' message:", error);
      }
    })();
  }
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message.type === "closeSidePanel") {
    (async () => {
      try {
        await chrome.sidePanel.setOptions({
          tabId: sender.tab.id,
          enabled: false,
        });
        await chrome.sidePanel.setOptions({
          tabId: sender.tab.id,
          path: "side-panel.html",
          enabled: true,
        });
      } catch (error) {
        console.error("Error closing side panel:", error);
      }
    })();
  }
});

function extractApplicationIdFromURL(url) {
  const urlParams = new URLSearchParams(url.search);

  // First, attempt to get the application ID from the URL parameters
  const appIdFromParams = urlParams.get("application_id");
  if (appIdFromParams) {
    return appIdFromParams;
  }

  // If not found in URL parameters, look for it in the URL path
  const pathSegments = url.pathname
    .split("/")
    .filter((segment) => segment.trim() !== "");
  const appIndex = pathSegments.indexOf("applications");
  if (appIndex !== -1 && pathSegments.length > appIndex + 1) {
    return pathSegments[appIndex + 1];
  } else {
    console.error("Application ID not found in URL path.");
    return null;
  }
}

function extractApplicationIdFromLeverURL(url) {
  const parts = url.pathname.split("/");
  return parts[2]; // applicationId is the third part of the path
}

function extractApplicationIdFromRecruiteeURL(url) {
  const urlParams = new URLSearchParams(url.search);
  return urlParams.get("candidate");
}

function extractApplicationIdFromUkgURL(url) {
  const urlParams = new URLSearchParams(url.search);
  return urlParams.get("candidateId");
}

function extractApplicationIdFromAshbyURL(url) {
  const pathSegments = url.pathname.split("/");
  const appIndex = pathSegments.indexOf("applications");
  if (appIndex !== -1 && pathSegments.length > appIndex + 1) {
    return pathSegments[appIndex + 1];
  }
  console.error("Application ID not found in URL path.");
  return null;
}

async function enableSidePanel(tabId) {
  await chrome.sidePanel.setOptions({
    tabId,
    path: "side-panel.html",
    enabled: true,
  });
}
