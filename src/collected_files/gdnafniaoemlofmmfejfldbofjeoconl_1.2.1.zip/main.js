const ID_KEY = 'agentIdNumber';
const TOKEN = '_THIS_IS_AN_ORIGINAL_TOKEN_FROM_BITAPP_EXTENSION_';
const BITAPP_URL = 'https://login.bitapp.co.il/api/MRHSession/FromExtension';
const HB_URL = 'https://harb.cma.gov.il/'
const sessionUpdatedEventName = 'extension_updated_session';

const button = document.querySelector('button');
const loader = document.querySelector('.loader');
const input = document.querySelector('input');
const idError = document.querySelector('small');
const resStatus = document.querySelector('strong');

const init = async () => {
    chrome.runtime.connect({ name: "popup" });
    input.value = (await chrome.storage.local.get([ID_KEY]))[ID_KEY] || '';
    button.addEventListener('click', onClick);
}

const onClick = e => {
    e.preventDefault();
    resStatus.style.display = 'none';
    if(!input.value)
        idError.innerHTML = '*שדה חובה';
    else if(!validateIdNumber(input.value))
        idError.innerHTML = '*תעודת זהות לא תקינה';
    else {
        idError.innerHTML = '';
        chrome.storage.local.set({ [ID_KEY]: input.value });
        sendMRHSession(input.value);
    }
}

const sendMRHSession = async idNumber => {
    loader.style.display = 'block';
    button.style.display = 'none';
    const MRHSession = await getMRHSession(); 
    if(!MRHSession || (MRHSession.length != 32))
        return setStatus(false, 'אינך מאומת בדפדפן מול הר הביטוח');
    const headers = { token: TOKEN, 'Content-Type': 'application/json' };
    const cookies = await getAllCookies();
    const body = JSON.stringify({ idNumber, cookies });
    fetch(BITAPP_URL, { method: 'POST', headers, body })
        .then(({ ok }) => setStatus(ok))
        .catch(() => setStatus(false));
}

const setStatus = (success, msg) => {
    loader.style.display = 'none';
    button.style.display = 'block';
    resStatus.style.display = 'block';
    resStatus.style.color = success ? 'green' : 'red';
    resStatus.innerHTML = msg || (success ? 'האימות נשלח בהצלחה' : 'משהו השתבש האימות לא התקבל. אנא ודא/י שמספר הזהות נכון, ושאת/ה מאומת/ת בדפדפן מול הר הביטוח');
    if(success)
        chrome.runtime.sendMessage(sessionUpdatedEventName);
}

const getMRHSession = async () => {
    const params = { url: HB_URL, name: 'MRHSession' };
    const cookie = ((await chrome.cookies.get(params))||{}).value;
    return cookie;
}

const getAllCookies = async () => {
    const cookies = await chrome.cookies.getAll({ url: HB_URL });
    const result = {};
    cookies.forEach(({ name, value }) => result[name] = value);
    return result;
}

const validateIdNumber = idNumber => {
    if (idNumber.length > 9 || idNumber.length < 5 || !idNumber.match(/[0-9]+/)) 
        return false;
    idNumber.padStart(9, '0');
    let mone = 0;
    idNumber.split('').map(n => Number(n)).forEach((incNum, i) => {
        incNum *= (i % 2) + 1;
        if (incNum > 9) incNum -= 9;
        mone += incNum;
    });
    return mone % 10 == 0;
}

init();