const bitappUrl = 'https://login.bitapp.co.il/';
const openPopupEventName = 'open_HB_extension_popup';
const sessionUpdatedEventName = 'extension_updated_session';
let isPopupOpen = false;

// Set popup flag if open or not
chrome.runtime.onConnect.addListener(port => {
    if (port.name !== "popup") 
        return;
    isPopupOpen = true;
    port.onDisconnect.addListener(() => isPopupOpen = false);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Listen to open popup event from content.js and open popup in new tab if not already open
    if (message === openPopupEventName && !isPopupOpen) 
        chrome.tabs.create({ url: 'popup.html' });
    // Listen to popup messages and send it to content script 
    else if(message === sessionUpdatedEventName) 
        chrome.tabs.query({ url: [bitappUrl + '*'] }, tabs => 
            tabs.forEach(({ id }) => chrome.tabs.sendMessage(id, sessionUpdatedEventName)));
    sendResponse('done');        
});
