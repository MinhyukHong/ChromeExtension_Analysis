const openPopupEventName = 'open_HB_extension_popup';

// Listen to open popup event from website
window.addEventListener(openPopupEventName, e => 
    chrome.runtime.sendMessage(chrome.runtime.id, openPopupEventName)
        .then(response => window.postMessage(response, '*')));

// Send back to website message from extension
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => 
    window.dispatchEvent(new Event(message)));

