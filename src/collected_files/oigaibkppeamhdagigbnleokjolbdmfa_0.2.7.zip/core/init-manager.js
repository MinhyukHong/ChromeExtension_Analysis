// Initialization Manager

class InitializationManager {
    constructor() {
        this.components = new Map();
        this.initialized = new Set();
        this.isInitializing = false;
    }

    // Register a component with its initialization function and dependencies
    register(name, initFn, dependencies = []) {
        console.debug(`[Init-Manager] Registering component: ${name}`);
        if (this.components.has(name)) {
            console.warn(`[Init-Manager] Component ${name} already registered`);
            return;
        }

        this.components.set(name, {
            name,
            initFn,
            dependencies,
            status: 'pending'
        });
    }

    // Check if all dependencies of a component are initialized
    areDependenciesInitialized(dependencies) {
        return dependencies.every(dep => this.initialized.has(dep));
    }

    // Initialize a specific component
    async initializeComponent(name) {
        const component = this.components.get(name);
        if (!component) {
            console.error(`[Init-Manager] Component ${name} not found`);
            return false;
        }

        // Skip if already initialized
        if (this.initialized.has(name)) {
            return true;
        }

        // Check dependencies
        if (!this.areDependenciesInitialized(component.dependencies)) {
            console.debug(`[Init-Manager] Dependencies not ready for ${name}`);
            return false;
        }

        try {
            console.debug(`[Init-Manager] Initializing component: ${name}`);
            component.status = 'initializing';
            await component.initFn();
            component.status = 'initialized';
            this.initialized.add(name);
            console.debug(`[Init-Manager] Component ${name} initialized successfully`);
            return true;
        } catch (error) {
            console.error(`[Init-Manager] Failed to initialize ${name}:`, error);
            component.status = 'error';
            component.error = error;
            return false;
        }
    }

    // Initialize all components in dependency order
    async initialize() {
        if (this.isInitializing) {
            console.warn('[Init-Manager] Initialization already in progress');
            return;
        }

        this.isInitializing = true;
        console.debug('[Init-Manager] Starting initialization sequence');

        try {
            let progress = true;
            while (progress) {
                progress = false;
                for (const [name, component] of this.components) {
                    if (!this.initialized.has(name) && 
                        component.status !== 'error' && 
                        this.areDependenciesInitialized(component.dependencies)) {
                        
                        const success = await this.initializeComponent(name);
                        if (success) {
                            progress = true;
                        }
                    }
                }
            }

            // Check for uninitialized components
            const uninitializedComponents = Array.from(this.components.entries())
                .filter(([name]) => !this.initialized.has(name));

            if (uninitializedComponents.length > 0) {
                console.error('[Init-Manager] Some components failed to initialize:', 
                    uninitializedComponents.map(([name, component]) => ({
                        name,
                        status: component.status,
                        error: component.error
                    }))
                );
            } else {
                console.debug('[Init-Manager] All components initialized successfully');
            }
        } catch (error) {
            console.error('[Init-Manager] Initialization sequence failed:', error);
        } finally {
            this.isInitializing = false;
        }
    }

    // Get initialization status
    getStatus() {
        return {
            initialized: Array.from(this.initialized),
            pending: Array.from(this.components.entries())
                .filter(([name]) => !this.initialized.has(name))
                .map(([name, component]) => ({
                    name,
                    status: component.status,
                    error: component.error
                }))
        };
    }
}

// Create and export singleton instance
const initManager = new InitializationManager();
window.initManager = initManager;

// Start initialization when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => initManager.initialize());
} else {
    initManager.initialize();
}
