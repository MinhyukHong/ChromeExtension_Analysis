class QuickPromptManagerUI {
    constructor() {
        this.quickprompts = [];
        this.editingQuickPrompt = null;
        this.quickpromptToDelete = null;
        this.draggedItem = null;
        this.draggedIndex = null;
        this._fileInput = null;
        this.settings = {
            celebration: true,
            sound: true
        };
        this.initialize();
    }

    async initialize() {
        try {
            // Initialize elements first
            const elementsInitialized = this.initializeElements();
            if (!elementsInitialized) {
                throw new Error('Failed to initialize required elements');
            }

            // Load settings
            await this.loadSettings();
            
            // Load quickprompts
            await this.loadQuickPrompts();

            // Initialize features
            this.initializeEventListeners();
            this.initializeSmartSearch();
            this.initializeQuickPromptModal();
            this.initializeInsertTools();
            this.initializeSettings();
            this.initializeTemplates();

            // Focus search input when popup opens
            if (this.searchInput) {
                this.searchInput.focus();
            }
        } catch (error) {
            console.error('Initialization error:', error);
            this.showError('Failed to load quickprompts');
        }
    }

    async loadSettings() {
        try {
            const data = await chrome.storage.sync.get('settings');
            if (data.settings) {
                this.settings = {
                    ...this.settings,
                    ...data.settings
                };
            }
            this.updateSettingsUI();
        } catch (error) {
            console.error('Error loading settings:', error);
            this.showToast('Failed to load settings', 'error');
        }
    }

    updateSettingsUI() {
        Object.entries(this.settings).forEach(([key, value]) => {
            const toggle = document.getElementById(`${key}Toggle`);
            if (toggle) {
                toggle.checked = value;
            }
        });
    }

    initializeSettings() {
        const settingsBtn = document.getElementById('settingsBtn');
        const settingsModal = document.getElementById('settingsModal');
        const closeSettingsBtn = document.getElementById('closeSettingsBtn');

        if (settingsBtn) {
            settingsBtn.addEventListener('click', () => {
                this.showModal(settingsModal);
            });
        }

        if (closeSettingsBtn) {
            closeSettingsBtn.addEventListener('click', () => {
                this.closeModal(settingsModal);
            });
        }

        // Allow clicking outside to close
        settingsModal?.addEventListener('click', (e) => {
            if (e.target === settingsModal) {
                this.closeModal(settingsModal);
            }
        });

        // Initialize toggle handlers
        const toggles = {
            celebrationToggle: {
                key: 'celebration',
                description: 'Celebration effects'
            },
            soundToggle: {
                key: 'sound',
                description: 'Sound effects'
            }
        };

        Object.entries(toggles).forEach(([elementId, { key, description }]) => {
            const toggle = document.getElementById(elementId);
            if (toggle) {
                // Set initial state
                toggle.checked = this.settings[key];
                
                // Add change listener
                toggle.addEventListener('change', async (e) => {
                    this.settings[key] = e.target.checked;
                    try {
                        await chrome.storage.sync.set({ settings: this.settings });
                        this.showToast(
                            `${description} ${e.target.checked ? 'enabled' : 'disabled'}`,
                            'success'
                        );
                    } catch (error) {
                        console.error(`Error saving ${key} setting:`, error);
                        // Revert the toggle if save failed
                        e.target.checked = !e.target.checked;
                        this.settings[key] = e.target.checked;
                        this.showToast(`Failed to save ${description.toLowerCase()} setting`, 'error');
                    }
                });
            }
        });
    }

    showModal(modal) {
        console.log('[showModal] Attempting to show modal:', modal?.id);
        try {
            if (modal) {
                modal.classList.add('show');
                console.log('[showModal] Modal shown successfully');
            }
        } catch (error) {
            console.error('[showModal] Error showing modal:', error);
        }
    }

    closeModal(modal) {
        console.log('[closeModal] Attempting to close modal:', modal?.id);
        try {
            if (modal) {
                modal.classList.remove('show');
                console.log('[closeModal] Modal closed successfully');
            }
        } catch (error) {
            console.error('[closeModal] Error closing modal:', error);
        }
    }

    showToast(message, type = 'success') {
        console.log('[showToast] Showing toast:', { message, type });
        try {
            // Create toast container if it doesn't exist
            let toastContainer = document.querySelector('.toast-container');
            if (!toastContainer) {
                console.log('[showToast] Creating new toast container');
                toastContainer = document.createElement('div');
                toastContainer.className = 'toast-container';
                document.body.appendChild(toastContainer);
            }

            // Limit to 2 toasts maximum
            const maxToasts = 2;
            const existingToasts = toastContainer.querySelectorAll('.toast');
            console.log('[showToast] Existing toasts:', existingToasts.length);
            
            if (existingToasts.length >= maxToasts) {
                console.log('[showToast] Maximum toasts reached, removing oldest');
                existingToasts[0].classList.add('fade-out');
                setTimeout(() => existingToasts[0].remove(), 200);
            }

            // Create toast
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            console.log('[showToast] Created new toast with class:', toast.className);
            
            // Add content and show
            toast.innerHTML = `
                <div class="toast-icon">${type === 'success' ? '✓' : '!'}</div>
                <div class="toast-message">${message}</div>
            `;
            toastContainer.appendChild(toast);

            // Auto remove after delay
            setTimeout(() => {
                console.log('[showToast] Removing toast');
                toast.classList.add('fade-out');
                setTimeout(() => toast.remove(), 200);
            }, 3000);

        } catch (error) {
            console.error('[showToast] Error showing toast:', error);
        }
    }

    initializeInsertTools() {
        const textarea = document.getElementById('replacementPrompt');
        const toolsBar = document.querySelector('.tools-bar');
        
        if (!textarea || !toolsBar) {
            console.error('Required elements for insert tools not found');
            return;
        }

        toolsBar.addEventListener('click', async (e) => {
            const button = e.target.closest('.tool-btn');
            if (!button) return;

            const insertType = button.dataset.insert;
            let insertText = '';

            switch(insertType) {
                case 'timestamp':
                    const format = button.dataset.format || 'MM/DD/YYYY';
                    insertText = `{timestamp format:'${format}'}`;
                    break;

                case 'clipboard':
                    insertText = '{clipboard}';
                    break;

                case 'cursor':
                    insertText = '{cursor}';
                    break;

                case 'url-content':
                    insertText = '{url-content url:"https://api.github.com/zen"}';
                    break;

                default:
                    console.warn('Unknown insert type:', insertType);
                    return;
            }

            // Insert the text at cursor position
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const text = textarea.value;

            textarea.value = text.substring(0, start) + insertText + text.substring(end);
            textarea.focus();

            // Set cursor position after the inserted text
            textarea.selectionStart = textarea.selectionEnd = start + insertText.length;

            // Show feedback
            const actionMap = {
                'timestamp': 'current date/time',
                'clipboard': 'clipboard placeholder (fills when used)',
                'cursor': 'cursor end position',
                'url-content': 'URL content placeholder (fills when used)'
            };
            this.showToast(`Added ${actionMap[insertType]}`, 'success');
        });
    }

    showError(message) {
        console.error(message);
        // Create and show error message in UI instead of using Chrome messaging
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        // Insert at the top of the container
        const container = document.querySelector('.container');
        if (container && container.firstChild) {
            container.insertBefore(errorDiv, container.firstChild);
        }
        
        // Remove after 3 seconds
        setTimeout(() => {
            errorDiv.remove();
        }, 3000);
    }

    initializeElements() {
        // Main elements
        this.quickpromptList = document.getElementById('quickpromptList');
        this.searchInput = document.getElementById('searchInput');
        this.quickpromptModal = document.getElementById('quickpromptModal');
        this.quickpromptForm = document.getElementById('quickpromptForm');
        this.deleteModal = document.getElementById('deleteModal');
        this.modalTitle = document.getElementById('modalTitle');
        
        // Form inputs
        this.triggerInput = document.getElementById('triggerInput');
        this.replacementPrompt = document.getElementById('replacementPrompt');
        this.hotkeyInput = document.getElementById('hotkeyInput');
        
        // Buttons
        this.addQuickPromptBtn = document.getElementById('addQuickPromptBtn');
        this.cancelBtn = document.getElementById('cancelBtn');
        this.saveBtn = document.getElementById('saveBtn');
        this.exportBtn = document.getElementById('exportQuickPromptsBtn');
        this.importBtn = document.getElementById('importQuickPromptsBtn');
        this.resetBtn = document.getElementById('resetQuickPromptsBtn');
        this.confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
        this.cancelDeleteBtn = document.getElementById('cancelDeleteBtn');

        // Initialize delete modal buttons
        if (this.confirmDeleteBtn) {
            this.confirmDeleteBtn.addEventListener('click', () => this.handleDeleteConfirmation());
        }
        if (this.cancelDeleteBtn) {
            this.cancelDeleteBtn.addEventListener('click', () => this.closeModal(this.deleteModal));
        }

        // Check for required elements
        const requiredElements = [
            { name: 'quickpromptList', elem: this.quickpromptList },
            { name: 'searchInput', elem: this.searchInput },
            { name: 'quickpromptModal', elem: this.quickpromptModal },
            { name: 'quickpromptForm', elem: this.quickpromptForm },
            { name: 'modalTitle', elem: this.modalTitle },
            { name: 'triggerInput', elem: this.triggerInput },
            { name: 'replacementPrompt', elem: this.replacementPrompt },
            { name: 'addQuickPromptBtn', elem: this.addQuickPromptBtn },
            { name: 'cancelBtn', elem: this.cancelBtn },
            { name: 'saveBtn', elem: this.saveBtn }
        ];

        const missingElements = requiredElements
            .filter(({elem}) => !elem)
            .map(({name}) => name);

        if (missingElements.length > 0) {
            console.error('Failed to initialize required elements:', missingElements.join(', '));
            return false;
        }

        // Initialize event listeners for form elements
        this.quickpromptForm.addEventListener('submit', (e) => this.handleFormSubmit(e));
        this.addQuickPromptBtn.addEventListener('click', () => this.showEditModal(null));
        this.cancelBtn.addEventListener('click', () => this.closeModal(this.quickpromptModal));

        return true;
    }

    async handleFormSubmit(e) {
        e.preventDefault();

        const triggerInput = document.getElementById('triggerInput');
        const replacementPromptArea = document.getElementById('replacementPrompt');
        const hotkeyInput = document.getElementById('hotkeyInput');
        const showButtonToggle = document.getElementById('showButtonToggle');
        
        if (!triggerInput || !replacementPromptArea) {
            console.error('Form elements not found');
            this.showToast('An error occurred while saving', 'error');
            return;
        }

        const trigger = triggerInput.value.trim();
        const replacementPrompt = replacementPromptArea.value;
        const keyPress = hotkeyInput ? hotkeyInput.dataset.hotkey || null : null;
        const showButton = showButtonToggle ? showButtonToggle.checked : true;

        if (!trigger || !replacementPrompt) {
            this.showToast('Trigger and replacement text are required', 'error');
            return;
        }

        const quickpromptData = {
            trigger,
            replacementPrompt,
            description: trigger, // Using trigger as description for now
            keyPress,
            showButton
        };

        try {
            if (this.editingQuickPrompt) {
                const oldTrigger = this.editingQuickPrompt.trigger;
                await QuickPromptStorageManager.updateQuickPrompt(oldTrigger, quickpromptData);
            } else {
                await QuickPromptStorageManager.addQuickPrompt(quickpromptData);
            }

            await this.loadQuickPrompts();
            this.closeModal(this.quickpromptModal);
            this.showToast(this.editingQuickPrompt ? 'QuickPrompt updated successfully' : 'QuickPrompt added successfully');
            this.editingQuickPrompt = null;
        } catch (error) {
            console.error('Error saving quickprompt:', error);
            this.showToast(error.message || 'Failed to save quickprompt', 'error');
        }
    }

    initializeEventListeners() {
        if (!this.addQuickPromptBtn || !this.searchInput || !this.quickpromptForm || 
            !this.cancelBtn || !this.saveBtn) {
            console.error('Required elements for event listeners not found');
            return;
        }

        // Initialize help button for tutorial video
        const helpBtn = document.getElementById('helpBtn');
        const tutorialModal = document.getElementById('tutorialModal');
        
        if (helpBtn && tutorialModal) {
            // Open tutorial modal
            helpBtn.addEventListener('click', () => {
                console.log('[Tutorial] Opening video tutorial');
                const video = document.getElementById('tutorialVideo');
                if (video) {
                    // Add autoplay parameter when opening
                    video.src = video.src.includes('autoplay=1') 
                        ? video.src 
                        : video.src + '&autoplay=1';
                }
                this.showModal(tutorialModal);
            });

            // Close tutorial modal
            const closeBtn = tutorialModal.querySelector('.close-btn');
            if (closeBtn) {
                closeBtn.addEventListener('click', () => {
                    console.log('[Tutorial] Closing video tutorial');
                    const video = document.getElementById('tutorialVideo');
                    if (video) {
                        // Remove autoplay parameter and reset src to stop video
                        video.src = video.src.replace('&autoplay=1', '');
                    }
                    this.closeModal(tutorialModal);
                });
            }
        }

        // Add quickprompt button
        this.addQuickPromptBtn.addEventListener('click', () => this.showEditModal(null));
        
        // Search input
        this.searchInput.addEventListener('input', () => this.filterQuickPrompts());

        // Cancel button
        this.cancelBtn.addEventListener('click', () => this.closeModal(this.quickpromptModal));

        // Export button
        if (this.exportBtn) {
            this.exportBtn.addEventListener('click', () => this.exportQuickPrompts());
        }

        // Import button
        if (this.importBtn) {
            this.importBtn.addEventListener('click', () => {
                try {
                    this.fileInput.click();
                } catch (error) {
                    console.error('Error triggering file input:', error);
                    this.showToast('Failed to open file picker', 'error');
                }
            });
        }

        // Reset button
        if (this.resetBtn) {
            this.resetBtn.addEventListener('click', () => this.resetToDefault());
        }

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === this.quickpromptModal) {
                this.closeModal(this.quickpromptModal);
            }
        });
    }

    initializeQuickPromptModal() {
        const hotkeyBtn = document.getElementById('hotkeyInput');
        if (!hotkeyBtn) {
            console.error('Hotkey button not found');
            return;
        }

        let isRecording = false;
        let currentKeys = new Set();
        let lastKey = '';
        let recordedKeys = new Set(); // Keep track of the recorded combination

        const updateButtonText = (text, isRecording = false) => {
            hotkeyBtn.innerHTML = `
                <span class="icon">⌨️</span>
                ${text}
            `;
            hotkeyBtn.classList.toggle('recording', isRecording);
        };

        const formatKeyForDisplay = (key) => {
            const keyMap = {
                'Meta': '⌘',
                'Control': '⌃',
                'Alt': '⌥',
                'Shift': '⇧',
                ' ': 'Space',
            };
            return keyMap[key] || key.charAt(0).toUpperCase() + key.slice(1);
        };

        const formatKeyForStorage = (key) => {
            const keyMap = {
                'Meta': 'Cmd',
                'Control': 'Ctrl',
                'Alt': 'Alt',
                'Shift': 'Shift'
            };
            return keyMap[key] || key.toUpperCase();
        };

        const updateQuickPromptDisplay = () => {
            if (currentKeys.size === 0 && !lastKey && recordedKeys.size === 0) {
                updateButtonText('Click to Record Hotkey');
                hotkeyBtn.dataset.hotkey = '';
                return;
            }

            // Use recorded keys if available, otherwise use current keys
            const displayKeys = recordedKeys.size > 0 ? Array.from(recordedKeys) : Array.from(currentKeys);
            if (lastKey && !displayKeys.includes(lastKey)) {
                displayKeys.push(lastKey);
            }

            // Format for display
            const hotkeyText = `
                <div class="hotkey-keys">
                    ${displayKeys.map(key => `<span class="key">${formatKeyForDisplay(key)}</span>`).join('<span class="plus">+</span>')}
                </div>
            `;
            hotkeyBtn.innerHTML = hotkeyText;
            
            // Format for storage
            const storageKeys = displayKeys.map(formatKeyForStorage);
            hotkeyBtn.dataset.hotkey = storageKeys.join('+');
        };

        hotkeyBtn.addEventListener('click', () => {
            isRecording = !isRecording;
            currentKeys.clear();
            lastKey = '';
            recordedKeys.clear();
            
            if (isRecording) {
                updateButtonText('Press keys... (ESC to cancel)', true);
            } else {
                updateQuickPromptDisplay();
            }
        });

        const handleKeyDown = (e) => {
            if (!isRecording) return;
            
            e.preventDefault();
            e.stopPropagation();

            if (e.key === 'Escape') {
                isRecording = false;
                currentKeys.clear();
                lastKey = '';
                recordedKeys.clear();
                updateButtonText('Click to Record Hotkey');
                return;
            }

            // Add modifier keys
            if (e.metaKey) currentKeys.add('Meta');
            if (e.ctrlKey) currentKeys.add('Control');
            if (e.altKey) currentKeys.add('Alt');
            if (e.shiftKey) currentKeys.add('Shift');
            
            // Handle non-modifier key
            if (!['Meta', 'Control', 'Alt', 'Shift', 'Escape'].includes(e.key)) {
                if (/^[a-zA-Z0-9]$/.test(e.key)) {
                    lastKey = e.key;
                    // Save the current combination
                    recordedKeys = new Set(currentKeys);
                    if (lastKey) recordedKeys.add(lastKey);
                }
            }

            updateQuickPromptDisplay();
        };

        const handleKeyUp = (e) => {
            if (!isRecording) return;

            // Only stop recording when all keys are released
            if (recordedKeys.size > 0 && !e.metaKey && !e.ctrlKey && !e.altKey && !e.shiftKey) {
                isRecording = false;
            }

            // Remove released modifier keys from current keys (but not from recorded keys)
            if (e.key === 'Meta') currentKeys.delete('Meta');
            if (e.key === 'Control') currentKeys.delete('Control');
            if (e.key === 'Alt') currentKeys.delete('Alt');
            if (e.key === 'Shift') currentKeys.delete('Shift');

            updateQuickPromptDisplay();
            
            e.preventDefault();
            e.stopPropagation();
        };

        document.addEventListener('keydown', handleKeyDown);
        document.addEventListener('keyup', handleKeyUp);

        // Initialize with default text
        updateButtonText('Click to Record Hotkey');
    }

    initializeSmartSearch() {
        this.searchStrategy = {
            exactMatch: (quickprompt, query) => 
                quickprompt.trigger.toLowerCase().includes(query),
            
            fuzzyMatch: (quickprompt, query) => {
                const normalizedQuery = query.replace(/\s+/g, '');
                const normalizedTrigger = quickprompt.trigger.toLowerCase().replace(/\s+/g, '');
                
                const calculateProximity = (source, target) => {
                    let matchScore = 0;
                    let queryIndex = 0;

                    for (let i = 0; i < source.length && queryIndex < target.length; i++) {
                        if (source[i] === target[queryIndex]) {
                            matchScore++;
                            queryIndex++;
                        }
                    }

                    return matchScore / target.length;
                };

                const triggerProximity = calculateProximity(normalizedTrigger, normalizedQuery);


                return triggerProximity > 0.6 ;
            }
        };
    }

    async loadQuickPrompts() {
        try {
            const quickprompts = await QuickPromptStorageManager.getAllQuickPrompts();
            this.quickprompts = Array.isArray(quickprompts) ? quickprompts.map(quickprompt => ({
                ...quickprompt,
                replacementPrompt: quickprompt.replacementPrompt || '',
                trigger: quickprompt.trigger || '',
                keyPress: quickprompt.keyPress || '',
                description: quickprompt.trigger || ''
            })) : [];
            this.renderQuickPrompts();
        } catch (error) {
            console.error('Failed to load quickprompts:', error);
            this.showError('Failed to load quickprompts');
            this.quickprompts = [];
            this.renderQuickPrompts();
        }
    }

    async renderQuickPrompts(quickprompts = this.quickprompts) {
        if (!this.quickpromptList) return;

        // Clear existing quickprompts
        this.quickpromptList.innerHTML = '';

        // Create and append all quickprompt elements
        quickprompts.forEach(quickprompt => {
            const quickpromptElement = this.createQuickPromptElement(quickprompt);
            
            // Add drag and drop handlers
            quickpromptElement.addEventListener('dragstart', (e) => this.handleDragStart(e));
            quickpromptElement.addEventListener('dragend', (e) => this.handleDragEnd(e));
            quickpromptElement.addEventListener('dragover', (e) => this.handleDragOver(e));
            quickpromptElement.addEventListener('dragleave', (e) => {
                const item = e.target.closest('.quickprompt-item');
                if (item) {
                    item.classList.remove('drop-target-above', 'drop-target-below');
                }
            });
            quickpromptElement.addEventListener('drop', (e) => this.handleDrop(e));
            
            // Add single-click handler for editing
            quickpromptElement.addEventListener('click', () => this.showEditModal(quickprompt));
            
            // Add delete button click handler
            const deleteBtn = quickpromptElement.querySelector('.action-btn.delete');
            if (deleteBtn) {
                deleteBtn.addEventListener('click', (e) => {
                    e.stopPropagation();  // Stop event from bubbling up
                    this.showDeleteModal(quickprompt);
                });
            }
            
            this.quickpromptList.appendChild(quickpromptElement);
        });

        // Show empty state if no items
        if (quickprompts.length === 0) {
            this.showEmptyState();
        }
    }

    handleDragStart(e) {
        console.log('[handleDragStart] Starting drag operation');
        try {
            const item = e.target.closest('.quickprompt-item');
            if (!item) {
                console.log('[handleDragStart] No draggable item found');
                return;
            }

            this.draggedItem = item;
            this.draggedIndex = Array.from(item.parentNode.children).indexOf(item);
            
            console.log('[handleDragStart] Adding dragging class');
            item.classList.add('dragging');
            
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/html', item.innerHTML);
            
            console.log('[handleDragStart] Drag started successfully', {
                draggedIndex: this.draggedIndex
            });
        } catch (error) {
            console.error('[handleDragStart] Error in drag start:', error);
        }
    }

    handleDragEnd(e) {
        console.log('[handleDragEnd] Ending drag operation');
        try {
            if (this.draggedItem) {
                console.log('[handleDragEnd] Removing dragging class');
                this.draggedItem.classList.remove('dragging');
                this.draggedItem = null;
                this.draggedIndex = null;
            }

            // Clean up any remaining drag classes
            const items = document.querySelectorAll('.quickprompt-item');
            items.forEach(item => {
                console.log('[handleDragEnd] Cleaning up item classes');
                item.classList.remove('drop-target-above', 'drop-target-below', 'dragging');
            });
        } catch (error) {
            console.error('[handleDragEnd] Error in drag end:', error);
        }
    }

    handleDragOver(e) {
        e.preventDefault(); // Required to allow dropping
        console.log('[handleDragOver] Handling drag over');
        
        try {
            const item = e.target.closest('.quickprompt-item');
            if (!item || item === this.draggedItem) {
                console.log('[handleDragOver] No valid drop target');
                return;
            }

            // Clear previous drop target indicators
            const items = document.querySelectorAll('.quickprompt-item');
            items.forEach(el => {
                console.log('[handleDragOver] Removing previous drop target indicators');
                el.classList.remove('drop-target-above', 'drop-target-below');
            });

            // Determine drop position
            const rect = item.getBoundingClientRect();
            const y = e.clientY - rect.top;
            const height = rect.height;
            const position = y > height / 2 ? 'below' : 'above';
            
            console.log('[handleDragOver] Adding drop target indicator:', position);
            item.classList.add(`drop-target-${position}`);
        } catch (error) {
            console.error('[handleDragOver] Error in drag over:', error);
        }
    }

    formatKeyForDisplay(key) {
        if (!key) return '';
        
        // Replace common key symbols
        const keyMap = {
            'Meta': '⌘',
            'Alt': '⌥',
            'Shift': '⇧',
            'Control': '⌃',
            'ArrowUp': '↑',
            'ArrowDown': '↓',
            'ArrowLeft': '←',
            'ArrowRight': '→',
            'Enter': '↵',
            'Backspace': '⌫',
            'Delete': '⌦',
            'Escape': 'Esc'
        };

        // Split combination keys
        return key.split('+')
            .map(k => k.trim())
            .map(k => keyMap[k] || k)
            .join(' ');
    }

    createQuickPromptElement(quickprompt) {
        const element = document.createElement('div');
        element.className = 'quickprompt-item';
        element.draggable = true;
        element.dataset.id = quickprompt.id;

        // Create trigger section
        const trigger = document.createElement('div');
        trigger.className = 'quickprompt-trigger';
        trigger.textContent = quickprompt.trigger;

        // Create expansion section
        const expansion = document.createElement('div');
        expansion.className = 'quickprompt-expansion';

        // Add preview text
        const preview = document.createElement('div');
        preview.className = 'expansion-preview';
        preview.textContent = quickprompt.replacementPrompt;
        expansion.appendChild(preview);

        // Add keyboard shortcut if present
        if (quickprompt.keyPress) {
            const shortcut = document.createElement('div');
            shortcut.className = 'shortcut-tag';
            const keyDisplay = this.formatKeyForDisplay(quickprompt.keyPress);
            shortcut.textContent = keyDisplay;
            shortcut.title = `Keyboard shortcut: ${keyDisplay}`;
            expansion.appendChild(shortcut);
        }

        // Create actions section
        const actions = document.createElement('div');
        actions.className = 'quickprompt-actions';
        
        // Delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'action-btn delete';
        const deleteImg = document.createElement('img');
        deleteImg.src = '../assets/icons/delete-24.png';
        deleteImg.width = 16;
        deleteImg.height = 16;
        deleteImg.alt = 'Delete';
        deleteBtn.appendChild(deleteImg);
        deleteBtn.title = 'Delete QuickPrompt';
        deleteBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.showDeleteModal(quickprompt);
        });
        actions.appendChild(deleteBtn);

        // Add all sections to the element
        element.appendChild(trigger);
        element.appendChild(expansion);
        element.appendChild(actions);

        return element;
    }

    showDeleteModal(quickprompt) {
        this.quickpromptToDelete = quickprompt;
        const deleteModal = document.getElementById('deleteModal');
        if (deleteModal) {
            this.showModal(deleteModal);
        }
    }

    async handleDeleteConfirmation() {
        if (!this.quickpromptToDelete || !this.quickpromptToDelete.trigger) {
            console.error('No quickprompt to delete or invalid quickprompt');
            this.showToast('Failed to delete quickprompt', 'error');
            return;
        }
        
        try {
            await QuickPromptStorageManager.deleteQuickPrompt(this.quickpromptToDelete.trigger);
            await this.loadQuickPrompts();
            this.closeModal(this.deleteModal);
            this.showToast('QuickPrompt deleted successfully');
            this.quickpromptToDelete = null;
        } catch (error) {
            console.error('Failed to delete quickprompt:', error);
            this.showToast('Failed to delete quickprompt', 'error');
        }
    }

    async handleResetConfirmation() {
        try {
            const response = await fetch(chrome.runtime.getURL('templates/default-quickprompts.json'));
            const defaultQuickPrompts = await response.json();

            // Set all quickprompts at once instead of adding them one by one
            await QuickPromptStorageManager.setAllQuickPrompts(defaultQuickPrompts);

            // Refresh the UI
            await this.loadQuickPrompts();
            this.closeModal(this.resetModal);
            alert('QuickPrompts have been reset to default!');
        } catch (error) {
            console.error('Error resetting quickprompts:', error);
            alert('Failed to reset quickprompts. Please try again.');
        }
    }

    async resetToDefault() {
        try {
            // Create modal if it doesn't exist
            let resetModal = document.getElementById('resetModal');
            if (!resetModal) {
                resetModal = document.createElement('div');
                resetModal.id = 'resetModal';
                resetModal.className = 'modal';
                resetModal.innerHTML = `
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2>Reset QuickPrompts</h2>
                        </div>
                        <div class="modal-body">
                            <div class="reset-confirmation">
                                <svg viewBox="0 0 24 24" fill="none">
                                    <path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z M12 8v4m0 4h.01" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                                <p>Are you sure you want to reset all quickprompts to default?</p>
                                <p class="warning-text">This will remove all your existing quickprompts. This action cannot be undone.</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="secondary-btn" id="cancelResetBtn">Cancel</button>
                            <button type="button" class="danger-btn" id="confirmResetBtn">Reset All</button>
                        </div>
                    </div>
                `;
                document.querySelector('.container').appendChild(resetModal);
            }

            const confirmResetBtn = document.getElementById('confirmResetBtn');
            const cancelResetBtn = document.getElementById('cancelResetBtn');

            if (!confirmResetBtn || !cancelResetBtn) {
                console.error('Reset modal buttons not found:', { 
                    confirm: !!confirmResetBtn, 
                    cancel: !!cancelResetBtn 
                });
                this.showToast('An error occurred while preparing the reset dialog. Please refresh and try again.', 'error');
                return;
            }

            const handleReset = async () => {
                try {
                    // Show loading state
                    confirmResetBtn.disabled = true;
                    confirmResetBtn.textContent = 'Resetting...';

                    // Reset quickprompts
                    const response = await fetch(chrome.runtime.getURL('templates/default-quickprompts.json'));
                    const defaultQuickPrompts = await response.json();

                    // Set all quickprompts at once instead of adding them one by one
                    await QuickPromptStorageManager.setAllQuickPrompts(defaultQuickPrompts);

                    // Reset settings
                    this.settings = {
                        celebration: true,
                        sound: true
                    };
                    await chrome.storage.sync.set({ settings: this.settings });
                    this.updateSettingsUI();
                    
                    // Reset welcome screen
                    localStorage.removeItem('hideGettingStarted');
                    
                    // Refresh the UI
                    await this.loadQuickPrompts();
                    this.closeModal(resetModal);
                    
                    this.showToast('Everything has been reset to default!', 'success');
                } catch (error) {
                    console.error('Error during reset:', error);
                    this.showToast('Failed to reset. Please try again.', 'error');
                } finally {
                    confirmResetBtn.disabled = false;
                    confirmResetBtn.textContent = 'Reset All';
                }
            };

            const handleCancel = () => {
                this.closeModal(resetModal);
            };

            // Remove existing listeners to prevent duplicates
            const newConfirmBtn = confirmResetBtn.cloneNode(true);
            const newCancelBtn = cancelResetBtn.cloneNode(true);
            confirmResetBtn.parentNode.replaceChild(newConfirmBtn, confirmResetBtn);
            cancelResetBtn.parentNode.replaceChild(newCancelBtn, cancelResetBtn);

            // Add new listeners
            newConfirmBtn.addEventListener('click', handleReset);
            newCancelBtn.addEventListener('click', handleCancel);

            // Show the modal
            this.showModal(resetModal);

        } catch (error) {
            console.error('Error preparing reset:', error);
            this.showToast('Failed to prepare reset dialog', 'error');
        }
    }

    closeModal(modal) {
        if (modal) {
            modal.classList.remove('show');
        }
    }

    showModal(modal) {
        if (modal) {
            modal.classList.add('show');
        }
    }

    showToast(message, type = 'success') {
        // Create toast container if it doesn't exist
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container';
            document.body.appendChild(toastContainer);
        }

        // Limit to 2 toasts maximum
        const maxToasts = 2;
        const existingToasts = toastContainer.querySelectorAll('.toast');
        if (existingToasts.length >= maxToasts) {
            // Remove the oldest toast
            existingToasts[0].classList.add('fade-out');
            setTimeout(() => existingToasts[0].remove(), 200);
        }

        // Create toast
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        // Simplified success/error icons
        const icons = {
            success: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2"><path d="M13.25 4.75L6 12L2.75 8.75"/></svg>',
            error: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 5.75v2.5M8 11.25h.01M8 14A6 6 0 108 2a6 6 0 000 12z"/></svg>'
        };

        toast.innerHTML = `
            <div class="toast-content">
                ${icons[type]}
                <span>${message}</span>
            </div>
        `;

        // Add click to dismiss
        toast.addEventListener('click', () => {
            toast.classList.add('fade-out');
            setTimeout(() => toast.remove(), 200);
        });

        // Ensure smooth animation entry
        requestAnimationFrame(() => {
            toastContainer.appendChild(toast);
            // Force a reflow
            toast.offsetHeight;
        });

        // Auto remove after 2.5 seconds
        const timeout = setTimeout(() => {
            if (toast.parentElement) {
                toast.classList.add('fade-out');
                setTimeout(() => toast.remove(), 200);
            }
        }, 2500);

        // Clear timeout if toast is clicked
        toast.addEventListener('click', () => clearTimeout(timeout));
    }

    escapeHtml(unsafe) {
        if (!unsafe) return '';
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    get fileInput() {
        if (!this._fileInput) {
            this._fileInput = document.createElement('input');
            this._fileInput.type = 'file';
            this._fileInput.accept = '.json';
            this._fileInput.style.display = 'none';
            this._fileInput.addEventListener('change', (event) => this.handleFileSelect(event));
            document.body.appendChild(this._fileInput);
        }
        return this._fileInput;
    }

    async handleFileSelect(event) {
        const file = event.target.files[0];
        if (!file) return;

        try {
            const text = await file.text();
            const quickprompts = JSON.parse(text);

            if (!Array.isArray(quickprompts)) {
                throw new Error('Invalid quickprompts format: must be an array');
            }

            const { isValid, errors, validQuickPrompts } = QuickPromptStorageManager.validateQuickPrompts(quickprompts);
            
            if (!isValid) {
                throw new Error('Some quickprompts are invalid:\n' + errors.join('\n'));
            }

            await this.showImportConfirmation(validQuickPrompts);
        } catch (error) {
            console.error('Error importing quickprompts:', error);
            this.showToast(error.message || 'Failed to import quickprompts', 'error');
        } finally {
            // Clear the input for future imports
            event.target.value = '';
        }
    }

    async showImportConfirmation(validQuickPrompts) {
        // First try to find existing modal
        let importModal = document.getElementById('importModal');
        if (importModal) {
            importModal.remove(); // Remove existing modal if present
        }

        // Create modal
        importModal = document.createElement('div');
        importModal.id = 'importModal';
        importModal.className = 'modal';
        importModal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Import QuickPrompts</h2>
                </div>
                <div class="modal-body">
                    <div class="import-header">
                        <label class="checkbox-wrapper">
                            <input type="checkbox" id="selectAllImport">
                            <span class="checkbox-label">Select All Quickprompts</span>
                        </label>
                        <span class="import-count">0 selected</span>
                    </div>
                    <div class="import-grid">
                        ${validQuickPrompts.map((qp, index) => `
                            <div class="import-card" data-index="${index}">
                                <input type="checkbox" class="quickprompt-checkbox">
                                <div class="import-content">
                                    <div class="import-trigger">${this.escapeHtml(qp.trigger)}</div>
                                    <div class="import-description">${this.escapeHtml(qp.description || 'No description')}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="modal-btn cancel" id="cancelImportBtn">Cancel</button>
                    <button type="button" class="modal-btn primary" id="confirmImportBtn" disabled>Import Selected (0)</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(importModal);
        importModal.classList.add('show');

        return new Promise((resolve, reject) => {
            const cleanup = () => {
                importModal.classList.remove('show');
                setTimeout(() => {
                    if (importModal.parentNode) {
                        importModal.parentNode.removeChild(importModal);
                    }
                }, 300);
            };

            const selectedQuickprompts = new Set();
            const confirmBtn = importModal.querySelector('#confirmImportBtn');
            const selectAllCheckbox = importModal.querySelector('#selectAllImport');
            const countDisplay = importModal.querySelector('.import-count');
            
            const updateUI = () => {
                const count = selectedQuickprompts.size;
                countDisplay.textContent = `${count} selected`;
                confirmBtn.textContent = `Import Selected (${count})`;
                confirmBtn.disabled = count === 0;

                // Update "Select All" checkbox state
                const allCheckboxes = Array.from(importModal.querySelectorAll('.quickprompt-checkbox'));
                const allChecked = allCheckboxes.every(cb => cb.checked);
                selectAllCheckbox.checked = allChecked;

                // Update "Select All" checkbox indeterminate state
                const someChecked = allCheckboxes.some(cb => cb.checked);
                selectAllCheckbox.indeterminate = someChecked && !allChecked;
            };

            // Handle card clicks (including checkbox)
            importModal.querySelectorAll('.import-card').forEach((card, index) => {
                const checkbox = card.querySelector('.quickprompt-checkbox');
                
                const toggleSelection = () => {
                    checkbox.checked = !checkbox.checked;
                    if (checkbox.checked) {
                        selectedQuickprompts.add(validQuickPrompts[index]);
                        card.classList.add('selected');
                    } else {
                        selectedQuickprompts.delete(validQuickPrompts[index]);
                        card.classList.remove('selected');
                    }
                    updateUI();
                };

                // Click on card toggles selection
                card.addEventListener('click', (e) => {
                    if (e.target !== checkbox) { // Prevent double-toggle when clicking checkbox directly
                        toggleSelection();
                    }
                });

                // Checkbox change updates selection
                checkbox.addEventListener('change', (e) => {
                    e.stopPropagation(); // Prevent card click from firing
                    if (checkbox.checked) {
                        selectedQuickprompts.add(validQuickPrompts[index]);
                        card.classList.add('selected');
                    } else {
                        selectedQuickprompts.delete(validQuickPrompts[index]);
                        card.classList.remove('selected');
                    }
                    updateUI();
                });
            });

            // Handle select all
            selectAllCheckbox.addEventListener('change', () => {
                const checkboxes = importModal.querySelectorAll('.quickprompt-checkbox');
                const cards = importModal.querySelectorAll('.import-card');
                
                checkboxes.forEach((cb, index) => {
                    cb.checked = selectAllCheckbox.checked;
                    if (selectAllCheckbox.checked) {
                        selectedQuickprompts.add(validQuickPrompts[index]);
                        cards[index].classList.add('selected');
                    } else {
                        selectedQuickprompts.clear();
                        cards[index].classList.remove('selected');
                    }
                });
                updateUI();
            });

            // Handle import
            const handleImport = async () => {
                if (selectedQuickprompts.size === 0) {
                    this.showToast('Please select at least one quickprompt to import', 'error');
                    return;
                }

                try {
                    // Convert selected quickprompts to array and import using unified method
                    const selectedPrompts = {
                        quickprompts: Array.from(selectedQuickprompts)
                    };
                    
                    await this.importQuickPrompts(selectedPrompts, 'selected quickprompts');
                    cleanup();
                    resolve();
                } catch (error) {
                    console.error('Error importing quickprompts:', error);
                    this.showToast('Failed to import quickprompts', 'error');
                    cleanup();
                    reject(error);
                }
            };

            const handleCancel = () => {
                cleanup();
                resolve();
            };

            confirmBtn.addEventListener('click', handleImport, { once: true });
            importModal.querySelector('#cancelImportBtn').addEventListener('click', handleCancel, { once: true });
            importModal.addEventListener('click', (e) => {
                if (e.target === importModal) handleCancel();
            }, { once: true });
        });
    }

    async importQuickPrompts(newPrompts, sourceName = 'quickprompts') {
        try {
            // Get existing quickprompts
            const existingQuickprompts = await QuickPromptStorageManager.getAllQuickPrompts();
            
            // Handle both array (from template) and object with quickprompts array (from file)
            let promptsToAdd = [];
            if (Array.isArray(newPrompts)) {
                // Template import passes array directly
                promptsToAdd = newPrompts;
            } else if (newPrompts?.quickprompts && Array.isArray(newPrompts.quickprompts)) {
                // File import passes {quickprompts: [...]}
                promptsToAdd = newPrompts.quickprompts;
            } else {
                throw new Error('Invalid quickprompts format');
            }
            
            // Add new quickprompts with unique IDs
            const processedPrompts = promptsToAdd.map(qp => ({
                ...qp,
                id: crypto.randomUUID()
            }));

            // Merge with existing quickprompts (additive)
            const mergedQuickprompts = [...existingQuickprompts, ...processedPrompts];
            
            // Save all quickprompts
            await QuickPromptStorageManager.setAllQuickPrompts(mergedQuickprompts);
            
            // Refresh UI
            await this.loadQuickPrompts();
            
            // Show success message
            this.showToast(`Successfully imported ${sourceName}!`);
            
            return true;
        } catch (error) {
            console.error('Error importing quickprompts:', error);
            this.showToast('Failed to import quickprompts', 'error');
            return false;
        }
    }

    async handleFileImport() {
        try {
            const importedData = await this.showImportModal();
            if (importedData) {
                await this.importQuickPrompts(importedData, 'quickprompts');
            }
        } catch (error) {
            console.error('Import error:', error);
            this.showToast('Failed to import quickprompts', 'error');
        }
    }

    async loadAndShowTemplates(templatesModal, templatesList) {
        try {
            const response = await fetch(chrome.runtime.getURL('templates/problem-solving-templates.json'));
            const data = await response.json();
            
            // Clear existing templates
            templatesList.innerHTML = '';
            
            if (!data.templates || !Array.isArray(data.templates)) {
                throw new Error('Invalid template data');
            }

            // Create template items
            data.templates.forEach(template => {
                const templateItem = document.createElement('div');
                templateItem.className = 'template-item';
                templateItem.innerHTML = `
                    <div class="template-info">
                        <div class="template-name">${this.escapeHtml(template.name)}</div>
                        <div class="template-description">${this.escapeHtml(template.description)}</div>
                    </div>
                    <button class="import-btn primary-btn">Import</button>
                `;

                const importBtn = templateItem.querySelector('.import-btn');
                importBtn.addEventListener('click', async () => {
                    try {
                        await this.importQuickPrompts(template.quickprompts, template.name);
                        this.closeModal(templatesModal);
                    } catch (error) {
                        console.error('Error importing template:', error);
                        this.showToast('Failed to import template', 'error');
                    }
                });

                templatesList.appendChild(templateItem);
            });

            this.showModal(templatesModal);
        } catch (error) {
            console.error('Error loading templates:', error);
            this.showToast('Failed to load templates', 'error');
        }
    }

    initializeTemplates() {
        // Initialize file import
        const importBtn = document.getElementById('importBtn');
        importBtn?.addEventListener('click', () => this.handleFileImport());

        // Initialize template functionality
        const templatesBtn = document.getElementById('templatesBtn');
        const templatesModal = document.getElementById('templatesModal');
        const closeTemplatesBtn = templatesModal?.querySelector('.close-btn');
        const templatesList = document.querySelector('.templates-list');
        const browseTemplatesBtn = document.getElementById('browseTemplatesBtn');

        // Handler for template button clicks
        const handleTemplateClick = () => {
            this.loadAndShowTemplates(templatesModal, templatesList);
        };

        // Add click handlers to both template buttons
        templatesBtn?.addEventListener('click', handleTemplateClick);
        browseTemplatesBtn?.addEventListener('click', handleTemplateClick);

        // Close button handler
        closeTemplatesBtn?.addEventListener('click', () => {
            this.closeModal(templatesModal);
        });

        // Click outside to close
        templatesModal?.addEventListener('click', (e) => {
            if (e.target === templatesModal) {
                this.closeModal(templatesModal);
            }
        });
    }

    cleanup() {
        if (this._fileInput && this._fileInput.parentNode) {
            this._fileInput.parentNode.removeChild(this._fileInput);
            this._fileInput = null;
        }
    }

    showEditModal(quickprompt = null) {
        this.editingQuickPrompt = quickprompt;
        const modalTitle = document.getElementById('modalTitle');
        if (modalTitle) {
            modalTitle.textContent = quickprompt ? 'Edit QuickPrompt' : 'Add QuickPrompt';
        }
        
        // Reset form
        if (this.triggerInput && this.replacementPrompt) {
            this.triggerInput.value = quickprompt ? quickprompt.trigger : '';
            this.replacementPrompt.value = quickprompt ? quickprompt.replacementPrompt : '';
        }
        
        // Initialize hotkey button
        const hotkeyBtn = document.getElementById('hotkeyInput');
        if (hotkeyBtn) {
            if (quickprompt && quickprompt.keyPress) {
                const keys = quickprompt.keyPress.split('+').map(key => {
                    const keyMap = {
                        'Meta': '⌘',
                        'Control': '⌃',
                        'Alt': '⌥',
                        'Shift': '⇧',
                        ' ': 'Space',
                    };
                    return keyMap[key] || key;
                });
                
                hotkeyBtn.innerHTML = `
                    <div class="hotkey-keys">
                        ${keys.map(key => `<span class="key">${key}</span>`).join('<span class="plus">+</span>')}
                    </div>
                `;
                hotkeyBtn.dataset.hotkey = quickprompt.keyPress;
            } else {
                hotkeyBtn.innerHTML = `
                    <span class="icon">⌨️</span>
                    Click to Record HotKey
                `;
                hotkeyBtn.dataset.hotkey = '';
            }
        }

        // Initialize show button toggle
        const showButtonToggle = document.getElementById('showButtonToggle');
        if (showButtonToggle) {
            showButtonToggle.checked = quickprompt ? quickprompt.showButton !== false : true;
        }
        
        this.showModal(this.quickpromptModal);
        if (this.triggerInput) {
            this.triggerInput.focus();
        }
    }

    filterQuickPrompts() {
        if (!this.searchInput || !this.quickprompts) {
            this.renderQuickPrompts(this.quickprompts);
            return;
        }

        const searchTerm = this.searchInput.value.toLowerCase().trim();
        if (!searchTerm) {
            this.renderQuickPrompts(this.quickprompts);
            return;
        }

        // First try exact matches
        let filteredQuickPrompts = this.quickprompts.filter(quickprompt => 
            this.exactMatch(quickprompt, searchTerm)
        );

        // If no exact matches, try fuzzy matches
        if (filteredQuickPrompts.length === 0) {
            filteredQuickPrompts = this.quickprompts.filter(quickprompt => 
                this.fuzzyMatch(quickprompt, searchTerm)
            );
        }

        // Clear existing list
        while (this.quickpromptList.firstChild) {
            this.quickpromptList.removeChild(this.quickpromptList.firstChild);
        }

        // Show results or empty state
        if (filteredQuickPrompts.length > 0) {
            this.renderQuickPrompts(filteredQuickPrompts);
        } else {
            const emptyState = document.createElement('div');
            emptyState.className = 'empty-state';
            emptyState.textContent = `No quickprompts found matching "${searchTerm}"`;
            this.quickpromptList.appendChild(emptyState);
        }
    }

    exactMatch(quickprompt, query) {
        return quickprompt.trigger.toLowerCase().includes(query) ||
               quickprompt.replacementPrompt.toLowerCase().includes(query);
    }

    fuzzyMatch(quickprompt, query) {
        const normalizedQuery = query.toLowerCase();
        const triggerScore = this.calculateProximity(quickprompt.trigger.toLowerCase(), normalizedQuery);
        const promptScore = this.calculateProximity(quickprompt.replacementPrompt.toLowerCase(), normalizedQuery);
        
        return triggerScore > 0.3 || promptScore > 0.3; // Threshold for fuzzy matching
    }

    calculateProximity(source, target) {
        if (source === target) return 1;
        if (source.includes(target)) return 0.8;
        
        let matches = 0;
        const words = source.split(/\s+/);
        const targetWords = target.split(/\s+/);
        
        for (const targetWord of targetWords) {
            for (const word of words) {
                if (word.includes(targetWord) || 
                    this.levenshteinDistance(word, targetWord) <= Math.min(2, Math.floor(targetWord.length / 3))) {
                    matches++;
                    break;
                }
            }
        }
        
        return matches / targetWords.length;
    }

    levenshteinDistance(str1, str2) {
        const track = Array(str2.length + 1).fill(null).map(() =>
            Array(str1.length + 1).fill(null));
        for (let i = 0; i <= str1.length; i += 1) {
            track[0][i] = i;
        }
        for (let j = 0; j <= str2.length; j += 1) {
            track[j][0] = j;
        }
        for (let j = 1; j <= str2.length; j += 1) {
            for (let i = 1; i <= str1.length; i += 1) {
                const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
                track[j][i] = Math.min(
                    track[j][i - 1] + 1,
                    track[j - 1][i] + 1,
                    track[j - 1][i - 1] + indicator,
                );
            }
        }
        return track[str2.length][str1.length];
    }

    showEmptyState() {
        const emptyState = document.createElement('div');
        emptyState.className = 'empty-state';
        emptyState.textContent = "No quickprompts found. Click 'Add QuickPrompt' to create one.";
        this.quickpromptList.appendChild(emptyState);
    }

    async exportQuickPrompts() {
        try {
            const quickprompts = await QuickPromptStorageManager.getAllQuickPrompts();
            
            // Format the date for the filename
            const date = new Date().toISOString().split('T')[0];
            const filename = `quickprompts-${date}.json`;
            
            // Create a formatted JSON string
            const jsonString = JSON.stringify(quickprompts, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            
            // Create download link
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            
            // Trigger download
            document.body.appendChild(a);
            a.click();
            
            // Cleanup
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            // Show success message
            this.showToast('QuickPrompts exported successfully');
        } catch (error) {
            console.error('Error exporting quickprompts:', error);
            this.showToast('Failed to export quickprompts', 'error');
        }
    }
}

// Initialize the UI when the document is loaded
document.addEventListener('DOMContentLoaded', () => {
    new QuickPromptManagerUI();
});
