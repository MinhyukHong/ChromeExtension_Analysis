// API Client
window._aifuseDebug = window._aifuseDebug || { loadOrder: [] };
window._aifuseDebug.loadOrder.push('api/client.js');

// Normalize file data to a consistent format
function normalizeFileData(file) {
    // Handle both string and object inputs
    if (typeof file === 'string') {
        return {
            name: file.split('/').pop(),
            fullPath: file,
            relativePath: file,
            displayName: file.split('/').pop()
        };
    }
    
    return {
        name: file.name || file.relativePath?.split('/').pop() || '',
        fullPath: file.fullPath || file.path || file.relativePath || '',
        relativePath: file.relativePath || file.path || '',
        displayName: file.name || file.relativePath?.split('/').pop() || ''
    };
}

// API functions
async function checkApiHealth() {
    try {
        const response = await fetch('http://localhost:3000/health');
        if (!response.ok) {
            return { isHealthy: false, error: 'API responded with error' };
        }
        const data = await response.json();
        return { 
            isHealthy: data.status === 'ok',
            version: data.version,
            timestamp: data.timestamp
        };
    } catch (error) {
        // Silently handle the error and return status
        return { 
            isHealthy: false, 
            error: 'API server unavailable',
            details: error.message 
        };
    }
}

async function getFileOptions(query = '') {
    try {
        const endpoint = query ? '/search-files' : '/visible-files';
        const response = await fetch(`http://localhost:3000${endpoint}${query ? `?query=${encodeURIComponent(query)}` : ''}`);
        const data = await response.json();
        const files = query ? data.results : (data.files || []);
        return files.map(normalizeFileData);
    } catch (error) {
        console.error('[AIFuse-Debug][API] Error in getFileOptions:', error);
        return [];
    }
}

async function sendContentToFile(filePath, content) {
    try {
        const response = await fetch('http://localhost:3000/file', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ fullPath: filePath, content }),
        });
        if (!response.ok) {
            const error = await response.text();
            console.error('[AIFuse-Debug][API] Failed to update file. Error:', error);
            return false;
        }
        return true;
    } catch (error) {
        console.error('[AIFuse-Debug][API] Error in sendContentToFile:', error);
        return false;
    }
}

async function getFileContent(filePath) {
    try {
        const response = await fetch(`http://localhost:3000/file?fullPath=${encodeURIComponent(filePath)}`);
        if (!response.ok) {
            const error = await response.text();
            console.error('Failed to get file content. Error:', error);
            return null;
        }
        const data = await response.json();
        return data.content;
    } catch (error) {
        console.error('Error fetching file content:', error);
        return null;
    }
}

async function fetchVisibleFiles() {
    try {
        const response = await fetch('http://localhost:3000/visible-files');
        if (!response.ok) {
            throw new Error('Failed to fetch visible files');
        }
        const data = await response.json();
        return data.files;
    } catch (error) {
        console.error("Failed to fetch visible files:", error);
        return [];
    }
}

// Initialize API client
async function initializeApiClient() {
    try {
        // Make functions available globally
        window.getFileOptions = getFileOptions;
        window.sendContentToFile = sendContentToFile;
        window.getFileContent = getFileContent;
        window.fetchVisibleFiles = fetchVisibleFiles;
        window.checkApiHealth = checkApiHealth;
        
        // Perform initial health check
        const health = await checkApiHealth();
    } catch (error) {
        console.error('[API-Client] Failed to initialize API client:', error);
        throw error;
    }
}
