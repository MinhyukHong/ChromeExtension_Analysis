// API State Manager
window._aifuseDebug = window._aifuseDebug || { loadOrder: [] };
window._aifuseDebug.loadOrder.push('api/state.js');

// Simple state manager for API status
class ApiStateManager {
    // Constants for health check intervals
    CONNECTED_INTERVAL = 30000;    // 30 seconds when connected
    DISCONNECTED_INTERVAL = 30000;  //  seconds when disconnected

    constructor() {
        // Try to restore previous state from storage
        const savedState = localStorage.getItem('apiState');
        const defaultState = {
            isHealthy: false,
            version: null,
            lastChecked: null,
            error: 'Initializing...'
        };
        
        const state = savedState ? JSON.parse(savedState) : defaultState;
        
        this.isHealthy = state.isHealthy;
        this.version = state.version;
        this.lastChecked = state.lastChecked ? new Date(state.lastChecked) : null;
        this.error = state.error;
        this.listeners = new Set();
        this.checkInterval = null;
    }

    // Update state and notify listeners
    updateState(healthStatus) {
        const previousState = this.isHealthy;
        this.isHealthy = healthStatus.isHealthy;
        this.version = healthStatus.version;
        this.lastChecked = new Date();
        this.error = healthStatus.error;

        // Save state to localStorage
        localStorage.setItem('apiState', JSON.stringify({
            isHealthy: this.isHealthy,
            version: this.version,
            lastChecked: this.lastChecked,
            error: this.error
        }));

        // Always notify listeners on update
        this.notifyListeners();
    }

    // Add state change listener
    addListener(callback) {
        this.listeners.add(callback);
        // Immediately call with current state
        callback({
            isHealthy: this.isHealthy,
            version: this.version,
            lastChecked: this.lastChecked,
            error: this.error
        });
    }

    // Remove state change listener
    removeListener(callback) {
        this.listeners.delete(callback);
    }

    // Notify all listeners
    notifyListeners() {
        this.listeners.forEach(callback => callback({
            isHealthy: this.isHealthy,
            version: this.version,
            lastChecked: this.lastChecked,
            error: this.error
        }));
    }

    // Start periodic health check with adaptive interval
    async startHealthCheck() {
        // Clear any existing interval
        if (this.checkInterval) {
            clearInterval(this.checkInterval);
        }

        // Initial check
        const initialHealth = await window.checkApiHealth();
        this.updateState(initialHealth);

        // Helper to set the appropriate interval
        const setAppropriateInterval = () => {
            if (this.checkInterval) {
                clearInterval(this.checkInterval);
            }
            
            const interval = this.isHealthy ? this.CONNECTED_INTERVAL : this.DISCONNECTED_INTERVAL;
            
            this.checkInterval = setInterval(async () => {
                const health = await window.checkApiHealth();
                this.updateState(health);
            }, interval);
        };

        // Set initial interval
        setAppropriateInterval();

        // Update interval whenever health status changes
        this.addListener(() => {
            setAppropriateInterval();
        });
    }

    // Stop health check
    stopHealthCheck() {
        if (this.checkInterval) {
            clearInterval(this.checkInterval);
            this.checkInterval = null;
        }
    }
}

// Initialize state immediately
window.apiState = new ApiStateManager();

// Add API readiness check
window.isApiReady = () => {
    const readinessCheck = {
        apiStateExists: !!window.apiState,
        apiStateIsHealthy: window.apiState?.isHealthy,
        checkApiHealthExists: typeof window.checkApiHealth === 'function',
        getFileOptionsExists: typeof window.getFileOptions === 'function',
        sendContentToFileExists: typeof window.sendContentToFile === 'function'
    };
    
    
    const isReady = readinessCheck.apiStateExists && 
                   readinessCheck.apiStateIsHealthy &&
                   readinessCheck.checkApiHealthExists && 
                   readinessCheck.getFileOptionsExists && 
                   readinessCheck.sendContentToFileExists;
                   
    return isReady;
};

// Start health check immediately
window.apiState.startHealthCheck().catch(error => {
    console.error('[[State] Initial health check failed:', error);
});

// Make state functions available globally
window.getApiState = () => ({
    isHealthy: window.apiState.isHealthy,
    version: window.apiState.version,
    lastChecked: window.apiState.lastChecked,
    error: window.apiState.error
});

// Set up theme change listener
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    console.debug(`Theme changed to ${e.matches ? 'dark' : 'light'}`);
});

