// =============================================================================
// UI Constants - Icons, Classes, and Templates
// =============================================================================

window._aifuseDebug = window._aifuseDebug || { loadOrder: [] };
window._aifuseDebug.loadOrder.push('ui/chat.js');

// Access constants from window.UI_CONSTANTS
const ICONS = window.UI_CONSTANTS.ICONS;
const BUTTON_STYLES = window.UI_CONSTANTS.BUTTON_STYLES;
const CONTAINER_STYLES = window.UI_CONSTANTS.CONTAINER_STYLES;
const CHAT_SELECTORS = window.UI_CONSTANTS.CHAT_SELECTORS;

// =============================================================================
// Button Creation and Styling
// =============================================================================

function createButton(text, bgColor, hoverColor) {
    const button = document.createElement('button');
    button.className = BUTTON_STYLES.CUSTOM;
    button.textContent = text;
    button.style.backgroundColor = bgColor;
    button.style.borderColor = bgColor;
    button.style.transition = 'all 0.2s ease-in-out';
    
    button.addEventListener('mouseenter', () => {
        button.style.backgroundColor = hoverColor;
        button.style.transform = 'scale(1.05)';
    });
    button.addEventListener('mouseleave', () => {
        button.style.backgroundColor = bgColor;
        button.style.transform = 'scale(1)';
    });
    
    return button;
}

function createActionButton(icon, text) {
    const button = document.createElement('button');
    button.className = BUTTON_STYLES.BASE;
    button.innerHTML = `${icon}<span>${text}</span>`;
    button.dataset.requiresApi = 'true'; // Mark button as API-dependent
    
    // Set initial state based on API health if available
    if (window.apiState) {
        const currentState = window.apiState.isHealthy;
        if (currentState) {
            enableActionButton(button);
        } else {
            disableActionButton(button);
        }
    } else {
        // If apiState is not available, hide the button
        disableActionButton(button);
    }
    
    return button;
}

// =============================================================================
// Button State Management
// =============================================================================

function setButtonLoading(button) {
    button.innerHTML = `${ICONS.LOADING}<span>Loading...</span>`;
}

function setButtonSuccess(button, text = 'Done!') {
    button.innerHTML = `${ICONS.SUCCESS}<span>${text}</span>`;
}

function resetButton(button, originalContent) {
    button.innerHTML = originalContent;
}

function disableActionButton(button) {
    // Hide the button instead of disabling it
    button.style.display = 'none';
}

function enableActionButton(button) {
    // Show the button
    button.style.display = 'inline-flex';
    button.style.opacity = '1';
    button.style.cursor = 'pointer';
}

// =============================================================================
// Event Handlers
// =============================================================================

async function handlePushButtonClick(e, button, codeContent) {
    if (button.disabled) {
        e.preventDefault();
        return;
    }
    
    e.stopPropagation();
    e.preventDefault();
    
    const originalContent = button.innerHTML;
    
    try {
        const fileOptions = await window.getFileOptions();
        const selectedFile = await window.showFileSelectionPopup(fileOptions);
        if (!selectedFile) return;

        setButtonLoading(button);
        const success = await window.sendContentToFile(selectedFile, codeContent);
        
        if (success) {
            setButtonSuccess(button, 'Sent!');
            const rect = button.getBoundingClientRect();
            // Run effects in parallel
            await Promise.all([
                window.playSound(),
                window.triggerConfetti((rect.left + rect.right) / 2, rect.top)
            ]);
            setTimeout(() => resetButton(button, originalContent), 2000);
        }
    } catch (error) {
        console.error('[AIFuse-Debug][Chat] Error pushing code:', error);
        alert('Failed to send content');
        resetButton(button, originalContent);
    }
}

async function handleRunButtonClick(e, button, commands) {
    if (button.disabled) {
        e.preventDefault();
        return;
    }

    e.stopPropagation();
    e.preventDefault();

    if (!commands.length) {
        alert('No commands to execute.');
        return;
    }

    const originalContent = button.innerHTML;
    
    try {
        setButtonLoading(button);
        const response = await fetch('http://localhost:3000/run-command', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ commands })
        });

        if (!response.ok) {
            throw new Error('Failed to execute commands');
        }

        const result = await response.json();
        showCommandOutputWithActions(JSON.stringify(result, null, 2));
        setButtonSuccess(button);
        setTimeout(() => resetButton(button, originalContent), 2000);
    } catch (error) {
        console.error('[AIFuse-Debug][Chat] Error executing commands:', error);
        alert('Failed to execute commands');
        resetButton(button, originalContent);
    }
}

// =============================================================================
// Code Block Processing
// =============================================================================

function processCodeBlock(block) {
    if (!block || block.getAttribute('data-aifuse-processed') === 'true') {
        console.debug('[Chat] Skipping code block - already processed');
        return;
    }

    try {
        // Ensure the block has the necessary structure
        let container = block.querySelector('div:first-child');
        if (!container) {
            container = document.createElement('div');
            block.insertBefore(container, block.firstChild);
        }

        // Create button container
        const buttonContainer = document.createElement('div');
        buttonContainer.className = CONTAINER_STYLES.BUTTONS;
        
        // Create and setup buttons
        const pushButton = createActionButton(ICONS.PUSH, 'Push');
        const runButton = createActionButton(ICONS.RUN, 'Run');
        
        // Only add event listeners if code element exists
        const codeElement = block.querySelector('code');
        if (codeElement) {
            pushButton.addEventListener('click', (e) => 
                handlePushButtonClick(e, pushButton, codeElement.innerText)
            );
            runButton.addEventListener('click', (e) => 
                handleRunButtonClick(e, runButton, codeElement.innerText.trim().split('\n').filter(Boolean))
            );
        }
        
        // Append buttons
        buttonContainer.appendChild(pushButton);
        buttonContainer.appendChild(runButton);
        container.appendChild(buttonContainer);
        
        // Mark as processed
        block.setAttribute('data-aifuse-processed', 'true');
    } catch (error) {
        console.error('[AIFuse-Debug][Chat] Error processing code block:', error);
    }
}

// =============================================================================
// Output Display
// =============================================================================

function showCommandOutputWithActions(output) {
    let parsedOutput;
    try {
        parsedOutput = JSON.parse(output);
    } catch (e) {
        parsedOutput = { results: [{ command: 'unknown', stdout: output, stderr: '' }] };
    }

    const overlay = document.createElement('div');
    overlay.style.position = 'fixed';
    overlay.style.top = '0';
    overlay.style.left = '0';
    overlay.style.width = '100vw';
    overlay.style.height = '100vh';
    overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    overlay.style.zIndex = '999';
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) document.body.removeChild(overlay);
    });

    const container = document.createElement('div');
    container.style.backgroundColor = '#1a1a1a';
    container.style.color = '#e5e5e5';
    container.style.borderRadius = '8px';
    container.style.padding = '20px';
    container.style.width = '80%';
    container.style.maxWidth = '800px';
    container.style.maxHeight = '80vh';
    container.style.overflowY = 'auto';
    container.style.position = 'fixed';
    container.style.top = '50%';
    container.style.left = '50%';
    container.style.transform = 'translate(-50%, -50%)';
    container.style.fontFamily = 'Monaco, Consolas, monospace';

    // Header
    const header = document.createElement('div');
    header.style.marginBottom = '20px';
    header.style.display = 'flex';
    header.style.justifyContent = 'space-between';
    header.style.alignItems = 'center';
    
    const title = document.createElement('h2');
    title.textContent = 'Command Output';
    title.style.margin = '0';
    title.style.color = '#fff';
    header.appendChild(title);

    // Copy options
    const copyOptions = document.createElement('div');
    copyOptions.style.display = 'flex';
    copyOptions.style.gap = '10px';

    const copyButton = createButton('Copy', '#444', '#555');
    
    copyOptions.appendChild(copyButton);
    header.appendChild(copyOptions);

    container.appendChild(header);

    // Output content
    const outputContent = document.createElement('div');
    outputContent.style.backgroundColor = '#2d2d2d';
    outputContent.style.borderRadius = '4px';
    outputContent.style.padding = '15px';
    outputContent.style.marginBottom = '20px';

    parsedOutput.results.forEach((result, index) => {
        if (index > 0) {
            const separator = document.createElement('div');
            separator.style.height = '1px';
            separator.style.backgroundColor = '#444';
            separator.style.margin = '15px 0';
            outputContent.appendChild(separator);
        }

        // Command
        const cmdBlock = document.createElement('div');
        cmdBlock.style.marginBottom = '10px';
        
        const prompt = document.createElement('span');
        prompt.textContent = '$ ';
        prompt.style.color = '#666';
        cmdBlock.appendChild(prompt);
        
        const cmd = document.createElement('span');
        cmd.textContent = result.command;
        cmd.style.color = '#88c0d0';
        cmdBlock.appendChild(cmd);
        
        outputContent.appendChild(cmdBlock);

        // Output
        if (result.stdout) {
            const output = document.createElement('div');
            output.style.color = '#d8dee9';
            output.style.whiteSpace = 'pre-wrap';
            output.style.wordBreak = 'break-word';
            output.style.paddingLeft = '20px';
            output.textContent = result.stdout;
            outputContent.appendChild(output);
        }

        // Error (if any)
        if (result.stderr) {
            const error = document.createElement('div');
            error.style.color = '#bf616a';
            error.style.whiteSpace = 'pre-wrap';
            error.style.wordBreak = 'break-word';
            error.style.paddingLeft = '20px';
            error.style.marginTop = '5px';
            error.textContent = result.stderr;
            outputContent.appendChild(error);
        }
    });

    container.appendChild(outputContent);

    // Action buttons
    const buttonsContainer = document.createElement('div');
    buttonsContainer.style.display = 'flex';
    buttonsContainer.style.justifyContent = 'flex-end';
    buttonsContainer.style.gap = '10px';

    const closeButton = createButton('Close', '#444', '#555');
    closeButton.addEventListener('click', () => {
        document.body.removeChild(overlay);
    });

    // Copy handler
    copyButton.addEventListener('click', async () => {
        try {
            const textToCopy = parsedOutput.results
                .map(result => `$ ${result.command}\n${result.stdout}${result.stderr ? '\nError: ' + result.stderr : ''}`)
                .join('\n\n');
            await navigator.clipboard.writeText(textToCopy);
            copyButton.textContent = 'Copied!';
            setTimeout(() => {
                copyButton.textContent = 'Copy';
            }, 2000);
        } catch (err) {
            console.error('[AIFuse-Debug][Chat] Failed to copy:', err);
            alert('Failed to copy to clipboard');
        }
    });

    buttonsContainer.appendChild(closeButton);
    container.appendChild(buttonsContainer);
    overlay.appendChild(container);
    document.body.appendChild(overlay);
}

// =============================================================================
// Initialization and Setup
// =============================================================================

async function waitForApi() {
    return new Promise((resolve) => {
        const checkApi = () => {
            
            if (window.apiState && 
                typeof window.checkApiHealth === 'function' && 
                typeof window.getFileOptions === 'function' && 
                typeof window.sendContentToFile === 'function') {
                resolve();
            } else {
                setTimeout(checkApi, 100);
            }
        };
        checkApi();
    });
}

function setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            // Ensure we have valid nodes to process
            if (!mutation.addedNodes || !mutation.addedNodes.length) return;

            mutation.addedNodes.forEach((node) => {
                // Only process element nodes
                if (node.nodeType !== Node.ELEMENT_NODE) return;

                // Process PRE elements
                if (node.nodeName === 'PRE') {
                    // Ensure basic structure exists
                    if (!node.querySelector('div')) {
                        const div = document.createElement('div');
                        node.insertBefore(div, node.firstChild);
                    }
                    if (!node.querySelector('code')) {
                        const code = document.createElement('code');
                        node.appendChild(code);
                    }
                    processCodeBlock(node);
                }

                // Process nested PRE elements
                if (node.querySelectorAll) {
                    const preElements = node.querySelectorAll('pre');
                    preElements.forEach(pre => {
                        if (!pre.querySelector('div')) {
                            const div = document.createElement('div');
                            pre.insertBefore(div, pre.firstChild);
                        }
                        if (!pre.querySelector('code')) {
                            const code = document.createElement('code');
                            pre.appendChild(code);
                        }
                        processCodeBlock(pre);
                    });
                }
            });
        });
    });

    // Observe document body with required options
    if (document.body) {
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    } else {
        // Wait for body if not available
        document.addEventListener('DOMContentLoaded', () => {
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        });
    }

    return observer;
}

async function initializeCodeBlocks() {
    try {
        // Wait for document to be ready
        if (document.readyState !== 'complete') {
            await new Promise(resolve => {
                window.addEventListener('load', resolve);
            });
        }

        // Process all existing code blocks
        const preElements = document.querySelectorAll('pre');
        if (!preElements.length) {
            console.debug('[Chat] No existing code blocks found');
            return;
        }

        preElements.forEach(pre => {
            try {
                // Create basic structure if missing
                if (!pre.querySelector('div')) {
                    const div = document.createElement('div');
                    pre.insertBefore(div, pre.firstChild);
                }
                
                if (!pre.querySelector('code')) {
                    const code = document.createElement('code');
                    // Move existing content to code element
                    code.textContent = pre.textContent;
                    pre.textContent = '';
                    pre.appendChild(code);
                }

                // Process the block
                processCodeBlock(pre);
            } catch (error) {
                console.error('[AIFuse-Debug][Chat] Error initializing code block:', error);
            }
        });
    } catch (error) {
        console.error('[AIFuse-Debug][Chat] Error in initializeCodeBlocks:', error);
    }
}

// Improved initialization strategy
async function initialize() {
    await waitForApi();
    // Process existing code blocks
    const codeBlocks = document.querySelectorAll(CHAT_SELECTORS.CODE_BLOCKS);
    codeBlocks.forEach(processCodeBlock);

    // Set up mutation observer for new messages
    setupMutationObserver();

    // Add API state change listener
    if (window.apiState) {
        window.apiState.addListener((state) => {
            // Update all API-dependent buttons
            document.querySelectorAll('[data-requires-api="true"]').forEach(button => {
                if (state.isHealthy) {
                    enableActionButton(button);
                } else {
                    disableActionButton(button);
                }
            });
        });

        // Initial check of API state
        const currentState = window.apiState.isHealthy;
        document.querySelectorAll('[data-requires-api="true"]').forEach(button => {
            if (currentState) {
                enableActionButton(button);
            } else {
                disableActionButton(button);
            }
        });
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
} else {
    initialize();
}

// Also initialize when navigating between chats
document.addEventListener('locationchange', initialize);

// =============================================================================
// Helper function: Add a bottom bar to a block
// =============================================================================

function addBottomBar(block) {
    const bottomBar = document.createElement('div');
    bottomBar.className = 'flex items-center justify-between bg-gray-800 py-2 px-4 mt-2 border-t border-gray-700';
    bottomBar.style.display = 'flex';
    bottomBar.style.gap = '10px';
    block.appendChild(bottomBar);
    return bottomBar;
}

// =============================================================================
// Function to enhance message input
// =============================================================================

function enhanceMessageInput() {
    let pullButtonInstance = null;
    
    async function handlePullButtonClick(e, button) {
        if (button.disabled) {
            e.preventDefault();
            return;
        }
        
        e.stopPropagation();
        e.preventDefault();
        
        const originalContent = button.innerHTML;
        
        try {
            const fileOptions = await window.getFileOptions();
            const selectedFile = await window.showFileSelectionPopup(fileOptions);
            if (!selectedFile) return;

            setButtonLoading(button);
            
            const fileContent = await window.getFileContent(selectedFile);
            if (fileContent === null) {
                throw new Error('Failed to fetch file content');
            }

            // Get the ChatGPT input element and focus it
            const target = window.FileContentManager.getChatGPTInput();
            if (!target) {
                throw new Error('ChatGPT message input not found');
            }

            // Inject the content at the end
            const insertPosition = await window.FileContentManager.inject(target, fileContent);
            if (insertPosition === null) {
                throw new Error('Failed to insert file content');
            }
            
            setButtonSuccess(button, 'Inserted!');
            const rect = button.getBoundingClientRect();
            window.playSound();
            window.triggerConfetti((rect.left + rect.right) / 2, rect.top);
            setTimeout(() => resetButton(button, originalContent), 2000);
            
        } catch (error) {
            console.error('[AIFuse-Debug][Chat] Error pulling file:', error);
            alert(error.message || 'Failed to pull file');
            resetButton(button, originalContent);
        }
    }
    
    function addPullButton() {
        if (pullButtonInstance?.isConnected) return;
        
        const buttonContainer = document.querySelector(CHAT_SELECTORS.BUTTON_CONTAINER);
        if (!buttonContainer) return;
        
        pullButtonInstance = createActionButton(ICONS.PULL, '');
        pullButtonInstance.className = 'flex items-center justify-center py-1 px-2 text-gray-600 dark:text-white hover:bg-black/5 dark:hover:bg-white/5 rounded transition-colors duration-200';
        pullButtonInstance.addEventListener('click', (e) => handlePullButtonClick(e, pullButtonInstance));
        
        buttonContainer.insertBefore(pullButtonInstance, buttonContainer.firstChild);
    }
    
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.type === 'childList') {
                if (!pullButtonInstance || !pullButtonInstance.isConnected) {
                    setTimeout(addPullButton, 100);
                }
            }
        }
    });
    
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
    
    addPullButton();
    
    return () => {
        observer.disconnect();
        pullButtonInstance = null;
    };
}

// Call enhanceMessageInput
enhanceMessageInput();
