// UI Theme Constants
window.UI_CONSTANTS = {
    ICONS: {
        PUSH: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" class="text-gray-600 dark:text-gray-300">
            <path d="M12 4v16m0-16l-4 4m4-4l4 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`,
        RUN: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" class="text-gray-600 dark:text-gray-300">
            <path d="M5 3l14 9-14 9V3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`,
        SUCCESS: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" class="text-green-500">
            <path d="M20 6L9 17l-5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`,
        LOADING: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" class="text-gray-600 dark:text-gray-300 animate-spin">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2" stroke-dasharray="30 30" stroke-dashoffset="0"/>
        </svg>`,
        PULL: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M12 4v16m0 0l-4-4m4 4l4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`,
        STATUS_ONLINE: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <circle cx="6" cy="6" r="4" fill="#4ade80"/>
        </svg>`,
        STATUS_OFFLINE: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <circle cx="6" cy="6" r="4" fill="#f87171"/>
        </svg>`
    },

    BUTTON_STYLES: {
        BASE: 'flex gap-1 items-center py-1 px-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded',
        CUSTOM: 'text-white font-medium text-sm px-3 py-1 border rounded-md transition-all',
        STATUS_INDICATOR: 'fixed bottom-4 right-4 flex items-center gap-2 px-2 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-sm transition-all duration-300 hover:bg-gray-200 dark:hover:bg-gray-700'
    },

    CONTAINER_STYLES: {
        BUTTONS: 'aifuse-buttons flex gap-1 ml-2',
        HEADER: 'flex items-center justify-between'
    },

    CHAT_SELECTORS: {
        BUTTON_CONTAINER: '.flex.h-\\[44px\\].items-center.justify-between .flex.gap-x-1',
        PROSEMIRROR_EDITOR: '#prompt-textarea'
    }
};
