// Debounce function to limit API calls
function debounce(func, wait) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        return new Promise((resolve) => {
            timeout = setTimeout(() => resolve(func.apply(this, args)), wait);
        });
    };
}

// Create and style the popup container
function createPopupContainer() {
    const container = document.createElement('div');
    container.style.position = 'fixed';
    container.style.top = '50%';
    container.style.left = '50%';
    container.style.transform = 'translate(-50%, -50%)';
    container.style.backgroundColor = '#1e1e1e';
    container.style.padding = '20px';
    container.style.borderRadius = '8px';
    container.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
    container.style.zIndex = '10000';
    container.style.width = '500px';
    container.style.maxHeight = '80vh';
    container.style.display = 'flex';
    container.style.flexDirection = 'column';
    container.style.gap = '10px';
    return container;
}

// Create and style the search input
function createSearchInput() {
    const input = document.createElement('input');
    input.type = 'text';
    input.placeholder = 'Search files...';
    input.style.width = '100%';
    input.style.padding = '8px 12px';
    input.style.backgroundColor = '#2d2d2d';
    input.style.border = '1px solid #3d3d3d';
    input.style.borderRadius = '4px';
    input.style.color = '#fff';
    input.style.fontSize = '14px';
    return input;
}

// Create and style the file list container
function createFileList() {
    const list = document.createElement('div');
    list.style.overflowY = 'auto';
    list.style.maxHeight = 'calc(80vh - 120px)';
    list.style.marginTop = '10px';
    return list;
}

// Create a file option element
function createFileOption(file) {
    const option = document.createElement('div');
    
    // Create container for better layout
    const container = document.createElement('div');
    container.style.display = 'flex';
    container.style.flexDirection = 'column';
    
    // Create filename element
    const filename = document.createElement('div');
    filename.textContent = file.displayName;
    filename.style.fontSize = '14px';
    filename.style.fontWeight = 'bold';
    container.appendChild(filename);
    
    // Create path element if path differs from name
    if (file.relativePath && file.relativePath !== file.displayName) {
        const path = document.createElement('div');
        path.textContent = `└─ ${file.relativePath}`;
        path.style.fontSize = '12px';
        path.style.color = '#888';
        path.style.marginTop = '2px';
        container.appendChild(path);
    }
    
    option.appendChild(container);
    option.style.padding = '8px 12px';
    option.style.cursor = 'pointer';
    option.style.borderRadius = '4px';
    option.style.color = '#fff';
    option.style.transition = 'background-color 0.2s';

    option.addEventListener('mouseenter', () => {
        option.style.backgroundColor = '#3d3d3d';
    });

    option.addEventListener('mouseleave', () => {
        option.style.backgroundColor = 'transparent';
    });

    return option;
}

// Show the file selection popup
async function showFileSelectionPopup(initialOptions) {
    return new Promise((resolve) => {
        const container = createPopupContainer();
        const searchInput = createSearchInput();
        const fileList = createFileList();

        // Create overlay
        const overlay = document.createElement('div');
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        overlay.style.zIndex = '9999';

        // Stop click propagation on container
        container.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        // Close popup when clicking outside
        overlay.addEventListener('click', () => {
            document.body.removeChild(overlay);
            document.body.removeChild(container);
            resolve(null);
        });

        // Function to update the file list
        function updateFileList(files) {
            fileList.innerHTML = '';
            if (!files || files.length === 0) {
                const noResults = document.createElement('div');
                noResults.textContent = 'No files found';
                noResults.style.padding = '8px 12px';
                noResults.style.color = '#888';
                fileList.appendChild(noResults);
                return;
            }
            
            files.forEach(file => {
                const option = createFileOption(file);
                option.addEventListener('click', () => {
                    document.body.removeChild(overlay);
                    document.body.removeChild(container);
                    resolve(file.fullPath); // Return the full path for file operations
                });
                fileList.appendChild(option);
            });
        }

        // Initial file list
        const normalizedInitialOptions = Array.isArray(initialOptions) ? initialOptions : [];
        updateFileList(normalizedInitialOptions);

        // Debounced search function
        const debouncedSearch = debounce(async (query) => {
            const options = await window.getFileOptions(query);
            updateFileList(options);
        }, 300);

        // Search input handler
        searchInput.addEventListener('input', async (e) => {
            const query = e.target.value.trim();
            await debouncedSearch(query);
        });

        // Add elements to container
        container.appendChild(searchInput);
        container.appendChild(fileList);

        // Add container and overlay to body
        document.body.appendChild(overlay);
        document.body.appendChild(container);

        // Focus search input
        searchInput.focus();
    });
}

// Make the function available globally
window.showFileSelectionPopup = showFileSelectionPopup;
