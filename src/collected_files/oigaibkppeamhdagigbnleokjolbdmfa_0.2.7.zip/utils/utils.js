/**
 * This file contains utility functions for the AIFuse Chrome Extension
 * 
 * The confetti functionality uses js-confetti library
 * https://github.com/loonywizard/js-confetti
 * Copyright (c) 2021 Vladimir Nikitin
 * Licensed under MIT License
 */

window._aifuseDebug = window._aifuseDebug || { loadOrder: [] };
window._aifuseDebug.loadOrder.push('utils.js');

// Preload the sound file
let preloadedAudio = null;
let audioInitPromise = null;
let audioInitAttempts = 0;
const MAX_INIT_ATTEMPTS = 3;

// Start audio initialization immediately
initializeAudio().catch(error => {
    console.warn('[Audio] Early initialization warning:', error);
});

// Initialize audio with proper error handling
async function initializeAudio() {
    // Don't try to initialize if we've exceeded max attempts
    if (audioInitAttempts >= MAX_INIT_ATTEMPTS) {
        console.warn('[Sound] Max initialization attempts reached');
        return null;
    }

    // If already initializing, return existing promise
    if (audioInitPromise) {
        return audioInitPromise;
    }

    audioInitAttempts++;
    
    audioInitPromise = new Promise(async (resolve, reject) => {
        try {
            // Check if sound is enabled in settings
            const data = await chrome.storage.sync.get('settings');
            if (!data.settings?.sound) {
                console.log('[Sound] Sound is disabled in settings');
                resolve(null);
                return;
            }

            // Get the audio URL from chrome runtime
            const audioURL = chrome.runtime.getURL('assets/expand_sound.mp3');
            if (!audioURL) {
                throw new Error('Could not get audio URL');
            }

            // Create and configure audio element
            const audio = new Audio();
            
            // Add error handler before setting src
            audio.onerror = (e) => {
                console.error('[Sound] Audio load error:', e);
                reject(new Error(`Failed to load audio: ${e.target.error?.message || 'Unknown error'}`));
            };

            // Add load handler
            audio.oncanplaythrough = () => {
                console.log('[Sound] Audio loaded successfully');
                preloadedAudio = audio;
                resolve(audio);
            };

            // Set the source
            audio.src = audioURL;
            await audio.load();
            
        } catch (error) {
            console.error('[Sound] Error initializing audio:', error);
            preloadedAudio = null;
            audioInitPromise = null;
            reject(error);
        }
    });

    return audioInitPromise;
}

// Function to play the preloaded sound
async function playSound() {
    try {
        // Check if sound is enabled in settings
        const data = await chrome.storage.sync.get('settings');
        if (!data.settings?.sound) {
            return; // Exit early if sound is disabled
        }

        // If audio isn't initialized or failed, try to initialize it
        if (!preloadedAudio) {
            try {
                const audio = await initializeAudio();
                if (!audio) return; // Exit if initialization failed
            } catch (error) {
                console.warn('[Sound] Failed to initialize audio:', error);
                return;
            }
        }

        if (preloadedAudio) {
            try {
                preloadedAudio.currentTime = 0;
                await preloadedAudio.play().catch(async (error) => {
                    console.warn('[Sound] Playback failed, attempting recovery:', error);
                    // Reset audio state
                    preloadedAudio = null;
                    audioInitPromise = null;
                    // Try one more time with fresh initialization
                    const audio = await initializeAudio();
                    if (audio) {
                        audio.currentTime = 0;
                        await audio.play();
                    }
                });
            } catch (error) {
                console.error('[Sound] Final playback attempt failed:', error);
                // Reset state on complete failure
                preloadedAudio = null;
                audioInitPromise = null;
            }
        }
    } catch (error) {
        console.error('[Sound] Error in playSound:', error);
        // Reset audio if there was an error
        preloadedAudio = null;
        audioInitPromise = null;
    }
}

// Function to trigger confetti
async function triggerConfetti(x, y) {
  try {
    // Check if celebration effects are enabled in settings
    const data = await chrome.storage.sync.get('settings');
    if (!data.settings?.celebration) {
      return; // Exit early if celebration effects are disabled
    }

    const originX = x / window.innerWidth;
    const originY = y / window.innerHeight;
    
    if (!window.confetti) {
      console.error('[Confetti] Confetti function not found on window object');
      return;
    }
    
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { x: originX, y: originY },
      useWorker: false // Force disable worker to ensure compatibility
    });
    
  } catch (error) {
    console.error('[Confetti] Error triggering confetti:', error);
  }
}

// Helper function to get caret coordinates in INPUT and TEXTAREA elements
function getCaretCoordinates(element, position) {
  const div = document.createElement("div");
  const copyStyle = getComputedStyle(element);

  for (const prop of copyStyle) {
    div.style[prop] = copyStyle[prop];
  }

  div.style.position = "absolute";
  div.style.visibility = "hidden";
  div.style.whiteSpace = "pre-wrap";
  div.style.wordWrap = "break-word";

  div.textContent = element.value.substr(0, position);
  const span = document.createElement("span");
  span.textContent = element.value.substr(position) || ".";
  div.appendChild(span);

  document.body.appendChild(div);
  const coordinates = {
    top: span.offsetTop + parseInt(copyStyle.borderTopWidth),
    left: span.offsetLeft + parseInt(copyStyle.borderLeftWidth),
    height: parseInt(copyStyle.lineHeight)
  };
  document.body.removeChild(div);

  return coordinates;
}

// Helper function to get caret coordinates in contenteditable elements
function getContentEditableCaretCoords() {
  const selection = window.getSelection();
  if (!selection.rangeCount) return null;

  const range = selection.getRangeAt(0);
  const rects = range.getClientRects();
  if (!rects.length) return null;

  const rect = rects[0];
  return {
    top: rect.top,
    left: rect.left,
    height: rect.height
  };
}

// Initialize utils
function initializeUtils() {
    // Defer audio initialization to when it's needed
    console.debug('[Utils] Initialization complete');
}

// Export utilities through window
window.playSound = playSound;
window.triggerConfetti = triggerConfetti;
window.getCaretCoordinates = getCaretCoordinates;
window.getContentEditableCaretCoords = getContentEditableCaretCoords;
