// Configuration Management
class QuickPromptConfig {
  static async load() {
    try {
      const response = await fetch(chrome.runtime.getURL("templates/default-quickprompts.json"));
      return await response.json();
    } catch (error) {
      console.error('[QuickPromptConfig] Failed to load quickprompts:', error);
      return [];
    }
  }
}

// Placeholder Processing System
class PlaceholderProcessor {
  static #placeholderRegistry = new Map();

  static registerPlaceholder(name, handler) {
    this.#placeholderRegistry.set(name, handler);
  }

  static async processPlaceholders(text) {
    try {
      let processedText = text;
      let hasChanges;

      do {
        hasChanges = false;
        const originalText = processedText;

        // Process registered placeholders
        for (const [name, handler] of this.#placeholderRegistry) {
          // Match placeholders with balanced curly braces, case-insensitive
          const placeholderRegex = new RegExp(`{${name}(?:\\s*([^}]*?))?}`, 'gi');
          const matches = Array.from(processedText.matchAll(placeholderRegex));
          
          for (const match of matches) {
            const fullMatch = match[0];
            const attributesStr = match[1] ? match[1].trim() : '';
            
            // Parse attributes if present
            const attributes = {};
            if (attributesStr) {
              // First, recursively process any nested placeholders in the attributes
              const processedAttrs = await this.processPlaceholders(attributesStr);
              
              // Then parse the processed attributes string
              const attrRegex = /(\w+):(["'])((?:(?!\2|[{}]|\\(?:\2|[{}])).|\\.)*?)\2/gi;
              const attrMatches = Array.from(processedAttrs.matchAll(attrRegex));
              
              for (const attrMatch of attrMatches) {
                const [_, key, quote, value] = attrMatch;
                attributes[key.toLowerCase()] = value;
              }
            }

            try {
              const replacement = await handler.process(fullMatch, attributes);
              processedText = processedText.replace(fullMatch, replacement);
            } catch (error) {
              console.error(`[PlaceholderProcessor] Error processing ${fullMatch}:`, error);
            }
          }
        }

        // Check if any replacements were made
        hasChanges = processedText !== originalText;
      } while (hasChanges); // Continue until no more changes are made

      // Handle cursor placeholder separately since it's special
      if (processedText.includes('{cursor}')) {
        processedText = processedText.replace('{cursor}', '');
      }

      return processedText;
    } catch (error) {
      console.error('[PlaceholderProcessor] Processing error:', error);
      return text;
    }
  }
}

// Base class for placeholder handlers
class BasePlaceholderHandler {
  async process(text, attributes = {}) {
    throw new Error('Not implemented');
  }
}

// URL Content Handler
class URLContentPlaceholderHandler extends BasePlaceholderHandler {
  async process(text, attributes = {}) {
    try {
      if (!attributes.url) {
        throw new Error('URL attribute is required');
      }

      // Add error handling for connection issues
      const response = await fetch(attributes.url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json, text/plain'
        }
      }).catch(error => {
        console.error('[URLHandler] Fetch failed:', error);
        return `[Unable to fetch: ${error.message}]`;
      });

      if (!response.ok) {
        return `[Error: ${response.status} - ${response.statusText}]`;
      }

      let data;
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        data = await response.json();
      } else {
        data = await response.text();
      }

      // Format the response based on the format attribute
      const format = attributes.format || 'default';
      switch (format) {
        case 'files':
          if (typeof data === 'string') {
            // Clean up the file content
            return data
                .replace(/^relativePath:.*$/gm, '')  // Remove entire relativePath lines
                .replace(/^----.*$/gm, '')          // Remove entire separator lines
                .replace(/\n{3,}/g, '\n\n')        // Normalize multiple newlines to double
                .trim();
          }
          return Array.isArray(data) ? data.join(', ') : JSON.stringify(data);
        case 'json':
          return typeof data === 'object' ? JSON.stringify(data, null, 2) : data;
        default:
          return typeof data === 'object' ? JSON.stringify(data) : data;
      }
    } catch (error) {
      console.error('[URLHandler] Error processing URL content:', error);
      return `[Error: ${error.message}]`;
    }
  }
}

// Timestamp placeholder handler
class TimestampPlaceholderHandler extends BasePlaceholderHandler {
  #defaultFormat = 'MM/DD/YYYY HH:mm:ss';

  async process(text, attributes = {}) {

    const now = new Date();
    
    // Always use default format for empty or invalid attributes
    if (!attributes || Object.keys(attributes).length === 0) {
      return this.#formatDate(now, this.#defaultFormat);
    }

    // Check if format attribute exists and is valid
    let format = attributes.format;
    if (!format || typeof format !== 'string' || format.trim() === '') {
      return this.#formatDate(now, this.#defaultFormat);
    }

    // Clean up format string - remove extra quotes and braces
    format = format.replace(/^['"]|['"]$/g, '');

    // Validate format tokens
    const validTokens = ['MM', 'DD', 'YYYY', 'HH', 'mm', 'ss'];
    const isValid = validTokens.some(token => format.includes(token));
    
    // Use cleaned format or default
    const finalFormat = isValid ? format.trim() : this.#defaultFormat;
    return this.#formatDate(now, finalFormat);
  }

  #formatDate(date, format) {
    return format
        .replace('MM', String(date.getMonth() + 1).padStart(2, '0'))
        .replace('DD', String(date.getDate()).padStart(2, '0'))
        .replace('YYYY', date.getFullYear())
        .replace('HH', String(date.getHours()).padStart(2, '0'))
        .replace('mm', String(date.getMinutes()).padStart(2, '0'))
        .replace('ss', String(date.getSeconds()).padStart(2, '0'));
  }
}

// Clipboard placeholder handler
class ClipboardPlaceholderHandler extends BasePlaceholderHandler {
  async process(text, attributes = {}) {
    try {
      const clipboardText = await navigator.clipboard.readText();
      return clipboardText || '[Clipboard is empty]';
    } catch (error) {
      console.error('[ClipboardHandler] Error reading clipboard:', error);
      return '[Unable to access clipboard - Please grant clipboard permission]';
    }
  }
}

// DateTime placeholder handler
class DateTimePlaceholderHandler extends BasePlaceholderHandler {
  #defaultFormat = {
    dateStyle: 'short',
    timeStyle: 'short',
    hour12: false
  };

  #parseFormat(format) {
    if (!format) return this.#defaultFormat;
    
    // Handle common format strings
    const formatMap = {
      'hh:mm': { timeStyle: 'short', hour12: false },
      'HH:mm': { timeStyle: 'short', hour12: true },
      'full': { dateStyle: 'full', timeStyle: 'long' },
      'date': { dateStyle: 'short' },
      'time': { timeStyle: 'short' }
    };

    return formatMap[format] || this.#defaultFormat;
  }

  async process(text, attributes = {}) {
    const now = new Date();
    const format = this.#parseFormat(attributes.format);
    const dateTimeString = now.toLocaleString('en-US', format);
    return dateTimeString;
  }
}

// URL Content Handler
class UrlContentHandler extends BasePlaceholderHandler {
  #defaultFormat = 'auto';

  #normalizeUrl(url) {
    try {
      // Handle URL validation
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        throw new Error('URL must start with http:// or https://');
      }
      return url;
    } catch (error) {
      console.error('[UrlContentHandler] URL normalization error:', error);
      throw error;
    }
  }

  #formatters = {
    'json': async (response) => {
      const data = await response.json();
      return JSON.stringify(data, null, 2);
    },
    'text': async (response) => {
      const text = await response.text();
      return text;
    },
    'html': async (response) => {
      const html = await response.text();
      return html.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
    },
    'files': async (response) => {
      const data = await response.json();
      return data.files
        .map(file => `relativePath: ${file.relativePath}\n----\n${file.content}\n----`)
        .join("\n\n");
    },
    'auto': async (response) => {
      const contentType = response.headers.get('Content-Type');
      if (contentType?.includes('application/json')) {
        return this.#formatters['json'](response.clone());
      } else if (contentType?.includes('text/html')) {
        return this.#formatters['html'](response.clone());
      }
      return this.#formatters['text'](response.clone());
    }
  };

  async process(text, attributes = {}) {
    const { url, format = this.#defaultFormat } = attributes;
    if (!url) {
      throw new Error('URL is required');
    }

    // Test if we're in extension context
    const formatter = this.#formatters[format] || this.#formatters['auto'];
    
    try {
      const normalizedUrl = this.#normalizeUrl(url);

      // Test both fetch approaches
      let response;
      try {
        response = await fetch(normalizedUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
          },
          mode: 'cors',
          credentials: 'omit'
        });
      } catch (fetchError) {
        // Fallback to extension messaging if direct fetch fails
        response = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({
            type: 'fetch',
            url: normalizedUrl
          }, response => {
            if (chrome.runtime.lastError) {
              reject(chrome.runtime.lastError);
            } else {
              resolve(new Response(response.body, response));
            }
          });
        });
      }
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}, statusText: ${response.statusText}`);
      }
      
      const result = await formatter(response);
      return result;
    } catch (error) {
      console.error('[UrlContentHandler] Error fetching URL:', {
        error,
        url,
        format,
        message: error.message,
        stack: error.stack,
        type: error.constructor.name
      });
      return `[Error: ${error.message}]`;
    }
  }
}

// Command Runner Handler
class RunPlaceholderHandler extends BasePlaceholderHandler {
  async process(text, attributes = {}) {
    try {
      const cmd = attributes.cmd;
      if (!cmd) {
        throw new Error('No command provided');
      }

      const response = await fetch('http://localhost:3000/run-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ commands: [cmd] })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const { results } = await response.json();
      if (results[0].stderr) {
        return results[0].stderr;
      }
      return results[0].stdout;
    } catch (error) {
      console.error('[RunPlaceholderHandler] Run command error:', error);
      return error.message;
    }
  }
}

// QuickPrompt List Handler
class QuickPromptListPlaceholderHandler extends BasePlaceholderHandler {
  async process(text, attributes = {}) {
    try {
      // Use window.quickprompts which is kept in sync by QuickPromptStorageManager
      if (!window.quickprompts || !Array.isArray(window.quickprompts)) {
        console.error('[QuickPromptListwindow.quickprompts-Handler] QuickPrompts not available');
        return '[Error: QuickPrompts not available]';
      }

      // Sort quickprompts by order (higher first), then alphabetically by trigger
      const sortedQuickPrompts = window.quickprompts.sort((a, b) => {
        // Sort by order first (higher order comes first)
        if (b.order !== a.order) {
          return b.order - a.order;
        }
        // If orders are equal, sort alphabetically by trigger
        return a.trigger.toLowerCase().localeCompare(b.trigger.toLowerCase());
      });
      
      // Format each quickprompt with trigger, keyboard hotkey (if available), and description
      const quickpromptList = sortedQuickPrompts
        .map(s => {
          const keyPress = s.keyPress ? ` [${s.keyPress}]` : '';
          return `/${s.trigger}${keyPress}: ${s.description}`;
        })
        .join('\n');
      
      return quickpromptList;
    } catch (error) {
      console.error('[QuickPromptList-Handler] Error processing quickprompt list:', error);
      return '[Error: Unable to generate quickprompt list]';
    }
  }
}

// Register all available placeholders
PlaceholderProcessor.registerPlaceholder('clipboard', new ClipboardPlaceholderHandler());
PlaceholderProcessor.registerPlaceholder('timestamp', new TimestampPlaceholderHandler());
PlaceholderProcessor.registerPlaceholder('current-datetime', new DateTimePlaceholderHandler());
PlaceholderProcessor.registerPlaceholder('url-content', new UrlContentHandler());
PlaceholderProcessor.registerPlaceholder('quickprompts', new QuickPromptListPlaceholderHandler());
PlaceholderProcessor.registerPlaceholder('run', new RunPlaceholderHandler());

// Make it globally available
window.PlaceholderProcessor = PlaceholderProcessor;

// Text Processing
class TextProcessor {
  static async handleSpecialPlaceholders(text) {

    try {
      const processed = await PlaceholderProcessor.processPlaceholders(text);
      return processed;
    } catch (error) {
      console.error('[Processor-Debug] Processing failed:', {
        error,
        processorState: PlaceholderProcessor,
        text
      });
      return text;
    }
  }
}

// Input Type Detection
class InputTypeDetector {
  static analyze(element) {
    const analysis = {
      tagName: element.tagName,
      isContentEditable: element.isContentEditable,
      role: element.getAttribute('role'),
      type: element.type,
      className: element.className,
      isInput: element instanceof HTMLInputElement,
      isTextArea: element instanceof HTMLTextAreaElement,
      hasValue: 'value' in element,
      parentContentEditable: element.closest('[contenteditable]') !== null
    };
    return analysis;
  }
}

// Cursor Placeholder Management with enhanced error handling
class CursorPlaceholderManager {
  static addCursorPlaceholder(text, inputType) {
    try {
      // Validate input
      if (typeof text !== 'string') {
        console.error('[CursorPlaceholder] Invalid text:', text);
        return text;
      }

      // Default to plain text if no input type
      const isRichText = inputType && (inputType.isContentEditable || inputType.parentContentEditable);
      
      // Choose placeholder based on input type
      const cursorMarker = isRichText 
        ? '<span class="cursor-placeholder"></span>'
        : '‸';
      
      // Replace {cursor} or append to end
      const result = text.includes('{cursor}')
        ? text.replace('{cursor}', cursorMarker)
        : text + cursorMarker;
      
      return result;

    } catch (error) {
      console.error('[CursorPlaceholder] Error in addCursorPlaceholder:', error);
      return text; // Return original text as fallback
    }
  }
}

// Base Input Adapter
class TextInputAdapterBase {
  constructor(element) {
    this.element = element;
  }

  getText() { 
    throw new Error('Not implemented'); 
  }
  setText() { 
    throw new Error('Not implemented'); 
  }
  getCursorPosition() { 
    throw new Error('Not implemented'); 
  }
  replace() { 
    throw new Error('Not implemented'); 
  }
}

// Standard Input Adapter
class StandardInputAdapter extends TextInputAdapterBase {
  constructor(element) {
    super(element);
    this.inputType = InputTypeDetector.analyze(element);
  }

  getText() {
    try {
      const text = this.element.value;
      return text;
    } catch (error) {
      console.error('[StandardInputAdapter] Error getting text:', error);
      return '';
    }
  }

  setText(text) {
    try {
      this.element.value = text;
    } catch (error) {
      console.error('[StandardInputAdapter] Error setting text:', error);
    }
  }

  getCursorPosition() {
    try {
      const position = this.element.selectionStart;
      return position;
    } catch (error) {
      console.error('[StandardInputAdapter] Error getting cursor position:', error);
      return 0;
    }
  }

  replace(start, end, text) {
    try {
      if (text.includes('<') && text.includes('>')) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = text;
        text = tempDiv.textContent || tempDiv.innerText || text;
      }

      const cursorPosition = text.indexOf('‸');
      text = text.replace('‸', '');
      
      const beforeText = this.element.value.slice(0, start);
      const afterText = this.element.value.slice(end);
      const newValue = beforeText + text + afterText;
      
      // Store the final cursor position before any changes
      const finalPosition = cursorPosition >= 0 ? start + cursorPosition : start + text.length;
      
      // Update the input value and trigger an input event
      this.element.value = newValue;
      this.element.dispatchEvent(new Event('input', { bubbles: true }));
      
      // Force a re-render by briefly removing focus and restoring it
      const activeElement = document.activeElement;
      if (activeElement === this.element) {
        this.element.blur();
        this.element.focus();
      }
      
      // Set the cursor position after the re-render
      requestAnimationFrame(() => {
        this.element.setSelectionRange(finalPosition, finalPosition);
      });
    } catch (error) {
      console.error('[StandardInputAdapter] Error in replace:', error);
    }
  }
}

// ContentEditable Adapter
class ContentEditableAdapter extends TextInputAdapterBase {
  constructor(element) {
    super(element);
    this.inputType = InputTypeDetector.analyze(element);
  }

  async replaceContent(text) {
    try {
      console.log('[ContentEditableAdapter] replaceContent called with:', {
        text,
        currentContent: this.element.textContent,
        cursorPosition: this.getCursorPosition()
      });

      const selection = window.getSelection();
      const range = selection.getRangeAt(0);
      
      // Get current cursor position
      const cursorPosition = range.startOffset;
      
      // Find the start of the trigger
      const currentContent = this.element.textContent;
      const triggerStart = Math.max(0, currentContent.lastIndexOf('/', cursorPosition));
      
      // Call replace with the correct range
      this.replace(triggerStart, cursorPosition, text);
      
      return true;
    } catch (error) {
      console.error('[Content Replacement Error]', error);
      return false;
    }
  }

  getText() {
    try {
      const selection = window.getSelection();
      const range = selection.getRangeAt(0);
      const preCursorRange = range.cloneRange();
      preCursorRange.collapse(true);
      preCursorRange.setStart(this.element, 0);
      const textBeforeCursor = preCursorRange.toString();
      
      return textBeforeCursor;
    } catch (error) {
      console.error('[ContentEditableAdapter] Error getting text:', error);
      return this.element.innerText || '';
    }
  }

  setText(text) {
    try {
      this.element.innerHTML = text;
    } catch (error) {
      console.error('[ContentEditableAdapter] Error setting text:', error);
      try {
        this.element.innerText = text;
      } catch (fallbackError) {
        console.error('[ContentEditableAdapter] Fallback setText failed:', fallbackError);
      }
    }
  }

  getCursorPosition() {
    try {
      const selection = window.getSelection();
      const range = selection.getRangeAt(0);
      const preCursorRange = range.cloneRange();
      preCursorRange.collapse(true);
      preCursorRange.setStart(this.element, 0);
      const position = preCursorRange.toString().length;
      
      return position;
    } catch (error) {
      console.error('[ContentEditableAdapter] Error getting cursor position:', error);
      return 0;
    }
  }

  replace(start, end, text) {
    try {
      // Create wrapper div to maintain structure
      const wrapper = document.createElement('div');
      
      // Convert newlines to <br> and wrap text in <p> tags
      const lines = text.split('\n');
      wrapper.innerHTML = lines.map(line => 
        line.trim() === '---' ? '<p class="marker">---</p>' : 
        line.trim() === '' ? '<p><br></p>' : 
        `<p>${line}</p>`
      ).join('');
      
      console.log('[DOM-Debug] Created structure:', {
        wrapperHTML: wrapper.innerHTML,
        wrapperText: wrapper.textContent,
        childNodes: Array.from(wrapper.childNodes).map(n => ({
          type: n.nodeType,
          name: n.nodeName,
          text: n.textContent,
          className: n.className
        }))
      });

      // Set range for replacement
      const currentContent = this.element.textContent;
      const rangeStart = start === end ? start : Math.max(0, currentContent.lastIndexOf('/', start));
      const rangeEnd = end;

      const startNode = this._getTextNodeAtPosition(rangeStart);
      const endNode = this._getTextNodeAtPosition(rangeEnd);
      
      const selection = window.getSelection();
      const range = selection.getRangeAt(0);
      range.setStart(startNode.node, startNode.offset);
      range.setEnd(endNode.node, endNode.offset);
      console.log('[ContentEditableAdapter] Range before deleteContents:', {
        rangeStart,
        rangeEnd,
        startNode: startNode ? {
          text: startNode.node.textContent,
          offset: startNode.offset,
          nodeType: startNode.node.nodeType,
          parentNode: startNode.node.parentNode?.nodeName
        } : null,
        endNode: endNode ? {
          text: endNode.node.textContent,
          offset: endNode.offset,
          nodeType: endNode.node.nodeType,
          parentNode: endNode.node.parentNode?.nodeName
        } : null
      });
      
      range.deleteContents();
      console.log('[ContentEditableAdapter] Range after deleteContents:', {
        rangeStart,
        rangeEnd,
        startNode: startNode ? {
          text: startNode.node.textContent,
          offset: startNode.offset,
          nodeType: startNode.node.nodeType,
          parentNode: startNode.node.parentNode?.nodeName
        } : null,
        endNode: endNode ? {
          text: endNode.node.textContent,
          offset: endNode.offset,
          nodeType: endNode.node.nodeType,
          parentNode: endNode.node.parentNode?.nodeName
        } : null
      });

      // Insert each node separately to maintain structure
      const fragment = document.createDocumentFragment();
      while (wrapper.firstChild) {
        fragment.appendChild(wrapper.firstChild);
      }
      range.insertNode(fragment);
      console.log('[ContentEditableAdapter] After replacement:', {
        newContent: this.element.textContent,
        expectedContent: currentContent.slice(0, rangeStart) + text + currentContent.slice(rangeEnd),
        hasNewlines: this.element.textContent.includes('\n'),
        newlineCount: this.element.textContent.split('\n').length,
        innerHTML: this.element.innerHTML,
        elementChildNodes: Array.from(this.element.childNodes).map(n => ({
          type: n.nodeType,
          name: n.nodeName,
          text: n.textContent
        }))
      });

      // Phase 3: Cursor Positioning
      if (text.includes('---')) {
        // Find the first marker
        const markers = this.element.querySelectorAll('.marker');
        if (markers.length > 0) {
          const firstMarker = markers[0];
          const newRange = document.createRange();
          
          // Position cursor after the first marker
          newRange.setStartAfter(firstMarker);
          newRange.collapse(true);
          
          console.log('[ContentEditableAdapter] Cursor positioning:', {
            markerFound: true,
            markerContent: firstMarker.textContent,
            markerNextSibling: firstMarker.nextSibling?.nodeName
          });

          // Update selection
          selection.removeAllRanges();
          selection.addRange(newRange);
          this.element.focus();
          
          console.log('[ContentEditableAdapter] Final selection:', {
            rangeCount: selection.rangeCount,
            isCollapsed: selection.isCollapsed,
            type: selection.type,
            anchorNode: selection.anchorNode?.textContent,
            focusNode: selection.focusNode?.textContent,
            anchorOffset: selection.anchorOffset,
            focusOffset: selection.focusOffset
          });
        }
      }
    } catch (error) {
      console.error('[ContentEditableAdapter] Error in replace:', error);
    }
  }

  _getTextNodes(node) {
    const textNodes = [];
    const walk = document.createTreeWalker(
      node,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );

    let currentNode;
    while (currentNode = walk.nextNode()) {
      textNodes.push(currentNode);
    }
    return textNodes;
  }

  _getTextNodeAtPosition(index) {
    try {
      const walker = document.createTreeWalker(
        this.element,
        NodeFilter.SHOW_TEXT,
        null,
        false
      );
      
      let node;
      let charsCount = 0;

      while ((node = walker.nextNode())) {
        const nodeLength = node.textContent.length;
        if (charsCount + nodeLength >= index) {
          return { node, offset: index - charsCount };
        }
        charsCount += nodeLength;
      }

      const lastNode = this.element.lastChild;
      return {
        node: lastNode,
        offset: lastNode ? lastNode.textContent.length : 0
      };
    } catch (error) {
      console.error('[ContentEditableAdapter] Error finding text node:', error);
      return { node: null, offset: 0 };
    }
  }

  _createFragment(html) {
    try {
      const fragment = document.createDocumentFragment();
      const tempDiv = document.createElement('div');
      
      const cursorMarker = '{cursor}';
      const cursorIndex = html.indexOf(cursorMarker);
      
      if (cursorIndex !== -1) {
        const beforeCursor = html.substring(0, cursorIndex);
        const afterCursor = html.substring(cursorIndex + cursorMarker.length);
        
        if (beforeCursor) {
          const processedBefore = beforeCursor.replace(/\n/g, '<br>').replace(/ {2}/g, ' &nbsp;');
          tempDiv.innerHTML = processedBefore;
          while (tempDiv.firstChild) {
            fragment.appendChild(tempDiv.firstChild);
          }
        }
        
        const cursorSpan = document.createElement('span');
        cursorSpan.className = 'cursor-placeholder';
        cursorSpan.style.display = 'none';
        fragment.appendChild(cursorSpan);
        
        if (afterCursor) {
          const processedAfter = afterCursor.replace(/\n/g, '<br>').replace(/ {2}/g, ' &nbsp;');
          tempDiv.innerHTML = processedAfter;
          while (tempDiv.firstChild) {
            fragment.appendChild(tempDiv.firstChild);
          }
        }
      } else {
        const processed = html.replace(/\n/g, '<br>').replace(/ {2}/g, ' &nbsp;');
        tempDiv.innerHTML = processed;
        while (tempDiv.firstChild) {
          fragment.appendChild(tempDiv.firstChild);
        }
      }
      
      return fragment;
    } catch (error) {
      console.error('[ContentEditableAdapter] Error creating fragment:', error);
      return document.createTextNode(html);
    }
  }

  _placeCursorAfterReplacement() {
    try {
      const cursorPlaceholder = this.element.querySelector('.cursor-placeholder');
      if (cursorPlaceholder) {
        const range = document.createRange();
        range.setStartAfter(cursorPlaceholder);
        range.collapse(true);
        
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
        
        cursorPlaceholder.remove();
      } else {
        const range = document.createRange();
        range.selectNodeContents(this.element);
        range.collapse(false);
        
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);
      }
    } catch (error) {
      console.error('[ContentEditableAdapter] Error placing cursor:', error);
    }
  }

  replaceContent(text) {
    try {
      const selection = window.getSelection();
      const range = selection.getRangeAt(0);
      
      // Get current cursor position
      const cursorPosition = range.startOffset;
      
      // Find the start of the trigger
      const currentContent = this.element.textContent;
      const triggerStart = Math.max(0, currentContent.lastIndexOf('/', cursorPosition));
      
      // Call replace with the correct range
      this.replace(triggerStart, cursorPosition, text);
      
      return true;
    } catch (error) {
      console.error('[Content Replacement Error]', error);
      return false;
    }
  }
}

// Adapter Factory
class AdapterFactory {
  static createFor(element) {
    const inputType = InputTypeDetector.analyze(element);
    
    try {
      let adapter;
      if (inputType.isContentEditable || inputType.parentContentEditable || inputType.role === 'textbox') {
        adapter = new ContentEditableAdapter(element);
      } else {
        adapter = new StandardInputAdapter(element);
      }
      
      return adapter;
    } catch (error) {
      console.error('[AdapterFactory] Error creating adapter:', error);
      return new StandardInputAdapter(element);
    }
  }
}

// File Content Management
class FileContentManager {
  static async inject(target, content) {
    const adapter = AdapterFactory.createFor(target);
    if (!adapter) {
      console.error('No suitable adapter found for target element');
      return null;
    }

    try {
      const currentText = adapter.getText();
      const endPosition = currentText.length;
      await adapter.replaceContent(content);
      return endPosition;
    } catch (error) {
      console.error('[FileContentManager] Error injecting file content:', error);
      return null;
    }
  }

  static isValidTarget(element) {
    return element && (
      element.isContentEditable || 
      element.tagName === 'TEXTAREA' || 
      element.tagName === 'INPUT'
    );
  }

  static getActiveInputElement() {
    const active = document.activeElement;
    return this.isValidTarget(active) ? active : null;
  }

  static getChatGPTInput() {
    const input = document.querySelector('#prompt-textarea');
    if (this.isValidTarget(input)) {
      input.focus();
      return input;
    }
    return null;
  }
}

// Make FileContentManager available globally
window.FileContentManager = FileContentManager;

// Main input handler
async function handleInput(target, isKeyboardHotkey = false, quickPromptOverride = null) {
  const adapter = AdapterFactory.createFor(target);
  if (!adapter) {
    return;
  }

  const cursorPosition = adapter.getCursorPosition();
  const currentText = adapter.getText();
  const typedText = currentText.slice(0, cursorPosition);
  
  console.log('[Input-Handler] Initial state:', {
    isKeyboardHotkey,
    cursorPosition,
    currentText,
    typedText
  });

  if (!window.inlineCompletion) {
    return;
  }

  // If triggered by keyboard hotkey or has override, use the provided quickprompt
  if (isKeyboardHotkey || quickPromptOverride) {
    const quickPrompt = quickPromptOverride || window.quickprompts[0];
    if (!quickPrompt) {
      console.error('[Input-Handler] No quickprompt available for hotkey');
      return;
    }

    try {
      let finalText = quickPrompt.replacementPrompt;
      console.log('[QuickPrompt] Initial text:', {
        text: finalText,
        length: finalText?.length,
        hasNewlines: finalText?.includes('\n'),
        newlineCount: finalText?.split('\n').length
      });

      if (!finalText) {
        console.error('[Input-Handler] No replacement text found in quickprompt:', quickPrompt);
        return;
      }

      // Process special Placeholders before DOM insertion
      finalText = await TextProcessor.handleSpecialPlaceholders(finalText);
      console.log('[QuickPrompt] After placeholder processing:', {
        text: finalText,
        length: finalText?.length,
        hasNewlines: finalText?.includes('\n'),
        newlineCount: finalText?.split('\n').length
      });

      if (!finalText || typeof finalText !== 'string') {
        console.error('[Input-Handler] Text processing failed:', finalText);
        return;
      }

      // Instead of using markers, structure the content with paragraphs
      const lines = finalText.split('\n');
      const formattedText = lines.map((line, index) => {
        if (line.trim() === '') return '<p><br></p>';
        return `<p>${line}</p>`;
      }).join('');

      console.log('[QuickPrompt] Formatted text:', {
        text: formattedText,
        length: formattedText?.length
      });

      // Replace at cursor position
      await adapter.replace(cursorPosition, cursorPosition, formattedText);

      // Position cursor after the first non-empty line
      const newNodes = Array.from(adapter.element.childNodes);
      let cursorNode = null;
      
      for (let i = 0; i < newNodes.length; i++) {
        const node = newNodes[i];
        if (node.textContent.trim() !== '') {
          cursorNode = newNodes[i + 1] || node;
          break;
        }
      }

      if (cursorNode) {
        const selection = window.getSelection();
        const range = document.createRange();
        
        if (cursorNode.firstChild) {
          range.setStart(cursorNode.firstChild, 0);
        } else {
          range.setStartAfter(cursorNode);
        }
        range.collapse(true);
        
        selection.removeAllRanges();
        selection.addRange(range);
        adapter.element.focus();
      }

      return;
    } catch (error) {
      console.error('[Input-Handler] Error in hotkey replacement:', error);
      return;
    }
  }

  if (typedText.endsWith('/') && typedText.length === cursorPosition) {
    return;
  }

  const lastSlashIndex = typedText.lastIndexOf('/');
  if (lastSlashIndex === -1 || lastSlashIndex === cursorPosition - 1) {
    if (window.inlineCompletion) {
      window.inlineCompletion.updateGhostText(target, null);
    }
    return;
  }

  const query = typedText.slice(lastSlashIndex + 1);

  const matches = window.quickprompts
    .filter(s => s.trigger.toLowerCase().startsWith(query.toLowerCase()))
    .sort((a, b) => {
      const aExact = a.trigger.toLowerCase() === query.toLowerCase();
      const bExact = b.trigger.toLowerCase() === query.toLowerCase();
      // First, prioritize exact matches
      if (aExact !== bExact) return aExact ? -1 : 1;
      // Then sort by order (lower order comes first)
      if (a.order !== b.order) return a.order - b.order;
      // Finally, sort by trigger length
      return a.trigger.length - b.trigger.length;
    });

  if (matches.length > 0) {
    const bestMatch = matches[0];
    const suggestionText = bestMatch.trigger.slice(query.length);

    if (window.inlineCompletion) {
      window.inlineCompletion.updateGhostText(target, suggestionText, bestMatch);
    }

    if (bestMatch.trigger.toLowerCase() === query.toLowerCase()) {
      try {
        let finalText = bestMatch.replacementPrompt;
        console.log('[QuickPrompt] Initial text:', {
          text: finalText,
          length: finalText?.length,
          hasNewlines: finalText?.includes('\n'),
          newlineCount: finalText?.split('\n').length
        });

        if (!finalText) {
          console.error('[Input-Handler] No replacement text found in match:', bestMatch);
          return;
        }

        // Process special Placeholders before DOM insertion
        finalText = await TextProcessor.handleSpecialPlaceholders(finalText);
        console.log('[QuickPrompt] After placeholder processing:', {
          text: finalText,
          length: finalText?.length,
          hasNewlines: finalText?.includes('\n'),
          newlineCount: finalText?.split('\n').length
        });

        if (!finalText || typeof finalText !== 'string') {
          console.error('[Input-Handler] Text processing failed:', finalText);
          return;
        }

        await adapter.replace(lastSlashIndex, cursorPosition, finalText);
        if (window.inlineCompletion) {
          window.inlineCompletion.updateGhostText(target, null);
        }
        
        // Trigger visual feedback
        const rect = target.getBoundingClientRect();
        const coords = {
          left: rect.left + (rect.width / 2),
          top: rect.top
        };
        FeedbackManager.triggerVisualFeedback(coords);
      } catch (error) {
        console.error('[Input-Handler] Error in replacement:', error);
      }
    }
  } else {
    if (window.inlineCompletion) {
      window.inlineCompletion.updateGhostText(target, null);
    }
  }
}

const debouncedHandler = (() => {
  let timeout;
  return (target, isKeyboardHotkey = false, quickPromptOverride = null) => {
    if (timeout) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(() => {
      // Only process if target is still active
      if (document.activeElement === target) {
        handleInput(target, isKeyboardHotkey, quickPromptOverride);
      }
    }, 30); // Reduced from 100ms to 30ms for faster response
  };
})();

document.addEventListener("input", async (event) => {
  const target = event.target;
  // Only process valid targets
  if (!FileContentManager.isValidTarget(target)) {
    return;
  }

  const adapter = AdapterFactory.createFor(target);
  if (!adapter) {
    return;
  }

  const cursorPosition = adapter.getCursorPosition();
  const currentText = adapter.getText();
  const textBeforeCursor = currentText.slice(0, cursorPosition);

  // Find last trigger sequence
  const lastSlashIndex = textBeforeCursor.lastIndexOf('/');
  const potentialTrigger = lastSlashIndex >= 0 ? textBeforeCursor.slice(lastSlashIndex) : '';
  
  // Clear ghost text if trigger is invalid
  if (potentialTrigger.length <= 1) {
    if (window.inlineCompletion) {
      window.inlineCompletion.updateGhostText(target, null);
    }
  }

  debouncedHandler(target);
});

document.addEventListener('keydown', (e) => {
  // First check for Tab completion
  if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
    const target = (FileContentManager.isValidTarget(e.target) ? e.target : null) || 
                  FileContentManager.getActiveInputElement();
    
    if (target && window.inlineCompletion && window.inlineCompletion.handleTab(target)) {
      e.preventDefault();
      e.stopPropagation();
    }
    return;
  }

  // Then check for keyboard hotkey
  const target = (FileContentManager.isValidTarget(e.target) ? e.target : null) || 
                FileContentManager.getActiveInputElement();
  
  if (!target) return;

  // Build key combination string
  const modifiers = [];
  if (e.ctrlKey) modifiers.push('Ctrl');
  if (e.altKey) modifiers.push('Alt');
  if (e.shiftKey) modifiers.push('Shift');
  if (e.metaKey) modifiers.push(navigator.platform.includes('Mac') ? 'Cmd' : 'Meta');
  
  const keyCombo = [...modifiers, e.key].join('+');
  
  // Find matching quickprompt
  const quickPrompt = window.quickprompts?.find(s => s.keyPress && s.keyPress.toLowerCase() === keyCombo.toLowerCase());
  
  if (quickPrompt) {
    e.preventDefault();
    e.stopPropagation();
    
    // Create adapter and get cursor position
    const adapter = AdapterFactory.createFor(target);
    if (!adapter) return;
    
    const cursorPos = adapter.getCursorPosition();
    
    console.log('[QuickPrompt] Hotkey detected:', {
      keyCombo,
      quickPrompt,
      cursorPos,
      currentContent: adapter.getText()
    });
    
    (async () => {
      try {
        // Process the replacement text
        let replacementPrompt = quickPrompt.replacementPrompt;
        console.log('[QuickPrompt] Initial text:', {
          text: replacementPrompt,
          length: replacementPrompt?.length,
          hasNewlines: replacementPrompt?.includes('\n'),
          newlineCount: replacementPrompt?.split('\n').length
        });

        if (!replacementPrompt) {
          console.error('[QuickPrompt] Invalid replacement text:', replacementPrompt);
          return;
        }

        // Process special placeholders
        replacementPrompt = await TextProcessor.handleSpecialPlaceholders(replacementPrompt);
        console.log('[QuickPrompt] After placeholder processing:', {
          text: replacementPrompt,
          length: replacementPrompt?.length,
          hasNewlines: replacementPrompt?.includes('\n'),
          newlineCount: replacementPrompt?.split('\n').length
        });

        if (!replacementPrompt || typeof replacementPrompt !== 'string') {
          console.error('[QuickPrompt] Text processing failed:', replacementPrompt);
          return;
        }

        // Instead of using markers, structure the content with paragraphs
        const lines = replacementPrompt.split('\n');
        const formattedText = lines.map((line, index) => {
          if (line.trim() === '') return '<p><br></p>';
          return `<p>${line}</p>`;
        }).join('');

        console.log('[QuickPrompt] Formatted text:', {
          text: formattedText,
          length: formattedText?.length
        });

        // Replace at cursor position
        await adapter.replace(cursorPos, cursorPos, formattedText);

        // Position cursor after the first non-empty line
        const newNodes = Array.from(adapter.element.childNodes);
        let cursorNode = null;
        
        for (let i = 0; i < newNodes.length; i++) {
          const node = newNodes[i];
          if (node.textContent.trim() !== '') {
            cursorNode = newNodes[i + 1] || node;
            break;
          }
        }

        if (cursorNode) {
          const selection = window.getSelection();
          const range = document.createRange();
          
          if (cursorNode.firstChild) {
            range.setStart(cursorNode.firstChild, 0);
          } else {
            range.setStartAfter(cursorNode);
          }
          range.collapse(true);
          
          selection.removeAllRanges();
          selection.addRange(range);
          adapter.element.focus();
        }

        // Trigger visual feedback
        const rect = target.getBoundingClientRect();
        const coords = {
          left: rect.left + (rect.width / 2),
          top: rect.top
        };
        FeedbackManager.triggerVisualFeedback(coords);
      } catch (error) {
        console.error('[QuickPrompt] Error executing quickprompt:', error);
      }
    })();
  }
});

document.addEventListener('mouseenter', (event) => {
}, true);

class TooltipManager {
  static createTooltip(message) {
    const tooltip = document.createElement('div');
    tooltip.className = 'custom-tooltip';
    tooltip.textContent = message;
    return tooltip;
  }

  static showTooltip(element, message) {
    let tooltip = element.querySelector('.custom-tooltip');
    if (!tooltip) {
      tooltip = this.createTooltip(message);
      element.appendChild(tooltip);
    }

    const updatePosition = () => {
      const rect = element.getBoundingClientRect();
      tooltip.style.display = 'block';
      tooltip.style.left = rect.left - tooltip.offsetWidth - 8 + 'px';
      tooltip.style.top = rect.top + (rect.height - tooltip.offsetHeight) / 2 + 'px';
    };

    updatePosition();
    window.addEventListener('resize', updatePosition);
    element.addEventListener('mouseleave', () => {
      tooltip.style.display = 'none';
      window.removeEventListener('resize', updatePosition);
    }, { once: true });
  }
}

const tooltipStyles = document.createElement('style');
tooltipStyles.textContent = `
  .custom-tooltip {
    position: absolute;
    background-color: #343541;
    color: #ECECF1;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    z-index: 10000;
    max-width: 200px;
    pointer-events: none;
    display: none;
    border: 1px solid #565869;
  }

  .custom-tooltip::after {
    content: '';
    position: absolute;
    right: -6px;
    top: 50%;
    transform: translateY(-50%);
    border-width: 6px 0 6px 6px;
    border-style: solid;
    border-color: transparent transparent transparent #343541;
  }
`;
document.head.appendChild(tooltipStyles);

class FeedbackManager {
  static async triggerVisualFeedback(coords) {
    try {
      // Get settings
      const data = await chrome.storage.sync.get('settings');
      const settings = data.settings || {};

      // Run effects in parallel for better performance
      await Promise.all([
        // Play sound if enabled
        playSound(),
        // Show confetti if celebration effects are enabled
        settings.celebration ? triggerConfetti(coords.left, coords.top) : Promise.resolve()
      ]);
    } catch (error) {
      console.error('[FeedbackManager] Error triggering feedback:', error);
    }
  }
}

// Initialize quickprompts and inline completion
(async function() {
  
  // Initialize navigation manager
  try {
    // Only initialize NavigationManager in chat interface
    if (window.location.hostname.includes('chatgpt.com') || window.location.hostname === 'localhost') {
      window.navigationManager = new window.NavigationManager();
      await window.navigationManager.initializationPromise;
    }
  } catch (error) {
    console.error('[Navigation-Init] Failed to initialize NavigationManager:', error);
  }
  
  // Initialize storage and load quickprompts
  try {
    await window.QuickPromptStorageManager.initialize();
    window.quickprompts = await window.QuickPromptStorageManager.getAllQuickPrompts();
  } catch (error) {
    // Fallback to default-quickprompts.json if storage fails
    try {
      window.quickprompts = await QuickPromptConfig.load();
    } catch (fallbackError) {
      console.error('[QuickPrompt-Init] Fallback load failed:', fallbackError);
    }
  }

  let initializationAttempts = 0;
  const maxAttempts = 10;
  const initializeInlineCompletion = () => {
    if (typeof InlineCompletion !== 'undefined') {
      window.inlineCompletion = new InlineCompletion();

      // Clear ghost text on scroll
      window.addEventListener('scroll', () => {
        if (window.inlineCompletion && window.inlineCompletion.currentSuggestion) {
          const target = FileContentManager.getActiveInputElement() || FileContentManager.getChatGPTInput();
          if (target) {
            window.inlineCompletion.updateGhostText(target, null);
          }
        }
      }, { passive: true });

      // Clear ghost text on window resize
      window.addEventListener('resize', () => {
        if (window.inlineCompletion && window.inlineCompletion.currentSuggestion) {
          const target = FileContentManager.getActiveInputElement() || FileContentManager.getChatGPTInput();
          if (target) {
            window.inlineCompletion.updateGhostText(target, null);
          }
        }
      }, { passive: true });

      // Clear ghost text on cursor movement or selection change
      document.addEventListener('selectionchange', () => {
        if (window.inlineCompletion && window.inlineCompletion.currentSuggestion) {
          const target = FileContentManager.getActiveInputElement() || FileContentManager.getChatGPTInput();
          if (target) {
            window.inlineCompletion.updateGhostText(target, null);
          }
        }
      }, { passive: true });

      // Clear ghost text on mouse up (after selection)
      document.addEventListener('mouseup', () => {
        if (window.inlineCompletion && window.inlineCompletion.currentSuggestion) {
          const target = FileContentManager.getActiveInputElement() || FileContentManager.getChatGPTInput();
          if (target) {
            window.inlineCompletion.updateGhostText(target, null);
          }
        }
      }, { passive: true });

      // Clear ghost text on key navigation
      document.addEventListener('keydown', (e) => {
        if (e.key.startsWith('Arrow') || e.key === 'Home' || e.key === 'End' || e.key === 'PageUp' || e.key === 'PageDown') {
          if (window.inlineCompletion && window.inlineCompletion.currentSuggestion) {
            const target = FileContentManager.getActiveInputElement() || FileContentManager.getChatGPTInput();
            if (target) {
              window.inlineCompletion.updateGhostText(target, null);
            }
          }
        }
      }, { passive: true });

    } else if (initializationAttempts < maxAttempts) {
      initializationAttempts++;
      setTimeout(initializeInlineCompletion, 100);
    } else {
    }
  };
  
  initializeInlineCompletion();
})();
