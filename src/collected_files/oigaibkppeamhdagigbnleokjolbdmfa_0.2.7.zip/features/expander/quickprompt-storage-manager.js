// QuickPrompt Storage Manager
class QuickPromptStorageManager {
    static STORAGE_KEY_PREFIX = 'quickprompts_chunk_';
    static METADATA_KEY = 'quickprompts_metadata';
    static CURRENT_VERSION = 1;
    static CHUNK_SIZE = 10; // Number of quickprompts per chunk

    /**
     * Validate a single quickprompt object
     * @param {Object} quickPrompt - The quickprompt to validate
     * @returns {Object} - { isValid: boolean, errors: string[], quickprompt: Object }
     */
    static validateQuickPrompt(quickPrompt) {
        const errors = [];
        
        // Check if quickPrompt is an object
        if (!quickPrompt || typeof quickPrompt !== 'object') {
            return { isValid: false, errors: ['QuickPrompt must be an object'] };
        }

        // Required fields
        if (!quickPrompt.trigger || typeof quickPrompt.trigger !== 'string' || quickPrompt.trigger.trim() === '') {
            errors.push('Trigger is required and must be a non-empty string');
        }
        if (!quickPrompt.replacementPrompt || typeof quickPrompt.replacementPrompt !== 'string') {
            errors.push('ReplacementPrompt is required and must be a string');
        }

        // Optional fields with defaults
        if ('order' in quickPrompt && (typeof quickPrompt.order !== 'number' || isNaN(quickPrompt.order))) {
            errors.push('Order must be a number if provided');
        }

        // Key press validation (optional field)
        if ('keyPress' in quickPrompt) {
            if (quickPrompt.keyPress === null || quickPrompt.keyPress === '') {
                // Both null and empty string are valid for no hotkey
                // Normalize to null for consistency
                quickPrompt.keyPress = null;
            } else if (typeof quickPrompt.keyPress !== 'string') {
                errors.push('KeyPress must be a string if provided');
            } else {
                const validModifiers = ['Ctrl', 'Alt', 'Shift', 'Cmd', 'Meta'];
                const parts = quickPrompt.keyPress.split('+');
                
                // Must end with a single character or number
                const key = parts[parts.length - 1];
                if (!/^[A-Z0-9]$/.test(key)) {
                    errors.push('KeyPress must end with a single uppercase letter or number');
                }

                // Check modifiers
                const modifiers = parts.slice(0, -1);
                if (!modifiers.every(mod => validModifiers.includes(mod))) {
                    errors.push('KeyPress modifiers must be one of: Ctrl, Alt, Shift, Cmd, Meta');
                }
            }
        }

        // Normalize trigger by removing invalid characters
        if (quickPrompt.trigger) {
            quickPrompt.trigger = quickPrompt.trigger.trim();
        }

        return {
            isValid: errors.length === 0,
            errors,
            quickprompt: quickPrompt // Return potentially normalized quickprompt
        };
    }

    /**
     * Validate an array of quickprompts
     * @param {Array} quickprompts - Array of quickprompts to validate
     * @returns {Object} - { isValid: boolean, errors: string[], validQuickPrompts: Array }
     */
    static validateQuickPrompts(quickprompts) {
        if (!Array.isArray(quickprompts)) {
            return { 
                isValid: false, 
                errors: ['QuickPrompts must be an array'],
                validQuickPrompts: []
            };
        }

        const errors = [];
        const validQuickPrompts = [];
        const triggers = new Map(); // Track triggers and their quickprompts

        quickprompts.forEach((quickPrompt, index) => {
            const { isValid, errors: quickpromptErrors, quickprompt: normalizedQuickPrompt } = this.validateQuickPrompt(quickPrompt);
            
            if (!isValid) {
                errors.push(`QuickPrompt at index ${index} is invalid: ${quickpromptErrors.join(', ')}`);
                return; // Skip invalid quickprompts
            }

            const trigger = normalizedQuickPrompt.trigger;
            
            // Always use the newest quickprompt for a given trigger
            if (triggers.has(trigger)) {
                // Remove old quickprompt
                const oldIndex = validQuickPrompts.findIndex(qp => qp.trigger === trigger);
                if (oldIndex !== -1) {
                    validQuickPrompts.splice(oldIndex, 1);
                }
            }
            
            // Add new quickprompt
            triggers.set(trigger, normalizedQuickPrompt);
            validQuickPrompts.push(normalizedQuickPrompt);
        });

        return {
            isValid: true,
            errors,
            validQuickPrompts: validQuickPrompts.sort((a, b) => a.order - b.order)
        };
    }

    /**
     * Split quickprompts into chunks that fit within Chrome's storage limits
     */
    static _splitIntoChunks(quickprompts) {
        const chunks = [];
        for (let i = 0; i < quickprompts.length; i += this.CHUNK_SIZE) {
            chunks.push(quickprompts.slice(i, i + this.CHUNK_SIZE));
        }
        return chunks;
    }

    /**
     * Get all chunk keys from metadata
     */
    static async _getChunkKeys() {
        const metadata = await chrome.storage.sync.get(this.METADATA_KEY);
        return metadata[this.METADATA_KEY]?.chunkKeys || [];
    }

    /**
     * Initialize the storage system
     */
    static async initialize() {
        try {
            // Set up storage change listener
            chrome.storage.onChanged.addListener((changes, area) => {
                if (area === 'sync') {
                    // Check if any of our chunks changed
                    const chunkChanges = Object.keys(changes).filter(key => 
                        key.startsWith(this.STORAGE_KEY_PREFIX) || key === this.METADATA_KEY
                    );
                    
                    if (chunkChanges.length > 0) {
                        // Reload all quickprompts
                        this.getAllQuickPrompts().then(quickprompts => {
                            window.quickprompts = quickprompts;
                            console.debug('[Storage] QuickPrompts updated from storage change');
                        });
                    }
                }
            });

            // Try to load quickprompts from storage first
            const quickprompts = await this.getAllQuickPrompts();
            if (quickprompts && Array.isArray(quickprompts) && quickprompts.length > 0) {
                // Validate existing quickprompts
                const { isValid, validQuickPrompts, errors } = this.validateQuickPrompts(quickprompts);
                if (!isValid) {
                    console.warn('[Storage] Some quickprompts were invalid:', errors);
                }
                window.quickprompts = validQuickPrompts;
                console.debug('[Storage] Loaded existing quickprompts:', validQuickPrompts.length);
                return;
            }

            // If no quickprompts in storage, migrate from default-quickprompts.json
            await this.migrateFromJson();
            console.debug('[Storage] Migration complete');
        } catch (error) {
            console.error('[Storage] Initialization failed:', error);
            throw error;
        }
    }

    /**
     * Load quickprompts from default-quickprompts.json and store them
     */
    static async migrateFromJson() {
        try {
            // Clear existing quickprompts first
            await this.clearAllQuickPrompts();
            
            const defaultQuickPrompts = await QuickPromptConfig.load();
            const { isValid, validQuickPrompts, errors } = this.validateQuickPrompts(defaultQuickPrompts);

            if (errors.length > 0) {
                console.warn('[Storage] Some quickprompts were invalid during migration:', errors);
            }

            if (validQuickPrompts.length === 0) {
                throw new Error('No valid quickprompts found in default-quickprompts.json');
            }

            await this.setAllQuickPrompts(validQuickPrompts);
            window.quickprompts = validQuickPrompts;

        } catch (error) {
            console.error('[Storage] Migration failed:', error);
            throw error;
        }
    }

    /**
     * Get all QuickPrompts from storage, falling back to defaults if none exist
     */
    static async getAllQuickPrompts() {
        try {
            // Get metadata first
            const metadata = await chrome.storage.sync.get(this.METADATA_KEY);
            const chunkKeys = metadata[this.METADATA_KEY]?.chunkKeys || [];
            
            // If no chunk keys, return empty array
            if (chunkKeys.length === 0) {
                return [];
            }

            // Load all chunks
            const chunks = await chrome.storage.sync.get(chunkKeys);
            
            // Combine all quickprompts from chunks
            let allQuickPrompts = [];
            chunkKeys.forEach(key => {
                if (chunks[key] && Array.isArray(chunks[key])) {
                    allQuickPrompts = allQuickPrompts.concat(chunks[key]);
                }
            });

            // Ensure order field exists and sort
            allQuickPrompts = allQuickPrompts
                .map((quickprompt, index) => ({
                    ...quickprompt,
                    order: typeof quickprompt.order === 'number' ? quickprompt.order : index
                }))
                .sort((a, b) => a.order - b.order);

            return allQuickPrompts;
        } catch (error) {
            console.error('[Storage] Error getting quickprompts:', error);
            throw error;
        }
    }

    /**
     * Save quickprompts to storage in chunks
     */
    static async setAllQuickPrompts(quickprompts) {
        try {
            // Handle empty array case explicitly
            if (!Array.isArray(quickprompts) || quickprompts.length === 0) {
                // Clear all existing chunks
                const oldChunkKeys = await this._getChunkKeys();
                if (oldChunkKeys.length > 0) {
                    await chrome.storage.sync.remove(oldChunkKeys);
                }

                // Update metadata to reflect empty state
                await chrome.storage.sync.set({
                    [this.METADATA_KEY]: {
                        version: this.CURRENT_VERSION,
                        lastUpdate: new Date().toISOString(),
                        chunkKeys: []
                    }
                });

                window.quickprompts = [];
                return;
            }

            // Validate non-empty arrays
            const { isValid, validQuickPrompts, errors } = this.validateQuickPrompts(quickprompts);
            
            if (errors.length > 0) {
                console.warn('[Storage] Some quickprompts were invalid:', errors);
            }

            if (validQuickPrompts.length === 0) {
                throw new Error('No valid quickprompts to save');
            }

            // Ensure order field is present and valid
            const updatedQuickPrompts = validQuickPrompts.map((quickprompt, index) => ({
                ...quickprompt,
                order: typeof quickprompt.order === 'number' ? quickprompt.order : index
            }));

            const oldChunkKeys = await this._getChunkKeys();
            if (oldChunkKeys.length > 0) {
                await chrome.storage.sync.remove(oldChunkKeys);
            }

            const chunks = this._splitIntoChunks(updatedQuickPrompts);
            const chunkKeys = [];
            const storageUpdates = {};

            // Prepare chunks for storage
            chunks.forEach((chunk, index) => {
                const key = `${this.STORAGE_KEY_PREFIX}${index}`;
                chunkKeys.push(key);
                storageUpdates[key] = chunk;
            });

            // Update metadata with chunk keys
            storageUpdates[this.METADATA_KEY] = {
                version: this.CURRENT_VERSION,
                lastUpdate: new Date().toISOString(),
                chunkKeys: chunkKeys
            };

            // Save everything
            await chrome.storage.sync.set(storageUpdates);
            window.quickprompts = updatedQuickPrompts;
        } catch (error) {
            console.error('[Storage] Failed to save quickprompts:', error);
            throw error;
        }
    }

    /**
     * Update quickprompts
     */
    static async updateQuickPrompts(quickprompts) {
        const { isValid, errors, validQuickPrompts } = this.validateQuickPrompts(quickprompts);
        
        if (!isValid) {
            console.error('[Storage] Invalid quickprompts:', errors);
            throw new Error('Invalid quickprompts: ' + errors.join(', '));
        }

        try {
            // Ensure order field is present and valid
            const updatedQuickPrompts = validQuickPrompts.map((quickprompt, index) => ({
                ...quickprompt,
                order: typeof quickprompt.order === 'number' ? quickprompt.order : index
            }));

            // Clear existing chunks
            const oldChunkKeys = await this._getChunkKeys();
            if (oldChunkKeys.length > 0) {
                await chrome.storage.sync.remove(oldChunkKeys);
            }

            // Split quickprompts into chunks
            const chunks = this._splitIntoChunks(updatedQuickPrompts);
            const chunkKeys = [];
            const storageUpdates = {};

            // Prepare chunks for storage
            chunks.forEach((chunk, index) => {
                const key = `${this.STORAGE_KEY_PREFIX}${index}`;
                chunkKeys.push(key);
                storageUpdates[key] = chunk;
            });

            // Update metadata with chunk keys
            storageUpdates[this.METADATA_KEY] = {
                version: this.CURRENT_VERSION,
                lastUpdate: new Date().toISOString(),
                chunkKeys: chunkKeys
            };

            // Save everything
            await chrome.storage.sync.set(storageUpdates);
            window.quickprompts = updatedQuickPrompts;
            return true;
        } catch (error) {
            console.error('[Storage] Failed to save quickprompts:', error);
            throw error;
        }
    }

    /**
     * Add a new quickprompt
     */
    static async addQuickPrompt(quickprompt) {
        // Validate single quickprompt before adding
        const { isValid, errors } = this.validateQuickPrompt(quickprompt);
        if (!isValid) {
            throw new Error(`Invalid quickprompt: ${errors.join(', ')}`);
        }

        try {
            const quickprompts = await this.getAllQuickPrompts();
            // Check for duplicate trigger
            if (quickprompts.some(s => s.trigger === quickprompt.trigger)) {
                throw new Error(`QuickPrompt with trigger "${quickprompt.trigger}" already exists`);
            }
            quickprompts.push(quickprompt);
            await this.setAllQuickPrompts(quickprompts);
        } catch (error) {
            console.error('[Storage] Failed to add quickprompt:', error);
            throw error;
        }
    }

    /**
     * Update an existing QuickPrompt
     * @param {string} oldTrigger - The original trigger to update
     * @param {Object} updatedQuickPrompt - The new quickprompt data
     */
    static async updateQuickPrompt(oldTrigger, updatedQuickPrompt) {
        // Validate updated quickprompt
        const { isValid, errors } = this.validateQuickPrompt(updatedQuickPrompt);
        if (!isValid) {
            throw new Error(`Invalid quickprompt update: ${errors.join(', ')}`);
        }

        try {
            const quickprompts = await this.getAllQuickPrompts();
            
            // Find the QuickPrompt to update using the old trigger
            const index = quickprompts.findIndex(s => s.trigger === oldTrigger);
            if (index === -1) {
                throw new Error(`QuickPrompt with trigger "${oldTrigger}" not found`);
            }

            // If trigger is being changed, ensure new trigger doesn't conflict
            if (oldTrigger !== updatedQuickPrompt.trigger) {
                const conflictIndex = quickprompts.findIndex(s => s.trigger === updatedQuickPrompt.trigger);
                if (conflictIndex !== -1 && conflictIndex !== index) {
                    throw new Error(`QuickPrompt with trigger "${updatedQuickPrompt.trigger}" already exists`);
                }
            }

            // Update the quickprompt
            quickprompts[index] = { ...quickprompts[index], ...updatedQuickPrompt };
            await this.setAllQuickPrompts(quickprompts);
        } catch (error) {
            console.error('[Storage] Failed to update quickprompt:', error);
            throw error;
        }
    }

    /**
     * Delete a quickprompt
     */
    static async deleteQuickPrompt(trigger) {
        if (!trigger || typeof trigger !== 'string') {
            throw new Error('Invalid trigger');
        }

        try {
            const quickprompts = await this.getAllQuickPrompts();
            const filteredQuickPrompts = quickprompts.filter(s => s.trigger !== trigger);
            if (filteredQuickPrompts.length === quickprompts.length) {
                throw new Error(`QuickPrompt with trigger "${trigger}" not found`);
            }
            await this.setAllQuickPrompts(filteredQuickPrompts);
        } catch (error) {
            console.error('[Storage] Failed to delete quickprompt:', error);
            throw error;
        }
    }

    /**
     * Clear all quickprompts
     */
    static async clearAllQuickPrompts() {
        try {
            const chunkKeys = await this._getChunkKeys();
            await chrome.storage.sync.remove(chunkKeys);
            await chrome.storage.sync.remove(this.METADATA_KEY);
            return true;
        } catch (error) {
            console.error('Error clearing quickprompts:', error);
            throw error;
        }
    }
}

// Make QuickPromptStorageManager available globally
window.QuickPromptStorageManager = QuickPromptStorageManager;
