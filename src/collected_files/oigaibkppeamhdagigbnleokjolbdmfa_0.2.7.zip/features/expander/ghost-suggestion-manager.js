// Inline Completion Manager
class InlineCompletion {
    constructor() {
        this.ghostOverlay = null;
        this.currentSuggestion = null;
        this.currentMatch = null;
        this.initialized = false;
        this.initializationPromise = this.initialize();
        this._updateTimeout = null;
    }

    async initialize() {
        try {
            // Create ghost overlay if it doesn't exist
            if (!this.ghostOverlay) {
                // Wait for DOM to be ready
                if (document.readyState !== 'complete') {
                    await new Promise(resolve => {
                        document.addEventListener('readystatechange', () => {
                            if (document.readyState === 'complete') {
                                resolve();
                            }
                        });
                    });
                }

                this.ghostOverlay = document.createElement('div');
                this.ghostOverlay.className = 'quickprompt-ghost-overlay';
                document.body.appendChild(this.ghostOverlay);
                
                // Add necessary styles
                const styles = document.createElement('style');
                styles.textContent = `
                    .quickprompt-ghost-overlay {
                        position: fixed;
                        pointer-events: none;
                        color: #666;
                        opacity: 0.8;
                        font-family: inherit;
                        font-size: inherit;
                        white-space: pre-wrap;
                        overflow-wrap: break-word;
                        padding: 0;
                        margin: -2px 0 0 0;
                        z-index: 99999;
                        background: transparent;
                        border: none;
                        outline: none;
                        resize: none;
                        overflow: hidden;
                        display: block;
                        visibility: visible;
                        min-width: 1px;
                        min-height: 1px;
                    }
                    
                    @media (prefers-color-scheme: dark) {
                        .quickprompt-ghost-overlay {
                            color: #999999;
                        }
                    }
                `;
                document.head.appendChild(styles);
                this.initialized = true;
            }
        } catch (error) {
            console.error('[Ghost-Text] Initialization error:', error);
            throw error;
        }
    }

    getCaretPosition(input) {
        try {
            // Only handle textarea elements
            if (!input || input.tagName !== 'TEXTAREA') return null;

            // Create mirror div with memoization
            const mirrorDiv = this.getMirrorDiv(input);
            
            // Get text up to caret with validation
            const selectionStart = Math.min(input.selectionStart, input.value.length);
            if (selectionStart === null || selectionStart === undefined) {
                console.warn('[Ghost-Text] Invalid selection start');
                return null;
            }
            
            const textBeforeCaret = input.value.substring(0, selectionStart);
            
            // Create content with a span at caret position
            mirrorDiv.textContent = textBeforeCaret;
            const span = document.createElement('span');
            span.textContent = '.';
            mirrorDiv.appendChild(span);
            
            // Add to DOM for measurement with cleanup guarantee
            document.body.appendChild(mirrorDiv);
            
            try {
                // Get coordinates with validation
                const inputRect = input.getBoundingClientRect();
                const spanRect = span.getBoundingClientRect();
                const divRect = mirrorDiv.getBoundingClientRect();
                
                if (!this.isValidRect(inputRect) || !this.isValidRect(spanRect) || !this.isValidRect(divRect)) {
                    console.warn('[Ghost-Text] Invalid rectangle measurements');
                    return null;
                }
                
                // Calculate real position with scroll compensation
                const caretPos = {
                    top: inputRect.top + (spanRect.top - divRect.top) - input.scrollTop,
                    left: inputRect.left + (spanRect.left - divRect.left) - input.scrollLeft
                };
                
                return caretPos;
            } finally {
                // Ensure cleanup happens
                if (mirrorDiv.parentNode) {
                    document.body.removeChild(mirrorDiv);
                }
            }
        } catch (error) {
            console.error('[Ghost-Text] Error calculating caret position:', error);
            return null;
        }
    }

    // Helper method to validate rectangle measurements
    isValidRect(rect) {
        return rect && 
               typeof rect.top === 'number' && 
               typeof rect.left === 'number' && 
               !isNaN(rect.top) && 
               !isNaN(rect.left);
    }

    // Memoized mirror div creation with style synchronization
    getMirrorDiv(input) {
        const div = document.createElement('div');
        const computed = window.getComputedStyle(input);
        
        // Get essential styles for accurate text measurement
        const essentialStyles = [
            'font-family', 'font-size', 'font-weight', 'font-style',
            'letter-spacing', 'line-height', 'text-transform', 'word-spacing',
            'padding-left', 'padding-right', 'padding-top', 'padding-bottom',
            'border-left-width', 'border-right-width', 'border-top-width', 'border-bottom-width',
            'box-sizing', 'white-space', 'word-wrap', 'overflow-wrap'
        ];

        // Copy computed styles
        const styles = essentialStyles.reduce((acc, style) => {
            acc[style] = computed.getPropertyValue(style);
            return acc;
        }, {});

        // Apply essential positioning styles
        div.style.cssText = `
            position: absolute;
            top: -9999px;
            left: -9999px;
            width: ${input.offsetWidth}px;
            height: ${input.offsetHeight}px;
            visibility: hidden;
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-wrap: break-word;
        `;

        // Apply computed styles
        Object.assign(div.style, styles);

        return div;
    }

    async updateGhostText(input, suggestion, match = null) {
        console.debug('[Ghost-Update] Starting update:', {
            inputTag: input?.tagName,
            suggestion,
            matchTrigger: match?.trigger,
            currentState: {
                suggestion: this.currentSuggestion,
                matchTrigger: this.currentMatch?.trigger
            }
        });

        const STATE_CHECK_INTERVAL = 16;
        const MAX_RETRIES = 5;
        const DISPLAY_STATES = {
            PENDING: 'pending',
            VISIBLE: 'visible',
            HIDDEN: 'hidden'
        };

        let displayState = DISPLAY_STATES.PENDING;
        let retryCount = 0;

        // Debounce rapid updates
        if (this._updateTimeout) {
            clearTimeout(this._updateTimeout);
        }

        return new Promise((resolve) => {
            this._updateTimeout = setTimeout(async () => {
                try {
                    const success = await this._performUpdate(input, suggestion, match);
                    resolve(success);
                } catch (error) {
                    console.error('[Ghost-Text] Update failed:', error);
                    this.destroy();
                    resolve(false);
                }
            }, 10);
        });
    }

    async _performUpdate(input, suggestion, match) {
        console.debug('[Ghost-Debug] Starting _performUpdate:', {
            inputType: input?.tagName,
            isContentEditable: input?.isContentEditable,
            hasSelection: window.getSelection().rangeCount > 0,
            selectionCollapsed: window.getSelection().isCollapsed,
            activeElement: document.activeElement === input ? 'same' : 'different'
        });

        if (!input || !document.body.contains(input)) {
            console.warn('[Ghost-Text] Invalid input element');
            return false;
        }

        try {
            // Initialize if needed
            if (!this.ghostOverlay) {
                await this.initialize();
            }

            // Ensure the overlay is in the DOM
            if (!document.body.contains(this.ghostOverlay)) {
                document.body.appendChild(this.ghostOverlay);
            }

            // If no suggestion or input not visible, hide ghost text
            if (!suggestion || !this._isInViewport(input)) {
                this.currentSuggestion = null;
                this.currentMatch = null;
                this.ghostOverlay.style.display = 'none';
                return false;
            }

            // Update content
            this.ghostOverlay.textContent = suggestion;
            this.currentSuggestion = suggestion;
            this.currentMatch = match;

            // Function to update ghost text position
            const updatePosition = () => {
                if (!this.currentSuggestion || !this._isInViewport(input)) {
                    this.ghostOverlay.style.display = 'none';
                    return;
                }

                const coords = input.tagName === 'TEXTAREA' ? 
                    this.getCaretPosition(input) : 
                    this._getSelectionCoords();
                
                if (coords) {
                    this.ghostOverlay.style.display = 'block';
                    this.ghostOverlay.style.top = `${coords.top}px`;
                    this.ghostOverlay.style.left = `${coords.left}px`;
                } else {
                    this.ghostOverlay.style.display = 'none';
                }
            };

            // Clear existing scroll listeners
            if (input._scrollListeners) {
                input._scrollListeners.forEach(({ element, listener }) => {
                    element.removeEventListener('scroll', listener);
                });
            }
            input._scrollListeners = [];

            // Add scroll listeners to input and all scrollable parents
            const addScrollListener = (element) => {
                const listener = () => {
                    requestAnimationFrame(updatePosition);
                };
                element.addEventListener('scroll', listener, { passive: true });
                input._scrollListeners.push({ element, listener });
            };

            // Add listener to input itself
            addScrollListener(input);

            // Find and add listeners to scrollable parents
            let parent = input.parentElement;
            while (parent) {
                const style = window.getComputedStyle(parent);
                if (['auto', 'scroll'].includes(style.overflowY) || 
                    ['auto', 'scroll'].includes(style.overflowX)) {
                    addScrollListener(parent);
                }
                parent = parent.parentElement;
            }

            // Initial position update
            updatePosition();

            return true;
        } catch (error) {
            console.error('[Ghost-Text] Update error:', error);
            return false;
        }
    }

    // Helper function to check if element is in viewport
    _isInViewport(element) {
        try {
            const rect = element.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        } catch (error) {
            console.error('[Ghost-Text] Viewport check error:', error);
            return false;
        }
    }

    async _verifyVisibility() {
        try {
            // Basic existence check
            if (!this.ghostOverlay || !document.body.contains(this.ghostOverlay)) {
                return false;
            }

            // Ensure visibility
            Object.assign(this.ghostOverlay.style, {
                display: 'block',
                visibility: 'visible',
                opacity: '0.8'
            });

            return true;
        } catch (error) {
            console.error('[Ghost-Text] Visibility check error:', error);
            return false;
        }
    }

    _getSelectionCoords() {
        try {
            const selection = window.getSelection();
            if (selection.rangeCount > 0) {
                const range = selection.getRangeAt(0);
                const rect = range.getBoundingClientRect();
                
                // Log selection and range details
                console.debug('[Selection-Debug] Selection details:', {
                    rangeCount: selection.rangeCount,
                    isCollapsed: selection.isCollapsed,
                    rangeRect: {
                        top: rect.top,
                        left: rect.left,
                        bottom: rect.bottom,
                        right: rect.right
                    }
                });

                // Get the contenteditable element
                let element = range.startContainer;
                while (element && element.nodeType !== Node.ELEMENT_NODE) {
                    element = element.parentNode;
                }

                if (element) {
                    // Log element and its scroll info
                    console.debug('[Scroll-Debug] Element details:', {
                        tagName: element.tagName,
                        isContentEditable: element.isContentEditable,
                        scrollTop: element.scrollTop,
                        scrollLeft: element.scrollLeft,
                        clientHeight: element.clientHeight,
                        scrollHeight: element.scrollHeight,
                        rect: element.getBoundingClientRect()
                    });

                    // Log parent scroll containers
                    let parent = element.parentElement;
                    let scrollParents = [];
                    while (parent) {
                        const style = window.getComputedStyle(parent);
                        const isScrollable = ['auto', 'scroll'].includes(style.overflowY) ||
                                          ['auto', 'scroll'].includes(style.overflowX);
                        
                        if (isScrollable) {
                            scrollParents.push({
                                tagName: parent.tagName,
                                id: parent.id,
                                className: parent.className,
                                scrollTop: parent.scrollTop,
                                scrollLeft: parent.scrollLeft,
                                rect: parent.getBoundingClientRect()
                            });
                        }
                        parent = parent.parentElement;
                    }

                    console.debug('[Scroll-Debug] Scrollable parents:', scrollParents);
                }

                if (rect.top !== 0 || rect.left !== 0) {
                    // Log final coordinates
                    console.debug('[Position-Debug] Final coordinates:', {
                        top: rect.top,
                        left: rect.left,
                        windowScroll: {
                            scrollY: window.scrollY,
                            scrollX: window.scrollX
                        }
                    });
                    
                    return {
                        top: rect.top,
                        left: rect.left
                    };
                }
            }
        } catch (error) {
            console.error('[Ghost-Text] Selection coords error:', error);
        }
        return null;
    }

    async handleTab(eventOrInput) {
        console.debug('[Tab-State] Pre-handle state:', {
            currentSuggestion: this.currentSuggestion,
            currentMatch: this.currentMatch,
            ghostOverlayVisible: this.ghostOverlay?.style.display !== 'none',
            eventType: eventOrInput instanceof Event ? 'event' : 'direct',
            inputType: eventOrInput?.tagName || eventOrInput?.target?.tagName
        });

        if (!this.currentSuggestion || !this.currentMatch) {
            console.debug('[Tab-State] No suggestion/match - current state:', {
                hasSuggestion: !!this.currentSuggestion,
                hasMatch: !!this.currentMatch,
                ghostText: this.ghostOverlay?.textContent
            });
            return;
        }

        // Handle both event and direct input calls
        const isEvent = eventOrInput instanceof Event;
        const input = isEvent ? eventOrInput.target : eventOrInput;

        console.debug('[Tab-State] Input resolution:', {
            isEvent,
            inputTag: input?.tagName,
            inputType: input?.type,
            inputId: input?.id,
            activeElement: document.activeElement === input ? 'same' : 'different'
        });

        // Only prevent default if it's an event
        if (isEvent) {
            eventOrInput.preventDefault();
            eventOrInput.stopPropagation();
        }

        const adapter = AdapterFactory.createFor(input);
        if (!adapter) {
            console.debug('[Tab-Handler] Adapter creation failed:', {
                inputTag: input?.tagName,
                inputType: input?.type,
                inputId: input?.id,
                validInput: isValidInput(input),
                adapterType: adapter?.constructor?.name
            });
            return;
        }

        const cursorPos = adapter.getCursorPosition();
        const currentText = adapter.getText();
        
        console.debug('[Tab-Handler] Text retrieval:', {
            hasAdapter: !!adapter,
            cursorPos,
            textLength: currentText?.length,
            inputElement: {
                tag: input?.tagName,
                type: input?.type,
                value: input?.value?.length
            }
        });

        // Get the text to insert
        let textToInsert = this.currentMatch.replacementPrompt;
        console.debug('[Execution-Path] Starting text replacement:', {
            hasTextProcessor: !!TextProcessor,
            hasHandlePlaceholders: !!(TextProcessor?.handleSpecialPlaceholders),
            replacementPrompt: textToInsert,
            matchDetails: {
                trigger: this.currentMatch.trigger,
                hasProcessor: !!(this.currentMatch.processPlaceholders)
            }
        });

        if (!textToInsert) {
            console.debug('[Tab-Handler] No replacement text found');
            return;
        }

        try {
            console.debug('[Execution-Path] Before placeholder processing');
            textToInsert = await TextProcessor.handleSpecialPlaceholders(textToInsert);
            console.debug('[Execution-Path] After placeholder processing:', {
                processedText: textToInsert
            });
        } catch (error) {
            console.error('[Execution-Path] Error in placeholder processing:', error);
        }

        // Find the last slash before cursor
        const lastSlashIndex = currentText.lastIndexOf('/', cursorPos);
        if (lastSlashIndex === -1) {
            console.warn('[Tab-Handler] No trigger sequence found');
            return;
        }

        // Replace the text
        adapter.replace(lastSlashIndex, cursorPos, textToInsert);
        
        // Clear the ghost text and trigger effects
        this.updateGhostText(input, '');
        
        // Run effects in parallel
        Promise.all([
            // Play sound effect
            window.playSound?.().catch(error => {
                console.error('[Effects] Sound playback failed:', error);
            }),
            
            // Show confetti effect
            (async () => {
                try {
                    if (window.triggerConfetti) {
                        const rect = input.getBoundingClientRect();
                        const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
                        const scrollY = window.pageYOffset || document.documentElement.scrollTop;
                        
                        // Calculate position at the trigger text
                        const x = rect.left + scrollX;
                        const y = rect.top + scrollY + (rect.height / 2);
                        
                        await window.triggerConfetti(x, y);
                    }
                } catch (error) {
                    console.error('[Effects] Confetti effect failed:', error);
                }
            })()
        ]).catch(error => {
            console.error('[Effects] Error running effects:', error);
        });

        return true;
    }

    // Clean up when needed
    destroy() {
        if (this.ghostOverlay) {
            this.ghostOverlay.remove();
            this.ghostOverlay = null;
        }
    }
}

// Make InlineCompletion available globally
window.InlineCompletion = InlineCompletion;
