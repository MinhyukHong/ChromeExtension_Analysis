// Navigation Manager for ChatGPT message traversal
console.debug('[Navigation-Debug] Loading navigation-manager.js');

class NavigationManager {
    constructor() {
        console.debug('[Navigation-Debug] NavigationManager constructor called');
        this.state = {
            messages: [],
            initialized: false,
            currentIndex: -1,
            quickPromptButtons: [] // Track buttons for cleanup
        };
        this.initializationPromise = this.initialize();
        
        // Setup storage change listener
        chrome.storage.onChanged.addListener(this._handleStorageChange.bind(this));
    }

    // Handle storage changes
    _handleStorageChange(changes, namespace) {
        if (namespace !== 'sync') return;
        
        // Check if quickprompts changed
        const isQuickPromptsChange = Object.keys(changes).some(key => 
            key.startsWith(QuickPromptStorageManager.STORAGE_KEY_PREFIX) || 
            key === QuickPromptStorageManager.METADATA_KEY
        );
        
        if (isQuickPromptsChange && this.isInitialized()) {
            console.debug('[NavigationManager] QuickPrompts changed, recreating buttons');
            this._recreateQuickPromptButtons();
        }
    }

    // Clean up existing quickprompt buttons
    _cleanupQuickPromptButtons() {
        console.debug('[NavigationManager] Cleaning up buttons:', this.state.quickPromptButtons.length);
        this.state.quickPromptButtons.forEach(button => {
            if (button && button.parentNode) {
                button.parentNode.removeChild(button);
            }
        });
        this.state.quickPromptButtons = [];
    }

    // Recreate all quickprompt buttons
    async _recreateQuickPromptButtons() {
        if (!this.isChatInterface()) {
            console.debug('[NavigationManager] Not in chat interface, skipping button recreation');
            return;
        }

        try {
            // Clean up existing buttons
            this._cleanupQuickPromptButtons();

            // Get latest quickprompts
            const prompts = await QuickPromptStorageManager.getAllQuickPrompts();
            console.debug('[NavigationManager] Creating buttons for prompts:', prompts);

            // Create new buttons
            let visibleButtonCount = 0;
            prompts.forEach(prompt => {
                if (prompt.showButton === false) {
                    console.debug(`[NavigationManager] Skipping button for /${prompt.trigger} (showButton: false)`);
                    return;
                }

                const button = this.createButton(
                    `quickprompt-${prompt.trigger}`, 
                    () => this.insertQuickPrompt(prompt.trigger)
                );
                
                button.innerHTML = `/${prompt.trigger}`;
                button.title = prompt.keyPress 
                    ? `${prompt.replacementPrompt} (${prompt.keyPress})`
                    : prompt.replacementPrompt;
                button.style.cssText = `
                    ${button.style.cssText}
                    top: ${260 + (visibleButtonCount * 32)}px !important;
                    font-family: monospace;
                    font-size: 12px;
                    padding: 0 8px;
                    width: auto !important;
                    min-width: 50px;
                    background-color: var(--main-surface-tertiary);
                    color: var(--text-primary);
                `;

                document.body.appendChild(button);
                this.state.quickPromptButtons.push(button);
                visibleButtonCount++;
            });

            console.debug('[NavigationManager] Created buttons:', visibleButtonCount);
        } catch (error) {
            console.error('[NavigationManager] Error recreating buttons:', error);
        }
    }

    async initialize() {
        if (this.isInitialized()) {
            console.debug('[NavigationManager] Already initialized');
            return;
        }

        // Wait for the DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.initializeAfterDelay());
        } else {
            this.initializeAfterDelay();
        }
    }

    initializeAfterDelay() {
        // Give the page a moment to fully render
        setTimeout(async () => {
            try {
                this.updateMessagesList();
                this.setupMutationObserver();
                this.setupKeyboardControls();
                await this.createNavigationButtons();
                
                this.state.initialized = true;
                console.debug('[NavigationManager] Initialized successfully');
            } catch (error) {
                console.error('[NavigationManager] Error during initialization:', error);
            }
        }, 1000); // Wait 1 second for the page to settle
    }

    updateMessagesList() {
        this.state.messages = Array.from(
            document.querySelectorAll('[data-testid^="conversation-turn-"]')
        );
        console.debug('[NavigationManager] Messages list updated:', 
            this.state.messages.length);
    }

    setupMutationObserver() {
        // Watch for new messages being added
        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList') {
                    this.updateMessagesList();
                }
            }
        });

        // Start observing the chat container
        const chatContainer = document.querySelector('main');
        if (chatContainer) {
            observer.observe(chatContainer, {
                childList: true,
                subtree: true
            });
            console.debug('[NavigationManager] MutationObserver setup complete');
        }
    }

    setupKeyboardControls() {
        document.addEventListener('keydown', (event) => {
            // Command/Ctrl + ArrowUp/ArrowDown for navigation
            if (event.metaKey || event.ctrlKey) {  // metaKey for Mac, ctrlKey for Windows
                if (event.key === 'ArrowDown') {
                    event.preventDefault();
                    this.navigateToMessage('next');
                } else if (event.key === 'ArrowUp') {
                    event.preventDefault();
                    this.navigateToMessage('previous');
                }
            }
        });
        console.debug('[NavigationManager] Keyboard controls setup complete (⌘/Ctrl + ↑/↓)');
    }

    async createNavigationButtons() {
        console.debug('[NavigationManager] Creating navigation buttons');
        
        // Create up button
        const upButton = this.createButton('up', () => this.navigateToMessage('previous'));
        upButton.title = 'Previous message (⌘/Ctrl + ↑)';
        upButton.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-2xl" style="transform: scale(0.75);">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M15.1918 8.90615C15.6381 8.45983 16.3618 8.45983 16.8081 8.90615L21.9509 14.049C22.3972 14.4953 22.3972 15.2189 21.9509 15.6652C21.5046 16.1116 20.781 16.1116 20.3347 15.6652L17.1428 12.4734V22.2857C17.1428 22.9169 16.6311 23.4286 15.9999 23.4286C15.3688 23.4286 14.8571 22.9169 14.8571 22.2857V12.4734L11.6652 15.6652C11.2189 16.1116 10.4953 16.1116 10.049 15.6652C9.60265 15.2189 9.60265 14.4953 10.049 14.049L15.1918 8.90615Z" fill="currentColor"></path>
            </svg>
        `;

        // Create down button
        const downButton = this.createButton('down', () => this.navigateToMessage('next'));
        downButton.title = 'Next message (⌘/Ctrl + ↓)';
        downButton.innerHTML = `
            <svg width="16" height="16" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="icon-2xl" style="transform: scale(0.75);">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M16.8081 23.0938C16.3618 23.5402 15.6381 23.5402 15.1918 23.0938L10.049 17.951C9.60265 17.5047 9.60265 16.7811 10.049 16.3348C10.4953 15.8884 11.219 15.8884 11.6653 16.3348L14.8571 19.5266V9.71429C14.8571 9.0831 15.3688 8.57143 15.9999 8.57143C16.6311 8.57143 17.1428 9.0831 17.1428 9.71429V19.5266L20.3347 16.3348C20.781 15.8884 21.5046 15.8884 21.9509 16.3348C22.3972 16.7811 22.3972 17.5047 21.9509 17.951L16.8081 23.0938Z" fill="currentColor"></path>
            </svg>
        `;

        // Add navigation buttons to the document
        document.body.appendChild(upButton);
        document.body.appendChild(downButton);

        // Only add QuickPrompt buttons if we're in the chat interface
        if (this.isChatInterface()) {
            await this._recreateQuickPromptButtons();
        }

        // Fade out buttons after delay
        setTimeout(() => {
            upButton.style.opacity = "0.2";
            downButton.style.opacity = "0.2";
            if (this.isChatInterface()) {
                document.querySelectorAll('[id^="quickprompt-"]').forEach(button => {
                    button.style.opacity = "0.2";
                });
            }
        }, 3500);
    }

    createButton(type, onClick) {
        const button = document.createElement('button');
        button.id = `${type}Button`;
        button.classList.add('chatGPT-scroll-btn', 'cursor-pointer', 'absolute', 'right-6', 'z-10', 'rounded-full', 'border');
        
        const top = type === 'up' ? '196px' : type === 'down' ? '228px' : '260px';
        button.style.cssText = `
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: var(--main-surface-tertiary);
            color: var(--text-primary);
            opacity: 0.8;
            width: 25.33px;
            height: 25.33px;
            border-radius: 50%;
            position: fixed;
            top: ${top};
            right: 16px;
            z-index: 10000;
            transition: opacity 1s;
        `;

        // Add hover effects
        button.addEventListener('mouseover', () => {
            button.style.opacity = "1";
        });

        button.addEventListener('mouseleave', () => {
            button.style.transition = "opacity 1s";
            button.style.opacity = "0.2";
        });

        button.addEventListener('click', () => {
            onClick();
            this.feedbackAnimation(button);
        });

        return button;
    }

    async insertQuickPrompt(trigger) {
        console.debug('[NavigationManager] insertQuickPrompt called with trigger:', trigger);
        
        const textarea = document.querySelector('#prompt-textarea');
        console.debug('[NavigationManager] Found textarea:', !!textarea);
        
        if (!textarea || !FileContentManager.isValidTarget(textarea)) {
            console.debug('[NavigationManager] Could not find valid chat input');
            return;
        }

        // Find the matching quickprompt
        const prompt = window.quickprompts?.find(p => p.trigger === trigger);
        console.debug('[NavigationManager] Found matching prompt:', prompt);
        
        if (!prompt) {
            console.debug('[NavigationManager] No matching QuickPrompt found for trigger:', trigger);
            return;
        }

        // First focus the textarea
        console.debug('[NavigationManager] Before focus - Active element:', document.activeElement?.tagName);
        textarea.focus();
        console.debug('[NavigationManager] After focus - Active element:', document.activeElement?.tagName, 'Is textarea focused:', document.activeElement === textarea);

        const adapter = AdapterFactory.createFor(textarea);
        if (adapter) {
            try {
                let finalText = prompt.replacementPrompt;
                if (!finalText) {
                    console.error('[NavigationManager] No replacement text found in prompt:', prompt);
                    return;
                }

                // Process special Placeholders before DOM insertion
                finalText = await TextProcessor.handleSpecialPlaceholders(finalText);
                
                // Get the current text and cursor position
                const currentText = adapter.getText();
                const cursorPosition = adapter.getCursorPosition();
                
                // First append the trigger text at the cursor position
                const triggerText = `/${trigger}`;
                const beforeTrigger = currentText.slice(0, cursorPosition);
                const afterTrigger = currentText.slice(cursorPosition);
                adapter.setText(beforeTrigger + triggerText + afterTrigger);
                
                // Then replace just the trigger portion with the final text
                await adapter.replace(cursorPosition, cursorPosition + triggerText.length, finalText);
                
                // Trigger visual feedback
                const rect = textarea.getBoundingClientRect();
                const coords = {
                    left: rect.left + (rect.width / 2),
                    top: rect.top
                };
                FeedbackManager.triggerVisualFeedback(coords);
            } catch (error) {
                console.error('[NavigationManager] Error replacing text:', error);
            }
        }
    }

    navigateToMessage(direction) {
        const { messages, currentIndex } = this.state;
        if (!messages.length) return;

        let nextIndex;
        if (direction === 'next') {
            nextIndex = currentIndex < messages.length - 1 ? currentIndex + 1 : messages.length - 1;
        } else {
            nextIndex = currentIndex > 0 ? currentIndex - 1 : 0;
        }

        // If no message is currently selected, start from the nearest visible message
        if (currentIndex === -1) {
            nextIndex = this.findNearestVisibleMessageIndex();
        }

        if (nextIndex !== currentIndex) {
            this.scrollToMessage(messages[nextIndex]);
            this.state.currentIndex = nextIndex;
            console.debug(`[NavigationManager] Navigated to message ${nextIndex + 1}/${messages.length}`);
        }
    }

    findNearestVisibleMessageIndex() {
        const { messages } = this.state;
        const viewportMiddle = window.innerHeight / 2;
        
        let nearestIndex = 0;
        let smallestDistance = Infinity;

        messages.forEach((message, index) => {
            const rect = message.getBoundingClientRect();
            const distance = Math.abs(rect.top + rect.height / 2 - viewportMiddle);
            if (distance < smallestDistance) {
                smallestDistance = distance;
                nearestIndex = index;
            }
        });

        return nearestIndex;
    }

    scrollToMessage(message) {
        if (!message) return;
        
        // Scroll the message into view with smooth animation
        message.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });

        // Add a brief highlight effect
        message.style.transition = 'background-color 0.3s ease';
        message.style.backgroundColor = 'rgba(255, 255, 0, 0.2)';
        
        setTimeout(() => {
            message.style.backgroundColor = '';
            // Clean up after animation
            setTimeout(() => {
                message.style.transition = '';
            }, 300);
        }, 500);
    }

    feedbackAnimation(button) {
        button.style.transform = 'scale(0.8)';
        setTimeout(() => {
            button.style.transform = 'scale(1)';
        }, 200);
    }

    isInitialized() {
        return this.state.initialized;
    }

    isChatInterface() {
        // Check multiple elements that indicate we're in the chat interface
        const chatInput = document.querySelector('textarea[data-id="root"]') || 
                         document.querySelector('form textarea');
        const chatContainer = document.querySelector('main div.flex.flex-col.text-sm') || 
                            document.querySelector('main div.overflow-y-auto');
        const conversationContainer = document.querySelector('div.flex.flex-col.items-center') || 
                                    document.querySelector('div[role="presentation"]');
        
        // Debug logging for interface detection
        const interfaceState = {
            chatInput: !!chatInput,
            chatContainer: !!chatContainer,
            conversationContainer: !!conversationContainer
        };
        console.debug('[NavigationManager] isChatInterface check:', interfaceState);
        
        // Return true if at least 2 out of 3 elements are found
        const elementsFound = [chatInput, chatContainer, conversationContainer].filter(Boolean).length;
        return elementsFound >= 2;
    }
}

// Make NavigationManager available globally
console.debug('[Navigation-Debug] Making NavigationManager available globally');
window.NavigationManager = NavigationManager;
console.debug('[NavigationManager] NavigationManager exposed to window:', !!window.NavigationManager);

// Create and initialize NavigationManager
console.debug('[Navigation-Debug] Creating NavigationManager instance');
window.navigationManager = new NavigationManager();
