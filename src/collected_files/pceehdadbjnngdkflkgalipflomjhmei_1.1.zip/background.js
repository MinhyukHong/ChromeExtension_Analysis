var domain = "uso.news";
var ul = "https://" + domain;

chrome.runtime.setUninstallURL("https://" + domain + "/uninstall");
chrome.action.onClicked.addListener(function (info, tab) {
  if (info.menuItemId == "main_page") {
    chrome.tabs.create({
      url: chrome.runtime.getURL(ul),
    });
  }
});

chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason == "install") {
    chrome.cookies.getAll({ "domain": domain },
      function (cookies) {
        try {
          var link = "https://trk." + domain + "/c/?at=install";
          for (var i = 0; i < cookies.length; i++) {
            switch (cookies[i]["name"]) {
              case "sub1":
                link += "&cid=" + encodeURIComponent(cookies[i]["value"]);
                break;
              case "sub2":
                link += "&channel=" + encodeURIComponent(cookies[i]["value"]);
                break;
              case "sub3":
                link += "&fid=" + encodeURIComponent(cookies[i]["value"]);
                break;
              case "clkid":
                link += "&clkid=" + encodeURIComponent(cookies[i]["value"]);
                break;
              case "tsp":
                link += "&tsp=" + encodeURIComponent(cookies[i]["value"]);
                break;
            }
          }
          fetch(link);
        } catch (e) {
          console.log(e);
        }
      });
    chrome.cookies.set(
      {
        url: ul,
        domain: "." + domain,
        expirationDate: Math.floor(Date.now() / 1000) + 604800,
        name: "first_inst",
        path: "/",
        secure: false,
        value: "1"
      }
    );
  }
});