import { onWebRequestCompleted } from './lib/webRequest.js';
import { onCommitted } from './lib/webNavigation.js';
import { removeTabConnections } from './lib/tabConnections.js';

// service worker is not waked up on webRequest: https://stackoverflow.com/a/66618269/643514

chrome.runtime.onInstalled.addListener(async () => {
  console.log('extension installed');
  await chrome.action.setBadgeBackgroundColor({ color: '#db2b27' });
  chrome.storage.local.get(null, (items) => console.log(items));
});

chrome.webNavigation.onCommitted.addListener(onCommitted);

chrome.webRequest.onCompleted.addListener(onWebRequestCompleted, { urls: ['<all_urls>'] });

chrome.tabs.onRemoved.addListener(async (tabId) => {
  await removeTabConnections(tabId);
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (sender.tab && message === 'getTabId') {
    sendResponse(sender.tab.id);
  } else {
    sendResponse();
  }
});

chrome.tabs.onReplaced.addListener((addedTabId, removedTabId) => {
  //TODO: handle tab replace. at least rename keys in storage. https://stackoverflow.com/q/17756258/643514
});
