import { CONNECTION_LINES_SOURCE, CONNECTION_POINTS_SOURCE } from './sources.js';

/** @type {import('mapbox-gl').LineLayer } */
export const CONNECTION_LINES_LAYER = {
  id: 'connection-lines',
  source: CONNECTION_LINES_SOURCE,
  type: 'line',
  layout: {
    'line-cap': 'round',
    'line-join': 'round',
  },
  paint: {
    'line-color': ['case', ['boolean', ['get', 'warning']], '#d50000', '#00c853'],
    'line-width': 2,
    'line-blur': 1,
  },
};

/** @type {import('mapbox-gl').CircleLayer } */
export const CONNECTION_POINTS_LAYER = {
  id: 'connection-points',
  source: CONNECTION_POINTS_SOURCE,
  type: 'circle',
  paint: {
    'circle-color': ['case', ['boolean', ['get', 'warning']], '#d50000', '#00c853'],
    'circle-radius': 4,
    'circle-stroke-width': 2,
    'circle-stroke-color': '#fff',
  },
};
