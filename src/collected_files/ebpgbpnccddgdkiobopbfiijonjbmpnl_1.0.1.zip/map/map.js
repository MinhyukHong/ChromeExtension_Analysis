import mapboxgl from 'mapbox-gl';
import { listenConnections } from '../lib/connection.js';
import { getCenter } from './getCenter.js';
import { CONNECTION_LINES_LAYER, CONNECTION_POINTS_LAYER } from './layers.js';
import { CONNECTION_LINES_SOURCE, CONNECTION_POINTS_SOURCE } from './sources.js';
import { empty, toLines, toPoints } from './transform.js';

const statusLoader =  /** @type {HTMLDivElement} */ (document.getElementById('loader'));
const statusLocationOff =  /** @type {HTMLDivElement} */ (document.getElementById('location-off'));
const token = 'pk.eyJ1IjoibWFjcGF3IiwiYSI6ImNsMm9uMW55ODE4aHYzaW11enB4a2N1azYifQ.9YBzXVJ-_bDq4XLU87PI2Q';

/** @type {import('../index').Connection[]} */
let connections = [];
/** @type {import('../index').ConnectionLineFeature[]} */
let connectionLines = [];
/** @type {import('../index').ConnectionPointFeature[]} */
let connectionPoints = [];

(async () => {
  /** @type {[number, number]} */
  let center = [0, 0];

  try {
    center = await getCenter();
  } catch (error) {
    statusLoader.hidden = true;
    statusLocationOff.hidden = false;
    alert(error);
    return;
  }

  const map = new mapboxgl.Map({
    accessToken: token,
    container: 'map',
    style: 'mapbox://styles/mapbox/light-v10',
    center,
    zoom: 3,
    minZoom: 2,
  });

  // disable pitch and rotation
  map.dragRotate.disable();
  map.touchZoomRotate.disableRotation();

  await map.once('load');
  statusLoader.hidden = true;

  map.addSource(CONNECTION_LINES_SOURCE, { type: 'geojson', data: empty });
  map.addSource(CONNECTION_POINTS_SOURCE, { type: 'geojson', data: empty });

  addLayers();
  addEvents();

  listenConnections((items) => {
    connections = items.filter((c) => c.lat && c.lng);
    connectionLines = toLines(center, connections);
    connectionPoints = toPoints(connections);
    refreshSource();
  });

  function refreshSource() {
    const lines = /** @type {import('mapbox-gl').GeoJSONSource} */ (map.getSource(CONNECTION_LINES_SOURCE));
    const points = /** @type {import('mapbox-gl').GeoJSONSource} */ (map.getSource(CONNECTION_POINTS_SOURCE));
    lines.setData({ type: 'FeatureCollection', features: connectionLines });
    points.setData({ type: 'FeatureCollection', features: connectionPoints });
  }

  function addLayers() {
    map.addLayer(CONNECTION_LINES_LAYER);
    map.addLayer(CONNECTION_POINTS_LAYER);
  }

  function addEvents() {
    map.on('mouseenter', CONNECTION_POINTS_LAYER.id, () => {
      map.getCanvas().style.cursor = 'pointer';
    });

    map.on('mouseleave', CONNECTION_POINTS_LAYER.id, () => {
      map.getCanvas().style.cursor = '';
    });

    map.on('click', CONNECTION_POINTS_LAYER.id, (event) => {
      if (!event.features) return;
      const feature = event.features[0];
      if (feature.geometry.type !== 'Point') return;
      if (!feature.properties) return;
      /** @type {[number, number]} */
      const coordinates = [feature.geometry.coordinates[0], feature.geometry.coordinates[1]];

      // Ensure that if the map is zoomed out such that multiple
      // copies of the feature are visible, the popup appears
      // over the copy being pointed to.
      while (Math.abs(event.lngLat.lng - coordinates[0]) > 180) {
        coordinates[0] += event.lngLat.lng > coordinates[0] ? 360 : -360;
      }

      /** @type {string} */
      const idsString = feature.properties.ids;

      /** @type {string[]} */
      const ids = JSON.parse(idsString);

      const container = document.createElement('div');
      container.classList.add('popup-container');


      ids.forEach((id) => {
        const connection = connections.find((connection) => connection.id === id);
        if (!connection) return;

        const row = document.createElement('div');
        row.classList.add('popup-row');
        container.appendChild(row);

        const initiator = document.createElement('div');
        initiator.textContent = connection.initiator || connection.host;
        initiator.title = initiator.textContent;
        initiator.classList.add('popup-initiator');
        row.appendChild(initiator);

        const arrow = document.createElement('div');
        arrow.textContent = '➝';
        arrow.classList.add('popup-arrow');
        row.appendChild(arrow);

        const destination = document.createElement('div');
        destination.textContent = connection.host;
        destination.title = destination.textContent;
        destination.classList.add('popup-destination');
        row.appendChild(destination);
      });

      new mapboxgl.Popup()
        .setMaxWidth('400px')
        .setLngLat(coordinates)
        .setHTML(container.outerHTML)
        .addTo(map);
    });
  }
})();

(() => {
  const isMac = navigator.platform.indexOf('Mac') > -1;
  const mac = /** @type {HTMLDivElement[]} */ (Array.from(document.querySelectorAll('[data-platform="mac"]')));
  const pc = /** @type {HTMLDivElement[]} */ (Array.from(document.querySelectorAll('[data-platform="pc"]')));
  if (isMac) {
    mac.forEach((element) => element.hidden = false);
  } else {
    pc.forEach((element) => element.hidden = false);
  }
})();
