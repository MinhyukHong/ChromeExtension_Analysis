export const CONNECTION_LINES_SOURCE = 'source-lines';
export const CONNECTION_POINTS_SOURCE = 'source-points';
