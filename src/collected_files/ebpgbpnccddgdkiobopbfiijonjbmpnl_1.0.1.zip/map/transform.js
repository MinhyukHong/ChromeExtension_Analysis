import * as turf from '@turf/turf';

/**
 * @param {[number, number]} center
 * @param {import('../index').Connection[]} connections
 * @return {import('../index').ConnectionLineFeature[]}
 */
export function toLines(center, connections) {
  /** @type {Map<string, import('../index').ConnectionLineFeature>} */
  const cache = new Map();

  for (const connection of connections) {
    const { lng, lat } = connection;
    if (!lat || !lng) continue;

    const key = `${lng}|${lat}`;
    const record = cache.get(key);

    if (record) {
      record.properties.ids.push(connection.id);
      continue;
    }

    /** @type {import('../index').ConnectionLineFeature} */
    const feature = {
      type: 'Feature',
      properties: {
        ids: [connection.id],
        warning: connection.isWarning,
      },
      geometry: {
        type: 'LineString',
        coordinates: [center],
      },
    };

    const distance = turf.length({
      type: 'Feature',
      properties: {},
      geometry: {
        type: 'LineString',
        coordinates: [center, [lng, lat]],
      },
    });

    let i = 0;
    while (true) {
      i = Math.min(i + 0.005, 1);
      const arc = turf.along({
        type: 'Feature',
        properties: {},
        geometry: {
          type: 'LineString',
          coordinates: [center, [lng, lat]],
        },
      }, distance * i);
      feature.geometry.coordinates.push(arc.geometry.coordinates);
      if (i === 1) break;
    }

    cache.set(key, feature);
  }

  return Array.from(cache.values());
}

/**
 * @param {import('../index').Connection[]} connections
 * @return {import('../index').ConnectionPointFeature[]}
 */
export function toPoints(connections) {
  /** @type {Map<string, import('../index').ConnectionPointFeature>} */
  const cache = new Map();

  for (const connection of connections) {
    const { lng, lat } = connection;
    if (!lat || !lng) continue;

    const key = `${lng}|${lat}`;
    const record = cache.get(key);

    if (record) {
      record.properties.ids.push(connection.id);
      continue;
    }

    /** @type {import('../index').ConnectionPointFeature} */
    const feature = {
      type: 'Feature',
      properties: {
        ids: [connection.id],
        warning: connection.isWarning,
      },
      geometry: {
        type: 'Point',
        coordinates: [lng, lat],
      },
    };

    cache.set(key, feature);
  }

  return Array.from(cache.values());
}

/** @type {import('geojson').FeatureCollection} */
export const empty = { type: 'FeatureCollection', features: [] };
