/**
 * @return {Promise<[number, number]>}
 */
export function getCenter() {
  return new Promise((resolve, reject) => {
    const sessionKey = 'center';
    const session = sessionStorage.getItem(sessionKey);

    if (session) {
      try {
        const center = JSON.parse(session);
        return resolve(center);
      } catch (error) {
        // invalid session value
        sessionStorage.removeItem(sessionKey)
      }
    }

    navigator.geolocation.getCurrentPosition((position) => {
      const { longitude, latitude } = position.coords;
      sessionStorage.setItem(sessionKey, JSON.stringify([longitude, latitude]));
      resolve([longitude, latitude]);
    }, (error) => {
      console.error(error);
      reject(error.message);
    });
  });
}
