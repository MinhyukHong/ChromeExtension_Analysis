import {Feature, LineString, Point} from 'geojson';

export type GeoIPResponse = {
  city: {
    lat: number
    long: number
  }
  country: {
    iso_code: string
  }
}

export type LocationResponse = {
  lng?: number
  lat?: number
  country?: string
}

export type Connection = {
  id: string
  tabId: number
  url: string
  host: string
  ip: string
  lng?: number
  lat?: number
  country?: string
  initiator?: string
  isWarning?: boolean
  warningReason?: 'ip' | 'domain'
}

export type Tree = {
  type: string
  attributes?: { [key: string]: string }
  events?: { [key: string]: (event: any) => void }
  value?: string
  children?: Tree[]
}

export type ConnectionProperties = {
  ids: string[]
  warning?: boolean
}

export type ConnectionLineFeature = Feature<LineString, ConnectionProperties>;
export type ConnectionPointFeature = Feature<Point, ConnectionProperties>;
