const rootId = 'SpyBuster';
const localStorageKey = 'spy-buster';
const isMuted = () => Boolean(localStorage.getItem(localStorageKey));

const styles = (function () {
  return {
    container: rootId,
    header: `${rootId}-Header`,
    logo: `${rootId}-Logo`,
    title: `${rootId}-Title`,
    connections: `${rootId}-Connections`,
    connection: `${rootId}-Connection`,
    close: `${rootId}-Close`,
    hint: `${rootId}-Hint`,
  }
})();

if (!isMuted()) {
  chrome.runtime.sendMessage('getTabId', initialize);
}

/**
 * @param {number} tabId
 */
function initialize(tabId) {
  const tabStorageKey = `tab:${tabId}`;
  chrome.storage.onChanged.addListener(storageListener);

  /**
   * @param {{[key: string]: chrome.storage.StorageChange}} changes
   * @returns {Promise<void>}
   */
  async function storageListener(changes) {
    if (!changes[tabStorageKey]) return;
    if (isMuted()) {
      chrome.storage.onChanged.removeListener(storageListener);
      return;
    }

    /** @type {import('../index').Connection[]} */
    const connections = (await chrome.storage.local.get(tabStorageKey))[tabStorageKey] || [];
    const warnings = connections.filter(c => c.isWarning);
    if (!warnings.length) return;
    if (!document.body) return;

    render(warnings);
  }
}

function getRoot() {
  const existingRoot = document.getElementById(rootId);
  if (existingRoot) return existingRoot;
  const newRoot = document.createElement('div');
  newRoot.id = rootId;
  document.body.appendChild(newRoot);
  return newRoot;
}

function closeNotification() {
  const root = document.getElementById(rootId);
  if (!root) return;
  root.outerHTML = '';
  localStorage.setItem(localStorageKey, 'closed');
}

/**
 * @param {import('../index').Connection[]} connections
 */
function render(connections) {
  const root = getRoot();

  /** @type {import('../index').Tree} */
  const tree = {
    type: 'div',
    attributes: {
      class: styles.container,
    },
    children: [
      {
        type: 'div',
        attributes: {
          class: styles.header,
        },
        children: [
          {
            type: 'div',
            attributes: {
              class: styles.logo,
            },
            children: [
              {
                type: 'img',
                attributes: {
                  src: chrome.runtime.getURL('/static/logo.svg'),
                  alt: 'SpyBuster',
                },
              },
              {
                type: 'text',
                value: 'SpyBuster',
              },
            ],
          },
          {
            type: 'button',
            attributes: {
              type: 'button',
              class: styles.close,
            },
            events: {
              click: closeNotification,
            },
            children: [
              {
                type: 'img',
                attributes: {
                  src: chrome.runtime.getURL('/static/close.svg'),
                  alt: 'Close',
                },
              }
            ],
          },
        ],
      },
      {
        type: 'div',
        attributes: {
          class: styles.connections,
        },
        children: [
          {
            type: 'div',
            attributes: {
              class: styles.title,
            },
            children: [
              {
                type: 'text',
                value: 'Website has suspicious connections',
              },
            ],
          },
          {
            type: 'div',
            attributes: {
              class: styles.connection,
              title: document.location.host,
            },
            children: [
              {
                type: 'text',
                value: document.location.host,
              },
            ],
          }
        ],
      },
      {
        type: 'div',
        attributes: {
          class: styles.hint,
        },
        // add open popup button when https://github.com/GoogleChrome/developer.chrome.com/issues/2602 is fixed
        children: [
          {
            type: 'text',
            value: 'See details in the SpyBuster extension',
          },
        ],
      }
    ],
  };

  root.innerHTML = '';
  root.appendChild(tree2dom(tree));
}

/**
 * @param {import('../index').Tree} tree
 * @returns {HTMLElement | Text}
 */
function tree2dom(tree) {
  const { type, attributes, value, events, children } = tree;

  if (type === 'text' && value) {
    return document.createTextNode(value);
  }

  const node = document.createElement(type);

  if (attributes) {
    Object.keys(attributes).forEach((key) => {
      node.setAttribute(key, attributes[key]);
    });
  }

  if (events) {
    Object.keys(events).forEach((key) => {
      node.addEventListener(key, events[key]);
    });
  }

  if (children) {
    children.forEach((child) => {
      node.appendChild(tree2dom(child));
    });
  }

  return node;
}
