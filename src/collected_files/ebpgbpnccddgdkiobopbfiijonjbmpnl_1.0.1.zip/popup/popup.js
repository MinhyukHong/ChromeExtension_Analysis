import { listenConnections } from '../lib/connection.js';

const empty = /** @type {HTMLDivElement} */ (document.querySelector('#empty'));
const list = /** @type {HTMLDivElement} */ (document.querySelector('#list'));
const listItems = /** @type {HTMLDivElement} */ (document.querySelector('#list-items'));

(async () => {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tabs.length) return;
  const tabId = tabs[0].id;
  if (!tabId) return;

  listenConnections((connections) => {
    render(connections);
  }, tabId);
})();

/**
 * @param {import('../index').Connection[]} connections
 */
async function render(connections) {
  const warnings = connections.filter(c => c.isWarning);

  if (!warnings.length) {
    empty.hidden = false;
    list.hidden = true;
    return;
  }

  listItems.innerHTML = '';

  warnings.forEach((warning) => {
    const hostNode = document.createElement('div');
    hostNode.classList.add('list-host');
    hostNode.textContent = warning.host;

    const reasonNode = document.createElement('div');
    reasonNode.classList.add('list-reason');
    reasonNode.textContent = warning.warningReason === 'ip' ? 'ru server' : 'ru domain';

    listItems.prepend(hostNode, reasonNode);
  });

  empty.hidden = true;
  list.hidden = false;
}

// tabs
(() => {
  const buttons = /** @type {HTMLButtonElement[]} */ (Array.from(document.querySelectorAll('[data-tab]')));
  const containers = /** @type {HTMLDivElement[]} */ (Array.from(document.querySelectorAll('[data-for]')));
  buttons.forEach((button) => {
    button.addEventListener('click', () => {
      const targetAttribute = button.getAttribute('data-tab');

      buttons.forEach((button) => {
        button.classList.remove('-active');
      });

      containers.forEach((container) => {
        container.hidden = true;
      });

      button.classList.add('-active');

      const targetContainer = containers.find((container) => {
        return container.getAttribute('data-for') === targetAttribute;
      });

      if (targetContainer) {
        targetContainer.hidden = false;
      }
    });
  })
})();
