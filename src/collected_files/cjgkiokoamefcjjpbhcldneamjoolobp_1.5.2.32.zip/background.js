var config = appEnvironment;

chrome.webRequest.onHeadersReceived.addListener(function (obj) {
    return true;
}, {
    urls: ['<all_urls>'],
    types: ['main_frame', 'sub_frame', 'stylesheet', 'script', 'image', 'object', 'xmlhttprequest', 'other']
}, ['blocking', 'responseHeaders']);

var periodInMinutesAlarmNotifyAck = 10;

chrome.extension.onMessage.addListener(function (request, sender, sendResponse) {
    if (request['method'] == '_wab_settings') {
        wbxValidate();
        sendResponse(localStorage)
    } else if (request['method'] == '_wab_connection') {
        chrome.browserAction.setIcon({
            path: (request['connected'] ? 'icon48.png' : 'icon48_off.png')
        })
    } else if (request['method'] == '_wab_refresh') {
        chrome.tabs.query({url: "https://web.whatsapp.com/*"}, function (tabs){
            tabs.forEach(tab => {
                chrome.tabs.reload(tab.id, {bypassCache: true});
            })
        });
    } else if (request['method'] == '_wab_ack') {
        console.log("on ack", new Date());
        chrome.browserAction.setIcon({
            path: ('icon48.png')
        });
        periodInMinutesAlarmNotifyAck = 10;
        chrome.alarms.create('ackNotify', {delayInMinutes: periodInMinutesAlarmNotifyAck, periodInMinutes: periodInMinutesAlarmNotifyAck});
    }
    return true;
});

//save token sent by Asksuite Dashboard app
chrome.runtime.onMessageExternal.addListener(
    function(request, sender, sendResponse) {
        if (request.token) {
            localStorage['wab_key'] = request.token;
            if(window.waboxapp) {
                window.waboxapp.restart();
            }
        }
        return true;
    });

chrome.runtime.onInstalled.addListener(function () {
    refreshWhatsApp();
    return true;
});

chrome.alarms.onAlarm.addListener(function (alarm) {
    console.log("ALARMED", new Date());
    if (alarm.name === 'ackNotify') {
        chrome.browserAction.setIcon({
            path: ('icon48_off.png')
        });

        chrome.notifications.getAll(function (notifications) {

            console.log("notifications", notifications);

            Object.keys(notifications)
                .filter(function (key) {
                    return key.startsWith("notifyAck");
                })
                .forEach(function (key) {
                    chrome.notifications.clear(key, function (wasCleared) {
                    });
                });

            if (periodInMinutesAlarmNotifyAck < 30) {
                periodInMinutesAlarmNotifyAck++;
            }

            chrome.alarms.create('ackNotify', {
                delayInMinutes: periodInMinutesAlarmNotifyAck,
                periodInMinutes: periodInMinutesAlarmNotifyAck
            });
            createNotificationConnectBot();
        });

    }
    return true;
});

function createNotificationConnectBot() {
    chrome.notifications.create('notifyAck-' + new Date().getTime(), {
        iconUrl: "icon48.png",
        type: "basic",
        title: "Asksuite WhatsApp",
        message: "O robô está desconectado",
        buttons: [
            {
                "title": "Conectar novamente"
            }
        ],
    }, function (id) {
    });
}

chrome.notifications.onButtonClicked.addListener(function (notificationId) {
    if (notificationId.startsWith("notifyAck")) {
        refreshWhatsApp();
    }
    return true;
});

chrome.notifications.onClicked.addListener(function (notificationId) {
    if (notificationId.startsWith("notifyAck")) {
        refreshWhatsApp();
    }
    return true;
});

function wbxValidate() {
    // var httpRequest = new XMLHttpRequest();
    // httpRequest['open']('POST', 'https://' + wab_url + '/api/validate', false);
    // httpRequest['setRequestHeader']('Content-type', 'application/x-www-form-urlencoded');
    // httpRequest['send']('token=' + localStorage['wab_key']);
    // if (httpRequest.readyState == 4 && httpRequest.status != 200) {
    //     localStorage['wab_key'] = ''
    // }

    if (localStorage['wab_key'] && localStorage['wab_key'] !== config.asksuite_token) {
        localStorage['wab_key'] = ''
    }

    if (!localStorage['installed_at'] || isNaN(new Date(localStorage['installed_at']).getTime())) {
        localStorage['installed_at'] = new Date().toISOString();
    }
}

function refreshWhatsApp() {
    chrome.tabs.query({url: "https://web.whatsapp.com/*"}, function (tabs){
        if(tabs.length){
            tabs.forEach(tab => {
                chrome.tabs.reload(tab.id, {bypassCache: true});
            })
        } else {
            chrome.tabs.create({url: "https://web.whatsapp.com/"});
        }
        return true;
    });
}

wbxValidate();
