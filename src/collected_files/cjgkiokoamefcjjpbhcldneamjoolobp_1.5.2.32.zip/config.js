function isDevMode() {
    return !('update_url' in chrome.runtime.getManifest());
}

var appEnvironment = function () {
    var wab_url = 'localhost:5010';
    var wabox_server_uri = 'ws://' + wab_url + '/ws';
    var wabox_server_health_check = 'http://' + wab_url + '/health/check';

    if (!isDevMode()) {
        wab_url = 'wabox.asksuite.com';
        wabox_server_uri = 'wss://' + wab_url + '/ws';
        wabox_server_health_check = 'https://' + wab_url + '/health/check';
    }

    return {
        wab_url: wab_url,
        asksuite_token: '7be10299b5369b1f08ca917b4ed15a6a5b087d67774f0',
        wabox_server_uri: wabox_server_uri,
        wabox_server_health_check: wabox_server_health_check,
        whatsapp_upload_uri: 'https://' + wab_url + '/api/upload',
    }
}();


