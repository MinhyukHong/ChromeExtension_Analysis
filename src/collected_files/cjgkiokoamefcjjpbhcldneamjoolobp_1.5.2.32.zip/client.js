console.errorOriginal = console.error;
console.logOriginal = console.log;

function sendLogAsksuite(type, parameters) {
    var log = {
        type: type,
        time: new Date(),
        label: null,
        value: null,
    };

    if (parameters.length > 1) {
        log.label = parameters[0] != null ? parameters[0].toString() : null;
        log.value = parameters[1] != null ? (parameters[1].stack || parameters[1].toString()) : null;
    } else {
        log.value = parameters[0] != null ? (parameters[0].stack || parameters[0].toString()) : null;
    }
    toScript('_wabs_add_log', log);
}

console.error = function() {
    console.errorOriginal(...arguments);
    sendLogAsksuite('error', arguments);
};

console.log = function() {
    console.logOriginal(...arguments);
    sendLogAsksuite('log', arguments);
};

window.addEventListener('error', function(event) {
    console.error(event.message);
});

function waboxcli() {
    this['dtm'] = Math['floor'](Date['now']() / 1000) - 300;
    this['queue'] = {};
    this['uidsCache'] = {};
    this['messageContentCache'] = {};
    this['mediaCache'] = {};
    this['lastInMsgCache'] = {};
    this['installedAt'] = null;
    this['processingQueue'] = {};
    this['mediaMaxSize'] = 16 * 1024 * 1024; // 16Mb
    this['callbacks'] = {};
    this['callbacks']['_wabs_client_convert_image_to_base64'] = {};

    window['addEventListener']('message', this['onScriptMessage']);
	
    const waitForMainPage = setInterval(function () {

        const isLandingPage = !!document.querySelector('.landing-main');
        const isLoading = !!document.querySelector('#startup progress, #app .app-wrapper-web progress');
        const webpackLoaded = !!window.webpackJsonp || !!window.webpackChunkwhatsapp_web_client;

        if (!isLandingPage && !isLoading && webpackLoaded) {
            clearInterval(waitForMainPage);

            if (window.webpackJsonp && typeof webpackJsonp === "function") {
                webpackJsonp([], {
                    parasite: function (o, e, t) {
                        window.waboxcli.getStore(t)
                    }
                }, ['parasite']);
            } else if (typeof webpackChunkwhatsapp_web_client === 'object' && Array.isArray(webpackChunkwhatsapp_web_client)) {
                webpackChunkwhatsapp_web_client.push([
                    ["parasite"],
                    {},
                    function (o, e, t) {
                        let modules = [];
                        for (let idx in o.m) {
                            let module = o(idx);
                            modules.push(module);
                        }
                        window.waboxcli.getStoreV2(modules)
                    }
                ]);

                let modulesMap = self.require('__debug').modulesMap;

                if (modulesMap && !window['waboxstore']) {
                    let modules = {};
                
                    Object.keys(modulesMap)
                      .filter((e) => e.includes('WA'))
                      .forEach(function (mod) {
                        let module = modulesMap[mod];
                        if (module) {
                          modules[mod] = {
                            default: module.defaultExport,
                            factory: module.factory
                          };    
                          if (Object.keys(modules[mod].default).length === 0) {
                            try {
                              self.ErrorGuard.skipGuardGlobal(true);
                              Object.assign(modules[mod], self.importNamespace(mod));
                            } catch (e) {}
                          }
                        }
                      });
    
                    window.waboxcli.getStoreV2(modules)
                }
            } else {
                webpackJsonp.push([
                    ["parasite"],
                    {
                        parasite: function (o, e, t) {
                            window.waboxcli.getStoreV1(t)
                        }
                    },
                    [["parasite"]]
                ]);
            }

            var baseModules = ['Chat', 'MediaCollection', 'MessageSender', 'SendSeen'];

            var allBaseModulesLoaded = baseModules.filter(function (mod) {
                return window['waboxstore'] && window['waboxstore'][mod];
            }).length === baseModules.length;

            if (allBaseModulesLoaded) {

                window['waboxcli']['onStatusChange']();
                setInterval(window['waboxcli']['onStatusChange'], 30000);
                // window['waboxstore']['Chat']['on']('change:unreadCount', window['waboxcli']['onChatMsgChanged'])

                // window['waboxstore'].Chat.on('add', (newChat) => {
                //     setTimeout(() => {
                //         if(newChat['msgs']['_models'].length > 0 ){
                //             newChat['msgs']['_models'].forEach(newMessageFromNewChat => {
                //                 window['waboxcli']['onMsg'](newMessageFromNewChat);
                //             })
                //         }
                //     }, 10000);
                // });

                window['waboxstore'].Msg.on('add', (newMessage) => {

                    // console.log("newMessage", newMessage)

                    if (newMessage && newMessage.isNewMsg) {
                        window['waboxcli']['onMsg'](newMessage);
                    }


                });

                setTimeout(() => {
                    window['waboxcli']['toScript']('_init_client', {});
                }, 2000);
            } else {
                window['location']['reload']()
            }
        }

    }, 500);
}

waboxcli['prototype']['getStoreV1'] = function (store) {
    console.log("getStoreV1");
    let index = 0;
    let filters = [{
        id: 'Store',
        conditions: (value) => (value['Chat'] && value['Msg']) ? value : null
    }, {
        id: 'Stream',
        conditions: (value) => (value['StreamInfo'] && value['StreamMode']) ? value['default'] : null
    }, {
        id: 'Wap',
        conditions: (value) => (value['createGroup']) ? value : null
    }, {
        id: 'MediaCollection',
        conditions: (value) => (value['default'] && value['default']['prototype'] && value['default']['prototype']['processAttachments']) ? value['default'] : null
    }, {
        id: 'Presence',
        conditions: (value) => (value.Presence || (value.default || {}).Presence) ? value.default : null
    }, {
        id: 'WapDelete',
        conditions: (value) => (value['sendConversationDelete'] && value['sendConversationDelete']['length'] == 2) ? value : null
    }, {
        id: 'Conn',
        conditions: (value) => (value['default'] && value['default']['ref'] && value['default']['refTTL']) ? value['default'] : null
    }, {
        id: 'WapQuery',
        conditions: (value) => (value['queryExist']) ? value : ((value['default'] && value['default']['queryExist']) ? value['default'] : null)
    }, {
        id: "SendSeen",
        conditions: (module) => (module.sendSeen) ? module.sendSeen : null
    }, {
        id: 'MessageSender',
        conditions: (value) => (value['sendTextMsgToChat']) ? value : null
    }, {
        id: 'ProtoConstructor',
        conditions: (value) => (value['prototype'] && value['prototype']['constructor'].toString()['indexOf']('binaryProtocol deprecated version') >= 0) ? value : null
    }, {id: "GetMaybeMeUser", conditions: (module) => (module && module.getMaybeMeUser) ? module : null}, {
        id: 'CryptoLib',
        conditions: (value) => value['decryptE2EMedia'] ? value : null
    }];
    for (let prop in store) {
        if ((typeof store[prop] === 'object') && (store[prop] !== null)) {
            let values = Object['values'](store[prop])[0];
            if ((typeof values === 'object') && (values['exports'])) {
                for (let subProp in store[prop]) {
                    let value = store(subProp);
                    if (!value) {
                        continue
                    };
                    filters['forEach']((options) => {
                        if (!options['conditions'] || options['foundedModule']) {
                            return
                        };
                        let module = options['conditions'](value);
                        if (module !== null) {
                            index++;
                            options['foundedModule'] = module;
                            console.log("modulo carregado", options.id);
                        }
                    });
                    if (index == filters['length']) {
                        break
                    }
                };
                let finder = filters['find']((options) => options['id'] === 'Store');
                window['waboxstore'] = finder['foundedModule'] ? finder['foundedModule'] : {};
                filters['splice'](filters['indexOf'](finder), 1);
                filters['forEach']((options) => {
                    if (options['foundedModule']) {
                        window['waboxstore'][options['id']] = options['foundedModule']
                    }
                })
            }
        }
    }

    if (window.waboxstore.Presence) {
        for (const prop in window.waboxstore.Presence) {
            if (prop === "Presence") {
                continue;
            }
            window.waboxstore[prop] = window.waboxstore.Presence[prop] || window.waboxstore[prop];
        }
    }
};

waboxcli['prototype']['getStoreV2'] = function(modules) {
    console.log("getStoreV2");
    let foundCount = 0;
    let filters = [{
        id: 'Store',
        conditions: (value) => (value['Chat'] && value['Msg']) ? value : null
    }, {
        id: 'Stream',
        conditions: (value) => (value['StreamInfo'] && value['StreamMode']) ? value['default'] : null
    }, {
        id: 'Wap',
        conditions: (value) => (value['createGroup']) ? value : null
    }, {
        id: 'MediaCollection',
        conditions: (value) => (value['default'] && value['default']['prototype'] && value['default']['prototype']['processAttachments']) ? value['default'] : null
    }, {
        id: 'Presence',
        conditions: (value) => (value.Presence || (value.default || {}).Presence) ? value.default : null
    }, {
        id: 'WapDelete',
        conditions: (value) => (value['sendConversationDelete'] && value['sendConversationDelete']['length'] == 2) ? value : null
    }, {
        id: 'Conn',
        conditions: (value) => (value['default'] && value['default']['ref'] && value['default']['refTTL']) ? value['default'] : null
    }, {
        id: 'WapQuery',
        conditions: (value) => (value['queryExist']) ? value : ((value['default'] && value['default']['queryExist']) ? value['default'] : null)
    }, {
        id: "SendSeen",
        conditions: (module) => (module.sendSeen) ? module.sendSeen : null
    }, {
        id: 'MessageSender',
        conditions: (value) => (value['sendTextMsgToChat']) ? value : null
    }, {
        id: 'ProtoConstructor',
        conditions: (value) => (value['prototype'] && value['prototype']['constructor'].toString()['indexOf']('binaryProtocol deprecated version') >= 0) ? value : null
    }, {
        id: 'CryptoLib',
        conditions: (value) => value['decryptE2EMedia'] ? value : null
    }, {
        id: "Status",
        conditions: (module) => (module._index) ? module : null
    }, {
        id: "DownloadManager",
        conditions: (module) => (module.__esModule && module.downloadManager) ? module.downloadManager : null
    }];
    for (let idx in modules) {
        if ((typeof modules[idx] === "object") && (modules[idx] !== null)) {
            filters.forEach((needObj) => {
                if (!needObj.conditions || needObj.foundedModule)
                    return;
                let neededModule = needObj.conditions(modules[idx]);
                if (neededModule !== null) {
                    foundCount++;
                    needObj.foundedModule = neededModule;
                }
            });

            if (foundCount == filters.length) {
                break;
            }
        }
    }

    let neededStore = filters.find((needObj) => needObj.id === "Store");
    window.waboxstore = neededStore.foundedModule ? neededStore.foundedModule : {};
    filters.splice(filters.indexOf(neededStore), 1);
    filters.forEach((needObj) => {
        // debugger;
        if (needObj.foundedModule) {
            window.waboxstore[needObj.id] = needObj.foundedModule;
            console.log("modulo carregado", needObj.id);
        }
    });

    if (window.waboxstore.Presence) {
        for (const prop in window.waboxstore.Presence) {
            if (prop === "Presence") {
                continue;
            }
            window.waboxstore[prop] = window.waboxstore.Presence[prop] || window.waboxstore[prop];
        }
    }
};

waboxcli['prototype']['onScriptMessage'] = function (event) {
    // console.log("onScriptMessage", event)
    //
    if (event['data']['type'] && event['data']['type']['indexOf']('_wabc_') > -1) {

        var chatIdUser = event['data']['msg']['msg']['to'];

        if(!window['waboxcli']['queue'][chatIdUser]) {
            window['waboxcli']['queue'][chatIdUser] = [];
        }

        window['waboxcli']['queue'][chatIdUser]['push'](event['data']);

        if (!window['waboxcli']['processingQueue'][chatIdUser]) {
            window['waboxcli']['processingQueue'][chatIdUser] = true;
            window['waboxcli']['processQueue'](chatIdUser);
        }

    } else if (event['data']['type'] === '_init_client_resolve') {
        var installedAt = event['data']['msg']['installed_at'];
        window['waboxcli'].installedAt = installedAt == null ? new Date() : new Date(installedAt);
        window['waboxcli'].readLastMsgs();

        console.log("version", event['data']['msg']['version']);
        console.log("version WPP", (Debug || {}).VERSION);
    } else if (event['data']['type'] === '_send_seen') {
        console.log("Received send seen", event['data']);
        var chatIdUser = event['data']['msg']['to'];
        window.waboxcli['upsertChat'](chatIdUser, function (chat) {
            window.waboxcli.sendSeen(chat);
        })
    } else if (event['data']['type'] === '_wabs_client_convert_image_to_base64_resolve') {
        window.waboxcli.convertImgToBase64URLResolver(event['data']['msg']);
    }

};
waboxcli['prototype']['onStatusChange'] = function (event) {

    const waboxstoreChat = JSON.parse(JSON.stringify(waboxstore.Chat));
    let user = '';
    const firstChatWithMessages = (waboxstoreChat || []).find((chat) =>
        chat.msgs && chat.msgs.length > 0 && chat.msgs.some(msg => msg.id && msg.id.fromMe));

    if (firstChatWithMessages) {
        const firstFromMe = firstChatWithMessages.msgs.find((msg) => !!msg.id.fromMe)

        user = firstFromMe.from.split('@')[0]
    }
    var result;

    try {
        result = {
            conn: {
                me: {
                    user
                },
            }
        };
        window['waboxcli']['toScript']('_wabs_status', result)
    } catch (err) {
        window['waboxcli']['catch'](err)
    }
};
waboxcli['prototype']['onChatMsgChanged'] = function (chat) {

    if (chat && chat['id']) {
        // debugger
        var message = chat['msgs']['last']();
        if (message && message['id']) {
            if (!window['waboxcli']['lastInMsgCache'][chat['id']] || window['waboxcli']['lastInMsgCache'][chat['id']] != message['id']['id']) {
                window['waboxcli']['lastInMsgCache'][chat['id']] = message['id']['id'];
                window['waboxcli']['onMsg'](message)
            }
        }
    }
};

waboxcli['prototype']['readLastMsgs'] = function () {

    var installedAt = window.waboxcli.installedAt;

    setTimeout(() => {
        window.waboxstore.Chat
            .filter((c) => c.unreadCount > 0 && c.previewMessage && !c.previewMessage.isSentByMe)
            .map((c) => c.previewMessage)
            .filter((m) => m != null)
            .filter((m) => new Date(m.t * 1000) >= installedAt)
            .forEach((msg) => {
                window['waboxcli']['onMsg'](msg);
            });
    }, 100);
};

waboxcli['prototype']['handleBlob'] = function (blob, message, acceptedMediaTypes) {
    var blobSize = blob.size;

    if (blobSize <= window['waboxcli']['mediaMaxSize']) {
        window['waboxcli']['blobToBase64'](blob, function (media) {
            if (media && acceptedMediaTypes.includes(message['type'])) {
                var fn = window['waboxcli']['randomFN'](message['mimetype']);
                var msg = window['waboxcli']['extractChat'](message);
                msg.body = {
                    mimetype: message['mimetype'],
                    type: message['type'],
                    blob: media,
                    caption: message['caption'],
                    fn: fn,
                };
                window['waboxcli']['toScript']('_wabs_file', {msg});
                // result = {
                //     msg: window['waboxcli']['extractMsg'](message),
                //     fn: fn
                // };
                // window['waboxcli']['toScript']('_wabs_msg', result)
            } else {
                var msg = window['waboxcli']['extractChat'](message);
                msg.body = {
                    error: {
                        mediaNotSupported: true,
                        type: message['type']
                    }
                };

                window['waboxcli']['toScript']('_wabs_error', {msg});
            }
        })
    } else {
        var msg = window['waboxcli']['extractChat'](message);
        msg.body = {
            error: {
                mediaMaxSizeExceeded: true,
            }
        };

        window['waboxcli']['toScript']('_wabs_error', {msg});
    }
};

waboxcli['prototype']['shouldDownload'] = function (message) {
    return (
            message['isMedia'] ||
            message['isDoc'] ||
        message['isMMS'] ||
        (message.mediaObject && message.mediaObject.entries && message.mediaObject.entries.entries && message.mediaObject.entries.entries.some(f => f.type === 'document')) ||
        (message.mediaObject && message.mediaObject.type === 'AUDIO')) &&
        message['mediaData'] &&
        message['mediaData']['mediaStage']['toLowerCase']() != 'resolved'
};

waboxcli['prototype']['onMsg'] = function (message) {

    var result;
    var acceptedMediaTypes = ['document', 'image', 'audio', 'ptt'];

    // console.log('onMsg', message)
    if (message.isNotification || (message.from && (message.from === "status@broadcast" || message.from._serialized === "status@broadcast"))) {
        return;
    }

    const currentChat = getChatFromMessage(message);

    if (currentChat && !currentChat.trusted) {
        currentChat.notSpam = true;
        currentChat._handleNotSpamChange();
        console.log('trusting', currentChat.id);
    }

    waboxcli.waitForPendingChats(currentChat)
        .then(() => {

            try {
                // debugger;
                if (message['t'] > window['waboxcli']['dtm'] && !(message['id']['id'] in window['waboxcli']['uidsCache'])) {
                    if (window['waboxcli']['shouldDownload'](message)) {
                        message['mediaData']['parent'] = message;
                        message['mediaData']['on']('change:mediaStage', window['waboxcli']['onMediaData']);
                        message['downloadMedia']({downloadEvenIfExpensive: true, rmrReason: 15, isUserInitiated: false})
                    } else {
                        if (message['isMedia'] || message['isDoc'] || message['isMMS'] || (message.mediaObject && message.mediaObject.type === 'AUDIO') ||
                            ['image', 'ptt', 'document', 'audio'].indexOf(message['type']) > -1) {
                            var isBlob = message['type'] === 'document';
                            waboxcli.downloadFile(message, isBlob, function (result, m) {
                                var blob;
                                var downloadingBlob = false;
                                if (!blob) {
                                    if (m.mediaData && m.mediaData.mediaBlob) {
                                        blob = m.mediaData.mediaBlob.forceToBlob();
                                    } else if ((m.mediaData && m.mediaData.filehash) || m.mediaObject.filehash) {
                                        const mediaData = ((m.mediaData && m.mediaData) || m.mediaObject);
                                        const data = {
                                            ...mediaData,
                                            ...mediaData.toJSON(),
                                            type: mediaData.type,
                                            signal: new AbortController().signal
                                        };
                                        downloadingBlob = true;

                                        const downloadDecryptFunc = window['waboxstore'].DownloadManager.downloadAndDecrypt || window['waboxstore'].DownloadManager.downloadAndMaybeDecrypt;

                                        if (!downloadDecryptFunc) {
                                            console.log('Error to downloadAndDecrypt: function not found');
                                            return;
                                        }

                                        downloadDecryptFunc(data)
                                            .then(function (buffer) {
                                                waboxcli.handleBlob(new Blob([buffer]), message, acceptedMediaTypes);
                                            }).catch((error) => {
                                            console.log('Error to downloadAndDecrypt', error);
                                        });
                                    }
                                }

                                if (blob) {
                                    waboxcli.handleBlob(blob, message, acceptedMediaTypes);
                                } else if (!downloadingBlob) {
                                    // window['waboxstore'].CryptoLib.decryptE2EMedia(m.type, result, m.mediaKey, m.mimetype).then(function (a) {
                                    //     blob = a._blob;
                                    //     waboxcli.handleBlob(blob, message, acceptedMediaTypes);
                                    // }).catch(console.error);

                                    console.log("Blob not found");
                                }
                            });
                        } else if (message.type === 'location') { // Location
                            var mimetype = 'image/jpeg';
                            var type = 'image';
                            var fn = window['waboxcli']['randomFN']();
                            var msg = window['waboxcli']['extractChat'](message);
                            msg.body = {
                                mimetype: mimetype,
                                type: type,
                                blob: msg.body,
                                fn: fn,
                            };
                            window['waboxcli']['toScript']('_wabs_file', {msg});
                        } else if (message.type === 'chat') {
                            var messageContentKey = window.waboxcli.generateMessageContentKey(message.text);
                            if (!messageContentKey || !(window.waboxcli.messageContentCache[currentChat.id.user] || {})[messageContentKey]) {
                                result = {
                                    msg: window['waboxcli']['extractChat'](message)
                                };

                                // console.log('extractChat', result);

                                window['waboxcli']['toScript']('_wabs_msg', result)
                            }
                        }
                    }
                } else if (message['id']['id'] in window['waboxcli']['uidsCache']) {
                    delete window['waboxcli']['uidsCache'][message['id']['id']]
                }

            } catch (err) {
                window['waboxcli']['catch'](err)
            }

        })
        .catch(err => {
            window['waboxcli']['catch'](err)
        })
};
waboxcli['prototype']['downloadFile'] = function (msg, blob, done) {
    let xhr = new XMLHttpRequest();

    xhr.onload = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                done(xhr.response, msg);
            } else {
                console.error(xhr.statusText);
            }
        } else {
            console.log(err);
            done(false);
        }
    };

    xhr.open("GET", msg.clientUrl || msg.deprecatedMms3Url, true);
    xhr.responseType = blob ? 'blob' : 'arraybuffer';
    xhr.send(null);
};
waboxcli['prototype']['onMediaData'] = function(media) {

    if (media['mediaStage']['toLowerCase']() == 'resolved') {
        window['waboxcli']['onMsg'](media['parent'])
    }
};
waboxcli['prototype']['onAck'] = function(message) {
    try {
        var result = {
            id: message['id']['id'],
            ack: message['ack'],
            muid: window['waboxcli']['uidsCache'][message['id']['id']]
        };
        //['waboxcli']['toScript']('_wabs_ack', result);
        if (message['ack'] > 2) {
            // delete window['waboxcli']['uidsCache'][message['id']['id']]
        }
    } catch (err) {
        window['waboxcli']['catch'](err)
    }
};

function toScript(type, message) {
    // console.log(message);
    window['postMessage']({
        type: type,
        msg: message
    }, '*')
}

waboxcli['prototype']['toScript'] = toScript;

waboxcli['prototype']['catch'] = function(error) {
    console.error(error);
    window['waboxcli']['toScript']('_wabs_err', {
        error: error['message'],
        stack: error['stack']
    })
};

waboxcli['prototype']['convertImgToBase64URL'] = function (url, callback, outputFormat) {
    const id = new Date().getTime() + "_" + url;
    window['waboxcli']['callbacks']['_wabs_client_convert_image_to_base64'][id] = callback;

    waboxcli.toScript('_wabs_client_convert_image_to_base64', {
        id,
        url,
    });
};

waboxcli['prototype']['convertImgToBase64URLResolver'] = function (message) {
    if (!window['waboxcli']['callbacks']['_wabs_client_convert_image_to_base64'][message.id]) {
        return;
    }

    window['waboxcli']['callbacks']['_wabs_client_convert_image_to_base64'][message.id](message.dataURL);
    delete window['waboxcli']['callbacks']['_wabs_client_convert_image_to_base64'][message.id];
};

waboxcli['prototype']['base64MediaToFile'] = function (b64Data, filename) {
    var arr = b64Data.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, {type: mime});
};

waboxcli['prototype']['processMedia'] = function (chat, message, mediaBlob) {

    var mc = new window.waboxstore.MediaCollection(chat);

    return mc.processAttachments([{file: mediaBlob}, 1], 1, chat).then(function () {
        var media = mc._models[0];

        var oldChatLength = chat.msgs._models.length;

        media.sendToChat(chat, {caption: message.msg.body.desc || message.msg.body.caption});

        return waboxcli.waitForChatChange(message, chat, oldChatLength);
    });

};

waboxcli['prototype']['waitForChatChange'] = function (message, chat, oldChatLength, messageContentKey) {
    return new Promise(function (resolve, reject) {
        const interval = setInterval(() => {
            if (oldChatLength !== chat.msgs._models.length) {
                clearInterval(interval);
                var lastChat = chat.msgs._models[chat.msgs._models.length - 1];

                if (lastChat) {
                    if (messageContentKey) {
                        delete window.waboxcli.messageContentCache[chat.id.user][messageContentKey];
                    }
                    window.waboxcli.uidsCache[lastChat.id.id] = message.custom_uid;
                    lastChat.on('change:ack', window.waboxcli.onAck)
                }

                window.waboxcli.sendSeen(chat);

                waboxcli.waitForPendingChats(chat).then(resolve);
            }
        }, 10);
    });
}

waboxcli['prototype']['hasPendingChats'] = function (chat) {
    return !chat || (chat && chat.msgs._models[chat.msgs._models.length - 1].ack === 0);
};

waboxcli['prototype']['waitForPendingChats'] = function (chat, intervalTimeout = 100) {
    var waitForPendingChats = Promise.resolve();
    var interval;

    if (waboxcli.hasPendingChats(chat)) {
        waitForPendingChats = new Promise(resolve => {
            interval = setInterval(() => {
                if (!waboxcli.hasPendingChats(chat)) {
                    clearInterval(interval);
                    resolve();
                }
            }, intervalTimeout);
        });
    }

    var timeout = new Promise(resolve => {
        const wait = setTimeout(() => {
            if (interval) clearInterval(interval);

            clearTimeout(wait);
            resolve();
        }, 30000);
    });

    return Promise.race([waitForPendingChats, timeout]);
};

waboxcli['prototype']['sendMessage'] = function (message, chat) {
    if (message['body']) {
        var text = message.body.text || message.body.desc;

        var oldChatLength = chat.msgs._models.length;

        var messageContentKey = window.waboxcli.generateMessageContentKey(text);

        if (messageContentKey) {
            window.waboxcli.messageContentCache[chat.id.user] = window.waboxcli.messageContentCache[chat.id.user] || {};
            window.waboxcli.messageContentCache[chat.id.user][messageContentKey] = true;
        }

        window.waboxstore.MessageSender.sendTextMsgToChat(chat, text);

        return waboxcli.waitForChatChange(message, chat, oldChatLength, messageContentKey);
    };
};

waboxcli['prototype']['generateMessageContentKey'] = function (text) {
    if (!text) {
        return null;
    }
    return text.trim();
};

waboxcli['prototype']['sendSeen'] = function (chat) {
    setTimeout(() => window.waboxstore.SendSeen(chat, false), 2000);
};

waboxcli['prototype']['continueQueue'] = function(chatIdUser) {
    if (window.waboxcli.queue[chatIdUser].length) {
        window.waboxcli.processQueue(chatIdUser);
    } else {
        window.waboxcli.processingQueue[chatIdUser] = false;
    }
};

waboxcli['prototype']['processQueue'] = function(chatIdUser) {

    try {
        window['waboxcli']['processingQueue'][chatIdUser] = true;

        // console.log('processing queue');

        var message, processed;
        if (this['queue'][chatIdUser]['length']) {
            message = this['queue'][chatIdUser]['shift']()['msg'];

            this['upsertChat'](message['msg']['to'], function(chat) {
                processed = false;
                if (chat) {
                    switch (message['cmd']) {
                        case 'chat':
                            if (message['msg']['body']['text']) {
                                window.waboxcli.sendMessage(message['msg'], chat).then(() => window.waboxcli.continueQueue(chatIdUser));
                            }
                            break;
                        case 'audio':
                        case 'document':
                        case 'image_attachment':
                            var mediaBlob = waboxcli.base64MediaToFile(message['msg']['body']['base64'], message['msg']['body']['caption'] || "file");
                            window.waboxcli.mediaCache[message['msg']['body']['fn']] = mediaBlob;
                            waboxcli.processMedia(chat, message, mediaBlob).then(() => window.waboxcli.continueQueue(chatIdUser));
                            break;
                        case 'image':
                            if (message['msg']['body']['url']) {
                                let url = message['msg']['body']['url'];
                                if (window.waboxcli.mediaCache[url]) {
                                    var blob = window.waboxcli.mediaCache[url];
                                    waboxcli.processMedia(chat, message, blob).then(() => window.waboxcli.continueQueue(chatIdUser));
                                } else {
                                    waboxcli.convertImgToBase64URL(url, function (imgBase64) {
                                        if (!imgBase64) {
                                            window.waboxcli.sendMessage(message['msg'], chat).then(() => window.waboxcli.continueQueue(chatIdUser));
                                        } else {
                                            var mediaBlob = waboxcli.base64MediaToFile(imgBase64, "meu file");
                                            // console.log('Updated cache', url);

                                            window.waboxcli.mediaCache[url] = mediaBlob;
                                            waboxcli.processMedia(chat, message, mediaBlob).then(() => window.waboxcli.continueQueue(chatIdUser));
                                        }
                                    });
                                }

                            }
                            break;
                    }
                }
            })
        }
    } catch (err) {
        window['waboxcli']['catch'](err)
    }
};
waboxcli['prototype']['upsertChat'] = function(recipient, callback) {
    try {
        window['waboxstore']['Chat']['find'](this['cuidToJid'](recipient))['then'](function(chat) {
            callback(chat)
        }, function(options) {
            window['waboxstore']['WapQuery']['queryExist'](window['waboxcli']['cuidToJid'](recipient))['then'](function(argument) {
                callback(window['waboxstore']['Chat']['gadd'](argument['jid']))
            }, function(options) {})
        })
    } catch (err) {}
};
waboxcli['prototype']['cuidToJid'] = function(recipient) {
    return (recipient['indexOf']('@') < 0 ? recipient + '@c.us' : recipient)
};
waboxcli['prototype']['blobToBase64'] = function(media, callback) {
    try {
        var fileReader = new window.FileReader();
        fileReader['readAsDataURL'](media);
        fileReader['onloadend'] = function() {
            callback(fileReader['result'])
        }
    } catch (err) {
        window['waboxcli']['catch'](err)
    }
};
waboxcli['prototype']['randomFN'] = function() {
    var characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var result = '';
    for (var i = 32; i > 0; --i) {
        result += characters[Math['floor'](Math['random']() * characters['length'])]
    };
    return result
};


waboxcli['prototype']['extract'] = function(obj) {
    var result = {};
    for (var key in obj) {
        if (typeof(obj[key]) != 'object' && typeof(obj[key]) != 'function') {
            result[key] = obj[key]
        } else {
            if (key == 'chat' || key == 'senderObj') {
                result[key] = window['waboxcli']['extract'](typeof(obj[key]['all']) != 'undefined' ? obj[key]['all'] : obj[key]['attributes'])
            } else {
                if (key == 'id' || key == 'me' || key === 'wid') {
                    result[key] = window['waboxcli']['extract'](obj[key])
                }
            }
        }
    };
    if (result['wid']) {
        result['me'] = result['wid'];
    }
    return result
};


waboxcli['prototype']['extractChat'] = function (msg) {

    let chat = getChatFromMessage(msg);
    if (!chat) {
        if (waboxstore.Chat && waboxstore.Chat._models && waboxstore.Chat._models.length && (msg.to || msg.from)) {
            chat = waboxstore.Chat._models.find(model => {
                return !!(msg.to && msg.to.user === model.id.user || msg.from && model.id.user === msg.from.user);
            });
        }
    }

    // console.log("extractChat", msg)

    if (!msg.senderObj) {
        msg.senderObj = {
            name: msg.from.user,
        };
    }

    var result = {
        body: msg.body,
        id: JSON.parse(JSON.stringify(msg.id)),
        senderObj: JSON.parse(JSON.stringify(msg.senderObj)),
        chat: JSON.parse(JSON.stringify(chat)),
        to: msg.to
    };

    result.senderObj.userid = msg.senderObj.userid;
    result.senderObj.id = msg.senderObj.id;

    result.chat.id = chat.id;
    result.chat.active = chat.active;
    result.chat.isGroup = chat.isGroup;

    delete result.chat.msgs;

    return result;


};
waboxcli['prototype']['extractMsg'] = function(obj) {

    var result = window['waboxcli']['extract'](typeof(obj['all']) != 'undefined' ? obj['all'] : obj['attributes']);
    if (typeof(result['chat']) == 'undefined' && typeof(obj['chat']) != 'undefined') {
        result['chat'] = window['waboxcli']['extract'](typeof(obj['chat']['all']) != 'undefined' ? obj['chat']['all'] : obj['chat']['attributes'])
    };
    return result
};

let loaderInterval = null;
let isLoaded = false;

function getChatFromMessage(message) {

    if (message.chat) {
        return message.chat;
    }
    let chat;
    if (waboxstore.Chat && waboxstore.Chat._models && waboxstore.Chat._models.length) {
        chat = waboxstore.Chat._models.find(model => {
            return !!(message.to && message.to.user === model.id.user || message.from && model.id.user === message.from.user);
        });
    }

    if (!chat)  {
       console.log('getChatFromMessage error: chat not found');
    }

    return chat;
}

function initExtension() {
    isLoaded = true;
    clearInterval(loaderInterval);
    console.log("end load client.js", new Date());
    window['waboxcli'] = new waboxcli();
}

function checkIfIsLoaded() {
    return !!document.querySelector('[data-testid=chatlist-header]');
}

loaderInterval = setInterval(() => {
    if(!isLoaded && checkIfIsLoaded()) {
        initExtension();
    }
}, 1000);

console.log("init load client.js", new Date());
window.addEventListener("load", initExtension);
