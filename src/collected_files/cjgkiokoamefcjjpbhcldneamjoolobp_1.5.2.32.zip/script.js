const config = appEnvironment;

const consoleLogList = [];

function waboxapp(url, token, installedAt) {
    this.myVersion = '1.5.2.32';
    this.chromeVersion = /Chrome\/([0-9.]+)/.exec(navigator.userAgent)[1];
    this.token = token;
    this.ws_uri = config.wabox_server_uri;
    this.ws = false;
    this.ws_to = null;
    this.ws_refresh_to = null;
    this.ws_alive_to = null;
    this.ws_queue = [];
    this.installed_at = new Date(installedAt);
    this.upload_uri = config.whatsapp_upload_uri;
    this.wsConnected = false;
    this.status = {};
    if (this.token) {
        this.wsConnect(function (msgObj) {
            try {
                var j = msgObj.data;
                if (typeof msgObj.data === 'string') {
                    j = JSON.parse(msgObj.data);
                }
                window.waboxapp.wsReceive(j);
            } catch (err) {
                console.error(err);
            }

        });
        window.addEventListener('message', this.onClientMsg);
        this.injectClient();

        chrome.extension.sendMessage({
            method: '_wab_ack'
        }, function () {
        });
    }
}

waboxapp.prototype.injectClient = function () {
    try {
        (function () {
            var script = document.createElement('script');
            script.src = chrome.extension.getURL('client.js');
            document.body.appendChild(script);
        })()
    } catch (err) {
        window.waboxapp['catch'](err)
    }
};

waboxapp.prototype.toClient = function (type, msg) {
    window['postMessage']({
        type: type,
        msg: msg
    }, '*')
};

waboxapp.prototype.catch = function (err) {
    window.waboxapp.onClientMsg({
        type: '_wabs_err',
        data: {
            error: err.message,
            stack: err.stack
        }
    })
};

waboxapp.prototype.checkToRefreshPage = function () {
    fetch(config.wabox_server_health_check, {
        mode: "no-cors"
    }).then(() => {
        window.waboxapp['refreshPage']();
    });
};

waboxapp.prototype.wsConnect = function (callback) {

    if (this.ws_to) {
        clearTimeout(this.ws_to)
    }

    if (this.ws) {
        this.ws.close()
    }

    this.ws = new WebSocket(this.ws_uri + '?&token=' + this.token);
    this.ws.onopen = function (msg) {
        chrome.extension['sendMessage']({
            method: '_wab_connection',
            connected: true
        });

        var isReconnect = false;
        if (window.waboxapp.ws_alive_to) {
            clearInterval(window.waboxapp.ws_alive_to);
            isReconnect = !window.waboxapp.wsConnected;
        }

        window.waboxapp.ws_alive_to = setInterval(window.waboxapp.wsAlive, 60000);
        window.waboxapp.wsAlive();
        window.waboxapp.wsProcessQueue();
        if (isReconnect) {
            setTimeout(() => {
                window.waboxapp['toClient']('_init_client_resolve', {
                    installed_at: window.waboxapp.installed_at,
                    version: window.waboxapp.myVersion,
                });
            }, 3000);
        }

        window.waboxapp.wsConnected = true;

        if (window.waboxapp.ws_refresh_to) {
            clearInterval(window.waboxapp.ws_refresh_to);
            window.waboxapp.ws_refresh_to = null;
        }
    };

    this.ws.onclose = function (event) {
        chrome.extension.sendMessage({
            method: '_wab_connection',
            connected: false
        });
        if (!event['wasClean']) {
            this.ws = false;
            this.ws_to = setTimeout(function () {
                window.waboxapp.wsConnect(callback)
            }, 500)
        }

        window.waboxapp.wsConnected = false;
        if (!window.waboxapp.ws_refresh_to) {
            window.waboxapp.ws_refresh_to = setInterval(() => window.waboxapp.checkToRefreshPage(), 60000);
        }
    };
    this.ws.onmessage = callback
};

waboxapp.prototype.wsReceive = function (receivedMsg) {
    const systemCommands = ['refresh', 'requestLogs'];

    receivedMsg = (typeof receivedMsg == 'string' ? JSON.parse(receivedMsg) : receivedMsg);
    if (receivedMsg['cmd'] && receivedMsg['msg']) {
        if(systemCommands.includes(receivedMsg['cmd'])) {
            switch(receivedMsg['cmd']) {
                case 'refresh':
                    window.waboxapp['refreshPage']();
                    break;
                case 'requestLogs':
                    this.wsSend({
                        type: '_wabs_send_logs',
                        uid: receivedMsg['msg']['uid'],
                        logs: consoleLogList,
                    });
                    break;
            }

        } else {
            window.waboxapp['toClient']('_wabc_', receivedMsg)
        }
    } else if (receivedMsg['ack']) {
        chrome.extension.sendMessage({
            method: '_wab_ack'
        }, function () {
        });
    } else if (receivedMsg['sendSeen']) {
        window.waboxapp['toClient']('_send_seen', receivedMsg['sendSeen']);
    }
};

waboxapp.prototype.refreshPage = function () {
    chrome.extension.sendMessage({
        method: '_wab_refresh',
    });
};

waboxapp.prototype.wsSend = function (msgObj) {
    this.ws_queue.push(msgObj);
    this.wsProcessQueue()
};

waboxapp.prototype.wsAlive = function () {
    window.waboxapp.wsSend({
        type: '_wabs_alive'
    })
};

waboxapp.prototype.wsProcessQueue = function () {
    while (this.ws.readyState == window.WebSocket.OPEN && this.ws_queue.length) {
        var msgObj = this.ws_queue.pop();
        msgObj.token = waboxapp.token;
        msgObj.me = (waboxapp.status && waboxapp.status.conn ? waboxapp.status.conn.me : false);
        var cloneMsg = new Object(msgObj);

        if (cloneMsg.me) {
            cloneMsg.me = {
                user: cloneMsg.me.user
            }
        }

        if (cloneMsg.type === '_wabs_msg' || cloneMsg.type === '_wabs_file') {

            if (cloneMsg.me) {
                cloneMsg.me = {
                    user: cloneMsg.me.user
                }
            } else if (cloneMsg.msg.msg.to) {
                if(cloneMsg.msg.msg.id.fromMe) {
                    cloneMsg.me = {
                        user: cloneMsg.msg.msg.senderObj.id.user
                    }
                } else {
                    cloneMsg.me = {
                        user: cloneMsg.msg.msg.to.user
                    }
                }
            }

            cloneMsg.msg = {
                msg: {
                    body: cloneMsg.msg.msg.body,
                    id: cloneMsg.msg.msg.id,
                    senderObj: cloneMsg.msg.msg.senderObj,
                    chat: cloneMsg.msg.msg.chat
                }
            }
        }

        var sendMsg = true;

        if (cloneMsg.type === '_wabs_ack' || (['_wabs_file', '_wabs_msg', '_wabs_error'].includes(cloneMsg.type) && cloneMsg.msg.msg.chat.isGroup)) {
            sendMsg = false;
        }

        cloneMsg.v = this.myVersion + ' chrome:' + this.chromeVersion;
        cloneMsg.version = this.myVersion;

        if (cloneMsg.type == '_wabs_send_logs') {
            cloneMsg.logs = msgObj.logs;
        }

        if (sendMsg) {
            this.ws.send(JSON.stringify(cloneMsg))
        }
    }
};

waboxapp.prototype.onClientMsg = function (msgObj) {
    if (msgObj.data.type && msgObj.data.type.indexOf('_wabs_') > -1) {
        switch (msgObj.data.type) {
            case '_wabs_status':
                const status = msgObj.data.msg;
                const hasMe = status && status.conn && status.conn.me;
                if (hasMe) {
                    waboxapp.status = status;
                }
                break;
            case '_wabs_add_log':
                consoleLogList.push(msgObj.data.msg);
                break;

            case '_wabs_client_convert_image_to_base64':
                window.waboxapp.convertImgToBase64URL(msgObj.data.msg)
                break;
            case '_wabs_file':
            case '_wabs_error':
            default:
                window.waboxapp.wsSend(msgObj.data);
                break;
        }
    } else if (msgObj.data.type && msgObj.data.type === '_init_client') {
        window.waboxapp['toClient']('_init_client_resolve', {
            installed_at: window.waboxapp.installed_at,
            version: window.waboxapp.myVersion
        });
    }
};

waboxapp.prototype.convertImgToBase64URL = function (data) {
    function callback(dataURL) {
        window.waboxapp['toClient']('_wabs_client_convert_image_to_base64_resolve', {
            dataURL: dataURL,
            id: data.id
        });
    }
    try {
        console.log('onClientMsg', data);
        const url = data.url;
        const outputFormat = data.outputFormat;

        var img = new Image();
        img.crossOrigin = 'Anonymous';
        img.onload = function(){
            var canvas = document.createElement('CANVAS'),
                ctx = canvas.getContext('2d'), dataURL;
            canvas.height = img.height;
            canvas.width = img.width;
            ctx.drawImage(img, 0, 0);
            dataURL = canvas.toDataURL(outputFormat);
            try {
                callback(dataURL);
            } catch (e) {
                console.error(e);
            }
            canvas = null;
        };
        img.onerror = function(err) { console.error(err.target.src);
            callback(null); //callback
        };
        var proxyUrl = 'https://cors.asksuite.com/';
        img.src = (url.startsWith('blob:') ? '' : proxyUrl) + url;

    } catch (err) {
        window.waboxapp['catch'](err)
    }
};

waboxapp.prototype.upload = function (media) {
    try {
        var form = new FormData();
        form.append('token', window.waboxapp['token']);
        form.append('fn', media['fn']);
        form.append('blob', media['blob']);
        var httpRequest = new XMLHttpRequest();
        httpRequest.open('POST', window.waboxapp.upload_uri, true);
        httpRequest.send(form)
    } catch (err) {
        window.waboxapp['catch'](err)
    }
};

waboxapp.prototype.restart = function () {
    restartKey(this.ws_uri);
};

restartKey = function(wab_url) {
    chrome.extension.sendMessage({
        method: '_wab_settings'
    }, function (response) {
        if (response && response['wab_key']) {
            window.waboxapp = new waboxapp(wab_url, response['wab_key'], response['installed_at']);
        }
    });

};

restartKey(config.wab_url);
