if (document['querySelector']('#wab_link')) {
    if (localStorage['wab_key']) {
        document['querySelector']('.wab_status.ko')['style']['display'] = 'none';
        document['querySelector']('.wab_status.ok')['style']['display'] = 'block'
    }
}
if (document['querySelector']('#wab_validate')) {
    document['querySelector']('#wab_key')['value'] = (typeof(localStorage['wab_key']) != 'undefined' ? localStorage['wab_key'] : '');
    document['querySelector']('#wab_validate')['addEventListener']('click', function () {
        document['querySelector']('.wab_validated.ok')['style']['display'] = 'none';
        document['querySelector']('.wab_validated.ko')['style']['display'] = 'none';
        document['querySelector']('#wab_validate')['disabled'] = true;
        document['querySelector']('#wab_validate')['value'] = '...';
        // var httpRequest = new XMLHttpRequest();
        var tokenValue = document['querySelector']('#wab_key')['value'];
        // httpRequest['open']('POST', 'http://' + wab_url + '/api/validate', false);
        // httpRequest['setRequestHeader']('Content-type', 'application/x-www-form-urlencoded');
        // httpRequest['send']('token=' + tokenValue);
        document['querySelector']('#wab_validate')['disabled'] = false;
        document['querySelector']('#wab_validate')['value'] = 'Validate';
        // if (httpRequest['readyState'] == 4 && httpRequest['status'] == 200) {
        if (tokenValue === '7be10299b5369b1f08ca917b4ed15a6a5b087d67774f0') {
            document['querySelector']('.wab_validated.ok')['style']['display'] = 'block';
            localStorage['wab_key'] = tokenValue;
        } else {
            localStorage['wab_key'] = '';
            document['querySelector']('.wab_validated.ko')['style']['display'] = 'block'
        }
    })
}