/**
 * 微博内容发布模块 (Content Script)
 * 
 * 主要功能：
 * 1. 处理文本内容的发布
 * 2. 处理图片的上传和插入
 * 3. 模拟用户操作触发发布动作
 * 
 * 实现细节：
 * 1. 文本处理：
 *    - 使用标准的DOM事件模拟用户输入
 *    - 处理多行文本和特殊字符
 *    - 确保不超过微博字数限制
 * 
 * 2. 图片处理：
 *    - 使用粘贴事件上传图片（重要！）
 *    - 支持多图上传，最多9张
 *    - 处理图片上传的进度和状态
 * 
 * 3. 发布流程：
 *    - 清理已有内容
 *    - 插入文本
 *    - 上传图片
 *    - 触发发布按钮
 *    - 等待发布完成
 * 
 * 注意事项：
 * 1. 图片上传必须使用粘贴方式，不要改用文件上传
 * 2. 所有操作都需要考虑网络延迟
 * 3. 需要处理各种异常情况
 * 4. 微博编辑器状态的维护很重要
 */

// 等待元素出现的通用函数
async function waitForElement(selector, maxAttempts = 50) {
  console.log('等待元素:', selector);
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const element = document.querySelector(selector);
    if (element) {
      console.log('找到元素:', selector);
      return element;
    }
    await new Promise(resolve => setTimeout(resolve, 100));  
  }
  throw new Error('找不到元素: ' + selector);
}

// 等待多个元素出现的通用函数
async function waitForElements(selector, maxAttempts = 50) {
  console.log('等待元素:', selector);
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const elements = document.querySelectorAll(selector);
    if (elements.length > 0) {
      console.log('找到元素:', selector);
      return elements;
    }
    await new Promise(resolve => setTimeout(resolve, 100));  
  }
  throw new Error('找不到元素: ' + selector);
}

// 将 base64 图片数据转换为 File 对象
async function base64ToFile(base64Data, filename = 'image.png') {
  const response = await fetch(base64Data);
  const blob = await response.blob();
  return new File([blob], filename, { type: 'image/png' });
}

// 清理已有图片的函数
async function clearExistingImages() {
  try {
    // 检查是否有现有图片
    const existingImages = document.querySelectorAll('.picture_pic_2FfMX');
    if (existingImages.length > 0) {
      console.log('找到现有图片，开始清理...');
      for (const img of existingImages) {
        // 查找关闭按钮
        const closeButton = img.closest('.picture_item_3zpnC')?.querySelector('.close_1OzvM');
        if (closeButton) {
          closeButton.click();
          // 每次点击后等待一下，确保图片被清理
          await new Promise(resolve => setTimeout(resolve, 300));
        }
      }
      // 最后再等待一下，确保所有图片都被清理完毕
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    return true;
  } catch (error) {
    console.error('清理现有图片失败:', error);
    // 即使清理失败也继续执行
    return true;
  }
}

// 清理编辑器内容的函数
async function clearEditorContent() {
  try {
    console.log('开始清理编辑器内容...');
    const editor = await waitForElement('.Form_input_2gtXx');
    if (editor) {
      // 清除文本内容
      editor.innerHTML = '';
      editor.value = '';
      editor.textContent = '';
      
      // 触发必要的事件
      editor.dispatchEvent(new Event('input', { bubbles: true }));
      editor.dispatchEvent(new Event('change', { bubbles: true }));
      
      // 清除图片
      await clearExistingImages();
      
      console.log('编辑器内容清理完成');
      return true;
    }
  } catch (error) {
    console.error('清理编辑器内容失败:', error);
    return false;
  }
}

// 在页面加载完成时清理内容
async function initializeContent() {
  console.log('页面初始化开始...');
  try {
    // 等待页面完全加载
    await new Promise(resolve => {
      if (document.readyState === 'complete') {
        resolve();
      } else {
        window.addEventListener('load', resolve);
      }
    });
    
    // 给微博页面充分的时间加载其UI组件
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // 清理编辑器内容
    await clearEditorContent();
    
    console.log('页面初始化完成');
  } catch (error) {
    console.error('页面初始化失败:', error);
  }
}

// 开始初始化
initializeContent();

/**
 * 微博内容发布模块
 * 
 * ！！！重要说明！！！
 * 图片上传必须使用粘贴方式实现，不能使用文件上传方式。
 * 原因：
 * 1. 文件上传方式在某些场景下可能无法正常工作
 * 2. 粘贴方式更接近真实用户行为，更稳定可靠
 * 3. 这是产品要求的标准实现方式
 * 
 * 请勿修改为其他上传方式！
 */
async function uploadImage(imageData) {
  try {
    console.log('开始上传图片...');
    
    const editor = await waitForElement('.Form_input_2gtXx');
    if (!editor) {
      throw new Error('找不到编辑器元素');
    }

    // 将 base64 转换为 Blob
    const blob = await fetch(imageData).then(res => res.blob());
    
    // 创建 File 对象
    const file = new File([blob], 'image.png', { type: blob.type });
    
    // 创建 DataTransfer 对象用于粘贴操作
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    
    // 创建粘贴事件
    const pasteEvent = new ClipboardEvent('paste', {
      bubbles: true,
      cancelable: true,
      clipboardData: dataTransfer
    });

    // 确保编辑器处于激活状态
    editor.focus();
    // 给足够的时间让编辑器获得焦点
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // 触发粘贴事件
    editor.dispatchEvent(pasteEvent);
    
    // 等待图片上传完成
    await new Promise((resolve, reject) => {
      let attempts = 0;
      const maxAttempts = 180; // 增加到180秒
      const checkInterval = setInterval(() => {
        attempts++;
        
        const uploadProgress = document.querySelector('.picture-upload-progress');
        const imagePreview = document.querySelector('.picture-preview');
        
        if (imagePreview && !uploadProgress) {
          // 如果找到预览图但没有上传进度条，说明上传已完成
          clearInterval(checkInterval);
          resolve(true);
          return;
        }
        
        if (attempts >= maxAttempts) {
          clearInterval(checkInterval);
          // 即使超时，如果图片预览存在，也认为是成功的
          if (imagePreview) {
            console.log('图片已成功上传，但耗时较长');
            resolve(true);
            return;
          }
          reject(new Error('图片上传超时，请检查网络连接或稍后重试'));
          return;
        }
        
        if (uploadProgress) {
          console.log(`图片上传中...${attempts}/${maxAttempts}`);
        }
      }, 500); // 缩短检查间隔到500ms
    });

    console.log('图片上传完成');
    return true;

  } catch (error) {
    console.error('图片上传失败:', error);
    throw error;
  }
}

// 微博内容发布模块
async function handleWeiboPublish(text, imageData) {
  try {
    console.log('开始处理微博发布...');
    
    // 等待页面完全加载
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // 等待编辑器加载并清理现有内容
    const editor = await waitForElement('.Form_input_2gtXx');
    if (!editor) {
      throw new Error('找不到编辑器元素');
    }

    // 确保内容被清理
    await clearEditorContent();
    
    // 设置新文本内容
    editor.textContent = text;
    editor.dispatchEvent(new Event('input', { bubbles: true }));
    console.log('文本内容已设置');

    // 如果有图片，上传图片（添加重试机制）
    if (imageData) {
      console.log('开始处理图片上传');
      let retryCount = 0;
      const maxRetries = 3;
      
      while (retryCount < maxRetries) {
        try {
          await uploadImage(imageData);
          break;
        } catch (uploadError) {
          retryCount++;
          console.error(`图片上传失败，尝试重试 ${retryCount}/${maxRetries}:`, uploadError);
          if (retryCount === maxRetries) {
            throw uploadError;
          }
          // 等待一段时间后重试
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }
    }

    console.log('内容准备完成，请手动点击发布按钮');
    return true;
  } catch (error) {
    console.error('准备发布内容失败:', error);
    throw error;
  }
}

// 监听来自扩展的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('收到消息:', request);

  // 响应 ping 消息
  if (request.action === 'ping') {
    sendResponse({ status: 'ready' });
    return;
  }

  if (request.action === 'clearContent') {
    clearEditorContent().then(success => {
      sendResponse({ success });
    });
    return true;
  }
  
  if (request.action === 'publish') {
    sendResponse({ success: true, status: 'started' });
    
    (async () => {
      try {
        console.log('开始执行发布操作...');
        
        // 等待页面完全加载
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // 等待编辑器加载
        const editor = await waitForElement('.Form_input_2gtXx');
        if (!editor) {
          throw new Error('找不到编辑器元素');
        }

        // 设置文本内容的关键改进
        console.log('准备设置内容:', request.content);
        
        // 1. 首先聚焦编辑器
        editor.focus();
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // 2. 清空现有内容
        document.execCommand('selectAll', false, null);
        document.execCommand('delete', false, null);
        await new Promise(resolve => setTimeout(resolve, 100));
        
        // 3. 插入新内容
        const text = request.content;
        document.execCommand('insertText', false, text);
        
        // 4. 触发必要的事件
        editor.dispatchEvent(new Event('input', { bubbles: true }));
        editor.dispatchEvent(new Event('change', { bubbles: true }));
        editor.dispatchEvent(new Event('blur', { bubbles: true }));
        
        // 5. 验证内容是否正确设置
        await new Promise(resolve => setTimeout(resolve, 100));
        if (editor.textContent !== text) {
          // 如果常规方法失败，尝试替代方法
          editor.innerHTML = text.replace(/\n/g, '<br>');
          editor.dispatchEvent(new Event('input', { bubbles: true }));
          editor.dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        console.log('内容设置完成，当前编辑器内容:', editor.textContent);
        
        // 如果有图片，处理图片上传
        if (request.imageData) {
          console.log('开始处理图片上传');
          await uploadImage(request.imageData);
        }
        
        // 等待发布按钮可用
        const publishButton = await waitForElement('.Tool_btn_2Eane', 100);
        if (!publishButton) {
          throw new Error('找不到发布按钮');
        }

        // 确保按钮可点击
        publishButton.removeAttribute('disabled');
        publishButton.classList.remove('Tool_disabled_3fCra');

        // 点击发布按钮前等待一下
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // 点击发布按钮
        await new Promise(resolve => setTimeout(resolve, 500));
        console.log('已准备好发布按钮，请手动点击');
        
        // 通知后台发布成功
        chrome.runtime.sendMessage({ 
          action: 'publishComplete',
          success: true 
        });
      } catch (error) {
        console.error('发布操作失败:', error);
        chrome.runtime.sendMessage({ 
          action: 'publishComplete',
          success: false,
          error: error.message 
        });
      }
    })();
    
    return false;
  }
  
  return false;
});

// 简化的图片上传函数
async function uploadImage(imageData) {
  try {
    console.log('开始上传图片...');
    
    const editor = await waitForElement('.Form_input_2gtXx');
    if (!editor) {
      throw new Error('找不到编辑器元素');
    }
    
    // 清理现有图片
    const existingImages = document.querySelectorAll('.picture_pic_2FfMX');
    if (existingImages.length > 0) {
      for (const img of existingImages) {
        const closeButton = img.closest('.picture_item_3zpnC')?.querySelector('.close_1OzvM');
        if (closeButton) {
          closeButton.click();
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    }
    
    // 将 base64 转换为 Blob
    const blob = await fetch(imageData).then(res => res.blob());
    const file = new File([blob], 'image.png', { type: blob.type });
    
    // 创建粘贴事件
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    const pasteEvent = new ClipboardEvent('paste', {
      bubbles: true,
      cancelable: true,
      clipboardData: dataTransfer
    });
    
    // 确保编辑器处于激活状态并粘贴图片
    editor.focus();
    await new Promise(resolve => setTimeout(resolve, 500));
    editor.dispatchEvent(pasteEvent);
    
    // 等待图片上传完成
    await new Promise((resolve, reject) => {
      let attempts = 0;
      const maxAttempts = 180; // 增加到180秒
      const checkInterval = setInterval(() => {
        attempts++;
        
        const uploadProgress = document.querySelector('.picture-upload-progress');
        const imagePreview = document.querySelector('.picture-preview');
        
        if (imagePreview && !uploadProgress) {
          // 如果找到预览图但没有上传进度条，说明上传已完成
          clearInterval(checkInterval);
          resolve(true);
          return;
        }
        
        if (attempts >= maxAttempts) {
          clearInterval(checkInterval);
          // 即使超时，如果图片预览存在，也认为是成功的
          if (imagePreview) {
            console.log('图片已成功上传，但耗时较长');
            resolve(true);
            return;
          }
          reject(new Error('图片上传超时，请检查网络连接或稍后重试'));
          return;
        }
        
        if (uploadProgress) {
          console.log(`图片上传中...${attempts}/${maxAttempts}`);
        }
      }, 500); // 缩短检查间隔到500ms
    });
    
    console.log('图片上传完成');
    return true;
  } catch (error) {
    console.error('图片上传失败:', error);
    throw error;
  }
}
