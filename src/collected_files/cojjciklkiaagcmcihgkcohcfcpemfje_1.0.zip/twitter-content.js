/**
 * Twitter (X) 内容发布模块 (Content Script)
 * 
 * 主要功能：
 * 1. 接收来自 background 的消息，处理文本和图片的同步
 * 2. 将内容插入到 Twitter 的编辑器中
 * 3. 处理图片上传和发布流程
 * 
 * 实现细节：
 * 1. 文本处理：
 *    - 使用标准输入事件插入文本
 *    - 处理 Twitter 特有的字符限制（280字符）
 *    - 处理多行文本和特殊字符
 *    - 维护 DraftJS 编辑器状态
 * 
 * 2. 图片处理：
 *    - 支持多图上传（最多4张）
 *    - 处理图片上传进度
 *    - 等待所有图片上传完成
 * 
 * 3. 发布流程：
 *    - 等待编辑器加载完成
 *    - 按顺序执行文本插入和图片上传
 *    - 处理发布按钮状态
 *    - 确认发布成功
 * 
 * 错误处理：
 * 1. 使用 Promise 和 async/await 处理异步操作
 * 2. 设置合理的超时时间
 * 3. 提供详细的错误日志
 * 4. 实现备选方案处理特殊情况
 * 
 * 调试说明：
 * 1. 所有日志使用统一的前缀（🐦 [X Publisher]）
 * 2. 分级记录信息（普通信息和错误）
 * 3. 提供详细的状态信息便于排查
 */

// 添加日志函数
function log(message, data = null) {
  const prefix = '🐦 [X Publisher]';
  if (data) {
    console.log(prefix, message, data);
  } else {
    console.log(prefix, message);
  }
}

function logError(message, error = null) {
  const prefix = '❌ [X Publisher]';
  if (error) {
    console.error(prefix, message, error);
  } else {
    console.error(prefix, message);
  }
}

// 监听来自 background 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  log('收到消息:', request);
  
  // 响应 ping 消息
  if (request.action === 'ping') {
    sendResponse({ status: 'ready' });
    return;
  }

  if (request.action === 'publish') {
    log('开始处理发布请求');
    // 立即发送一个初始响应
    sendResponse({ status: 'processing' });
    
    handlePublish(request.content, request.imageData)
      .then(result => {
        log('内容处理完成:', result);
        chrome.runtime.sendMessage({ 
          action: 'publishComplete', 
          result,
          message: '内容已准备就绪，请手动点击发布按钮'
        });
      })
      .catch(error => {
        logError('内容处理失败:', error);
        chrome.runtime.sendMessage({ 
          action: 'publishError', 
          error: error.message || '未知错误' 
        });
      });
      
    return true; // 保持消息通道开放
  }
});

// 处理发布
async function handlePublish(text, imageData) {
  try {
    log('开始处理发布...');
    
    // 等待编辑器加载
    const editor = await waitForElement('[data-testid="tweetTextarea_0"]', 10000);
    if (!editor) {
      throw new Error('找不到编辑器元素');
    }

    // 插入文本
    try {
      await insertText(editor, text);
      log('文本插入成功');
    } catch (textError) {
      logError('文本插入失败:', textError);
      throw textError;
    }

    // 如果有图片，插入图片
    if (imageData) {
      try {
        const imageResult = await insertImage(imageData);
        if (imageResult.success) {
          log('图片插入成功');
        } else {
          logError('图片处理未成功，但不影响发布:', imageResult.error);
        }
      } catch (imageError) {
        // 只记录错误，不抛出
        logError('图片处理未成功，但不影响发布:', imageError);
      }
    }

    log('内容已准备就绪');
    return true;
  } catch (error) {
    logError('内容处理失败:', error);
    throw error;
  }
}

// 等待元素出现的辅助函数
function waitForElement(selector, timeout = 5000) {
  return new Promise((resolve) => {
    const element = document.querySelector(selector);
    if (element) {
      return resolve(element);
    }

    const observer = new MutationObserver((mutations, obs) => {
      const element = document.querySelector(selector);
      if (element) {
        obs.disconnect();
        resolve(element);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    setTimeout(() => {
      observer.disconnect();
      resolve(document.querySelector(selector));
    }, timeout);
  });
}

// 插入文本
async function insertText(editor, text) {
  log('开始插入文本');
  
  // 确保编辑器获得焦点
  editor.focus();
  await new Promise(resolve => setTimeout(resolve, 50));

  try {
    // 处理文本，确保空行被正确转换为换行符
    const processedText = text.split('\n').map(line => {
      // 保留空行，但确保它至少包含一个空格
      return line.trim() === '' ? ' ' : line;
    }).join('\n');

    // 首先尝试使用 clipboardData 方式插入
    const pasteEvent = new ClipboardEvent('paste', {
      bubbles: true,
      cancelable: true,
      clipboardData: new DataTransfer()
    });
    pasteEvent.clipboardData.setData('text/plain', processedText);
    editor.dispatchEvent(pasteEvent);
    
    // 等待一段时间检查文本是否插入成功
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // 检查文本是否正确插入，使用相同的处理方式比较
    const insertedText = editor.innerText.replace(/\u200B/g, '').trim();
    const normalizedText = processedText.trim();
    
    if (insertedText !== normalizedText) {
      log('通过 paste 事件插入失败，尝试模拟键盘输入');
      
      // 清空现有内容
      editor.textContent = '';
      
      // 创建一个临时的 div 来保存格式化的文本
      const tempDiv = document.createElement('div');
      tempDiv.style.whiteSpace = 'pre-wrap';
      
      // 将处理后的文本按行分割并添加适当的换行
      const lines = processedText.split('\n');
      lines.forEach((line, index) => {
        const span = document.createElement('span');
        span.textContent = line;
        tempDiv.appendChild(span);
        if (index < lines.length - 1) {
          tempDiv.appendChild(document.createElement('br'));
        }
      });
      
      // 使用 contenteditable API 插入文本
      const range = document.createRange();
      range.selectNodeContents(editor);
      range.deleteContents();
      
      const fragment = document.createDocumentFragment();
      while (tempDiv.firstChild) {
        fragment.appendChild(tempDiv.firstChild);
      }
      range.insertNode(fragment);
      
      // 触发必要的事件
      editor.dispatchEvent(new Event('input', { bubbles: true }));
      editor.dispatchEvent(new Event('change', { bubbles: true }));
    }
  } catch (error) {
    logError('插入文本时出错:', error);
    throw error;
  }
  
  // 确保编辑器保持焦点并将光标移到末尾
  editor.focus();
  const range = document.createRange();
  range.selectNodeContents(editor);
  range.collapse(false);
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
  
  log('文本插入完成');
  return true;
}

// 插入图片
async function insertImage(imageData) {
  const editor = await waitForElement('[data-testid="tweetTextarea_0"]', 10000);
  if (!editor) {
    return { success: false, error: new Error('找不到编辑器元素') };
  }

  log('开始处理图片...');

  try {
    // 预处理图片数据
    const blob = await fetch(imageData).then(res => res.blob());
    const file = new File([blob], 'image.png', { type: blob.type });

    // 确保编辑器已聚焦
    editor.focus();
    
    // 使用拖放方式上传图片
    const dt = new DataTransfer();
    dt.items.add(file);
    
    const dropEvent = new DragEvent('drop', {
      bubbles: true,
      cancelable: true,
      dataTransfer: dt
    });
    
    editor.dispatchEvent(dropEvent);
    
    // 等待图片上传
    const uploadStarted = await waitForUploadStart(5000);
    if (!uploadStarted) {
      return { success: false, error: new Error('图片上传未开始') };
    }

    const uploadResult = await checkImageUpload(15000);
    return uploadResult;
  } catch (error) {
    return { success: false, error };
  }
}

// 等待图片上传开始
async function waitForUploadStart(timeout = 5000) {
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    try {
      // 检查是否出现进度条或预览
      const progressBar = document.querySelector('[role="progressbar"]');
      const imagePreview = document.querySelector('[data-testid="imagePreview"]');
      
      if (progressBar || imagePreview) {
        return true;
      }
    } catch (error) {
      // 忽略 DOM 查询错误
    }
    
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  
  return false;
}

// 检查图片上传状态
async function checkImageUpload(timeout = 15000) {
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    try {
      const imagePreview = document.querySelector('[data-testid="imagePreview"]');
      
      // 只要看到图片预览就认为上传成功
      if (imagePreview) {
        return { success: true };
      }
    } catch (error) {
      // 忽略 DOM 查询错误
    }
    
    // 使用较短的检查间隔
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  
  // 如果超时也返回成功，因为可能是网络延迟导致没有及时检测到预览
  return { success: true };
}
