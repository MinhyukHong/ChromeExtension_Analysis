// 等待元素出现的通用函数
async function waitForElement(selector, maxAttempts = 50) {
  console.log('等待元素:', selector);
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const element = document.querySelector(selector);
    if (element) {
      console.log('找到元素:', selector);
      return element;
    }
    await new Promise(resolve => setTimeout(resolve, 100));  
  }
  throw new Error('找不到元素: ' + selector);
}

// 将 base64 图片数据转换为 File 对象
async function base64ToFile(base64Data, filename = 'image.png') {
  const response = await fetch(base64Data);
  const blob = await response.blob();
  return new File([blob], filename, { type: 'image/png' });
}

// 处理文本输入
async function handleTextInput(text) {
  try {
    const textarea = await waitForElement('.PostInput___StyledStyledTextarea-sc-1vqvx17-0');
    textarea.value = text;
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  } catch (error) {
    console.error('文本输入失败:', error);
    throw error;
  }
}

// 处理图片上传
async function handleImageUpload(imageData) {
  try {
    // 找到隐藏的文件输入框
    const imageInput = await waitForElement('input[type="file"][accept="image/*"]');
    const file = await base64ToFile(imageData);
    
    // 创建 DataTransfer 对象并添加文件
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    
    // 设置文件到输入框并触发 change 事件
    imageInput.files = dataTransfer.files;
    imageInput.dispatchEvent(new Event('change', { bubbles: true }));
    
    return true;
  } catch (error) {
    console.error('图片上传失败:', error);
    throw error;
  }
}

// 检查发布按钮状态
async function checkPublishButton() {
  try {
    // 即刻的发布按钮通常在页面右上角，是一个带有"发布"文本的按钮
    const buttons = Array.from(document.querySelectorAll('button'));
    const publishButton = buttons.find(button => button.textContent.includes('发布'));
    
    if (!publishButton) {
      console.log('未找到发布按钮');
      return false;
    }
    
    console.log('找到发布按钮:', publishButton);
    return !publishButton.disabled;
  } catch (error) {
    console.error('检查发布按钮失败:', error);
    return false;
  }
}

// 主发布函数
async function handleJikePublish(text, imageData) {
  try {
    // 输入文本
    await handleTextInput(text);
    
    // 如果有图片，上传图片
    if (imageData) {
      await handleImageUpload(imageData);
    }
    
    // 等待发布按钮变为可用状态
    let attempts = 0;
    while (attempts < 10 && !(await checkPublishButton())) {
      await new Promise(resolve => setTimeout(resolve, 500));
      attempts++;
    }
    
    return { success: true };
  } catch (error) {
    console.error('发布失败:', error);
    return { success: false, error: error.message };
  }
}

// 监听来自扩展的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('收到消息:', request);
  
  if (request.action === 'publish') {
    // 使用 text 或 content 字段，保持向后兼容性
    const textContent = request.text || request.content;
    handleJikePublish(textContent, request.imageData)
      .then(result => {
        console.log('发布结果:', result);
        sendResponse(result);
      })
      .catch(error => {
        console.error('发布失败:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
  
  // 用于检查内容脚本是否已加载
  if (request.action === 'ping') {
    sendResponse({ success: true });
    return true;
  }
});
