# Social Media Publisher

Chrome 扩展，用于自动发布内容到各个社交媒体平台。

## 实现原理

本扩展通过 Chrome Extension API 在目标网页中注入 JavaScript 代码，模拟用户操作来实现内容发布：

1. **工作方式**
   - 在浏览器中注入 JavaScript 代码
   - 通过 DOM 操作找到并控制页面元素
   - 模拟用户的输入、点击等操作

2. **核心技术**
   - 使用选择器定位页面元素
   - JavaScript 事件模拟用户行为
   - 处理异步操作和状态检查
   - 错误处理和失败重试
   

## 已实现平台

### 知乎

#### 技术方案
1. **文本输入**
   - 使用 Clipboard API 模拟粘贴操作
   - 通过 ClipboardEvent 触发粘贴事件
   - 失败时回退到直接设置 textContent

2. **关键元素**
   - 编辑器容器: `.DraftEditor-root`
   - 编辑区域: `.public-DraftEditor-content`
   - 发布按钮: `.Button.css-1o2ioyv`

3. **实现细节**
   - 需要等待编辑器完全加载
   - 触发必要的事件（input, change, blur）
   - 正确处理发布按钮状态

### 微博

#### 技术方案
1. **文本输入**
   - 直接设置编辑器的 textContent
   - 触发 input 事件确保内容更新

2. **图片上传**
   - 使用文件上传方式（不使用粘贴方式）
   - 通过 File 对象和 DataTransfer 模拟文件选择
   - 触发 change 事件进行上传

3. **关键元素**
   - 编辑器: `.Form_input_2gtXx`
   - 图片按钮: `.VPlus_file_n7Xjc`
   - 文件输入: `input[type="file"][accept*="image"]`
   - 发布按钮: `.Tool_btn_2Eane`
   - 上传成功标志: `.picture_pic_2FfMX`
   - 上传错误标志: `.picture_upload_error_text_1E5Zw`

4. **实现细节**
   - 图片上传需要足够的等待时间（最多20次尝试）
   - 发布按钮需要移除 disabled 属性和 class
   - 所有操作需要按顺序执行，不能并行

## 注意事项

1. **选择器维护**
   - 所有选择器都可能随平台更新而变化
   - 需要定期检查并更新选择器

2. **错误处理**
   - 所有操作都有超时机制
   - 提供清晰的错误信息
   - 失败时有降级方案

3. **代码组织**
   - 每个平台独立的内容文件
   - 通用函数抽取复用
   - 详细的注释说明

