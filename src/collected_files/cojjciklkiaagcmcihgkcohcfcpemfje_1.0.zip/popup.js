document.addEventListener('DOMContentLoaded', () => {
  const contentInput = document.getElementById('content');
  const imageContainer = document.getElementById('imageContainer');
  const generateImageButton = document.getElementById('generateImageButton');
  const downloadImageButton = document.getElementById('downloadImage');
  const imagePreview = document.getElementById('imagePreview');
  
  // 跟踪是否已生成图片
  let generatedImageData = null;

  // 在后台自动进行文本格式化
  function formatText(text) {
    if (!text) return '';
    
    // 在中文和英文之间添加空格
    text = text.replace(/([A-Za-z])([\u4e00-\u9fa5])/g, '$1 $2')
               .replace(/([\u4e00-\u9fa5])([A-Za-z])/g, '$1 $2');
    
    // 在特定标点符号后添加换行
    text = text.replace(/([。！？\n]+)/g, '$1\n')
               .replace(/([。！？]+\n)/g, '$1\n');
    
    // 去除多余的换行
    text = text.replace(/\n{3,}/g, '\n\n');
    
    return text.trim();
  }

  // 图片生成函数
  async function generateImage() {
    const text = formatText(document.getElementById('content').value);
    if (!text) {
      return null;
    }

    // 创建临时容器
    const tempContainer = document.createElement('div');
    tempContainer.style.cssText = `
      position: absolute;
      left: -9999px;
      padding: 32px;
      width: 600px;
      min-height: 200px;
      background: linear-gradient(135deg, #e6f0ff 0%, #f0f6ff 100%);
      border-radius: 20px;
      font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
      white-space: pre-wrap;
      word-break: break-word;
      box-sizing: border-box;
    `;

    // 创建内容容器（毛玻璃效果）
    const contentContainer = document.createElement('div');
    contentContainer.style.cssText = `
      padding: 28px;
      background: rgba(255, 255, 255, 0.7);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border-radius: 20px;
      box-shadow: 
        0 4px 6px rgba(0, 0, 0, 0.02),
        0 10px 15px rgba(0, 0, 0, 0.03),
        0 20px 30px rgba(0, 0, 0, 0.04);
      line-height: 1.8;
      font-size: 16px;
      color: #2c3e50;
      letter-spacing: 0.5px;
    `;

    // 处理文本格式：将第一行作为标题
    const lines = text.split('\n');
    if (lines.length > 1) {
      const title = document.createElement('div');
      title.style.cssText = `
        text-align: center;
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 24px;
        color: #1a1a1a;
      `;
      title.textContent = lines[0];
      
      const content = document.createElement('div');
      content.style.cssText = `
        text-align: left;
      `;
      content.textContent = lines.slice(1).join('\n');
      
      contentContainer.appendChild(title);
      contentContainer.appendChild(content);
    } else {
      contentContainer.textContent = text;
    }

    // 将内容容器添加到临时容器
    tempContainer.appendChild(contentContainer);
    document.body.appendChild(tempContainer);

    // 调整容器高度以适应内容
    const contentHeight = contentContainer.offsetHeight;
    tempContainer.style.height = (contentHeight + 64) + 'px'; // 64px 是上下内边距之和

    try {
      // 使用 html2canvas 生成图片
      const canvas = await html2canvas(tempContainer, {
        scale: 2,
        backgroundColor: null,
        logging: false
      });

      // 移除临时容器
      document.body.removeChild(tempContainer);

      // 返回图片的 base64 数据
      return canvas.toDataURL('image/png');
    } catch (error) {
      console.error('生成图片失败:', error);
      document.body.removeChild(tempContainer);
      return null;
    }
  }

  // 图片生成功能
  generateImageButton.addEventListener('click', async () => {
    const text = formatText(contentInput.value);
    if (!text) {
      alert('请先输入内容');
      return;
    }

    try {
      generatedImageData = await generateImage();
      if (generatedImageData) {
        imagePreview.src = generatedImageData;
        imagePreview.style.display = 'block';
        downloadImageButton.style.display = 'block';
        console.log('图片已生成并显示');
      }
    } catch (error) {
      console.error('生成图片失败:', error);
      alert('生成图片失败: ' + error.message);
    }
  });

  // 下载图片功能
  downloadImageButton.addEventListener('click', () => {
    if (!generatedImageData) {
      alert('请先生成图片');
      return;
    }

    const link = document.createElement('a');
    link.href = generatedImageData;
    link.download = '分享图片.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  });

  // 发布功能
  document.getElementById('publishAll').addEventListener('click', async () => {
    const content = contentInput.value;
    const selectedPlatforms = Array.from(document.querySelectorAll('input[name="platform"]:checked'))
      .map(input => input.value);

    if (selectedPlatforms.length === 0) {
      document.getElementById('status').textContent = '请选择至少一个发布平台';
      return;
    }

    const publishButton = document.getElementById('publishAll');
    publishButton.disabled = true;
    document.getElementById('status').textContent = '发布中...';

    try {
      const response = await chrome.runtime.sendMessage({
        action: 'publish',
        data: {
          content: content,
          platforms: selectedPlatforms,
          imageData: generatedImageData
        }
      });

      if (response.success) {
        document.getElementById('status').textContent = '发布成功！';
      } else {
        document.getElementById('status').textContent = '发布失败: ' + response.error;
      }
    } catch (error) {
      document.getElementById('status').textContent = '发布失败: ' + error.message;
    } finally {
      publishButton.disabled = false;
    }
  });
});