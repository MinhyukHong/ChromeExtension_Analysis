# Chrome Web Store Description

## 简短描述 (Short Description)
[中文]
一键发布内容到多个社交媒体平台，支持微博、Twitter/X、知乎和即刻，让分享更轻松！

[English]
Publish content to multiple social media platforms with one click! Supporting Weibo, Twitter/X, Zhihu, and Jike.

## 详细描述 (Detailed Description)
[中文]
🚀 主要功能：
• 一键多平台发布：同时将内容分享到微博、Twitter/X、知乎和即刻
• 智能格式适配：自动调整内容格式以符合各平台特点
• 图片分享支持：轻松分享文字配图内容
• 一键复制：快速复制已编辑好的内容到剪贴板
• 简洁界面：清爽的用户界面，操作简单直观

✨ 为什么选择我们：
• 节省时间：无需在多个平台间来回切换
• 提高效率：一次编辑，多平台同步发布
• 完全免费：所有功能免费使用
• 注重隐私：不收集任何个人数据
• 轻量级：占用资源少，不影响浏览器性能


[English]
🚀 Key Features:
• Multi-platform Publishing: Share content simultaneously on Weibo, Twitter/X, Zhihu, and Jike
• Smart Format Adaptation: Automatically adjusts content format for each platform
• Image Sharing Support: Easily share text with images
• One-click Copy: Quick copy of edited content to clipboard
• Clean Interface: Simple and intuitive user interface

✨ Why Choose Us:
• Save Time: No need to switch between multiple platforms
• Boost Efficiency: Edit once, publish everywhere
• Completely Free: All features available at no cost
• Privacy Focused: No personal data collection
• Lightweight: Minimal browser resource usage



## 使用流程 | How to Use

[中文]
1. 点击浏览器工具栏中的扩展图标，打开发布界面
2. 在弹出的窗口中输入要发布的内容
3. 选择要发布到的社交媒体平台（支持微博、Twitter/X、知乎和即刻）
4. 点击"发布"按钮后，扩展会：
   - 自动打开所选平台的发布页面
   - 将您输入的内容同步填充到平台的编辑框中
   - 等待您检查内容并手动点击平台的发布按钮

[English]
1. Click the extension icon in the browser toolbar to open the publishing interface
2. Enter your content in the popup window
3. Select the social media platforms you want to publish to (supports Weibo, Twitter/X, Zhihu, and Jike)
4. After clicking the "Publish" button, the extension will:
   - Automatically open the publishing page of the selected platform
   - Sync your content to the platform's editor
   - Wait for you to review and manually click the platform's publish button

## 权限说明 | Permission Details

[中文]
本扩展请求以下权限用于实现核心功能：

- `activeTab`: 用于在当前标签页执行内容脚本
- `scripting`: 用于注入必要的脚本以实现内容同步
- `clipboardWrite`: 用于处理内容粘贴操作

这些权限都是实现上述工作流程所必需的最小权限集合。我们承诺不会收集任何用户数据，所有操作都在本地完成。

[English]
This extension requests the following permissions for core functionality:

- `activeTab`: Required to execute content scripts in the current tab
- `scripting`: Required to inject necessary scripts for content syncing
- `clipboardWrite`: Required for content paste operations

These permissions are the minimum required set to implement the workflow described above. We commit to not collecting any user data, and all operations are performed locally.
