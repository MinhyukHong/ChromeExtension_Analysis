/**
 * Social Media Publisher Chrome Extension
 * 
 * 架构说明：
 * 本扩展采用Chrome扩展标准架构，包含以下主要组件：
 * 1. Background Script (本文件) - 作为整个扩展的控制中心
 * 2. Content Scripts (*-content.js) - 负责在各平台页面中执行具体的发布操作
 * 3. Popup UI - 提供用户界面，收集发布内容和配置
 * 
 * Background Script 主要职责：
 * 1. 统一管理各平台的发布流程
 * 2. 处理来自popup的发布请求
 * 3. 协调与各平台content script的通信
 * 4. 管理浏览器tab的创建、切换和关闭
 * 5. 处理错误情况和重试机制
 * 
 * 发布流程：
 * 1. 接收popup发来的发布请求
 * 2. 根据选择的平台创建对应的tab
 * 3. 注入对应的content script
 * 4. 等待content script准备就绪
 * 5. 发送内容到content script进行发布
 * 6. 处理发布结果并反馈给popup
 * 
 * 错误处理：
 * 1. 超时重试机制
 * 2. 发布失败的错误收集
 * 3. Tab状态异常处理
 */

// 平台配置
const PLATFORM_CONFIG = {
  zhihu: {
    url: 'https://www.zhihu.com/',
    publisher: publishToZhihu
  },
  weibo: {
    url: 'https://weibo.com/',
    publisher: publishToWeibo
  },
  twitter: {
    url: 'https://twitter.com/home',
    publisher: publishToTwitter
  },
  jike: {
    url: 'https://web.okjike.com',  // 修正为正确的主页地址
    publisher: publishToJike
  }
};

// 监听来自popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('收到消息:', request);
  
  if (request.action === 'publish') {
    handlePublish(request.data.content, request.data.platforms, request.data.imageData)
      .then(result => {
        console.log('发布结果:', result);
        sendResponse({ success: true, result });
      })
      .catch(error => {
        console.error('发布失败:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

// 等待内容脚本准备就绪
async function waitForContentScript(tabId, maxAttempts = 5) {
  for (let i = 0; i < maxAttempts; i++) {
    try {
      await chrome.tabs.sendMessage(tabId, { action: 'ping' });
      console.log(`内容脚本就绪: tabId=${tabId}`);
      return true;
    } catch (error) {
      console.log(`等待内容脚本 (${i + 1}/${maxAttempts}): tabId=${tabId}`);
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
  return false;
}

// 主发布处理函数
async function handlePublish(content, platforms, imageData) {
  console.log('开始发布流程...', { content, platforms, imageData });
  const publishPromises = [];

  try {
    // 对每个平台并行处理
    for (const platform of platforms) {
      const config = PLATFORM_CONFIG[platform];
      if (!config) {
        throw new Error(`未知平台: ${platform}`);
      }

      const publishPromise = (async () => {
        try {
          // 创建新标签页
          console.log(`为 ${platform} 创建标签页`);
          const tab = await chrome.tabs.create({ url: config.url, active: false });
          
          // 等待页面加载完成
          await new Promise((resolve) => {
            const listener = (tabId, info) => {
              if (tabId === tab.id && info.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
              }
            };
            chrome.tabs.onUpdated.addListener(listener);
          });

          // 等待内容脚本就绪
          if (!await waitForContentScript(tab.id)) {
            throw new Error(`内容脚本初始化失败: ${platform}`);
          }

          // 发送发布消息到内容脚本
          const response = await chrome.tabs.sendMessage(tab.id, {
            action: 'publish',
            content: content,
            imageData: imageData
          });

          return { platform, success: true, response };
        } catch (error) {
          console.error(`${platform}发布失败:`, error);
          return { platform, success: false, error: error.message };
        }
      })();

      publishPromises.push(publishPromise);
    }

    // 等待所有发布任务完成
    const results = await Promise.all(publishPromises);
    
    // 检查是否所有平台都发布成功
    const allSuccess = results.every(result => result.success);
    
    return { 
      success: allSuccess, 
      results,
      error: allSuccess ? null : '部分平台发布失败，请查看详细结果'
    };
  } catch (error) {
    console.error('发布过程出错:', error);
    return { success: false, error: error.message };
  }
}

// 知乎发布函数
async function publishToZhihu(tabId, content) {
  try {
    console.log('开始知乎发布流程');

    // 等待页面加载完成
    await new Promise(resolve => setTimeout(resolve, 2000));

    // 检查content script是否需要注入
    try {
      await chrome.tabs.sendMessage(tabId, { action: 'ping' });
    } catch (error) {
      console.log('Content script 未加载，开始注入...');
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['zhihu-content.js']
      });
      // 等待脚本加载
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // 向 content script 发送消息
    const response = await chrome.tabs.sendMessage(tabId, {
      action: 'publishToZhihu',
      text: content
    });

    if (!response || !response.success) {
      throw new Error(response?.error || '发布失败');
    }

    console.log('知乎发布脚本执行完成');
  } catch (error) {
    console.error('知乎发布失败:', error);
    throw error;
  }
}

// 微博发布函数
async function publishToWeibo(content, imageData) {
  try {
    console.log('开始发布到微博...');
    
    // 获取或创建微博标签页
    const tab = await getOrCreateWeiboTab();
    if (!tab) {
      throw new Error('无法创建或获取微博标签页');
    }
    
    // 等待页面加载完成
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // 注入内容脚本
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['weibo-content.js']
    });
    
    // 发送发布请求
    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'publish',
      content: content,
      imageData: imageData
    });
    
    if (!response || !response.success) {
      throw new Error(response?.error || '发布请求失败');
    }
    
    // 等待发布完成的消息
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('发布操作超时'));
      }, 30000);
      
      const messageListener = (message) => {
        if (message.action === 'publishComplete') {
          clearTimeout(timeout);
          chrome.runtime.onMessage.removeListener(messageListener);
          
          if (message.success) {
            resolve();
          } else {
            reject(new Error(message.error || '发布失败'));
          }
        }
      };
      
      chrome.runtime.onMessage.addListener(messageListener);
    });
  } catch (error) {
    console.error('微博发布失败:', error);
    throw error;
  }
}

// Twitter (通过 Typefully) 发布函数
async function publishToTwitter(tabId, content, imageData) {
  await chrome.scripting.executeScript({
    target: { tabId },
    func: async (content, imageData) => {
      const waitForElement = (selector, timeout = 10000) => {
        return new Promise((resolve, reject) => {
          const startTime = Date.now();
          const check = () => {
            const element = document.querySelector(selector);
            if (element) {
              resolve(element);
            } else if (Date.now() - startTime > timeout) {
              reject(new Error(`等待元素超时: ${selector}`));
            } else {
              setTimeout(check, 100);
            }
          };
          check();
        });
      };

      try {
        // 等待编辑器加载
        const editor = await waitForElement('[contenteditable="true"]');
        
        // 输入文本内容
        editor.textContent = content;
        editor.dispatchEvent(new InputEvent('input', { bubbles: true }));

        // 如果有图片，添加到剪贴板并提示用户
        if (imageData) {
          // 创建一个临时的文本区域来复制内容
          const textarea = document.createElement('textarea');
          textarea.value = content;
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);

          // 转换图片数据为 Blob
          const response = await fetch(imageData);
          const blob = await response.blob();
          
          // 创建 ClipboardItem
          const clipboardItem = new ClipboardItem({
            [blob.type]: blob
          });
          
          // 写入剪贴板
          await navigator.clipboard.write([clipboardItem]);
          
          alert('内容和图片已复制到剪贴板，请按 Ctrl+V 或 Command+V 粘贴');
        }
      } catch (error) {
        console.error('发布失败:', error);
        alert('发布失败: ' + error.message);
      }
    },
    args: [content, imageData]
  });
}

// 即刻发布函数
async function publishToJike(tabId, content, imageData) {
  try {
    // 等待内容脚本准备就绪
    if (!(await waitForContentScript(tabId))) {
      throw new Error('内容脚本未就绪');
    }

    // 发送发布请求到内容脚本
    const result = await chrome.tabs.sendMessage(tabId, {
      action: 'publish',
      text: content,
      imageData: imageData
    });

    if (!result.success) {
      throw new Error(result.error || '发布失败');
    }

    return result;
  } catch (error) {
    console.error('即刻发布失败:', error);
    throw error;
  }
}

// 监听来自content script的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'keepAlive') {
    sendResponse({ success: true });
  }
});