# Privacy Policy

[中文]
隐私政策

最后更新日期：2024年12月28日

感谢您使用 Social Media Publisher 扩展程序。我们高度重视您的隐私，并承诺保护您的个人信息。

1. 信息收集
我们不收集、存储或传输任何个人信息。本扩展程序运行所需的所有数据都存储在您的本地浏览器中。

2. 权限使用说明
本扩展程序请求以下权限：
- activeTab：用于访问当前标签页，实现内容发布功能
- scripting：用于在特定网站执行内容发布脚本
- tabs：用于管理标签页状态
- clipboardWrite：用于复制内容到剪贴板

3. 数据存储
- 所有数据仅存储在您的本地浏览器中
- 不会将任何数据上传到外部服务器
- 您可以随时通过卸载扩展程序删除所有相关数据

4. 第三方网站
本扩展程序与以下第三方网站交互：
- weibo.com
- twitter.com / x.com
- zhihu.com
- okjike.com
请注意，这些网站有其各自的隐私政策，我们建议您查看这些政策。

5. 更新
我们可能会不时更新本隐私政策。更新后的版本将在 Chrome Web Store 页面公布。

6. 联系我们
如果您对本隐私政策有任何疑问，请通过 Chrome Web Store 页面与我们联系。

[English]
Privacy Policy

Last Updated: December 28, 2024

Thank you for using the Social Media Publisher extension. We highly value your privacy and are committed to protecting your personal information.

1. Information Collection
We do not collect, store, or transmit any personal information. All data required for the extension to function is stored locally in your browser.

2. Permissions Explanation
This extension requests the following permissions:
- activeTab: To access the current tab for content publishing
- scripting: To execute content publishing scripts on specific websites
- tabs: To manage tab states
- clipboardWrite: To copy content to clipboard

3. Data Storage
- All data is stored locally in your browser only
- No data is uploaded to external servers
- You can remove all related data by uninstalling the extension

4. Third-Party Websites
This extension interacts with the following third-party websites:
- weibo.com
- twitter.com / x.com
- zhihu.com
- okjike.com
Please note that these websites have their own privacy policies, which we recommend reviewing.

5. Updates
We may update this privacy policy from time to time. Updated versions will be posted on the Chrome Web Store page.

6. Contact Us
If you have any questions about this privacy policy, please contact us through the Chrome Web Store page.
