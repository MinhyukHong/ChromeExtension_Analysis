/**
 * 知乎内容发布模块
 * 
 * 技术方案说明：
 * 1. 文本输入实现：
 *    - 使用 execCommand 和事件模拟实现文本输入
 *    - 通过 DraftJS 特定事件确保内容更新
 *    - 多重备份方案确保内容能够正确插入
 * 
 * 2. 关键选择器：
 *    - 编辑器容器: .DraftEditor-root
 *    - 编辑区域: .public-DraftEditor-content
 *    - 发布按钮: .Button.css-1o2ioyv
 * 
 * 3. 注意事项：
 *    - 必须等待编辑器完全加载
 *    - 需要触发必要的事件（input, change, blur）
 *    - 发布按钮状态需要正确处理
 */

// 等待元素出现的通用函数
const waitForElement = async (selector, maxAttempts = 30) => {
  console.log('等待元素:', selector);
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const element = document.querySelector(selector);
    if (element) {
      console.log('找到元素:', selector);
      return element;
    }
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  throw new Error('找不到元素: ' + selector);
};

// 处理知乎发布
async function handleZhihuPublish(text) {
  try {
    console.log('开始执行知乎内容脚本');
    
    // 等待并点击"写想法"按钮
    console.log('查找写想法按钮...');
    const writeButton = await waitForElement('button.GlobalWriteV2-topItem:nth-child(4)');
    writeButton.click();
    
    // 等待编辑器加载
    console.log('等待编辑器加载...');
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // 获取编辑器相关元素
    const editor = await waitForElement('.public-DraftEditor-content[contenteditable="true"]');
    
    // 创建一个新的 contenteditable div 来临时存放内容
    const tempDiv = document.createElement('div');
    tempDiv.contentEditable = true;
    tempDiv.style.position = 'absolute';
    tempDiv.style.left = '-9999px';
    document.body.appendChild(tempDiv);

    try {
      // 将文本转换为HTML格式
      const formattedText = text.split('\n').map(line => 
        `<div>${line || '<br>'}</div>`
      ).join('');
      
      // 将格式化的文本放入临时div
      tempDiv.innerHTML = formattedText;

      // 聚焦编辑器
      editor.focus();
      
      // 创建一个新的 Selection 和 Range
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(editor);
      selection.removeAllRanges();
      selection.addRange(range);

      // 将内容复制到剪贴板
      const clipboardData = new DataTransfer();
      clipboardData.setData('text/html', tempDiv.innerHTML);
      clipboardData.setData('text/plain', text);

      // 创建并触发粘贴事件
      const pasteEvent = new ClipboardEvent('paste', {
        bubbles: true,
        cancelable: true,
        clipboardData: clipboardData
      });
      
      // 触发粘贴事件
      editor.dispatchEvent(pasteEvent);

      // 等待一下以确保内容被处理
      await new Promise(resolve => setTimeout(resolve, 500));

      // 模拟按键事件来触发内容更新
      const keyEvent = new KeyboardEvent('keydown', {
        key: 'Process',
        code: 'Process',
        bubbles: true
      });
      editor.dispatchEvent(keyEvent);

      // 触发其他必要的事件
      ['input', 'change', 'blur', 'focus'].forEach(eventType => {
        editor.dispatchEvent(new Event(eventType, { bubbles: true }));
      });

      // 最后再次聚焦编辑器
      editor.focus();
      
      // 等待确保内容更新
      await new Promise(resolve => setTimeout(resolve, 1000));
    } finally {
      // 清理临时元素
      document.body.removeChild(tempDiv);
    }
    
    console.log('知乎内容设置完成');
    return true;
    
  } catch (error) {
    console.error('知乎发布失败:', error);
    throw error;
  }
}

// 监听来自扩展的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('收到消息:', request);

  // 响应 ping 消息
  if (request.action === 'ping') {
    sendResponse({ status: 'ready' });
    return;
  }

  if (request.action === 'publish') {
    handleZhihuPublish(request.content)
      .then(result => {
        console.log('知乎发布成功');
        sendResponse({ success: true });
      })
      .catch(error => {
        console.error('知乎发布失败:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});
